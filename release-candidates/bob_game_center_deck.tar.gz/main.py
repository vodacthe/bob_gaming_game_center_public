"""
Bob Gaming Game Center - Main Entry Point

Desktop application for syncing game saves across multiple computers
using Nextcloud WebDAV as the cloud storage backend.
"""

import sys
import os
import signal
import logging
import traceback

# Ensure the app package is importable
if getattr(sys, 'frozen', False):
    # Running as PyInstaller bundle
    app_dir = sys._MEIPASS
    # Tell pysdl2 where the bundled SDL2 DLLs are
    os.environ.setdefault('PYSDL2_DLL_PATH', app_dir)
else:
    app_dir = os.path.dirname(os.path.abspath(__file__))

# Configure SDL2 for global background gamepad input capture before any SDL2 module is loaded
os.environ["SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS"] = "1"
os.environ["SDL_JOYSTICK_RAWINPUT"] = "0"

sys.path.insert(0, app_dir)

def configure_qt_platform_args(argv: list[str], platform_name: str = sys.platform) -> list[str]:
    """Configure Qt platform flags. Only Windows uses windows:darkmode=2.
    Preserves any explicit user-specified -platform or --platform argument."""
    args = list(argv)
    has_platform = any(
        isinstance(arg, str)
        and (
            arg in ("-platform", "--platform")
            or arg.startswith(("-platform=", "--platform="))
        )
        for arg in args
    )
    if has_platform:
        return args
    if platform_name == "win32":
        args.extend(["-platform", "windows:darkmode=2"])
    return args


# Force dark mode on Windows (must not be passed on Linux/SteamOS)
sys.argv = configure_qt_platform_args(sys.argv)

from app.config import LOG_FILE, CRASH_LOG_FILE, CONFIG_DIR
from app.core.pyz_pin import install_frozen_pyz_pin

install_frozen_pyz_pin()

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt, QtMsgType, qInstallMessageHandler
from PySide6.QtGui import QFont, QIcon

from app.ui.main_window import MainWindow
from app.ui.styles import DARK_THEME
from app.version import APP_VERSION

logger = logging.getLogger(__name__)

# Lock file for single instance
LOCK_FILE = os.path.join(CONFIG_DIR, "app.lock")


# ===================== CRASH LOGGING =====================

def _install_crash_handlers():
    """Install global exception and Qt message handlers to log crashes."""
    crash_logger = logging.getLogger("CRASH")

    # --- Python unhandled exception handler ---
    _original_excepthook = sys.excepthook

    def _crash_excepthook(exc_type, exc_value, exc_tb):
        """Log unhandled Python exceptions to crash.log before dying."""
        tb_text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        crash_logger.critical(
            f"UNHANDLED EXCEPTION — app will crash\n"
            f"{'=' * 60}\n"
            f"{tb_text}"
            f"{'=' * 60}"
        )
        # Flush all handlers to ensure crash info is written
        for handler in logging.root.handlers:
            handler.flush()
        # Call original hook (prints to stderr)
        _original_excepthook(exc_type, exc_value, exc_tb)

    sys.excepthook = _crash_excepthook

    # --- Qt/C++ fatal message handler ---
    def _qt_message_handler(msg_type, context, message):
        """Capture Qt fatal/critical messages to crash.log."""
        if msg_type == QtMsgType.QtFatalMsg:
            crash_logger.critical(
                f"QT FATAL — app will crash\n"
                f"{'=' * 60}\n"
                f"{message}\n"
                f"  File: {context.file}:{context.line} ({context.function})\n"
                f"{'=' * 60}"
            )
            for handler in logging.root.handlers:
                handler.flush()
        elif msg_type == QtMsgType.QtCriticalMsg:
            crash_logger.error(f"QT CRITICAL: {message}")
        elif msg_type == QtMsgType.QtWarningMsg:
            # Only log important Qt warnings, skip noisy ones
            if "white-space" not in message and "Cannot read property" not in message:
                logging.getLogger("Qt").warning(message)

    qInstallMessageHandler(_qt_message_handler)

    logger.info(
        f"Crash handlers installed — logs: {LOG_FILE} | crashes: {CRASH_LOG_FILE}"
    )


# ===================== SINGLE INSTANCE =====================

def _kill_previous_instance():
    """Kill any previously running instance using the lock file PID."""
    if not os.path.exists(LOCK_FILE):
        return

    try:
        with open(LOCK_FILE, "r") as f:
            old_pid = int(f.read().strip())

        # Check if the process is still running and kill it
        if old_pid != os.getpid():
            if sys.platform == "win32":
                import ctypes
                PROCESS_TERMINATE = 0x0001
                SYNCHRONIZE = 0x00100000
                kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
                kernel32.OpenProcess.restype = ctypes.c_void_p
                kernel32.TerminateProcess.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
                kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
                kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
                handle = kernel32.OpenProcess(PROCESS_TERMINATE | SYNCHRONIZE, 0, old_pid)
                if handle:
                    kernel32.TerminateProcess(handle, 0)
                    kernel32.WaitForSingleObject(handle, 1500)
                    kernel32.CloseHandle(handle)
                    logger.info(f"[Startup] Terminated previous instance (PID {old_pid})")
            else:
                os.kill(old_pid, signal.SIGTERM)
                logger.info(f"[Startup] Terminated previous instance (PID {old_pid})")
    except (ValueError, OSError, ProcessLookupError):
        pass  # Process already gone or invalid PID


def _write_lock():
    """Write current PID to lock file."""
    os.makedirs(os.path.dirname(LOCK_FILE), exist_ok=True)
    with open(LOCK_FILE, "w") as f:
        f.write(str(os.getpid()))


def _remove_lock():
    """Remove lock file on exit."""
    try:
        if os.path.exists(LOCK_FILE):
            with open(LOCK_FILE, "r") as f:
                pid = int(f.read().strip())
            if pid == os.getpid():
                os.remove(LOCK_FILE)
    except (ValueError, OSError):
        pass


def is_admin() -> bool:
    """Check if current process has Administrator / root privileges."""
    try:
        if sys.platform == "win32":
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        else:
            return os.geteuid() == 0
    except Exception:
        return False


def _recover_net_unblock():
    """Undo what a killed previous run left behind (hosts block, proxy script setting). Never raises."""
    try:
        from app.core.net_unblock.journal import recover_on_start
        recover_on_start()
    except Exception:
        logger.exception("[NetUnblock] Startup recovery failed")


def _restore_net_unblock() -> int:
    """`--net-restore`: remove every Network Unblock change and exit (needs Administrator)."""
    try:
        from app.core.net_unblock.manager import restore_all
        for message in restore_all():
            print(message)
        return 0
    except Exception as e:
        print(f"Network Unblock restore failed: {e}")
        return 1


# ===================== MAIN =====================

def main():
    """Application entry point."""
    # Install crash handlers FIRST — before anything else can fail
    _install_crash_handlers()

    if "--setup-deck" in sys.argv:
        try:
            from app.core.desktop_integration import run_deck_setup_cli
            sys.exit(run_deck_setup_cli(sys.argv))
        except Exception as e:
            logger.error(f"[Packaging/Deck] Failed to run deck setup CLI: {e}", exc_info=True)
            sys.exit(1)

    # Single instance: kill any previous instance
    _kill_previous_instance()
    _write_lock()

    import atexit
    atexit.register(_remove_lock)

    _recover_net_unblock()
    if "--net-restore" in sys.argv:
        sys.exit(_restore_net_unblock())

    if "--verify-native" in sys.argv:
        try:
            from app.core.remote.native_paths import verify_and_log_native_dlls
            paths = verify_and_log_native_dlls(stdout=True)
            for k, v in paths.items():
                print(f"[DLL] {k}: {v}")
            sys.exit(0)
        except Exception as e:
            print(f"[ERROR] verify_and_log_native_dlls failed: {e}")
            sys.exit(1)

    logger.info(f"App starting (PID {os.getpid()})")

    if is_admin():
        logger.info("[Security] Running with Administrator privileges (UIPI bypass active).")
    else:
        logger.warning(
            "[Security] Running WITHOUT Administrator privileges. "
            "Simulated keystrokes may be blocked by Windows UIPI when targeting elevated games."
        )

    # High DPI support
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("BobGaming.GameCenter")
        except Exception as e:
            logger.debug(f"[Win32] Could not set AppUserModelID: {e}")

    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationName("Bob Gaming Game Center")
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName("BobGaming")

    # Set Fusion style for consistent cross-platform rendering
    app.setStyle("Fusion")

    # Apply dark theme
    app.setStyleSheet(DARK_THEME)

    # Set default font
    font = QFont()
    if sys.platform == "win32":
        font.setFamily("Segoe UI")
    else:
        font.setFamilies(["Noto Sans", "DejaVu Sans", "Segoe UI", "sans-serif"])
    font.setPointSize(10)
    app.setFont(font)

    # Set app icon if available
    icon_path = os.path.join(app_dir, "assets", "icon.png")
    logo_path = os.path.join(app_dir, "assets", "logo.png")
    if os.path.exists(icon_path):
        app.setWindowIcon(QIcon(icon_path))
    elif os.path.exists(logo_path):
        app.setWindowIcon(QIcon(logo_path))

    # Create main window
    window = MainWindow()

    # Check if launched at startup / minimized
    start_minimized = "--minimized" in sys.argv or "--startup" in sys.argv
    if start_minimized:
        logger.info("Starting minimized (triggered by startup/minimized flag)")
        if not window.config.get("minimize_to_tray", True):
            window.showMinimized()
        else:
            window.hide()
    else:
        window.show()
        logger.info("Main window shown — entering event loop")

    sys.exit(app.exec())



if __name__ == "__main__":
    main()

