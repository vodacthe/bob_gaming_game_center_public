#!/usr/bin/env bash
# ==============================================================================
# Bob Game Center - SteamOS / Arch Linux Startup Wrapper
# Handles Wayland/Xcb display configuration, environment variables,
# virtual environment activation, in-place self-updates, and clean exit.
# ==============================================================================

set -uo pipefail

# --- 1. Canonical Script & Application Directory Resolution ---
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$(cd -P "$(dirname "$SOURCE")" && pwd)"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
RESOLVED_DIR="$(cd -P "$(dirname "$SOURCE")" && pwd)"

if [ -f "$RESOLVED_DIR/main.py" ]; then
    APP_DIR="$RESOLVED_DIR"
elif [ -f "$RESOLVED_DIR/../../main.py" ]; then
    APP_DIR="$(cd -P "$RESOLVED_DIR/../.." && pwd)"
else
    APP_DIR="${HOME}/Applications/BobGameCenter"
fi

cd "$APP_DIR"

# --- 2. P0 Logging Setup ---
TAG="[Launcher/Deck]"
LOG_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/BobGameCenter/logs"
LAUNCH_LOG="$LOG_DIR/launch.log"

mkdir -p "$LOG_DIR"

# Rotate log file if > 5 MB
if [ -f "$LAUNCH_LOG" ] && [ "$(stat -c%s "$LAUNCH_LOG" 2>/dev/null || stat -f%z "$LAUNCH_LOG" 2>/dev/null || echo 0)" -gt 5242880 ]; then
    mv -f "$LAUNCH_LOG" "$LAUNCH_LOG.1" 2>/dev/null || true
fi

log_entry() {
    local level="$1"; shift
    local msg="$*"
    local ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    echo "[$ts] [$level] $TAG $msg" | tee -a "$LAUNCH_LOG"
}

# --- 3. Mode & Compositor Detection ---
SESSION_MODE="DesktopMode"
if [ "${SteamDeck:-0}" = "1" ] || [ "${SteamTenfoot:-0}" = "1" ] || [ "${XDG_CURRENT_DESKTOP:-}" = "gamescope" ] || pgrep -x gamescope &>/dev/null; then
    SESSION_MODE="GameMode (gamescope)"
elif [ -n "${KDE_FULL_SESSION:-}" ] || [ "${XDG_CURRENT_DESKTOP:-}" = "KDE" ]; then
    SESSION_MODE="DesktopMode (KDE Plasma)"
fi

# --- 4. Environment Variables Configuration ---
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export PYTHONUNBUFFERED=1
export BOB_APP_DIR="$APP_DIR"
export BOB_WRAPPER_MANAGED=1

# Detect if launched from systemd/XDG autostart (wait for SteamOS Game Mode or Plasma display)
IS_AUTOSTART=0
for arg in "$@"; do
    if [ "$arg" = "--autostart" ] || [ "$arg" = "--startup" ]; then
        IS_AUTOSTART=1
        break
    fi
done

_probe_live_display() {
    # Pull DISPLAY / WAYLAND_DISPLAY from systemd user session environment if available
    if command -v systemctl &>/dev/null; then
        local sd_env
        sd_env="$(systemctl --user show-environment 2>/dev/null || true)"
        if [ -z "${DISPLAY:-}" ]; then
            local sd_disp
            sd_disp="$(printf '%s\n' "$sd_env" | sed -n 's/^DISPLAY=//p' | head -n1)"
            [ -n "$sd_disp" ] && export DISPLAY="$sd_disp"
        fi
        if [ -z "${WAYLAND_DISPLAY:-}" ]; then
            local sd_wl
            sd_wl="$(printf '%s\n' "$sd_env" | sed -n 's/^WAYLAND_DISPLAY=//p' | head -n1)"
            [ -n "$sd_wl" ] && export WAYLAND_DISPLAY="$sd_wl"
        fi
    fi

    # Check Wayland socket in XDG_RUNTIME_DIR (Plasma wayland-0 or SteamOS gamescope-0)
    if [ -n "${WAYLAND_DISPLAY:-}" ] && [ -S "$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY" ]; then
        return 0
    fi
    local sock
    for sock in "$XDG_RUNTIME_DIR"/wayland-* "$XDG_RUNTIME_DIR"/gamescope-*; do
        if [ -S "$sock" ]; then
            export WAYLAND_DISPLAY="$(basename "$sock")"
            return 0
        fi
    done

    # Check X11 / XWayland socket (/tmp/.X11-unix/X0, X1, ...)
    if [ -n "${DISPLAY:-}" ]; then
        local dnum="${DISPLAY#:}"
        dnum="${dnum%%.*}"
        if [ -S "/tmp/.X11-unix/X${dnum}" ]; then
            return 0
        fi
    fi
    for sock in /tmp/.X11-unix/X*; do
        if [ -S "$sock" ]; then
            export DISPLAY=":$(basename "$sock" | sed 's/^X//')"
            return 0
        fi
    done
    return 1
}

if [ "$IS_AUTOSTART" -eq 1 ]; then
    WAIT_SEC=0
    while [ "$WAIT_SEC" -lt 45 ]; do
        if _probe_live_display; then
            log_entry "INFO" "Autostart detected live display after ${WAIT_SEC}s (DISPLAY=${DISPLAY:-none}, WAYLAND_DISPLAY=${WAYLAND_DISPLAY:-none})"
            break
        fi
        sleep 1
        WAIT_SEC=$((WAIT_SEC + 1))
    done
    # Re-detect session mode after compositor comes up
    if [ "${SteamDeck:-0}" = "1" ] || [ "${SteamTenfoot:-0}" = "1" ] || [ "${XDG_CURRENT_DESKTOP:-}" = "gamescope" ] || pgrep -x gamescope &>/dev/null; then
        SESSION_MODE="GameMode (gamescope)"
    elif [ -n "${KDE_FULL_SESSION:-}" ] || [ "${XDG_CURRENT_DESKTOP:-}" = "KDE" ]; then
        SESSION_MODE="DesktopMode (KDE Plasma)"
    fi
else
    _probe_live_display || true
fi

export DISPLAY="${DISPLAY:-:0}"

# UTF-8 encoding guard
export LC_ALL="${LC_ALL:-C.UTF-8}"
export LANG="${LANG:-C.UTF-8}"

# Qt Platform Plugin: prefer xcb first for background GameMode autostart (avoids gamescope fullscreen hijack),
# otherwise try wayland first and fallback to xcb (XWayland)
if [ "$IS_AUTOSTART" -eq 1 ] && [ "$SESSION_MODE" = "GameMode (gamescope)" ]; then
    export QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-xcb;wayland}"
else
    export QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-wayland;xcb}"
fi

# Gamepad background event capture for PySDL2
export SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS=1
export SDL_JOYSTICK_RAWINPUT=0

# Add local bin to PATH for standalone 7zz / aria2c
chmod 755 "$APP_DIR/native/bin/linux"/* "$APP_DIR/bin"/* 2>/dev/null || true
export PATH="$APP_DIR/native/bin/linux:$APP_DIR/bin:$HOME/.local/bin:$PATH:$HOME/.local/share/flatpak/exports/bin:/var/lib/flatpak/exports/bin"

# --- 5. Virtual Environment Python Selection ---
VENV_PYTHON="$APP_DIR/venv/bin/python"
if [ -x "$VENV_PYTHON" ]; then
    PYTHON_EXEC="$VENV_PYTHON"
    PY_SOURCE="venv"
else
    PYTHON_EXEC="$(command -v python3 || echo "python3")"
    PY_SOURCE="system"
fi

APP_VER="$(sed -n 's/^APP_VERSION *= *"\([^"]*\)".*/\1/p' "$APP_DIR/app/version.py" 2>/dev/null | head -n1)"
APP_VER="${APP_VER:-unknown}"

START_TIME=$(date +%s)
log_entry "INFO" "Starting Bob Game Center..."
log_entry "INFO" "Version: $APP_VER | Mode: $SESSION_MODE | WorkDir: $APP_DIR"
log_entry "INFO" "Python: $PYTHON_EXEC ($PY_SOURCE) | QT_QPA_PLATFORM: $QT_QPA_PLATFORM | DISPLAY: $DISPLAY"
[ -n "${WAYLAND_DISPLAY:-}" ] && log_entry "INFO" "WAYLAND_DISPLAY: $WAYLAND_DISPLAY"

# --- 6. Process Execution & Signal Forwarding ---
"$PYTHON_EXEC" "$APP_DIR/main.py" "$@" &
APP_PID=$!
log_entry "INFO" "Launched main process PID: $APP_PID"

# Trap termination signals and forward to Python process
forward_signal() {
    local sig="$1"
    log_entry "WARNING" "Received signal $sig, forwarding to PID $APP_PID..."
    kill "-$sig" "$APP_PID" 2>/dev/null || true
}

trap 'forward_signal SIGTERM' SIGTERM
trap 'forward_signal SIGINT' SIGINT
trap 'forward_signal SIGHUP' SIGHUP

# Wait for application exit
wait "$APP_PID"
EXIT_CODE=$?

END_TIME=$(date +%s)
DURATION=$((END_TIME - START_TIME))

if [ "$EXIT_CODE" -eq 0 ]; then
    log_entry "INFO" "Bob Game Center (PID $APP_PID) exited normally (code 0) after ${DURATION}s."
else
    log_entry "ERROR" "Bob Game Center (PID $APP_PID) exited with error code $EXIT_CODE after ${DURATION}s."
fi

# --- 7. In-Place Self-Update Application (Game Mode & Desktop Mode Safe) ---
PENDING_TAR="$APP_DIR/.bob_pending_update.tar.gz"
if [ -f "$PENDING_TAR" ]; then
    UPD_START=$(date +%s)
    log_entry "INFO" "Pending self-update package found ($PENDING_TAR). Applying in-place..."
    STAGE_DIR="$APP_DIR/.bob_update_staging"
    rm -rf "$STAGE_DIR"
    mkdir -p "$STAGE_DIR"

    OLD_REQ_HASH=""
    [ -f "$APP_DIR/requirements.txt" ] && OLD_REQ_HASH="$(sha256sum "$APP_DIR/requirements.txt" 2>/dev/null | awk '{print $1}')"

    if tar -xzf "$PENDING_TAR" -C "$STAGE_DIR" && [ -s "$STAGE_DIR/main.py" ] && [ -s "$STAGE_DIR/scripts/deck/bob_game_center.sh" ]; then
        rm -f "$PENDING_TAR"
        if command -v rsync &>/dev/null; then
            rsync -a --delete \
                --exclude 'venv' \
                --exclude '.bob_update_staging' \
                --exclude '.bob_pending_update.tar.gz*' \
                "$STAGE_DIR/" "$APP_DIR/"
        else
            cp -rf "$STAGE_DIR"/. "$APP_DIR/"
        fi
        rm -rf "$STAGE_DIR"

        chmod 755 "$APP_DIR/scripts/deck"/*.sh "$APP_DIR/native/bin/linux"/* "$APP_DIR/bin"/* 2>/dev/null || true
        ln -sf "$APP_DIR/scripts/deck/bob_game_center.sh" "$APP_DIR/bob_game_center.sh"
        if [ -x "$APP_DIR/native/bin/linux/aria2c" ]; then
            mkdir -p "$APP_DIR/bin" "$HOME/.local/bin"
            ln -sf "$APP_DIR/native/bin/linux/aria2c" "$APP_DIR/bin/aria2c"
            ln -sf "$APP_DIR/native/bin/linux/aria2c" "$HOME/.local/bin/aria2c"
        fi

        NEW_REQ_HASH=""
        [ -f "$APP_DIR/requirements.txt" ] && NEW_REQ_HASH="$(sha256sum "$APP_DIR/requirements.txt" 2>/dev/null | awk '{print $1}')"
        if [ -n "$NEW_REQ_HASH" ] && [ "$OLD_REQ_HASH" != "$NEW_REQ_HASH" ] && [ -x "$APP_DIR/venv/bin/pip" ]; then
            log_entry "INFO" "requirements.txt changed; updating Python dependencies..."
            "$APP_DIR/venv/bin/pip" install --prefer-binary -r "$APP_DIR/requirements.txt" >>"$LAUNCH_LOG" 2>&1 || \
                log_entry "WARNING" "pip install returned non-zero during self-update; continuing with existing packages."
        fi

        UPD_DUR=$(($(date +%s) - UPD_START))
        log_entry "INFO" "Self-update applied in ${UPD_DUR}s. Reloading launcher in-place (PID $$)..."
        exec "$APP_DIR/bob_game_center.sh" "$@"
    else
        log_entry "ERROR" "Failed to extract pending self-update archive; discarding package."
        rm -rf "$STAGE_DIR" "$PENDING_TAR"
    fi
fi

exit "$EXIT_CODE"
