#!/usr/bin/env python3
"""
scripts/deck/deploy_deck.py - Automated Steam Deck Deployment & Live Verification Tool.

Packages Bob Game Center, transfers it to Steam Deck over SSH/SFTP, executes user-space
installation, and verifies application readiness for Desktop Mode and Game Mode.
Adheres strictly to P0 logging, security, and immutability invariants.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
from pathlib import Path
import stat
import sys
import tarfile
import time
from typing import Any, Callable, Optional

# Enforce UTF-8 encoding for console output on Windows
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# --- P0 Logging Setup ---
TAG = "[Deployment/Deck]"
logger = logging.getLogger("Deployment.Deck")


# --- Packaging Rules ---
EXCLUDE_DIR_PATTERNS = {
    ".git",
    ".agents",
    ".claude",
    ".gemini",
    ".vscode",
    ".idea",
    "venv",
    ".venv",
    "env",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    "build",
    "dist",
    "htmlcov",
    ".coverage",
}

EXCLUDE_ROOT_DIRS = {
    "tests",
    "tools",
    "hooks",
    "streaming-technical",
    "downloads",
    "online_fix",
}

EXCLUDE_EXTENSIONS = {
    ".pyc",
    ".pyo",
    ".pyd",
    ".tmp",
    ".bak",
    ".log",
    ".spec",
    ".dll",
    ".exe",
    ".ps1",
    ".def",
}

EXCLUDE_RELATIVE_PREFIXES = (
    "native/bin/x64",
    "native\\bin\\x64",
    "native/third_party",
    "native/moonlight-common-c",
    "native/shim",
    "native/ffmpeg_layout",
    "native/build",
    "native/CMakeLists.txt",
    "native/VERSIONS.md",
)

EXCLUDE_ROOT_FILES = {
    "config.json",
    "dht.dat",
    "build.py",
    "ruff.toml",
    ".gitignore",
    ".gitattributes",
}


def find_default_key_file() -> Optional[str]:
    """Auto-detect user's private SSH key in standard locations."""
    candidates = [
        os.path.expanduser("~/.ssh/id_ed25519_deck_claude"),
        os.path.expanduser("~/.ssh/id_ed25519"),
        os.path.expanduser("~/.ssh/id_rsa"),
    ]
    for candidate in candidates:
        if os.path.isfile(candidate):
            return candidate
    return None


def should_exclude_path(rel_path: str) -> bool:
    """Determine whether a relative file/directory path should be excluded from package."""
    # Normalize separators
    norm = rel_path.replace("\\", "/").strip("/")
    parts = norm.split("/")

    for part in parts:
        if part in EXCLUDE_DIR_PATTERNS:
            return True

    if parts and parts[0] in EXCLUDE_ROOT_DIRS:
        return True

    if len(parts) == 1:
        lower_root = parts[0].lower()
        if lower_root in EXCLUDE_ROOT_FILES:
            return True
        if lower_root.endswith(".md") and lower_root not in {"readme.md", "third_party_notices.md"}:
            return True

    for prefix in EXCLUDE_RELATIVE_PREFIXES:
        if norm.startswith(prefix.replace("\\", "/")):
            return True

    _, ext = os.path.splitext(norm)
    if ext.lower() in EXCLUDE_EXTENSIONS:
        return True

    return False


def build_deck_tarball(
    source_dir: str | Path,
    output_tar: str | Path,
    progress_callback: Optional[Callable[[str], None]] = None,
) -> Path:
    """
    Package Bob Game Center into a POSIX-normalized .tar.gz archive.
    Enforces deck:deck ownership and 0o755 executable bits on scripts.
    """
    start_time = time.monotonic()
    source_path = Path(source_dir).resolve()
    output_path = Path(output_tar).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    logger.info(f"{TAG} Creating deployment bundle from {source_path} to {output_path}...")
    file_count = 0

    def tar_filter(tarinfo: tarfile.TarInfo) -> Optional[tarfile.TarInfo]:
        nonlocal file_count
        rel_path = tarinfo.name

        if should_exclude_path(rel_path):
            return None

        # Normalize ownership to SteamOS user deck
        tarinfo.uname = "deck"
        tarinfo.gname = "deck"
        tarinfo.uid = 1000
        tarinfo.gid = 1000

        # Normalize POSIX permissions
        norm_name = tarinfo.name.replace("\\", "/").lower()
        is_executable = (
            norm_name.endswith(".sh")
            or norm_name.endswith(".py")
            or "/bin/" in norm_name
            or norm_name.endswith("/aria2c")
            or norm_name == "aria2c"
            or norm_name.endswith("/7zz")
            or norm_name == "7zz"
            or norm_name.endswith("/7z")
            or norm_name == "7z"
        )
        if tarinfo.isdir():
            tarinfo.mode = 0o755
        elif is_executable:
            tarinfo.mode = 0o755
        else:
            tarinfo.mode = 0o644

        file_count += 1
        return tarinfo

    with tarfile.open(output_path, "w:gz") as tar:
        for item in source_path.iterdir():
            if item.name in EXCLUDE_DIR_PATTERNS:
                continue
            tar.add(item, arcname=item.name, filter=tar_filter)

    duration = time.monotonic() - start_time
    size_mb = output_path.stat().st_size / (1024 * 1024)
    logger.info(
        f"{TAG} Package created: {output_path.name} ({size_mb:.2f} MB, "
        f"{file_count} entries) in {duration:.2f}s"
    )
    if progress_callback:
        progress_callback(f"Bundle built: {size_mb:.2f} MB in {duration:.2f}s")

    return output_path


# --- Remote Verifier Script (Embedded One-Shot Probe) ---
REMOTE_PROBE_SCRIPT = r"""
import json, os, subprocess, sys

def run_probe(app_dir="/home/deck/Applications/BobGameCenter", steam_dir="/home/deck/.local/share/Steam"):
    res = {"status": "PASS", "checks": {}, "errors": []}

    # 1. App directory & runner script
    app_exists = os.path.isdir(app_dir)
    res["checks"]["app_directory"] = {"passed": app_exists, "path": app_dir}
    if not app_exists:
        res["errors"].append(f"Application directory missing: {app_dir}")

    runner_path = os.path.join(app_dir, "bob_game_center.sh")
    runner_ok = os.path.isfile(runner_path) and os.access(runner_path, os.X_OK)
    res["checks"]["runner_executable"] = {"passed": runner_ok, "path": runner_path}
    if not runner_ok:
        res["errors"].append(f"Runner script missing or not executable: {runner_path}")

    # 2. Virtual environment interpreter & import checks
    venv_python = os.path.join(app_dir, "venv", "bin", "python")
    venv_exists = os.path.isfile(venv_python) and os.access(venv_python, os.X_OK)
    module_imports_ok = False
    import_details = {}

    if venv_exists:
        try:
            cmd = [
                venv_python, "-c",
                "import app.core.steam_manager; import app.core.online_fix.runner; print('IMPORTS_OK')"
            ]
            env = os.environ.copy()
            env["PYTHONPATH"] = app_dir
            out = subprocess.check_output(cmd, env=env, text=True, stderr=subprocess.STDOUT).strip()
            module_imports_ok = "IMPORTS_OK" in out
            import_details["output"] = out
        except subprocess.CalledProcessError as exc:
            module_imports_ok = False
            import_details["error"] = str(exc)
            import_details["output"] = exc.output
            res["errors"].append(f"Module import failed: {exc} | Output: {exc.output}")
        except Exception as exc:
            module_imports_ok = False
            import_details["error"] = str(exc)
            res["errors"].append(f"Module import failed: {exc}")
    else:
        res["errors"].append(f"Virtualenv python missing: {venv_python}")

    res["checks"]["venv"] = {
        "passed": venv_exists and module_imports_ok,
        "python": venv_python,
        "imports_ok": module_imports_ok,
        "details": import_details
    }

    # 3. Desktop Mode .desktop entry
    desktop_file = os.path.expanduser("~/.local/share/applications/bob_game_center.desktop")
    desktop_ok = False
    if os.path.isfile(desktop_file):
        try:
            with open(desktop_file, "r", encoding="utf-8") as f:
                c = f.read()
            desktop_ok = "bob_game_center.sh" in c and "[Desktop Entry]" in c
        except Exception:
            desktop_ok = False

    res["checks"]["desktop_entry"] = {"passed": desktop_ok, "path": desktop_file}
    if not desktop_ok:
        res["errors"].append(f"Desktop launcher invalid or missing: {desktop_file}")

    # 4. Steam Shortcuts registration
    steam_ok = False
    found_users = []
    if os.path.isdir(steam_dir):
        userdata = os.path.join(steam_dir, "userdata")
        if os.path.isdir(userdata):
            for u in os.listdir(userdata):
                if u.isdigit() and u != "0":
                    found_users.append(u)
                    vdf = os.path.join(userdata, u, "config", "shortcuts.vdf")
                    if os.path.isfile(vdf):
                        try:
                            with open(vdf, "rb") as vf:
                                vdata = vf.read()
                            if b"Bob Game Center" in vdata or b"bob_game_center.sh" in vdata:
                                steam_ok = True
                        except Exception:
                            pass

    res["checks"]["steam_shortcuts"] = {
        "passed": steam_ok,
        "users": found_users
    }
    # 5. External binary resolution (aria2c and 7z)
    aria2_found = False
    aria2_path = None
    aria2_version = None
    sevenz_found = False
    sevenz_path = None

    if venv_exists:
        try:
            probe_code = (
                "import os, sys; "
                "from app.core.binary_finder import find_aria2c, find_7z; "
                "a = find_aria2c() or ''; "
                "s = find_7z() or ''; "
                "print(f'ARIA2:{a}'); "
                "print(f'7Z:{s}')"
            )
            cmd = [venv_python, "-c", probe_code]
            env = os.environ.copy()
            env["PYTHONPATH"] = app_dir
            out = subprocess.check_output(cmd, env=env, text=True, stderr=subprocess.STDOUT)
            for line in out.splitlines():
                if line.startswith("ARIA2:"):
                    aria2_path = line[6:].strip() or None
                elif line.startswith("7Z:"):
                    sevenz_path = line[3:].strip() or None
        except Exception as exc:
            res["errors"].append(f"Failed to query binary_finder via python: {exc}")

    if aria2_path and os.path.isfile(aria2_path) and os.access(aria2_path, os.X_OK):
        try:
            vout = subprocess.check_output([aria2_path, "--version"], text=True, stderr=subprocess.STDOUT)
            first_line = vout.splitlines()[0] if vout else ""
            if "aria2" in first_line:
                aria2_found = True
                aria2_version = first_line
        except Exception as exc:
            res["errors"].append(f"aria2c execution failed: {exc}")
    else:
        res["errors"].append(f"aria2c binary missing or not executable (resolved path: {aria2_path})")

    if sevenz_path and os.path.isfile(sevenz_path) and os.access(sevenz_path, os.X_OK):
        sevenz_found = True
    else:
        res["errors"].append(f"7z/7zz binary missing or not executable (resolved path: {sevenz_path})")

    res["checks"]["binary_resolution"] = {
        "passed": aria2_found and sevenz_found,
        "aria2c": {"passed": aria2_found, "path": aria2_path, "version": aria2_version},
        "7z": {"passed": sevenz_found, "path": sevenz_path},
    }

    if res["errors"]:
        res["status"] = "FAIL"

    return res

t_dir = sys.argv[1] if len(sys.argv) > 1 else "/home/deck/Applications/BobGameCenter"
report = run_probe(app_dir=t_dir)
print(json.dumps(report))
sys.exit(0 if report["status"] == "PASS" else 1)
"""


class DeckDeployer:
    """Manages SSH connection, SFTP file transfer, execution, and verification on Steam Deck."""

    def __init__(
        self,
        host: str = "192.168.1.24",
        user: str = "deck",
        port: int = 22,
        key_file: Optional[str] = None,
        password: Optional[str] = None,
        target_dir: str = "/home/deck/Applications/BobGameCenter",
        timeout: float = 15.0,
        dry_run: bool = False,
        close_steam: bool = False,
    ):
        self.host = host
        self.user = user
        self.port = port
        self.key_file = key_file or find_default_key_file()
        self.password = password
        self.target_dir = target_dir
        self.timeout = timeout
        self.dry_run = dry_run
        self.close_steam = close_steam
        self._ssh_client: Any = None

    def connect(self) -> Any:
        """Establish SSH connection using key or password authentication."""
        if self.dry_run:
            logger.info(f"{TAG} [DRY-RUN] Would connect to {self.user}@{self.host}:{self.port}")
            return None

        if self._ssh_client is not None:
            return self._ssh_client

        try:
            import paramiko
        except ImportError:
            logger.error(f"{TAG} paramiko library is required for Deck deployment.")
            raise

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        auth_method = "unknown"
        start_time = time.monotonic()

        # Dual authentication strategy: Key-based first, password fallback
        connect_exc: Optional[Exception] = None

        if self.key_file and os.path.isfile(self.key_file):
            try:
                logger.info(f"{TAG} Attempting SSH key connection using {self.key_file}...")
                client.connect(
                    hostname=self.host,
                    port=self.port,
                    username=self.user,
                    key_filename=self.key_file,
                    timeout=self.timeout,
                    look_for_keys=False,
                    allow_agent=True,
                )
                auth_method = "publickey"
            except (paramiko.AuthenticationException, paramiko.SSHException) as exc:
                logger.warning(f"{TAG} Key authentication failed: {exc}. Trying password if available...")
                connect_exc = exc

        if auth_method == "unknown" and self.password:
            try:
                logger.info(f"{TAG} Attempting password authentication...")
                client.connect(
                    hostname=self.host,
                    port=self.port,
                    username=self.user,
                    password=self.password,
                    timeout=self.timeout,
                    look_for_keys=False,
                    allow_agent=False,
                )
                auth_method = "password"
            except Exception as exc:
                connect_exc = exc

        if auth_method == "unknown":
            err_msg = f"Failed to authenticate with {self.user}@{self.host}:{self.port}"
            if connect_exc:
                err_msg += f": {connect_exc}"
            logger.error(f"{TAG} {err_msg}")
            raise paramiko.AuthenticationException(err_msg)

        elapsed = time.monotonic() - start_time
        logger.info(f"{TAG} Connected to {self.user}@{self.host} via {auth_method} in {elapsed:.2f}s")
        self._ssh_client = client
        return client

    def close(self) -> None:
        """Close SSH connection."""
        if self._ssh_client is not None:
            try:
                self._ssh_client.close()
            except Exception:
                pass
            self._ssh_client = None

    def exec_command(
        self,
        cmd: str,
        timeout: float = 120.0,
        stream: bool = False,
    ) -> tuple[int, str, str]:
        """Execute command on remote Steam Deck, optionally streaming output."""
        if self.dry_run:
            logger.info(f"{TAG} [DRY-RUN] Executing: {cmd}")
            return (0, "[DRY-RUN OUTPUT]", "")

        client = self.connect()
        start_time = time.monotonic()

        stdin, stdout, stderr = client.exec_command(cmd, timeout=timeout, get_pty=stream)
        stdout_chunks: list[str] = []
        stderr_chunks: list[str] = []

        if stream:
            for line in iter(stdout.readline, ""):
                stdout_chunks.append(line)
                try:
                    sys.stdout.write(line)
                    sys.stdout.flush()
                except UnicodeEncodeError:
                    # Fallback for Windows consoles with non-UTF8 code pages
                    safe_line = line.encode(sys.stdout.encoding or "utf-8", errors="replace").decode(
                        sys.stdout.encoding or "utf-8", errors="replace"
                    )
                    sys.stdout.write(safe_line)
                    sys.stdout.flush()
                except Exception:
                    pass
        else:
            stdout_str = stdout.read().decode("utf-8", errors="replace")
            stderr_str = stderr.read().decode("utf-8", errors="replace")
            stdout_chunks.append(stdout_str)
            stderr_chunks.append(stderr_str)

        exit_code = stdout.channel.recv_exit_status()
        duration = time.monotonic() - start_time

        out_full = "".join(stdout_chunks)
        err_full = "".join(stderr_chunks)

        if exit_code != 0:
            logger.warning(
                f"{TAG} Command exited with code {exit_code} in {duration:.2f}s: {cmd[:60]}..."
            )
        else:
            logger.info(f"{TAG} Command succeeded in {duration:.2f}s: {cmd[:60]}...")

        return (exit_code, out_full, err_full)

    def preflight_check(self) -> dict[str, Any]:
        """Verify reachability, target OS architecture, disk space, and Steam status."""
        logger.info(f"{TAG} Running pre-flight probe on {self.host}...")
        start_time = time.monotonic()

        if self.dry_run:
            return {"status": "PASS", "arch": "x86_64", "free_mb": 50000, "steam_running": False}

        # Probe OS and user
        code, out, _ = self.exec_command("whoami; uname -s; uname -m")
        if code != 0:
            raise RuntimeError(f"Pre-flight probe failed with exit code {code}")

        lines = [line.strip() for line in out.strip().splitlines() if line.strip()]
        remote_user = lines[0] if len(lines) > 0 else "unknown"
        remote_sys = lines[1] if len(lines) > 1 else "unknown"
        remote_arch = lines[2] if len(lines) > 2 else "unknown"

        if remote_sys.lower() != "linux" or remote_arch != "x86_64":
            raise RuntimeError(f"Unsupported remote system: {remote_sys} {remote_arch}. Required: Linux x86_64")

        # Probe free space on /home
        code, out_df, _ = self.exec_command("df -Pk /home | awk 'NR==2 {print $4}'")
        try:
            free_kb = int(out_df.strip())
            free_mb = free_kb // 1024
        except ValueError:
            free_mb = 1024  # Fallback if awk parsing differed

        if free_mb < 500:
            raise RuntimeError(
                f"Insufficient disk space on /home/deck. Required: 500 MB, Available: {free_mb} MB"
            )

        # Probe Steam client process
        code_steam, _, _ = self.exec_command("pgrep -x steam || true")
        steam_running = code_steam == 0

        if steam_running:
            if self.close_steam:
                logger.info(f"{TAG} Steam is running. Performing graceful shutdown (steam -shutdown)...")
                self.exec_command("steam -shutdown || pkill -x steam || true")
                time.sleep(2.0)
            else:
                logger.info(
                    f"{TAG} Steam is currently running. Shortcuts will be registered on disk "
                    "and visible upon Steam restart."
                )

        duration = time.monotonic() - start_time
        logger.info(
            f"{TAG} Pre-flight passed in {duration:.2f}s: User={remote_user}, OS={remote_sys} {remote_arch}, "
            f"FreeSpace={free_mb}MB, SteamRunning={steam_running}"
        )
        return {
            "status": "PASS",
            "user": remote_user,
            "os": remote_sys,
            "arch": remote_arch,
            "free_mb": free_mb,
            "steam_running": steam_running,
        }

    def upload_bundle(
        self,
        local_bundle: str | Path,
        remote_path: str = "/home/deck/bob_game_center_deploy.tar.gz",
    ) -> bool:
        """Transfer deployment tarball to target Deck via SFTP."""
        start_time = time.monotonic()
        local_p = Path(local_bundle)
        total_size = local_p.stat().st_size
        logger.info(f"{TAG} Uploading {local_p.name} ({total_size / (1024*1024):.2f} MB) to {remote_path}...")

        if self.dry_run:
            logger.info(f"{TAG} [DRY-RUN] Upload complete.")
            return True

        client = self.connect()
        sftp = client.open_sftp()
        try:
            last_logged_milestone = -1

            def sftp_callback(transferred: int, total: int) -> None:
                nonlocal last_logged_milestone
                if total <= 0:
                    return
                pct = int((transferred / total) * 100)
                # Log milestones every 25% per P0 rules
                milestone = pct // 25
                if milestone > last_logged_milestone:
                    last_logged_milestone = milestone
                    logger.info(f"{TAG} Upload progress: {pct}% ({transferred}/{total} bytes)")

            sftp.put(str(local_p), remote_path, callback=sftp_callback)
        finally:
            sftp.close()

        duration = time.monotonic() - start_time
        logger.info(f"{TAG} Upload complete in {duration:.2f}s")
        return True

    def extract_bundle(
        self,
        remote_path: str = "/home/deck/bob_game_center_deploy.tar.gz",
        clean: bool = False,
    ) -> bool:
        """Extract tarball directly into target application directory."""
        start_time = time.monotonic()
        logger.info(f"{TAG} Extracting bundle to {self.target_dir} (clean={clean})...")

        clean_cmd = f"rm -rf '{self.target_dir}' && " if clean else ""
        extract_cmd = (
            f"{clean_cmd}mkdir -p '{self.target_dir}' && "
            f"tar -xzf '{remote_path}' -C '{self.target_dir}/' && "
            f"rm -f '{remote_path}'"
        )

        code, out, err = self.exec_command(extract_cmd)
        if code != 0:
            logger.error(f"{TAG} Failed to extract bundle: {err or out}")
            return False

        duration = time.monotonic() - start_time
        logger.info(f"{TAG} Bundle extracted successfully in {duration:.2f}s")
        return True

    def run_installer(self) -> bool:
        """Invoke install_deck.sh on Steam Deck to bootstrap venv and shortcuts."""
        start_time = time.monotonic()
        install_script = f"{self.target_dir}/scripts/deck/install_deck.sh"
        cmd = f"bash '{install_script}'"

        logger.info(f"{TAG} Invoking installer: {cmd}...")
        code, out, err = self.exec_command(cmd, timeout=300.0, stream=True)
        duration = time.monotonic() - start_time

        if code != 0:
            logger.error(f"{TAG} Installer failed with exit code {code} in {duration:.2f}s")
            return False

        logger.info(f"{TAG} Installer completed successfully in {duration:.2f}s")
        return True

    def verify_deployment(self) -> dict[str, Any]:
        """Run remote probe script and return verification dictionary."""
        start_time = time.monotonic()
        logger.info(f"{TAG} Running remote verification probe on target...")

        if self.dry_run:
            return {"status": "PASS", "checks": {"dry_run": True}, "errors": []}

        import base64
        b64 = base64.b64encode(REMOTE_PROBE_SCRIPT.encode("utf-8")).decode("ascii")
        probe_cmd = f"python3 -c \"import base64; exec(base64.b64decode('{b64}').decode('utf-8'))\" '{self.target_dir}'"
        code, out, err = self.exec_command(probe_cmd, timeout=30.0)
        duration = time.monotonic() - start_time

        try:
            # Parse the JSON output from remote stdout
            report = json.loads(out.strip())
        except Exception as exc:
            logger.error(f"{TAG} Failed to parse verification JSON output: {exc}. Raw: {out}")
            report = {
                "status": "FAIL",
                "checks": {},
                "errors": [f"Malformed probe output: {exc}", out],
            }

        logger.info(
            f"{TAG} Verification status: {report.get('status')} in {duration:.2f}s "
            f"({len(report.get('errors', []))} errors)"
        )
        return report

    def terminate_running_instances(self) -> None:
        """Terminate any existing Bob Game Center instances running on Steam Deck."""
        logger.info(f"{TAG} Terminating any running Bob Game Center instances on target...")
        term_cmd = (
            "pkill -TERM -f 'bob_game_center.sh' 2>/dev/null || true; "
            "pkill -TERM -f 'main.py' 2>/dev/null || true; "
            "sleep 1.5; "
            "pkill -KILL -f 'main.py' 2>/dev/null || true"
        )
        code, out, err = self.exec_command(term_cmd, timeout=10.0)
        logger.info(f"{TAG} Process termination completed (exit code {code})")

    def deploy(
        self,
        source_dir: str | Path,
        bundle_only: bool = False,
        upload_only: bool = False,
        verify_only: bool = False,
        clean: bool = False,
    ) -> bool:
        """Run complete deployment pipeline."""
        total_start = time.monotonic()

        try:
            # Mode: Verify Only
            if verify_only:
                self.connect()
                rep = self.verify_deployment()
                self.close()
                if rep.get("status") != "PASS":
                    for err in rep.get("errors", []):
                        logger.error(f"{TAG} Verification failure: {err}")
                else:
                    logger.info(f"{TAG} All remote verification checks PASSED!")
                return rep.get("status") == "PASS"

            dist_tar = Path(source_dir) / "dist" / "bob_game_center_deck.tar.gz"
            if bundle_only:
                build_deck_tarball(source_dir, dist_tar)
                logger.info(f"{TAG} Bundle-only mode complete. Archive: {dist_tar}")
                return True

            # Step 1: Pre-flight check
            self.preflight_check()

            # Terminate running instances before updating files
            self.terminate_running_instances()

            # Step 2: Build local tarball
            build_deck_tarball(source_dir, dist_tar)

            # Step 3: SFTP Upload
            remote_tar = "/home/deck/bob_game_center_deploy.tar.gz"
            self.upload_bundle(dist_tar, remote_tar)

            if upload_only:
                logger.info(f"{TAG} Upload-only mode complete.")
                self.close()
                return True

            # Step 4: Remote Extract
            if not self.extract_bundle(remote_tar, clean=clean):
                self.close()
                return False

            # Step 5: Remote Install
            if not self.run_installer():
                self.close()
                return False

            # Step 6: Remote Verification
            report = self.verify_deployment()
            self.close()

            total_duration = time.monotonic() - total_start
            passed = report.get("status") == "PASS"

            if passed:
                logger.info(f"{TAG} Full deployment and verification SUCCEEDED in {total_duration:.2f}s!")
            else:
                logger.error(
                    f"{TAG} Deployment finished with verification failures in {total_duration:.2f}s: "
                    f"{report.get('errors')}"
                )

            return passed

        except Exception as exc:
            total_duration = time.monotonic() - total_start
            logger.error(f"{TAG} Deployment failed after {total_duration:.2f}s: {exc}", exc_info=True)
            self.close()
            return False


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Bob Game Center - Automated Steam Deck Deployment & Verification CLI",
        allow_abbrev=False,
    )
    parser.add_argument(
        "--host",
        default=os.environ.get("DECK_HOST", "192.168.1.24"),
        help="Steam Deck IP address or hostname (default: %(default)s)",
    )
    parser.add_argument(
        "--user",
        default=os.environ.get("DECK_USER", "deck"),
        help="Remote SSH username (default: %(default)s)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("DECK_PORT", "22")),
        help="SSH port (default: %(default)s)",
    )
    parser.add_argument(
        "--key-file",
        default=None,
        help="Path to private SSH key (default: auto-detected from ~/.ssh/)",
    )
    parser.add_argument(
        "--password-env",
        default="DECK_PASSWORD",
        help="Environment variable name containing Deck password (default: %(default)s)",
    )
    parser.add_argument(
        "--target-dir",
        default="/home/deck/Applications/BobGameCenter",
        help="Remote deployment destination directory (default: %(default)s)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate actions without modifying disk or connecting over SSH",
    )
    parser.add_argument(
        "--bundle-only",
        action="store_true",
        help="Package tarball locally only without uploading",
    )
    parser.add_argument(
        "--upload-only",
        action="store_true",
        help="Upload tarball to Steam Deck without extracting or installing",
    )
    parser.add_argument(
        "--verify-only",
        action="store_true",
        help="Run remote verification probe on Steam Deck without deploying",
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="Remove existing target directory before extracting",
    )
    parser.add_argument(
        "--close-steam",
        action="store_true",
        help="Gracefully shut down Steam on target before updating shortcuts",
    )
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    args = parse_args(argv)

    # Resolve password securely from environment variable (never log or hardcode)
    password = os.environ.get(args.password_env) or os.environ.get("SSHPASS")

    root_dir = Path(__file__).resolve().parent.parent.parent

    deployer = DeckDeployer(
        host=args.host,
        user=args.user,
        port=args.port,
        key_file=args.key_file,
        password=password,
        target_dir=args.target_dir,
        dry_run=args.dry_run,
        close_steam=args.close_steam,
    )

    success = deployer.deploy(
        source_dir=root_dir,
        bundle_only=args.bundle_only,
        upload_only=args.upload_only,
        verify_only=args.verify_only,
        clean=args.clean,
    )

    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
