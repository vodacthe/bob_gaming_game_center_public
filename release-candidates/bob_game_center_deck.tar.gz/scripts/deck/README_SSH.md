# Steam Deck Installation & SSH Remote Deployment Guide

> **Quick End-User Install (No SSH Needed)**:
> End users on Steam Deck Desktop Mode can open **Konsole** and install the latest published release in one command:
> ```bash
> curl -fsSL https://raw.githubusercontent.com/vodacthe/bob_gaming_game_center_public/main/install.sh | bash
> ```
> Future updates are delivered automatically inside Bob Game Center via `UpdateDialog`.

This guide explains how to enable SSH (Secure Shell) on your Steam Deck to allow remote deployment, debugging, and management of **Bob Game Center** from your PC (Windows, macOS, or Linux).

---

## 1. Prerequisites

1. **Same Local Network**: Ensure your Steam Deck and your host PC are connected to the same Wi-Fi network or local subnet.
2. **Peripherals (Optional)**: A physical keyboard, Bluetooth keyboard, or USB-C dock is helpful, but the on-screen virtual keyboard (`STEAM` + `X`) works as well.

> **P0 Security Notice**: Never share your Steam Deck password or private keys in public repositories or logs. This guide uses placeholders `<deck-ip>` and `<password>`. Replace them with your actual values when executing commands.

---

## 2. Step-by-Step Steam Deck Setup

### Step 1: Switch to Desktop Mode
1. On your Steam Deck, press the **STEAM** button (or hold the physical Power button).
2. Select **Power** -> **Switch to Desktop**.
3. Wait for the KDE Plasma desktop to appear.

### Step 2: Open Konsole (Terminal)
1. Click the **Application Launcher** icon in the bottom-left corner of the taskbar.
2. Navigate to **System** -> click **Konsole**.
3. (If using handheld mode without a physical keyboard, press `STEAM` + `X` to summon the virtual keyboard).

### Step 3: Set a Password for User `deck`
By default, SteamOS ships with no password set for user `deck`. A password is required to execute `sudo` administrative commands and authenticate over SSH.

1. In Konsole, type:
   ```bash
   passwd
   ```
2. Enter your new password when prompted:
   ```text
   New password: <password>
   Retype new password: <password>
   ```
   *(Note: Linux terminals do not echo characters or asterisks while typing passwords for security).*
3. When successful, the terminal will confirm:
   ```text
   passwd: password updated successfully
   ```

### Step 4: Enable and Start the SSH Service
SteamOS includes OpenSSH by default. Enable and start the systemd SSH service with:

```bash
sudo systemctl enable --now sshd
```

When prompted for `[sudo] password for deck:`, enter the `<password>` configured in Step 3.

> **Note on SteamOS Immutable Rootfs**:
> You do **not** need to disable `steamos-readonly`. Enabling systemd services writes to `/etc/systemd/system/`, which resides in the persistent writable overlay and survives SteamOS system updates.

Verify that the service is running:
```bash
systemctl status sshd
```
Expected output:
```text
Active: active (running)
```

### Step 5: Find Your Steam Deck's IP Address

#### Method A: Graphical Interface (Recommended)
1. Click the **Wi-Fi / Network icon** in the KDE system tray (bottom-right corner next to the clock).
2. Select your active Wi-Fi connection -> click **Details**.
3. Note the **IPv4 Address** (referred to in this guide as `<deck-ip>`).

#### Method B: Terminal Command
In Konsole, run:
```bash
ip addr show wlan0
```
Look for the line beginning with `inet` (e.g. `inet 192.168.1.XX/24`).

### Step 6: Test SSH Connection from Your Host PC
Open a terminal on your host PC (PowerShell, Command Prompt, or bash):

```bash
ssh deck@<deck-ip>
```

1. If prompted with `The authenticity of host '<deck-ip>' can't be established... Are you sure you want to continue connecting (yes/no)?`, type `yes` and press Enter.
2. Enter your Steam Deck `<password>`.
3. You should see the SteamOS prompt:
   ```text
   (deck@steamdeck ~)$
   ```
4. Type `exit` to disconnect.

---

## 3. (Recommended) Passwordless SSH Key Authentication

Setting up SSH key authentication allows the automated deployment script (`deploy_deck.py`) and testing tools to connect securely without prompting for a password each time.

### From Windows (PowerShell)
```powershell
# 1. Generate an ED25519 key if you do not have one:
ssh-keygen -t ed25519

# 2. Append your public key to the Steam Deck authorized_keys:
Get-Content $env:USERPROFILE\.ssh\id_ed25519.pub | ssh deck@<deck-ip> "mkdir -p ~/.ssh && chmod 700 ~/.ssh && cat >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys"
```

### From macOS / Linux
```bash
# 1. Generate an ED25519 key if you do not have one:
ssh-keygen -t ed25519

# 2. Copy the public key to the Steam Deck:
ssh-copy-id deck@<deck-ip>
```

---

## 4. Automated Deployment Tool (`deploy_deck.py`)

Once SSH is configured, you can deploy and verify Bob Game Center on your Steam Deck with a single command from your host PC:

```bash
# Deploy using SSH key (auto-detected)
python scripts/deck/deploy_deck.py --host <deck-ip> --user deck

# Deploy using password via environment variable
set DECK_PASSWORD=<password>        # Windows cmd
$env:DECK_PASSWORD="<password>"    # Windows PowerShell
export DECK_PASSWORD="<password>"  # Linux / macOS
python scripts/deck/deploy_deck.py --host <deck-ip> --user deck
```

### Key CLI Options
| Flag | Description |
|---|---|
| `--host <ip>` | Steam Deck IP address (default: `192.168.1.24` or `$DECK_HOST`). |
| `--user <user>` | Remote username (default: `deck` or `$DECK_USER`). |
| `--port <port>` | SSH port (default: `22` or `$DECK_PORT`). |
| `--key-file <path>` | Path to private SSH key (default: auto-detected from `~/.ssh/`). |
| `--password-env <var>` | Environment variable holding password (default: `DECK_PASSWORD`). |
| `--dry-run` | Simulate packaging and deployment actions without modifying disk or connecting. |
| `--bundle-only` | Package `dist/bob_game_center_deck.tar.gz` locally without uploading. |
| `--upload-only` | Upload bundle without extracting or running installer. |
| `--verify-only` | Run remote verification probe on Steam Deck without reinstalling. |
| `--clean` | Remove existing target directory before deployment. |
| `--close-steam` | Gracefully close Steam on target device before updating shortcuts. |

---

## 5. Service Management

- **Check SSH status**:
  ```bash
  systemctl status sshd
  ```
- **Temporarily stop SSH service**:
  ```bash
  sudo systemctl stop sshd
  ```
- **Permanently disable SSH on boot**:
  ```bash
  sudo systemctl disable --now sshd
  ```

---

## 6. Troubleshooting

| Symptom | Cause | Solution |
|---|---|---|
| `Connection refused` | SSH service is not running on Steam Deck. | In Desktop Mode Konsole, execute: `sudo systemctl enable --now sshd`. |
| `Connection timed out` | Steam Deck is asleep, IP is incorrect, or router has AP isolation enabled. | 1. Press Power button to wake Steam Deck.<br>2. Re-check IP via `ip addr show wlan0`.<br>3. Verify PC and Deck are connected to the same Wi-Fi subnet. |
| `Permission denied (publickey,password)` | Password incorrect or SSH key not authorized. | Re-run `passwd` on Steam Deck to reset password, or verify `~/.ssh/authorized_keys` permissions (`600`). |
| `Host key verification failed` | Steam Deck IP changed or system was re-imaged. | On host PC, remove stale fingerprint: `ssh-keygen -R <deck-ip>`. |
| SSH disconnects after a few minutes | Deck sleep / suspend timer triggered. | In Desktop Mode: **System Settings** -> **Power Management** -> set screen/sleep timeout to "Never" when plugged in. |
