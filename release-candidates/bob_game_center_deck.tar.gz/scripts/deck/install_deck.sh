#!/usr/bin/env bash
# ==============================================================================
# Bob Game Center - SteamOS / Arch Linux User-Space Installer
# Safe for SteamOS immutable rootfs (deploys entirely in user space /home/deck/)
# ==============================================================================

set -euo pipefail

# --- Color formatting for terminal output ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# --- P0 Tag and Logging ---
TAG="[Packaging/Deck/Install]"
LOG_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/BobGameCenter/logs"
INSTALL_LOG="$LOG_DIR/install.log"

mkdir -p "$LOG_DIR"
exec > >(tee -a "$INSTALL_LOG") 2>&1

log() {
    local level="$1"; shift
    local msg="$*"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "${BLUE}[$timestamp]${NC} ${BOLD}$TAG${NC} [$level] $msg"
}

info()    { log "INFO" "${GREEN}$*${NC}"; }
warn()    { log "WARN" "${YELLOW}$*${NC}"; }
error()   { log "ERROR" "${RED}$*${NC}"; }
step()    { echo -e "\n${BOLD}${BLUE}==>${NC} ${BOLD}$*${NC}"; }

# --- 1. Prevent Running as Root ---
if [ "${EUID:-$(id -u)}" -eq 0 ]; then
    error "DO NOT run this installer as root or with sudo!"
    error "Bob Game Center deploys to user space (/home/deck/Applications/BobGameCenter) and integrates with Steam client owned by the 'deck' user."
    exit 1
fi

step "Checking system environment and prerequisites..."

# --- 2. Resolve Paths ---
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
DEFAULT_TARGET_DIR="${HOME}/Applications/BobGameCenter"
APP_DIR="${BOB_APP_DIR:-$DEFAULT_TARGET_DIR}"

info "User: $(whoami) (UID: $(id -u))"
info "Source directory: $SOURCE_DIR"
info "Target application directory: $APP_DIR"

# --- 3. Verify Python 3 Availability ---
if ! command -v python3 &>/dev/null; then
    error "python3 is not installed or not in PATH."
    exit 1
fi

PYTHON_BIN="$(command -v python3)"
PY_VER="$("$PYTHON_BIN" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
info "Detected Python version: $PY_VER ($PYTHON_BIN)"

# Verify Python version >= 3.9
PY_MAJOR="$("$PYTHON_BIN" -c 'import sys; print(sys.version_info.major)')"
PY_MINOR="$("$PYTHON_BIN" -c 'import sys; print(sys.version_info.minor)')"
if [ "$PY_MAJOR" -lt 3 ] || ([ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 9 ]); then
    error "Python >= 3.9 is required, found $PY_VER."
    exit 1
fi

# Check venv module
if ! "$PYTHON_BIN" -c "import venv" &>/dev/null; then
    error "python3-venv module is not available in system Python."
    exit 1
fi

# --- 4. Deploy Application Files to User Space ---
step "Deploying application files to $APP_DIR..."
mkdir -p "$APP_DIR"
mkdir -p "$HOME/Games"
mkdir -p "${XDG_DATA_HOME:-$HOME/.local/share}/applications"
mkdir -p "${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps"

if [ "$SOURCE_DIR" != "$APP_DIR" ]; then
    info "Syncing files from $SOURCE_DIR to $APP_DIR..."
    if command -v rsync &>/dev/null; then
        rsync -a --delete \
            --exclude 'venv' \
            --exclude '__pycache__' \
            --exclude '*.pyc' \
            --exclude '.git' \
            --exclude '.pytest_cache' \
            --exclude '.ruff_cache' \
            --exclude 'build' \
            --exclude 'dist' \
            "$SOURCE_DIR/" "$APP_DIR/"
    else
        info "rsync not found, copying with cp..."
        cp -rT "$SOURCE_DIR" "$APP_DIR"
    fi
else
    info "Already running directly inside target directory $APP_DIR."
fi

# --- 5. Create or Validate Virtual Environment ---
step "Setting up isolated Python virtual environment (--system-site-packages)..."
VENV_DIR="$APP_DIR/venv"
VENV_PYTHON="$VENV_DIR/bin/python"
VENV_PIP="$VENV_DIR/bin/pip"

CREATE_VENV=0
if [ ! -x "$VENV_PYTHON" ]; then
    CREATE_VENV=1
else
    if ! "$VENV_PYTHON" -c "import sys" &>/dev/null; then
        warn "Existing virtual environment in $VENV_DIR is corrupted. Recreating..."
        rm -rf "$VENV_DIR"
        CREATE_VENV=1
    fi
fi

if [ "$CREATE_VENV" -eq 1 ]; then
    info "Creating virtual environment at $VENV_DIR with --system-site-packages..."
    "$PYTHON_BIN" -m venv --system-site-packages "$VENV_DIR"
fi

if [ ! -x "$VENV_PYTHON" ]; then
    error "Failed to create virtual environment interpreter at $VENV_PYTHON."
    exit 1
fi
info "Virtual environment interpreter: $VENV_PYTHON"

# --- 6. Install / Verify Dependencies ---
step "Installing / verifying dependencies from requirements.txt..."
REQ_FILE="$APP_DIR/requirements.txt"

if [ -f "$REQ_FILE" ]; then
    info "Checking pip availability..."
    if [ ! -x "$VENV_PIP" ]; then
        info "Bootstrapping pip via ensurepip..."
        "$VENV_PYTHON" -m ensurepip --default-pip || true
    fi

    # Upgrade pip silently if online
    "$VENV_PYTHON" -m pip install --upgrade pip --quiet 2>/dev/null || warn "Could not upgrade pip (offline mode or restricted network)."

    info "Installing requirements (using --prefer-binary for pre-built wheels)..."
    if "$VENV_PIP" install --prefer-binary -r "$REQ_FILE"; then
        info "Dependencies successfully installed / updated."
    else
        warn "pip install encountered an issue. Checking if core modules already exist..."
        if "$VENV_PYTHON" -c "import PySide6; import requests" &>/dev/null; then
            info "Core packages (PySide6, requests) are present. Continuing installation."
        else
            error "Failed to install required dependencies. Please verify network connectivity."
            exit 1
        fi
    fi
else
    warn "requirements.txt not found at $REQ_FILE! Skipping package installation."
fi

# --- 7. Permissions and Symlinks ---
step "Configuring executable permissions and runner symlinks..."
chmod 755 "$APP_DIR/scripts/deck/bob_game_center.sh" 2>/dev/null || true
chmod 755 "$APP_DIR/scripts/deck/install_deck.sh" 2>/dev/null || true

# Root launcher symlink
ln -sf "$APP_DIR/scripts/deck/bob_game_center.sh" "$APP_DIR/bob_game_center.sh"
info "Created launcher symlink: $APP_DIR/bob_game_center.sh -> scripts/deck/bob_game_center.sh"

# Native helper binaries
mkdir -p "$APP_DIR/native/bin/linux" "$APP_DIR/bin" "${HOME}/.local/bin"

if [ -d "$APP_DIR/native/bin/linux" ]; then
    chmod 755 "$APP_DIR/native/bin/linux"/* 2>/dev/null || true
fi
if [ -d "$APP_DIR/bin" ]; then
    chmod 755 "$APP_DIR/bin"/* 2>/dev/null || true
fi

ARIA2_TARGET="$APP_DIR/native/bin/linux/aria2c"
if [ ! -x "$ARIA2_TARGET" ]; then
    EXISTING_ARIA2="$(command -v aria2c || echo "")"
    if [ -n "$EXISTING_ARIA2" ] && [ -x "$EXISTING_ARIA2" ]; then
        info "Found existing aria2c at $EXISTING_ARIA2"
        ln -sf "$EXISTING_ARIA2" "$ARIA2_TARGET"
    else
        info "aria2c missing. Downloading static Linux x86_64 binary..."
        ARIA2_URL="https://github.com/P3TERX/Aria2-Pro-Core/releases/download/1.36.0_2021.08.22/aria2-1.36.0-static-linux-amd64.tar.gz"
        TMP_TAR="$(mktemp --suffix=.tar.gz 2>/dev/null || echo "/tmp/aria2_$$.tar.gz")"
        if curl -fsSL -A "BobGameCenter-Installer" --connect-timeout 10 "$ARIA2_URL" -o "$TMP_TAR"; then
            tar -xzf "$TMP_TAR" -C "$APP_DIR/native/bin/linux/" aria2c 2>/dev/null || tar -xzf "$TMP_TAR" -C "$APP_DIR/native/bin/linux/"
            chmod 755 "$ARIA2_TARGET"
            rm -f "$TMP_TAR"
            info "Provisioned aria2c at $ARIA2_TARGET"
        else
            warn "Failed to download aria2c. Please ensure network connectivity."
            rm -f "$TMP_TAR"
        fi
    fi
fi

if [ -x "$ARIA2_TARGET" ]; then
    ln -sf "$ARIA2_TARGET" "$APP_DIR/bin/aria2c"
    ln -sf "$ARIA2_TARGET" "${HOME}/.local/bin/aria2c"
fi

SEVENZ_TARGET="$APP_DIR/native/bin/linux/7zz"
if [ ! -x "$SEVENZ_TARGET" ]; then
    EXISTING_7Z="$(command -v 7zz || command -v 7z || echo "")"
    if [ -n "$EXISTING_7Z" ] && [ -x "$EXISTING_7Z" ]; then
        info "Found existing 7z binary at $EXISTING_7Z"
        ln -sf "$EXISTING_7Z" "$SEVENZ_TARGET"
    else
        info "7zz missing. Downloading official static Linux x86_64 7zz..."
        SEVENZ_URL="https://github.com/ip7z/7zip/releases/download/24.09/7z2409-linux-x64.tar.xz"
        TMP_7Z="$(mktemp --suffix=.tar.xz 2>/dev/null || echo "/tmp/7zz_$$.tar.xz")"
        if curl -fsSL -A "BobGameCenter-Installer" --connect-timeout 10 "$SEVENZ_URL" -o "$TMP_7Z"; then
            tar -xJf "$TMP_7Z" -C "$APP_DIR/native/bin/linux/" 7zz 2>/dev/null || tar -xJf "$TMP_7Z" -C "$APP_DIR/native/bin/linux/"
            chmod 755 "$SEVENZ_TARGET"
            rm -f "$TMP_7Z"
            info "Provisioned 7zz at $SEVENZ_TARGET"
        else
            warn "Failed to download 7zz. RAR extraction may require system p7zip/7zip."
            rm -f "$TMP_7Z"
        fi
    fi
fi

if [ -x "$SEVENZ_TARGET" ]; then
    ln -sf "$SEVENZ_TARGET" "$APP_DIR/bin/7zz"
    ln -sf "$SEVENZ_TARGET" "${HOME}/.local/bin/7zz"
fi

# --- 8. FreeDesktop Icon & Desktop Integration ---
step "Registering Desktop Mode launcher and Steam Game Mode shortcut..."

ICON_SOURCE="$APP_DIR/assets/icon.png"
ICON_DEST="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps/bob_game_center.png"
if [ -f "$ICON_SOURCE" ]; then
    cp "$ICON_SOURCE" "$ICON_DEST" 2>/dev/null || true
fi

# Run setup_deck.py or main.py --setup-deck
if [ -f "$APP_DIR/scripts/deck/setup_deck.py" ]; then
    info "Running setup_deck.py..."
    "$VENV_PYTHON" "$APP_DIR/scripts/deck/setup_deck.py" || warn "setup_deck.py finished with warnings."
else
    info "Running python -m app.main --setup-deck..."
    "$VENV_PYTHON" "$APP_DIR/main.py" --setup-deck 2>/dev/null || warn "app.main --setup-deck completed with warnings."
fi

step "Installation complete!"
info "Bob Game Center is installed in: $APP_DIR"
info "Launch via Desktop Mode: Applications -> Games -> Bob Game Center"
info "Launch via CLI: $APP_DIR/bob_game_center.sh"
info "Launch via Steam Game Mode: Check Non-Steam library in Steam"
info "Installer log saved to: $INSTALL_LOG"

exit 0
