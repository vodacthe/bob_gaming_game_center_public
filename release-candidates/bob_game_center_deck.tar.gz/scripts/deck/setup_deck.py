#!/usr/bin/env python3
"""
scripts/deck/setup_deck.py - Standalone SteamOS Desktop & Game Mode Setup CLI.
Allows users, scripts, and installers (install_deck.sh) to configure .desktop
entry and Steam shortcuts without loading the graphical interface.
"""
from __future__ import annotations

import argparse
import logging
import os
import sys

_current_dir = os.path.dirname(os.path.abspath(__file__))
_root_dir = os.path.abspath(os.path.join(_current_dir, "..", ".."))
if _root_dir not in sys.path:
    sys.path.insert(0, _root_dir)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("Packaging.Deck")
TAG = "[Packaging/Deck]"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Bob Game Center - SteamOS Desktop & Game Mode Setup CLI"
    )
    parser.add_argument(
        "--app-dir",
        default=_root_dir,
        help="Installation root for Bob Game Center (default: %(default)s)"
    )
    parser.add_argument(
        "--steam-path",
        default=None,
        help="Custom Steam path (default: autodetected Steam root)"
    )
    parser.add_argument(
        "--desktop-dir",
        default=None,
        help="Custom destination for .desktop launcher (default: ~/.local/share/applications)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate registration and file creation without modifying disk"
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing configuration"
    )

    args = parser.parse_args(argv)

    try:
        from app.core.desktop_integration import setup_deck_integration
        res = setup_deck_integration(
            app_dir=args.app_dir,
            steam_path=args.steam_path,
            desktop_dir=args.desktop_dir,
            dry_run=args.dry_run,
        )
        if res.get("success"):
            print(f"[OK] {res.get('message', 'Setup completed successfully.')}")
            return 0
        else:
            print(f"[ERROR] {res.get('message', 'Setup failed.')}", file=sys.stderr)
            return 1
    except Exception as exc:
        logger.error(f"{TAG} Setup failed with unexpected exception: {exc}", exc_info=True)
        print(f"[ERROR] Exception during setup: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
