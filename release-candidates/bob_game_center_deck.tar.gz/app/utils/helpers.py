"""
Utility helper functions for Bob Gaming Game Center.
"""

import os
import sys
import re
import hashlib
from datetime import datetime


# Windows: don't flash a console window when a windowed app spawns netsh/ipconfig/powershell.
CREATE_NO_WINDOW = 0x08000000


def is_admin() -> bool:
    """True if the current process has Administrator privileges (Windows)."""
    try:
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False


def run_hidden(cmd: list[str], timeout: float = 15.0):
    """Run a command without a console window and without a shell; returns CompletedProcess."""
    import subprocess
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        creationflags=CREATE_NO_WINDOW if sys.platform == "win32" else 0,
    )


def resource_path(relative_path: str) -> str:
    """Get absolute path to resource, works for dev and PyInstaller bundle."""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath(os.path.dirname(__file__)), "..", "..", relative_path)


def sanitize_filename(name: str) -> str:
    """Remove invalid characters from a filename/folder name."""
    # Remove characters not allowed in Windows filenames
    sanitized = re.sub(r'[<>:"/\\|?*]', '', name)
    # Remove leading/trailing whitespace and dots
    sanitized = sanitized.strip().strip('.')
    # Replace multiple spaces with single space
    sanitized = re.sub(r'\s+', ' ', sanitized)
    return sanitized if sanitized else "unnamed"


def format_timestamp(ts: str | float | None) -> str:
    """Format a timestamp to readable string."""
    if ts is None:
        return "Never"
    try:
        if isinstance(ts, (int, float)):
            dt = datetime.fromtimestamp(ts)
        else:
            dt = datetime.fromisoformat(ts)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, OSError):
        return str(ts)


def get_file_hash(filepath: str) -> str:
    """Calculate MD5 hash of a file for change detection."""
    hasher = hashlib.md5()
    try:
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hasher.update(chunk)
        return hasher.hexdigest()
    except IOError:
        return ""


def get_folder_size(folder_path: str) -> int:
    """Calculate total size of a folder in bytes."""
    total = 0
    for dirpath, _dirnames, filenames in os.walk(folder_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            try:
                total += os.path.getsize(fp)
            except OSError:
                pass
    return total


def format_size(size_bytes: int) -> str:
    """Format file size to human-readable string."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


# Alias for backward compatibility
format_file_size = format_size


def restart_application():
    """Restart the application as a new process and terminate current process."""
    import subprocess
    import logging
    from PySide6.QtWidgets import QApplication

    log = logging.getLogger(__name__)

    if getattr(sys, 'frozen', False):
        exe = sys.executable
        args = [exe]
        work_dir = os.path.dirname(sys.executable)
    else:
        # Running as python script
        main_script = os.path.abspath(os.path.join(
            os.path.dirname(__file__), "..", "..", "main.py"
        ))
        exe = sys.executable
        args = [exe, main_script]
        work_dir = os.path.dirname(main_script)

    creation_flags = 0
    if sys.platform == "win32":
        creation_flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)

    log.info(f"Restarting application: {args} in {work_dir}")
    try:
        subprocess.Popen(args, cwd=work_dir, creationflags=creation_flags)
    except Exception as e:
        log.error(f"Failed to spawn new process for restart: {e}")

    app = QApplication.instance()
    if app:
        app.quit()
    else:
        sys.exit(0)

