"""
Dialog for moving an installed game's folder to another folder/drive/SD card.
Displays source folder + size, lets the user pick a destination folder (with quick SteamOS
SD card / internal storage buttons when present), validates space/paths, and executes the
move in a tracked background QThread with live progress and cancellation support.
"""

from __future__ import annotations

import logging
import os
import shutil
import sys
import threading
from typing import Sequence

from PySide6.QtCore import Qt, QThread
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
)

from app.core.game_mover import GameMoveWorker, _measure_tree, validate_move_operation
from app.ui.game_card import DARK_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.utils.helpers import format_size

logger = logging.getLogger(__name__)
TAG = "[Library/MoveUI]"

_active_moves: set = set()
_active_lock = threading.Lock()
_quit_hooked = False


def _stop_moves_on_quit() -> None:
    with _active_lock:
        items = list(_active_moves)
    for worker, thread in items:
        try:
            worker.cancel()
            thread.quit()
            if not thread.wait(5000):
                logger.warning(f"{TAG} game move thread still running at exit")
        except RuntimeError:
            pass


def _hook_quit() -> None:
    global _quit_hooked
    app = QApplication.instance()
    if app is not None and not _quit_hooked:
        app.aboutToQuit.connect(_stop_moves_on_quit)
        _quit_hooked = True


def discover_quick_destinations() -> list[tuple[str, str]]:
    """Return quick-pick destination (label, path) buttons appropriate for the active OS."""
    options: list[tuple[str, str]] = []
    if sys.platform != "win32":
        internal_games = os.path.expanduser("~/Games")
        if os.path.isdir(internal_games):
            options.append(("Bộ nhớ trong (~/Games)", internal_games))
        media_root = "/run/media"
        if os.path.isdir(media_root):
            try:
                for entry in sorted(os.listdir(media_root)):
                    full = os.path.join(media_root, entry)
                    if not os.path.isdir(full):
                        continue
                    # SteamOS mounts SD cards directly under /run/media/mmcblk0p1 or /run/media/<user>/<label>
                    if entry == os.environ.get("USER", "deck"):
                        for sub in sorted(os.listdir(full)):
                            sub_path = os.path.join(full, sub)
                            if os.path.isdir(sub_path):
                                options.append((f"Thẻ nhớ ({sub})", sub_path))
                    else:
                        options.append((f"Ổ gắn ngoài ({entry})", full))
            except OSError:
                pass
    return options


class MoveGameDialog(QDialog):
    """Dark confirmation & progress dialog for safely moving an installed game."""

    def __init__(
        self,
        game_name: str,
        resolved_dir: str,
        refusal_reason: str = "",
        exe_path: str = "",
        save_path: str = "",
        has_shortcut: bool = False,
        steam_running: bool = False,
        steam_path: str | None = None,
        other_game_exes: Sequence[str] = (),
        extra_protected_dirs: Sequence[str] = (),
        parent=None,
    ):
        super().__init__(parent)
        self.game_name = game_name
        self.resolved_dir = resolved_dir
        self.refusal_reason = refusal_reason
        self.exe_path = exe_path
        self.save_path = save_path
        self.has_shortcut = has_shortcut
        self.steam_running = steam_running
        self.steam_path = steam_path
        self.other_game_exes = list(other_game_exes)
        self.extra_protected_dirs = list(extra_protected_dirs)

        self._worker: GameMoveWorker | None = None
        self._thread: QThread | None = None
        self._moving = False
        self.result_data: dict | None = None

        self._source_bytes = 0
        if self.resolved_dir and os.path.isdir(self.resolved_dir):
            try:
                _cnt, self._source_bytes = _measure_tree(self.resolved_dir)
            except OSError:
                self._source_bytes = 0

        self.setWindowTitle("Di chuyển thư mục game")
        self.setMinimumWidth(560)
        self.setModal(True)
        self.setStyleSheet("""
            QDialog {
                background-color: #0d141e;
                color: #e2e8f0;
            }
            QLabel {
                background: transparent;
                border: none;
            }
            QLineEdit {
                background-color: #0b0f17;
                color: #f8fafc;
                border: 1px solid rgba(148, 163, 184, 0.28);
                border-radius: 8px;
                padding: 6px 10px;
                font-size: 12px;
            }
            QLineEdit:focus {
                border-color: #8b5cf6;
            }
        """)

        self._setup_ui()
        self._update_preview()

    def _setup_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 18)
        root.setSpacing(12)

        # Header
        header_row = QHBoxLayout()
        header_row.setSpacing(12)
        icon_lbl = QLabel()
        icon_lbl.setFixedSize(36, 36)
        icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_lbl.setStyleSheet(
            "background-color: rgba(56, 189, 248, 0.14); "
            "border: 1px solid rgba(56, 189, 248, 0.35); border-radius: 10px;"
        )
        icon_lbl.setPixmap(make_svg_pixmap("folder", size=18, color="#38bdf8"))
        header_row.addWidget(icon_lbl)

        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        title_lbl = QLabel(f'Di chuyển "{self.game_name}"')
        title_lbl.setWordWrap(True)
        title_lbl.setStyleSheet("color: #f8fafc; font-size: 15px; font-weight: 700;")
        size_hint = f" (~{format_size(self._source_bytes)})" if self._source_bytes > 0 else ""
        sub_lbl = QLabel(
            f"Di chuyển thư mục cài đặt{size_hint} sang ổ đĩa hoặc thẻ nhớ khác và tự cập nhật đường dẫn Steam."
        )
        sub_lbl.setWordWrap(True)
        sub_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")
        title_col.addWidget(title_lbl)
        title_col.addWidget(sub_lbl)
        header_row.addLayout(title_col, 1)
        root.addLayout(header_row)

        # Source box
        src_frame = QFrame()
        src_frame.setObjectName("srcBox")
        src_frame.setStyleSheet(
            "QFrame#srcBox { background-color: #111927; "
            "border: 1px solid rgba(148, 163, 184, 0.22); border-radius: 8px; } "
            "QLabel { border: none; background: transparent; }"
        )
        src_lay = QVBoxLayout(src_frame)
        src_lay.setContentsMargins(12, 10, 12, 10)
        src_lay.setSpacing(4)

        src_cap = QLabel("Thư mục cài đặt hiện tại:")
        src_cap.setStyleSheet("color: #94a3b8; font-size: 11px; font-weight: 600;")
        src_lay.addWidget(src_cap)

        self.source_label = QLabel(self.resolved_dir if self.resolved_dir else "(Chưa xác định được thư mục an toàn)")
        self.source_label.setWordWrap(True)
        self.source_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.source_label.setStyleSheet("color: #f8fafc; font-family: Consolas, 'Segoe UI', monospace; font-size: 12px;")
        src_lay.addWidget(self.source_label)

        if self.refusal_reason:
            self.refusal_label = QLabel(self.refusal_reason)
            self.refusal_label.setWordWrap(True)
            self.refusal_label.setStyleSheet("color: #fbbf24; font-size: 12px; font-weight: 600; padding-top: 4px;")
            src_lay.addWidget(self.refusal_label)
        else:
            self.refusal_label = None

        root.addWidget(src_frame)

        # Destination picker box
        dst_frame = QFrame()
        dst_frame.setObjectName("dstBox")
        dst_frame.setStyleSheet(
            "QFrame#dstBox { background-color: #111927; "
            "border: 1px solid rgba(139, 92, 246, 0.28); border-radius: 8px; } "
            "QLabel { border: none; background: transparent; }"
        )
        dst_lay = QVBoxLayout(dst_frame)
        dst_lay.setContentsMargins(12, 10, 12, 10)
        dst_lay.setSpacing(8)

        dst_cap = QLabel("Chọn thư mục đích mới (game sẽ được đặt thành thư mục con bên trong):")
        dst_cap.setStyleSheet("color: #cbd5e1; font-size: 12px; font-weight: 600;")
        dst_lay.addWidget(dst_cap)

        pick_row = QHBoxLayout()
        pick_row.setSpacing(8)
        self.dest_edit = QLineEdit()
        self.dest_edit.setPlaceholderText("Ví dụ: D:\\Games hoặc /run/media/mmcblk0p1/Games")
        self.dest_edit.textChanged.connect(self._update_preview)
        pick_row.addWidget(self.dest_edit, 1)

        self.browse_btn = QPushButton(" Chọn thư mục...")
        self.browse_btn.setIcon(make_svg_icon("folder", size=14, color="#f1f5f9"))
        self.browse_btn.setStyleSheet(DARK_BTN_STYLE)
        self.browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.browse_btn.clicked.connect(self._browse_dest)
        pick_row.addWidget(self.browse_btn)
        dst_lay.addLayout(pick_row)

        quick_opts = discover_quick_destinations()
        if quick_opts:
            q_row = QHBoxLayout()
            q_row.setSpacing(6)
            for label, path in quick_opts[:4]:
                qbtn = QPushButton(label)
                qbtn.setStyleSheet(DARK_BTN_STYLE)
                qbtn.setCursor(Qt.CursorShape.PointingHandCursor)
                qbtn.clicked.connect(lambda _c=False, p=path: self.dest_edit.setText(p))
                q_row.addWidget(qbtn)
            q_row.addStretch()
            dst_lay.addLayout(q_row)

        self.preview_label = QLabel("")
        self.preview_label.setWordWrap(True)
        self.preview_label.setStyleSheet("color: #94a3b8; font-size: 11px;")
        dst_lay.addWidget(self.preview_label)

        root.addWidget(dst_frame)

        # Steam & related configs info box
        info_frame = QFrame()
        info_frame.setObjectName("infoBox")
        info_frame.setStyleSheet(
            "QFrame#infoBox { background-color: #111927; "
            "border: 1px solid rgba(56, 189, 248, 0.22); border-radius: 8px; } "
            "QLabel { border: none; background: transparent; }"
        )
        info_lay = QVBoxLayout(info_frame)
        info_lay.setContentsMargins(12, 10, 12, 10)
        info_lay.setSpacing(4)

        steam_row = QHBoxLayout()
        steam_row.setSpacing(8)
        steam_ico = QLabel()
        steam_ico.setFixedSize(16, 16)
        steam_ico.setPixmap(make_svg_pixmap("steam", size=15, color="#38bdf8"))
        steam_row.addWidget(steam_ico)

        steam_msg = (
            "Sẽ tự động cập nhật đường dẫn phím tắt Non-Steam trong Steam (giữ nguyên AppID, ảnh bìa và Proton Prefix), "
            "cùng cấu hình Thư viện, Lịch sử tải, Upscaler và Triple-Screen."
            if self.has_shortcut
            else "Sẽ tự động cập nhật đường dẫn trong Thư viện, Lịch sử tải, Upscaler và Triple-Screen (nếu có)."
        )
        self.steam_info_label = QLabel(steam_msg)
        self.steam_info_label.setWordWrap(True)
        self.steam_info_label.setStyleSheet("color: #cbd5e1; font-size: 12px;")
        steam_row.addWidget(self.steam_info_label, 1)
        info_lay.addLayout(steam_row)

        if self.has_shortcut and self.steam_running:
            steam_hint = QLabel(
                "Steam đang chạy: phím tắt sẽ tự cập nhật đường dẫn mới khi khởi động lại Steam."
            )
            steam_hint.setWordWrap(True)
            steam_hint.setStyleSheet("color: #64748b; font-size: 11px; padding-left: 24px;")
            info_lay.addWidget(steam_hint)

        root.addWidget(info_frame)

        # Progress bar + status
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(10)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet(
            "QProgressBar { background-color: rgba(255, 255, 255, 0.08); border: none; border-radius: 5px; } "
            "QProgressBar::chunk { background-color: #8b5cf6; border-radius: 5px; }"
        )
        self.progress_bar.hide()
        root.addWidget(self.progress_bar)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("color: #94a3b8; font-size: 12px;")
        self.status_label.hide()
        root.addWidget(self.status_label)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)
        btn_row.addStretch()

        self.cancel_btn = QPushButton("Hủy bỏ")
        self.cancel_btn.setStyleSheet(DARK_BTN_STYLE)
        self.cancel_btn.setFixedHeight(36)
        self.cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cancel_btn.clicked.connect(self._on_cancel_clicked)
        btn_row.addWidget(self.cancel_btn)

        self.confirm_btn = QPushButton(" Bắt đầu di chuyển")
        self.confirm_btn.setIcon(make_svg_icon("folder", size=14, color="#ffffff"))
        self.confirm_btn.setStyleSheet(PURPLE_BTN_STYLE)
        self.confirm_btn.setFixedHeight(36)
        self.confirm_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.confirm_btn.clicked.connect(self._on_start_move)
        btn_row.addWidget(self.confirm_btn)

        root.addLayout(btn_row)

    def _browse_dest(self) -> None:
        try:
            start_dir = self.dest_edit.text().strip() or (
                os.path.dirname(self.resolved_dir) if self.resolved_dir else os.path.expanduser("~")
            )
            chosen = QFileDialog.getExistingDirectory(
                self,
                f"Chọn thư mục đích để di chuyển {self.game_name}",
                start_dir,
            )
            if chosen:
                self.dest_edit.setText(os.path.normpath(chosen))
        except Exception:
            logger.exception(f"{TAG} Failed browsing destination directory")

    def _update_preview(self) -> None:
        if self._moving:
            return
        can_base = bool(self.resolved_dir) and not self.refusal_reason
        dest_parent = self.dest_edit.text().strip().strip('"')
        if not can_base:
            self.preview_label.setText("")
            self.confirm_btn.setEnabled(False)
            return

        if not dest_parent:
            self.preview_label.setText("Hãy chọn thư mục đích chứa trò chơi sau khi di chuyển.")
            self.preview_label.setStyleSheet("color: #94a3b8; font-size: 11px;")
            self.confirm_btn.setEnabled(False)
            return

        folder_name = os.path.basename(os.path.normpath(self.resolved_dir))
        target_preview = os.path.join(os.path.normpath(dest_parent), folder_name)
        free_text = ""
        if os.path.isdir(dest_parent):
            try:
                free_bytes = shutil.disk_usage(dest_parent).free
                free_text = f"  •  Còn trống: {format_size(free_bytes)}"
            except OSError:
                pass
            self.preview_label.setStyleSheet("color: #38bdf8; font-size: 11px;")
            self.preview_label.setText(f"Đích dự kiến: {target_preview}{free_text}")
            self.confirm_btn.setEnabled(True)
        else:
            self.preview_label.setStyleSheet("color: #fbbf24; font-size: 11px;")
            self.preview_label.setText(f"Thư mục không tồn tại: {dest_parent}")
            self.confirm_btn.setEnabled(False)

    def _set_moving_state(self, moving: bool) -> None:
        self._moving = moving
        self.dest_edit.setEnabled(not moving)
        self.browse_btn.setEnabled(not moving)
        self.confirm_btn.setEnabled(not moving)
        self.progress_bar.setVisible(moving)
        self.status_label.setVisible(moving or bool(self.status_label.text()))
        self.cancel_btn.setText("Hủy di chuyển" if moving else "Hủy bỏ")

    def _on_start_move(self) -> None:
        try:
            if self._moving:
                return
            dest_parent = self.dest_edit.text().strip().strip('"')
            ok, err, _dest_dir, _total = validate_move_operation(
                self.resolved_dir,
                dest_parent,
                other_game_exes=self.other_game_exes,
                extra_protected_dirs=self.extra_protected_dirs,
            )
            if not ok:
                logger.warning(f"{TAG} Move preflight refused for {self.game_name!r}: {err}")
                QMessageBox.warning(self, "Không thể di chuyển", err)
                return

            self._set_moving_state(True)
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(0)
            self.status_label.setText("Đang chuẩn bị di chuyển trò chơi...")

            _hook_quit()
            worker = GameMoveWorker(
                game_name=self.game_name,
                source_dir=self.resolved_dir,
                dest_parent_dir=dest_parent,
                exe_path=self.exe_path,
                save_path=self.save_path,
                steam_path=self.steam_path,
                other_game_exes=self.other_game_exes,
                extra_protected_dirs=self.extra_protected_dirs,
            )
            thread = QThread()
            worker.moveToThread(thread)

            with _active_lock:
                _active_moves.add((worker, thread))

            thread.started.connect(worker.run)
            worker.progress.connect(self._on_move_progress)
            worker.finished.connect(self._on_move_finished)
            worker.finished.connect(thread.quit)

            def _cleanup():
                with _active_lock:
                    _active_moves.discard((worker, thread))
                worker.deleteLater()
                thread.deleteLater()
                if self._thread is thread:
                    self._thread = None
                    self._worker = None

            thread.finished.connect(_cleanup)
            self._worker = worker
            self._thread = thread
            logger.info(f"{TAG} Dispatched background move for {self.game_name!r} -> {dest_parent!r}")
            thread.start()
        except Exception:
            logger.exception(f"{TAG} Failed starting game move for {self.game_name!r}")
            self._set_moving_state(False)
            QMessageBox.critical(self, "Lỗi di chuyển", "Không thể khởi chạy tiến trình di chuyển trò chơi.")

    def _on_move_progress(self, cur: int, tot: int, message: str) -> None:
        try:
            if tot > 0:
                self.progress_bar.setRange(0, tot)
                self.progress_bar.setValue(cur)
            else:
                self.progress_bar.setRange(0, 0)
            if message:
                self.status_label.setText(message)
        except RuntimeError:
            pass

    def _on_move_finished(self, result: dict) -> None:
        try:
            self._set_moving_state(False)
            if result.get("success"):
                self.result_data = result
                self.accept()
                return

            err = str(result.get("error") or "Di chuyển trò chơi không thành công.")
            self.status_label.setText(err)
            if not result.get("cancelled"):
                QMessageBox.warning(self, "Không thể di chuyển", err)
            self._update_preview()
        except Exception:
            logger.exception(f"{TAG} Error in _on_move_finished")

    def _on_cancel_clicked(self) -> None:
        if self._moving and self._worker is not None:
            self._worker.cancel()
            self.cancel_btn.setEnabled(False)
            self.status_label.setText("Đang hủy và khôi phục an toàn...")
            return
        self.reject()

    def closeEvent(self, event) -> None:
        if self._moving and self._worker is not None:
            self._worker.cancel()
            self.status_label.setText("Đang hủy tiến trình di chuyển trước khi đóng...")
            event.ignore()
            return
        super().closeEvent(event)
