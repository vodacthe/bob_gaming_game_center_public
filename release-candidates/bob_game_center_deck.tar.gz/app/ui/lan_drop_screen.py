"""
BobDrop (AirDrop-like LAN / ZeroTier / VPN encrypted file & folder sharing) UI screen and dialogs.
Matches Bob Gaming Game Center design system: ScreenHeader, SVG icons, zero emojis, off-UI-thread I/O.
"""

from __future__ import annotations

import functools
import inspect
import logging
import os
import sys
import threading
import time

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from app.core.lan_drop.discovery import DEFAULT_TRANSFER_TCP_PORT, PeerInfo
from app.core.lan_drop.service import (
    DECISION_TIMEOUT_SEC,
    IncomingOffer,
    LanDropService,
    TransferRecord,
    format_bytes,
)
from app.ui.game_card import DARK_BTN_STYLE, GREEN_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS, CONTENT_SPACING, ScreenHeader

logger = logging.getLogger(__name__)
TAG = "[BobDrop/UI]"


def _escape_mnemonic(text: str) -> str:
    return (text or "").replace("&", "&&")


def _safe(func):
    """Guard UI slots so exceptions are logged and surfaced cleanly without reaching Qt's C++ loop."""
    params = list(inspect.signature(func).parameters.values())[1:]
    accepts_varargs = any(p.kind is inspect.Parameter.VAR_POSITIONAL for p in params)
    max_args = len([p for p in params if p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)])

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if not accepts_varargs:
            args = args[:max_args]
        try:
            return func(self, *args, **kwargs)
        except Exception:
            logger.exception(f"{TAG} {func.__name__} failed")
            try:
                if isValid(self) and hasattr(self, "_set_status"):
                    self._set_status("Có lỗi không mong muốn (xem Nhật ký Logs).", error=True)
            except Exception:
                pass
            return None

    return wrapper


_ui_tasks: set["_SizeScanTask"] = set()
_ui_tasks_lock = threading.Lock()
_ui_quit_hooked = False


def _stop_ui_tasks_on_quit() -> None:
    with _ui_tasks_lock:
        tasks = list(_ui_tasks)
    for t in tasks:
        t.cancel()
    for t in tasks:
        t.wait(1500)


def _ensure_quit_hook() -> None:
    global _ui_quit_hooked
    app = QApplication.instance()
    if app is not None and not _ui_quit_hooked:
        app.aboutToQuit.connect(_stop_ui_tasks_on_quit)
        _ui_quit_hooked = True


class _SizeScanTask(QThread):
    """Compute file count and byte size of staged paths off the UI thread."""

    done = Signal(str, int, int)  # (root_path, file_count, total_bytes)

    def __init__(self, target_path: str):
        super().__init__(None)
        self._path = target_path
        self._cancelled = False
        self.setObjectName("bobdrop-size-scan")

    def cancel(self) -> None:
        self._cancelled = True

    def start_tracked(self) -> None:
        _ensure_quit_hook()
        with _ui_tasks_lock:
            _ui_tasks.add(self)
        self.finished.connect(self._forget)
        self.start()

    def _forget(self) -> None:
        with _ui_tasks_lock:
            _ui_tasks.discard(self)

    def run(self) -> None:
        count = 0
        total = 0
        try:
            p = self._path
            if os.path.isfile(p) and not os.path.islink(p):
                count = 1
                total = os.path.getsize(p)
            elif os.path.isdir(p) and not os.path.islink(p):
                for root, dirs, files in os.walk(p, followlinks=False):
                    if self._cancelled:
                        return
                    dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(root, d))]
                    for fn in files:
                        if self._cancelled:
                            return
                        fp = os.path.join(root, fn)
                        if not os.path.islink(fp) and os.path.isfile(fp):
                            count += 1
                            try:
                                total += os.path.getsize(fp)
                            except OSError:
                                pass
            if not self._cancelled:
                self.done.emit(p, count, total)
        except Exception:
            logger.exception(f"{TAG} Folder size scan failed for {self._path!r}")


_SCREEN_STYLE = """
QFrame#dropConfigBar, QFrame#dropPanel, QFrame#peerCard, QFrame#transferRow {
    background-color: rgba(15, 20, 34, 0.72);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 12px;
}
QFrame#peerCard:hover {
    border-color: rgba(56, 189, 248, 0.45);
    background-color: rgba(22, 30, 50, 0.85);
}
QFrame#dropZone {
    background-color: rgba(12, 18, 32, 0.65);
    border: 2px dashed rgba(56, 189, 248, 0.35);
    border-radius: 12px;
}
QFrame#dropZone[dragActive="true"] {
    background-color: rgba(16, 185, 129, 0.12);
    border: 2px dashed #10b981;
}
QLabel {
    background: transparent;
    border: none;
    color: #e2e8f0;
}
QLineEdit, QComboBox {
    background-color: rgba(10, 14, 24, 0.85);
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 8px;
    padding: 0 10px;
    min-height: 32px;
    max-height: 32px;
    color: #f8fafc;
    font-size: 12px;
}
QLineEdit:focus, QComboBox:focus {
    border-color: #38bdf8;
}
QListWidget#stagedList {
    background-color: rgba(8, 12, 22, 0.55);
    border: 1px solid rgba(255, 255, 255, 0.07);
    border-radius: 8px;
    color: #e2e8f0;
    font-size: 12px;
    padding: 4px;
}
QListWidget#stagedList::item {
    padding: 6px 8px;
    border-radius: 6px;
}
QListWidget#stagedList::item:selected {
    background-color: rgba(56, 189, 248, 0.18);
    color: #ffffff;
}
QProgressBar {
    background-color: rgba(255, 255, 255, 0.08);
    border: none;
    border-radius: 4px;
    height: 8px;
    text-align: center;
}
QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0ea5e9, stop:1 #10b981);
    border-radius: 4px;
}
"""


def _extract_dropped_paths(mime_data) -> list[str]:
    if not mime_data or not mime_data.hasUrls():
        return []
    paths: list[str] = []
    for url in mime_data.urls():
        if url.isLocalFile():
            local = os.path.abspath(url.toLocalFile())
            if os.path.exists(local) and not os.path.islink(local):
                paths.append(local)
    return paths


class _DropZoneFrame(QFrame):
    paths_dropped = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("dropZone")
        self.setAcceptDrops(True)
        self.setProperty("dragActive", "false")

    def _set_drag_active(self, active: bool) -> None:
        self.setProperty("dragActive", "true" if active else "false")
        self.style().unpolish(self)
        self.style().polish(self)

    def dragEnterEvent(self, event):
        if _extract_dropped_paths(event.mimeData()):
            self._set_drag_active(True)
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self._set_drag_active(False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        self._set_drag_active(False)
        paths = _extract_dropped_paths(event.mimeData())
        if paths:
            event.acceptProposedAction()
            self.paths_dropped.emit(paths)
        else:
            event.ignore()


class _PeerCardWidget(QFrame):
    """Single discovered LAN / ZeroTier / VPN peer card with checkbox, direct send, and drop-to-send."""

    selection_toggled = Signal(str, bool)
    send_clicked = Signal(object)       # PeerInfo
    files_dropped_on_peer = Signal(object, list)  # (PeerInfo, paths)
    untrust_clicked = Signal(str)       # device_id

    def __init__(self, peer: PeerInfo, checked: bool, is_trusted: bool, parent=None):
        super().__init__(parent)
        self.peer = peer
        self.setObjectName("peerCard")
        self.setAcceptDrops(True)

        row = QHBoxLayout(self)
        row.setContentsMargins(12, 10, 12, 10)
        row.setSpacing(10)

        self.checkbox = QCheckBox()
        self.checkbox.setChecked(checked)
        self.checkbox.toggled.connect(lambda state: self.selection_toggled.emit(self.peer.device_id, state))
        row.addWidget(self.checkbox)

        icon_lbl = QLabel()
        icon_name = "shield" if is_trusted else "users"
        icon_color = "#10b981" if is_trusted else "#38bdf8"
        icon_lbl.setPixmap(make_svg_pixmap(icon_name, size=20, color=icon_color))
        icon_lbl.setFixedSize(24, 24)
        row.addWidget(icon_lbl)

        info_col = QVBoxLayout()
        info_col.setSpacing(2)

        tags = [f"[{peer.net_kind}]"]
        if is_trusted:
            tags.append("[Tin cậy]")
        if peer.mode == "trusted":
            tags.append("[Chỉ nhận tin cậy]")
        if peer.pin_required:
            tags.append("[Yêu cầu PIN]")

        title_lbl = QLabel(f"{peer.device_name}  {' '.join(tags)}")
        title_lbl.setStyleSheet("font-size: 13px; font-weight: 700; color: #f8fafc;")
        sub_lbl = QLabel(f"IP: {peer.ip}:{peer.port}  |  Khoá: {peer.short_fingerprint}")
        sub_lbl.setStyleSheet("font-size: 11px; color: #94a3b8;")

        info_col.addWidget(title_lbl)
        info_col.addWidget(sub_lbl)
        row.addLayout(info_col, stretch=1)

        if is_trusted:
            revoke_btn = QPushButton("Bỏ ghim")
            revoke_btn.setStyleSheet(DARK_BTN_STYLE)
            revoke_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            revoke_btn.setToolTip("Xoá trạng thái ghim khoá tin cậy của thiết bị này")
            revoke_btn.clicked.connect(lambda: self.untrust_clicked.emit(self.peer.device_id))
            row.addWidget(revoke_btn)

        send_btn = QPushButton("Gửi ngay")
        send_btn.setIcon(make_svg_icon("upload", size=14, color="#ffffff"))
        send_btn.setStyleSheet(PURPLE_BTN_STYLE)
        send_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        send_btn.clicked.connect(lambda: self.send_clicked.emit(self.peer))
        row.addWidget(send_btn)

    def dragEnterEvent(self, event):
        if _extract_dropped_paths(event.mimeData()):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        paths = _extract_dropped_paths(event.mimeData())
        if paths:
            event.acceptProposedAction()
            self.files_dropped_on_peer.emit(self.peer, paths)
        else:
            event.ignore()


class _TransferRowWidget(QFrame):
    """Live row tracking a single incoming or outgoing transfer."""

    cancel_clicked = Signal(str)
    open_folder_clicked = Signal(str)

    def __init__(self, record: TransferRecord, parent=None):
        super().__init__(parent)
        self.transfer_id = record.transfer_id
        self._save_dir = record.save_dir
        self.setObjectName("transferRow")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 8, 12, 8)
        outer.setSpacing(6)

        top = QHBoxLayout()
        top.setSpacing(8)

        self.title_lbl = QLabel()
        self.title_lbl.setStyleSheet("font-size: 12px; font-weight: 700; color: #f8fafc;")
        top.addWidget(self.title_lbl, stretch=1)

        self.sas_lbl = QLabel()
        self.sas_lbl.setStyleSheet(
            "font-size: 11px; font-weight: 700; color: #38bdf8; "
            "background-color: rgba(56, 189, 248, 0.12); border: 1px solid rgba(56, 189, 248, 0.35); "
            "border-radius: 6px; padding: 2px 8px;"
        )
        top.addWidget(self.sas_lbl)

        self.action_btn = QPushButton("Huỷ")
        self.action_btn.setStyleSheet(DARK_BTN_STYLE)
        self.action_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.action_btn.clicked.connect(self._on_action_clicked)
        top.addWidget(self.action_btn)

        outer.addLayout(top)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setTextVisible(False)
        outer.addWidget(self.progress_bar)

        self.detail_lbl = QLabel()
        self.detail_lbl.setStyleSheet("font-size: 11px; color: #94a3b8;")
        outer.addWidget(self.detail_lbl)

        self.apply_record(record)

    def _on_action_clicked(self) -> None:
        if self._mode == "cancel":
            self.cancel_clicked.emit(self.transfer_id)
        elif self._mode == "open" and self._save_dir:
            self.open_folder_clicked.emit(self._save_dir)

    def apply_record(self, rec: TransferRecord) -> None:
        self._save_dir = rec.save_dir
        direction_txt = "Gửi tới" if rec.direction == "send" else "Nhận từ"
        self.title_lbl.setText(
            f"{direction_txt} {rec.peer_name} ({rec.peer_ip})  -  {rec.file_count} tệp ({format_bytes(rec.total_bytes)})"
        )
        if rec.sas_code:
            self.sas_lbl.setText(f"Mã đối chiếu: {rec.sas_code}")
            self.sas_lbl.show()
        else:
            self.sas_lbl.hide()

        pct = int((rec.transferred_bytes * 100) / rec.total_bytes) if rec.total_bytes > 0 else (
            100 if rec.status == "completed" else 0
        )
        self.progress_bar.setValue(max(0, min(100, pct)))

        speed_str = f"  |  {format_bytes(rec.speed_bps)}/s" if rec.speed_bps > 0 and rec.status == "transferring" else ""
        self.detail_lbl.setText(
            f"{rec.message}  ({format_bytes(rec.transferred_bytes)} / {format_bytes(rec.total_bytes)}{speed_str})"
        )

        if rec.status in ("connecting", "waiting", "transferring"):
            self._mode = "cancel"
            self.action_btn.setText("Huỷ")
            self.action_btn.show()
        elif rec.status == "completed" and rec.direction == "receive" and rec.save_dir:
            self._mode = "open"
            self.action_btn.setText("Mở thư mục")
            self.action_btn.show()
        else:
            self._mode = "none"
            self.action_btn.hide()


class IncomingTransferDialog(QDialog):
    """AirDrop-style incoming file prompt with SAS 6-digit verification, TOFU pinning, and 60s countdown."""

    decision_made = Signal(str, bool, bool)  # (transfer_id, accepted, trust_peer)

    def __init__(self, offer: IncomingOffer, parent=None, standalone: bool = False):
        super().__init__(parent)
        self.offer = offer
        self._decided = False
        self._remaining_sec = int(DECISION_TIMEOUT_SEC)

        self.setWindowTitle("BobDrop - Nhận tệp chia sẻ nội bộ")
        self.setMinimumWidth(480)
        if standalone:
            self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)

        self.setStyleSheet("""
            QDialog {
                background-color: #0d1220;
                border: 1px solid rgba(56, 189, 248, 0.35);
                border-radius: 12px;
            }
            QLabel { color: #e2e8f0; background: transparent; }
            QCheckBox { color: #cbd5e1; font-size: 12px; spacing: 8px; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(14)

        hdr = QHBoxLayout()
        hdr_icon = QLabel()
        hdr_icon.setPixmap(make_svg_pixmap("share", size=24, color="#38bdf8"))
        hdr.addWidget(hdr_icon)
        mode_tag = " (Chia sẻ cho tất cả)" if offer.broadcast else ""
        hdr_title = QLabel(f"{offer.sender_name} muốn gửi tệp cho bạn{mode_tag}")
        hdr_title.setStyleSheet("font-size: 15px; font-weight: 700; color: #ffffff;")
        hdr_title.setWordWrap(True)
        hdr.addWidget(hdr_title, stretch=1)
        layout.addLayout(hdr)

        meta_lbl = QLabel(f"Địa chỉ nguồn: {offer.sender_ip}   |   Tổng dung lượng: {format_bytes(offer.total_size)}")
        meta_lbl.setStyleSheet("font-size: 12px; color: #94a3b8;")
        layout.addWidget(meta_lbl)

        # Security / Trust banner
        sec_frame = QFrame()
        sec_lay = QVBoxLayout(sec_frame)
        sec_lay.setContentsMargins(12, 10, 12, 10)
        sec_lay.setSpacing(4)

        if offer.key_changed:
            sec_frame.setStyleSheet(
                "background-color: rgba(239, 68, 68, 0.16); border: 1px solid rgba(239, 68, 68, 0.7); border-radius: 8px;"
            )
            warn_lbl = QLabel(
                "CẢNH BÁO BẢO MẬT: Khoá định danh của thiết bị này ĐÃ THAY ĐỔI so với lần ghim trước! "
                "Có nguy cơ giả mạo trên mạng chung — bắt buộc kiểm tra mã đối chiếu 6 số bên dưới."
            )
            warn_lbl.setWordWrap(True)
            warn_lbl.setStyleSheet("color: #fca5a5; font-size: 12px; font-weight: 700;")
            sec_lay.addWidget(warn_lbl)
        elif offer.is_trusted:
            sec_frame.setStyleSheet(
                "background-color: rgba(16, 185, 129, 0.14); border: 1px solid rgba(16, 185, 129, 0.55); border-radius: 8px;"
            )
            ok_lbl = QLabel("Thiết bị đã ghim khoá tin cậy (Đã xác thực chữ ký ECDSA qua kênh TLS 1.3)")
            ok_lbl.setWordWrap(True)
            ok_lbl.setStyleSheet("color: #6ee7b7; font-size: 12px; font-weight: 600;")
            sec_lay.addWidget(ok_lbl)
        else:
            sec_frame.setStyleSheet(
                "background-color: rgba(56, 189, 248, 0.12); border: 1px solid rgba(56, 189, 248, 0.45); border-radius: 8px;"
            )
            new_lbl = QLabel("Thiết bị mới: Hãy kiểm tra Mã đối chiếu 6 số trùng khớp với màn hình người gửi")
            new_lbl.setWordWrap(True)
            new_lbl.setStyleSheet("color: #7dd3fc; font-size: 12px; font-weight: 600;")
            sec_lay.addWidget(new_lbl)

        sas_lbl = QLabel(f"Mã đối chiếu bảo mật:   {offer.sas_code}")
        sas_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sas_lbl.setStyleSheet("font-size: 18px; font-weight: 800; color: #ffffff; letter-spacing: 2px; padding-top: 4px;")
        sec_lay.addWidget(sas_lbl)
        layout.addWidget(sec_frame)

        # File preview list
        preview_lines = [
            f"- {f['rel_path']} ({format_bytes(f['size'])})"
            for f in offer.files[:6]
        ]
        if len(offer.files) > 6:
            preview_lines.append(f"... và {len(offer.files) - 6} tệp khác")
        files_box = QLabel("\n".join(preview_lines))
        files_box.setWordWrap(True)
        files_box.setStyleSheet(
            "background-color: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255, 255, 255, 0.08); "
            "border-radius: 8px; padding: 10px; font-size: 12px; color: #cbd5e1;"
        )
        layout.addWidget(files_box)

        dest_lbl = QLabel(f"Lưu vào: {offer.save_dir}")
        dest_lbl.setWordWrap(True)
        dest_lbl.setStyleSheet("font-size: 11px; color: #94a3b8;")
        layout.addWidget(dest_lbl)

        self.trust_cb = QCheckBox("Ghim tin cậy thiết bị này cho các lần sau")
        if offer.is_trusted and not offer.key_changed:
            self.trust_cb.setChecked(True)
            self.trust_cb.hide()
        else:
            self.trust_cb.setChecked(not offer.key_changed)
        layout.addWidget(self.trust_cb)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)
        btn_row.addStretch()

        self.decline_btn = QPushButton(f"Từ chối ({self._remaining_sec}s)")
        self.decline_btn.setStyleSheet(DARK_BTN_STYLE)
        self.decline_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.decline_btn.clicked.connect(self._on_decline)
        btn_row.addWidget(self.decline_btn)

        self.accept_btn = QPushButton("Chấp nhận nhận tệp")
        self.accept_btn.setIcon(make_svg_icon("download", size=14, color="#042612"))
        self.accept_btn.setStyleSheet(GREEN_BTN_STYLE)
        self.accept_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.accept_btn.clicked.connect(self._on_accept)
        btn_row.addWidget(self.accept_btn)

        layout.addLayout(btn_row)

        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._on_tick)
        self._timer.start()

    def _on_tick(self) -> None:
        self._remaining_sec -= 1
        if self._remaining_sec <= 0:
            self._on_decline()
        else:
            self.decline_btn.setText(f"Từ chối ({self._remaining_sec}s)")

    def _finalize(self, accepted: bool) -> None:
        if self._decided:
            return
        self._decided = True
        self._timer.stop()
        trust = bool(accepted and self.trust_cb.isChecked())
        self.decision_made.emit(self.offer.transfer_id, accepted, trust)
        if accepted:
            self.accept()
        else:
            self.reject()

    def _on_accept(self) -> None:
        self._finalize(True)

    def _on_decline(self) -> None:
        self._finalize(False)

    def reject(self) -> None:
        if not self._decided:
            self._decided = True
            self._timer.stop()
            self.decision_made.emit(self.offer.transfer_id, False, False)
        super().reject()


class LanDropScreen(QWidget):
    """Full-screen BobDrop view inside MainWindow."""

    back_requested = Signal()

    def __init__(self, service: LanDropService, parent=None):
        super().__init__(parent)
        self.service = service
        self._staged_paths: list[str] = []
        self._staged_sizes: dict[str, tuple[int, int]] = {}  # path -> (file_count, bytes)
        self._selected_peer_ids: set[str] = set()
        self._transfer_rows: dict[str, _TransferRowWidget] = {}

        self.setAcceptDrops(True)
        self.setStyleSheet(_SCREEN_STYLE)
        self._build_ui()
        self._connect_service()
        self.sync_from_service()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.header = ScreenHeader(
            "Chia sẻ file nội bộ (BobDrop)",
            "share",
            subtitle="Truyền tệp và thư mục trực tiếp qua mạng LAN, ZeroTier, VPN với mã hoá đầu-cuối TLS 1.3",
        )
        self.header.back_requested.connect(self._on_back)
        self.mode_badge = self.header.add_badge("MỌI NGƯỜI", "ok")
        self.open_dir_btn = self.header.add_button("Mở thư mục nhận", "secondary", icon="folder")
        self.open_dir_btn.clicked.connect(self._on_open_receive_dir)
        self.add_ip_btn = self.header.add_button("Thêm IP VPN", "secondary", icon="plus")
        self.add_ip_btn.clicked.connect(self._on_add_vpn_ip)
        self.refresh_btn = self.header.add_button("Làm mới", "secondary", icon="refresh")
        self.refresh_btn.clicked.connect(self._on_refresh_peers)
        root.addWidget(self.header)

        body = QVBoxLayout()
        body.setContentsMargins(*CONTENT_MARGINS)
        body.setSpacing(CONTENT_SPACING)

        # 1. Security & Visibility Settings Bar
        cfg_bar = QFrame()
        cfg_bar.setObjectName("dropConfigBar")
        cfg_layout = QVBoxLayout(cfg_bar)
        cfg_layout.setContentsMargins(16, 12, 16, 12)
        cfg_layout.setSpacing(10)

        row1 = QHBoxLayout()
        row1.setSpacing(12)

        row1.addWidget(QLabel("Tên thiết bị:"))
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Tên hiển thị trong mạng LAN/VPN")
        self.name_input.editingFinished.connect(self._on_device_name_edited)
        row1.addWidget(self.name_input, stretch=1)

        row1.addWidget(QLabel("Chế độ nhận:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("Mọi người trong mạng", "everyone")
        self.mode_combo.addItem("Chỉ thiết bị tin cậy", "trusted")
        self.mode_combo.addItem("Tắt nhận tệp (Ẩn diện)", "off")
        self.mode_combo.currentIndexChanged.connect(self._on_mode_changed)
        row1.addWidget(self.mode_combo)

        row1.addWidget(QLabel("Mã phòng (PIN):"))
        self.pin_input = QLineEdit()
        self.pin_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.pin_input.setPlaceholderText("Trống = không dùng PIN")
        self.pin_input.setFixedWidth(160)
        self.pin_input.editingFinished.connect(self._on_pin_edited)
        row1.addWidget(self.pin_input)

        self.fp_label = QLabel()
        self.fp_label.setStyleSheet(
            "font-size: 11px; font-weight: 700; color: #38bdf8; "
            "background-color: rgba(56, 189, 248, 0.10); border: 1px solid rgba(56, 189, 248, 0.30); "
            "border-radius: 6px; padding: 4px 8px;"
        )
        row1.addWidget(self.fp_label)
        cfg_layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.setSpacing(10)
        row2.addWidget(QLabel("Thư mục lưu tệp nhận:"))
        self.save_dir_label = QLabel()
        self.save_dir_label.setStyleSheet("color: #94a3b8; font-size: 12px;")
        self.save_dir_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        row2.addWidget(self.save_dir_label, stretch=1)

        change_dir_btn = QPushButton("Đổi thư mục")
        change_dir_btn.setIcon(make_svg_icon("folder", size=14, color="#f1f5f9"))
        change_dir_btn.setStyleSheet(DARK_BTN_STYLE)
        change_dir_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        change_dir_btn.clicked.connect(self._on_choose_save_dir)
        row2.addWidget(change_dir_btn)

        self.status_lbl = QLabel("Sẵn sàng bảo mật TLS 1.3.")
        self.status_lbl.setStyleSheet("font-size: 12px; color: #10b981; font-weight: 600;")
        row2.addWidget(self.status_lbl)

        cfg_layout.addLayout(row2)
        body.addWidget(cfg_bar)

        # 2. Split Main Columns: Left = Drag & Drop Payload, Right = Peer Radar
        mid_row = QHBoxLayout()
        mid_row.setSpacing(CONTENT_SPACING)

        # Left Panel: Drop Zone + Staged Items
        left_panel = QFrame()
        left_panel.setObjectName("dropPanel")
        left_lay = QVBoxLayout(left_panel)
        left_lay.setContentsMargins(16, 14, 16, 14)
        left_lay.setSpacing(10)

        left_hdr = QHBoxLayout()
        left_title = QLabel("1. Kéo thả tệp hoặc thư mục cần gửi")
        left_title.setStyleSheet("font-size: 14px; font-weight: 700; color: #ffffff;")
        left_hdr.addWidget(left_title, stretch=1)
        self.staged_summary_lbl = QLabel("Chưa chọn tệp nào")
        self.staged_summary_lbl.setStyleSheet("font-size: 12px; color: #94a3b8;")
        left_hdr.addWidget(self.staged_summary_lbl)
        left_lay.addLayout(left_hdr)

        self.drop_zone = _DropZoneFrame()
        self.drop_zone.paths_dropped.connect(self.add_staged_paths)
        dz_lay = QVBoxLayout(self.drop_zone)
        dz_lay.setContentsMargins(16, 16, 16, 16)
        dz_lay.setSpacing(8)
        dz_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

        dz_icon = QLabel()
        dz_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dz_icon.setPixmap(make_svg_pixmap("upload", size=28, color="#38bdf8"))
        dz_lay.addWidget(dz_icon)

        dz_hint = QLabel("Kéo thả nhiều tệp lẻ hoặc nguyên thư mục vào đây\n(Hoặc thả trực tiếp lên thẻ người nhận bên phải để gửi ngay)")
        dz_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dz_hint.setStyleSheet("font-size: 12px; color: #cbd5e1;")
        dz_lay.addWidget(dz_hint)

        dz_btns = QHBoxLayout()
        dz_btns.setSpacing(8)
        dz_btns.addStretch()

        add_files_btn = QPushButton("Chọn tệp")
        add_files_btn.setIcon(make_svg_icon("file", size=14, color="#f1f5f9"))
        add_files_btn.setStyleSheet(DARK_BTN_STYLE)
        add_files_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        add_files_btn.clicked.connect(self._on_pick_files)
        dz_btns.addWidget(add_files_btn)

        add_folder_btn = QPushButton("Chọn thư mục")
        add_folder_btn.setIcon(make_svg_icon("folder", size=14, color="#f1f5f9"))
        add_folder_btn.setStyleSheet(DARK_BTN_STYLE)
        add_folder_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        add_folder_btn.clicked.connect(self._on_pick_folder)
        dz_btns.addWidget(add_folder_btn)

        clear_btn = QPushButton("Xoá danh sách")
        clear_btn.setIcon(make_svg_icon("trash", size=14, color="#f1f5f9"))
        clear_btn.setStyleSheet(DARK_BTN_STYLE)
        clear_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        clear_btn.clicked.connect(self._on_clear_staged)
        dz_btns.addWidget(clear_btn)
        dz_btns.addStretch()
        dz_lay.addLayout(dz_btns)

        left_lay.addWidget(self.drop_zone)

        self.staged_list = QListWidget()
        self.staged_list.setObjectName("stagedList")
        self.staged_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        left_lay.addWidget(self.staged_list, stretch=1)

        remove_sel_btn = QPushButton("Bỏ mục đang chọn")
        remove_sel_btn.setStyleSheet(DARK_BTN_STYLE)
        remove_sel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        remove_sel_btn.clicked.connect(self._on_remove_selected_staged)
        left_lay.addWidget(remove_sel_btn, alignment=Qt.AlignmentFlag.AlignRight)

        mid_row.addWidget(left_panel, stretch=1)

        # Right Panel: Peer Radar + Send Selected / Send All
        right_panel = QFrame()
        right_panel.setObjectName("dropPanel")
        right_lay = QVBoxLayout(right_panel)
        right_lay.setContentsMargins(16, 14, 16, 14)
        right_lay.setSpacing(10)

        right_hdr = QHBoxLayout()
        right_title = QLabel("2. Thiết bị trong mạng LAN / ZeroTier / VPN")
        right_title.setStyleSheet("font-size: 14px; font-weight: 700; color: #ffffff;")
        right_hdr.addWidget(right_title, stretch=1)
        self.peer_count_lbl = QLabel("0 thiết bị trực tuyến")
        self.peer_count_lbl.setStyleSheet("font-size: 12px; color: #38bdf8; font-weight: 600;")
        right_hdr.addWidget(self.peer_count_lbl)
        right_lay.addLayout(right_hdr)

        self.peer_scroll = QScrollArea()
        self.peer_scroll.setWidgetResizable(True)
        self.peer_scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        self.peer_container = QWidget()
        self.peer_container.setStyleSheet("background: transparent;")
        self.peer_list_layout = QVBoxLayout(self.peer_container)
        self.peer_list_layout.setContentsMargins(0, 0, 4, 0)
        self.peer_list_layout.setSpacing(8)

        self.empty_peers_lbl = QLabel(
            "Đang quét thiết bị mở Bob Gaming Game Center trong cùng mạng LAN, ZeroTier hoặc Radmin VPN...\n"
            "Nếu dùng VPN định tuyến lớp 3 (Tailscale / WireGuard), bấm 'Thêm IP VPN' trên thanh tiêu đề."
        )
        self.empty_peers_lbl.setWordWrap(True)
        self.empty_peers_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_peers_lbl.setStyleSheet("color: #64748b; font-size: 12px; padding: 28px 12px;")
        self.peer_list_layout.addWidget(self.empty_peers_lbl)
        self.peer_list_layout.addStretch()
        self.peer_scroll.setWidget(self.peer_container)
        right_lay.addWidget(self.peer_scroll, stretch=1)

        send_actions = QHBoxLayout()
        send_actions.setSpacing(10)

        self.send_selected_btn = QPushButton("Gửi người đã chọn (0)")
        self.send_selected_btn.setIcon(make_svg_icon("upload", size=14, color="#ffffff"))
        self.send_selected_btn.setStyleSheet(PURPLE_BTN_STYLE)
        self.send_selected_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_selected_btn.clicked.connect(self._on_send_selected)
        send_actions.addWidget(self.send_selected_btn, stretch=1)

        self.send_all_btn = QPushButton("Chia sẻ cho tất cả (0)")
        self.send_all_btn.setIcon(make_svg_icon("users", size=14, color="#042612"))
        self.send_all_btn.setStyleSheet(GREEN_BTN_STYLE)
        self.send_all_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_all_btn.clicked.connect(self._on_send_all)
        send_actions.addWidget(self.send_all_btn, stretch=1)

        right_lay.addLayout(send_actions)
        mid_row.addWidget(right_panel, stretch=1)

        body.addLayout(mid_row, stretch=3)

        # 3. Active & Recent Transfers Panel
        xfer_panel = QFrame()
        xfer_panel.setObjectName("dropPanel")
        xfer_lay = QVBoxLayout(xfer_panel)
        xfer_lay.setContentsMargins(16, 12, 16, 12)
        xfer_lay.setSpacing(8)

        xfer_title = QLabel("Tiến trình truyền và lịch sử phiên hiện tại")
        xfer_title.setStyleSheet("font-size: 13px; font-weight: 700; color: #ffffff;")
        xfer_lay.addWidget(xfer_title)

        self.xfer_scroll = QScrollArea()
        self.xfer_scroll.setWidgetResizable(True)
        self.xfer_scroll.setMinimumHeight(110)
        self.xfer_scroll.setMaximumHeight(180)
        self.xfer_scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        self.xfer_container = QWidget()
        self.xfer_container.setStyleSheet("background: transparent;")
        self.xfer_list_layout = QVBoxLayout(self.xfer_container)
        self.xfer_list_layout.setContentsMargins(0, 0, 4, 0)
        self.xfer_list_layout.setSpacing(6)

        self.empty_xfer_lbl = QLabel("Chưa có phiên gửi hoặc nhận tệp nào trong phiên làm việc này.")
        self.empty_xfer_lbl.setStyleSheet("color: #64748b; font-size: 12px; padding: 12px 4px;")
        self.xfer_list_layout.addWidget(self.empty_xfer_lbl)
        self.xfer_list_layout.addStretch()
        self.xfer_scroll.setWidget(self.xfer_container)
        xfer_lay.addWidget(self.xfer_scroll)

        body.addWidget(xfer_panel, stretch=1)
        root.addLayout(body, stretch=1)

    def _connect_service(self) -> None:
        self.service.peers_changed.connect(self._on_peers_changed)
        self.service.transfer_updated.connect(self._on_transfer_updated)
        self.service.status_changed.connect(self._on_service_status_changed)
        self.service.service_error.connect(self._on_service_error)

    @_safe
    def sync_from_service(self) -> None:
        self.name_input.blockSignals(True)
        self.name_input.setText(self.service.get_device_name())
        self.name_input.blockSignals(False)

        mode = self.service.get_mode()
        self.mode_combo.blockSignals(True)
        idx = self.mode_combo.findData(mode)
        self.mode_combo.setCurrentIndex(max(0, idx))
        self.mode_combo.blockSignals(False)

        self.pin_input.blockSignals(True)
        self.pin_input.setText(self.service.get_room_pin())
        self.pin_input.blockSignals(False)

        self.fp_label.setText(f"Khoá máy: {self.service.identity.short_fingerprint}")
        self.save_dir_label.setText(self.service.get_save_dir())
        self._update_mode_badge(mode, self.service.tcp_port)
        self._render_peers(self.service.get_peers())
        for rec in self.service.get_transfers():
            self._on_transfer_updated(rec)

    def _update_mode_badge(self, mode: str, port: int) -> None:
        if mode == "everyone":
            self.mode_badge.set_state(f"MỌI NGƯỜI (TLS :{port})" if port else "MỌI NGƯỜI", "ok")
        elif mode == "trusted":
            self.mode_badge.set_state("CHỈ TIN CẬY", "info")
        else:
            self.mode_badge.set_state("ĐANG TẮT", "off")

    def _set_status(self, text: str, error: bool = False) -> None:
        self.status_lbl.setText(text)
        color = "#f87171" if error else "#10b981"
        self.status_lbl.setStyleSheet(f"font-size: 12px; color: {color}; font-weight: 600;")

    # ---- Screen-wide Drag & Drop ----

    def dragEnterEvent(self, event):
        if _extract_dropped_paths(event.mimeData()):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        paths = _extract_dropped_paths(event.mimeData())
        if paths:
            event.acceptProposedAction()
            self.add_staged_paths(paths)
        else:
            event.ignore()

    # ---- Staging Payload ----

    @_safe
    def add_staged_paths(self, paths: list[str]) -> None:
        added = 0
        for raw in paths:
            p = os.path.abspath(raw)
            if not os.path.exists(p) or os.path.islink(p) or p in self._staged_paths:
                continue
            self._staged_paths.append(p)
            added += 1
            kind = "Thư mục" if os.path.isdir(p) else "Tệp"
            item = QListWidgetItem(
                make_svg_icon("folder" if os.path.isdir(p) else "file", size=16, color="#38bdf8"),
                f"[{kind}] {os.path.basename(p.rstrip('/\\'))}  -  Đang tính dung lượng...",
            )
            item.setData(Qt.ItemDataRole.UserRole, p)
            item.setToolTip(p)
            self.staged_list.addItem(item)
            task = _SizeScanTask(p)
            task.done.connect(self._on_path_size_computed)
            task.start_tracked()
        if added:
            self._refresh_staged_summary()
            self._set_status(f"Đã thêm {added} mục vào danh sách chờ gửi.")

    @_safe
    def _on_path_size_computed(self, root_path: str, file_count: int, total_bytes: int) -> None:
        self._staged_sizes[root_path] = (file_count, total_bytes)
        for i in range(self.staged_list.count()):
            item = self.staged_list.item(i)
            if item and item.data(Qt.ItemDataRole.UserRole) == root_path:
                is_dir = os.path.isdir(root_path)
                kind = f"Thư mục - {file_count} tệp" if is_dir else "Tệp"
                item.setText(f"[{kind}] {os.path.basename(root_path.rstrip('/\\'))}  ({format_bytes(total_bytes)})")
                break
        self._refresh_staged_summary()

    def _refresh_staged_summary(self) -> None:
        if not self._staged_paths:
            self.staged_summary_lbl.setText("Chưa chọn tệp nào")
            return
        total_files = sum(self._staged_sizes.get(p, (1, 0))[0] for p in self._staged_paths)
        total_bytes = sum(self._staged_sizes.get(p, (0, 0))[1] for p in self._staged_paths)
        self.staged_summary_lbl.setText(
            f"{len(self._staged_paths)} mục ({total_files} tệp - {format_bytes(total_bytes)})"
        )

    @_safe
    def _on_pick_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Chọn các tệp muốn chia sẻ")
        if files:
            self.add_staged_paths(files)

    @_safe
    def _on_pick_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục muốn chia sẻ")
        if folder:
            self.add_staged_paths([folder])

    @_safe
    def _on_clear_staged(self) -> None:
        self._staged_paths.clear()
        self._staged_sizes.clear()
        self.staged_list.clear()
        self._refresh_staged_summary()

    @_safe
    def _on_remove_selected_staged(self) -> None:
        for item in self.staged_list.selectedItems():
            p = item.data(Qt.ItemDataRole.UserRole)
            if p in self._staged_paths:
                self._staged_paths.remove(p)
            self._staged_sizes.pop(p, None)
            self.staged_list.takeItem(self.staged_list.row(item))
        self._refresh_staged_summary()

    # ---- Settings Actions ----

    @_safe
    def _on_back(self) -> None:
        self.back_requested.emit()

    @_safe
    def _on_device_name_edited(self) -> None:
        self.service.set_device_name(self.name_input.text())
        self.name_input.setText(self.service.get_device_name())
        self._set_status("Đã cập nhật tên hiển thị thiết bị.")

    @_safe
    def _on_mode_changed(self) -> None:
        mode = str(self.mode_combo.currentData() or "everyone")
        self.service.set_mode(mode)
        self._update_mode_badge(mode, self.service.tcp_port)
        self._set_status("Đã cập nhật chế độ hiển thị và nhận tệp.")

    @_safe
    def _on_pin_edited(self) -> None:
        self.service.set_room_pin(self.pin_input.text())
        has_pin = bool(self.pin_input.text().strip())
        self._set_status("Đã bật bảo vệ Mã phòng (PIN)." if has_pin else "Đã tắt Mã phòng (PIN).")

    @_safe
    def _on_choose_save_dir(self) -> None:
        chosen = QFileDialog.getExistingDirectory(self, "Chọn thư mục lưu tệp BobDrop", self.service.get_save_dir())
        if not chosen:
            return
        try:
            self.service.set_save_dir(chosen)
            self.save_dir_label.setText(self.service.get_save_dir())
            self._set_status("Đã đổi thư mục lưu tệp nhận.")
        except ValueError as exc:
            QMessageBox.warning(self, "Thư mục không hợp lệ", str(exc))

    @_safe
    def _on_open_receive_dir(self) -> None:
        folder = self.service.get_save_dir()
        os.makedirs(folder, exist_ok=True)
        self._open_folder_in_explorer(folder)

    def _open_folder_in_explorer(self, folder: str) -> None:
        if os.path.isdir(folder) and sys.platform == "win32" and hasattr(os, "startfile"):
            os.startfile(folder)

    @_safe
    def _on_add_vpn_ip(self) -> None:
        text, ok = QInputDialog.getText(
            self,
            "Thêm thiết bị VPN / ZeroTier thủ công",
            "Nhập địa chỉ IP nội bộ hoặc VPN chung mạng (ví dụ 100.84.10.5 hoặc 26.15.20.8:53319):",
        )
        if not ok or not text.strip():
            return
        ip_part, _, port_part = text.strip().partition(":")
        port = int(port_part) if port_part.isdigit() else DEFAULT_TRANSFER_TCP_PORT
        self._set_status(f"Đang dò kết nối bảo mật tới {ip_part}:{port}...")
        self.service.probe_manual_peer_async(ip_part, port, persist=True)

    @_safe
    def _on_refresh_peers(self) -> None:
        self._set_status("Đang quét lại các card mạng LAN, ZeroTier và VPN...")
        self.service.refresh_peers()

    # ---- Peer Radar & Dispatch ----

    @_safe
    def _on_peers_changed(self, peers: list[PeerInfo]) -> None:
        self._render_peers(peers)

    def _render_peers(self, peers: list[PeerInfo]) -> None:
        online_ids = {p.device_id for p in peers}
        self._selected_peer_ids.intersection_update(online_ids)

        while self.peer_list_layout.count() > 0:
            child = self.peer_list_layout.takeAt(0)
            w = child.widget()
            if w is not None and w is not self.empty_peers_lbl:
                w.deleteLater()

        trusted_map = self.service.get_trusted_peers()
        if not peers:
            self.empty_peers_lbl.show()
            self.peer_list_layout.addWidget(self.empty_peers_lbl)
        else:
            self.empty_peers_lbl.hide()
            for peer in peers:
                pinned = trusted_map.get(peer.device_id)
                is_trusted = bool(
                    pinned and str(pinned.get("fingerprint", "")).lower() == peer.fingerprint.lower()
                )
                card = _PeerCardWidget(
                    peer=peer,
                    checked=(peer.device_id in self._selected_peer_ids),
                    is_trusted=is_trusted,
                    parent=self.peer_container,
                )
                card.selection_toggled.connect(self._on_peer_checked)
                card.send_clicked.connect(self._on_send_single_peer)
                card.files_dropped_on_peer.connect(self._on_files_dropped_on_peer)
                card.untrust_clicked.connect(self._on_untrust_peer)
                self.peer_list_layout.addWidget(card)

        self.peer_list_layout.addStretch()
        self.peer_count_lbl.setText(f"{len(peers)} thiết bị trực tuyến")
        self._update_send_buttons(len(peers))

    @_safe
    def _on_peer_checked(self, device_id: str, checked: bool) -> None:
        if checked:
            self._selected_peer_ids.add(device_id)
        else:
            self._selected_peer_ids.discard(device_id)
        self._update_send_buttons(len(self.service.get_peers()))

    def _update_send_buttons(self, total_peers: int) -> None:
        sel = len(self._selected_peer_ids)
        self.send_selected_btn.setText(f"Gửi người đã chọn ({sel})")
        self.send_selected_btn.setEnabled(sel > 0)
        self.send_all_btn.setText(f"Chia sẻ cho tất cả ({total_peers})")
        self.send_all_btn.setEnabled(total_peers > 0)

    @_safe
    def _on_untrust_peer(self, device_id: str) -> None:
        self.service.untrust_peer(device_id)
        self._render_peers(self.service.get_peers())
        self._set_status("Đã xoá ghim khoá tin cậy của thiết bị.")

    def _resolve_pin_for_targets(self, targets: list[PeerInfo]) -> str | None:
        current_pin = self.pin_input.text().strip() or self.service.get_room_pin()
        if current_pin or not any(p.pin_required for p in targets):
            return current_pin
        pin, ok = QInputDialog.getText(
            self,
            "Yêu cầu Mã phòng (PIN)",
            "Thiết bị nhận đang bật bảo vệ Mã phòng (PIN). Nhập PIN để xác thực:",
            QLineEdit.EchoMode.Password,
        )
        if not ok or not pin.strip():
            return None
        return pin.strip()

    def _dispatch_send(self, paths: list[str], targets: list[PeerInfo]) -> None:
        if not paths:
            QMessageBox.information(
                self,
                "Chưa có tệp",
                "Hãy kéo thả tệp hoặc thư mục vào vùng chia sẻ bên trái trước khi gửi.",
            )
            return
        if not targets:
            QMessageBox.information(self, "Chưa chọn người nhận", "Chưa có thiết bị nhận nào được chọn.")
            return
        pin = self._resolve_pin_for_targets(targets)
        if pin is None:
            return
        self.service.send_to_peers(paths, targets, room_pin=pin)
        self._set_status(f"Đã gửi lời mời nhận tệp tới {len(targets)} thiết bị.")

    @_safe
    def _on_send_single_peer(self, peer: PeerInfo) -> None:
        self._dispatch_send(list(self._staged_paths), [peer])

    @_safe
    def _on_files_dropped_on_peer(self, peer: PeerInfo, dropped_paths: list[str]) -> None:
        self.add_staged_paths(dropped_paths)
        self._dispatch_send(dropped_paths, [peer])

    @_safe
    def _on_send_selected(self) -> None:
        peers = [p for p in self.service.get_peers() if p.device_id in self._selected_peer_ids]
        self._dispatch_send(list(self._staged_paths), peers)

    @_safe
    def _on_send_all(self) -> None:
        peers = self.service.get_peers()
        self._dispatch_send(list(self._staged_paths), peers)

    # ---- Transfer Progress Updates ----

    @_safe
    def _on_transfer_updated(self, record: TransferRecord) -> None:
        self.empty_xfer_lbl.hide()
        row = self._transfer_rows.get(record.transfer_id)
        if row is None:
            row = _TransferRowWidget(record, parent=self.xfer_container)
            row.cancel_clicked.connect(self.service.cancel_transfer)
            row.open_folder_clicked.connect(self._open_folder_in_explorer)
            self._transfer_rows[record.transfer_id] = row
            self.xfer_list_layout.insertWidget(0, row)
        else:
            row.apply_record(record)

    @_safe
    def _on_service_status_changed(self, mode: str, port: int) -> None:
        self._update_mode_badge(mode, port)

    @_safe
    def _on_service_error(self, message: str) -> None:
        self._set_status(message, error=True)
