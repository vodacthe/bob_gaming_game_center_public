"""On-screen keyboard so text fields can be filled with a controller (opened by GamepadNavigator on A).

Plain Qt buttons, so GamepadNavigator drives it like any other dialog. Shortcuts while it is open:
X = backspace, Y = space, LB = Shift, RB = symbols, RT = Enter, Start = hide the keyboard, B = cancel. A physical keyboard
also works. Enter: a new line in a multi-line field; in a one-line field it closes the keyboard and presses
Enter in the field afterwards (sends a chat message, submits a form).

Vietnamese: the keys are plain Latin, so the keyboard composes Telex / VNI itself (app.core.vietnamese). The globe key
opens a small menu: ENG (no composition) / VNI / TLX (Telex); the choice is remembered. Password fields never compose.

Paste: the clipboard key (and Ctrl+V on a physical keyboard) inserts the clipboard text as it is, e.g. a code the chat
overlay copied. One-line fields get its line breaks turned into spaces.

The bottom row is icons only (shift, symbols, language, paste, space, backspace, hide) to keep the keyboard narrow. A
controller shortcut (LB / RB / X / Y / RT / Start) flashes the matching key as pressed, so the player sees what happened.
"""

import json
import logging
import os
import re

import shiboken6
from PySide6.QtCore import QEvent, QPoint, QSize, Qt, QTimer
from PySide6.QtGui import QActionGroup, QColor, QFont, QGuiApplication, QKeyEvent, QKeySequence, QTextCursor
from PySide6.QtWidgets import (
    QApplication, QDialog, QGraphicsDropShadowEffect, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMenu,
    QPlainTextEdit, QPushButton, QTextEdit, QVBoxLayout, QWidget,
)

from app.core import vietnamese
from app.ui.icons import make_svg_icon

logger = logging.getLogger(__name__)

_WORD_BEFORE = re.compile(r"[^\W\d_]+$")
_METHOD_LABELS = {vietnamese.OFF: "ENG", vietnamese.VNI: "VNI", vietnamese.TELEX: "TLX"}   # menu order too
_ICON_SIZE = 20
_ICON_COLOR = "#f1f5f9"
_FLASH_MS = 160          # how long a controller shortcut keeps its key looking pressed
_SETTINGS_FILENAME = "virtual_keyboard.json"


def _clipboard_text() -> str:
    clipboard = QGuiApplication.clipboard()
    return clipboard.text() if clipboard is not None else ""


def _settings_path() -> str:
    import app.config as config   # read at call time so tests can redirect CONFIG_DIR
    return os.path.join(config.CONFIG_DIR, _SETTINGS_FILENAME)


def load_input_method() -> str:
    """The remembered typing method (Telex by default)."""
    try:
        with open(_settings_path(), encoding="utf-8") as f:
            method = json.load(f).get("input_method")
        if method in vietnamese.METHODS:
            return method
    except (OSError, ValueError, AttributeError):
        pass
    return vietnamese.TELEX


def save_input_method(method: str) -> None:
    try:
        os.makedirs(os.path.dirname(_settings_path()), exist_ok=True)
        with open(_settings_path(), "w", encoding="utf-8") as f:
            json.dump({"input_method": method}, f)
    except OSError as e:
        logger.warning(f"[VirtualKeyboard] Could not save the input method: {e}")


_LAYERS = {
    "lower": ("1234567890", "qwertyuiop", "asdfghjkl@", "zxcvbnm.-_"),
    "upper": ("1234567890", "QWERTYUIOP", "ASDFGHJKL@", "ZXCVBNM.-_"),
    "symbols": ("1234567890", "!@#$%^&*()", "-_=+[]{};:", "'\"\\|,.<>/?"),
}

_STYLE = """
    #vkContainer {
        background-color: #0b0e14;
        border: 1px solid rgba(168, 85, 247, 0.45);
        border-radius: 16px;
    }
    QLabel { color: #e2e8f0; background: transparent; border: none; }
    QLabel#vkLegend { color: #94a3b8; font-size: 11px; }
    QLineEdit, QPlainTextEdit {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 8px;
        color: #ffffff;
        font-size: 15px;
        padding: 6px 10px;
    }
    QPushButton {
        background: rgba(255, 255, 255, 0.06);
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 8px;
        color: #f1f5f9;
        font-family: 'Segoe UI', Arial, sans-serif;
        font-size: 15px;
        padding: 0px;
        min-height: 0px;
    }
    QPushButton:hover, QPushButton:focus { background: rgba(139, 92, 246, 0.30); border-color: rgba(192, 132, 252, 0.8); }
    QPushButton:checked { background: rgba(139, 92, 246, 0.55); }
    QPushButton:pressed { background: rgba(192, 132, 252, 0.85); border-color: #f5d0fe; }
    QPushButton:disabled { background: rgba(255, 255, 255, 0.03); border-color: rgba(255, 255, 255, 0.05); }
    QPushButton#vkEnter { background: #7c3aed; border-color: #a855f7; font-weight: bold; font-size: 16px; }
    QPushButton#vkEnter:hover, QPushButton#vkEnter:focus { background: #8b5cf6; border-color: #e9d5ff; }
    QPushButton#vkEnter:pressed { background: #c4b5fd; border-color: #ffffff; color: #1e1b4b; }
"""

_MENU_STYLE = """
    QMenu { background-color: #0b0e14; border: 1px solid rgba(168, 85, 247, 0.55); border-radius: 8px; padding: 4px; }
    QMenu::item { color: #f1f5f9; font-family: 'Segoe UI', Arial, sans-serif; font-size: 15px;
                  padding: 8px 28px 8px 14px; border-radius: 6px; }
    QMenu::item:selected { background: rgba(139, 92, 246, 0.45); }
    QMenu::indicator { width: 14px; height: 14px; }
"""


class VirtualKeyboardDialog(QDialog):
    gamepad_hide_hints = True   # the dialog shows its own legend

    def __init__(self, text: str = "", multiline: bool = False, password: bool = False,
                 title: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Bàn phím ảo")
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._multiline = multiline
        self.submit_requested = False   # Enter was pressed on a one-line field: press Enter in it afterwards
        self._layer = "lower"
        self._key_buttons: list[list[QPushButton]] = []
        self._password = password
        self._method_menu: QMenu | None = None
        self._method = vietnamese.OFF if password else load_input_method()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(16, 16, 16, 16)
        container = QWidget(self)
        container.setObjectName("vkContainer")
        container.setStyleSheet(_STYLE)
        shadow = QGraphicsDropShadowEffect(container)
        shadow.setBlurRadius(36)
        shadow.setOffset(0, 8)
        shadow.setColor(QColor(0, 0, 0, 180))
        container.setGraphicsEffect(shadow)
        outer.addWidget(container)

        layout = QVBoxLayout(container)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(10)

        heading = QLabel(title or "Nhập văn bản")
        heading.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        layout.addWidget(heading)

        if multiline:
            self._edit = QPlainTextEdit()
            self._edit.setPlainText(text)
            self._edit.setFixedHeight(96)
            self._edit.moveCursor(self._edit.textCursor().MoveOperation.End)
        else:
            self._edit = QLineEdit(text)
            if password:
                self._edit.setEchoMode(QLineEdit.EchoMode.Password)
            self._edit.setCursorPosition(len(text))
        self._edit.setFocusPolicy(Qt.FocusPolicy.NoFocus)   # keys keep the focus; typing goes through _insert
        layout.addWidget(self._edit)

        grid = QGridLayout()
        grid.setSpacing(6)
        for r in range(4):
            row = []
            for c in range(10):
                btn = QPushButton()
                btn.setFixedSize(46, 40)
                btn.clicked.connect(lambda _=False, b=btn: self._insert(b.property("ch")))
                grid.addWidget(btn, r, c)
                row.append(btn)
            self._key_buttons.append(row)
        layout.addLayout(grid)

        bottom = QHBoxLayout()
        bottom.setSpacing(6)
        self._shift_btn = self._icon_button("shift", 48, self._toggle_shift, "Shift (LB)", checkable=True)
        self._sym_btn = self._action_button("#+=", 52, self._toggle_symbols, checkable=True)
        self._sym_btn.setToolTip("Ký hiệu (RB)")
        self._lang_btn = self._icon_button("globe", 44, self._choose_method, "")
        self._paste_btn = self._icon_button("clipboard", 44, self._paste, "Dán nội dung đã copy (Ctrl+V)")
        self._space_btn = self._icon_button("space", 60, lambda: self._insert(" "), "Dấu cách (Y)")
        self._back_btn = self._icon_button("backspace", 48, self._backspace, "Xoá (X)")
        self._enter_btn = self._action_button("↵ Enter", 100, self._enter)
        self._enter_btn.setObjectName("vkEnter")      # the main action: the most prominent key
        self._enter_btn.setToolTip("Enter (RT)")
        self._done_btn = self._icon_button("keyboard", 44, self.accept, "Tắt bàn phím (Start)")
        for btn, name in ((self._lang_btn, "vkLang"), (self._paste_btn, "vkPaste"), (self._space_btn, "vkSpace"),
                          (self._back_btn, "vkBackspace"), (self._shift_btn, "vkShift"), (self._sym_btn, "vkSymbols"),
                          (self._done_btn, "vkDone")):
            btn.setObjectName(name)
        bottom.addWidget(self._shift_btn)
        bottom.addWidget(self._sym_btn)
        bottom.addWidget(self._lang_btn)
        bottom.addWidget(self._paste_btn)
        bottom.addWidget(self._space_btn, stretch=1)
        bottom.addWidget(self._back_btn)
        bottom.addWidget(self._enter_btn)
        bottom.addWidget(self._done_btn)       # small "hide keyboard" key, hard to hit by mistake
        layout.addLayout(bottom)

        legend = QLabel("RT: Enter   ·   X: Xoá   ·   Y: Dấu cách   ·   LB: Shift   ·   RB: Ký hiệu   ·   START: Tắt   ·   B: Huỷ")
        legend.setObjectName("vkLegend")
        legend.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(legend)

        self._refresh_keys()
        self._refresh_method()
        self._key_buttons[1][0].setFocus()
        self.adjustSize()

    def _action_button(self, label: str, width: int, slot, checkable: bool = False) -> QPushButton:
        btn = QPushButton(label)
        btn.setMinimumWidth(width)
        btn.setFixedHeight(40)
        btn.setCheckable(checkable)
        btn.clicked.connect(lambda _=False: slot())
        return btn

    def _icon_button(self, icon: str, width: int, slot, tooltip: str, checkable: bool = False) -> QPushButton:
        btn = self._action_button("", width, slot, checkable=checkable)
        btn.setIcon(make_svg_icon(icon, _ICON_SIZE, color=_ICON_COLOR))
        btn.setIconSize(QSize(_ICON_SIZE, _ICON_SIZE))
        btn.setToolTip(tooltip)
        return btn

    # ── editing ──

    def text(self) -> str:
        return self._edit.toPlainText() if self._multiline else self._edit.text()

    def _word_before_cursor(self) -> str:
        if self._multiline:
            cur = self._edit.textCursor()
            before = cur.block().text()[:cur.positionInBlock()]
        else:
            before = self._edit.text()[:self._edit.cursorPosition()]
        m = _WORD_BEFORE.search(before)
        return m.group(0) if m else ""

    def _insert_composed(self, s: str) -> bool:
        """Type `s` as a Telex / VNI key joined to the word before the cursor. False: nothing to compose."""
        if len(s) != 1 or self._method == vietnamese.OFF:
            return False
        word = self._word_before_cursor()
        new = vietnamese.compose(word, s, self._method)
        if new is None:
            return False
        if self._multiline:
            cur = self._edit.textCursor()
            cur.movePosition(QTextCursor.MoveOperation.Left, QTextCursor.MoveMode.KeepAnchor, len(word))
            cur.insertText(new)
            self._edit.setTextCursor(cur)
        else:
            pos = self._edit.cursorPosition()
            self._edit.setSelection(pos - len(word), len(word))
            self._edit.insert(new)
        return True

    def _insert(self, s: str):
        if not s:
            return
        if self._insert_composed(s):
            pass
        elif self._multiline:
            self._edit.insertPlainText(s)
        else:
            self._edit.insert(s)
        if self._layer == "upper":   # one-shot shift, like a phone keyboard
            self._layer = "lower"
            self._refresh_keys()

    def _paste(self):
        """Insert the clipboard text untouched (no Telex / VNI)."""
        text = _clipboard_text()
        if not text:
            return
        if self._multiline:
            self._edit.insertPlainText(text.replace("\r\n", "\n").replace("\r", "\n"))
        else:
            self._edit.insert(" ".join(part.strip() for part in text.splitlines() if part.strip()))
        if self._layer == "upper":
            self._layer = "lower"
            self._refresh_keys()

    def _backspace(self):
        if self._multiline:
            self._edit.textCursor().deletePreviousChar()
        else:
            self._edit.backspace()

    def _enter(self):
        if self._multiline:
            self._insert("\n")
        else:
            self.submit_requested = True
            self.accept()

    def _build_method_menu(self) -> QMenu:
        menu = QMenu(self)
        menu.setStyleSheet(_MENU_STYLE)
        group = QActionGroup(menu)
        group.setExclusive(True)
        for method, label in _METHOD_LABELS.items():
            action = menu.addAction(label)
            action.setCheckable(True)
            action.setChecked(method == self._method)
            action.setData(method)
            group.addAction(action)
            action.triggered.connect(lambda _=False, m=method: self._set_method(m))
        return menu

    def _choose_method(self):
        """The globe key: a small menu above it with ENG / VNI / TLX (the gamepad drives it like any menu)."""
        if self._password:
            return
        menu = self._build_method_menu()
        menu.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self._method_menu = menu
        menu.destroyed.connect(lambda *_: setattr(self, "_method_menu", None))
        menu.popup(self._lang_btn.mapToGlobal(QPoint(0, 0)) - QPoint(0, menu.sizeHint().height() + 4))

    def _set_method(self, method: str):
        if self._password or method not in vietnamese.METHODS:
            return
        self._method = method
        save_input_method(method)
        self._refresh_method()

    def _refresh_method(self):
        self._lang_btn.setEnabled(not self._password)
        self._lang_btn.setToolTip("Kiểu gõ: không dùng cho mật khẩu" if self._password
                                  else f"Kiểu gõ tiếng Việt: {_METHOD_LABELS[self._method]} (bấm để đổi ENG / VNI / TLX)")

    def _toggle_shift(self):
        self._layer = "lower" if self._layer == "upper" else "upper"
        self._refresh_keys()

    def _toggle_symbols(self):
        self._layer = "lower" if self._layer == "symbols" else "symbols"
        self._refresh_keys()

    def _refresh_keys(self):
        rows = _LAYERS[self._layer]
        for r, row in enumerate(self._key_buttons):
            for c, btn in enumerate(row):
                ch = rows[r][c]
                btn.setProperty("ch", ch)
                btn.setText("&&" if ch == "&" else ch)
        self._shift_btn.setChecked(self._layer == "upper")
        self._sym_btn.setChecked(self._layer == "symbols")

    # ── input ──

    def _flash(self, btn: QPushButton):
        """Make `btn` look pressed for a moment (a click made with a controller shortcut has no mouse press)."""
        btn.setDown(True)
        QTimer.singleShot(_FLASH_MS, lambda: btn.setDown(False) if shiboken6.isValid(btn) else None)

    def gamepad_button(self, action: str) -> bool:
        handlers = {"x": (self._backspace, self._back_btn), "y": (lambda: self._insert(" "), self._space_btn),
                    "lb": (self._toggle_shift, self._shift_btn), "rb": (self._toggle_symbols, self._sym_btn),
                    "rt": (self._enter, self._enter_btn), "start": (self.accept, self._done_btn)}
        entry = handlers.get(action)
        if entry is None:
            return False
        fn, btn = entry
        self._flash(btn)
        fn()
        return True

    def keyPressEvent(self, event):
        key = event.key()
        if event.matches(QKeySequence.StandardKey.Paste):
            self._paste()
        elif key == Qt.Key.Key_Backspace:
            self._backspace()
        elif key in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not self._multiline:
            self._enter()
        elif event.text() and event.text().isprintable() and not event.modifiers() & (
                Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier):
            self._insert(event.text())
        else:
            super().keyPressEvent(event)


def edit_with_virtual_keyboard(widget) -> bool:
    """Edit a QLineEdit / QPlainTextEdit / QTextEdit through the on-screen keyboard. True if changed or sent.

    Enter on a one-line field (RT / the Enter key) also presses Enter in the field, e.g. to send a chat message.
    """
    multiline = isinstance(widget, (QPlainTextEdit, QTextEdit))
    if multiline:
        text = widget.toPlainText()
        password = False
        title = widget.placeholderText()
    else:
        text = widget.text()
        password = widget.echoMode() != QLineEdit.EchoMode.Normal
        title = widget.placeholderText()
    dlg = VirtualKeyboardDialog(text, multiline=multiline, password=password, title=title, parent=widget.window())
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return False
    new_text = dlg.text()
    submit = dlg.submit_requested and not multiline
    if new_text == text and not submit:
        return False
    if multiline:
        widget.setPlainText(new_text)
    else:
        widget.setText(new_text)
        if not submit:
            widget.editingFinished.emit()
    widget.setFocus()
    if submit:
        for kind in (QEvent.Type.KeyPress, QEvent.Type.KeyRelease):
            QApplication.sendEvent(widget, QKeyEvent(kind, Qt.Key.Key_Return, Qt.KeyboardModifier.NoModifier, "\r"))
    return True
