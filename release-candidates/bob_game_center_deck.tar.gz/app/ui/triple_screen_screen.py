"""In-app screen for Ghép màn hình (Triple Screen borderless span without Eyefinity / NVIDIA Surround)."""

from __future__ import annotations

import functools
import inspect
import logging
import os
import threading
import time
from typing import Callable

from PySide6.QtCore import QRectF, Qt, QThread, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from app.core.triple_screen.service import TripleScreenService, discover_builtin_executables
from app.core.triple_screen.win32 import (
    MonitorInfo,
    SpanBounds,
    auto_select_horizontal_monitors,
    compute_span_bounds,
    enumerate_monitors,
    launch_executable_direct,
)
from app.ui.game_card import DARK_BTN_STYLE, GREEN_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_icon
from app.ui.screen_header import CONTENT_MARGINS, CONTENT_SPACING, ScreenHeader
from app.ui.styles import CHECK_ICON_PATH

logger = logging.getLogger(__name__)
TAG = "[TripleScreen/UI]"

_STYLE = """
QLabel { color: #e2e8f0; font-size: 13px; background: transparent; border: none; }
QLabel#hint { color: #94a3b8; font-size: 12px; }
QLabel#cardTitle { color: #ffffff; font-size: 14px; font-weight: 700; }
QLabel#gameTitle { color: #ffffff; font-size: 13px; font-weight: 700; }
QLabel#gameProc { color: #94a3b8; font-size: 11px; font-weight: 600; }
QLabel#gamePath { color: #94a3b8; font-size: 12px; }
QLabel#gamePathMissing { color: #e3b341; font-size: 12px; }
QLabel#defaultPill {
    background-color: rgba(139, 92, 246, 0.20);
    color: #c4b5fd;
    border: 1px solid rgba(139, 92, 246, 0.45);
    border-radius: 5px;
    padding: 1px 7px;
    font-size: 10px;
    font-weight: 700;
}
QLabel#boundsInfo {
    color: #cbd5e1;
    font-size: 12px;
    font-weight: 600;
    background-color: rgba(12, 16, 24, 0.72);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 8px;
    padding: 8px 12px;
}
QLabel#statusLine { color: #94a3b8; font-size: 12px; padding: 2px 2px; }
QLabel#statusLine[kind="ok"] { color: #34d399; }
QLabel#statusLine[kind="error"] { color: #f87171; }
QFrame#card {
    background-color: rgba(18, 22, 34, 0.72);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 12px;
}
QFrame#gameRow {
    background-color: rgba(12, 16, 26, 0.72);
    border: 1px solid rgba(255, 255, 255, 0.07);
    border-radius: 10px;
}
QCheckBox { color: #e6edf3; font-size: 13px; font-weight: 600; spacing: 8px; background: transparent; }
QCheckBox::indicator {
    width: 16px; height: 16px; border: 1px solid rgba(255, 255, 255, 0.22);
    border-radius: 4px; background-color: rgba(12, 16, 24, 0.85);
}
QCheckBox::indicator:checked { background-color: #8b5cf6; border: 1px solid #a78bfa; image: url("__CHECK__"); }
""".replace("__CHECK__", CHECK_ICON_PATH)


def _safe(func):
    """Guard UI slots so exceptions are logged and reported in the status line."""
    params = list(inspect.signature(func).parameters.values())[1:]
    accepts_varargs = any(p.kind is inspect.Parameter.VAR_POSITIONAL for p in params)
    max_args = len([p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if not accepts_varargs:
            args = args[:max_args]
        try:
            return func(self, *args, **kwargs)
        except Exception:
            logger.exception(f"{TAG} {func.__name__} failed")
            try:
                if isValid(self) and hasattr(self, "_set_status"):
                    self._set_status("Có lỗi không mong muốn (xem Nhật ký Logs).", kind="error")
            except Exception:
                pass
            return None

    return wrapper


_ui_tasks: set["_Task"] = set()
_ui_tasks_lock = threading.Lock()
_ui_quit_hooked = False


def _stop_ui_tasks_on_quit() -> None:
    with _ui_tasks_lock:
        tasks = list(_ui_tasks)
    for t in tasks:
        t.cancel()
    for t in tasks:
        t.wait(1500)


def _hook_quit() -> None:
    global _ui_quit_hooked
    app = QApplication.instance()
    if app is not None and not _ui_quit_hooked:
        app.aboutToQuit.connect(_stop_ui_tasks_on_quit)
        _ui_quit_hooked = True


class _Task(QThread):
    """Run fn() off the UI thread and emit done(result, error_text)."""

    done = Signal(object, str)

    def __init__(self, fn: Callable[[], object], label: str):
        super().__init__(None)
        self.label = label
        self._fn = fn
        self._cancel = False
        self.setObjectName(f"triple-screen-{label}")

    def cancel(self) -> None:
        self._cancel = True

    def start_tracked(self) -> None:
        _hook_quit()
        with _ui_tasks_lock:
            _ui_tasks.add(self)
        self.finished.connect(self._forget)
        self.start()

    def _forget(self) -> None:
        with _ui_tasks_lock:
            _ui_tasks.discard(self)

    def run(self) -> None:
        started = time.monotonic()
        result, error = None, ""
        try:
            result = self._fn()
        except Exception as exc:
            logger.exception(f"{TAG} task {self.label!r} failed")
            error = str(exc) or exc.__class__.__name__
        else:
            logger.debug(f"{TAG} task {self.label!r} finished in {time.monotonic() - started:.2f}s")
        if not self._cancel:
            try:
                self.done.emit(result, error)
            except Exception:
                logger.debug(f"{TAG} task {self.label!r}: receiver deleted before delivery")


class _MonitorMapWidget(QWidget):
    """Interactive physical monitor layout diagram allowing users to toggle monitors in the span group."""

    selection_changed = Signal(list)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(156)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._monitors: list[MonitorInfo] = []
        self._selected: set[str] = set()
        self._bounds: SpanBounds = SpanBounds(0, 0, 0, 0)
        self._hit_rects: list[tuple[QRectF, str]] = []

    def set_data(self, monitors: list[MonitorInfo], selected_devices: list[str], bounds: SpanBounds) -> None:
        self._monitors = list(monitors)
        self._selected = {d for d in selected_devices if d}
        self._bounds = bounds
        self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            pos = event.position()
            for rect, device in self._hit_rects:
                if rect.contains(pos):
                    if device in self._selected:
                        if len(self._selected) <= 1:
                            return
                        self._selected.remove(device)
                    else:
                        self._selected.add(device)
                    ordered = [m.device for m in self._monitors if m.device in self._selected]
                    self.selection_changed.emit(ordered)
                    return
        super().mouseReleaseEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        outer = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        painter.setBrush(QColor(10, 14, 22, 195))
        painter.setPen(QPen(QColor(255, 255, 255, 22), 1.0))
        painter.drawRoundedRect(outer, 10, 10)

        self._hit_rects = []
        if not self._monitors:
            painter.setPen(QColor("#94a3b8"))
            painter.setFont(QFont("Segoe UI", 10))
            painter.drawText(outer, Qt.AlignmentFlag.AlignCenter, "Không phát hiện được màn hình hiển thị.")
            painter.end()
            return

        min_x = min(m.x for m in self._monitors)
        min_y = min(m.y for m in self._monitors)
        max_x = max(m.x + m.width for m in self._monitors)
        max_y = max(m.y + m.height for m in self._monitors)
        total_w = max(1, max_x - min_x)
        total_h = max(1, max_y - min_y)

        canvas = outer.adjusted(18, 16, -18, -16)
        scale = min(canvas.width() / total_w, canvas.height() / total_h)
        drawn_w = total_w * scale
        drawn_h = total_h * scale
        offset_x = canvas.left() + (canvas.width() - drawn_w) / 2.0
        offset_y = canvas.top() + (canvas.height() - drawn_h) / 2.0

        def _to_widget_rect(x: int, y: int, w: int, h: int) -> QRectF:
            return QRectF(
                offset_x + (x - min_x) * scale,
                offset_y + (y - min_y) * scale,
                max(18.0, w * scale),
                max(18.0, h * scale),
            )

        for idx, m in enumerate(self._monitors, 1):
            r = _to_widget_rect(m.x, m.y, m.width, m.height)
            self._hit_rects.append((r, m.device))
            draw_r = r.adjusted(2.0, 2.0, -2.0, -2.0)
            is_sel = m.device in self._selected

            if is_sel:
                painter.setBrush(QColor(139, 92, 246, 56))
                painter.setPen(QPen(QColor("#8b5cf6"), 1.8))
            else:
                painter.setBrush(QColor(30, 41, 59, 120))
                painter.setPen(QPen(QColor(148, 163, 184, 70), 1.0))
            painter.drawRoundedRect(draw_r, 6, 6)

            title = f"Màn {idx} (Chính)" if m.is_primary else f"Màn {idx}"
            res_text = f"{m.width}x{m.height}"
            pos_text = f"({m.x}, {m.y})"

            painter.setPen(QColor("#ffffff") if is_sel else QColor("#94a3b8"))
            title_font = QFont("Segoe UI", 9, QFont.Weight.Bold)
            painter.setFont(title_font)
            inner = draw_r.adjusted(4, 4, -4, -4)
            if inner.height() >= 48:
                h3 = inner.height() / 3.0
                painter.drawText(QRectF(inner.left(), inner.top(), inner.width(), h3), Qt.AlignmentFlag.AlignCenter, title)
                painter.setFont(QFont("Segoe UI", 8, QFont.Weight.DemiBold))
                painter.setPen(QColor("#c4b5fd") if is_sel else QColor("#64748b"))
                painter.drawText(QRectF(inner.left(), inner.top() + h3, inner.width(), h3), Qt.AlignmentFlag.AlignCenter, res_text)
                painter.setFont(QFont("Segoe UI", 8))
                painter.setPen(QColor("#94a3b8") if is_sel else QColor("#475569"))
                painter.drawText(QRectF(inner.left(), inner.top() + 2 * h3, inner.width(), h3), Qt.AlignmentFlag.AlignCenter, pos_text)
            else:
                painter.drawText(inner, Qt.AlignmentFlag.AlignCenter, f"{title}\n{res_text}")

        if self._bounds.width > 0 and self._bounds.height > 0 and self._selected:
            span_r = _to_widget_rect(self._bounds.x, self._bounds.y, self._bounds.width, self._bounds.height)
            dash_pen = QPen(QColor("#10b981"), 1.6, Qt.PenStyle.DashLine)
            painter.setPen(dash_pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(span_r.adjusted(0.5, 0.5, -0.5, -0.5), 7, 7)

        painter.end()


class TripleScreenScreen(QWidget):
    """Full-screen manager for multi-monitor borderless gaming without Eyefinity / Surround."""

    back_requested = Signal()

    def __init__(
        self,
        service: TripleScreenService,
        library_games_getter: Callable[[], list[dict]] | None = None,
        config_getter: Callable[[], dict] | None = None,
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        self.service = service
        self._library_games_getter = library_games_getter
        self._config_getter = config_getter
        self._monitors: list[MonitorInfo] = []
        self._discover_inflight = False
        self._snap_inflight = False
        self._build_ui()

        self.service.status_changed.connect(self._on_service_status_changed)
        self.service.games_changed.connect(self._on_service_games_changed)
        self.service.game_snapped.connect(self._on_service_game_snapped)
        self.service.snap_resisted.connect(self._on_service_snap_resisted)

    def _card(self, title: str) -> tuple[QFrame, QVBoxLayout]:
        card = QFrame()
        card.setObjectName("card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(20, 16, 20, 18)
        layout.setSpacing(10)
        lbl = QLabel(title)
        lbl.setObjectName("cardTitle")
        layout.addWidget(lbl)
        return card, layout

    def _build_ui(self) -> None:
        self.setStyleSheet(_STYLE)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        header = ScreenHeader(
            "Ghép màn hình",
            "triple_screen",
            subtitle="Chạy trò chơi tràn nhiều màn hình không cần bật Eyefinity hay NVIDIA Surround",
        )
        header.back_requested.connect(self.back_requested.emit)
        self.status_badge = header.add_badge("TẮT TỰ ĐỘNG", "off")
        self.header = header
        root.addWidget(header)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(*CONTENT_MARGINS)
        body_layout.setSpacing(CONTENT_SPACING)

        # Card 1: Monitor layout & background watcher toggle
        mon_card, mon_layout = self._card("Cụm màn hình và Tự động ghép")
        top_controls = QHBoxLayout()
        top_controls.setSpacing(10)

        self.auto_watch_cb = QCheckBox(
            "Tự động theo dõi ngầm (tự ghép cửa sổ ngay cả khi mở game từ Steam hoặc ngoài Desktop)"
        )
        self.auto_watch_cb.setCursor(Qt.CursorShape.PointingHandCursor)
        self.auto_watch_cb.toggled.connect(self._on_auto_watch_toggled)
        top_controls.addWidget(self.auto_watch_cb, stretch=1)

        self.auto_row_btn = QPushButton("Tự chọn hàng ngang")
        self.auto_row_btn.setStyleSheet(DARK_BTN_STYLE)
        self.auto_row_btn.setIcon(make_svg_icon("sliders", size=14, color="#cbd5e1"))
        self.auto_row_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.auto_row_btn.clicked.connect(self._on_auto_select_row)
        top_controls.addWidget(self.auto_row_btn)

        self.refresh_monitors_btn = QPushButton("Làm mới màn hình")
        self.refresh_monitors_btn.setStyleSheet(DARK_BTN_STYLE)
        self.refresh_monitors_btn.setIcon(make_svg_icon("refresh", size=14, color="#cbd5e1"))
        self.refresh_monitors_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.refresh_monitors_btn.clicked.connect(self._on_refresh_monitors)
        top_controls.addWidget(self.refresh_monitors_btn)
        mon_layout.addLayout(top_controls)

        map_hint = QLabel("Bấm trực tiếp lên từng màn hình trong sơ đồ bên dưới để chọn hoặc bỏ màn hình ghép:")
        map_hint.setObjectName("hint")
        mon_layout.addWidget(map_hint)

        self.monitor_map = _MonitorMapWidget(self)
        self.monitor_map.selection_changed.connect(self._on_monitor_selection_changed)
        mon_layout.addWidget(self.monitor_map)

        self.bounds_label = QLabel("")
        self.bounds_label.setObjectName("boundsInfo")
        self.bounds_label.setWordWrap(True)
        mon_layout.addWidget(self.bounds_label)

        body_layout.addWidget(mon_card)

        # Card 2: Game presets & custom .exe launchers
        games_card = QFrame()
        games_card.setObjectName("card")
        self.games_card = games_card
        games_layout = QVBoxLayout(games_card)
        games_layout.setContentsMargins(20, 16, 20, 18)
        games_layout.setSpacing(10)

        games_hdr = QHBoxLayout()
        games_hdr.setSpacing(8)
        games_title = QLabel("Danh sách trò chơi (Mặc định: ETS 2 và ATS)")
        games_title.setObjectName("cardTitle")
        games_hdr.addWidget(games_title)
        games_hdr.addStretch(1)

        self.quick_run_btn = QPushButton("Chọn .exe và chạy")
        self.quick_run_btn.setStyleSheet(PURPLE_BTN_STYLE)
        self.quick_run_btn.setIcon(make_svg_icon("play", size=14, color="#ffffff"))
        self.quick_run_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.quick_run_btn.clicked.connect(self._on_quick_run_clicked)
        games_hdr.addWidget(self.quick_run_btn)

        self.add_exe_btn = QPushButton("Thêm game")
        self.add_exe_btn.setStyleSheet(DARK_BTN_STYLE)
        self.add_exe_btn.setIcon(make_svg_icon("plus", size=14, color="#cbd5e1"))
        self.add_exe_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_exe_btn.clicked.connect(self._on_add_exe_clicked)
        games_hdr.addWidget(self.add_exe_btn)

        self.snap_now_btn = QPushButton("Ghép ngay")
        self.snap_now_btn.setStyleSheet(DARK_BTN_STYLE)
        self.snap_now_btn.setIcon(make_svg_icon("fullscreen", size=14, color="#cbd5e1"))
        self.snap_now_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.snap_now_btn.clicked.connect(self._on_snap_now_clicked)
        games_hdr.addWidget(self.snap_now_btn)

        games_layout.addLayout(games_hdr)
        hint = QLabel(
            "Lưu ý quan trọng: Trong cài đặt Display của game (như BeamNG.drive, Assetto Corsa...), "
            "hãy chọn chế độ Cửa sổ (Window / Windowed — không chọn Fullscreen hay Borderless vì game sẽ khoá cứng 1 màn hình), "
            "sau đó Bob sẽ tự gỡ viền và kéo tràn màn hình. Khi bật Ghép màn hình, Bob cũng tự hook Lossless Scaling "
            "(LSFG / FSR) để xuất đủ nhiều màn hình mà không cần Surround / Eyefinity."
        )
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        games_layout.addWidget(hint)

        self._games_container = QWidget(games_card)
        self._games_list_layout = QVBoxLayout(self._games_container)
        self._games_list_layout.setContentsMargins(0, 4, 0, 0)
        self._games_list_layout.setSpacing(8)
        games_layout.addWidget(self._games_container)

        body_layout.addWidget(games_card)

        self.status_label = QLabel("Sẵn sàng ghép màn hình.")
        self.status_label.setObjectName("statusLine")
        self.status_label.setWordWrap(True)
        body_layout.addWidget(self.status_label)
        body_layout.addStretch()

        scroll.setWidget(body)
        root.addWidget(scroll, stretch=1)

    def _set_status(self, message: str, kind: str = "normal") -> None:
        self.status_label.setText(message)
        self.status_label.setProperty("kind", kind)
        self.status_label.style().unpolish(self.status_label)
        self.status_label.style().polish(self.status_label)

    def _refresh_status_badge(self) -> None:
        if self.service.is_auto_watch_enabled():
            self.status_badge.set_state("TỰ ĐỘNG BẬT", "ok")
        elif self.service.is_watching():
            self.status_badge.set_state("ĐANG CHỜ GAME", "info")
        else:
            self.status_badge.set_state("TẮT TỰ ĐỘNG", "off")

    def _refresh_monitors_ui(self) -> None:
        self._monitors = enumerate_monitors()
        saved_selected = self.service.get_selected_monitors()
        valid_devs = {m.device for m in self._monitors}
        selected = [d for d in saved_selected if d in valid_devs]
        if not selected:
            selected = auto_select_horizontal_monitors(self._monitors)

        bounds, chosen = compute_span_bounds(self._monitors, selected)
        self.monitor_map.set_data(self._monitors, [m.device for m in chosen], bounds)

        if not self._monitors:
            self.bounds_label.setText("Chưa phát hiện được màn hình nào.")
        elif len(self._monitors) == 1:
            m = self._monitors[0]
            self.bounds_label.setText(
                f"Vùng ghép mục tiêu: {bounds.width} x {bounds.height} tại (X={bounds.x}, Y={bounds.y}) "
                f"— Hiện chỉ có 1 màn hình ({m.width}x{m.height}) đang kết nối"
            )
        else:
            self.bounds_label.setText(
                f"Vùng ghép mục tiêu: {bounds.width} x {bounds.height} tại (X={bounds.x}, Y={bounds.y}) "
                f"— Đang ghép {len(chosen)} / {len(self._monitors)} màn hình"
            )

    def _rebuild_game_rows(self) -> None:
        while self._games_list_layout.count():
            item = self._games_list_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

        for entry in self.service.get_games():
            self._games_list_layout.addWidget(self._create_game_row(entry))

    def _create_game_row(self, entry: dict) -> QFrame:
        gid = entry["id"]
        name = str(entry.get("name") or "Game")
        proc = str(entry.get("process_name") or "")
        exe_path = str(entry.get("exe_path") or "").strip()
        is_builtin = bool(entry.get("builtin", False))

        row = QFrame(self._games_container)
        row.setObjectName("gameRow")
        hl = QHBoxLayout(row)
        hl.setContentsMargins(14, 12, 14, 12)
        hl.setSpacing(12)

        cb = QCheckBox(row)
        cb.setChecked(bool(entry.get("enabled", True)))
        cb.setToolTip("Bật hoặc tắt theo dõi ngầm cho trò chơi này")
        cb.setCursor(Qt.CursorShape.PointingHandCursor)
        cb.toggled.connect(lambda checked, g=gid: self._on_game_enabled_toggled(g, checked))
        hl.addWidget(cb, alignment=Qt.AlignmentFlag.AlignTop)

        info_col = QVBoxLayout()
        info_col.setContentsMargins(0, 0, 0, 0)
        info_col.setSpacing(3)

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.setSpacing(8)
        title_lbl = QLabel(name)
        title_lbl.setObjectName("gameTitle")
        title_row.addWidget(title_lbl)

        if is_builtin:
            pill = QLabel("MẶC ĐỊNH")
            pill.setObjectName("defaultPill")
            title_row.addWidget(pill)

        if proc:
            proc_lbl = QLabel(f"({proc})")
            proc_lbl.setObjectName("gameProc")
            title_row.addWidget(proc_lbl)
        title_row.addStretch()
        info_col.addLayout(title_row)

        if exe_path and os.path.isfile(exe_path):
            path_lbl = QLabel(exe_path)
            path_lbl.setObjectName("gamePath")
        elif exe_path:
            path_lbl = QLabel(f"Không tìm thấy file trên đĩa: {exe_path}")
            path_lbl.setObjectName("gamePathMissing")
        else:
            path_lbl = QLabel("Chưa có đường dẫn .exe — Bấm Chọn .exe hoặc bấm Chạy để chọn file")
            path_lbl.setObjectName("gamePathMissing")
        path_lbl.setWordWrap(True)
        path_lbl.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        info_col.addWidget(path_lbl)
        hl.addLayout(info_col, stretch=1)

        pick_btn = QPushButton("Chọn .exe")
        pick_btn.setStyleSheet(DARK_BTN_STYLE)
        pick_btn.setIcon(make_svg_icon("folder", size=14, color="#cbd5e1"))
        pick_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        pick_btn.clicked.connect(lambda _c=False, g=gid: self._on_pick_exe_for_game(g))
        hl.addWidget(pick_btn)

        run_btn = QPushButton("Chạy")
        run_btn.setStyleSheet(GREEN_BTN_STYLE)
        run_btn.setIcon(make_svg_icon("play", size=14, color="#042612"))
        run_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        run_btn.clicked.connect(lambda _c=False, g=gid: self._on_run_game(g))
        hl.addWidget(run_btn)

        if not is_builtin:
            del_btn = QPushButton("Xoá")
            del_btn.setStyleSheet(DARK_BTN_STYLE)
            del_btn.setIcon(make_svg_icon("trash", size=14, color="#f87171"))
            del_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            del_btn.clicked.connect(lambda _c=False, g=gid: self._on_remove_game(g))
            hl.addWidget(del_btn)

        return row

    def _start_dir_for(self, current_exe: str = "") -> str:
        if current_exe and os.path.isdir(os.path.dirname(current_exe)):
            return os.path.dirname(current_exe)
        return os.environ.get("PROGRAMFILES(X86)", os.environ.get("PROGRAMFILES", "C:/"))

    def _prompt_exe_file(self, title: str, start_dir: str = "") -> str:
        chosen, _ = QFileDialog.getOpenFileName(
            self,
            title,
            start_dir or self._start_dir_for(),
            "Tệp thực thi (*.exe);;Tất cả tệp (*.*)",
        )
        return str(chosen or "").strip()

    def _maybe_discover_builtin_exes(self) -> None:
        if self._discover_inflight or os.environ.get("BOBGAMING_TRIPLESCREEN_DISABLE") == "1":
            return
        games = self.service.get_games()
        missing = [
            g for g in games
            if g.get("builtin") and (not g.get("exe_path") or not os.path.isfile(str(g.get("exe_path") or "")))
        ]
        if not missing:
            return

        lib_games = list(self._library_games_getter()) if callable(self._library_games_getter) else []
        cfg = self._config_getter() if callable(self._config_getter) else {}
        cfg_games = dict((cfg or {}).get("games") or {})

        self._discover_inflight = True
        task = _Task(
            lambda: discover_builtin_executables(config_games=cfg_games, library_games=lib_games),
            "discover-builtins",
        )
        task.done.connect(self._on_discover_done)
        task.start_tracked()

    @_safe
    def _on_discover_done(self, result: object, error: str) -> None:
        self._discover_inflight = False
        if not isValid(self) or error or not isinstance(result, dict):
            return
        if result:
            self.service.apply_discovered_executables(result)

    @_safe
    def sync_from_service(self) -> None:
        """Refresh UI widgets from TripleScreenService and current monitors."""
        self.auto_watch_cb.blockSignals(True)
        self.auto_watch_cb.setChecked(self.service.is_auto_watch_enabled())
        self.auto_watch_cb.blockSignals(False)

        self._refresh_status_badge()
        self._refresh_monitors_ui()
        self._rebuild_game_rows()
        self._maybe_discover_builtin_exes()

    @_safe
    def _on_auto_watch_toggled(self, checked: bool) -> None:
        self.service.set_auto_watch(bool(checked))
        self._refresh_status_badge()
        if checked:
            self._set_status("Đã bật tự động theo dõi ngầm cho các game đã chọn.", kind="ok")
        else:
            self._set_status("Đã tắt theo dõi ngầm. Bấm Chạy trên app để tự ghép theo phiên.", kind="normal")

    @_safe
    def _on_monitor_selection_changed(self, devices: list) -> None:
        self.service.set_selected_monitors([str(d) for d in devices])
        self._refresh_monitors_ui()
        self._sync_lossless_async()
        self._set_status("Đã cập nhật cụm màn hình mục tiêu.", kind="ok")

    @_safe
    def _on_auto_select_row(self) -> None:
        self._monitors = enumerate_monitors()
        auto_devs = auto_select_horizontal_monitors(self._monitors)
        self.service.set_selected_monitors(auto_devs)
        self._refresh_monitors_ui()
        self._sync_lossless_async()
        self._set_status("Đã tự động chọn hàng màn hình nằm ngang.", kind="ok")

    def _sync_lossless_async(self) -> None:
        if os.environ.get("BOBGAMING_TRIPLESCREEN_DISABLE") == "1":
            return
        task = _Task(self.service.sync_lossless_hook, "sync-lossless")
        task.start_tracked()

    @_safe
    def _on_refresh_monitors(self) -> None:
        self._refresh_monitors_ui()
        self._set_status(f"Đã quét lại {len(self._monitors)} màn hình đang kết nối.", kind="normal")

    @_safe
    def _on_game_enabled_toggled(self, game_id: str, checked: bool) -> None:
        self.service.set_game_enabled(game_id, bool(checked))

    @_safe
    def _on_pick_exe_for_game(self, game_id: str) -> None:
        entry = self.service.get_game(game_id)
        if entry is None:
            return
        chosen = self._prompt_exe_file(
            f"Chọn file .exe cho {entry['name']}",
            self._start_dir_for(entry.get("exe_path", "")),
        )
        if not chosen:
            return
        self.service.set_game_exe(game_id, chosen)
        self._rebuild_game_rows()
        self._set_status(f"Đã cập nhật đường dẫn .exe cho {entry['name']}.", kind="ok")

    @_safe
    def _on_add_exe_clicked(self) -> None:
        chosen = self._prompt_exe_file("Chọn file .exe của trò chơi để thêm")
        if not chosen:
            return
        entry = self.service.add_custom_game(chosen)
        self._rebuild_game_rows()
        self._set_status(f"Đã thêm {entry['name']} vào danh sách Ghép màn hình.", kind="ok")

    @_safe
    def _on_quick_run_clicked(self) -> None:
        chosen = self._prompt_exe_file("Chọn file .exe để chạy ở chế độ Ghép màn hình")
        if not chosen:
            return
        entry = self.service.add_custom_game(chosen)
        self._rebuild_game_rows()
        self._launch_entry(entry)

    @_safe
    def _on_run_game(self, game_id: str) -> None:
        entry = self.service.get_game(game_id)
        if entry is None:
            return
        exe_path = str(entry.get("exe_path") or "").strip()
        if not exe_path or not os.path.isfile(exe_path):
            chosen = self._prompt_exe_file(
                f"Chọn file thực thi (.exe) cho {entry['name']}",
                self._start_dir_for(exe_path),
            )
            if not chosen:
                return
            updated = self.service.set_game_exe(game_id, chosen)
            if updated is not None:
                entry = updated
            self._rebuild_game_rows()
        self._launch_entry(entry)

    def _launch_entry(self, entry: dict) -> None:
        exe_path = str(entry.get("exe_path") or "").strip()
        if not exe_path or not os.path.isfile(exe_path):
            self._set_status(f"Không tìm thấy file .exe hợp lệ cho {entry.get('name', 'game')}.", kind="error")
            return
        self.service.arm_session_target(entry["id"])
        self._refresh_status_badge()
        game_name = str(entry.get("name") or "Game")
        self._set_status(f"Đang chạy {game_name} và chờ cửa sổ game để ghép màn hình...", kind="ok")
        logger.info(f"{TAG} Starting {game_name!r} directly in Triple Screen mode (exe={exe_path})")
        task = _Task(lambda p=exe_path: launch_executable_direct(p), f"launch-{entry['id']}")
        task.done.connect(lambda res, err, n=game_name: self._on_launch_done(n, res, err))
        task.start_tracked()

    @_safe
    def _on_launch_done(self, game_name: str, result: object, error: str) -> None:
        if not isValid(self):
            return
        if error:
            self._set_status(f"Không thể chạy {game_name}: {error}", kind="error")
            return
        if isinstance(result, tuple) and len(result) >= 2 and not result[0]:
            self._set_status(str(result[1]), kind="error")

    @_safe
    def _on_remove_game(self, game_id: str) -> None:
        if self.service.remove_game(game_id):
            self._rebuild_game_rows()
            self._set_status("Đã xoá trò chơi khỏi danh sách Ghép màn hình.", kind="normal")

    @_safe
    def _on_snap_now_clicked(self) -> None:
        if self._snap_inflight:
            return
        self._snap_inflight = True
        self.snap_now_btn.setEnabled(False)
        self._set_status("Đang tìm cửa sổ game để ghép màn hình...", kind="normal")
        task = _Task(self.service.snap_now, "snap-now")
        task.done.connect(self._on_snap_now_done)
        task.start_tracked()

    @_safe
    def _on_snap_now_done(self, result: object, error: str) -> None:
        self._snap_inflight = False
        if not isValid(self):
            return
        self.snap_now_btn.setEnabled(True)
        if error:
            self._set_status(f"Ghép thất bại: {error}", kind="error")
            return
        if isinstance(result, tuple) and len(result) >= 2:
            ok, msg = bool(result[0]), str(result[1])
            self._set_status(msg, kind="ok" if ok else "error")

    @_safe
    def _on_service_status_changed(self, _watching: bool, _reason: str) -> None:
        if isValid(self):
            self._refresh_status_badge()

    @_safe
    def _on_service_games_changed(self) -> None:
        if isValid(self):
            self._rebuild_game_rows()

    @_safe
    def _on_service_game_snapped(self, game_name: str, bounds: object) -> None:
        if not isValid(self):
            return
        if isinstance(bounds, SpanBounds):
            self._set_status(
                f"Đã ghép {game_name} tràn {bounds.width}x{bounds.height} tại (X={bounds.x}, Y={bounds.y}).",
                kind="ok",
            )

    @_safe
    def _on_service_snap_resisted(self, game_name: str, cur_bounds: object) -> None:
        if not isValid(self):
            return
        if isinstance(cur_bounds, SpanBounds):
            self._set_status(
                f"{game_name} đang tự khoá ở {cur_bounds.width}x{cur_bounds.height} (1 màn hình). "
                "Hãy đổi Display Mode trong game sang Window / Windowed rồi bấm Ghép ngay.",
                kind="error",
            )
