"""Controller tester (like hardwaretester.com/gamepad): identity, every button / axis / hat live, stick circularity
and drift, triggers, battery and a vibration test from light to strong.

Data comes from GamepadMonitor.device_snapshots (the gamepad thread owns SDL); vibration requests go back through
GamepadMonitor.rumble*, so this widget never calls SDL itself. Every slot is guarded: a bad reading is logged and
skipped, it never reaches Qt's event loop.
"""

from __future__ import annotations

import collections
import functools
import logging
import math
import time

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QApplication, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea, QSlider, QSpinBox,
    QVBoxLayout, QWidget,
)

from app.core import gamepad_battery as battery
from app.core import gamepad_tester as gt

logger = logging.getLogger(__name__)
TAG = "[ControllerTester]"

_PANEL = ("QFrame#testerPanel { background-color: rgba(18, 22, 34, 0.75); border: 1px solid rgba(255,255,255,0.08);"
          " border-radius: 10px; } QLabel { background: transparent; border: none; color: #cbd5e1; }")
_BTN = ("QPushButton { background-color: rgba(139, 92, 246, 0.2); color: #e9d5ff; border: 1px solid rgba(139,92,246,0.45);"
        " border-radius: 6px; padding: 3px 8px; font-size: 11px; } QPushButton:hover { background-color: rgba(139, 92, 246, 0.35); }"
        " QPushButton:disabled { color: #64748b; border-color: rgba(255,255,255,0.08); background: transparent; }")
_ACCENT = QColor("#a78bfa")
_PRESSED = QColor("#22c55e")
_IDLE = QColor(255, 255, 255, 40)
_HAT = {0: "—", 1: "↑", 2: "→", 3: "↗", 4: "↓", 6: "↘", 8: "←", 9: "↖", 12: "↙"}


def _guarded(func):
    @functools.wraps(func)
    def wrapper(self, *args):
        try:
            return func(self, *args)
        except Exception:   # noqa: BLE001 - see module docstring
            logger.exception(f"{TAG} {func.__name__} failed")
    return wrapper


def _panel(title: str) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("testerPanel")
    frame.setStyleSheet(_PANEL)
    lay = QVBoxLayout(frame)
    lay.setContentsMargins(12, 8, 12, 10)
    lay.setSpacing(6)
    head = QLabel(title)
    head.setStyleSheet("color: #a78bfa; font-weight: bold; font-size: 11px; letter-spacing: 1px;")
    lay.addWidget(head)
    return frame, lay


# ---------------------------------------------------------------------------------------------------------- drawings

class StickView(QWidget):
    """Stick position, recent trail and the circularity test (slices coloured by how far they miss the circle)."""

    TRAIL = 48

    def __init__(self, title: str):
        super().__init__()
        self.title = title
        self.tracker = gt.CircularityTracker()
        self.x = self.y = 0.0
        self.trail: collections.deque = collections.deque(maxlen=self.TRAIL)
        self.setMinimumSize(150, 176)

    def set_position(self, x: float, y: float) -> None:
        self.x, self.y = x, y
        self.trail.append((x, y))
        self.tracker.add(x, y)
        self.update()

    def reset(self) -> None:
        self.tracker.reset()
        self.trail.clear()
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        size = min(self.width(), self.height() - 36)
        r = size / 2 - 6
        c = QPointF(self.width() / 2, 6 + r)
        p.setPen(QPen(QColor(255, 255, 255, 60), 1.5))
        p.setBrush(QColor(10, 14, 22, 200))
        p.drawEllipse(c, r, r)
        for rect_r in (r * 0.5,):
            p.setPen(QPen(QColor(255, 255, 255, 25), 1, Qt.PenStyle.DashLine))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(c, rect_r, rect_r)
        p.setPen(QPen(QColor(255, 255, 255, 30), 1))
        p.drawLine(QPointF(c.x() - r, c.y()), QPointF(c.x() + r, c.y()))
        p.drawLine(QPointF(c.x(), c.y() - r), QPointF(c.x(), c.y() + r))
        for start, end, reach in self.tracker.slices():      # the circularity wedges
            miss = abs(1.0 - reach)
            color = QColor(34, 197, 94, 110) if miss < 0.05 else QColor(245, 158, 11, 120) if miss < 0.12 \
                else QColor(239, 68, 68, 130)
            path = QPainterPath(c)
            rr = r * min(reach, 1.25)
            path.arcTo(QRectF(c.x() - rr, c.y() - rr, 2 * rr, 2 * rr), -math.degrees(start), -math.degrees(end - start))
            path.closeSubpath()
            p.fillPath(path, color)
        if len(self.trail) > 1:
            pts = [QPointF(c.x() + tx * r, c.y() + ty * r) for tx, ty in self.trail]
            for i in range(1, len(pts)):
                p.setPen(QPen(QColor(167, 139, 250, int(200 * i / len(pts))), 2))
                p.drawLine(pts[i - 1], pts[i])
        dot = QPointF(c.x() + self.x * r, c.y() + self.y * r)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#f8fafc"))
        p.drawEllipse(dot, 5, 5)
        err = self.tracker.error_percent()
        p.setPen(QColor("#e2e8f0"))
        p.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        top = c.y() + r + 4
        p.drawText(QRectF(0, top, self.width(), 14), Qt.AlignmentFlag.AlignCenter, self.title)
        p.setFont(QFont("Segoe UI", 8))
        info = (f"Sai số {err:.1f}%" if err is not None
                else f"Xoay sát mép {self.tracker.covered}/{gt.MIN_BINS_FOR_RESULT}")
        drift = gt.drift(self.x, self.y)
        p.setPen(QColor("#fca5a5") if drift > gt.DRIFT_WARN and err is None and len(self.trail) > 5
                 and all(math.hypot(a, b) > gt.DRIFT_WARN for a, b in list(self.trail)[-5:]) else QColor("#94a3b8"))
        p.drawText(QRectF(0, top + 14, self.width(), 14), Qt.AlignmentFlag.AlignCenter,
                   f"{info} · {self.x:+.2f}, {self.y:+.2f}")
        p.end()


class AxisBar(QWidget):
    """-32768..32767 as a thin bar growing from the centre."""

    def __init__(self):
        super().__init__()
        self._value = 0
        self.setFixedHeight(8)
        self.setMinimumWidth(60)

    def setValue(self, value: int) -> None:
        if value != self._value:
            self._value = int(value)
            self.update()

    def value(self) -> int:
        return self._value

    def paintEvent(self, _e):
        p = QPainter(self)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor(255, 255, 255, 18))
        mid = w / 2
        x = gt.axis_value(self._value) * mid
        p.fillRect(QRectF(min(mid, mid + x), 0, abs(x), h), _ACCENT)
        p.fillRect(QRectF(mid - 0.5, 0, 1, h), QColor(255, 255, 255, 90))
        p.end()


class GamepadDiagram(QWidget):
    """A generic Xbox-layout pad that lights up the standard (SDL game-controller) buttons."""

    def __init__(self):
        super().__init__()
        self.state: gt.DeviceState | None = None
        self.setMinimumSize(250, 175)

    def set_state(self, state: gt.DeviceState | None) -> None:
        self.state = state
        self.update()

    def _pressed(self, name: str) -> bool:
        return bool(self.state and self.state.gc_buttons.get(name))

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        s = min(w / 360, h / 250)
        p.translate((w - 360 * s) / 2, (h - 250 * s) / 2)
        p.scale(s, s)
        outline = QPen(QColor("#94a3b8"), 2)
        st = self.state
        lt, rt = (st.trigger("left"), st.trigger("right")) if st else (0.0, 0.0)
        for x, val, name in ((70, lt, "LT"), (250, rt, "RT")):          # triggers
            rect = QRectF(x, 4, 40, 26)
            p.setPen(outline)
            p.setBrush(QColor(15, 20, 30))
            p.drawRoundedRect(rect, 8, 8)
            if val > 0.01:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(_PRESSED)
                p.drawRoundedRect(QRectF(rect.x(), rect.bottom() - rect.height() * val, rect.width(), rect.height() * val), 8, 8)
            p.setPen(QColor("#e2e8f0"))
            p.drawText(rect, Qt.AlignmentFlag.AlignCenter, f"{name} {int(val * 100)}%")
        for x, name in ((62, "LB"), (242, "RB")):                        # bumpers
            p.setPen(outline)
            p.setBrush(_PRESSED if self._pressed(name) else QColor(15, 20, 30))
            p.drawRoundedRect(QRectF(x, 36, 56, 14), 6, 6)
        body = QPainterPath()                                            # body + grips
        body.moveTo(80, 60)
        body.cubicTo(140, 50, 220, 50, 280, 60)
        body.cubicTo(330, 70, 350, 160, 345, 210)
        body.cubicTo(340, 245, 300, 245, 285, 215)
        body.cubicTo(270, 185, 250, 175, 230, 178)
        body.lineTo(130, 178)
        body.cubicTo(110, 175, 90, 185, 75, 215)
        body.cubicTo(60, 245, 20, 245, 15, 210)
        body.cubicTo(10, 160, 30, 70, 80, 60)
        p.setPen(QPen(QColor("#cbd5e1"), 2.5))
        p.setBrush(QColor(20, 26, 38, 220))
        p.drawPath(body)
        lx, ly = st.stick("left") if st else (0.0, 0.0)
        rx, ry = st.stick("right") if st else (0.0, 0.0)
        for cx, cy, sx, sy, press in ((95, 105, lx, ly, "LS"), (225, 150, rx, ry, "RS")):   # sticks
            p.setPen(outline)
            p.setBrush(QColor(10, 14, 22))
            p.drawEllipse(QPointF(cx, cy), 24, 24)
            p.setBrush(_PRESSED if self._pressed(press) else QColor("#475569"))
            p.drawEllipse(QPointF(cx + sx * 12, cy + sy * 12), 13, 13)
        dx, dy = 140, 150                                                # d-pad
        for name, rect in (("DPadUp", QRectF(dx - 8, dy - 26, 16, 18)), ("DPadDown", QRectF(dx - 8, dy + 8, 16, 18)),
                           ("DPadLeft", QRectF(dx - 26, dy - 8, 18, 16)), ("DPadRight", QRectF(dx + 8, dy - 8, 18, 16))):
            p.setPen(outline)
            p.setBrush(_PRESSED if self._pressed(name) else QColor(15, 20, 30))
            p.drawRoundedRect(rect, 3, 3)
        fx, fy = 265, 105                                                # face buttons
        for name, (ox, oy), color in (("Y", (0, -20), "#facc15"), ("A", (0, 20), "#22c55e"),
                                      ("X", (-20, 0), "#3b82f6"), ("B", (20, 0), "#ef4444")):
            pressed = self._pressed(name)
            p.setPen(QPen(QColor(color), 2))
            p.setBrush(QColor(color) if pressed else QColor(15, 20, 30))
            p.drawEllipse(QPointF(fx + ox, fy + oy), 10, 10)
            p.setPen(QColor("#0b0f17") if pressed else QColor(color))
            p.drawText(QRectF(fx + ox - 10, fy + oy - 10, 20, 20), Qt.AlignmentFlag.AlignCenter, name)
        for name, x in (("Back", 155), ("Guide", 180), ("Start", 205)):    # centre buttons
            p.setPen(outline)
            p.setBrush(_PRESSED if self._pressed(name) else QColor(15, 20, 30))
            p.drawEllipse(QPointF(x, 100), 8 if name == "Guide" else 6, 8 if name == "Guide" else 6)
        if st is None:
            p.setPen(QColor("#94a3b8"))
            p.drawText(QRectF(0, 0, 360, 250), Qt.AlignmentFlag.AlignCenter, "Chưa có tay cầm")
        p.end()


# ---------------------------------------------------------------------------------------------------------- panel

HOLD_EXIT_SECONDS = 1.0     # hold B this long to leave the tester (the pad drives the UI again)


class ControllerTesterPanel(QWidget):
    exit_requested = Signal()   # B held on a controller: leave test mode

    def __init__(self, gamepad, parent=None, clock=time.monotonic):
        super().__init__(parent)
        self._clock = clock
        self._b_since: float | None = None
        self._gamepad = gamepad
        self._devices: list[gt.DeviceState] = []
        self._selected_id: int | None = None
        self._stamps: collections.deque = collections.deque(maxlen=60)
        self._ramp_timers: list[QTimer] = []
        self._build()
        if gamepad is not None:
            gamepad.device_snapshots.connect(self._on_snapshots)

    # ---- lifecycle: snapshots only while visible
    def showEvent(self, e):
        super().showEvent(e)
        self._set_detail(True)

    def hideEvent(self, e):
        self._set_detail(False)
        super().hideEvent(e)

    def _set_detail(self, on: bool) -> None:
        try:
            if self._gamepad is not None:
                self._gamepad.set_detail_enabled(on)
                if not on:
                    self._stop_rumble()
        except Exception:   # noqa: BLE001
            logger.exception(f"{TAG} could not switch the snapshots {'on' if on else 'off'}")

    def cleanup(self) -> None:
        self._set_detail(False)
        if self._gamepad is not None:
            try:
                self._gamepad.device_snapshots.disconnect(self._on_snapshots)
            except (RuntimeError, TypeError):
                pass

    # ---- layout (fits the app's default 1280 x 800 window without scrolling)
    def _build(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()                       # only a fallback for very small windows
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { border: none; background-color: #0a0e17; }")
        outer.addWidget(scroll)
        body = QWidget()
        body.setStyleSheet("background-color: transparent;")
        lay = QVBoxLayout(body)
        lay.setContentsMargins(20, 8, 20, 10)
        lay.setSpacing(8)
        scroll.setWidget(body)

        top = QHBoxLayout()
        top.setSpacing(8)
        self.device_combo = QComboBox()
        self.device_combo.setMinimumWidth(240)
        self.device_combo.currentIndexChanged.connect(self._on_device_picked)
        self.status = QLabel("Đang chờ tay cầm…")
        self.status.setStyleSheet("color: #94a3b8; font-size: 11px;")
        pick = QLabel("Tay cầm:")
        pick.setStyleSheet("color: #cbd5e1; font-size: 11px;")
        top.addWidget(pick)
        top.addWidget(self.device_combo)
        top.addWidget(self.status, 1)
        lay.addLayout(top)

        # row 1: identity | pad | raw inputs
        row1 = QHBoxLayout()
        row1.setSpacing(8)
        info_frame, info_lay = _panel("THÔNG TIN")
        self.info_grid = QGridLayout()
        self.info_grid.setHorizontalSpacing(10)
        self.info_grid.setVerticalSpacing(1)
        self._info: dict[str, QLabel] = {}
        for i, key in enumerate(("Tên", "GUID", "VID:PID", "Phiên bản", "Serial", "Loại", "Kiểu đọc", "Instance / Player",
                                 "Pin", "Rung", "Nút / Trục / Hat", "Tần số cập nhật")):
            k = QLabel(key)
            k.setStyleSheet("color: #64748b; font-size: 10px;")
            v = QLabel("—")
            v.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            v.setStyleSheet("color: #f1f5f9; font-family: Consolas, 'Segoe UI'; font-size: 11px;")
            self.info_grid.addWidget(k, i, 0)
            self.info_grid.addWidget(v, i, 1)
            self._info[key] = v
        copy = QPushButton("Copy")
        copy.setToolTip("Copy GUID")
        copy.setStyleSheet(_BTN)
        copy.clicked.connect(self._copy_guid)
        self.info_grid.addWidget(copy, 1, 2)
        self.info_grid.setColumnStretch(1, 1)
        info_lay.addLayout(self.info_grid)
        info_lay.addStretch()
        row1.addWidget(info_frame, 5)
        diag_frame, diag_lay = _panel("TAY CẦM")
        self.diagram = GamepadDiagram()
        diag_lay.addWidget(self.diagram, 1)
        row1.addWidget(diag_frame, 4)
        raw_frame, raw_lay = _panel("NÚT · TRỤC · HAT (THÔ)")
        self.buttons_grid = QGridLayout()
        self.buttons_grid.setSpacing(3)
        raw_lay.addLayout(self.buttons_grid)
        self.axes_box = QGridLayout()
        self.axes_box.setHorizontalSpacing(6)
        self.axes_box.setVerticalSpacing(2)
        raw_lay.addLayout(self.axes_box)
        self.hats_label = QLabel("Hat: —")
        self.hats_label.setStyleSheet("font-size: 11px;")
        raw_lay.addWidget(self.hats_label)
        raw_lay.addStretch()
        self._button_cells: list[QLabel] = []
        self._axis_rows: list[tuple[QLabel, AxisBar]] = []
        row1.addWidget(raw_frame, 4)
        lay.addLayout(row1, 1)

        # row 2: sticks | vibration
        row2 = QHBoxLayout()
        row2.setSpacing(8)
        stick_frame, stick_lay = _panel("CẦN ANALOG · ĐỘ TRÒN · DRIFT")
        sticks = QHBoxLayout()
        sticks.setSpacing(6)
        self.left_stick, self.right_stick = StickView("Cần trái"), StickView("Cần phải")
        sticks.addWidget(self.left_stick)
        sticks.addWidget(self.right_stick)
        stick_lay.addLayout(sticks, 1)
        reset = QPushButton("Làm lại test độ tròn")
        reset.setStyleSheet(_BTN)
        reset.setToolTip("Xoay từng cần thật chậm, sát mép, vài vòng. Sai số < 5% là tốt; > 10% thường do cần bị mòn "
                         "hoặc vùng chết hình vuông. Thả tay mà chấm không về giữa = drift.")
        reset.clicked.connect(self._reset_circularity)
        stick_lay.addWidget(reset, 0, Qt.AlignmentFlag.AlignLeft)
        row2.addWidget(stick_frame, 5)

        vib_frame, vib_lay = _panel("TEST RUNG")
        self.vib_note = QLabel("")
        self.vib_note.setStyleSheet("color: #fbbf24; font-size: 11px;")
        self.vib_note.setWordWrap(True)
        vib_lay.addWidget(self.vib_note)
        sliders = QGridLayout()
        sliders.setVerticalSpacing(2)
        self.low_slider, self.high_slider = QSlider(Qt.Orientation.Horizontal), QSlider(Qt.Orientation.Horizontal)
        self.low_value, self.high_value = QLabel("50%"), QLabel("50%")
        for row, (name, tip, slider, value) in enumerate((
                ("Motor trái", "Motor nặng, tần số thấp", self.low_slider, self.low_value),
                ("Motor phải", "Motor nhẹ, tần số cao", self.high_slider, self.high_value))):
            slider.setRange(0, 100)
            slider.setValue(50)
            slider.valueChanged.connect(lambda v, lab=value: lab.setText(f"{v}%"))
            label = QLabel(name)
            label.setToolTip(tip)
            label.setStyleSheet("font-size: 11px;")
            value.setStyleSheet("font-size: 11px;")
            value.setFixedWidth(34)
            sliders.addWidget(label, row, 0)
            sliders.addWidget(slider, row, 1)
            sliders.addWidget(value, row, 2)
        self.duration = QSpinBox()
        self.duration.setRange(100, gt.RUMBLE_MAX_MS)
        self.duration.setSingleStep(100)
        self.duration.setValue(1000)
        self.duration.setSuffix(" ms")
        self.duration.setFixedWidth(100)
        dur = QLabel("Thời gian")
        dur.setStyleSheet("font-size: 11px;")
        sliders.addWidget(dur, 2, 0)
        sliders.addWidget(self.duration, 2, 1, Qt.AlignmentFlag.AlignLeft)
        vib_lay.addLayout(sliders)
        buttons = QGridLayout()
        buttons.setSpacing(4)
        self._vib_buttons: list[QPushButton] = []

        def add(label, slot, row, col, tip=""):
            b = QPushButton(label)
            b.setStyleSheet(_BTN)
            if tip:
                b.setToolTip(tip)
            b.clicked.connect(slot)
            buttons.addWidget(b, row, col)
            self._vib_buttons.append(b)
            return b

        for i, (label, low, high) in enumerate(gt.RUMBLE_PRESETS):
            add(label, lambda _=False, lo=low, hi=high: self._rumble(lo, hi), 0, i)
        add("Theo thanh trượt", lambda _=False: self._rumble(self.low_slider.value() / 100,
                                                            self.high_slider.value() / 100), 1, 0)
        add("Tăng dần", lambda _=False: self._ramp(), 1, 1, "Rung từ nhẹ tới mạnh (10 nấc trong 3 giây)")
        add("Chỉ trái", lambda _=False: self._rumble(self.low_slider.value() / 100 or 0.5, 0), 1, 2)
        add("Chỉ phải", lambda _=False: self._rumble(0, self.high_slider.value() / 100 or 0.5), 1, 3)
        self.trigger_btn = add("Rung cò", lambda _=False: self._rumble_triggers(), 1, 4,
                               "Rung cò LT/RT (tay Xbox One / Series)")
        stop = QPushButton("Dừng")
        stop.setStyleSheet(_BTN)
        stop.clicked.connect(lambda _=False: self._stop_rumble())
        buttons.addWidget(stop, 2, 0)
        vib_lay.addLayout(buttons)
        vib_lay.addStretch()
        row2.addWidget(vib_frame, 4)
        lay.addLayout(row2, 1)
        self._render(None)

    # ---- data
    @_guarded
    def _on_snapshots(self, snapshots) -> None:
        self._stamps.append(time.monotonic())
        self._devices = [gt.DeviceState.from_dict(d) for d in snapshots or [] if isinstance(d, dict)]
        ids = [d.instance_id for d in self._devices]
        combo_ids = [self.device_combo.itemData(i) for i in range(self.device_combo.count())]
        if ids != combo_ids:
            self.device_combo.blockSignals(True)
            self.device_combo.clear()
            for d in self._devices:
                self.device_combo.addItem(f"{d.index}: {d.name}", d.instance_id)
            if self._selected_id in ids:
                self.device_combo.setCurrentIndex(ids.index(self._selected_id))
            elif ids:
                self._selected_id = ids[0]
                self.left_stick.reset()
                self.right_stick.reset()
            self.device_combo.blockSignals(False)
            logger.info(f"{TAG} controllers: {[d.name for d in self._devices] or 'none'}")
        self._render(self.selected)
        self._check_hold_b()

    @staticmethod
    def _b_held(d: gt.DeviceState) -> bool:
        if d.is_controller and d.gc_buttons:
            return bool(d.gc_buttons.get("B"))
        return len(d.buttons) > 1 and bool(d.buttons[1])          # raw pads: button 1 is B / Circle nearly everywhere

    def _check_hold_b(self) -> None:
        """Holding B on any controller for HOLD_EXIT_SECONDS leaves the tester, so the pad can drive the UI again."""
        held = any(self._b_held(d) for d in self._devices)
        now = self._clock()
        if not held:
            if self._b_since is not None:
                self._b_since = None
                self.status.setText(f"{self.selected.pressed_count()} nút đang bấm" if self.selected else self.status.text())
            return
        if self._b_since is None:
            self._b_since = now
        progress = (now - self._b_since) / HOLD_EXIT_SECONDS
        if progress >= 1.0:
            self._b_since = None
            logger.info(f"{TAG} B held: leaving the controller tester")
            self.exit_requested.emit()
            return
        self.status.setText(f"Giữ B để thoát chế độ test… {int(progress * 100)}%")

    @property
    def selected(self) -> gt.DeviceState | None:
        return next((d for d in self._devices if d.instance_id == self._selected_id), None)

    @_guarded
    def _on_device_picked(self, index: int) -> None:
        self._selected_id = self.device_combo.itemData(index)
        self._reset_circularity()
        self._render(self.selected)

    def update_rate(self) -> float:
        if len(self._stamps) < 2:
            return 0.0
        span = self._stamps[-1] - self._stamps[0]
        return (len(self._stamps) - 1) / span if span > 0 else 0.0

    def _render(self, d: gt.DeviceState | None) -> None:
        self.diagram.set_state(d)
        if d is None:
            self.status.setText("Chưa phát hiện tay cầm nào — cắm dây hoặc bật Bluetooth rồi bấm một nút")
            for v in self._info.values():
                v.setText("—")
            self._set_vibration_enabled(False, "")
            return
        level = battery.from_sdl(d.power)
        if self._b_since is None:
            self.status.setText(f"{d.pressed_count()} nút đang bấm · giữ B {HOLD_EXIT_SECONDS:g}s để thoát chế độ test")
        info = {
            "Tên": d.name, "GUID": d.guid or "—", "VID:PID": d.vid_pid, "Phiên bản": f"{d.product_version:04X}",
            "Serial": d.serial or "—", "Loại": d.type_label,
            "Kiểu đọc": "SDL GameController (đã có ánh xạ chuẩn)" if d.is_controller else "Joystick thô (chưa có ánh xạ)",
            "Instance / Player": f"{d.instance_id} / {d.player_index if d.player_index >= 0 else '—'}",
            "Pin": f"{battery.ICONS.get(level, '')} {battery.LABELS[level]}".strip(),
            "Rung": ("Có" if d.rumble else "Không") + (" · rung cò" if d.trigger_rumble else ""),
            "Nút / Trục / Hat": f"{len(d.buttons)} / {len(d.axes)} / {len(d.hats)}",
            "Tần số cập nhật": f"{self.update_rate():.0f} Hz",
        }
        for key, value in info.items():
            if self._info[key].text() != value:
                self._info[key].setText(value)
        self._info["Pin"].setToolTip(battery.WIRED_HINT if level == battery.WIRED else "")
        self.left_stick.set_position(*d.stick("left"))
        self.right_stick.set_position(*d.stick("right"))
        self._render_raw(d)
        self._set_vibration_enabled(d.rumble, "" if d.rumble else "Tay cầm này không hỗ trợ rung qua SDL")
        self.trigger_btn.setEnabled(d.trigger_rumble)

    def _render_raw(self, d: gt.DeviceState) -> None:
        if len(self._button_cells) != len(d.buttons):
            for cell in self._button_cells:
                cell.deleteLater()
            self._button_cells = []
            for i in range(len(d.buttons)):
                cell = QLabel(f"B{i}")
                cell.setAlignment(Qt.AlignmentFlag.AlignCenter)
                cell.setFixedSize(34, 20)
                self.buttons_grid.addWidget(cell, i // 7, i % 7)
                self._button_cells.append(cell)
        for i, (cell, value) in enumerate(zip(self._button_cells, d.buttons)):
            style = ("background:#22c55e; color:#0b0f17; border-radius:4px; font-weight:bold; font-size:10px;" if value
                     else "background:rgba(255,255,255,0.05); color:#94a3b8; border-radius:4px; font-size:10px;")
            if cell.property("style_on") != bool(value):
                cell.setStyleSheet(style)
                cell.setProperty("style_on", bool(value))
        if len(self._axis_rows) != len(d.axes):
            for label, bar in self._axis_rows:
                label.deleteLater()
                bar.deleteLater()
            self._axis_rows = []
            for i in range(len(d.axes)):
                label = QLabel()
                label.setStyleSheet("font-family: Consolas; color: #e2e8f0; font-size: 10px;")
                bar = AxisBar()
                self.axes_box.addWidget(label, i, 0)
                self.axes_box.addWidget(bar, i, 1)
                self._axis_rows.append((label, bar))
        for i, ((label, bar), raw) in enumerate(zip(self._axis_rows, d.axes)):
            label.setText(f"AXIS {i}: {gt.axis_value(raw):+.5f}")
            bar.setValue(int(raw))
        self.hats_label.setText("Hat: " + (" ".join(f"H{i} {_HAT.get(v, v)}" for i, v in enumerate(d.hats)) or "—"))

    # ---- actions
    def _set_vibration_enabled(self, on: bool, note: str) -> None:
        for b in self._vib_buttons:
            b.setEnabled(on)
        self.vib_note.setText(note)

    @_guarded
    def _reset_circularity(self, *_):
        self.left_stick.reset()
        self.right_stick.reset()

    @_guarded
    def _copy_guid(self, *_):
        d = self.selected
        if d and d.guid:
            QApplication.clipboard().setText(d.guid)
            self.status.setText("Đã copy GUID")

    @_guarded
    def _rumble(self, low: float, high: float, ms: int | None = None) -> None:
        d = self.selected
        if d is None or self._gamepad is None:
            return
        self._cancel_ramp()
        ms = int(ms or self.duration.value())
        logger.info(f"{TAG} rumble {d.name}: low {low:.0%} high {high:.0%} for {ms} ms")
        self._gamepad.rumble(d.instance_id, gt.motor_value(low), gt.motor_value(high), ms)

    @_guarded
    def _rumble_triggers(self, *_):
        d = self.selected
        if d is None or self._gamepad is None:
            return
        v = gt.motor_value(max(self.low_slider.value(), self.high_slider.value()) / 100 or 0.5)
        self._gamepad.rumble_triggers(d.instance_id, v, v, self.duration.value())

    @_guarded
    def _ramp(self, *_):
        """Light to strong in 10 steps over 3 s: tells how many distinct strengths the motors really have."""
        d = self.selected
        if d is None or self._gamepad is None:
            return
        self._cancel_ramp()
        steps = gt.ramp(10, 3000)
        logger.info(f"{TAG} ramp test on {d.name}")
        for level, start in steps:
            t = QTimer(self)
            t.setSingleShot(True)
            t.timeout.connect(lambda lv=level, iid=d.instance_id: self._gamepad.rumble(
                iid, gt.motor_value(lv), gt.motor_value(lv), 400))
            t.start(start)
            self._ramp_timers.append(t)
        self.status.setText("Đang rung tăng dần từ nhẹ tới mạnh…")

    def _cancel_ramp(self) -> None:
        for t in self._ramp_timers:
            t.stop()
            t.deleteLater()
        self._ramp_timers = []

    @_guarded
    def _stop_rumble(self, *_):
        self._cancel_ramp()
        if self._gamepad is None:
            return
        for d in self._devices:
            if d.rumble:
                self._gamepad.rumble(d.instance_id, 0, 0, 0)
