"""Background loader for chat pictures (images, stickers, emoticons), animated ones included.

Disk / network I/O runs on a small thread pool; decoding and downscaling run on the GUI thread, one
picture per event-loop turn (Qt image decoding from several Python threads can deadlock). Keeps a memory-bounded cache. Failures are remembered so a broken link is not
retried on every repaint.
"""

from __future__ import annotations

import hashlib
import logging
import os
import time
import urllib.request
from bisect import bisect_right
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QImage, QPixmap

from app.ui.steam_chat.animation import decode_frames

logger = logging.getLogger(__name__)

THUMB_MAX_W = 320          # decoded thumbnails are stored at most this big; the overlay scales further
THUMB_MAX_H = 240
_MAX_BYTES = 12 * 1024 * 1024
_TIMEOUT = 15
_CACHE_BYTES = 96 * 1024 * 1024      # decoded frames kept in memory (an animated sticker is a few MB)
_DISK_BYTES = 200 * 1024 * 1024      # downloaded files kept on disk so stickers / emoticons show instantly
_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BobGameCenter-SteamChat"

# 54x54 PNG per emoticon (404 for unknown names); scaled down to the text height when drawn
EMOTICON_URL = "https://community.fastly.steamstatic.com/economy/emoticonlarge/"

LOADING = "loading"
READY = "ready"
FAILED = "failed"


def emoticon_url(name: str) -> str:
    return EMOTICON_URL + name


def is_emoticon_url(url: str) -> bool:
    return url.startswith(EMOTICON_URL)


def default_disk_dir() -> str:
    import app.config as config   # read at call time so tests can redirect CONFIG_DIR
    return os.path.join(config.CONFIG_DIR, "cache", "steam_chat")


def prune_disk(folder: str, max_bytes: int = _DISK_BYTES) -> None:
    """Delete the oldest files until the folder fits in `max_bytes`."""
    try:
        files = [e for e in os.scandir(folder) if e.is_file()]
    except OSError:
        return
    stats = sorted(((e.stat().st_mtime, e.stat().st_size, e.path) for e in files))
    total = sum(size for _t, size, _p in stats)
    for _t, size, path in stats:
        if total <= max_bytes:
            break
        try:
            os.remove(path)
            total -= size
        except OSError:
            pass


def download(url: str) -> bytes | None:
    if not url.lower().startswith(("https://", "http://")):
        return None
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
        data = resp.read(_MAX_BYTES + 1)
    return data if len(data) <= _MAX_BYTES else None


def _decode(data: bytes | None) -> list[tuple[QImage, int]]:
    """GUI thread only: frames scaled down to thumbnail size.

    Decoding with Qt from worker threads deadlocked the app (Qt image code in several Python threads vs.
    the GIL; reproduced when a warm disk cache made many decodes start at once), so workers only do I/O.
    """
    frames = decode_frames(data) if data else []
    out = []
    for image, delay in frames:
        if image.width() > THUMB_MAX_W or image.height() > THUMB_MAX_H:
            image = image.scaled(THUMB_MAX_W, THUMB_MAX_H, Qt.AspectRatioMode.KeepAspectRatio,
                                 Qt.TransformationMode.SmoothTransformation)
        out.append((image, delay))
    return out


class _Entry:
    __slots__ = ("frames", "ends", "total", "cost")

    def __init__(self, frames: list[tuple[QImage, int]]):
        self.frames = [QPixmap.fromImage(img) for img, _d in frames]
        self.ends, t = [], 0
        for _img, delay in frames:
            t += delay
            self.ends.append(t)
        self.total = t
        self.cost = sum(img.width() * img.height() * 4 for img, _d in frames)

    def frame_at(self, now_ms: int) -> QPixmap:
        if len(self.frames) == 1 or self.total <= 0:
            return self.frames[0]
        return self.frames[bisect_right(self.ends, now_ms % self.total)]


class ImageCache(QObject):
    """`pixmap(url)` returns the picture (the current frame if animated) or None and starts loading it.

    Emits `loaded(url)` when a download finishes, successfully or not.
    """

    loaded = Signal(str)
    _sig_done = Signal(str, object, bool)     # url, raw bytes or None, came from the disk cache

    def __init__(self, parent=None, fetch=download, max_bytes: int = _CACHE_BYTES, workers: int = 3,
                 clock=time.monotonic, disk_dir: str | None = None):
        super().__init__(parent)
        self._fetch = fetch
        self._disk_dir = disk_dir
        self._max_bytes = max_bytes
        self._clock = clock
        self._state: dict[str, str] = {}
        self._entries: OrderedDict[str, _Entry] = OrderedDict()
        self._bytes = 0
        self._decode_queue: list[tuple[str, bytes | None, bool]] = []
        self._decode_scheduled = False
        self._pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="SteamChat-Img")
        self._sig_done.connect(self._on_done)
        if disk_dir:
            self._pool.submit(prune_disk, disk_dir)

    def state(self, url: str) -> str | None:
        return self._state.get(url)

    def settled(self, url: str) -> bool:
        """Loaded or given up on: drawing it now will not change once the download finishes."""
        return self._state.get(url) in (READY, FAILED)

    def is_animated(self, url: str) -> bool:
        entry = self._entries.get(url)
        return entry is not None and len(entry.frames) > 1

    def pixmap(self, url: str) -> QPixmap | None:
        entry = self._entries.get(url)
        if entry is not None:
            self._entries.move_to_end(url)
            return entry.frame_at(int(self._clock() * 1000))
        if url not in self._state:
            self.request(url)
        return None

    def request(self, url: str) -> None:
        if url in self._state and self._state[url] != FAILED:
            return
        self._state[url] = LOADING
        try:
            self._pool.submit(self._work, url)
        except RuntimeError:            # pool shut down
            self._state[url] = FAILED

    def shutdown(self) -> None:
        self._pool.shutdown(wait=False, cancel_futures=True)

    def _disk_path(self, url: str) -> str:
        return os.path.join(self._disk_dir, hashlib.sha1(url.encode("utf-8")).hexdigest())

    def _read_disk(self, url: str) -> bytes | None:
        if not self._disk_dir:
            return None
        try:
            with open(self._disk_path(url), "rb") as f:
                return f.read()
        except OSError:
            return None

    def _write_disk(self, url: str, data: bytes) -> None:
        if not self._disk_dir:
            return
        try:
            os.makedirs(self._disk_dir, exist_ok=True)
            path = self._disk_path(url)
            with open(path + ".tmp", "wb") as f:
                f.write(data)
            os.replace(path + ".tmp", path)
        except OSError as e:
            logger.debug(f"[SteamChat] Could not cache image on disk: {e}")

    def _work(self, url: str, use_disk: bool = True) -> None:
        """Worker thread: I/O only (disk cache, then network). Decoding happens on the GUI thread."""
        data = self._read_disk(url) if use_disk else None
        from_disk = bool(data)
        if not data:
            try:
                data = self._fetch(url)
            except Exception as e:
                logger.debug(f"[SteamChat] Image download failed ({url}): {e}")
                data = None
        try:
            self._sig_done.emit(url, data, from_disk)
        except RuntimeError:            # cache deleted while downloading
            pass

    def _on_done(self, url: str, data, from_disk: bool) -> None:
        self._decode_queue.append((url, data, from_disk))
        if not self._decode_scheduled:
            self._decode_scheduled = True
            QTimer.singleShot(0, self._decode_next)

    def _decode_next(self) -> None:
        """One picture per event-loop turn so a burst of cached pictures does not stall the UI."""
        self._decode_scheduled = False
        if not self._decode_queue:
            return
        url, data, from_disk = self._decode_queue.pop(0)
        frames = _decode(data)
        if self._decode_queue:
            self._decode_scheduled = True
            QTimer.singleShot(0, self._decode_next)
        if not frames and from_disk:    # corrupt cache file: download it again
            try:
                self._pool.submit(self._work, url, False)
                return
            except RuntimeError:
                pass
        if frames and data and not from_disk:
            try:
                self._pool.submit(self._write_disk, url, data)
            except RuntimeError:
                pass
        self._store(url, frames)

    def _store(self, url: str, frames) -> None:
        old = self._entries.pop(url, None)
        if old is not None:
            self._bytes -= old.cost
        if not frames:
            self._state[url] = FAILED
        else:
            entry = _Entry(frames)
            self._state[url] = READY
            self._entries[url] = entry
            self._bytes += entry.cost
            while self._bytes > self._max_bytes and len(self._entries) > 1:
                gone, evicted = self._entries.popitem(last=False)
                self._bytes -= evicted.cost
                self._state.pop(gone, None)
        self.loaded.emit(url)
