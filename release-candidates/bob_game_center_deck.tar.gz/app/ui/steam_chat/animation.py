"""Decode chat pictures into frames: animated PNG (Steam stickers), GIF / WebP, or a single still image.

Qt has no APNG reader, so APNG is decoded here: every frame's fdAT/IDAT data is re-wrapped as a tiny
standalone PNG for QImage, then composited onto a canvas following the frame's blend / dispose ops.
"""

from __future__ import annotations

import struct
import zlib

from PySide6.QtCore import QBuffer, QByteArray, QIODevice, QRect, Qt
from PySide6.QtGui import QImage, QImageReader, QPainter

_PNG_SIG = b"\x89PNG\r\n\x1a\n"
MAX_FRAMES = 240
_MIN_DELAY_MS = 20          # browsers treat 0-10 ms frame delays as "fast": use 100 ms like they do
_DEFAULT_DELAY_MS = 100

# APNG fcTL dispose / blend ops
_DISPOSE_BACKGROUND = 1
_DISPOSE_PREVIOUS = 2
_BLEND_SOURCE = 0


def _delay(ms: float) -> int:
    return _DEFAULT_DELAY_MS if ms <= 10 else max(_MIN_DELAY_MS, int(ms))


def _chunks(data: bytes):
    pos = len(_PNG_SIG)
    while pos + 8 <= len(data):
        length, ctype = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + length]
        if len(body) < length:
            return
        yield ctype, body
        pos += 12 + length
        if ctype == b"IEND":
            return


def _chunk(ctype: bytes, body: bytes) -> bytes:
    return struct.pack(">I", len(body)) + ctype + body + struct.pack(">I", zlib.crc32(ctype + body) & 0xFFFFFFFF)


def is_apng(data: bytes) -> bool:
    if not data.startswith(_PNG_SIG):
        return False
    for ctype, _body in _chunks(data):
        if ctype == b"acTL":
            return True
        if ctype == b"IDAT":
            return False
    return False


def decode_apng(data: bytes) -> list[tuple[QImage, int]]:
    """Fully composited frames with their delays (ms). Empty list when the data cannot be decoded."""
    ihdr = b""
    shared: list[tuple[bytes, bytes]] = []      # PLTE / tRNS / colour chunks every frame needs
    frames: list[dict] = []
    current: dict | None = None
    seen_idat = False
    for ctype, body in _chunks(data):
        if ctype == b"IHDR":
            ihdr = body
        elif ctype == b"fcTL" and len(body) >= 26:
            w, h, x, y, num, den, dispose, blend = struct.unpack(">IIIIHHBB", body[4:26])
            current = {"w": w, "h": h, "x": x, "y": y, "dispose": dispose, "blend": blend,
                       "delay": _delay(num * 1000 / (den or 100)), "data": []}
            frames.append(current)
            if len(frames) > MAX_FRAMES:
                break
        elif ctype == b"IDAT":
            seen_idat = True
            if current is not None:             # IDAT before any fcTL is a fallback image, not a frame
                current["data"].append(body)
        elif ctype == b"fdAT":
            if current is not None:
                current["data"].append(body[4:])
        elif not seen_idat and current is None and ctype not in (b"acTL", b"IEND"):
            shared.append((ctype, body))
    if len(ihdr) != 13 or not frames:
        return []

    width, height = struct.unpack(">II", ihdr[:8])
    canvas = QImage(width, height, QImage.Format.Format_ARGB32_Premultiplied)
    canvas.fill(Qt.GlobalColor.transparent)
    out: list[tuple[QImage, int]] = []
    for f in frames[:MAX_FRAMES]:
        if not f["data"]:
            continue
        png = (_PNG_SIG + _chunk(b"IHDR", struct.pack(">II", f["w"], f["h"]) + ihdr[8:])
               + b"".join(_chunk(t, b) for t, b in shared)
               + _chunk(b"IDAT", b"".join(f["data"])) + _chunk(b"IEND", b""))
        part = QImage.fromData(png)
        if part.isNull():
            continue
        area = QRect(f["x"], f["y"], f["w"], f["h"])
        before = canvas.copy() if f["dispose"] == _DISPOSE_PREVIOUS else None
        p = QPainter(canvas)
        if f["blend"] == _BLEND_SOURCE:
            p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Source)
        p.drawImage(area.topLeft(), part)
        p.end()
        out.append((canvas.copy(), f["delay"]))
        if f["dispose"] == _DISPOSE_BACKGROUND:
            p = QPainter(canvas)
            p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Clear)
            p.fillRect(area, Qt.GlobalColor.transparent)
            p.end()
        elif before is not None:
            canvas = before
    return out


def _decode_with_qt(data: bytes) -> list[tuple[QImage, int]]:
    buf = QBuffer()
    buf.setData(QByteArray(data))
    buf.open(QIODevice.OpenModeFlag.ReadOnly)
    reader = QImageReader(buf)
    frames: list[tuple[QImage, int]] = []
    while len(frames) < MAX_FRAMES:
        image = reader.read()
        if image.isNull():
            break
        frames.append((image, _delay(reader.nextImageDelay())))
        if not reader.supportsAnimation() or not reader.canRead():
            break
    return frames


def decode_frames(data: bytes) -> list[tuple[QImage, int]]:
    """Frames of any picture Qt can read plus APNG; one frame for still images, [] if undecodable."""
    if not data:
        return []
    if is_apng(data):
        frames = decode_apng(data)
        if frames:
            return frames
    return _decode_with_qt(data)
