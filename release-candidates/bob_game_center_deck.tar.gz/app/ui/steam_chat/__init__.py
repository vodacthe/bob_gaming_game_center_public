"""Steam Chat Overlay UI: in-game chat box (overlay.py), global hotkeys, controller and settings screen."""
