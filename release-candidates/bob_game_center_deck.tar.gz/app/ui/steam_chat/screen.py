"""In-app screen for the Steam Chat Overlay: Steam connection, chat room picker and overlay options."""

from __future__ import annotations

import logging
import os
import threading

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QKeySequence
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QKeySequenceEdit,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from app.config import get_app_dir
from app.core.steam_chat import steam_debug
from app.core.steam_chat.gametools import normalize_keywords
from app.core.steam_chat.models import BridgeState, BridgeStatus
from app.core.steam_chat.settings import (
    FILTER_ALL,
    FILTER_MENTIONS,
    SHOW_MODE_ALWAYS,
    SHOW_MODE_GAME,
    SOUND_ALL,
    SOUND_MENTION,
    SOUND_OFF,
)
from app.ui.gamepad_monitor import GamepadMonitor
from app.ui.icons import make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader
from app.ui.steam_chat.controller import HOTKEY_CHAT, HOTKEY_TOGGLE, SteamChatController, status_text

logger = logging.getLogger(__name__)

CHECK_ICON_PATH = os.path.join(get_app_dir(), "assets", "checkbox_check.svg").replace("\\", "/")

_GREEN, _GREY, _AMBER, _RED, _BLUE = "#2ed573", "#8b949e", "#d29922", "#ff4757", "#388bfd"

_STATE_COLORS = {
    BridgeState.CONNECTED: _GREEN,
    BridgeState.CONNECTING: _BLUE,
    BridgeState.NOT_READY: _BLUE,
    BridgeState.NO_ROOM: _AMBER,
    BridgeState.RESTART_REQUIRED: _AMBER,
    BridgeState.DEBUG_DISABLED: _AMBER,
    BridgeState.STEAM_NOT_RUNNING: _GREY,
    BridgeState.STOPPED: _GREY,
    BridgeState.PORT_CONFLICT: _RED,
    BridgeState.ERROR: _RED,
}

_ATTACHED_STATES = (BridgeState.CONNECTED, BridgeState.NO_ROOM)

_STYLE = """
QLabel { color: #e2e8f0; font-size: 13px; background: transparent; border: none; }
QLabel#hint { color: #8b949e; font-size: 12px; }
QLabel#cardTitle { color: #ffffff; font-size: 14px; font-weight: bold; }
QFrame#card { background-color: rgba(18, 22, 34, 0.7); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 12px; }
QCheckBox { color: #e6edf3; font-size: 13px; font-weight: bold; spacing: 8px; background: transparent; }
QCheckBox::indicator {
    width: 16px; height: 16px; border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 4px; background-color: rgba(12, 16, 24, 0.8);
}
QCheckBox::indicator:checked { background-color: #8b5cf6; border: 1px solid #a78bfa; image: url("__CHECK__"); }
QSpinBox, QKeySequenceEdit QLineEdit {
    background-color: rgba(12, 16, 24, 0.85); color: #e2e8f0; border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 6px; padding: 4px 8px; min-height: 22px;
}
QPushButton {
    background-color: rgba(255, 255, 255, 0.05); color: #cbd5e1; border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 6px;
    padding: 6px 14px; font-size: 12px; font-weight: bold;
}
QPushButton:hover { background-color: rgba(255, 255, 255, 0.1); color: #ffffff; border-color: rgba(139, 92, 246, 0.5); }
QPushButton:disabled { color: #475569; border-color: rgba(255, 255, 255, 0.04); }
QPushButton#primaryBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8b5cf6, stop:1 #6d28d9); color: #ffffff;
    border: 1px solid rgba(168, 85, 247, 0.6);
}
QPushButton#primaryBtn:hover { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #a855f7, stop:1 #7c3aed); }
QLabel#comboDisplay {
    background-color: rgba(12, 16, 24, 0.85); color: #e2e8f0; border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 6px; padding: 6px 8px;
}
QLabel#comboDisplay[recording="true"] { border-color: #f5d061; color: #f5d061; }
""".replace("__CHECK__", CHECK_ICON_PATH)


class SteamChatScreen(QWidget):
    back_requested = Signal()
    _restart_done = Signal(bool)

    def __init__(self, controller: SteamChatController, parent=None):
        super().__init__(parent)
        self.controller = controller
        self._groups = []
        self._loading_groups = False
        self._gamepad = controller.gamepad
        self._recording: str | None = None       # HOTKEY_CHAT / HOTKEY_TOGGLE while recording a controller combo
        self._gp_display: dict[str, QLabel] = {}
        self._gp_record_btn: dict[str, QPushButton] = {}
        self._gp_clear_btn: dict[str, QPushButton] = {}
        self.setStyleSheet(_STYLE)
        self._build()
        self._load_from_settings()

        controller.status_changed.connect(self._on_status)
        controller.probe_finished.connect(self._on_status)
        controller.groups_loaded.connect(self._on_groups_loaded)
        controller.groups_failed.connect(self._on_groups_failed)
        controller.hotkeys_changed.connect(self._on_hotkeys_changed)
        self._restart_done.connect(self._on_restart_done)
        self._on_status(controller.status)
        self._on_hotkeys_changed(controller.hotkey_ok)
        if self._gamepad is not None:
            self._gamepad.buttons_changed.connect(self._on_gp_buttons)
            self._gamepad.gamepad_connected.connect(self._update_gp_status)
            self._gamepad.gamepad_disconnected.connect(self._update_gp_status)
        self._update_gp_status()

    # ---- layout -------------------------------------------------------------------------------------
    def _card(self, title: str) -> tuple[QFrame, QVBoxLayout]:
        card = QFrame()
        card.setObjectName("card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(20, 16, 20, 18)
        layout.setSpacing(10)
        label = QLabel(title)
        label.setObjectName("cardTitle")
        layout.addWidget(label)
        return card, layout

    @staticmethod
    def _hint(text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("hint")
        label.setWordWrap(True)
        return label

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        header = ScreenHeader("Steam Chat Overlay", "chat")
        header.back_requested.connect(self.back_requested.emit)
        self.badge = header.add_badge("", "off")
        root.addWidget(header)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        body = QWidget()
        body.setStyleSheet("background: transparent;")
        content = QVBoxLayout(body)
        content.setContentsMargins(*CONTENT_MARGINS)
        content.setSpacing(18)

        # 1. Master switch
        card, lay = self._card("Khung chat trong game")
        self.enabled_cb = QCheckBox("Bật Steam Chat Overlay")
        self.enabled_cb.toggled.connect(self._on_enabled_toggled)
        lay.addWidget(self.enabled_cb)
        lay.addWidget(self._hint(
            "Hiện tin nhắn của một kênh chat nhóm Steam ở góc trái màn hình khi đang chơi game, và trả lời "
            "ngay trong game. Tin nhắn được gửi bằng chính tài khoản Steam đang đăng nhập. "
            "Game cần chạy ở chế độ Borderless / Windowed (fullscreen độc quyền sẽ che overlay)."))
        content.addWidget(card)

        # 2. Steam connection
        card, lay = self._card("Kết nối Steam")
        row = QHBoxLayout()
        self.status_dot = QLabel("●")
        row.addWidget(self.status_dot)
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        row.addWidget(self.status_label, 1)
        lay.addLayout(row)
        buttons = QHBoxLayout()
        self.enable_debug_btn = QPushButton("Bật kết nối với Steam")
        self.enable_debug_btn.setObjectName("primaryBtn")
        self.enable_debug_btn.clicked.connect(self._on_enable_debug)
        buttons.addWidget(self.enable_debug_btn)
        self.restart_btn = QPushButton("Khởi động lại Steam")
        self.restart_btn.clicked.connect(self._on_restart_steam)
        buttons.addWidget(self.restart_btn)
        self.disable_debug_btn = QPushButton("Tắt kết nối")
        self.disable_debug_btn.clicked.connect(self._on_disable_debug)
        buttons.addWidget(self.disable_debug_btn)
        self.recheck_btn = QPushButton("Kiểm tra lại")
        self.recheck_btn.clicked.connect(self._recheck)
        buttons.addWidget(self.recheck_btn)
        buttons.addStretch()
        lay.addLayout(buttons)
        lay.addWidget(self._hint(
            "Overlay đọc và gửi chat qua chính Steam client đang chạy (chế độ debug CEF của Steam, chỉ mở "
            "trên 127.0.0.1:8080 — không cần đăng nhập lại). Bật lần đầu cần khởi động lại Steam. "
            "Lưu ý: khi chế độ này bật, các chương trình khác trên máy cũng có thể điều khiển Steam qua cổng "
            "đó; bấm \"Tắt kết nối\" nếu không dùng nữa."))
        content.addWidget(card)

        # 3. Chat room
        card, lay = self._card("Kênh chat")
        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(8)
        grid.addWidget(QLabel("Nhóm chat"), 0, 0)
        self.group_combo = QComboBox()
        self.group_combo.currentIndexChanged.connect(self._on_group_changed)
        grid.addWidget(self.group_combo, 0, 1)
        grid.addWidget(QLabel("Kênh"), 1, 0)
        self.room_combo = QComboBox()
        self.room_combo.currentIndexChanged.connect(self._on_room_changed)
        grid.addWidget(self.room_combo, 1, 1)
        self.reload_btn = QPushButton("Tải danh sách")
        self.reload_btn.clicked.connect(self._reload_groups)
        grid.addWidget(self.reload_btn, 0, 2)
        grid.setColumnStretch(1, 1)
        lay.addLayout(grid)
        self.groups_hint = self._hint("")
        lay.addWidget(self.groups_hint)
        content.addWidget(card)

        # 4. Overlay options
        card, lay = self._card("Tuỳ chỉnh overlay")
        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(8)
        r = 0
        grid.addWidget(QLabel("Hiển thị"), r, 0)
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("Chỉ khi đang chơi game (toàn màn hình / borderless)", SHOW_MODE_GAME)
        self.mode_combo.addItem("Luôn hiển thị trên mọi cửa sổ", SHOW_MODE_ALWAYS)
        grid.addWidget(self.mode_combo, r, 1, 1, 2)
        r += 1
        grid.addWidget(QLabel("Phím mở ô chat"), r, 0)
        self.chat_key = self._key_edit()
        grid.addWidget(self.chat_key, r, 1)
        self.chat_key_state = QLabel("")
        grid.addWidget(self.chat_key_state, r, 2)
        r += 1
        grid.addWidget(QLabel("Phím ẩn / hiện overlay"), r, 0)
        self.toggle_key = self._key_edit()
        grid.addWidget(self.toggle_key, r, 1)
        self.toggle_key_state = QLabel("")
        grid.addWidget(self.toggle_key_state, r, 2)
        r += 1
        for name, label in ((HOTKEY_CHAT, "Tay cầm: mở ô chat"), (HOTKEY_TOGGLE, "Tay cầm: ẩn / hiện")):
            grid.addWidget(QLabel(label), r, 0)
            grid.addWidget(self._gamepad_row(name), r, 1, 1, 2)
            r += 1
        self.gp_status = self._hint("")
        grid.addWidget(self.gp_status, r, 1, 1, 2)
        r += 1
        grid.addWidget(QLabel("Tin nhắn hiện lên"), r, 0)
        self.filter_combo = QComboBox()
        self.filter_combo.addItem("Mọi tin nhắn mới", FILTER_ALL)
        self.filter_combo.addItem("Chỉ tin có tag mình (@tên, @all, @online)", FILTER_MENTIONS)
        grid.addWidget(self.filter_combo, r, 1, 1, 2)
        r += 1
        grid.addWidget(QLabel("Âm báo"), r, 0)
        self.sound_combo = QComboBox()
        self.sound_combo.addItem("Tắt", SOUND_OFF)
        self.sound_combo.addItem("Khi có người tag mình", SOUND_MENTION)
        self.sound_combo.addItem("Mọi tin nhắn mới", SOUND_ALL)
        grid.addWidget(self.sound_combo, r, 1, 1, 2)
        r += 1
        grid.addWidget(QLabel("Từ khoá cảnh báo"), r, 0)
        self.keywords_edit = QLineEdit()
        self.keywords_edit.setPlaceholderText("lobby, vào game, tên game… (cách nhau bằng dấu phẩy)")
        grid.addWidget(self.keywords_edit, r, 1, 1, 2)
        r += 1
        self.copy_codes_cb = QCheckBox("Tự động copy code (code game, OTP, mã vào lobby) trong tin nhắn đến")
        grid.addWidget(self.copy_codes_cb, r, 0, 1, 3)
        r += 1
        self.fade_spin = self._spin(3, 120, " giây")
        self.lines_spin = self._spin(1, 30, " dòng")
        self.font_spin = self._spin(8, 28, " pt")
        self.width_spin = self._spin(240, 1200, " px", step=20)
        self.history_spin = self._spin(0, 100, " tin", step=5)
        for label, spin in (("Thời gian hiện tin", self.fade_spin), ("Số dòng tối đa", self.lines_spin),
                            ("Cỡ chữ", self.font_spin), ("Độ rộng khung", self.width_spin),
                            ("Lịch sử tải sẵn", self.history_spin)):
            grid.addWidget(QLabel(label), r, 0)
            grid.addWidget(spin, r, 1)
            r += 1
        grid.setColumnStretch(1, 1)
        lay.addLayout(grid)
        lay.addWidget(self._hint(
            "Khi đang gõ: Enter gửi · Esc đóng · PageUp/PageDown hoặc lăn chuột trên ô nhập để cuộn lịch sử "
            "(cuộn lên đầu sẽ tự tải tin cũ hơn từ Steam) · ↑/↓ gọi lại tin đã gửi · "
            "kéo biểu tượng ⠿ để di chuyển khung chat (ở chế độ \"Luôn hiển thị\", khung chat nằm cố định trên "
            "màn hình bạn kéo tới — mặc định là màn hình chính). Tổ hợp tay cầm hoạt động như phím tắt (bấm lại để đóng ô "
            "chat); nên chọn tổ hợp game không dùng, ví dụ Back + RB. Tự copy code: nhận ra dòng chỉ có một mã viết hoa "
            "(ABCD-EF12-…, JWKD, 89D2, OTP 6 số…) hoặc mã đứng sau chữ \"code / mã / otp / pass / lobby / room\"; "
            "khi copy, overlay hiện dòng xanh \"Đã copy code: …\". "
            "Lệnh trong ô chat: gõ / để xem danh sách (/count 3 đếm ngược 3 2 1 GO, /count 5 0.5s Nhảy! tuỳ chỉnh, "
            "/room <tên> và /group <tên> đổi kênh / nhóm — hoặc Ctrl+Tab / Ctrl+Shift+Tab khi đang mở ô chat để chuyển kênh kế tiếp / trước, /quiet bật tắt chế độ chỉ hiện tin khi bị tag); "
            "gõ :tên để chèn emoticon. Công cụ chơi game: /timer 5m Boss (hẹn giờ), /ready (hỏi cả nhóm sẵn sàng chưa — "
            "trả lời rồi / vô / ok / vào), /join <tên> (vào game của bạn bè như chuột phải → Join Game), /invite <tên|all> (mời vào lobby / game của bạn), /chat <tên> [tin nhắn] (mở chat riêng với bạn bè kèm lịch sử, có tin nhắn thì gửi luôn; /group hoặc /room để quay lại), /afk 10p ăn cơm + /back, "
            "/alert <từ khoá>, /team 2 (chia đội), /pick a b c (chọn ngẫu nhiên)."))
        buttons = QHBoxLayout()
        save = QPushButton("Lưu")
        save.setObjectName("primaryBtn")
        save.clicked.connect(self._on_save)
        buttons.addWidget(save)
        preview = QPushButton("Xem thử")
        preview.clicked.connect(self._on_preview)
        buttons.addWidget(preview)
        reset_pos = QPushButton("Đặt lại vị trí")
        reset_pos.clicked.connect(self.controller.reset_position)
        buttons.addWidget(reset_pos)
        buttons.addStretch()
        lay.addLayout(buttons)
        content.addWidget(card)

        content.addStretch()
        scroll.setWidget(body)
        root.addWidget(scroll)

    def _gamepad_row(self, name: str) -> QWidget:
        row = QWidget()
        lay = QHBoxLayout(row)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        display = QLabel("—")
        display.setObjectName("comboDisplay")
        display.setMinimumWidth(220)
        lay.addWidget(display, 1)
        record = QPushButton("Ghi")
        record.clicked.connect(lambda: self._toggle_gp_record(name))
        lay.addWidget(record)
        clear = QPushButton("Xoá")
        clear.clicked.connect(lambda: self._clear_gp_combo(name))
        lay.addWidget(clear)
        self._gp_display[name] = display
        self._gp_record_btn[name] = record
        self._gp_clear_btn[name] = clear
        return row

    @staticmethod
    def _spin(lo: int, hi: int, suffix: str, step: int = 1) -> QSpinBox:
        spin = QSpinBox()
        spin.setRange(lo, hi)
        spin.setSingleStep(step)
        spin.setSuffix(suffix)
        spin.setMaximumWidth(160)
        return spin

    @staticmethod
    def _key_edit() -> QKeySequenceEdit:
        edit = QKeySequenceEdit()
        edit.setMaximumSequenceLength(1)
        edit.setClearButtonEnabled(True)
        edit.setMaximumWidth(220)
        return edit

    # ---- settings <-> widgets ---------------------------------------------------------------------
    def _load_from_settings(self) -> None:
        s = self.controller.settings
        self.enabled_cb.blockSignals(True)
        self.enabled_cb.setChecked(s.enabled)
        self.enabled_cb.blockSignals(False)
        idx = self.mode_combo.findData(s.show_mode)
        self.mode_combo.setCurrentIndex(max(0, idx))
        self.chat_key.setKeySequence(QKeySequence.fromString(s.hotkey_chat, QKeySequence.SequenceFormat.PortableText))
        self.toggle_key.setKeySequence(QKeySequence.fromString(s.hotkey_toggle, QKeySequence.SequenceFormat.PortableText))
        self.fade_spin.setValue(s.fade_seconds)
        self.lines_spin.setValue(s.max_lines)
        self.history_spin.setValue(s.history_lines)
        self.copy_codes_cb.setChecked(s.auto_copy_codes)
        self.keywords_edit.setText(", ".join(s.alert_keywords))
        self.filter_combo.setCurrentIndex(max(0, self.filter_combo.findData(s.display_filter)))
        self.sound_combo.setCurrentIndex(max(0, self.sound_combo.findData(s.sound_mode)))
        self.font_spin.setValue(s.font_size)
        self.width_spin.setValue(s.width)
        self._refresh_gp_displays()
        if s.group_id and not self._groups:
            self._set_combo_placeholder(self.group_combo, s.group_name or s.group_id)
            self._set_combo_placeholder(self.room_combo, s.chat_name or s.chat_id)

    @staticmethod
    def _set_combo_placeholder(combo: QComboBox, text: str) -> None:
        combo.blockSignals(True)
        combo.clear()
        combo.addItem(text, None)
        combo.blockSignals(False)

    def _store_widgets(self) -> None:
        s = self.controller.settings
        s.show_mode = self.mode_combo.currentData() or SHOW_MODE_GAME
        s.hotkey_chat = self.chat_key.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
        s.hotkey_toggle = self.toggle_key.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
        s.fade_seconds = self.fade_spin.value()
        s.max_lines = self.lines_spin.value()
        s.history_lines = self.history_spin.value()
        s.auto_copy_codes = self.copy_codes_cb.isChecked()
        s.alert_keywords = normalize_keywords(self.keywords_edit.text().replace(";", ",").split(","))
        s.display_filter = self.filter_combo.currentData() or FILTER_ALL
        s.sound_mode = self.sound_combo.currentData() or SOUND_MENTION
        s.font_size = self.font_spin.value()
        s.width = self.width_spin.value()

    # ---- actions ------------------------------------------------------------------------------------
    def _on_enabled_toggled(self, checked: bool) -> None:
        self._store_widgets()
        self.controller.set_enabled(checked)
        if not checked:
            self.controller.probe_async()

    def _on_save(self) -> None:
        self._store_widgets()
        result = self.controller.apply_settings()
        if self.controller.active and not all(result.values()):
            QMessageBox.warning(self, "Phím tắt",
                                "Một số phím tắt không đăng ký được (không hợp lệ hoặc đã bị ứng dụng khác dùng). "
                                "Hãy chọn tổ hợp khác, ví dụ Ctrl+Enter, Ctrl+Shift+Enter hoặc Ctrl+F12.")

    def _on_preview(self) -> None:
        self._store_widgets()
        self.controller.apply_settings()
        self.controller.preview()

    def _recheck(self) -> None:
        if self.controller.active:
            self._on_status(self.controller.status)
            if self.controller.status.state in _ATTACHED_STATES:
                self._reload_groups()
        else:
            self.controller.probe_async()

    def _on_enable_debug(self) -> None:
        if not self.controller.enable_steam_debugging():
            QMessageBox.warning(self, "Steam Chat", "Không tìm thấy thư mục cài Steam hoặc không ghi được file cấu hình.")
            return
        self._ask_restart()

    def _on_disable_debug(self) -> None:
        if not self.controller.disable_steam_debugging():
            QMessageBox.warning(self, "Steam Chat", "Không xoá được file cấu hình debug của Steam.")
            return
        QMessageBox.information(self, "Steam Chat",
                                "Đã tắt. Cổng debug của Steam sẽ đóng sau lần khởi động lại Steam tiếp theo.")
        self._recheck()

    def _on_restart_steam(self) -> None:
        self._ask_restart()

    def _ask_restart(self) -> None:
        answer = QMessageBox.question(
            self, "Khởi động lại Steam",
            "Steam cần khởi động lại để bật kết nối.\n\nGame đang chạy qua Steam (nếu có) sẽ bị đóng. Tiếp tục?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            self._recheck()
            return
        self.restart_btn.setEnabled(False)
        self.enable_debug_btn.setEnabled(False)
        self.status_label.setText("Đang khởi động lại Steam…")

        def work():
            ok = False
            try:
                ok = steam_debug.restart_steam()
            except Exception:
                logger.exception("[SteamChat] Restart Steam failed")
            self._restart_done.emit(ok)
        threading.Thread(target=work, name="SteamChat-Restart", daemon=True).start()

    def _on_restart_done(self, ok: bool) -> None:
        self.restart_btn.setEnabled(True)
        self.enable_debug_btn.setEnabled(True)
        if not ok:
            QMessageBox.warning(self, "Steam Chat", "Không khởi động lại được Steam. Hãy tự thoát và mở lại Steam.")
        self._recheck()

    # ---- groups -------------------------------------------------------------------------------------
    def _reload_groups(self) -> None:
        if not self.controller.active:
            self.groups_hint.setText("Bật Steam Chat Overlay để tải danh sách nhóm.")
            return
        if self.controller.status.state not in _ATTACHED_STATES:
            self.groups_hint.setText("Chưa kết nối được Steam — xem mục Kết nối Steam ở trên.")
            return
        self._loading_groups = True
        self.reload_btn.setEnabled(False)
        self.groups_hint.setText("Đang tải danh sách nhóm…")
        self.controller.request_groups()

    def _on_groups_loaded(self, groups: list) -> None:
        self._loading_groups = False
        self.reload_btn.setEnabled(True)
        self._groups = groups
        s = self.controller.settings
        self.group_combo.blockSignals(True)
        self.group_combo.clear()
        selected = -1
        for i, g in enumerate(groups):
            self.group_combo.addItem(g.name, g.group_id)
            if g.group_id == s.group_id:
                selected = i
        self.group_combo.blockSignals(False)
        if not groups:
            self.groups_hint.setText("Tài khoản Steam này chưa tham gia nhóm chat nào.")
            self.room_combo.clear()
            return
        self.groups_hint.setText(f"{len(groups)} nhóm chat.")
        self.group_combo.setCurrentIndex(selected if selected >= 0 else 0)
        self._on_group_changed(self.group_combo.currentIndex())

    def _on_groups_failed(self, error: str) -> None:
        self._loading_groups = False
        self.reload_btn.setEnabled(True)
        self.groups_hint.setText(f"Không tải được danh sách nhóm: {error}")

    def _current_group(self):
        gid = self.group_combo.currentData()
        return next((g for g in self._groups if g.group_id == gid), None)

    def _on_group_changed(self, _index: int) -> None:
        group = self._current_group()
        if group is None:
            return
        s = self.controller.settings
        self.room_combo.blockSignals(True)
        self.room_combo.clear()
        selected = 0
        for i, room in enumerate(group.rooms):
            self.room_combo.addItem(("🔊 " if room.voice else "# ") + room.name, room.chat_id)
            if group.group_id == s.group_id and room.chat_id == s.chat_id:
                selected = i
        self.room_combo.blockSignals(False)
        if group.rooms:
            self.room_combo.setCurrentIndex(selected)
            self._on_room_changed(selected)

    def _on_room_changed(self, _index: int) -> None:
        group = self._current_group()
        chat_id = self.room_combo.currentData()
        if group is None or not chat_id:
            return
        room = next((r for r in group.rooms if r.chat_id == chat_id), None)
        self.controller.set_room(group.group_id, chat_id, group.name, room.name if room else "")

    # ---- status -------------------------------------------------------------------------------------
    def _on_status(self, status: BridgeStatus) -> None:
        color = _STATE_COLORS.get(status.state, _GREY)
        self.status_dot.setStyleSheet(f"color: {color}; font-size: 14px;")
        self.status_label.setText(status_text(status) + (f" ({status.detail})" if status.detail and status.state not in (
            BridgeState.CONNECTED, BridgeState.ERROR) else ""))
        active = self.controller.active
        self.badge.set_state("● ĐANG BẬT" if active else "○ ĐANG TẮT", "ok" if active else "off")

        marker = steam_debug.is_debug_marker_present()
        self.enable_debug_btn.setVisible(status.state is BridgeState.DEBUG_DISABLED or (not marker and not active))
        self.restart_btn.setVisible(status.state in (BridgeState.RESTART_REQUIRED, BridgeState.DEBUG_DISABLED) and marker)
        self.disable_debug_btn.setVisible(marker)

        if status.state in _ATTACHED_STATES and not self._groups and not self._loading_groups:
            self._reload_groups()

    def _on_hotkeys_changed(self, result: dict) -> None:
        for name, label in ((HOTKEY_CHAT, self.chat_key_state), (HOTKEY_TOGGLE, self.toggle_key_state)):
            if name not in result:
                label.setText("")
            elif result[name]:
                label.setText("✓ đã đăng ký")
                label.setStyleSheet(f"color: {_GREEN};")
            else:
                label.setText("✗ không dùng được")
                label.setStyleSheet(f"color: {_RED};")

    # ---- controller combos -------------------------------------------------------------------------
    @staticmethod
    def combo_text(inputs) -> str:
        return " + ".join(GamepadMonitor.get_input_display_name(i) for i in sorted(inputs or [])) or "—"

    def _gp_combo(self, name: str) -> list:
        s = self.controller.settings
        return s.gamepad_chat if name == HOTKEY_CHAT else s.gamepad_toggle

    def _refresh_gp_displays(self) -> None:
        available = self._gamepad is not None
        for name, display in self._gp_display.items():
            recording = self._recording == name
            if not recording:
                display.setText(self.combo_text(self._gp_combo(name)))
            display.setProperty("recording", "true" if recording else "false")
            display.style().unpolish(display)
            display.style().polish(display)
            self._gp_record_btn[name].setText("Dừng" if recording else "Ghi")
            self._gp_record_btn[name].setEnabled(available and self._recording in (None, name))
            self._gp_clear_btn[name].setEnabled(not recording and bool(self._gp_combo(name)))

    def _update_gp_status(self, *_args) -> None:
        if self._gamepad is None:
            self.gp_status.setText("Không dùng được tay cầm (thiếu SDL2).")
        elif self._gamepad.connected_device_names:
            self.gp_status.setText(f"Tay cầm: {self._gamepad.connected_device_names}")
        else:
            self.gp_status.setText("Chưa kết nối tay cầm — vẫn lưu được tổ hợp, sẽ hoạt động khi cắm tay cầm.")
        self._refresh_gp_displays()

    def _toggle_gp_record(self, name: str) -> None:
        if self._gamepad is None:
            return
        if self._recording == name:
            inputs = self._gamepad.stop_recording()
            self._recording = None
            if inputs:
                self.controller.set_gamepad_combo(name, inputs)
            self._refresh_gp_displays()
            return
        if self._recording is not None:
            self._gamepad.stop_recording()
        self._recording = name
        self._gamepad.start_recording()
        self._gp_display[name].setText("Nhấn giữ tổ hợp trên tay cầm rồi bấm Dừng…")
        self._refresh_gp_displays()

    def _on_gp_buttons(self, inputs: set) -> None:
        if self._recording in self._gp_display:
            self._gp_display[self._recording].setText(self.combo_text(inputs))

    def _clear_gp_combo(self, name: str) -> None:
        self.controller.set_gamepad_combo(name, [])
        self._refresh_gp_displays()

    def _cancel_gp_recording(self) -> None:
        if self._recording is not None and self._gamepad is not None:
            self._gamepad.stop_recording()
        self._recording = None
        self._refresh_gp_displays()

    def showEvent(self, event):
        super().showEvent(event)
        self._load_from_settings()
        self._recheck()

    def hideEvent(self, event):
        self._cancel_gp_recording()
        super().hideEvent(event)
