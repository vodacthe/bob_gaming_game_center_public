"""Async metadata cache and launcher for Steam Chat rich embeds (YouTube videos & Steam Store games)."""

from __future__ import annotations

import hashlib
import html
import json
import logging
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass

from PySide6.QtCore import QObject, Signal

from app.core import steam_manager
from app.core.steam_chat.models import EMBED_OG, EMBED_STORE, EMBED_YOUTUBE, ChatEmbed
from app.ui.steam_chat.images import FAILED, LOADING, READY

logger = logging.getLogger(__name__)
TAG = "[SteamChat/Embeds]"

_TIMEOUT = 10.0
_MAX_JSON_BYTES = 2 * 1024 * 1024
_DISK_TTL_SECONDS = 86400
_MAX_MEM_ENTRIES = 256
_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BobGameCenter-SteamChat/1.0"
_HTML_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")


@dataclass(frozen=True)
class EmbedMetadata:
    kind: str
    item_id: str
    title: str
    subtitle: str = ""
    thumb_url: str = ""
    price_text: str = ""
    original_price_text: str = ""
    discount_percent: int = 0
    domain: str = ""


def domain_label(url: str) -> str:
    try:
        host = urllib.parse.urlsplit(url).netloc.lower()
    except ValueError:
        host = ""
    if ":" in host:
        host = host.split(":", 1)[0]
    if host.startswith("www."):
        host = host[4:]
    return host.upper()


def youtube_thumb_url(video_id: str) -> str:
    return f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"


def store_header_url(appid: str) -> str:
    return f"https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/{appid}/header.jpg"


def fallback_metadata(embed: ChatEmbed, loading: bool = False) -> EmbedMetadata:
    if embed.kind == EMBED_OG:
        dom = domain_label(embed.url)
        return EmbedMetadata(
            kind=EMBED_OG,
            item_id=embed.item_id,
            title=embed.title or dom or embed.url,
            subtitle=embed.subtitle,
            thumb_url=embed.thumb_url,
            domain=dom,
        )
    if embed.kind == EMBED_YOUTUBE:
        return EmbedMetadata(
            kind=EMBED_YOUTUBE,
            item_id=embed.item_id,
            title="Đang tải thông tin video…" if loading else "Video trên YouTube",
            subtitle="YouTube",
            thumb_url=youtube_thumb_url(embed.item_id),
        )
    return EmbedMetadata(
        kind=EMBED_STORE,
        item_id=embed.item_id,
        title="Đang tải thông tin game…" if loading else f"Steam App #{embed.item_id}",
        subtitle="Xem trang cửa hàng trên Steam",
        thumb_url=store_header_url(embed.item_id),
        price_text="" if loading else "Xem trên Steam",
    )


def _clean_html_text(raw: str, max_len: int = 220) -> str:
    if not raw:
        return ""
    stripped = _HTML_TAG_RE.sub(" ", str(raw))
    unescaped = html.unescape(stripped)
    collapsed = _WS_RE.sub(" ", unescaped).strip()
    if len(collapsed) > max_len:
        return collapsed[: max_len - 1].rstrip() + "…"
    return collapsed


def _http_get_json(url: str, timeout: float = _TIMEOUT) -> dict | None:
    if not url.lower().startswith(("https://", "http://")):
        logger.warning(f"{TAG} Refused non-HTTP metadata URL: {url}")
        return None
    t0 = time.monotonic()
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": _USER_AGENT,
            "Accept": "application/json, text/plain, */*",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = getattr(resp, "status", 200)
            body = resp.read(_MAX_JSON_BYTES + 1)
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        if len(body) > _MAX_JSON_BYTES:
            logger.warning(f"{TAG} Metadata payload exceeded limit url={url} status={status} duration_ms={elapsed_ms}")
            return None
        parsed = json.loads(body.decode("utf-8", errors="replace"))
        logger.info(f"{TAG} Fetched metadata url={url} status={status} duration_ms={elapsed_ms}")
        return parsed if isinstance(parsed, dict) else None
    except urllib.error.HTTPError as e:
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        logger.warning(f"{TAG} Metadata HTTP failure url={url} status={e.code} duration_ms={elapsed_ms}: {e.reason}")
        return None
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        logger.warning(f"{TAG} Metadata network/parse failure url={url} status=none duration_ms={elapsed_ms}: {e}")
        return None
    except Exception:
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        logger.exception(f"{TAG} Unexpected error fetching metadata url={url} status=error duration_ms={elapsed_ms}")
        return None


def fetch_embed_metadata(kind: str, item_id: str, http_json=_http_get_json) -> EmbedMetadata | None:
    """Blocking worker function: fetch YouTube oEmbed or Steam Store appdetails metadata."""
    if kind == EMBED_YOUTUBE:
        watch_url = f"https://www.youtube.com/watch?v={urllib.parse.quote(item_id, safe='_-')}"
        oembed_url = f"https://www.youtube.com/oembed?url={urllib.parse.quote(watch_url, safe='')}&format=json"
        data = http_json(oembed_url)
        if not data:
            return None
        title = _clean_html_text(data.get("title") or "", max_len=140)
        if not title:
            return None
        author = _clean_html_text(data.get("author_name") or "YouTube", max_len=80) or "YouTube"
        return EmbedMetadata(
            kind=EMBED_YOUTUBE,
            item_id=item_id,
            title=title,
            subtitle=author,
            thumb_url=youtube_thumb_url(item_id),
        )

    if kind == EMBED_STORE:
        if not item_id.isdigit():
            logger.warning(f"{TAG} Refused invalid Steam AppID: {item_id!r}")
            return None
        api_url = f"https://store.steampowered.com/api/appdetails?appids={item_id}&cc=vn&l=vietnamese"
        payload = http_json(api_url)
        entry = payload.get(item_id) if isinstance(payload, dict) else None
        if not isinstance(entry, dict) or not entry.get("success") or not isinstance(entry.get("data"), dict):
            logger.warning(f"{TAG} Steam appdetails unavailable for appid={item_id}")
            return None
        info = entry["data"]
        name = _clean_html_text(info.get("name") or "", max_len=120)
        if not name:
            return None
        desc = _clean_html_text(info.get("short_description") or "", max_len=200)
        header = str(info.get("header_image") or "").strip()
        if not header.lower().startswith(("https://", "http://")):
            header = store_header_url(item_id)

        price_text = ""
        original_price = ""
        discount = 0
        if info.get("is_free"):
            price_text = "Miễn phí"
        elif isinstance(info.get("price_overview"), dict):
            po = info["price_overview"]
            try:
                discount = max(0, int(po.get("discount_percent") or 0))
            except (TypeError, ValueError):
                discount = 0
            price_text = _clean_html_text(po.get("final_formatted") or "", max_len=40)
            if discount > 0:
                original_price = _clean_html_text(po.get("initial_formatted") or "", max_len=40)
        elif isinstance(info.get("release_date"), dict) and info["release_date"].get("coming_soon"):
            date_str = _clean_html_text(info["release_date"].get("date") or "", max_len=40)
            price_text = f"Sắp ra mắt ({date_str})" if date_str else "Sắp ra mắt"
        else:
            price_text = "Xem trên Steam"

        return EmbedMetadata(
            kind=EMBED_STORE,
            item_id=item_id,
            title=name,
            subtitle=desc,
            thumb_url=header,
            price_text=price_text,
            original_price_text=original_price,
            discount_percent=discount,
        )

    logger.warning(f"{TAG} Unsupported embed kind: {kind!r}")
    return None


def _default_start_steam_uri(uri: str) -> bool:
    if sys.platform != "win32" or not uri.startswith("steam://store/"):
        return False
    os.startfile(uri)
    return True


def _default_open_browser(url: str) -> bool:
    if not url.lower().startswith(("https://", "http://")):
        return False
    return bool(webbrowser.open(url))


def open_chat_embed(
    embed: ChatEmbed,
    steam_running_fn=steam_manager.is_steam_running,
    start_steam_uri=_default_start_steam_uri,
    open_browser=_default_open_browser,
) -> bool:
    """Open a clicked chat embed card: Steam Store opens steam://store/<appid> when Steam runs, else browser."""
    try:
        if embed.kind == EMBED_STORE:
            if not embed.item_id.isdigit():
                logger.warning(f"{TAG} Refused opening Store embed with non-numeric appid={embed.item_id!r}")
                return False
            browser_url = f"https://store.steampowered.com/app/{embed.item_id}/"
            if steam_running_fn():
                steam_uri = f"steam://store/{embed.item_id}"
                try:
                    if start_steam_uri(steam_uri):
                        logger.info(f"{TAG} Opened Steam Store app in Steam client: {steam_uri}")
                        return True
                except OSError as e:
                    logger.warning(f"{TAG} Could not open {steam_uri}, falling back to browser: {e}")
            ok = bool(open_browser(browser_url))
            if ok:
                logger.info(f"{TAG} Opened Steam Store app in browser: {browser_url}")
            else:
                logger.warning(f"{TAG} Browser refused Steam Store URL: {browser_url}")
            return ok

        if embed.kind in (EMBED_YOUTUBE, EMBED_OG):
            if not embed.url.lower().startswith(("https://", "http://")):
                logger.warning(f"{TAG} Refused opening {embed.kind} embed with unsafe URL: {embed.url!r}")
                return False
            ok = bool(open_browser(embed.url))
            if ok:
                logger.info(f"{TAG} Opened {embed.kind} link in browser: {embed.url}")
            else:
                logger.warning(f"{TAG} Browser refused {embed.kind} URL: {embed.url}")
            return ok

        logger.warning(f"{TAG} Unknown embed kind clicked: {embed.kind!r}")
        return False
    except Exception:
        logger.exception(f"{TAG} Unexpected error opening chat embed {embed}")
        return False


class EmbedCache(QObject):
    """Async off-UI-thread metadata cache for YouTube and Steam Store chat cards."""

    loaded = Signal(str, str)                     # kind, item_id
    _sig_done = Signal(str, str, object, bool)    # kind, item_id, EmbedMetadata | None, from_disk

    def __init__(self, parent=None, fetch=fetch_embed_metadata, workers: int = 2, disk_dir: str | None = None):
        super().__init__(parent)
        self._fetch = fetch
        self._disk_dir = os.path.join(disk_dir, "embeds") if disk_dir else None
        self._state: dict[tuple[str, str], str] = {}
        self._entries: OrderedDict[tuple[str, str], EmbedMetadata] = OrderedDict()
        self._pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="SteamChat-Embed")
        self._sig_done.connect(self._on_done)

    def state(self, embed: ChatEmbed) -> str | None:
        if embed.kind == EMBED_OG:
            return READY
        return self._state.get((embed.kind, embed.item_id))

    def settled(self, embed: ChatEmbed) -> bool:
        if embed.kind == EMBED_OG:
            return True
        return self._state.get((embed.kind, embed.item_id)) in (READY, FAILED)

    def metadata(self, embed: ChatEmbed) -> EmbedMetadata:
        """Return cached metadata, or start loading in the background and return clean fallback metadata."""
        if embed.kind == EMBED_OG:
            return fallback_metadata(embed, loading=False)
        key = (embed.kind, embed.item_id)
        entry = self._entries.get(key)
        if entry is not None:
            self._entries.move_to_end(key)
            return entry
        if key not in self._state:
            self.request(embed)
        return fallback_metadata(embed, loading=(self._state.get(key) == LOADING))

    def request(self, embed: ChatEmbed) -> None:
        key = (embed.kind, embed.item_id)
        if key in self._state and self._state[key] != FAILED:
            return
        self._state[key] = LOADING
        try:
            self._pool.submit(self._work, embed.kind, embed.item_id)
        except RuntimeError:
            self._state[key] = FAILED

    def shutdown(self) -> None:
        self._pool.shutdown(wait=False, cancel_futures=True)

    def _disk_path(self, kind: str, item_id: str) -> str:
        digest = hashlib.sha1(f"{kind}:{item_id}".encode("utf-8")).hexdigest()
        return os.path.join(self._disk_dir, f"{digest}.json")

    def _read_disk(self, kind: str, item_id: str) -> EmbedMetadata | None:
        if not self._disk_dir:
            return None
        try:
            path = self._disk_path(kind, item_id)
            if time.time() - os.path.getmtime(path) > _DISK_TTL_SECONDS:
                return None
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if not isinstance(raw, dict) or not raw.get("title"):
                return None
            return EmbedMetadata(
                kind=str(raw.get("kind") or kind),
                item_id=str(raw.get("item_id") or item_id),
                title=str(raw["title"]),
                subtitle=str(raw.get("subtitle") or ""),
                thumb_url=str(raw.get("thumb_url") or ""),
                price_text=str(raw.get("price_text") or ""),
                original_price_text=str(raw.get("original_price_text") or ""),
                discount_percent=int(raw.get("discount_percent") or 0),
            )
        except (OSError, ValueError, TypeError):
            return None

    def _write_disk(self, meta: EmbedMetadata) -> None:
        if not self._disk_dir:
            return
        try:
            os.makedirs(self._disk_dir, exist_ok=True)
            path = self._disk_path(meta.kind, meta.item_id)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(asdict(meta), f, ensure_ascii=False)
            os.replace(tmp, path)
        except OSError as e:
            logger.debug(f"{TAG} Could not write embed metadata cache: {e}")

    def _work(self, kind: str, item_id: str) -> None:
        meta = None
        from_disk = False
        try:
            meta = self._read_disk(kind, item_id)
            from_disk = meta is not None
            if meta is None:
                meta = self._fetch(kind, item_id)
        except Exception:
            logger.exception(f"{TAG} Worker failed for {kind}:{item_id}")
            meta = None
        try:
            self._sig_done.emit(kind, item_id, meta, from_disk)
        except RuntimeError:
            pass

    def _on_done(self, kind: str, item_id: str, meta: object, from_disk: bool) -> None:
        try:
            key = (kind, item_id)
            if isinstance(meta, EmbedMetadata):
                self._state[key] = READY
                self._entries[key] = meta
                self._entries.move_to_end(key)
                while len(self._entries) > _MAX_MEM_ENTRIES:
                    gone, _ = self._entries.popitem(last=False)
                    self._state.pop(gone, None)
                if not from_disk:
                    try:
                        self._pool.submit(self._write_disk, meta)
                    except RuntimeError:
                        pass
            else:
                self._state[key] = FAILED
            self.loaded.emit(kind, item_id)
        except Exception:
            logger.exception(f"{TAG} Failed handling metadata completion for {kind}:{item_id}")
