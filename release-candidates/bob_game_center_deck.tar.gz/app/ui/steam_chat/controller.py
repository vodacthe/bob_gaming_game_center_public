"""SteamChatController: glue between the Steam chat bridge (background threads) and the overlay (GUI).

Owns the settings store, the bridge, both overlay windows and the global hotkeys. Lives on the GUI
thread; bridge callbacks are marshalled through private queued signals.
"""

from __future__ import annotations

import logging
import os
import re
import sys
import threading
import time
from dataclasses import dataclass, field

from PySide6.QtCore import QEvent, QObject, QPoint, Qt, QTimer, Signal
from PySide6.QtGui import QCursor, QGuiApplication, QKeyEvent
from PySide6.QtWidgets import QApplication, QMenu

from app.core.steam_chat import steam_debug
from app.core.steam_chat import codes, commands, gametools, mentions
from app.core.steam_chat.bbcode import extract_mentions, from_chat_input, render_rich_message
from app.core.steam_chat.bridge import SteamChatBridge, send_error_text
from app.core.steam_chat.cdp import CdpError
from app.core.steam_chat.models import DM_GROUP, BridgeState, BridgeStatus, ChatMessage
from app.core.steam_chat.settings import (
    FILTER_ALL,
    FILTER_MENTIONS,
    SHOW_MODE_ALWAYS,
    SOUND_ALL,
    SOUND_OFF,
    ChatOverlaySettings,
    SettingsStore,
)
from app.ui.steam_chat import win32
from app.ui.steam_chat.embeds import open_chat_embed
from app.ui.steam_chat.hotkey import MOD_CONTROL, MOD_SHIFT, GlobalHotkeys, parse_hotkey
from app.ui.steam_chat.keyhook import KeyboardCapture, KeyStroke
from app.ui.steam_chat.overlay import ChatInputBar, ChatOverlayWindow, OverlayLine, name_color

logger = logging.getLogger(__name__)

HOTKEY_CHAT = "chat"
HOTKEY_TOGGLE = "toggle"
GAMEPAD_GROUP = "steam_chat"            # combo group inside the shared GamepadMonitor
GAMEPAD_PREFIX = "steamchat:"           # combo ids: steamchat:chat / steamchat:toggle
_FOREGROUND_POLL_MS = 1000
_INPUT_GAP = 4
_OLDER_BATCH = 30                       # messages fetched per "load older" step
_TICK_MS = 1000                         # timers / AFK / ready check housekeeping
_AFK_REPLY_GAP = 180.0                  # an AFK auto-reply goes to the same person at most this often
_AFK_ANY_GAP = 15.0                     # ... and to anyone at most this often
_MAX_MISSED = 20                        # tags remembered while AFK
_FRIENDS_MAX_AGE = 15.0                 # friends' game state used for the /join and /invite suggestions
_STEAM_URL = re.compile(r"^steam://(?:joinlobby/\d+/\d+/\d+|rungame/\d+/\d+/[A-Za-z0-9%._~-]*)$")
_SOUND_GAP = 1.5                        # seconds between two notification sounds
_GROUPS_MAX_AGE = 60.0                  # the cached chat group list is refreshed when older than this
_DM_SEND_WAIT_MS = 8000                 # /chat <friend> <message>: send even if the chat's backlog never arrives
_CODE_REPEAT_SECONDS = 30.0
def _menu_text(text: str) -> str:
    """Qt reads "&" in menu / button text as a keyboard-shortcut marker ("A & B" shows as "A _B"); "&&" is a real "&"."""
    return str(text).replace("&", "&&")


_MENU_STYLE = """
    QMenu { background-color: rgba(14, 16, 26, 245); color: #e2e8f0; border: 1px solid rgba(139, 92, 246, 0.65);
            border-radius: 6px; padding: 4px; }
    QMenu::item { padding: 5px 22px 5px 12px; border-radius: 4px; }
    QMenu::item:selected { background-color: rgba(139, 92, 246, 0.45); }
    QMenu::item:disabled { color: #64748b; }
    QMenu::separator { height: 1px; background: rgba(255, 255, 255, 0.1); margin: 4px 6px; }
"""             # the same code seen again within this time is not copied / announced again

def play_notification_sound() -> None:
    """The system notification sound (nothing to ship; follows the user's Windows sound scheme)."""
    try:
        if sys.platform == "win32":
            import winsound
            winsound.MessageBeep(winsound.MB_ICONASTERISK)
    except Exception:
        logger.exception("[SteamChat] Could not play the notification sound")


def open_steam_url(url: str) -> bool:
    """Hand a steam://joinlobby/... or steam://rungame/... link to Steam (anything else is refused)."""
    if not _STEAM_URL.match(url) or sys.platform != "win32":
        return False
    os.startfile(url)
    return True


@dataclass
class _TimerEntry:
    number: int
    label: str
    deadline: float
    say: bool


@dataclass
class _AfkState:
    message: str
    until: float | None = None              # monotonic deadline, None = until /back
    until_clock: float | None = None        # the same moment as wall-clock time (shown to others)
    last_reply: float = -1e9
    replied: dict = field(default_factory=dict)      # account id -> monotonic time of our last reply
    missed: list = field(default_factory=list)       # (sender, text, unix time) of the tags we did not see


def copy_to_clipboard(text: str) -> bool:
    clipboard = QGuiApplication.clipboard()
    if clipboard is None:
        return False
    clipboard.setText(text)
    return True


STATUS_TEXT = {
    BridgeState.STOPPED: "Đang tắt",
    BridgeState.STEAM_NOT_RUNNING: "Steam chưa chạy",
    BridgeState.DEBUG_DISABLED: "Chưa bật kết nối với Steam",
    BridgeState.RESTART_REQUIRED: "Cần khởi động lại Steam để kết nối",
    BridgeState.PORT_CONFLICT: "Cổng 8080 đang bị ứng dụng khác chiếm",
    BridgeState.CONNECTING: "Đang kết nối Steam…",
    BridgeState.NOT_READY: "Đang chờ Steam Chat tải xong…",
    BridgeState.NO_ROOM: "Chưa chọn kênh chat",
    BridgeState.CONNECTED: "Đã kết nối",
    BridgeState.ERROR: "Lỗi kết nối",
}


def screen_for_origin(origin):
    """QScreen whose native top-left is `origin` (Qt on Windows keeps native origins, scales only sizes)."""
    if origin is None:
        return None
    for screen in QGuiApplication.screens():
        top_left = screen.geometry().topLeft()
        if (top_left.x(), top_left.y()) == tuple(origin):
            return screen
    return None


def status_text(status: BridgeStatus) -> str:
    base = STATUS_TEXT.get(status.state, status.state.value)
    return f"{base}: {status.detail}" if status.detail and status.state in (
        BridgeState.CONNECTED, BridgeState.ERROR) else base


class SteamChatController(QObject):
    status_changed = Signal(object)        # BridgeStatus
    groups_loaded = Signal(object)         # list[ChatGroupInfo]
    groups_failed = Signal(str)
    probe_finished = Signal(object)        # BridgeStatus (when the bridge is not running)
    hotkeys_changed = Signal(dict)         # name -> registered ok
    enabled_changed = Signal(bool)

    _sig_message = Signal(object)
    _sig_history = Signal(object)
    _sig_status = Signal(object)
    _sig_send = Signal(str, bool, str)
    _sig_older = Signal(object, bool, object)
    _sig_members = Signal(object, bool)
    _sig_emoticons = Signal(object)
    _sig_groups = Signal(object)
    _sig_friends = Signal(object)
    _sig_invited = Signal(object)
    _sig_all_friends = Signal(object)
    _sig_chat_target = Signal(object)

    def __init__(self, parent=None, store: SettingsStore | None = None, bridge_factory=SteamChatBridge):
        super().__init__(parent)
        self.store = store or SettingsStore()
        self._bridge = bridge_factory(
            on_message=self._sig_message.emit,
            on_status=self._sig_status.emit,
            on_history=self._sig_history.emit,
            on_send_result=self._sig_send.emit,
            on_older=self._sig_older.emit,
            on_members=self._sig_members.emit,
            on_emoticons=self._sig_emoticons.emit,
            history_lines=self.settings.history_lines,
        )
        self._sig_message.connect(self._on_message)
        self._sig_history.connect(self._on_history)
        self._sig_status.connect(self._on_status)
        self._sig_send.connect(self._on_send_result)
        self._sig_older.connect(self._on_older)
        self._sig_members.connect(self._on_members)
        self._sig_emoticons.connect(self._on_emoticons)
        self._sig_groups.connect(self._on_groups_cached)
        self._sig_friends.connect(self._on_friends)
        self._sig_invited.connect(self._on_invited)
        self._sig_all_friends.connect(self._on_all_friends)
        self._sig_chat_target.connect(self._on_chat_target)

        self._overlay: ChatOverlayWindow | None = None
        self._input: ChatInputBar | None = None
        self._hotkeys: GlobalHotkeys | None = None
        self._keys: KeyboardCapture | None = None
        self._captured = False
        self._typing_fg = 0
        self._open_menu: QMenu | None = None
        self._gamepad = None                     # shared app.ui.gamepad_monitor.GamepadMonitor (optional)
        self._hotkey_ok: dict[str, bool] = {}
        self._fg = win32.ForegroundInfo()
        self._return_hwnd = 0
        self._user_hidden = False
        self._active = False
        self._last_status = BridgeStatus(BridgeState.STOPPED)
        self._oldest: tuple[int, int] | None = None   # (timestamp, ordinal) of the oldest message shown
        self._members: list = []                      # ChatMember of the selected room (@-mentions)
        self._copy_text = copy_to_clipboard           # tests replace it: never touch the real clipboard
        self._last_code = ""
        self._last_code_at = 0.0
        self._can_mention_all = False
        self._count_left = -1                         # /count: next number to send (0 = the final line), -1 when idle
        self._count_final = commands.COUNT_GO
        self._groups: list = []                       # ChatGroupInfo: /room and /group choices
        self._groups_at = 0.0
        self._groups_loading = False
        self._play_sound = play_notification_sound    # tests replace it: never make a noise
        self._open_url = open_steam_url               # tests replace it: never launch Steam
        self._open_embed = open_chat_embed            # tests replace it: never open external browser/Steam
        self._timers: list[_TimerEntry] = []
        self._timer_seq = 0
        self._afk: _AfkState | None = None
        self._ready: gametools.ReadyCheck | None = None
        self._friends: list[gametools.FriendInfo] = []    # online friends: /join and /invite suggestions
        self._friends_at = 0.0
        self._friends_loading = False
        self._join_pending: str | None = None         # /join <name> waiting for fresh friend data
        self._all_friends: list[gametools.FriendInfo] = []   # every friend (offline too): /chat suggestions
        self._dm: tuple[str, str] | None = None       # (friend account id, name) while a private chat is open (not saved)
        self._chat_resolving = False
        self._dm_pending = ""                         # /chat <friend> <message>: sent once the private chat has loaded
        self._dm_send_timer = QTimer(self)
        self._dm_send_timer.setSingleShot(True)
        self._dm_send_timer.setInterval(_DM_SEND_WAIT_MS)
        self._dm_send_timer.timeout.connect(self._flush_dm_pending)
        self._inviting = False
        self._tick = QTimer(self)
        self._tick.setInterval(_TICK_MS)
        self._tick.timeout.connect(self._on_tick)
        self._last_sound = 0.0
        self._count_timer = QTimer(self)
        self._count_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._count_timer.timeout.connect(self._count_tick)

        self._fg_timer = QTimer(self)
        self._fg_timer.setInterval(_FOREGROUND_POLL_MS)
        self._fg_timer.timeout.connect(self._poll_foreground)

    # ---- properties ------------------------------------------------------------------------------
    @property
    def settings(self) -> ChatOverlaySettings:
        return self.store.data

    @property
    def status(self) -> BridgeStatus:
        return self._last_status

    @property
    def active(self) -> bool:
        return self._active

    @property
    def hotkey_ok(self) -> dict[str, bool]:
        return dict(self._hotkey_ok)

    @property
    def gamepad(self):
        return self._gamepad

    # ---- controller (gamepad) combos -------------------------------------------------------------
    def attach_gamepad(self, monitor) -> None:
        """Use the app-wide GamepadMonitor for controller combos (it keeps polling in the background)."""
        if monitor is None or monitor is self._gamepad:
            return
        self._gamepad = monitor
        monitor.combo_triggered.connect(self._on_gamepad_combo)
        self._sync_gamepad_combos()

    def set_gamepad_combo(self, name: str, inputs) -> None:
        """Store the controller combo for HOTKEY_CHAT / HOTKEY_TOGGLE (empty = none) and apply it."""
        keys = sorted({str(k) for k in (inputs or [])})
        if name == HOTKEY_CHAT:
            self.settings.gamepad_chat = keys
        elif name == HOTKEY_TOGGLE:
            self.settings.gamepad_toggle = keys
        else:
            return
        self.store.save()
        self._sync_gamepad_combos()

    def _sync_gamepad_combos(self) -> None:
        if self._gamepad is None:
            return
        combos = {}
        if self._active:
            for name, keys in ((HOTKEY_CHAT, self.settings.gamepad_chat),
                               (HOTKEY_TOGGLE, self.settings.gamepad_toggle)):
                if keys:
                    combos[GAMEPAD_PREFIX + name] = set(keys)
        try:
            self._gamepad.set_combos(combos, group=GAMEPAD_GROUP)
        except Exception:
            logger.exception("[SteamChat] Could not update controller combos")

    def _on_gamepad_combo(self, combo_id: str) -> None:
        if self._active and combo_id.startswith(GAMEPAD_PREFIX):
            self._on_hotkey(combo_id[len(GAMEPAD_PREFIX):])

    # ---- lifecycle ---------------------------------------------------------------------------------
    def start(self) -> None:
        """Start everything if the feature is enabled (idempotent)."""
        if self._active or not self.settings.enabled:
            return
        self._active = True
        self._ensure_windows()
        self._apply_visual_settings()
        self._register_hotkeys()
        self._sync_gamepad_combos()
        self._bridge.set_history_lines(self.settings.history_lines)
        self._bridge.set_room(*self._room_ids())
        self._bridge.start()
        self._fg_timer.start()
        logger.info("[SteamChat] Overlay started")

    def stop(self, blocking: bool = True) -> None:
        if not self._active:
            return
        self._active = False
        self._fg_timer.stop()
        self.cancel_count()
        self._reset_tools()
        self.close_input(restore_focus=False)
        if self._hotkeys is not None:
            self._hotkeys.unregister_all()
        self._hotkey_ok = {}
        self.hotkeys_changed.emit({})
        self._sync_gamepad_combos()
        if self._overlay is not None:
            self._overlay.hide()
            self._overlay.clear()
        if blocking:
            self._bridge.stop()
        else:
            threading.Thread(target=self._bridge.stop, name="SteamChat-Stop", daemon=True).start()
        logger.info("[SteamChat] Overlay stopped")

    def shutdown(self) -> None:
        """App exit: stop and release native resources."""
        self.stop(blocking=True)
        if self._gamepad is not None:
            try:
                self._gamepad.combo_triggered.disconnect(self._on_gamepad_combo)
            except (RuntimeError, TypeError):
                pass
            self._gamepad = None
        if self._keys is not None:
            self._keys.shutdown()
            self._keys = None
        if self._hotkeys is not None:
            self._hotkeys.close()
            self._hotkeys = None
        if self._overlay is not None:
            self._overlay.images.shutdown()
            self._overlay.embeds.shutdown()
        for w in (self._input, self._overlay):
            if w is not None:
                w.close()
                w.deleteLater()
        self._input = self._overlay = None

    def set_enabled(self, enabled: bool) -> None:
        self.settings.enabled = bool(enabled)
        self.store.save()
        if enabled:
            self.start()
        else:
            self.stop(blocking=False)
        self.enabled_changed.emit(bool(enabled))

    def set_room(self, group_id: str, chat_id: str, group_name: str = "", chat_name: str = "") -> None:
        s = self.settings
        leaving_dm, self._dm = self._dm is not None, None
        self._drop_dm_pending()
        if (s.group_id, s.chat_id) == (group_id, chat_id) and not leaving_dm:
            return
        if (s.group_id, s.chat_id) != (group_id, chat_id):
            s.group_id, s.chat_id, s.group_name, s.chat_name = group_id, chat_id, group_name, chat_name
            self.store.save()
        self._show_room(group_id, chat_id)

    def _show_room(self, group_id: str, chat_id: str) -> None:
        """Make the overlay mirror this room (a group channel or a private chat): clean slate, backlog on subscribe."""
        self.cancel_count()
        if self._overlay is not None:
            self._overlay.clear()
        self._oldest = None
        self._on_members([], False)                 # the new room's members arrive once it is subscribed
        self._bridge.set_room(group_id, chat_id)
        self._update_input_channel()
        self._push_switch_options()

    def _room_ids(self) -> tuple[str, str]:
        """(group id, chat id) the overlay mirrors now: the open private chat, else the saved channel."""
        if self._dm is not None:
            return DM_GROUP, self._dm[0]
        return self.settings.group_id, self.settings.chat_id

    def apply_settings(self) -> dict[str, bool]:
        """Persist and apply visual/hotkey settings. Returns the hotkey registration result."""
        self.store.save()
        self._bridge.set_history_lines(self.settings.history_lines)
        if self._active:
            self._apply_visual_settings()
            self._register_hotkeys()
            self._sync_gamepad_combos()
            self._reposition()
        return self.hotkey_ok

    def reset_position(self) -> None:
        defaults = ChatOverlaySettings()
        self.settings.pos_x, self.settings.pos_y = defaults.pos_x, defaults.pos_y
        self.settings.screen_name = defaults.screen_name
        self.store.save()
        self._reposition()

    # ---- Steam side --------------------------------------------------------------------------------
    def request_groups(self) -> None:
        """Load the chat group list in the background -> groups_loaded / groups_failed."""
        def work():
            try:
                self.groups_loaded.emit(self._bridge.list_groups())
            except CdpError as e:
                self.groups_failed.emit(str(e))
            except Exception as e:
                logger.exception("[SteamChat] list_groups failed")
                self.groups_failed.emit(str(e))
        threading.Thread(target=work, name="SteamChat-Groups", daemon=True).start()

    def probe_async(self) -> None:
        """Classify the Steam connection without starting the bridge -> probe_finished."""
        def work():
            try:
                state, _target = steam_debug.probe()
                if state is BridgeState.CONNECTING:
                    state = BridgeState.STOPPED
                self.probe_finished.emit(BridgeStatus(state))
            except Exception as e:
                self.probe_finished.emit(BridgeStatus(BridgeState.ERROR, str(e)))
        threading.Thread(target=work, name="SteamChat-Probe", daemon=True).start()

    def enable_steam_debugging(self) -> bool:
        """Create the marker file; remember that we did so it can be undone on factory reset."""
        existed = steam_debug.is_debug_marker_present()
        ok = steam_debug.set_debug_marker(True)
        if ok and not existed:
            self.settings.created_debug_marker = True
            self.store.save()
        return ok

    def disable_steam_debugging(self) -> bool:
        ok = steam_debug.set_debug_marker(False)
        if ok:
            self.settings.created_debug_marker = False
            self.store.save()
        return ok

    def factory_reset(self) -> None:
        self.stop(blocking=True)
        if self.settings.created_debug_marker:
            steam_debug.set_debug_marker(False)
        self.store.delete()

    # ---- overlay actions ---------------------------------------------------------------------------
    def preview(self) -> None:
        """Show sample lines so the user can check size/position (works even while disconnected)."""
        self._ensure_windows()
        self._apply_visual_settings()
        samples = [
            ("Tai`", 103050789, "Vào game chưa ae?"),
            ("Bob Boomer", 1, "Đang load map, đợi xíu"),
            ("Minh", 222, "Ok, mình đợi ở spawn :steamhappy:"),
        ]
        for sender, acct, text in samples:
            self._overlay.add_line(OverlayLine(text=text, sender=sender, color=name_color(acct, acct == 1)))
        self._reposition(screen=None if self._pinned_screen_mode() else self._screen_for_cursor())
        self._show_overlay()

    _MENU_KEYS = {
        0x0D: Qt.Key.Key_Return,
        0x1B: Qt.Key.Key_Escape,
        0x25: Qt.Key.Key_Left,
        0x26: Qt.Key.Key_Up,
        0x27: Qt.Key.Key_Right,
        0x28: Qt.Key.Key_Down,
    }

    def _passthrough_hotkeys(self) -> list[tuple[int, int]]:
        """(MOD_*, vk) of active Ctrl/Shift overlay hotkeys so RegisterHotKey still receives e.g. Ctrl+Return to close."""
        combos: list[tuple[int, int]] = []
        for hk in (self.settings.hotkey_chat, self.settings.hotkey_toggle):
            parsed = parse_hotkey(hk)
            if parsed is not None and not (parsed[0] & ~(MOD_CONTROL | MOD_SHIFT)):
                combos.append(parsed)
        return combos

    def _on_captured_key(self, stroke: KeyStroke) -> None:
        try:
            if not self._captured:
                return
            if self._open_menu is not None and self._open_menu.isVisible():
                qkey = self._MENU_KEYS.get(stroke.vk)
                if qkey is not None:
                    target = QApplication.activePopupWidget() or self._open_menu
                    QApplication.sendEvent(target, QKeyEvent(QEvent.Type.KeyPress, qkey, Qt.KeyboardModifier.NoModifier, ""))
                return
            if self._input is not None and self._input.isVisible():
                self._input.feed_key(stroke)
        except Exception:
            logger.exception("[SteamChat] Failed to handle captured keystroke")

    def _on_capture_target_lost(self) -> None:
        try:
            if self._captured:
                self.close_input(restore_focus=False)
        except Exception:
            logger.exception("[SteamChat] Failed to close chat input after foreground change")

    def open_input(self) -> None:
        if not self._active:
            return
        try:
            fg = win32.foreground_info()
            if not fg.own:
                self._fg = fg
                self._return_hwnd = fg.hwnd
            want_capture = bool(not fg.own and fg.fullscreen and self._keys is not None)
            self._reposition()
            self._overlay.set_expanded(True)
            self._show_overlay()
            self._overlay.set_interactive(True)         # mouse wheel scrolls the history
            self._update_input_channel()
            self._bridge.request_members()              # someone may have joined since the room was hooked
            self._bridge.request_emoticons()
            self._refresh_groups()
            self._fetch_friends()
            self._captured = bool(
                want_capture
                and self._keys.start(self._passthrough_hotkeys(), target_hwnd=fg.hwnd)
            )
            self._typing_fg = fg.hwnd if self._captured else 0
            self._input.open(captured=self._captured)
            if not self._captured:
                win32.set_foreground(int(self._input.winId()))
            self._input.keep_topmost()
            logger.info(
                f"[SteamChat] Chat input opened (mode={'captured' if self._captured else 'focused'}, "
                f"fg={fg.hwnd:#x}, fullscreen={fg.fullscreen})"
            )
        except Exception:
            logger.exception("[SteamChat] Failed to open chat input")

    def close_input(self, restore_focus: bool = True) -> None:
        if self._input is None or not self._input.isVisible():
            return
        try:
            was_captured = self._captured
            self._captured = False
            self._typing_fg = 0
            if self._keys is not None:
                self._keys.stop()
            self._input.hide()
            self._overlay.set_expanded(False)
            self._overlay.set_interactive(False)
            if not self._overlay.has_visible_content():
                self._overlay.hide()
            restored = False
            if restore_focus and not was_captured and self._return_hwnd:
                restored = win32.set_foreground(self._return_hwnd)
            self._return_hwnd = 0
            logger.info(
                f"[SteamChat] Chat input closed (was_captured={was_captured}, restore_focus={restore_focus}, "
                f"restored={restored})"
            )
        except Exception:
            logger.exception("[SteamChat] Failed to close chat input")

    def toggle_visibility(self) -> None:
        self._user_hidden = not self._user_hidden
        if self._user_hidden:
            self.close_input()
            if self._overlay is not None:
                self._overlay.hide()
        else:
            self._add_system("Steam Chat Overlay: hiện")

    # ---- internals -----------------------------------------------------------------------------------
    def _ensure_windows(self) -> None:
        if self._overlay is not None:
            return
        self._overlay = ChatOverlayWindow()
        self._overlay.faded_out.connect(self._on_faded_out)
        self._overlay.older_requested.connect(self._on_older_requested)
        self._overlay.size_changed.connect(self._anchor_overlay)
        self._overlay.embed_clicked.connect(self._on_embed_clicked)
        self._input = ChatInputBar()
        self._input.submitted.connect(self._on_submit)
        self._input.cancelled.connect(self.close_input)
        self._input.deactivated.connect(lambda: self.close_input(restore_focus=False))
        self._input.scroll_requested.connect(self._overlay.scroll_by)
        self._input.channel_step.connect(self._cycle_channel)
        self._input.channel_clicked.connect(self._on_channel_clicked)
        self._input.set_images(self._overlay.images)
        self._input.drag_moved.connect(self._on_drag_moved)
        self._input.drag_finished.connect(self._on_drag_finished)
        if self._keys is None:
            keys = KeyboardCapture(self)
            if keys.available:
                keys.key.connect(self._on_captured_key)
                keys.target_lost.connect(self._on_capture_target_lost)
                self._keys = keys

    def _apply_visual_settings(self) -> None:
        s = self.settings
        self._overlay.configure(font_size=s.font_size, width=s.width, max_lines=s.max_lines,
                                fade_seconds=s.fade_seconds)
        self._input.configure(font_size=s.font_size, width=s.width)
        self._update_input_channel()

    def _register_hotkeys(self) -> None:
        if self._hotkeys is None:
            self._hotkeys = GlobalHotkeys(self)
            self._hotkeys.triggered.connect(self._on_hotkey)
        self._hotkey_ok = {
            HOTKEY_CHAT: self._hotkeys.register(HOTKEY_CHAT, self.settings.hotkey_chat),
            HOTKEY_TOGGLE: self._hotkeys.register(HOTKEY_TOGGLE, self.settings.hotkey_toggle),
        }
        self.hotkeys_changed.emit(dict(self._hotkey_ok))

    def _on_hotkey(self, name: str) -> None:
        if name == HOTKEY_CHAT:
            if self._input is not None and self._input.isVisible():
                self.close_input()
            else:
                self._user_hidden = False
                self.open_input()
        elif name == HOTKEY_TOGGLE:
            self.toggle_visibility()

    def _update_input_channel(self) -> None:
        if self._input is not None:
            label = f"@ {self._dm[1]}" if self._dm is not None else self.settings.chat_name or self.settings.group_name
            self._input.set_channel(label, self._last_status.connected)

    def _overlay_allowed(self) -> bool:
        if not self._active or self._user_hidden:
            return False
        return self.settings.show_mode == SHOW_MODE_ALWAYS or self._fg.fullscreen

    def _show_overlay(self) -> None:
        if not self._overlay.isVisible():
            self._overlay.show()
        if self._input.holding:                     # the channel menu is up: raising the box would bury (and close) it
            return
        win32.keep_topmost(int(self._overlay.winId()))
        if self._input.isVisible():
            self._input.keep_topmost()              # the overlay must not climb over the input bar / suggestion list

    def _screen_for_cursor(self):
        return QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()

    def _pinned_screen_mode(self) -> bool:
        """"Always" mode stays on one monitor; game mode follows the game's monitor."""
        return self.settings.show_mode == SHOW_MODE_ALWAYS

    def _saved_screen(self):
        """The monitor the user dragged the box to; the primary monitor if none / unplugged."""
        name = self.settings.screen_name
        if name:
            for screen in QGuiApplication.screens():
                if screen.name() == name:
                    return screen
        return QGuiApplication.primaryScreen()

    def _target_screen(self):
        if self._pinned_screen_mode():
            return self._saved_screen()
        return screen_for_origin(self._fg.monitor_origin) or self._screen_for_cursor()

    def _reposition(self, screen=None) -> None:
        if self._overlay is None:
            return
        screen = screen or self._target_screen()
        if screen is None:
            return
        geo = screen.geometry()
        passive_h = self._overlay.passive_height
        box_h = passive_h + _INPUT_GAP + self._input.height()
        x = geo.x() + int(self.settings.pos_x * geo.width())
        y = geo.y() + int(self.settings.pos_y * geo.height())
        x = max(geo.left(), min(x, geo.right() - self._overlay.width()))
        y = max(geo.top(), min(y, geo.bottom() - box_h))
        self._input.move(x, y + passive_h + _INPUT_GAP)
        self._anchor_overlay()

    def _anchor_overlay(self) -> None:
        """Sit the chat box right above the input bar; the taller history panel grows upwards."""
        if self._overlay is None:
            return
        x = self._input.x()
        y = self._input.y() - _INPUT_GAP - self._overlay.height()
        screen = QGuiApplication.screenAt(self._input.geometry().center())
        if screen is not None:
            y = max(screen.geometry().top(), y)
        self._overlay.move(x, y)

    def _on_drag_moved(self, delta: QPoint) -> None:
        self._overlay.move(self._overlay.pos() + delta)
        self._input.move(self._input.pos() + delta)

    def _on_drag_finished(self) -> None:
        screen = QGuiApplication.screenAt(self._input.geometry().center()) or self._target_screen()
        if screen is None:
            return
        geo = screen.geometry()
        top = self._input.y() - _INPUT_GAP - self._overlay.passive_height     # top-left of the passive box
        self.settings.pos_x = (self._input.x() - geo.x()) / max(1, geo.width())
        self.settings.pos_y = (top - geo.y()) / max(1, geo.height())
        self.settings.screen_name = screen.name()
        self.store.save()

    def _poll_foreground(self) -> None:
        fg = win32.foreground_info()
        if not fg.own:
            moved = fg.monitor != self._fg.monitor
            self._fg = fg
            if moved and self._overlay is not None and not self._input.isVisible()                     and not self._pinned_screen_mode():
                self._reposition()
        if self._overlay is None:
            return
        typing = self._input.isVisible()
        if (
            typing
            and self._captured
            and not self._input.holding
            and fg.hwnd
            and not fg.own
            and self._typing_fg
            and fg.hwnd != self._typing_fg
        ):
            self.close_input(restore_focus=False)
            typing = False
        if self._overlay.isVisible() and not typing and not self._overlay_allowed():
            self._overlay.hide()
        if self._input.holding:                     # the channel menu is up: raising the box would bury (and close) it
            return
        if self._overlay.isVisible():
            win32.keep_topmost(int(self._overlay.winId()))
        if typing:
            self._input.keep_topmost()

    def _on_faded_out(self) -> None:
        if self._overlay is not None and not self._overlay.expanded:
            self._overlay.hide()

    def _add_line(self, line: OverlayLine, quiet: bool = False) -> None:
        if self._overlay is None:
            return
        if quiet:                                   # waits in the history, does not pop up over the game
            self._overlay.add_line(line, quiet=True)
            return
        self._overlay.add_line(line)
        if self._input.isVisible() or self._overlay_allowed():
            if not self._overlay.isVisible():
                self._reposition()
            self._show_overlay()

    def _add_system(self, text: str, error: bool = False, notice: bool = False) -> None:
        self._add_line(OverlayLine(text=text, system=True, error=error, notice=notice))

    def _highlight(self, msg: ChatMessage) -> tuple[bool, tuple[str, ...]]:
        """(counts as a mention, the words to highlight): a tag of us, or one of our /alert keywords."""
        hits = () if msg.is_self else gametools.find_keywords(msg.text, self.settings.alert_keywords)
        return msg.mentioned or bool(hits), tuple(dict.fromkeys((*msg.mentions, *hits)))

    def _line_from_message(self, msg: ChatMessage) -> OverlayLine:
        mentioned, shown = self._highlight(msg)
        return OverlayLine(text=msg.text, sender=msg.sender, timestamp=msg.timestamp,
                           color=name_color(msg.account_id, msg.is_self), images=msg.images, embeds=msg.embeds,
                           mentions=shown, mentioned=mentioned)

    # ---- bridge callbacks (GUI thread) ------------------------------------------------------------
    def _note_oldest(self, key) -> None:
        if key is not None and (self._oldest is None or tuple(key) < self._oldest):
            self._oldest = tuple(key)

    def _on_message(self, msg: ChatMessage) -> None:
        if self._active:
            self._note_oldest((msg.timestamp, msg.ordinal))
            mentioned, _shown = self._highlight(msg)
            quiet = (self.settings.display_filter == FILTER_MENTIONS and not mentioned and not msg.is_self
                     and not msg.local)
            self._add_line(self._line_from_message(msg), quiet=quiet)
            self._copy_code_from(msg)
            self._notify(msg, mentioned)
            self._track_ready(msg)
            self._track_afk(msg)

    def _notify(self, msg: ChatMessage, mentioned: bool | None = None) -> None:
        """A sound for a live message from someone else, as chosen in the settings (at most one per _SOUND_GAP)."""
        mode = self.settings.sound_mode
        if mode == SOUND_OFF or msg.is_self or msg.history or msg.local:
            return
        if mode != SOUND_ALL and not (msg.mentioned if mentioned is None else mentioned):
            return
        now = time.monotonic()
        if now - self._last_sound < _SOUND_GAP:
            return
        self._last_sound = now
        self._play_sound()

    def _copy_code_from(self, msg: ChatMessage) -> None:
        """A game / lobby / OTP code in a live message from someone else goes to the clipboard, and we say so."""
        if not self.settings.auto_copy_codes or msg.is_self or msg.history or msg.local:
            return
        code = codes.find_code(msg.text)
        if not code:
            return
        now = time.monotonic()
        if code == self._last_code and now - self._last_code_at < _CODE_REPEAT_SECONDS:
            return
        try:
            copied = self._copy_text(code)
        except Exception:
            logger.exception("[SteamChat] Could not copy the code")
            copied = False
        if copied:
            self._last_code, self._last_code_at = code, now
            self._add_system(f"Đã copy code: {code}", notice=True)
        else:
            self._add_system(f"Không copy được code: {code}", error=True)

    def _on_history(self, messages: list) -> None:
        if self._dm_pending and self._dm is not None:
            QTimer.singleShot(0, self._flush_dm_pending)   # after the backlog below is in place
        if self._active and self._overlay is not None:
            self._oldest = None
            if messages:
                self._note_oldest((messages[0].timestamp, messages[0].ordinal))
            self._overlay.set_backlog([self._line_from_message(m) for m in messages])

    def _on_older_requested(self) -> None:
        ts, ordinal = self._oldest or (0, 0)
        if not self._active or not self._bridge.request_older(ts, ordinal, _OLDER_BATCH):
            if self._overlay is not None:
                self._overlay.history_unavailable()

    def _on_older(self, messages: list, more: bool, oldest) -> None:
        if not self._active or self._overlay is None:
            return
        if any(m.chat_id != self._room_ids()[1] for m in messages):
            return                                  # answer for a room the user switched away from
        self._note_oldest(oldest)
        self._overlay.prepend_history([self._line_from_message(m) for m in messages], more)

    def _on_members(self, members: list, can_mention_all: bool) -> None:
        self._members = list(members)
        self._can_mention_all = bool(can_mention_all)
        self._push_friend_options()                 # /invite all depends on the member list
        if self._input is not None:
            self._input.set_members(self._members, self._can_mention_all)

    def _on_status(self, status: BridgeStatus) -> None:
        previous, self._last_status = self._last_status, status
        if status.state is BridgeState.NO_ROOM and self._dm is not None:
            name, self._dm = self._dm[1], None       # the private chat cannot be opened (no longer a friend?): go back
            pending = self._drop_dm_pending()
            self._show_room(self.settings.group_id, self.settings.chat_id)      # clears the overlay: report afterwards
            self._add_system(f"Không mở được chat riêng với {name}" + (f" — chưa gửi: {pending}" if pending else ""),
                             error=True)
        self._update_input_channel()
        if self._active:
            if status.connected and not previous.connected:
                self._add_system(f"Đã kết nối Steam Chat: {status.detail}")
                self._refresh_groups(force=True)
            elif previous.connected and not status.connected and status.state is not BridgeState.STOPPED:
                self._add_system(f"Mất kết nối Steam Chat — {STATUS_TEXT.get(status.state, '')}", error=True)
        self.status_changed.emit(status)

    def _on_submit(self, text: str) -> None:
        if not text:
            self.close_input()
            return
        self._input.remember_sent(text)
        if not self._run_overlay_command(text):     # the overlay's own commands never go to Steam as typed
            if self._afk is not None and not text.startswith("/"):
                self.end_afk()                      # typing a message means we are back
            self._send_text(text)
        if self._overlay is not None:
            self._overlay.keep_live_together()
        self.close_input()

    def _run_overlay_command(self, text: str) -> bool:
        if not text.startswith("/"):
            return False
        count = commands.parse_count(text)
        if count is not None:
            self._run_count(count)
            return True
        switch = commands.parse_switch(text)
        if switch is not None:
            self._run_switch(switch)
            return True
        quiet = commands.parse_quiet(text)
        if quiet is not None:
            self.set_mentions_only(quiet.enable)
            return True
        for parse, run in ((gametools.parse_timer, self._run_timer), (gametools.parse_ready, self._run_ready),
                           (gametools.parse_join, self._run_join), (gametools.parse_invite, self._run_invite),
                           (gametools.parse_chat, self._run_chat),
                           (gametools.parse_afk, self._run_afk),
                           (gametools.parse_alert, self._run_alert), (gametools.parse_team, self._run_team),
                           (gametools.parse_pick, self._run_pick)):
            command = parse(text)
            if command is not None:
                run(command)
                return True
        return False

    def _send_text(self, text: str) -> bool:
        """Send `text` to the room and show it right away (Steam does not echo what this client sent)."""
        # sent as typed: Steam's server expands "/sticker X" itself (after checking the user owns it) and
        # rejects sticker BBCode coming from a client; the local echo shows the picture right away
        wire = mentions.apply_mentions(text, self._members, self._can_mention_all)   # "@Tai" -> [mention=..]
        if self._bridge.send(wire):
            raw = from_chat_input(wire)
            shown, images, embeds = render_rich_message(raw)
            self._add_line(OverlayLine(text=shown, sender=self._bridge.self_name or "Bạn",
                                       timestamp=int(time.time()), images=images, embeds=embeds,
                                       mentions=tuple(dict.fromkeys(name for _target, name in extract_mentions(raw))),
                                       color=name_color(self._bridge.self_account_id, True)))
            return True
        self._add_system(f"Chưa gửi được ({STATUS_TEXT.get(self._last_status.state, '')}): {text}", error=True)
        return False

    # ---- /count --------------------------------------------------------------------------------------
    @property
    def counting(self) -> bool:
        return self._count_left >= 0

    def _run_count(self, command: commands.CountCommand) -> None:
        if command.error:
            self._add_system(command.error, error=True)
        elif command.start:
            self.start_count(command.start, command.interval, command.final)
        elif self.counting:
            self.cancel_count()
            self._add_system("Đã huỷ đếm ngược", notice=True)
        else:
            self._add_system("Không có đếm ngược nào đang chạy", error=True)

    def start_count(self, start: int, interval: float = commands.COUNT_INTERVAL,
                    final: str = commands.COUNT_GO) -> None:
        """Type `start`, ..., 2, 1 and then `final` into the room, `interval` seconds apart (the first right now)."""
        self.cancel_count()
        self._count_final = final
        self._count_timer.setInterval(max(1, int(interval * 1000)))
        self._count_left = max(1, int(start))
        self._count_tick()

    def cancel_count(self) -> None:
        self._count_timer.stop()
        self._count_left = -1

    def _count_tick(self) -> None:
        number = self._count_left
        if number < 0 or not self._send_text(str(number) if number else self._count_final):
            self.cancel_count()
        elif number == 0 or (number == 1 and not self._count_final):    # the last line went out
            self.cancel_count()
        else:
            self._count_left = number - 1
            if not self._count_timer.isActive():
                self._count_timer.start()

    # ---- /room, /group ---------------------------------------------------------------------------------
    def _refresh_groups(self, force: bool = False) -> None:
        """Load the chat groups in the background (for /room and /group) unless a recent copy is cached."""
        if self._groups_loading or not self._last_status.connected:
            return
        if not force and self._groups and time.monotonic() - self._groups_at < _GROUPS_MAX_AGE:
            return
        self._groups_loading = True

        def work():
            try:
                self._sig_groups.emit(self._bridge.list_groups())
            except Exception:
                logger.exception("[SteamChat] Could not load the chat groups")
                self._sig_groups.emit(None)
        threading.Thread(target=work, name="SteamChat-Rooms", daemon=True).start()

    def _on_groups_cached(self, groups) -> None:
        self._groups_loading = False
        if groups is not None:
            self._groups, self._groups_at = list(groups), time.monotonic()
            self._push_switch_options()

    def _current_group(self):
        return next((g for g in self._groups if g.group_id == self.settings.group_id), None)

    def _push_all_friend_options(self) -> None:
        if self._input is not None:
            self._input.set_chat_options([(f.name or f.display, "online" if f.online else "offline")
                                          for f in sorted(self._all_friends, key=lambda f: (not f.online, f.name.lower()))])

    def _room_choices(self) -> list[tuple[str, str]]:
        """(room name, chat id) of the text channels of the current group."""
        group = self._current_group()
        return [(r.name, r.chat_id) for r in group.rooms if not r.voice] if group is not None else []

    def _push_switch_options(self) -> None:
        if self._input is None:
            return
        s = self.settings
        rooms = [(name, "") for name, chat_id in self._room_choices() if chat_id != s.chat_id]
        groups = [(g.name, f"{len([r for r in g.rooms if not r.voice])} kênh")
                  for g in self._groups if g.group_id != s.group_id]
        self._input.set_switch_options(rooms, groups)

    def _run_switch(self, command: commands.SwitchCommand) -> None:
        if not self._groups:
            self._refresh_groups(force=True)
            self._add_system("Chưa tải xong danh sách kênh, thử lại sau giây lát", error=True)
            return
        by_room = command.kind == commands.ROOM
        if by_room:
            options = self._room_choices()
        else:
            options = [(g.name, g.group_id) for g in self._groups]
        label = "kênh" if by_room else "nhóm"
        if not command.name:
            names = ", ".join(name for name, _id in options) or "(không có)"
            self._add_system(f"Các {label}: {names}", notice=True)
            return
        name, several = commands.resolve_name(options, command.name)
        if name is None:
            if several:
                self._add_system(f"Nhiều {label} khớp \"{command.name}\": {', '.join(several)}", error=True)
            else:
                self._add_system(f"Không có {label} nào tên \"{command.name}\"", error=True)
            return
        ident = next(i for n, i in options if n == name)
        if by_room:
            group = self._current_group()
            chat_id = ident
        else:
            self._switch_to_group(next(g for g in self._groups if g.group_id == ident))
            return
        self._switch_to(group, chat_id)

    def _switch_to_group(self, group) -> None:
        """The group's default text channel (else its first one)."""
        rooms = [r for r in group.rooms if not r.voice]
        room = next((r for r in rooms if r.is_default), rooms[0] if rooms else None)
        if room is None:
            self._add_system(f"Nhóm \"{group.name}\" không có kênh chat nào", error=True)
            return
        self._switch_to(group, room.chat_id)

    def _switch_to(self, group, chat_id: str) -> None:
        target = next((r for r in group.rooms if r.chat_id == chat_id), None)
        if self._dm is None and (group.group_id, chat_id) == (self.settings.group_id, self.settings.chat_id):
            self._add_system("Đang ở kênh này rồi", notice=True)
            return
        self.set_room(group.group_id, chat_id, group.name, target.name if target else "")
        self._add_system(f"Đã chuyển sang {group.name} / #{target.name if target else ''}", notice=True)

    def _cycle_channel(self, step: int) -> None:
        """Ctrl+Tab / Ctrl+Shift+Tab in the input bar: the next / previous text channel of the current group."""
        group = self._current_group()
        if group is None:
            self._refresh_groups(force=True)
            self._add_system("Chưa tải xong danh sách kênh, thử lại sau giây lát", error=True)
            return
        rooms = [r for r in group.rooms if not r.voice]
        if len(rooms) < 2:
            self._add_system("Nhóm này chỉ có một kênh chat", notice=True)
            return
        if self._dm is not None:                    # Ctrl+Tab in a private chat goes back to the saved channel
            self._switch_to(group, self.settings.chat_id)
            return
        current = next((i for i, r in enumerate(rooms) if r.chat_id == self.settings.chat_id), -1)
        self._switch_to(group, rooms[(current + step) % len(rooms)].chat_id)

    # ---- channel menu (click on the "# channel" label of the input bar) -----------------------------------
    _MENU_FRIENDS = 15                      # private chats offered in the menu (online friends first)

    def build_channel_menu(self) -> QMenu:
        """Channels of the current group, the other groups, and private chats with friends. Each action switches."""
        menu = QMenu()
        menu.setStyleSheet(_MENU_STYLE)
        group = self._current_group()
        in_dm = self._dm is not None
        if not self._groups:
            loading = menu.addAction("Đang tải danh sách kênh…")
            loading.setEnabled(False)
            self._refresh_groups(force=True)
        if in_dm:
            back = menu.addAction(_menu_text(f"↩ Quay lại # {self.settings.chat_name or self.settings.group_name or 'kênh đã lưu'}"))
            back.triggered.connect(self._safe_call(self._leave_dm))
            menu.addSeparator()
        if group is not None:
            menu.addSection(_menu_text(group.name))
            for room in (r for r in group.rooms if not r.voice):
                act = menu.addAction(_menu_text(f"# {room.name}"))
                act.setCheckable(True)
                act.setChecked(not in_dm and room.chat_id == self.settings.chat_id)
                act.triggered.connect(self._safe_call(lambda _=False, g=group, c=room.chat_id: self._switch_to(g, c)))
        others = [g for g in self._groups if g.group_id != self.settings.group_id]
        if others:
            sub = QMenu("Nhóm khác", menu)                  # parented: Qt owns it, not a Python wrapper
            menu.addMenu(sub)
            sub.setStyleSheet(_MENU_STYLE)
            for g in sorted(others, key=lambda g: g.name.lower()):
                act = sub.addAction(_menu_text(g.name))
                act.triggered.connect(self._safe_call(lambda _=False, g=g: self._switch_to_group(g)))
        friends = sorted(self._all_friends, key=lambda f: (not f.online, (f.name or f.display).lower()))
        if friends:
            sub = QMenu("Chat riêng", menu)                  # parented: Qt owns it, not a Python wrapper
            menu.addMenu(sub)
            sub.setStyleSheet(_MENU_STYLE)
            for f in friends[:self._MENU_FRIENDS]:
                name = f.name or f.display
                act = sub.addAction(_menu_text(("● " if f.online else "○ ") + name))
                act.setCheckable(True)
                act.setChecked(in_dm and self._dm[0] == str(f.account_id))
                act.triggered.connect(self._safe_call(lambda _=False, f=f, n=name: self.open_dm(f.account_id, n)))
            if len(friends) > self._MENU_FRIENDS:
                more = sub.addAction(f"… gõ /chat <tên> cho {len(friends) - self._MENU_FRIENDS} bạn còn lại")
                more.setEnabled(False)
        elif self._last_status.connected:
            self._fetch_friends(force=True)             # the full friends list comes with it, for next time
        return menu

    def _leave_dm(self) -> None:
        s = self.settings
        self.set_room(s.group_id, s.chat_id, s.group_name, s.chat_name)
        self._add_system(f"Đã quay lại # {s.chat_name or s.group_name}", notice=True)

    def _safe_call(self, fn):
        def run(*args):
            try:
                fn(*args)
            except Exception:
                logger.exception("[SteamChat] Channel menu action failed")
                self._add_system("Không chuyển được kênh (chi tiết trong Nhật ký Logs)", error=True)
        return run

    @staticmethod
    def _exec_menu(menu: QMenu, pos: QPoint) -> None:
        menu.exec(pos)                              # blocking; tests replace this

    def _on_channel_clicked(self, bar_top_left: QPoint) -> None:
        if self._input is None:
            return
        try:
            menu = self.build_channel_menu()
            if menu.isEmpty():
                return
            captured = self._captured
            for m in [menu, *menu.findChildren(QMenu)]:     # submenus too, else they open under the chat box
                if captured:
                    m.setWindowFlag(Qt.WindowType.WindowDoesNotAcceptFocus, True)
                    m.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
                m.aboutToShow.connect(
                    lambda m=m, cap=captured: QTimer.singleShot(
                        0,
                        lambda: (
                            win32.set_no_activate(int(m.winId()), True) if cap else None,
                            win32.keep_topmost(int(m.winId())),
                        ),
                    )
                )
            self._input.hold_open(True)
            self._open_menu = menu
            try:
                self._exec_menu(menu, bar_top_left - QPoint(0, menu.sizeHint().height() + 4))   # above the bar
            finally:
                self._open_menu = None
                self._input.hold_open(False)
            if self._input.isVisible() and not self._captured:
                self._input.activateWindow()
                self._input.edit.setFocus()
        except Exception:
            logger.exception("[SteamChat] Could not show the channel menu")

    # ---- /quiet ----------------------------------------------------------------------------------------
    def set_mentions_only(self, enable: bool | None = None) -> None:
        """Pop up only the messages that mention you (None toggles). Saved with the settings."""
        s = self.settings
        mentions_only = (s.display_filter != FILTER_MENTIONS) if enable is None else bool(enable)
        s.display_filter = FILTER_MENTIONS if mentions_only else FILTER_ALL
        self.store.save()
        self._add_system("Chỉ hiện tin khi bị tag: BẬT (tin khác vẫn xem được khi mở ô chat)" if mentions_only
                         else "Chỉ hiện tin khi bị tag: TẮT — hiện mọi tin", notice=True)

    # ---- housekeeping (timers, AFK, ready check) -------------------------------------------------------
    def _ensure_tick(self) -> None:
        if not self._tick.isActive():
            self._tick.start()

    def _reset_tools(self) -> None:
        self._tick.stop()
        self._timers.clear()
        self._afk = None
        self._ready = None
        self._join_pending = None

    def _on_tick(self) -> None:
        now = time.monotonic()
        for entry in [e for e in self._timers if e.deadline <= now]:
            self._fire_timer(entry)
        if self._afk is not None and self._afk.until is not None and now >= self._afk.until:
            self.end_afk()
        if self._ready is not None and now >= self._ready.deadline:
            self._finish_ready(timed_out=True)
        if not (self._timers or self._ready or (self._afk is not None and self._afk.until is not None)):
            self._tick.stop()

    def _alert_sound(self) -> None:
        """The sound of something the user asked for (a timer, a finished ready check); silent when sounds are off."""
        if self.settings.sound_mode != SOUND_OFF:
            self._last_sound = time.monotonic()
            self._play_sound()

    # ---- /timer ----------------------------------------------------------------------------------------
    def _run_timer(self, command: gametools.TimerCommand) -> None:
        if command.error:
            self._add_system(command.error, error=True)
        elif command.kind == "list":
            now = time.monotonic()
            if not self._timers:
                self._add_system("Chưa có hẹn giờ nào — dùng /timer 5m Boss", notice=True)
            else:
                self._add_system("Hẹn giờ: " + " · ".join(
                    f"#{e.number} {e.label} còn {gametools.format_duration(e.deadline - now)}" for e in self._timers),
                    notice=True)
        elif command.kind == "stop":
            self._stop_timers(command.target)
        else:
            self.start_timer(command.seconds, command.label, command.say)

    def start_timer(self, seconds: int, label: str, say: bool = False) -> None:
        if len(self._timers) >= gametools.MAX_TIMERS:
            self._add_system(f"Tối đa {gametools.MAX_TIMERS} hẹn giờ cùng lúc", error=True)
            return
        self._timer_seq += 1
        self._timers.append(_TimerEntry(self._timer_seq, label, time.monotonic() + seconds, say))
        self._ensure_tick()
        self._add_system(f"Đã hẹn giờ {gametools.format_duration(seconds)} — {label} (#{self._timer_seq})"
                         + (", sẽ báo lên kênh" if say else ""), notice=True)

    def _stop_timers(self, target: str) -> None:
        if target in ("all", ""):
            count, self._timers = len(self._timers), []
        else:
            keep = [e for e in self._timers if str(e.number) != target.lstrip("#")]
            count, self._timers = len(self._timers) - len(keep), keep
        self._add_system(f"Đã huỷ {count} hẹn giờ" if count else "Không có hẹn giờ nào khớp", notice=bool(count),
                         error=not count)

    def _fire_timer(self, entry: _TimerEntry) -> None:
        self._timers.remove(entry)
        self._add_system(f"⏰ {entry.label} — hết giờ!", notice=True)
        self._alert_sound()
        if entry.say:
            self._send_text(f"⏰ {entry.label}")

    # ---- /afk, /back -------------------------------------------------------------------------------------
    def _run_afk(self, command: gametools.AfkCommand) -> None:
        if command.error:
            self._add_system(command.error, error=True)
        elif command.stop:
            if self._afk is None:
                self._add_system("Bạn đang không AFK", error=True)
            else:
                self.end_afk()
        else:
            self.start_afk(command.seconds, command.message)

    def start_afk(self, seconds: int | None, message: str = "") -> None:
        now = time.monotonic()
        self._afk = _AfkState(message or "lát nữa quay lại",
                              until=now + seconds if seconds else None,
                              until_clock=time.time() + seconds if seconds else None)
        if seconds:
            self._ensure_tick()
        self._add_system(f"Đã bật AFK{f' {gametools.format_duration(seconds)}' if seconds else ''}: "
                         f"{self._afk.message} — ai tag bạn sẽ được tự trả lời. Gõ /back để quay lại", notice=True)

    def end_afk(self) -> None:
        afk, self._afk = self._afk, None
        if afk is None:
            return
        if not afk.missed:
            self._add_system("Đã hết AFK — không ai tag bạn", notice=True)
            return
        self._add_system(f"Đã hết AFK — {len(afk.missed)} lần bị tag:", notice=True)
        for sender, text, ts in afk.missed[-5:]:
            self._add_system(f"  • {sender} ({time.strftime('%H:%M', time.localtime(ts))}): {text[:90]}", notice=True)

    def _track_afk(self, msg: ChatMessage) -> None:
        afk = self._afk
        if afk is None or msg.is_self or msg.history or msg.local or not msg.mentioned:
            return
        afk.missed.append((msg.sender, msg.text, msg.timestamp or int(time.time())))
        del afk.missed[:-_MAX_MISSED]
        if not msg.personal:                        # @all / @online: noted, but not answered
            return
        now = time.monotonic()
        if now - afk.last_reply < _AFK_ANY_GAP or now - afk.replied.get(msg.account_id, -1e9) < _AFK_REPLY_GAP:
            return
        afk.last_reply = afk.replied[msg.account_id] = now
        back = f" (về khoảng {time.strftime('%H:%M', time.localtime(afk.until_clock))})" if afk.until_clock else ""
        self._send_text(f"💤 @{msg.sender} mình đang AFK: {afk.message}{back}")

    # ---- /alert ----------------------------------------------------------------------------------------
    def _run_alert(self, command: gametools.AlertCommand) -> None:
        words = list(self.settings.alert_keywords)
        if command.kind == "list":
            self._add_system("Từ khoá cảnh báo: " + ", ".join(words) if words else
                             "Chưa có từ khoá — dùng /alert lobby để thêm (gõ lại để bỏ)", notice=True)
            return
        if command.kind == "clear":
            words = []
            note = "Đã xoá hết từ khoá cảnh báo"
        elif gametools.fold(command.word) in {gametools.fold(w) for w in words}:
            words = [w for w in words if gametools.fold(w) != gametools.fold(command.word)]
            note = f"Đã bỏ từ khoá: {command.word}"
        elif len(words) >= gametools.MAX_KEYWORDS:
            self._add_system(f"Tối đa {gametools.MAX_KEYWORDS} từ khoá", error=True)
            return
        else:
            words.append(command.word)
            note = f"Đã thêm từ khoá: {command.word} — tin có từ này sẽ được tô tím và báo như khi bị tag"
        self.settings.alert_keywords = gametools.normalize_keywords(words)
        self.store.save()
        self._add_system(note, notice=True)

    # ---- /ready ----------------------------------------------------------------------------------------
    def _run_ready(self, command: gametools.ReadyCommand) -> None:
        if command.stop:
            if self._ready is None:
                self._add_system("Không có ready check nào đang chạy", error=True)
            else:
                self._ready = None
                self._add_system("Đã huỷ ready check", notice=True)
            return
        self._bridge.request_members()              # who is online may have changed
        check = gametools.ReadyCheck(command.text)
        text = "✅ Ready check" + (f": {command.text}" if command.text else "!") + " — sẵn sàng thì nhắn rồi / vô / ok"
        if self._send_text(text):
            self._ready = check
            self._ensure_tick()

    def _track_ready(self, msg: ChatMessage) -> None:
        check = self._ready
        if check is None or msg.is_self or msg.history or msg.local or not gametools.is_ready_reply(msg.text):
            return
        if not check.mark(msg.account_id, msg.sender):
            return
        if check.complete(self._members):
            self._finish_ready(timed_out=False)
        else:
            self._add_system("✅ " + check.summary(self._members), notice=True)

    def _finish_ready(self, timed_out: bool) -> None:
        check, self._ready = self._ready, None
        if check is None:
            return
        if timed_out:
            waiting = check.waiting(self._members)
            self._add_system("Hết giờ ready check — " + check.summary(self._members), error=bool(waiting),
                             notice=not waiting)
        else:
            self._add_system(f"🎉 Cả nhóm đã sẵn sàng! ({check.summary(self._members)})", notice=True)
            self._alert_sound()

    # ---- /team, /pick -----------------------------------------------------------------------------------
    def _run_team(self, command: gametools.TeamCommand) -> None:
        if command.error:
            self._add_system(command.error, error=True)
            return
        names = list(command.names) or [m.name for m in self._members if m.online]
        if not names:
            self._add_system("Chưa có danh sách thành viên đang online — thử lại sau giây lát, hoặc ghi tên: /team 2 a b c d",
                             error=True)
        elif len(names) < command.count:
            self._add_system(f"Không đủ người để chia {command.count} đội (có {len(names)})", error=True)
        else:
            self._send_text(gametools.teams_text(gametools.split_teams(names, command.count)))

    def _run_pick(self, command: gametools.PickCommand) -> None:
        if command.error:
            self._add_system(command.error, error=True)
        else:
            self._send_text(gametools.pick_text(command.options))

    # ---- friends: /join, /invite ------------------------------------------------------------------------
    def _fetch_friends(self, force: bool = False) -> None:
        """Read the online friends and their games (in the background) -> _on_friends."""
        if self._friends_loading or not self._last_status.connected:
            return
        if not force and time.monotonic() - self._friends_at < _FRIENDS_MAX_AGE:
            return
        self._friends_loading = True

        def work():
            try:
                self._sig_friends.emit(self._bridge.list_friends())
            except Exception:
                logger.exception("[SteamChat] Could not read the friends list")
                self._sig_friends.emit(None)
            try:
                self._sig_all_friends.emit(self._bridge.list_all_friends())
            except Exception:
                logger.exception("[SteamChat] Could not read the full friends list")
        threading.Thread(target=work, name="SteamChat-Friends", daemon=True).start()

    def _push_friend_options(self) -> None:
        if self._input is None:
            return
        self._input.set_join_options([(f.name, f.label) for f in self._friends if f.join_url()])
        everyone = [("all", "mọi thành viên online của nhóm chat")] if self._members else []
        self._input.set_invite_options(everyone + [(f.name, f.label or "online") for f in self._friends])

    def _run_join(self, command: gametools.JoinCommand) -> None:
        if not self._last_status.connected:
            self._add_system("Chưa kết nối Steam", error=True)
            return
        self._join_pending = command.name
        self._fetch_friends(force=True)

    def _on_friends(self, friends) -> None:
        self._friends_loading = False
        if friends is not None:
            self._friends, self._friends_at = list(friends), time.monotonic()
            self._push_friend_options()
        pending, self._join_pending = self._join_pending, None
        if pending is not None:
            self._join(pending, friends)

    def _join(self, name: str, friends) -> None:
        """Do what the right-click "Join Game" of the friend called `name` does."""
        if friends is None:
            self._add_system("Không đọc được danh sách bạn bè của Steam", error=True)
            return
        if not name:
            joinable = [f for f in friends if f.join_url()]
            shown = ", ".join(f"{f.name} ({f.label})" for f in joinable[:8])
            self._add_system(("Có thể vào game của: " + shown + (f" … (+{len(joinable) - 8})" if len(joinable) > 8 else ""))
                             if joinable else "Không người bạn nào đang ở trong game có thể vào", notice=bool(joinable),
                             error=not joinable)
            return
        friend, several = gametools.resolve_friend(friends, name)
        if friend is None:
            self._add_system(f"Nhiều bạn khớp \"{name}\": {', '.join(f.name for f in several[:6])}" if several
                             else f"Không thấy bạn bè online nào tên \"{name}\"", error=True)
        elif not friend.ingame:
            self._add_system(f"{friend.name} đang online nhưng không chơi game", error=True)
        elif friend.join_url() is None:
            self._add_system(f"{friend.name} đang chơi {friend.label} nhưng chưa mở lobby hoặc server để vào", error=True)
        else:
            self._launch(friend)

    def _launch(self, friend: gametools.FriendInfo) -> None:
        try:
            ok = self._open_url(friend.join_url() or "")
        except Exception:
            logger.exception("[SteamChat] Could not open the join link")
            ok = False
        if ok:
            self._add_system(f"Đang vào game của {friend.name} ({friend.label})…", notice=True)
        else:
            self._add_system(f"Không mở được link vào game của {friend.name}", error=True)

    def _run_invite(self, command: gametools.InviteCommand) -> None:
        """Invite a friend (or every online member of the room) to our lobby / game, like the friends list does."""
        if not self._last_status.connected:
            self._add_system("Chưa kết nối Steam", error=True)
            return
        if not command.target.strip():
            self._add_system(gametools.INVITE_USAGE, error=True)
            return
        if self._inviting:
            self._add_system("Đang gửi lời mời trước đó, đợi chút", error=True)
            return
        self._inviting = True
        target, members = command.target, list(self._members)

        def work():
            try:
                state = self._bridge.invite_state()
                if not state.get("kind"):
                    self._sig_invited.emit({"error": "Bạn chưa ở trong lobby hoặc game có thể mời — hãy mở lobby trong "
                                                     "game trước"})
                    return
                plan = gametools.plan_invite(target, self._bridge.list_friends(), members,
                                             str(state.get("lobbyId") or ""))
                if plan.error:
                    self._sig_invited.emit({"error": plan.error})
                    return
                result = self._bridge.send_invites(plan.ids)
                self._sig_invited.emit({"plan": plan, "result": result, "state": state})
            except Exception as e:
                logger.exception("[SteamChat] Could not send the invites")
                self._sig_invited.emit({"error": f"Không gửi được lời mời: {e}"})
        threading.Thread(target=work, name="SteamChat-Invite", daemon=True).start()

    def _on_invited(self, outcome) -> None:
        self._inviting = False
        if outcome.get("error"):
            self._add_system(outcome["error"], error=True)
            return
        plan, result, state = outcome["plan"], outcome["result"], outcome["state"]
        if not result.get("ok"):
            self._add_system("Steam không gửi được lời mời", error=True)
            return
        by_id = dict(zip(plan.ids, plan.names))
        sent = [by_id.get(i, str(i)) for i in result.get("sent", [])]
        where = ("lobby" if result.get("kind") == "lobby" else "game") + (f" {result.get('game')}" if result.get("game") else "")
        if not sent:
            self._add_system("Không gửi được lời mời cho ai", error=True)
            return
        shown = ", ".join(sent[:6]) + (f" … (+{len(sent) - 6})" if len(sent) > 6 else "")
        skipped = f" — bỏ qua: {'; '.join(plan.skipped)}" if plan.skipped else ""
        self._add_system(f"Đã mời {shown} vào {where}{skipped}" if len(sent) <= 6 else
                         f"Đã mời {len(sent)} người vào {where} ({shown}){skipped}", notice=True)

    # ---- /chat: private chat with a friend ---------------------------------------------------------------
    def _on_all_friends(self, friends) -> None:
        if friends is not None:
            self._all_friends = list(friends)
            self._push_all_friend_options()

    def _run_chat(self, command: gametools.ChatCommand) -> None:
        """`/chat <friend>`: mirror the private chat with that friend (backlog included) instead of the group channel."""
        target = command.target.strip()
        if not target:
            self._add_system(gametools.CHAT_USAGE, error=True)
            return
        if not self._last_status.connected and self._last_status.state not in (BridgeState.NO_ROOM,):
            self._add_system("Chưa kết nối Steam", error=True)
            return
        if self._chat_resolving:
            self._add_system("Đang tìm bạn trước đó, đợi chút", error=True)
            return
        self._chat_resolving = True

        def work():
            try:
                friends = self._bridge.list_all_friends()
                friend, several, message = gametools.resolve_friend_and_message(friends, target)
                self._sig_chat_target.emit({"target": target, "friend": friend, "several": several,
                                            "message": message})
            except Exception as e:
                logger.exception("[SteamChat] Could not look the friend up for /chat")
                self._sig_chat_target.emit({"target": target, "error": f"Không đọc được danh sách bạn bè: {e}"})
        threading.Thread(target=work, name="SteamChat-Chat", daemon=True).start()

    def _on_chat_target(self, outcome) -> None:
        self._chat_resolving = False
        if outcome.get("error"):
            self._add_system(outcome["error"], error=True)
            return
        friend, several, target = outcome.get("friend"), outcome.get("several") or [], outcome["target"]
        if friend is None:
            self._add_system(f"Nhiều bạn khớp \"{target}\": {', '.join(f.name for f in several[:6])}" if several
                             else f"Không thấy bạn bè nào tên \"{target}\"", error=True)
            return
        self.open_dm(friend.account_id, friend.name or friend.display, outcome.get("message") or "")

    def open_dm(self, account_id: int, name: str, message: str = "") -> None:
        """Show the private chat with this friend in the overlay (and send `message` to it once it has loaded).
        Not saved: the next start shows the saved channel."""
        ident = str(int(account_id))
        message = message.strip()
        if self._dm is not None and self._dm[0] == ident:
            if message:
                self._send_text(message)                # already open and loaded: send right away
            else:
                self._add_system(f"Đang chat riêng với {name} rồi", notice=True)
            return
        self._dm = (ident, name)
        self._drop_dm_pending()
        self._show_room(DM_GROUP, ident)
        self._add_system(f"Đang chat riêng với {name} (quay lại nhóm: /group hoặc /room)", notice=True)
        logger.info(f"[SteamChat] Private chat opened with {name} ({ident})" + (" with a message to send" if message else ""))
        if message:
            self._dm_pending = message
            if self.settings.history_lines <= 0:        # no backlog will come: nothing can wipe the echo
                self._flush_dm_pending()
            else:
                self._dm_send_timer.start()

    def _flush_dm_pending(self) -> None:
        self._dm_send_timer.stop()
        text, self._dm_pending = self._dm_pending, ""
        if text and self._dm is not None:
            self._send_text(text)

    def _drop_dm_pending(self) -> str:
        self._dm_send_timer.stop()
        text, self._dm_pending = self._dm_pending, ""
        return text

    # ---- emoticons -------------------------------------------------------------------------------------
    def _on_emoticons(self, emoticons) -> None:
        if self._input is not None:
            self._input.set_emoticons(emoticons or [])

    def _on_send_result(self, text: str, ok: bool, error: str) -> None:
        if not ok:
            self.cancel_count()                     # a countdown with holes is worse than none
            self._add_system(f"{send_error_text(error)}: {text}", error=True)

    def _on_embed_clicked(self, embed) -> None:
        self.close_input(restore_focus=False)
        try:
            ok = bool(self._open_embed(embed))
        except Exception:
            logger.exception("[SteamChat/Embeds] Embed click handler failed")
            ok = False
        if not ok:
            self._add_system("Không mở được liên kết", error=True)
