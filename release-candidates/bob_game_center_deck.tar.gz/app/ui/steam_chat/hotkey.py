"""System-wide hotkeys via RegisterHotKey (thread message queue) + a Qt native event filter.

RegisterHotKey works for games running in the foreground without hooks or injection. The key
combination is consumed system-wide while registered, so defaults avoid plain keys like Enter.
"""

from __future__ import annotations

import logging
import sys

from PySide6.QtCore import QAbstractNativeEventFilter, QCoreApplication, QObject, Qt, Signal
from PySide6.QtGui import QKeySequence

logger = logging.getLogger(__name__)

_IS_WIN = sys.platform == "win32"
if _IS_WIN:
    import ctypes
    from ctypes import wintypes

    _user32 = ctypes.WinDLL("user32", use_last_error=True)
    _user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_uint, ctypes.c_uint]
    _user32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]

WM_HOTKEY = 0x0312
MOD_ALT, MOD_CONTROL, MOD_SHIFT, MOD_WIN, MOD_NOREPEAT = 0x1, 0x2, 0x4, 0x8, 0x4000

_K = Qt.Key
_VK_BY_QT_KEY = {
    _K.Key_Return: 0x0D, _K.Key_Enter: 0x0D, _K.Key_Space: 0x20, _K.Key_Tab: 0x09,
    _K.Key_Backspace: 0x08, _K.Key_Escape: 0x1B, _K.Key_Insert: 0x2D, _K.Key_Delete: 0x2E,
    _K.Key_Home: 0x24, _K.Key_End: 0x23, _K.Key_PageUp: 0x21, _K.Key_PageDown: 0x22,
    _K.Key_Left: 0x25, _K.Key_Up: 0x26, _K.Key_Right: 0x27, _K.Key_Down: 0x28,
    _K.Key_Pause: 0x13, _K.Key_ScrollLock: 0x91,
    _K.Key_QuoteLeft: 0xC0, _K.Key_AsciiTilde: 0xC0, _K.Key_Minus: 0xBD, _K.Key_Equal: 0xBB,
    _K.Key_BracketLeft: 0xDB, _K.Key_BracketRight: 0xDD, _K.Key_Backslash: 0xDC,
    _K.Key_Semicolon: 0xBA, _K.Key_Apostrophe: 0xDE, _K.Key_Comma: 0xBC, _K.Key_Period: 0xBE,
    _K.Key_Slash: 0xBF,
}


def parse_hotkey(text: str) -> tuple[int, int] | None:
    """'Ctrl+Return' (QKeySequence portable text) -> (MOD_* flags, virtual-key). None if unsupported."""
    if not text:
        return None
    seq = QKeySequence.fromString(text, QKeySequence.SequenceFormat.PortableText)
    if seq.count() != 1:
        return None
    combo = seq[0]
    key, mods = combo.key(), combo.keyboardModifiers()
    value = int(key.value) if hasattr(key, "value") else int(key)
    if int(_K.Key_A.value) <= value <= int(_K.Key_Z.value) or int(_K.Key_0.value) <= value <= int(_K.Key_9.value):
        vk = value
    elif int(_K.Key_F1.value) <= value <= int(_K.Key_F24.value):
        vk = 0x70 + value - int(_K.Key_F1.value)
    else:
        vk = _VK_BY_QT_KEY.get(key)
    if vk is None:
        return None
    flags = 0
    if mods & Qt.KeyboardModifier.ControlModifier:
        flags |= MOD_CONTROL
    if mods & Qt.KeyboardModifier.AltModifier:
        flags |= MOD_ALT
    if mods & Qt.KeyboardModifier.ShiftModifier:
        flags |= MOD_SHIFT
    if mods & Qt.KeyboardModifier.MetaModifier:
        flags |= MOD_WIN
    return flags, vk


def display_hotkey(text: str) -> str:
    seq = QKeySequence.fromString(text or "", QKeySequence.SequenceFormat.PortableText)
    return seq.toString(QKeySequence.SequenceFormat.NativeText) or "—"


class _Filter(QAbstractNativeEventFilter):
    def __init__(self, manager: "GlobalHotkeys"):
        super().__init__()
        self._manager = manager

    def nativeEventFilter(self, event_type, message):
        if event_type == b"windows_generic_MSG" or event_type == "windows_generic_MSG":
            try:
                msg = wintypes.MSG.from_address(int(message))
                if msg.message == WM_HOTKEY and not msg.hWnd:
                    self._manager._dispatch(int(msg.wParam))
            except Exception:
                pass
        return False, 0


class GlobalHotkeys(QObject):
    """Named hotkeys. `triggered(name)` fires on the GUI thread. Must be used from the GUI thread."""

    triggered = Signal(str)

    _BASE_ID = 0xB0B0

    def __init__(self, parent=None):
        super().__init__(parent)
        self._ids: dict[str, int] = {}
        self._names: dict[int, str] = {}
        self._next_id = self._BASE_ID
        self._filter = None
        if _IS_WIN:
            self._filter = _Filter(self)
            QCoreApplication.instance().installNativeEventFilter(self._filter)

    def register(self, name: str, hotkey: str) -> bool:
        """(Re)bind `name`. Returns False when the combination is invalid or taken by another app."""
        self.unregister(name)
        parsed = parse_hotkey(hotkey)
        if parsed is None or not _IS_WIN:
            return False
        flags, vk = parsed
        hotkey_id = self._next_id
        self._next_id += 1
        if not _user32.RegisterHotKey(None, hotkey_id, flags | MOD_NOREPEAT, vk):
            logger.warning(f"[SteamChat] Hotkey {hotkey!r} for {name} is unavailable "
                           f"(error {ctypes.get_last_error()})")
            return False
        self._ids[name] = hotkey_id
        self._names[hotkey_id] = name
        logger.info(f"[SteamChat] Hotkey {hotkey} -> {name}")
        return True

    def unregister(self, name: str) -> None:
        hotkey_id = self._ids.pop(name, None)
        if hotkey_id is None:
            return
        self._names.pop(hotkey_id, None)
        if _IS_WIN:
            _user32.UnregisterHotKey(None, hotkey_id)

    def unregister_all(self) -> None:
        for name in list(self._ids):
            self.unregister(name)

    def close(self) -> None:
        self.unregister_all()
        app = QCoreApplication.instance()
        if self._filter is not None and app is not None:
            app.removeNativeEventFilter(self._filter)
            self._filter = None

    def _dispatch(self, hotkey_id: int) -> None:
        name = self._names.get(hotkey_id)
        if name:
            self.triggered.emit(name)
