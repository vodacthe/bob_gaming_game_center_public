"""
Game Trainer screen: search FLiNG trainers, download them directly in-app (both flingtrainer.com and the archive),
pick any supported game-version build, and run them. All network, disk and process work runs in Task threads; results
come back through queued signals.
"""

from __future__ import annotations

import functools
import html
import inspect
import logging
import os
import time

from PySide6.QtCore import QObject, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QProgressBar,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from app.core.trainer import fling_client, library
from app.core.trainer.models import (
    SOURCE_ARCHIVE,
    InstalledTrainer,
    SearchResult,
    TrainerDetail,
    TrainerError,
    TrainerFile,
    TrainerSummary,
)
from app.ui.game_card import DARK_BTN_STYLE, GREEN_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_pixmap
from app.ui.online_fix.common import (
    INPUT_STYLE,
    STATUS_COLORS,
    SpinningLoader,
    Task,
    make_button,
    progress_style,
    render_rounded_image,
)
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader

logger = logging.getLogger(__name__)
TAG = "[Trainer/UI]"

_MUTED_DISABLED_RULE = (
    "QPushButton:disabled { color: rgba(255, 255, 255, 0.42); "
    "background-color: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255, 255, 255, 0.08); }"
)
_SECTION_STYLE = "color: #64748b; font-size: 11px; font-weight: 800; letter-spacing: 1px; background: transparent;"


def _safe_slot(func):
    """Guard Qt slots so exceptions log with traceback and never reach Qt's event loop."""
    params = list(inspect.signature(func).parameters.values())[1:]
    accepts_varargs = any(p.kind is inspect.Parameter.VAR_POSITIONAL for p in params)
    max_args = len([p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if not accepts_varargs:
            args = args[:max_args]
        try:
            if not isValid(self):
                return None
            return func(self, *args, **kwargs)
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} {type(self).__name__}.{func.__name__} failed")
            return None

    return wrapper


def _wrap_label(text: str, style: str) -> QLabel:
    """Word-wrapped label that never forces its card wider than the viewport."""
    lbl = QLabel(text)
    lbl.setTextFormat(Qt.TextFormat.PlainText)     # site text is never interpreted as HTML
    lbl.setWordWrap(True)
    lbl.setMinimumWidth(1)
    lbl.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
    if style:
        lbl.setStyleSheet(style)
    return lbl


def _badge_style(color: str, bg: str, border: str) -> str:
    return (f"color: {color}; background-color: {bg}; border: 1px solid {border}; border-radius: 5px; "
            "padding: 1px 7px; font-size: 10px; font-weight: 800;")


class _ProgressBridge(QObject):
    """Created on the UI thread; workers emit through it so the progress reaches the UI as a queued signal."""

    progress = Signal(str, int, int)    # key, bytes done, bytes total (0 = unknown)


class _TrainerCard(QFrame):
    """One trainer row: search hit and / or installed trainer, with an expandable details panel."""

    action = Signal(str, str)               # (action, key): primary, details, folder, remove, page, pick_file
    download_file = Signal(str, object)     # (key, TrainerFile)

    THUMB_W = 184
    THUMB_H = 86

    def __init__(self, summary: TrainerSummary, installed: InstalledTrainer | None = None, parent=None):
        super().__init__(parent)
        self.summary = summary
        self.installed = installed
        self.key = summary.key
        self.state = "idle"
        self._remove_armed = False
        self._version_btns: list = []
        self.setObjectName("trainerCard")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet("""
            #trainerCard {
                background-color: rgba(15, 21, 34, 0.86);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 12px;
            }
            #trainerCard:hover {
                border-color: rgba(139, 92, 246, 0.45);
                background-color: rgba(20, 28, 45, 0.92);
            }
            #trainerCard QLabel { background: transparent; border: none; }
        """)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 12, 16, 12)
        outer.setSpacing(10)

        row = QHBoxLayout()
        row.setSpacing(16)
        self.thumb_lbl = QLabel()
        self.thumb_lbl.setFixedSize(self.THUMB_W, self.THUMB_H)
        self.thumb_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thumb_lbl.setStyleSheet(
            "background-color: rgba(10, 14, 24, 0.95); "
            "border: 1px solid rgba(255, 255, 255, 0.07); border-radius: 8px;"
        )
        self.thumb_lbl.setPixmap(make_svg_pixmap("bolt", size=28, color="#475569"))
        row.addWidget(self.thumb_lbl)

        mid = QVBoxLayout()
        mid.setContentsMargins(0, 0, 0, 0)
        mid.setSpacing(5)
        title_row = QHBoxLayout()
        title_row.setSpacing(8)
        if summary.source == SOURCE_ARCHIVE:
            badge = QLabel("KHO LƯU TRỮ")
            badge.setStyleSheet(_badge_style("#cbd5e1", "rgba(148, 163, 184, 0.14)", "rgba(148, 163, 184, 0.35)"))
            badge.setToolTip("Trainer cũ từ archive.flingtrainer.com")
        else:
            badge = QLabel("FLiNG")
            badge.setStyleSheet(_badge_style("#c4b5fd", "rgba(139, 92, 246, 0.16)", "rgba(139, 92, 246, 0.45)"))
        badge.setFixedHeight(20)
        title_row.addWidget(badge)
        self.installed_badge = QLabel("ĐÃ TẢI")
        self.installed_badge.setStyleSheet(_badge_style("#052e16", "#2ed573", "#2ed573"))
        self.installed_badge.setFixedHeight(20)
        title_row.addWidget(self.installed_badge)
        self.title_lbl = _wrap_label(summary.title, "color: #f8fafc; font-size: 14px; font-weight: 700;")
        title_row.addWidget(self.title_lbl, 1)
        mid.addLayout(title_row)

        self.meta_lbl = _wrap_label("", "color: #94a3b8; font-size: 12px;")
        mid.addWidget(self.meta_lbl)
        self.state_lbl = _wrap_label("", "")
        mid.addWidget(self.state_lbl)
        self.progress = QProgressBar()
        self.progress.setFixedHeight(6)
        self.progress.setTextVisible(False)
        self.progress.setRange(0, 100)
        self.progress.setStyleSheet(progress_style("#8b5cf6"))
        self.progress.hide()
        mid.addWidget(self.progress)
        mid.addStretch(1)
        row.addLayout(mid, 1)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.primary_btn = make_button("Tải về", GREEN_BTN_STYLE + _MUTED_DISABLED_RULE, "download")
        self.primary_btn.clicked.connect(lambda: self.action.emit("primary", self.key))
        actions.addWidget(self.primary_btn)
        self.details_btn = make_button("Chi tiết", DARK_BTN_STYLE, "chevron_down")
        self.details_btn.clicked.connect(lambda: self.action.emit("details", self.key))
        actions.addWidget(self.details_btn)
        self.folder_btn = make_button("Thư mục", DARK_BTN_STYLE, "folder")
        self.folder_btn.setToolTip("Mở thư mục chứa trainer")
        self.folder_btn.clicked.connect(lambda: self.action.emit("folder", self.key))
        actions.addWidget(self.folder_btn)
        self.remove_btn = make_button("Xóa", DARK_BTN_STYLE, "trash")
        self.remove_btn.clicked.connect(self._on_remove_clicked)
        actions.addWidget(self.remove_btn)
        row.addLayout(actions)
        outer.addLayout(row)

        self.details_frame = QFrame()
        self.details_frame.setObjectName("trainerDetails")
        self.details_frame.setStyleSheet("""
            #trainerDetails {
                background-color: rgba(10, 14, 24, 0.6);
                border: 1px solid rgba(255, 255, 255, 0.06);
                border-radius: 10px;
            }
        """)
        self.details_lay = QVBoxLayout(self.details_frame)
        self.details_lay.setContentsMargins(14, 12, 14, 12)
        self.details_lay.setSpacing(8)
        self.details_frame.hide()
        outer.addWidget(self.details_frame)

        self.set_installed(installed)

    # -------------------------------------------------------------- state

    def set_installed(self, installed: InstalledTrainer | None):
        self.installed = installed
        self.installed_badge.setVisible(installed is not None)
        self.folder_btn.setVisible(installed is not None)
        self.remove_btn.setVisible(installed is not None)
        self._disarm_remove()
        if installed is not None:
            when = time.strftime("%d/%m/%Y", time.localtime(installed.installed_at)) if installed.installed_at else ""
            self.meta_lbl.setText(f"Bản: {installed.file_title}" + (f"  ·  Tải ngày {when}" if when else ""))
        else:
            parts = []
            if self.summary.updated:
                parts.append(f"Cập nhật {self.summary.updated}")
            parts.append("Kho lưu trữ · Tải trực tiếp" if self.summary.source == SOURCE_ARCHIVE
                         else "Tải trực tiếp trong ứng dụng")
            self.meta_lbl.setText("  ·  ".join(parts))
        if self.state in ("idle", "installed"):
            self.set_state("installed" if installed is not None else "idle")

    def set_state(self, state: str, text: str = "", kind: str = "info"):
        """idle | busy | downloading | installed (+ optional status text)."""
        self.state = state
        self.progress.setVisible(state == "downloading")
        if state != "downloading":
            self.progress.setValue(0)
        if state == "installed" or (state == "idle" and self.installed is not None):
            self.state = "installed"
            self._style_primary("Chạy", PURPLE_BTN_STYLE, "play", True)
            default = "Bấm 'Chạy', vào game rồi bật cheat bằng phím tắt (ví dụ Num 1)."
            if self.installed is not None and self.installed.anti_cheat:
                default = (f"Game dùng {self.installed.anti_cheat}: chỉ dùng trainer khi chơi offline, "
                           "dùng online có thể bị khóa tài khoản.")
                kind = "warn" if kind == "info" else kind
        elif state == "idle":
            self._style_primary("Tải về", GREEN_BTN_STYLE, "download", True)
            default = ""
        elif state == "busy":
            self._style_primary("Đang xử lý...", DARK_BTN_STYLE, "", False)
            default = "Đang xử lý..."
            kind = "busy" if kind == "info" else kind
        else:   # downloading
            self._style_primary("Hủy tải", DARK_BTN_STYLE, "close", True)
            default = "Đang tải..."
            kind = "busy" if kind == "info" else kind
        can_act = state not in ("busy", "downloading")
        self.remove_btn.setEnabled(can_act)
        for btn in self._version_btns:
            if isValid(btn):
                btn.setEnabled(can_act)
        message = text or default
        self.state_lbl.setVisible(bool(message))
        self.state_lbl.setText(message)
        self.state_lbl.setStyleSheet(f"color: {STATUS_COLORS.get(kind, STATUS_COLORS['info'])}; font-size: 11px;")

    def set_progress(self, done: int, total: int):
        if total > 0:
            pct = max(0, min(100, done * 100 // total))
            self.progress.setRange(0, 100)
            self.progress.setValue(pct)
            self.state_lbl.setText(f"Đang tải... {pct}% ({done / 1048576:.1f} / {total / 1048576:.1f} MB)")
        else:
            self.progress.setRange(0, 0)
            self.state_lbl.setText(f"Đang tải... {done / 1048576:.1f} MB")

    def _style_primary(self, text: str, style: str, icon: str, enabled: bool):
        from app.ui.icons import make_svg_icon

        self.primary_btn.setText(text)
        self.primary_btn.setStyleSheet(style + _MUTED_DISABLED_RULE)
        self.primary_btn.setIcon(make_svg_icon(icon, size=14, normal_color="#ffffff") if icon else QIcon())
        self.primary_btn.setEnabled(enabled)

    def set_banner(self, pix: QPixmap | None):
        if pix is not None and not pix.isNull():
            self.thumb_lbl.setStyleSheet("background: transparent; border: none;")
            self.thumb_lbl.setPixmap(pix)

    def _on_remove_clicked(self):
        if not self._remove_armed:
            self._remove_armed = True
            self.remove_btn.setText("Bấm lần nữa để xóa")
            QTimer.singleShot(4000, self._disarm_remove)
            return
        self._disarm_remove()
        self.action.emit("remove", self.key)

    def _disarm_remove(self):
        if not isValid(self):
            return
        self._remove_armed = False
        self.remove_btn.setText("Xóa")

    # -------------------------------------------------------------- details

    def details_visible(self) -> bool:
        return self.details_frame.isVisible()

    def hide_details(self):
        self.details_frame.hide()
        self.details_btn.setText("Chi tiết")

    def show_details(self, detail: TrainerDetail):
        self._version_btns.clear()
        while self.details_lay.count():
            item = self.details_lay.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
            elif item.layout() is not None:
                _clear_layout(item.layout())

        facts = []
        if detail.game_version:
            facts.append(f"Phiên bản game hỗ trợ: <b>{html.escape(detail.game_version)}</b>")
        if detail.options_count:
            facts.append(f"{detail.options_count} tùy chọn")
        if detail.last_updated:
            facts.append(f"Cập nhật {html.escape(detail.last_updated)}")
        if facts:
            lbl = _wrap_label("  ·  ".join(facts), "color: #cbd5e1; font-size: 12px; background: transparent;")
            lbl.setTextFormat(Qt.TextFormat.RichText)
            self.details_lay.addWidget(lbl)

        if detail.anti_cheat:
            warn = _wrap_label(f"Game dùng {detail.anti_cheat}. Chỉ dùng trainer khi chơi offline / chơi đơn: "
                               "dùng trong chế độ online có thể bị khóa tài khoản.",
                               f"color: {STATUS_COLORS['warn']}; font-size: 12px; font-weight: 600; "
                               "background: transparent;")
            self.details_lay.addWidget(warn)

        if detail.options:
            head = QLabel("PHÍM TẮT")
            head.setStyleSheet(_SECTION_STYLE)
            self.details_lay.addWidget(head)
            grid = QGridLayout()
            grid.setHorizontalSpacing(18)
            grid.setVerticalSpacing(5)
            half = (len(detail.options) + 1) // 2
            for i, opt in enumerate(detail.options):
                col = 0 if i < half else 2
                r = i if i < half else i - half
                key_lbl = QLabel(opt.hotkey)
                key_lbl.setTextFormat(Qt.TextFormat.PlainText)
                key_lbl.setStyleSheet(
                    "color: #e2e8f0; background-color: rgba(139, 92, 246, 0.18); "
                    "border: 1px solid rgba(139, 92, 246, 0.4); border-radius: 5px; "
                    "padding: 1px 6px; font-size: 11px; font-weight: 700;"
                )
                key_lbl.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
                name_lbl = _wrap_label(opt.name, "color: #cbd5e1; font-size: 12px; background: transparent;")
                grid.addWidget(key_lbl, r, col, Qt.AlignmentFlag.AlignLeft)
                grid.addWidget(name_lbl, r, col + 1)
            grid.setColumnStretch(1, 1)
            grid.setColumnStretch(3, 1)
            self.details_lay.addLayout(grid)
        elif self.summary.source == SOURCE_ARCHIVE:
            note = _wrap_label("Trainer cũ trong kho lưu trữ: danh sách phím tắt hiện trong cửa sổ trainer khi chạy.",
                               "color: #94a3b8; font-size: 12px; background: transparent;")
            self.details_lay.addWidget(note)

        if detail.files and self.summary.source != SOURCE_ARCHIVE:
            head = QLabel(f"CÁC BẢN TRAINER ({len(detail.files)} BẢN - MỚI NHẤT Ở TRÊN)")
            head.setStyleSheet(_SECTION_STYLE)
            self.details_lay.addWidget(head)
            can_act = self.state not in ("busy", "downloading")
            for idx, f in enumerate(detail.files):
                ver_row = QHBoxLayout()
                ver_row.setSpacing(10)
                is_current = self.installed is not None and self.installed.file_title == f.title
                if is_current:
                    cur_badge = QLabel("ĐANG CÀI")
                    cur_badge.setStyleSheet(_badge_style("#052e16", "#2ed573", "#2ed573"))
                    cur_badge.setFixedHeight(18)
                    ver_row.addWidget(cur_badge)
                info = "  ·  ".join(x for x in (f.added, f.size_text) if x)
                lbl = _wrap_label(html.escape(f.title) + (f"   <span style='color:#64748b;'>{html.escape(info)}</span>"
                                                          if info else ""),
                                  "color: #cbd5e1; font-size: 12px; background: transparent;")
                lbl.setTextFormat(Qt.TextFormat.RichText)
                ver_row.addWidget(lbl, 1)
                btn_style = (GREEN_BTN_STYLE if idx == 0 and self.installed is None else DARK_BTN_STYLE) + _MUTED_DISABLED_RULE
                dl_btn = make_button("Tải lại" if is_current else "Tải bản này", btn_style, "download", small=True)
                dl_btn.setEnabled(can_act)
                dl_btn.clicked.connect(lambda _checked=False, tf=f: self.download_file.emit(self.key, tf))
                self._version_btns.append(dl_btn)
                ver_row.addWidget(dl_btn)
                self.details_lay.addLayout(ver_row)
            hint = _wrap_label("Bấm 'Tải về' ở trên để lấy bản mới nhất, hoặc chọn đúng bản khớp với phiên bản (patch) "
                               "game của bạn.",
                               "color: #64748b; font-size: 11px; background: transparent;")
            self.details_lay.addWidget(hint)

        btns = QHBoxLayout()
        btns.setSpacing(8)
        if self.summary.source != SOURCE_ARCHIVE:
            page_btn = make_button("Mở trang FLiNG", DARK_BTN_STYLE, "globe", small=True)
            page_btn.clicked.connect(lambda: self.action.emit("page", self.key))
            btns.addWidget(page_btn)
            pick_btn = make_button("Chọn file có sẵn...", DARK_BTN_STYLE, "folder", small=True)
            pick_btn.setToolTip("Nhập file trainer (.zip, .rar, .7z, .exe) đã có sẵn trên máy")
            pick_btn.clicked.connect(lambda: self.action.emit("pick_file", self.key))
            btns.addWidget(pick_btn)
        btns.addStretch(1)
        self.details_lay.addLayout(btns)

        self.details_frame.show()
        self.details_btn.setText("Thu gọn")


def _clear_layout(layout):
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w is not None:
            w.deleteLater()
        elif item.layout() is not None:
            _clear_layout(item.layout())


class TrainerScreen(QWidget):
    """Full screen under CÔNG CỤ NÂNG CAO: search, download and run FLiNG trainers."""

    back_requested = Signal()

    def __init__(self, config: dict, parent=None, trainer_library: library.TrainerLibrary | None = None,
                 client: fling_client.FlingClient | None = None):
        super().__init__(parent)
        self.setObjectName("trainerScreen")
        self.config = config
        self._library = trainer_library or library.get_library()
        self._client = client or fling_client.get_client()
        self._search_req = 0
        self._searching = False
        self._results: list[TrainerSummary] = []
        self._details: dict[str, TrainerDetail] = {}
        self._installed: dict[str, InstalledTrainer] = {}
        self._result_cards: dict[str, _TrainerCard] = {}
        self._installed_cards: dict[str, _TrainerCard] = {}
        self._detail_loading: set[str] = set()
        self._after_detail: dict[str, set[str]] = {}    # key -> {"details", "get"} to run once the detail arrives
        self._downloading: set[str] = set()             # trainers currently downloading in-app
        self._banner_cache: dict[str, QPixmap] = {}
        self._banner_loading: set[str] = set()
        self._downloads_dir = library.downloads_dir()

        self._bridge = _ProgressBridge(self)
        self._bridge.progress.connect(self._on_progress)

        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self._library.cancel_all)

        self._setup_ui()
        self.reload_installed()
        logger.info(f"{TAG} Screen created (library: {self._library.root})")

    # -------------------------------------------------------------- layout

    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.header = ScreenHeader(
            "Game Trainer",
            "bolt",
            subtitle="Tìm trainer FLiNG cho game, tải về và chạy ngay trong Bob Gaming. Chỉ dùng khi chơi offline.",
        )
        self.header.back_requested.connect(self._on_back)
        self.count_badge = self.header.add_badge("ĐÃ TẢI: 0", "off")
        self.folder_btn = self.header.add_button("Thư mục trainer", "secondary", icon="folder",
                                                 tooltip="Mở thư mục chứa các trainer đã tải")
        self.folder_btn.clicked.connect(self._on_open_root)
        self.site_btn = self.header.add_button("Trang FLiNG", "secondary", icon="globe",
                                               tooltip="Mở flingtrainer.com trong trình duyệt")
        self.site_btn.clicked.connect(self._on_open_site)
        root.addWidget(self.header)

        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(*CONTENT_MARGINS)
        lay.setSpacing(14)

        search_row = QHBoxLayout()
        search_row.setSpacing(10)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Nhập tên game (tiếng Anh), ví dụ: Elden Ring, Black Myth, Cyberpunk")
        self.search_edit.setFixedHeight(36)
        self.search_edit.setStyleSheet(INPUT_STYLE)
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.returnPressed.connect(self._on_search)
        search_row.addWidget(self.search_edit, 1)
        self.search_btn = make_button("Tìm trainer", PURPLE_BTN_STYLE + _MUTED_DISABLED_RULE, "search")
        self.search_btn.clicked.connect(self._on_search)
        search_row.addWidget(self.search_btn)
        lay.addLayout(search_row)

        status_card = QFrame()
        status_card.setObjectName("trainerStatusBar")
        status_card.setStyleSheet("""
            #trainerStatusBar {
                background-color: rgba(15, 21, 34, 0.72);
                border: 1px solid rgba(255, 255, 255, 0.07);
                border-radius: 10px;
            }
            #trainerStatusBar QLabel { background: transparent; border: none; }
        """)
        status_lay = QHBoxLayout(status_card)
        status_lay.setContentsMargins(14, 10, 14, 10)
        status_lay.setSpacing(10)
        self.spinner = SpinningLoader(size=16, line_width=2, color="#38bdf8", parent=status_card)
        self.spinner.hide()
        status_lay.addWidget(self.spinner)
        self.status_label = QLabel("Nhập tên game rồi bấm 'Tìm trainer'. Trainer chạy kèm game và bật cheat "
                                   "bằng phím tắt.")
        self.status_label.setTextFormat(Qt.TextFormat.PlainText)
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet(f"color: {STATUS_COLORS['info']}; font-size: 12px;")
        status_lay.addWidget(self.status_label, 1)
        lay.addWidget(status_card)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        container = QWidget()
        container.setStyleSheet("background: transparent;")
        col = QVBoxLayout(container)
        col.setContentsMargins(0, 0, 4, 8)
        col.setSpacing(10)

        self.results_title = QLabel("KẾT QUẢ TÌM KIẾM")
        self.results_title.setStyleSheet(_SECTION_STYLE)
        col.addWidget(self.results_title)
        self.results_note = _wrap_label("", "color: #94a3b8; font-size: 13px; background: transparent;")
        col.addWidget(self.results_note)
        self.results_box = QVBoxLayout()
        self.results_box.setSpacing(10)
        col.addLayout(self.results_box)

        col.addSpacing(8)
        self.installed_title = QLabel("TRAINER ĐÃ TẢI")
        self.installed_title.setStyleSheet(_SECTION_STYLE)
        col.addWidget(self.installed_title)
        self.installed_empty = QLabel("Chưa có trainer nào. Nhập tên game ở ô tìm kiếm phía trên để bắt đầu.")
        self.installed_empty.setWordWrap(True)
        self.installed_empty.setStyleSheet("color: #94a3b8; font-size: 13px; background: transparent;")
        col.addWidget(self.installed_empty)
        self.installed_box = QVBoxLayout()
        self.installed_box.setSpacing(10)
        col.addLayout(self.installed_box)
        col.addStretch(1)

        self.scroll.setWidget(container)
        lay.addWidget(self.scroll, 1)
        root.addWidget(body, 1)
        self._show_results_section(False)

    def _show_results_section(self, visible: bool):
        self.results_title.setVisible(visible)
        self.results_note.setVisible(visible and not self._results)

    def _set_status(self, text: str, kind: str = "info", busy: bool = False):
        self.status_label.setText(text)
        self.status_label.setStyleSheet(f"color: {STATUS_COLORS[kind]}; font-size: 12px;")
        if busy:
            self.spinner.show()
            self.spinner.start()
        else:
            self.spinner.stop()
            self.spinner.hide()

    def _cards(self, key: str) -> list[_TrainerCard]:
        return [c for c in (self._result_cards.get(key), self._installed_cards.get(key))
                if c is not None and isValid(c)]

    def _set_card_state(self, key: str, state: str, text: str = "", kind: str = "info"):
        for card in self._cards(key):
            card.set_state(state, text, kind)

    def _new_card(self, summary: TrainerSummary, installed: InstalledTrainer | None) -> _TrainerCard:
        card = _TrainerCard(summary, installed, self)
        card.action.connect(self._on_card_action)
        card.download_file.connect(self._on_download_file)
        if summary.key in self._downloading:
            card.set_state("downloading")
        elif self._library.is_busy(summary.key):
            card.set_state("busy")
        image = summary.image_url or (installed.image_url if installed else "")
        if image:
            cached = self._banner_cache.get(image)
            if cached is not None:
                card.set_banner(cached)
            else:
                self._load_banner(image)
        return card

    # -------------------------------------------------------------- installed list

    @_safe_slot
    def reload_installed(self):
        task = Task(self._library.list_installed, label="trainer-installed", expected_errors=(TrainerError,))
        task.done.connect(self._on_installed_loaded)
        task.start_tracked()

    @_safe_slot
    def _on_installed_loaded(self, result: object, error: str):
        if error:
            self._set_status(error, "error")
            return
        items = list(result or [])
        self._installed = {t.key: t for t in items}
        for card in self._installed_cards.values():
            if isValid(card):
                card.hide()
                card.deleteLater()
        self._installed_cards.clear()
        for item in items:
            summary = TrainerSummary(key=item.key, title=item.title, page_url=item.page_url, source=item.source,
                                     image_url=item.image_url, download_url=item.download_url)
            card = self._new_card(summary, item)
            self._installed_cards[item.key] = card
            self.installed_box.addWidget(card)
        for key, card in self._result_cards.items():
            if isValid(card):
                card.set_installed(self._installed.get(key))
        self.installed_empty.setVisible(not items)
        self.installed_title.setText(f"TRAINER ĐÃ TẢI ({len(items)})" if items else "TRAINER ĐÃ TẢI")
        self.count_badge.set_state(f"ĐÃ TẢI: {len(items)}", "ok" if items else "off")

    # -------------------------------------------------------------- search

    def search_for(self, text: str):
        """Prefill the search box (e.g. from a library game) and search."""
        self.search_edit.setText(text or "")
        self._on_search()

    @_safe_slot
    def _on_search(self):
        query = self.search_edit.text().strip()
        if not query:
            self._clear_results()
            self._show_results_section(False)
            self._set_status("Nhập tên game rồi bấm 'Tìm trainer'.", "info")
            return
        if self._searching:
            return
        logger.info(f"{TAG} User searched {query!r}")
        self._searching = True
        self._search_req += 1
        req = self._search_req
        self.search_btn.setEnabled(False)
        self._set_status(f"Đang tìm trainer cho '{query}' trên FLiNG...", "busy", busy=True)
        task = Task(lambda: self._client.search(query), label="trainer-search", expected_errors=(TrainerError,))
        task.done.connect(lambda result, err, r=req, q=query: self._on_search_done(r, q, result, err))
        task.start_tracked()

    @_safe_slot
    def _on_search_done(self, req: int, query: str, result: object, error: str):
        if req != self._search_req:
            return
        self._searching = False
        self.search_btn.setEnabled(True)
        if error or not isinstance(result, SearchResult):
            self._set_status(error or "Không đọc được kết quả tìm kiếm.", "error")
            return
        self._results = list(result.items)
        self._clear_results()
        for summary in self._results:
            card = self._new_card(summary, self._installed.get(summary.key))
            self._result_cards[summary.key] = card
            self.results_box.addWidget(card)
        self.results_title.setText(f"KẾT QUẢ TÌM KIẾM ({len(self._results)})")
        self.results_note.setText(
            f"Không tìm thấy trainer cho '{query}'. Thử tên tiếng Anh hoặc ngắn hơn (ví dụ 'elden' thay vì "
            "'elden ring nightreign')." if not self._results else "")
        self._show_results_section(True)
        if result.site_error:
            self._set_status(f"Không tải được danh sách từ flingtrainer.com ({result.site_error}). Đang hiện "
                             f"{len(self._results)} trainer cũ trong kho lưu trữ, bản mới có thể bị thiếu.", "warn")
        elif self._results:
            self._set_status(f"Tìm thấy {len(self._results)} trainer cho '{query}'. Bấm 'Tải về' để lấy bản mới nhất.",
                             "ok")
        else:
            self._set_status(f"Không có trainer nào khớp với '{query}'.", "warn")
        self.scroll.verticalScrollBar().setValue(0)

    def _clear_results(self):
        for card in self._result_cards.values():
            if isValid(card):
                card.hide()
                card.deleteLater()
        self._result_cards.clear()

    # -------------------------------------------------------------- card actions

    def _summary_for(self, key: str) -> TrainerSummary | None:
        for card in self._cards(key):
            return card.summary
        return None

    @_safe_slot
    def _on_card_action(self, action: str, key: str):
        summary = self._summary_for(key)
        if summary is None:
            return
        if action == "primary":
            self._on_primary(summary)
        elif action == "details":
            self._toggle_details(summary)
        elif action == "folder":
            item = self._installed.get(key)
            if item is not None:
                QDesktopServices.openUrl(QUrl.fromLocalFile(item.folder))
        elif action == "remove":
            self._remove(summary)
        elif action == "page":
            logger.info(f"{TAG} User opened the FLiNG page of {summary.title!r}")
            QDesktopServices.openUrl(QUrl(summary.page_url))
        elif action == "pick_file":
            self._pick_file(summary)

    @_safe_slot
    def _on_download_file(self, key: str, file: object):
        if not isinstance(file, TrainerFile) or key in self._downloading or self._library.is_busy(key):
            return
        detail = self._details.get(key)
        if detail is None:
            return
        logger.info(f"{TAG} User selected trainer build {file.title!r} ({key})")
        self._download_direct(detail, file)

    def _on_primary(self, summary: TrainerSummary):
        key = summary.key
        cards = self._cards(key)
        state = cards[0].state if cards else "idle"
        if state == "downloading":
            self._library.cancel(key)
            return
        if state == "busy":
            return
        if key in self._installed:
            self._launch(key)
            return
        logger.info(f"{TAG} User asked to get trainer {summary.title!r} ({key})")
        self._with_detail(summary, "get")

    def _with_detail(self, summary: TrainerSummary, then: str):
        key = summary.key
        cached = self._details.get(key)
        if (cached is not None and summary.source == SOURCE_ARCHIVE
                and cached.summary.download_url != summary.download_url):
            self._details.pop(key, None)    # archive details are built from the summary: rebuild from this one
        if key in self._details:
            self._after_detail_loaded(key, then)
            return
        self._after_detail.setdefault(key, set()).add(then)
        if key in self._detail_loading:
            if then == "get":
                self._set_card_state(key, "busy", "Đang đọc trang trainer...")
            return
        self._detail_loading.add(key)
        if then == "get":
            self._set_card_state(key, "busy", "Đang đọc trang trainer...")
        task = Task(lambda: self._client.get_detail(summary), label=f"trainer-detail-{key}",
                    expected_errors=(TrainerError,))
        task.done.connect(lambda result, err, k=key: self._on_detail_loaded(k, result, err))
        task.start_tracked()

    @_safe_slot
    def _on_detail_loaded(self, key: str, result: object, error: str):
        self._detail_loading.discard(key)
        actions = self._after_detail.pop(key, set())
        if error or not isinstance(result, TrainerDetail):
            msg = error or "Không đọc được trang trainer."
            self._set_card_state(key, "idle", msg, "error")
            self._set_status(msg, "error")
            return
        self._details[key] = result
        for then in ("details", "get"):
            if then in actions:
                self._after_detail_loaded(key, then)

    def _after_detail_loaded(self, key: str, then: str):
        detail = self._details[key]
        if then == "details":
            for card in self._cards(key):
                card.show_details(detail)
        elif then == "get":
            self._get(detail)

    def _toggle_details(self, summary: TrainerSummary):
        cards = self._cards(summary.key)
        if cards and cards[0].details_visible():
            for card in cards:
                card.hide_details()
            return
        self._with_detail(summary, "details")

    # -------------------------------------------------------------- getting a trainer

    def _get(self, detail: TrainerDetail):
        key = detail.summary.key
        if not detail.files:
            self._set_card_state(key, "idle", "Trang FLiNG chưa có link tải cho trainer này.", "warn")
            return
        self._download_direct(detail, detail.files[0])

    def _download_direct(self, detail: TrainerDetail, file: TrainerFile):
        key = detail.summary.key
        self._downloading.add(key)
        self._set_card_state(key, "downloading", f"Đang tải {file.title}...")
        self._set_status(f"Đang tải trainer '{file.title}' từ FLiNG...", "busy", busy=True)
        bridge = self._bridge
        last = {"pct": -1}

        def on_progress(done: int, total: int):
            pct = done * 100 // total if total else -1
            if pct == last["pct"] and total:
                return
            last["pct"] = pct
            try:
                bridge.progress.emit(key, done, total)
            except RuntimeError:        # the screen is gone; the download itself continues
                pass

        task = Task(lambda: self._library.install(detail, file, progress=on_progress, client=self._client),
                    label=f"trainer-download-{key}", expected_errors=(TrainerError,))
        task.done.connect(lambda result, err, k=key: self._on_installed(k, result, err))
        task.start_tracked()

    @_safe_slot
    def _on_progress(self, key: str, done: int, total: int):
        for card in self._cards(key):
            if card.state == "downloading":
                card.set_progress(done, total)

    def _import(self, detail: TrainerDetail, path: str, matched_title: str):
        key = detail.summary.key
        file = next((f for f in detail.files if f.title == matched_title),
                    TrainerFile(title=matched_title, url=detail.summary.page_url))
        self._set_card_state(key, "busy", f"Đang giải nén {os.path.basename(path)}...")
        task = Task(lambda: self._library.import_file(detail, file, path), label=f"trainer-import-{key}",
                    expected_errors=(TrainerError,))
        task.done.connect(lambda result, err, k=key: self._on_installed(k, result, err))
        task.start_tracked()

    @_safe_slot
    def _on_installed(self, key: str, result: object, error: str):
        self._downloading.discard(key)
        if error or not isinstance(result, InstalledTrainer):
            msg = error or "Không cài được trainer."
            self._set_card_state(key, "idle", msg, "warn" if "hủy" in msg.lower() else "error")
            self._set_status(msg, "warn" if "hủy" in msg.lower() else "error", busy=bool(self._downloading))
            return
        self._installed[key] = result
        detail = self._details.get(key)
        for card in self._cards(key):
            card.set_installed(result)
            card.set_state("installed", f"Đã tải xong {result.file_title}. Bấm 'Chạy' rồi vào game.", "ok")
            if detail is not None and card.details_visible():
                card.show_details(detail)
        self._set_status(f"Trainer '{result.title}' đã sẵn sàng. Bấm 'Chạy', vào game rồi bật cheat bằng phím tắt.",
                         "ok", busy=bool(self._downloading))
        self.reload_installed()

    def _pick_file(self, summary: TrainerSummary):
        detail = self._details.get(summary.key)
        if detail is None:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Chọn file trainer có sẵn", self._downloads_dir,
                                              "Trainer (*.zip *.rar *.7z *.exe)")
        if not path:
            return
        logger.info(f"{TAG} User picked {path} for {summary.key}")
        stem = os.path.splitext(os.path.basename(path))[0]
        matched = next((f.title for f in detail.files if stem.lower().startswith(f.title.lower())), stem)
        self._import(detail, path, matched)

    # -------------------------------------------------------------- run / remove

    def _launch(self, key: str):
        item = self._installed.get(key)
        if item is None:
            return
        logger.info(f"{TAG} User launched trainer {item.title!r}")
        self._set_card_state(key, "busy", "Đang mở trainer (Windows có thể hỏi quyền quản trị)...")
        task = Task(lambda: self._library.launch(key), label=f"trainer-launch-{key}", expected_errors=(TrainerError,))
        task.done.connect(lambda result, err, k=key: self._on_launched(k, result, err))
        task.start_tracked()

    @_safe_slot
    def _on_launched(self, key: str, result: object, error: str):
        if error:
            self._set_card_state(key, "installed", error, "error")
            self._set_status(error, "error")
            self.reload_installed()     # drops the entry when the exe vanished (antivirus)
            return
        item = result if isinstance(result, InstalledTrainer) else self._installed.get(key)
        title = item.title if item else key
        self._set_card_state(key, "installed", "Trainer đã mở. Vào game rồi bật cheat bằng phím tắt.", "ok")
        if item is not None and item.anti_cheat:
            self._set_status(f"Đã mở '{title}'. Game dùng {item.anti_cheat}: chỉ dùng khi chơi offline.", "warn")
        else:
            self._set_status(f"Đã mở '{title}'. Vào game rồi bật cheat bằng phím tắt (ví dụ Num 1).", "ok")

    def _remove(self, summary: TrainerSummary):
        key = summary.key
        logger.info(f"{TAG} User removed trainer {summary.title!r}")
        self._set_card_state(key, "busy", "Đang xóa...")
        task = Task(lambda: self._library.remove(key), label=f"trainer-remove-{key}", expected_errors=(TrainerError,))
        task.done.connect(lambda result, err, k=key, t=summary.title: self._on_removed(k, t, err))
        task.start_tracked()

    @_safe_slot
    def _on_removed(self, key: str, title: str, error: str):
        if error:
            self._set_card_state(key, "installed", error, "error")
            self._set_status(error, "error")
            return
        self._installed.pop(key, None)
        card = self._result_cards.get(key)
        if card is not None and isValid(card):
            card.set_installed(None)
            card.set_state("idle")
            if card.details_visible() and key in self._details:
                card.show_details(self._details[key])
        self._set_status(f"Đã xóa trainer '{title}'.", "ok")
        self.reload_installed()

    # -------------------------------------------------------------- misc

    def _load_banner(self, url: str):
        if url in self._banner_loading:
            return
        self._banner_loading.add(url)
        client = self._client

        def _work():
            raw = client.fetch_image(url)
            if not raw:
                return None
            return render_rounded_image(raw, _TrainerCard.THUMB_W, _TrainerCard.THUMB_H, 8, top_only=False)

        task = Task(_work, label="trainer-banner")
        task.done.connect(lambda img, _err, u=url: self._on_banner_ready(u, img))
        task.start_tracked()

    @_safe_slot
    def _on_banner_ready(self, url: str, img: object):
        self._banner_loading.discard(url)
        if img is None:
            return
        pix = QPixmap.fromImage(img)
        if pix.isNull():
            return
        self._banner_cache[url] = pix
        for card in list(self._result_cards.values()) + list(self._installed_cards.values()):
            if isValid(card) and url in (card.summary.image_url, card.installed.image_url if card.installed else ""):
                card.set_banner(pix)

    @_safe_slot
    def _on_open_root(self):
        root = self._library.root
        try:
            os.makedirs(root, exist_ok=True)
        except OSError as e:
            self._set_status(f"Không tạo được thư mục trainer: {e.strerror or e}", "error")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(root))

    @_safe_slot
    def _on_open_site(self):
        QDesktopServices.openUrl(QUrl(fling_client.SITE_URL))

    @_safe_slot
    def _on_back(self):
        self.back_requested.emit()
