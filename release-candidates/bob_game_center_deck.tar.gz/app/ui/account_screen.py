"""
Account Screen for Bob Gaming Game Center.
Full-screen profile view when logged in, or interactive login form when logged out,
with standard top bar and '← Quay lại' button.
"""

import logging
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QCheckBox, QFrame,
    QRadioButton, QButtonGroup, QMessageBox, QScrollArea,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

from app.config import (
    load_config, save_config, encode_password, decode_password,
    PROVIDER_NEXTCLOUD, PROVIDER_GOOGLE_DRIVE,
)
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader
from app.ui.login_screen import ConnectionTestThread, GoogleAuthThread

logger = logging.getLogger(__name__)


class AccountScreen(QWidget):
    """Full-screen in-app Account & Cloud Authentication view."""

    back_requested = Signal()
    login_successful = Signal(dict)
    logout_requested = Signal()

    def __init__(self, config: dict, is_logged_in: bool = False, parent=None):
        super().__init__(parent)
        self.config = config.copy()
        self._is_logged_in = is_logged_in
        self._test_thread = None
        self._setup_ui()

    def set_account_state(self, is_logged_in: bool, config: dict):
        """Update account screen state dynamically."""
        self.config = config.copy()
        self._is_logged_in = is_logged_in
        self._refresh_content()

    def _setup_ui(self):
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        # ── Top Header ──
        header = ScreenHeader("Tài khoản Cloud", "user", subtitle="Tài khoản & dịch vụ đám mây")
        header.back_requested.connect(self._on_back)
        self.status_badge = header.add_badge("CHƯA KẾT NỐI", "error")
        self.main_layout.addWidget(header)

        # ── Scroll Area for Dynamic Content ──
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("background: transparent; border: none;")

        self.content_widget = QWidget()
        self.content_widget.setStyleSheet("background: transparent;")
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setContentsMargins(*CONTENT_MARGINS)
        self.content_layout.setSpacing(20)

        self.scroll.setWidget(self.content_widget)
        self.main_layout.addWidget(self.scroll)

        self._refresh_content()

    def _on_back(self):
        self.back_requested.emit()

    def _refresh_content(self):
        """Re-render profile card or login form based on authentication state."""
        # Clear existing content
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        provider = self.config.get("cloud_provider", "")
        username = self.config.get("username", "")

        if self._is_logged_in and (provider or username):
            self.status_badge.set_state("● ĐÃ KẾT NỐI", "ok")
            self._build_profile_view()
        else:
            self.status_badge.set_state("CHƯA KẾT NỐI", "error")
            self._build_login_view()

    # ── Logged In Profile View ──

    def _build_profile_view(self):
        provider = self.config.get("cloud_provider", PROVIDER_NEXTCLOUD)
        provider_name = "Google Drive" if provider == PROVIDER_GOOGLE_DRIVE else "Nextcloud"
        username = self.config.get("username", "Người dùng")
        cloud_url = self.config.get("cloud_url", "")

        card = QFrame()
        card.setObjectName("accountProfileCard")
        card.setStyleSheet("""
            #accountProfileCard {
                background-color: rgba(18, 22, 34, 0.7);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 12px;
            }
            #accountProfileCard QLabel {
                border: none;
                background: transparent;
            }
        """)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(28, 24, 28, 24)
        card_layout.setSpacing(16)

        # Profile Row
        prof_row = QHBoxLayout()
        prof_row.setSpacing(16)

        avatar = QLabel()
        avatar.setFixedSize(54, 54)
        avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        avatar.setStyleSheet("""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #8b5cf6, stop:1 #6d28d9);
            border: none;
            border-radius: 27px;
        """)
        avatar.setPixmap(make_svg_pixmap("cloud", size=28, color="#ffffff"))
        prof_row.addWidget(avatar)

        user_info = QVBoxLayout()
        user_info.setSpacing(4)
        display_user = username if username else ("Google Drive" if provider == PROVIDER_GOOGLE_DRIVE else "Người dùng")
        u_name = QLabel(display_user)
        u_name.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        u_name.setStyleSheet("color: #ffffff; background: transparent; border: none;")
        user_info.addWidget(u_name)

        if provider == PROVIDER_GOOGLE_DRIVE:
            badge_text = "Dịch vụ: Google Drive"
        else:
            badge_text = f"Dịch vụ: {provider_name}" + (f" ({cloud_url})" if cloud_url else "")
        p_badge = QLabel(badge_text)
        p_badge.setStyleSheet("color: #94a3b8; font-size: 13px; background: transparent; border: none;")
        user_info.addWidget(p_badge)
        prof_row.addLayout(user_info)
        prof_row.addStretch()

        card_layout.addLayout(prof_row)

        sep = QFrame()
        sep.setFixedHeight(1)
        sep.setStyleSheet("background-color: rgba(255, 255, 255, 0.06);")
        card_layout.addWidget(sep)

        # Details list
        details_layout = QVBoxLayout()
        details_layout.setSpacing(10)

        status_item = QLabel("✓ Tự động sao lưu & đồng bộ save game đang kích hoạt")
        status_item.setStyleSheet("color: #2ed573; font-size: 13px; font-weight: 500; background: transparent; border: none;")
        details_layout.addWidget(status_item)

        desc_item = QLabel("Các bản lưu save game mới sẽ tự động được tải lên đám mây khi bạn kết thúc trò chơi.")
        desc_item.setStyleSheet("color: #8b949e; font-size: 12px; background: transparent; border: none;")
        desc_item.setWordWrap(True)
        details_layout.addWidget(desc_item)

        card_layout.addLayout(details_layout)

        # Action Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)

        test_btn = QPushButton("Kiểm tra kết nối")
        test_btn.setObjectName("secondaryBtn")
        test_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        test_btn.setFixedHeight(36)
        test_btn.clicked.connect(self._test_connection)
        btn_row.addWidget(test_btn)

        change_acc_btn = QPushButton("Đổi tài khoản khác")
        change_acc_btn.setObjectName("secondaryBtn")
        change_acc_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        change_acc_btn.setFixedHeight(36)
        change_acc_btn.clicked.connect(self._switch_to_login_form)
        btn_row.addWidget(change_acc_btn)

        logout_btn = QPushButton("Đăng xuất")
        logout_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        logout_btn.setFixedHeight(36)
        logout_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(220, 38, 38, 0.15);
                color: #f87171;
                border: 1px solid rgba(239, 68, 68, 0.4);
                border-radius: 6px;
                font-weight: bold;
                padding: 0 16px;
            }
            QPushButton:hover {
                background-color: rgba(220, 38, 38, 0.3);
                border-color: rgba(239, 68, 68, 0.7);
            }
        """)
        logout_btn.clicked.connect(self._on_logout)
        btn_row.addWidget(logout_btn)

        btn_row.addStretch()
        card_layout.addLayout(btn_row)

        self.content_layout.addWidget(card)
        self.content_layout.addStretch()

    def _switch_to_login_form(self):
        self._is_logged_in = False
        self._refresh_content()

    # ── Login Form View ──

    def _build_login_view(self):
        card = QFrame()
        card.setObjectName("accountLoginCard")
        card.setStyleSheet("""
            #accountLoginCard {
                background-color: rgba(18, 22, 34, 0.7);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 12px;
            }
            #accountLoginCard QLabel {
                border: none;
                background: transparent;
            }
        """)
        form_layout = QVBoxLayout(card)
        form_layout.setContentsMargins(32, 28, 32, 28)
        form_layout.setSpacing(14)

        title = QLabel("Kết nối Dịch vụ Đám mây")
        title.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title.setStyleSheet("color: #ffffff; background: transparent; border: none;")
        form_layout.addWidget(title)

        subtitle = QLabel("Chọn nhà cung cấp và nhập thông tin để kích hoạt đồng bộ save game lên cloud.")
        subtitle.setStyleSheet("color: #8b949e; font-size: 13px; background: transparent; border: none;")
        form_layout.addWidget(subtitle)

        # Provider Selector Frame
        p_frame = QFrame()
        p_frame.setObjectName("accountProviderFrame")
        p_frame.setStyleSheet("""
            #accountProviderFrame {
                background-color: #121620;
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 8px;
                padding: 6px;
            }
            #accountProviderFrame QLabel {
                border: none;
                background: transparent;
            }
        """)
        p_layout = QHBoxLayout(p_frame)
        p_layout.setContentsMargins(8, 4, 8, 4)
        p_layout.setSpacing(16)

        self.provider_group = QButtonGroup(self)
        self.nc_radio = QRadioButton("Nextcloud (Máy chủ riêng)")
        self.nc_radio.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        self.nc_radio.setChecked(self.config.get("cloud_provider", PROVIDER_NEXTCLOUD) != PROVIDER_GOOGLE_DRIVE)
        self.nc_radio.toggled.connect(self._on_provider_changed)
        self.provider_group.addButton(self.nc_radio)
        p_layout.addWidget(self.nc_radio)

        self.gd_radio = QRadioButton("Google Drive")
        self.gd_radio.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        self.gd_radio.setChecked(self.config.get("cloud_provider", "") == PROVIDER_GOOGLE_DRIVE)
        self.provider_group.addButton(self.gd_radio)
        p_layout.addWidget(self.gd_radio)
        p_layout.addStretch()

        form_layout.addWidget(p_frame)

        # Nextcloud Inputs Container
        self.nc_container = QWidget()
        nc_layout = QVBoxLayout(self.nc_container)
        nc_layout.setContentsMargins(0, 0, 0, 0)
        nc_layout.setSpacing(10)

        url_lbl = QLabel("Địa chỉ máy chủ Nextcloud (URL)")
        url_lbl.setStyleSheet("color: #cbd5e1; font-weight: bold; font-size: 12px;")
        nc_layout.addWidget(url_lbl)
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("https://nextcloud.example.com")
        self.url_input.setText(self.config.get("cloud_url", ""))
        self.url_input.setFixedHeight(38)
        nc_layout.addWidget(self.url_input)

        user_lbl = QLabel("Tên đăng nhập")
        user_lbl.setStyleSheet("color: #cbd5e1; font-weight: bold; font-size: 12px;")
        nc_layout.addWidget(user_lbl)
        self.user_input = QLineEdit()
        self.user_input.setPlaceholderText("username")
        self.user_input.setText(self.config.get("username", ""))
        self.user_input.setFixedHeight(38)
        nc_layout.addWidget(self.user_input)

        pass_lbl = QLabel("Mật khẩu hoặc App Password")
        pass_lbl.setStyleSheet("color: #cbd5e1; font-weight: bold; font-size: 12px;")
        nc_layout.addWidget(pass_lbl)
        self.pass_input = QLineEdit()
        self.pass_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.pass_input.setPlaceholderText("••••••••")
        saved_pass = self.config.get("password", "")
        if saved_pass:
            self.pass_input.setText(decode_password(saved_pass))
        self.pass_input.setFixedHeight(38)
        nc_layout.addWidget(self.pass_input)

        form_layout.addWidget(self.nc_container)

        # Google Drive Info Container
        self.gd_container = QWidget()
        gd_layout = QVBoxLayout(self.gd_container)
        gd_layout.setContentsMargins(0, 0, 0, 0)
        gd_layout.setSpacing(10)
        gd_desc = QLabel("Đăng nhập bằng tài khoản Google. Trình duyệt mặc định sẽ mở ra để bạn cấp quyền truy cập Google Drive.")
        gd_desc.setStyleSheet("color: #94a3b8; font-size: 13px;")
        gd_desc.setWordWrap(True)
        gd_layout.addWidget(gd_desc)
        form_layout.addWidget(self.gd_container)

        self._on_provider_changed()

        self.remember_cb = QCheckBox("Ghi nhớ thông tin đăng nhập trên máy tính này")
        self.remember_cb.setChecked(self.config.get("remember_me", True))
        self.remember_cb.setStyleSheet("font-size: 12px; color: #cbd5e1;")
        form_layout.addWidget(self.remember_cb)

        # Actions
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)

        self.login_test_btn = QPushButton("Kiểm tra kết nối")
        self.login_test_btn.setObjectName("secondaryBtn")
        self.login_test_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.login_test_btn.setFixedHeight(40)
        self.login_test_btn.clicked.connect(self._test_connection)
        btn_layout.addWidget(self.login_test_btn)

        self.submit_btn = QPushButton("Đăng nhập && Kết nối")
        self.submit_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.submit_btn.setFixedHeight(40)
        self.submit_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8b5cf6, stop:1 #6d28d9);
                color: #ffffff;
                font-weight: bold;
                border-radius: 8px;
                padding: 0 20px;
                border: 1px solid rgba(168, 85, 247, 0.5);
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #a855f7, stop:1 #7c3aed);
            }
        """)
        self.submit_btn.clicked.connect(self._on_submit_login)
        btn_layout.addWidget(self.submit_btn)

        btn_layout.addStretch()
        form_layout.addLayout(btn_layout)

        self.content_layout.addWidget(card)
        self.content_layout.addStretch()

    def _on_provider_changed(self):
        is_nc = self.nc_radio.isChecked()
        self.nc_container.setVisible(is_nc)
        self.gd_container.setVisible(not is_nc)

    def _test_connection(self):
        if self.gd_radio.isChecked() if hasattr(self, "gd_radio") else (self.config.get("cloud_provider") == PROVIDER_GOOGLE_DRIVE):
            self._test_google_drive()
        else:
            url = self.url_input.text().strip() if hasattr(self, "url_input") else self.config.get("cloud_url", "")
            user = self.user_input.text().strip() if hasattr(self, "user_input") else self.config.get("username", "")
            pwd = self.pass_input.text() if hasattr(self, "pass_input") else decode_password(self.config.get("password", ""))
            if not url or not user or not pwd:
                QMessageBox.warning(self, "Thiếu thông tin", "Vui lòng nhập đầy đủ URL, tên người dùng và mật khẩu.")
                return
            self._test_thread = ConnectionTestThread(url, user, pwd)
            self._test_thread.result.connect(self._on_test_result)
            self._test_thread.start()

    def _test_google_drive(self):
        self._test_thread = GoogleAuthThread()
        self._test_thread.result.connect(self._on_test_result)
        self._test_thread.start()

    def _on_test_result(self, success: bool, message: str):
        if success:
            QMessageBox.information(self, "Kiểm tra kết nối", message)
        else:
            QMessageBox.critical(self, "Lỗi kết nối", message)

    def _on_submit_login(self):
        provider = PROVIDER_GOOGLE_DRIVE if self.gd_radio.isChecked() else PROVIDER_NEXTCLOUD
        new_config = {
            "cloud_provider": provider,
            "remember_me": self.remember_cb.isChecked(),
        }

        if provider == PROVIDER_NEXTCLOUD:
            url = self.url_input.text().strip()
            user = self.user_input.text().strip()
            pwd = self.pass_input.text()
            if not url or not user or not pwd:
                QMessageBox.warning(self, "Thiếu thông tin", "Vui lòng điền đầy đủ URL, tên người dùng và mật khẩu.")
                return
            new_config["cloud_url"] = url
            new_config["username"] = user
            new_config["password"] = encode_password(pwd)
        else:
            new_config["cloud_url"] = ""
            new_config["username"] = "Google Drive"
            new_config["password"] = ""

        self.config.update(new_config)
        self.login_successful.emit(self.config)
        self._is_logged_in = True
        self._refresh_content()

    def _on_logout(self):
        reply = QMessageBox.question(
            self,
            "Xác nhận đăng xuất",
            "Bạn có chắc muốn đăng xuất khỏi dịch vụ đám mây?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self._is_logged_in = False
            self.logout_requested.emit()
            self._refresh_content()
