"""
Utility selector dialog for Bob Gaming Game Center.
Shows available utility tools with enable/disable states and SVG vector icons.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QWidget,
    QGraphicsDropShadowEffect, QStyle, QStyleOption
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont, QPainter

from app.ui.icons import make_svg_pixmap


_UTILITIES = [
    ("remote_gaming", "cast", "Remote Gaming (Sunshine/Apollo)",
     "Stream game từ PC máy chủ nội bộ với độ trễ cực thấp", True),
    ("steam_artwork", "image", "Quản lý ảnh bìa Steam",
     "Tải và đồng bộ ảnh bìa cho game Non-Steam trong thư viện", True),
    ("controller_mapper", "controller", "Ánh xạ phím tay cầm",
     "Gán tổ hợp nút gamepad sang phím tắt bàn phím tiện lợi", True),
    ("log_console", "terminal", "Nhật ký hệ thống (Live Logs)",
     "Theo dõi tiến trình và nhật ký hoạt động thời gian thực", True),
    ("net_unblock", "globe", "Mở chặn mạng (DPI & DNS)",
     "Vượt chặn DNS & SNI nhà mạng cho Steam, Reddit, Discord", True),
    ("game_trainer", "gamepad", "Can thiệp Game (Trainer)",
     "Bộ nhớ tùy biến và tiện ích hỗ trợ game", False),
    ("steam_chat", "chat", "Steam Chat Overlay",
     "Hiện & trả lời chat nhóm Steam ngay trong game", True),
]

_DIALOG_WIDTH = 480
_DIALOG_HEIGHT = 96 * len(_UTILITIES) + 61


class _UtilityCard(QWidget):
    """A clickable card for each utility option."""

    clicked = Signal(str)  # utility_id

    def __init__(self, utility_id: str, icon_name: str, title: str,
                 description: str, enabled: bool = True, parent=None):
        super().__init__(parent)
        self._id = utility_id
        self._enabled = enabled

        self.setFixedHeight(80)
        self.setMinimumWidth(400)
        if enabled:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
            self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)  # controller navigation (gamepad_nav)

        self._apply_style(hovered=False)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(16)

        # Icon wrapper for a premium look
        self.icon_box = QWidget()
        self.icon_box.setObjectName("iconBox")
        self.icon_box.setFixedSize(48, 48)

        if enabled:
            self.icon_box.setStyleSheet("""
                #iconBox {
                    background-color: rgba(212, 175, 55, 0.12);
                    border: 1px solid rgba(212, 175, 55, 0.35);
                    border-radius: 8px;
                }
            """)
        else:
            self.icon_box.setStyleSheet("""
                #iconBox {
                    background-color: rgba(255, 255, 255, 0.03);
                    border: 1px solid rgba(255, 255, 255, 0.05);
                    border-radius: 8px;
                }
            """)

        box_layout = QHBoxLayout(self.icon_box)
        box_layout.setContentsMargins(0, 0, 0, 0)
        box_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        icon_color = "#f5d061" if enabled else "#4e5563"
        icon_pix = make_svg_pixmap(icon_name, size=24, color=icon_color)
        icon_label = QLabel()
        icon_label.setPixmap(icon_pix)
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_label.setStyleSheet("background: transparent; border: none;")
        box_layout.addWidget(icon_label)
        layout.addWidget(self.icon_box)

        # Text column
        text_col = QVBoxLayout()
        text_col.setSpacing(2)
        text_col.setContentsMargins(0, 0, 0, 0)

        title_label = QLabel(title)
        title_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        color = "#ffffff" if enabled else "#7a828e"
        title_label.setStyleSheet(f"color: {color}; background: transparent; border: none;")
        text_col.addWidget(title_label)

        desc_label = QLabel(description)
        desc_label.setFont(QFont("Segoe UI", 10))
        desc_color = "#9fa6b2" if enabled else "#4e5563"
        desc_label.setStyleSheet(f"color: {desc_color}; background: transparent; border: none;")
        text_col.addWidget(desc_label)

        layout.addLayout(text_col, 1)

        # Status badge or Arrow
        if not enabled:
            badge = QLabel("Sắp ra mắt")
            badge.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
            badge.setStyleSheet("""
                QLabel {
                    color: #555e6c;
                    background: rgba(255, 255, 255, 0.03);
                    border: 1px solid rgba(255, 255, 255, 0.06);
                    border-radius: 6px;
                    padding: 4px 10px;
                }
            """)
            layout.addWidget(badge)
        else:
            self.arrow = QLabel("→")
            self.arrow.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
            self.arrow.setStyleSheet("color: #a855f7; background: transparent; border: none;")
            layout.addWidget(self.arrow)

    def paintEvent(self, event):
        opt = QStyleOption()
        opt.initFrom(self)
        p = QPainter(self)
        self.style().drawPrimitive(QStyle.PrimitiveElement.PE_Widget, opt, p, self)

    def _apply_style(self, hovered: bool):
        if not self._enabled:
            self.setStyleSheet("""
                _UtilityCard {
                    background-color: rgba(13, 17, 26, 0.6);
                    border: 1px solid rgba(255, 255, 255, 0.04);
                    border-radius: 10px;
                }
            """)
        elif hovered:
            self.setStyleSheet("""
                _UtilityCard {
                    background-color: rgba(28, 35, 52, 0.95);
                    border: 1px solid rgba(139, 92, 246, 0.6);
                    border-radius: 10px;
                }
            """)
        else:
            self.setStyleSheet("""
                _UtilityCard {
                    background-color: rgba(18, 23, 34, 0.7);
                    border: 1px solid rgba(255, 255, 255, 0.07);
                    border-radius: 10px;
                }
            """)

    def enterEvent(self, event):
        if self._enabled:
            self._apply_style(hovered=True)
            if hasattr(self, 'arrow'):
                self.arrow.setStyleSheet("color: #c084fc; background: transparent; border: none;")
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._apply_style(hovered=False)
        if hasattr(self, 'arrow') and self._enabled:
            self.arrow.setStyleSheet("color: #a855f7; background: transparent; border: none;")
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if self._enabled and event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self._id)
        super().mousePressEvent(event)

    # ── Controller navigation (app/ui/gamepad_nav.py) ──

    def gamepad_activate(self):
        if self._enabled:
            self.clicked.emit(self._id)


class UtilityDialog(QDialog):
    """Modal dialog showing available utility tools."""

    utility_selected = Signal(str)  # utility_id

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Công cụ & Tiện ích")
        self.setFixedSize(_DIALOG_WIDTH, _DIALOG_HEIGHT)
        self.setWindowFlags(
            Qt.WindowType.Dialog
            | Qt.WindowType.FramelessWindowHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self._setup_ui()

    def _setup_ui(self):
        # Outer container with background
        container = QWidget(self)
        container.setObjectName("dialogContainer")
        container.setGeometry(0, 0, _DIALOG_WIDTH, _DIALOG_HEIGHT)
        container.setStyleSheet("""
            #dialogContainer {
                background-color: #0b0e14;
                border: 1px solid rgba(212, 175, 55, 0.35);
                border-radius: 16px;
            }
        """)

        shadow = QGraphicsDropShadowEffect(container)
        shadow.setBlurRadius(36)
        shadow.setOffset(0, 8)
        shadow.setColor(QColor(0, 0, 0, 180))
        container.setGraphicsEffect(shadow)

        layout = QVBoxLayout(container)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)

        # Title bar
        title_row = QHBoxLayout()
        title_row.setContentsMargins(4, 0, 4, 0)
        title = QLabel("Công cụ & Tiện ích")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        title.setStyleSheet("color: #ffffff; background: transparent; border: none;")
        title_row.addWidget(title)
        title_row.addStretch()

        close_btn = QPushButton("×")
        close_btn.setFixedSize(30, 30)
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 8px;
                color: #8b949e;
                font-family: 'Segoe UI', Arial, sans-serif;
                font-size: 16px;
                font-weight: bold;
                padding: 0px;
                min-height: 0px;
            }
            QPushButton:hover {
                background: rgba(255, 71, 87, 0.2);
                color: #ff4d4d;
                border-color: rgba(255, 71, 87, 0.4);
            }
        """)
        close_btn.clicked.connect(self.reject)
        title_row.addWidget(close_btn)
        layout.addLayout(title_row)

        # Utility cards
        for uid, icon_name, title_text, desc, enabled in _UTILITIES:
            card = _UtilityCard(uid, icon_name, title_text, desc, enabled)
            card.clicked.connect(self._on_card_clicked)
            layout.addWidget(card)

        layout.addStretch()

    def _on_card_clicked(self, utility_id: str):
        self.utility_selected.emit(utility_id)
        self.accept()
