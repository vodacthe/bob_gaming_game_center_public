"""
Exclude Dialog for Bob Gaming Game Center.
Allows users to configure gitignore-style patterns and select files to exclude
from cloud sync (e.g. machine-specific graphics, audio, resolution, and configs).
"""

import os
import logging
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QTreeWidget, QTreeWidgetItem,
    QPlainTextEdit, QLineEdit, QCheckBox,
    QSplitter, QWidget, QFrame, QHeaderView,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QColor, QBrush

from app.core.exclude_filter import (
    ExcludeFilter,
    PRESET_CONFIG_EXTS,
    PRESET_GRAPHICS_PATTERNS,
    PRESET_LOGS_CACHE,
)
from app.config import BOBIGNORE_FILENAME
from app.utils.helpers import format_size

logger = logging.getLogger(__name__)


class ExcludeDialog(QDialog):
    """
    Modal dialog to view, edit, and apply exclude rules for a game's save folder.
    """

    patterns_saved = Signal(str, list)  # game_name, patterns

    def __init__(self, game_name: str, save_path: str, initial_patterns: list[str] = None, parent=None):
        super().__init__(parent)
        self.game_name = game_name
        self.save_path = save_path
        self._updating_checks = False  # Prevent event recursion

        # Parse initial patterns
        self.patterns: list[str] = list(initial_patterns or [])

        # If no patterns provided, try loading from existing .bobignore or .syncignore
        if not self.patterns and self.save_path and os.path.isdir(self.save_path):
            temp_filter = ExcludeFilter((), save_dir=self.save_path)
            self.patterns = list(temp_filter.patterns)

        self.setWindowTitle(f"Exclude Rules — {self.game_name}")
        self.resize(720, 640)
        self.setMinimumSize(600, 500)

        self._setup_ui()
        self._scan_and_populate_files()
        self._apply_patterns_to_tree()

    def _setup_ui(self):
        """Build the dialog layout and widgets."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        # ---- Header ----
        title_label = QLabel("Quy tắc loại trừ file (Không đồng bộ Cloud)")
        title_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #ffffff;")

        desc_label = QLabel(
            "Chọn tệp hoặc nhập quy tắc định dạng .gitignore để chỉ giữ cục bộ trên máy này.\n"
            "Các tệp bị loại trừ sẽ không tải lên Cloud hoặc bị ghi đè khi đồng bộ."
        )
        desc_label.setStyleSheet("color: #8b949e; font-size: 12px; line-height: 1.4;")
        desc_label.setWordWrap(True)

        path_badge = QLabel(f"Thư mục lưu game: {self.save_path if self.save_path else 'Chưa cấu hình'}")
        path_badge.setStyleSheet(
            "background-color: #121620; color: #a855f7; padding: 6px 12px; "
            "border-radius: 6px; font-family: monospace; font-size: 11px; border: 1px solid rgba(255, 255, 255, 0.08);"
        )
        path_badge.setWordWrap(True)

        layout.addWidget(title_label)
        layout.addWidget(desc_label)
        layout.addWidget(path_badge)

        # ---- Quick Presets Bar ----
        preset_header = QLabel("Mẫu cấu hình nhanh:")
        preset_header.setStyleSheet("color: #8b949e; font-size: 12px; font-weight: bold;")
        
        preset_layout = QHBoxLayout()
        preset_layout.setSpacing(8)

        btn_cfg = QPushButton("+ Cấu hình (*.ini, *.cfg, *.xml, *.json)")
        btn_cfg.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_cfg.setStyleSheet(self._preset_btn_style())
        btn_cfg.clicked.connect(lambda: self._add_preset(PRESET_CONFIG_EXTS))

        btn_gfx = QPushButton("+ Đồ họa (*graphic*, *display*, *render*)")
        btn_gfx.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_gfx.setStyleSheet(self._preset_btn_style())
        btn_gfx.clicked.connect(lambda: self._add_preset(PRESET_GRAPHICS_PATTERNS))

        btn_log = QPushButton("+ Logs && Cache (*.log, *.bak, cache/)")
        btn_log.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_log.setStyleSheet(self._preset_btn_style())
        btn_log.clicked.connect(lambda: self._add_preset(PRESET_LOGS_CACHE))

        preset_layout.addWidget(btn_cfg)
        preset_layout.addWidget(btn_gfx)
        preset_layout.addWidget(btn_log)
        preset_layout.addStretch()

        layout.addWidget(preset_header)
        layout.addLayout(preset_layout)

        # ---- Main Content: Splitter (File Tree on Top/Left, Text Rules on Bottom/Right) ----
        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.setChildrenCollapsible(False)

        # Container Top: Files in directory
        files_widget = QWidget()
        files_layout = QVBoxLayout(files_widget)
        files_layout.setContentsMargins(0, 0, 0, 0)
        files_layout.setSpacing(6)

        files_top_row = QHBoxLayout()
        files_title = QLabel("Tệp trong thư mục lưu (Tích chọn để loại trừ)")
        files_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #c9d1d9;")
        
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Lọc tìm tệp...")
        self.search_input.setMaximumWidth(220)
        self.search_input.setStyleSheet("""
            QLineEdit {
                background-color: #0d1117;
                border: 1px solid #30363d;
                border-radius: 6px;
                padding: 4px 8px;
                color: #c9d1d9;
                font-size: 12px;
            }
            QLineEdit:focus {
                border-color: #a855f7;
            }
        """)
        self.search_input.textChanged.connect(self._filter_tree)

        files_top_row.addWidget(files_title)
        files_top_row.addStretch()
        files_top_row.addWidget(self.search_input)
        files_layout.addLayout(files_top_row)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Tệp / Thư mục", "Kích thước", "Trạng thái"])
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tree.header().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tree.setStyleSheet("""
            QTreeWidget {
                background-color: #0d1117;
                border: 1px solid #30363d;
                border-radius: 8px;
                color: #c9d1d9;
                padding: 4px;
            }
            QTreeWidget::item {
                padding: 4px;
                border-radius: 4px;
            }
            QTreeWidget::item:hover {
                background-color: #161b22;
            }
            QTreeWidget::item:selected {
                background-color: #21262d;
            }
            QHeaderView::section {
                background-color: #161b22;
                color: #8b949e;
                border: none;
                border-bottom: 1px solid #30363d;
                padding: 4px 8px;
                font-weight: bold;
                font-size: 11px;
            }
        """)
        self.tree.itemChanged.connect(self._on_tree_item_changed)
        files_layout.addWidget(self.tree)

        # Container Bottom: Gitignore rules text editor
        rules_widget = QWidget()
        rules_layout = QVBoxLayout(rules_widget)
        rules_layout.setContentsMargins(0, 0, 0, 0)
        rules_layout.setSpacing(6)

        rules_title = QLabel("Quy tắc loại trừ (.gitignore format — một quy tắc mỗi dòng)")
        rules_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #c9d1d9;")
        rules_layout.addWidget(rules_title)

        self.rules_editor = QPlainTextEdit()
        self.rules_editor.setPlaceholderText(
            "# Ví dụ:\n"
            "# *.ini          - Bỏ qua mọi file .ini trong tất cả thư mục\n"
            "# graphics.xml   - Bỏ qua file cấu hình đồ họa này\n"
            "# logs/          - Bỏ qua toàn bộ thư mục logs\n"
            "# /config.cfg    - Bỏ qua config.cfg ở thư mục gốc\n"
        )
        self.rules_editor.setStyleSheet("""
            QPlainTextEdit {
                background-color: #0d1117;
                border: 1px solid #30363d;
                border-radius: 8px;
                color: #c084fc;
                font-family: Consolas, 'Courier New', monospace;
                font-size: 12px;
                padding: 8px;
            }
            QPlainTextEdit:focus {
                border-color: #a855f7;
            }
        """)
        self.rules_editor.setPlainText("\n".join(self.patterns))
        self.rules_editor.textChanged.connect(self._on_rules_text_changed)
        rules_layout.addWidget(self.rules_editor)

        splitter.addWidget(files_widget)
        splitter.addWidget(rules_widget)
        splitter.setSizes([320, 160])
        layout.addWidget(splitter)

        # ---- Options & Summary ----
        bottom_options = QHBoxLayout()
        
        self.save_bobignore_cb = QCheckBox("Lưu quy tắc vào tệp .bobignore trong thư mục")
        self.save_bobignore_cb.setChecked(True)
        self.save_bobignore_cb.setStyleSheet("color: #8b949e; font-size: 12px;")

        self.summary_label = QLabel("0 tệp bị loại trừ")
        self.summary_label.setStyleSheet("color: #2ed573; font-weight: bold; font-size: 12px;")

        bottom_options.addWidget(self.save_bobignore_cb)
        bottom_options.addStretch()
        bottom_options.addWidget(self.summary_label)
        layout.addLayout(bottom_options)

        # ---- Action Buttons ----
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)

        self.cancel_btn = QPushButton("Hủy bỏ")
        self.cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #8b949e;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 8px;
                padding: 8px 18px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.06);
                color: #ffffff;
            }
        """)
        self.cancel_btn.clicked.connect(self.reject)

        self.save_btn = QPushButton(" Lưu && Áp dụng")
        self.save_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.save_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
                color: #0b0e14;
                border: none;
                border-radius: 8px;
                padding: 8px 24px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #fbbf24, stop:1 #f59e0b);
            }
        """)
        self.save_btn.clicked.connect(self._on_save)

        btn_layout.addStretch()
        btn_layout.addWidget(self.cancel_btn)
        btn_layout.addWidget(self.save_btn)
        layout.addLayout(btn_layout)

    def _preset_btn_style(self) -> str:
        return """
            QPushButton {
                background-color: #161b22;
                color: #58a6ff;
                border: 1px solid #30363d;
                border-radius: 6px;
                padding: 5px 10px;
                font-size: 11px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #21262d;
                border-color: #58a6ff;
            }
        """

    def _add_preset(self, patterns: list[str]):
        """Append preset patterns to editor."""
        current_text = self.rules_editor.toPlainText().strip()
        existing_lines = {l.strip() for l in current_text.splitlines() if l.strip()}
        
        to_add = [p for p in patterns if p not in existing_lines]
        if not to_add:
            return

        if current_text:
            new_text = current_text + "\n" + "\n".join(to_add)
        else:
            new_text = "\n".join(to_add)
            
        self.rules_editor.setPlainText(new_text)

    def _scan_and_populate_files(self):
        """Recursively scan save_path and build tree view."""
        self.tree.clear()
        if not self.save_path or not os.path.isdir(self.save_path):
            item = QTreeWidgetItem(self.tree, ["Thư mục lưu game không tồn tại hoặc chưa chọn.", "", ""])
            item.setDisabled(True)
            return

        self._all_items = []

        for root, dirs, files in os.walk(self.save_path):
            for file in files:
                if file in [".bobignore", ".syncignore"]:
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, self.save_path).replace("\\", "/")
                size_str = ""
                try:
                    size_str = format_size(os.path.getsize(full_path))
                except Exception:
                    pass

                item = QTreeWidgetItem(self.tree)
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(0, Qt.CheckState.Unchecked)
                item.setText(0, rel_path)
                item.setText(1, size_str)
                item.setData(0, Qt.ItemDataRole.UserRole, rel_path)
                self._all_items.append(item)

    def _on_rules_text_changed(self):
        """Triggered when user types in the rules editor."""
        self._apply_patterns_to_tree()

    def _get_active_filter(self) -> ExcludeFilter:
        """Create ExcludeFilter from editor text."""
        lines = [
            l.strip() for l in self.rules_editor.toPlainText().splitlines()
            if l.strip() and not l.strip().startswith("#")
        ]
        return ExcludeFilter(lines)

    def _apply_patterns_to_tree(self):
        """Update checkboxes and status in tree based on active rules."""
        if not hasattr(self, "_all_items"):
            return

        filter_obj = self._get_active_filter()
        self._updating_checks = True
        excluded_count = 0
        total_count = len(self._all_items)

        for item in self._all_items:
            rel_path = item.data(0, Qt.ItemDataRole.UserRole)
            if not rel_path:
                continue

            is_exc = filter_obj.is_excluded(rel_path)
            if is_exc:
                excluded_count += 1
                item.setCheckState(0, Qt.CheckState.Checked)
                item.setText(2, "● Loại trừ")
                item.setForeground(0, QBrush(QColor("#8b949e")))
                item.setForeground(2, QBrush(QColor("#ff7b72")))
            else:
                item.setCheckState(0, Qt.CheckState.Unchecked)
                item.setText(2, "● Đồng bộ")
                item.setForeground(0, QBrush(QColor("#c9d1d9")))
                item.setForeground(2, QBrush(QColor("#2ed573")))

        self._updating_checks = False
        self.summary_label.setText(f"Đã loại trừ {excluded_count} / {total_count} tệp khỏi Cloud")

    def _on_tree_item_changed(self, item: QTreeWidgetItem, column: int):
        """Handle user manually toggling a checkbox on a file item."""
        if column != 0 or self._updating_checks:
            return

        rel_path = item.data(0, Qt.ItemDataRole.UserRole)
        if not rel_path:
            return

        is_checked = (item.checkState(0) == Qt.CheckState.Checked)
        current_text = self.rules_editor.toPlainText()
        lines = current_text.splitlines()

        filter_obj = self._get_active_filter()
        currently_excluded = filter_obj.is_excluded(rel_path)

        if is_checked and not currently_excluded:
            # Add file rule to editor
            lines.append(f"/{rel_path}")
            self.rules_editor.setPlainText("\n".join(lines))
        elif not is_checked and currently_excluded:
            # Try to remove exact line matches
            new_lines = []
            removed = False
            for line in lines:
                clean = line.strip()
                if clean in (f"/{rel_path}", rel_path, os.path.basename(rel_path)):
                    removed = True
                    continue
                new_lines.append(line)

            if removed:
                self.rules_editor.setPlainText("\n".join(new_lines))
            else:
                # Matched by a wildcard rule (e.g. *.ini).
                # Re-apply to keep check state consistent with patterns.
                self._apply_patterns_to_tree()

    def _filter_tree(self, query: str):
        """Filter files displayed in the tree."""
        query_lower = query.lower().strip()
        if not hasattr(self, "_all_items"):
            return

        for item in self._all_items:
            rel_path = item.data(0, Qt.ItemDataRole.UserRole) or ""
            item.setHidden(bool(query_lower and query_lower not in rel_path.lower()))

    def _on_save(self):
        """Save patterns and close dialog."""
        lines = [
            l.strip() for l in self.rules_editor.toPlainText().splitlines()
            if l.strip() and not l.strip().startswith("#")
        ]
        self.patterns = lines

        # Optionally write .bobignore to save_path
        if self.save_bobignore_cb.isChecked() and self.save_path and os.path.isdir(self.save_path):
            bobignore_path = os.path.join(self.save_path, BOBIGNORE_FILENAME)
            try:
                content = (
                    "# Bob Gaming Game Center - Excluded files from cloud sync\n"
                    "# Files matching patterns below will NOT be uploaded or overwritten.\n\n"
                    + "\n".join(lines) + "\n"
                )
                with open(bobignore_path, "w", encoding="utf-8") as f:
                    f.write(content)
                logger.info(f"Saved .bobignore to {bobignore_path}")
            except Exception as e:
                logger.warning(f"Failed to write .bobignore: {e}")

        self.patterns_saved.emit(self.game_name, self.patterns)
        self.accept()

    def get_patterns(self) -> list[str]:
        """Return the finalized list of exclude patterns."""
        return self.patterns
