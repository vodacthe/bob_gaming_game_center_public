"""
Pairing Dialog with Apollo OTP and Standard PIN Tabs.
Follows Bob Gaming Titanium Violet & Champagne Gold luxury design.
"""

from __future__ import annotations

from typing import Optional

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTabWidget, QWidget, QProgressBar, QFrame
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QCursor

from app.core.remote.manager import RemoteGamingManager
from app.core.remote.models import RemoteHost


class PairingDialog(QDialog):
    """Dialog for pairing with a GameStream / Sunshine / Apollo host."""

    def __init__(self, host: RemoteHost, parent=None):
        super().__init__(parent)
        self.host = host
        self.manager = RemoteGamingManager.get()
        self.pairing = self.manager.pairing

        self.setWindowTitle("Ghép Đôi Thiết Bị - Remote Gaming")
        self.setFixedSize(480, 420)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)

        self._setup_ui()
        self._wire_signals()

        # If standard tab selected initially, generate PIN
        self._on_tab_changed(self.tab_widget.currentIndex())

    def _setup_ui(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #0f0f18;
                color: #ffffff;
            }
            QTabWidget::pane {
                border: 1px solid rgba(255, 255, 255, 0.1);
                background: #141422;
                border-radius: 8px;
            }
            QTabBar::tab {
                background: #1e1b4b;
                color: #94a3b8;
                padding: 8px 16px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                font-weight: 600;
            }
            QTabBar::tab:selected {
                background: #d97706;
                color: #ffffff;
            }
            QLineEdit {
                background: #1a1a2e;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 6px;
                color: #ffffff;
                padding: 8px 12px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border: 1.5px solid #fbbf24;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # Header
        header = QLabel(f"Ghép đôi với máy chủ: {self.host.hostname}")
        header.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        header.setStyleSheet("color: #fbbf24;")
        layout.addWidget(header)

        # Tabs
        self.tab_widget = QTabWidget()

        # Tab 0: Standard PIN (Default)
        tab_pin = QWidget()
        pin_layout = QVBoxLayout(tab_pin)
        pin_layout.setContentsMargins(16, 16, 16, 16)
        pin_layout.setSpacing(14)

        pin_info = QLabel("Nhập mã PIN hiển thị bên dưới vào Sunshine hoặc thông báo trên PC của bạn:")
        pin_info.setStyleSheet("color: #cbd5e1; font-size: 12px;")
        pin_info.setWordWrap(True)
        pin_layout.addWidget(pin_info)

        # PIN display box
        self.pin_display = QLabel("----")
        self.pin_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.pin_display.setFont(QFont("Segoe UI", 26, QFont.Weight.Bold))
        self.pin_display.setStyleSheet("""
            background: #10101c;
            border: 2px dashed #fbbf24;
            border-radius: 8px;
            color: #fbbf24;
            padding: 12px;
            letter-spacing: 12px;
        """)
        pin_layout.addWidget(self.pin_display)

        self.pin_status = QLabel("Đang kết nối tới PC chủ...")
        self.pin_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.pin_status.setStyleSheet("color: #38bdf8; font-size: 11px;")
        pin_layout.addWidget(self.pin_status)

        pin_layout.addStretch()
        self.tab_widget.addTab(tab_pin, "Mã PIN Chuẩn (Standard)")

        # Tab 1: Apollo OTP
        tab_otp = QWidget()
        otp_layout = QVBoxLayout(tab_otp)
        otp_layout.setContentsMargins(16, 16, 16, 16)
        otp_layout.setSpacing(12)

        otp_info = QLabel("Nhập mã OTP 4 số hiển thị trên giao diện Apollo / Sunshine:")
        otp_info.setStyleSheet("color: #cbd5e1; font-size: 12px;")
        otp_layout.addWidget(otp_info)

        self.otp_input = QLineEdit()
        self.otp_input.setPlaceholderText("0000")
        self.otp_input.setMaxLength(4)
        self.otp_input.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.otp_input.setFont(QFont("Segoe UI", 22, QFont.Weight.Bold))
        self.otp_input.setStyleSheet("letter-spacing: 8px; color: #fbbf24;")
        otp_layout.addWidget(self.otp_input)

        passphrase_info = QLabel("Mật khẩu bảo vệ (Passphrase - Để trống nếu không có):")
        passphrase_info.setStyleSheet("color: #94a3b8; font-size: 11px;")
        otp_layout.addWidget(passphrase_info)

        self.passphrase_input = QLineEdit()
        self.passphrase_input.setPlaceholderText("Passphrase (tùy chọn)")
        otp_layout.addWidget(self.passphrase_input)

        self.otp_btn = QPushButton("Xác Nhận && Ghép Đôi OTP")
        self.otp_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.otp_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #d97706, stop:1 #b45309);
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 10px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
            }
        """)
        self.otp_btn.clicked.connect(self._start_otp)
        otp_layout.addWidget(self.otp_btn)
        otp_layout.addStretch()

        self.tab_widget.addTab(tab_otp, "Apollo OTP (Tùy chọn)")

        layout.addWidget(self.tab_widget)

        # Progress bar & status
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background: rgba(255, 255, 255, 0.1);
                border: none;
                border-radius: 2px;
            }
            QProgressBar::chunk {
                background: #fbbf24;
                border-radius: 2px;
            }
        """)
        self.progress_bar.hide()
        layout.addWidget(self.progress_bar)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #94a3b8; font-size: 11px;")
        layout.addWidget(self.status_label)

        # Connect tab changes only AFTER status_label and progress_bar exist
        self.tab_widget.currentChanged.connect(self._on_tab_changed)

        # Bottom buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        self.close_btn = QPushButton("Đóng")
        self.close_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.close_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #ffffff;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 6px;
                padding: 6px 16px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.15);
            }
        """)
        self.close_btn.clicked.connect(self._on_close)
        btn_layout.addWidget(self.close_btn)
        layout.addLayout(btn_layout)

    def _wire_signals(self):
        self.pairing.pairing_progress.connect(self._on_progress)
        self.pairing.pairing_completed.connect(self._on_completed)
        self.pairing.pairing_failed.connect(self._on_failed)
        self.pairing.pin_generated.connect(self._on_pin_generated)

    def _on_tab_changed(self, index: int):
        self.status_label.setText("")
        if index == 0:
            # Standard PIN tab: Start standard PIN flow immediately
            self.pairing.cancel_pairing()
            self.progress_bar.show()
            self.pin_display.setText("----")
            self.pin_status.setText("Đang kết nối tới PC chủ...")
            self.pairing.start_pin_pairing(self.host)
        else:
            # Apollo OTP tab
            self.pairing.cancel_pairing()
            self.progress_bar.hide()
            self.otp_input.clear()
            self.otp_btn.setEnabled(True)

    def _start_otp(self):
        pin = self.otp_input.text().strip()
        passphrase = self.passphrase_input.text().strip()
        if len(pin) != 4 or not pin.isdigit():
            self.status_label.setText("Vui lòng nhập đủ 4 chữ số PIN")
            self.status_label.setStyleSheet("color: #ef4444;")
            return

        self.progress_bar.show()
        self.otp_btn.setEnabled(False)
        self.pairing.start_otp_pairing(self.host, pin, passphrase)

    def _on_pin_generated(self, pin: str):
        self.pin_display.setText(pin)
        self.pin_status.setText(f"Đang chờ nhập mã [{pin}] vào Sunshine trên PC chủ (tối đa 3 phút)...")
        self.pin_status.setStyleSheet("color: #38bdf8; font-size: 11px;")

    def _on_progress(self, msg: str):
        self.status_label.setText(msg)
        self.status_label.setStyleSheet("color: #38bdf8;")
        self.pin_status.setText(msg)

    def _on_completed(self, success: bool, msg: str):
        self.progress_bar.hide()
        self.status_label.setText(msg)
        self.status_label.setStyleSheet("color: #34d399; font-weight: bold;")
        self.pin_status.setText("Ghép đôi hoàn tất thành công!")
        self.pin_status.setStyleSheet("color: #34d399; font-size: 11px; font-weight: bold;")
        self.otp_btn.setEnabled(True)
        # Persist pairing and update UI
        self.manager.save_host_pairing(self.host)
        self.manager.select_host(self.host.uuid)
        QTimer.singleShot(1500, self.accept)

    def _on_failed(self, error: str):
        self.progress_bar.hide()
        self.status_label.setText(f"Lỗi: {error}")
        self.status_label.setStyleSheet("color: #ef4444;")
        self.pin_status.setText("Ghép đôi chưa thành công. Vui lòng thử lại.")
        self.pin_status.setStyleSheet("color: #ef4444; font-size: 11px;")
        self.otp_btn.setEnabled(True)

    def _on_close(self):
        self.pairing.cancel_pairing()
        self.reject()

    def closeEvent(self, event):
        self.pairing.cancel_pairing()
        super().closeEvent(event)
