"""
Manual Host Addition Dialog for Remote Gaming.
Allows users to enter an IP address or hostname to probe and add.
"""

from __future__ import annotations

import threading
from typing import Optional

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QProgressBar
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QCursor

from app.core.remote.manager import RemoteGamingManager


class AddHostDialog(QDialog):
    """Dialog for manually entering an IP address to add a Sunshine / GameStream host."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.manager = RemoteGamingManager.get()

        self.setWindowTitle("Thêm Máy Chủ Mới - Remote Gaming")
        self.setFixedSize(400, 260)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)

        self._setup_ui()

    def _setup_ui(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #0f0f18;
                color: #ffffff;
            }
            QLineEdit {
                background: #1a1a2e;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 6px;
                color: #ffffff;
                padding: 8px 12px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border: 1.5px solid #fbbf24;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel("Thêm PC Máy Chủ Thủ Công")
        title.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        title.setStyleSheet("color: #fbbf24;")
        layout.addWidget(title)

        desc = QLabel("Nhập địa chỉ IP nội bộ (LAN) hoặc tên miền của máy tính chạy Sunshine / Apollo:")
        desc.setStyleSheet("color: #94a3b8; font-size: 11px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # IP input
        self.ip_input = QLineEdit()
        self.ip_input.setPlaceholderText("Ví dụ: 192.168.1.100")
        layout.addWidget(self.ip_input)

        # Port input
        port_row = QHBoxLayout()
        port_label = QLabel("Cổng HTTP:")
        port_label.setStyleSheet("color: #cbd5e1; font-size: 11px;")
        port_row.addWidget(port_label)

        self.port_input = QLineEdit("47989")
        self.port_input.setFixedWidth(80)
        port_row.addWidget(self.port_input)
        port_row.addStretch()
        layout.addLayout(port_row)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.hide()
        layout.addWidget(self.progress_bar)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #94a3b8; font-size: 11px;")
        layout.addWidget(self.status_label)

        layout.addStretch()

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        self.cancel_btn = QPushButton("Hủy")
        self.cancel_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #ffffff;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 6px;
                padding: 6px 14px;
            }
        """)
        self.cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(self.cancel_btn)

        self.add_btn = QPushButton("Thăm Dò && Thêm")
        self.add_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.add_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #d97706, stop:1 #b45309);
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 6px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
            }
        """)
        self.add_btn.clicked.connect(self._start_probe)
        btn_row.addWidget(self.add_btn)

        layout.addLayout(btn_row)

    def _start_probe(self):
        ip = self.ip_input.text().strip()
        port_str = self.port_input.text().strip()

        if not ip:
            self.status_label.setText("Vui lòng nhập địa chỉ IP hoặc hostname")
            self.status_label.setStyleSheet("color: #ef4444;")
            return

        try:
            port = int(port_str)
        except ValueError:
            port = 47989

        self.progress_bar.show()
        self.add_btn.setEnabled(False)
        self.status_label.setText(f"Đang kết nối tới {ip}:{port}...")
        self.status_label.setStyleSheet("color: #38bdf8;")

        threading.Thread(
            target=self._run_probe,
            args=(ip, port),
            daemon=True,
            name=f"ProbeManual-{ip}",
        ).start()

    def _run_probe(self, ip: str, port: int):
        host = self.manager.add_host_manually(ip, port)
        if host:
            QTimer.singleShot(0, lambda: self._on_probe_success(host))
        else:
            QTimer.singleShot(0, lambda: self._on_probe_failed(ip))

    def _on_probe_success(self, host):
        self.progress_bar.hide()
        self.status_label.setText(f"Tìm thấy: {host.hostname}!")
        self.status_label.setStyleSheet("color: #34d399; font-weight: bold;")
        self.manager.select_host(host.uuid)
        QTimer.singleShot(1000, self.accept)

    def _on_probe_failed(self, ip: str):
        self.progress_bar.hide()
        self.add_btn.setEnabled(True)
        self.status_label.setText(f"Không thể kết nối tới {ip}. Hãy kiểm tra lại IP và Sunshine.")
        self.status_label.setStyleSheet("color: #ef4444;")
