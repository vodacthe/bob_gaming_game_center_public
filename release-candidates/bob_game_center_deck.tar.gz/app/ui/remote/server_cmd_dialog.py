"""
Host Quick Actions & Apollo Server Commands Dialog.
Allows executing quick host management actions anytime and Apollo control commands during active streams.
"""

from __future__ import annotations

import logging
import time
from typing import Callable, Optional

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QCursor, QFont
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.core.remote.manager import RemoteGamingManager
from app.core.remote.models import PairState, RemoteHost
from app.ui.icons import make_svg_icon

logger = logging.getLogger(__name__)

_ACTIVE_WORKERS: set["_HostActionWorker"] = set()


class _HostActionWorker(QThread):
    """Runs a blocking host network/control action off the Qt UI thread."""

    action_finished = Signal(str, bool, str)

    def __init__(self, action_id: str, fn: Callable[[], tuple[bool, str]]):
        super().__init__(None)
        self._action_id = action_id
        self._fn = fn

    def run(self) -> None:
        t0 = time.perf_counter()
        try:
            ok, msg = self._fn()
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            logger.info(
                f"[ServerCmdUI] Action '{self._action_id}' finished (ok={ok}, {elapsed_ms:.1f}ms): {msg}"
            )
            self.action_finished.emit(self._action_id, ok, msg)
        except Exception as e:
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            logger.error(
                f"[ServerCmdUI] Unexpected error in action '{self._action_id}' ({elapsed_ms:.1f}ms): {e}",
                exc_info=True,
            )
            self.action_finished.emit(self._action_id, False, str(e))


class ServerCommandDialog(QDialog):
    """Dialog for quick host actions (Wake-on-LAN, Quit App, Refresh) and Apollo server commands."""

    def __init__(self, host: RemoteHost, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.host = host
        self.manager = RemoteGamingManager.get()
        self.cmd_manager = self.manager.server_commands
        self._worker: Optional[_HostActionWorker] = None
        self._busy = False
        self._cmd_buttons: list[QPushButton] = []

        self.setWindowTitle(f"Quản Lý Máy Chủ - {self.host.hostname}")
        self.setMinimumWidth(480)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)

        self._setup_ui()
        self._wire_signals()
        self._refresh_state()
        logger.info(f"[ServerCmdUI] Opened dialog for host {self.host.hostname} ({self.host.ip})")

    @staticmethod
    def _has_valid_mac(host: RemoteHost) -> bool:
        mac_clean = (host.mac or "").replace(":", "").replace("-", "").strip()
        return len(mac_clean) == 12 and mac_clean != "0" * 12

    def _is_streaming_this_host(self) -> bool:
        ctrl = self.manager.stream_controller
        if not ctrl.is_active:
            return False
        active_host = getattr(ctrl, "active_host", None)
        return active_host is None or getattr(active_host, "uuid", None) == self.host.uuid

    def _setup_ui(self) -> None:
        self.setStyleSheet("""
            QDialog {
                background-color: #0f1420;
                color: #e2e8f0;
            }
            QFrame#sectionCard {
                background-color: #161e2e;
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
            }
            QLabel {
                background: transparent;
                border: none;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(14)

        # 1. Header with hostname + badges
        header_row = QHBoxLayout()
        header_row.setSpacing(8)

        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        self.title_label = QLabel(f"Máy chủ: {self.host.hostname}")
        self.title_label.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        self.title_label.setStyleSheet("color: #fbbf24;")
        title_col.addWidget(self.title_label)

        self.sub_label = QLabel(f"{self.host.ip}:{self.host.port}")
        self.sub_label.setStyleSheet("color: #94a3b8; font-size: 11px;")
        title_col.addWidget(self.sub_label)
        header_row.addLayout(title_col, 1)

        self.server_type_badge = QLabel("")
        header_row.addWidget(self.server_type_badge, 0, Qt.AlignmentFlag.AlignTop)

        self.online_badge = QLabel("")
        header_row.addWidget(self.online_badge, 0, Qt.AlignmentFlag.AlignTop)

        layout.addLayout(header_row)

        # 2. Quick Host Actions section
        quick_card = QFrame()
        quick_card.setObjectName("sectionCard")
        quick_layout = QVBoxLayout(quick_card)
        quick_layout.setContentsMargins(14, 12, 14, 14)
        quick_layout.setSpacing(10)

        quick_title = QLabel("THAO TÁC NHANH MÁY CHỦ")
        quick_title.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        quick_title.setStyleSheet("color: #cbd5e1; letter-spacing: 0.4px;")
        quick_layout.addWidget(quick_title)

        quick_grid = QGridLayout()
        quick_grid.setSpacing(8)

        self.btn_wake = self._make_action_button(
            "Đánh thức máy (WoL)", "bolt", "#fbbf24", self._on_wake_clicked
        )
        self.btn_refresh = self._make_action_button(
            "Làm mới trạng thái", "sync", "#38bdf8", self._on_refresh_clicked
        )
        self.btn_stop_game = self._make_action_button(
            "Dừng game đang chạy", "close", "#f87171", self._on_stop_game_clicked, danger=True
        )

        quick_grid.addWidget(self.btn_wake, 0, 0)
        quick_grid.addWidget(self.btn_refresh, 0, 1)
        quick_grid.addWidget(self.btn_stop_game, 1, 0, 1, 2)
        quick_layout.addLayout(quick_grid)
        layout.addWidget(quick_card)

        # 3. Apollo Server Commands section
        apollo_card = QFrame()
        apollo_card.setObjectName("sectionCard")
        apollo_layout = QVBoxLayout(apollo_card)
        apollo_layout.setContentsMargins(14, 12, 14, 14)
        apollo_layout.setSpacing(10)

        apollo_title = QLabel("LỆNH ĐIỀU KHIỂN HỆ THỐNG (APOLLO)")
        apollo_title.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        apollo_title.setStyleSheet("color: #cbd5e1; letter-spacing: 0.4px;")
        apollo_layout.addWidget(apollo_title)

        self.apollo_hint_label = QLabel("")
        self.apollo_hint_label.setWordWrap(True)
        self.apollo_hint_label.setStyleSheet("color: #94a3b8; font-size: 11px;")
        apollo_layout.addWidget(self.apollo_hint_label)

        self.apollo_grid_host = QWidget()
        self.apollo_grid = QGridLayout(self.apollo_grid_host)
        self.apollo_grid.setContentsMargins(0, 0, 0, 0)
        self.apollo_grid.setSpacing(8)
        apollo_layout.addWidget(self.apollo_grid_host)

        layout.addWidget(apollo_card)

        # 4. Status message + Close button
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("color: #38bdf8; font-size: 11px; min-height: 16px;")
        layout.addWidget(self.status_label)

        footer = QHBoxLayout()
        footer.addStretch()
        btn_close = QPushButton("Đóng")
        btn_close.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_close.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #e2e8f0;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 7px;
                padding: 7px 18px;
                font-weight: 600;
                font-size: 12px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.16);
                border-color: #fbbf24;
            }
        """)
        btn_close.clicked.connect(self.accept)
        footer.addWidget(btn_close)
        layout.addLayout(footer)

    def _make_action_button(
        self,
        text: str,
        icon_name: str,
        icon_color: str,
        slot: Callable[[], None],
        danger: bool = False,
    ) -> QPushButton:
        btn = QPushButton(text)
        btn.setIcon(make_svg_icon(icon_name, color=icon_color, size=14))
        btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        if danger:
            btn.setStyleSheet("""
                QPushButton {
                    background: rgba(239, 68, 68, 0.14);
                    border: 1px solid rgba(239, 68, 68, 0.35);
                    border-radius: 8px;
                    color: #fca5a5;
                    padding: 10px 12px;
                    font-weight: 600;
                    font-size: 12px;
                }
                QPushButton:hover:enabled {
                    background: rgba(239, 68, 68, 0.28);
                    border-color: #ef4444;
                    color: #ffffff;
                }
                QPushButton:disabled {
                    background: rgba(255, 255, 255, 0.03);
                    border: 1px solid rgba(255, 255, 255, 0.07);
                    color: rgba(255, 255, 255, 0.30);
                }
            """)
        else:
            btn.setStyleSheet("""
                QPushButton {
                    background: rgba(30, 41, 59, 0.85);
                    border: 1px solid rgba(255, 255, 255, 0.14);
                    border-radius: 8px;
                    color: #f1f5f9;
                    padding: 10px 12px;
                    font-weight: 600;
                    font-size: 12px;
                }
                QPushButton:hover:enabled {
                    background: rgba(217, 119, 6, 0.25);
                    border-color: #fbbf24;
                    color: #ffffff;
                }
                QPushButton:disabled {
                    background: rgba(255, 255, 255, 0.03);
                    border: 1px solid rgba(255, 255, 255, 0.07);
                    color: rgba(255, 255, 255, 0.30);
                }
            """)
        btn.clicked.connect(slot)
        return btn

    def _wire_signals(self) -> None:
        self.manager.hosts_changed.connect(self._on_external_update)
        self.manager.apps_updated.connect(self._on_apps_updated)
        self.manager.stream_started.connect(self._on_stream_changed)
        self.manager.stream_stopped.connect(self._on_external_update)
        self.cmd_manager.command_finished.connect(self._on_apollo_cmd_finished)

    def _unwire_signals(self) -> None:
        for sig, slot in (
            (self.manager.hosts_changed, self._on_external_update),
            (self.manager.apps_updated, self._on_apps_updated),
            (self.manager.stream_started, self._on_stream_changed),
            (self.manager.stream_stopped, self._on_external_update),
            (self.cmd_manager.command_finished, self._on_apollo_cmd_finished),
        ):
            try:
                sig.disconnect(slot)
            except (RuntimeError, TypeError):
                pass

    def done(self, result: int) -> None:
        self._unwire_signals()
        if self._worker is not None:
            try:
                self._worker.action_finished.disconnect(self._on_worker_finished)
            except (RuntimeError, TypeError):
                pass
        super().done(result)

    def _on_stream_changed(self, *_args) -> None:
        self._on_external_update()

    def _on_apps_updated(self, updated_host: RemoteHost) -> None:
        if updated_host and updated_host.uuid == self.host.uuid:
            self.host = updated_host
            self._refresh_state()

    def _on_external_update(self) -> None:
        latest = self.manager.get_host(self.host.uuid)
        if latest is not None:
            self.host = latest
        self._refresh_state()

    def _refresh_state(self) -> None:
        self.title_label.setText(f"Máy chủ: {self.host.hostname}")
        self.sub_label.setText(f"{self.host.ip}:{self.host.port}")

        if self.host.is_apollo:
            self.server_type_badge.setText("APOLLO")
            self.server_type_badge.setStyleSheet(
                "background: rgba(56, 189, 248, 0.15); color: #38bdf8; "
                "border: 1px solid rgba(56, 189, 248, 0.45); border-radius: 6px; "
                "padding: 3px 8px; font-size: 10px; font-weight: 700;"
            )
        else:
            self.server_type_badge.setText("SUNSHINE")
            self.server_type_badge.setStyleSheet(
                "background: rgba(251, 191, 36, 0.14); color: #fbbf24; "
                "border: 1px solid rgba(251, 191, 36, 0.40); border-radius: 6px; "
                "padding: 3px 8px; font-size: 10px; font-weight: 700;"
            )

        if self.host.is_online:
            self.online_badge.setText("SẴN SÀNG")
            self.online_badge.setStyleSheet(
                "background: rgba(16, 185, 129, 0.16); color: #34d399; "
                "border: 1px solid rgba(16, 185, 129, 0.45); border-radius: 6px; "
                "padding: 3px 8px; font-size: 10px; font-weight: 700;"
            )
        else:
            self.online_badge.setText("OFFLINE")
            self.online_badge.setStyleSheet(
                "background: rgba(239, 68, 68, 0.15); color: #f87171; "
                "border: 1px solid rgba(239, 68, 68, 0.40); border-radius: 6px; "
                "padding: 3px 8px; font-size: 10px; font-weight: 700;"
            )

        can_wake = self._has_valid_mac(self.host) and not self._busy
        self.btn_wake.setEnabled(can_wake)
        if not self._has_valid_mac(self.host):
            self.btn_wake.setToolTip("Chưa có địa chỉ MAC của máy chủ (hãy kết nối 1 lần khi máy đang bật)")
        else:
            self.btn_wake.setToolTip(f"Gửi gói tin Wake-on-LAN tới {self.host.mac}")

        self.btn_refresh.setEnabled(not self._busy)
        self.btn_refresh.setToolTip("Kiểm tra kết nối, danh sách game và các lệnh máy chủ mới nhất")

        is_streaming_here = self._is_streaming_this_host()
        has_running_game = bool(
            is_streaming_here
            or (
                self.host.is_online
                and self.host.pair_state == PairState.PAIRED
                and self.host.current_game_id > 0
            )
        )
        self.btn_stop_game.setEnabled(has_running_game and not self._busy)
        if has_running_game:
            self.btn_stop_game.setToolTip("Đóng phiên stream hoặc trò chơi đang chạy trên máy chủ này")
        else:
            self.btn_stop_game.setToolTip("Hiện không có phiên game nào đang chạy trên máy chủ này")

        self._rebuild_apollo_commands(is_streaming_here)

    def _rebuild_apollo_commands(self, is_streaming_here: bool) -> None:
        while self.apollo_grid.count():
            item = self.apollo_grid.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        self._cmd_buttons.clear()

        commands = self.cmd_manager.get_available_commands(self.host)
        if commands:
            self.apollo_grid_host.setVisible(True)
            if is_streaming_here:
                self.apollo_hint_label.setText(
                    "Đang trong phiên stream: bấm vào lệnh bên dưới để gửi trực tiếp tới máy chủ Apollo."
                )
            else:
                self.apollo_hint_label.setText(
                    f"Máy chủ có {len(commands)} lệnh Apollo đã cấu hình. "
                    "Hãy bắt đầu phiên stream tới máy chủ này để kích hoạt các lệnh bên dưới."
                )

            for i, cmd in enumerate(commands[:8]):
                btn = self._make_action_button(
                    cmd.name,
                    "terminal",
                    "#fbbf24",
                    lambda checked=False, cid=cmd.id: self._execute(cid),
                )
                btn.setToolTip(cmd.description)
                btn.setEnabled(is_streaming_here and not self._busy)
                self.apollo_grid.addWidget(btn, i // 2, i % 2)
                self._cmd_buttons.append(btn)
        else:
            self.apollo_grid_host.setVisible(False)
            if self.host.is_apollo:
                self.apollo_hint_label.setText(
                    "Máy chủ Apollo chưa khai báo Server Commands. Bạn có thể thêm lệnh (Sleep, Shutdown, "
                    "Restart...) trong Apollo Web UI -> Configuration / PIN Clients -> Server Commands, "
                    "sau đó bấm 'Làm mới trạng thái'."
                )
            else:
                self.apollo_hint_label.setText(
                    "Máy chủ đang chạy Sunshine tiêu chuẩn. Các thao tác nhanh ở trên luôn dùng được; "
                    "lệnh điều khiển hệ thống từ xa chỉ hỗ trợ trên Apollo Server."
                )

    # ==================== ACTIONS ====================

    def _start_worker(self, action_id: str, status_msg: str, fn: Callable[[], tuple[bool, str]]) -> None:
        if self._busy:
            return
        self._busy = True
        self.status_label.setText(status_msg)
        self.status_label.setStyleSheet("color: #38bdf8; font-size: 11px;")
        self._refresh_state()

        worker = _HostActionWorker(action_id, fn)
        _ACTIVE_WORKERS.add(worker)
        worker.action_finished.connect(self._on_worker_finished)
        worker.finished.connect(lambda w=worker: _ACTIVE_WORKERS.discard(w))
        worker.finished.connect(worker.deleteLater)
        self._worker = worker
        worker.start()

    def _show_result(self, success: bool, msg: str) -> None:
        if success:
            self.status_label.setText(f"Thành công: {msg}")
            self.status_label.setStyleSheet("color: #34d399; font-size: 11px; font-weight: 600;")
        else:
            self.status_label.setText(f"Không thành công: {msg}")
            self.status_label.setStyleSheet("color: #f87171; font-size: 11px; font-weight: 600;")

    def _on_worker_finished(self, action_id: str, success: bool, msg: str) -> None:
        self._busy = False
        self._worker = None
        latest = self.manager.get_host(self.host.uuid)
        if latest is not None:
            self.host = latest
        self._refresh_state()
        self._show_result(success, msg)

    def _on_apollo_cmd_finished(self, cmd_id: str, success: bool, msg: str) -> None:
        self._show_result(success, msg)

    def _on_wake_clicked(self) -> None:
        host = self.host

        def _do_wake() -> tuple[bool, str]:
            ok = self.manager.wake_host(host)
            if ok:
                return True, f"Đã gửi gói tin Wake-on-LAN tới {host.hostname}"
            return False, "Không thể gửi gói tin Wake-on-LAN (kiểm tra địa chỉ MAC)"

        self._start_worker("wake_host", f"Đang gửi tín hiệu Wake-on-LAN tới {host.hostname}...", _do_wake)

    def _on_refresh_clicked(self) -> None:
        host = self.host

        def _do_refresh() -> tuple[bool, str]:
            probed = self.manager.discovery.probe_host(host.ip, port=host.port, timeout=3.0)
            if probed is None:
                self.manager._probe_saved_host(host)
                return False, f"Máy chủ {host.hostname} hiện đang ngoại tuyến"
            if host.pair_state == PairState.PAIRED:
                self.manager._run_refresh_apps(host)
            return True, f"Đã cập nhật trạng thái và danh sách từ {host.hostname}"

        self._start_worker("refresh_host", f"Đang kiểm tra kết nối tới {host.hostname}...", _do_refresh)

    def _on_stop_game_clicked(self) -> None:
        host = self.host
        if self._is_streaming_this_host():
            self.manager.stream_controller.stop()

        def _do_stop() -> tuple[bool, str]:
            if host.pair_state == PairState.PAIRED and host.is_online:
                ok = self.manager.quit_current_app(host)
                if ok:
                    return True, f"Đã dừng phiên game trên {host.hostname}"
                return False, f"Không thể dừng game trên {host.hostname}"
            return True, "Đã gửi yêu cầu đóng phiên stream hiện tại"

        self._start_worker("stop_game", f"Đang dừng phiên game trên {host.hostname}...", _do_stop)

    def _execute(self, command_id: str) -> None:
        if self._busy:
            return
        self.status_label.setText(f"Đang gửi lệnh '{command_id}' tới {self.host.hostname}...")
        self.status_label.setStyleSheet("color: #38bdf8; font-size: 11px;")
        self.cmd_manager.execute_command(self.host, command_id)
