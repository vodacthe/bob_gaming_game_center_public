"""
Stream Settings Modal Dialog for Remote Gaming.
Configures resolution, FPS, bitrate, codec, decoder, display mode, input, and Apollo options.
Ported from Artemis PC (gui/settings/).
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QCursor, QFont
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from app.core.remote.manager import RemoteGamingManager
from app.core.remote.models import StreamSettings, VideoCodec, default_bitrate_kbps
from app.ui.styles import CHECK_ICON_PATH


class StreamSettingsDialog(QDialog):
    """Modal dialog for customizing streaming resolution, bitrate, controls, and system preferences."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.manager = RemoteGamingManager.get()
        self.settings = self.manager.settings

        self.setWindowTitle("Cài Đặt Cấu Hình Remote Gaming")
        self.resize(540, 680)
        self.setMinimumSize(480, 520)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)

        self._setup_ui()
        self._load_current_values()

    def _setup_ui(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #0f0f18;
                color: #ffffff;
            }
            QScrollArea {
                background: transparent;
                border: none;
            }
            QGroupBox {
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 8px;
                margin-top: 14px;
                padding-top: 14px;
                font-weight: bold;
                color: #fbbf24;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 6px;
            }
            QLabel {
                color: #cbd5e1;
                font-size: 12px;
            }
            QComboBox {
                background: #1a1a2e;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 6px;
                color: #ffffff;
                padding: 6px 12px;
                font-size: 12px;
            }
            QComboBox:focus {
                border: 1px solid #fbbf24;
            }
            QComboBox QAbstractItemView {
                background: #1a1a2e;
                color: #ffffff;
                selection-background-color: #d97706;
            }
            QSlider::groove:horizontal {
                height: 6px;
                background: rgba(255, 255, 255, 0.15);
                border-radius: 3px;
            }
            QSlider::sub-page:horizontal {
                background: #d97706;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                background: #fbbf24;
                width: 16px;
                height: 16px;
                margin-top: -5px;
                margin-bottom: -5px;
                border-radius: 8px;
            }
            QCheckBox {
                color: #cbd5e1;
                font-size: 12px;
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
                border-radius: 4px;
                border: 1px solid rgba(255, 255, 255, 0.2);
                background: #1a1a2e;
            }
            QCheckBox::indicator:unchecked {
                image: none;
            }
            QCheckBox::indicator:checked {
                background: #d97706;
                border-color: #fbbf24;
                image: url("__CHECK_ICON_PATH__");
            }
        """.replace("__CHECK_ICON_PATH__", CHECK_ICON_PATH))

        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(18, 16, 18, 16)
        root_layout.setSpacing(12)

        title = QLabel("Cài Đặt Cấu Hình Remote Gaming")
        title.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        title.setStyleSheet("color: #fbbf24; padding-bottom: 4px;")
        root_layout.addWidget(title)

        # Scroll Area for all settings
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(4, 0, 10, 0)
        content_layout.setSpacing(14)

        # ==========================================
        # Group 1: Chất Lượng Hình Ảnh & Khung Hình
        # ==========================================
        group_video = QGroupBox("Chất Lượng Hình Ảnh && Khung Hình")
        gv_layout = QVBoxLayout(group_video)
        gv_layout.setSpacing(10)

        # Resolution
        row_res = QHBoxLayout()
        row_res.addWidget(QLabel("Độ phân giải:"))
        self.combo_res = QComboBox()
        self.combo_res.addItems([
            "1280x720 (720p HD)",
            "1920x1080 (1080p FHD - Chuẩn)",
            "2560x1440 (1440p 2K QHD)",
            "3840x2160 (4K UHD)",
            "2560x1080 (Ultrawide 21:9)",
            "3440x1440 (Ultrawide QHD)",
        ])
        self.combo_res.currentIndexChanged.connect(self._on_res_or_fps_changed)
        row_res.addWidget(self.combo_res, 1)
        gv_layout.addLayout(row_res)

        # FPS
        row_fps = QHBoxLayout()
        row_fps.addWidget(QLabel("Tần số quét (FPS):"))
        self.combo_fps = QComboBox()
        self.combo_fps.addItems([
            "30 FPS",
            "60 FPS (Mượt mà)",
            "90 FPS",
            "120 FPS",
            "144 FPS",
            "240 FPS (Siêu tốc độ - Màn hình 240Hz)",
        ])
        self.combo_fps.currentIndexChanged.connect(self._on_res_or_fps_changed)
        row_fps.addWidget(self.combo_fps, 1)
        gv_layout.addLayout(row_fps)

        # Bitrate
        row_br_label = QHBoxLayout()
        row_br_label.addWidget(QLabel("Băng thông (Bitrate):"))
        self.lbl_bitrate = QLabel("20 Mbps")
        self.lbl_bitrate.setStyleSheet("color: #fbbf24; font-weight: bold;")
        row_br_label.addWidget(self.lbl_bitrate)
        gv_layout.addLayout(row_br_label)

        self.slider_bitrate = QSlider(Qt.Orientation.Horizontal)
        self.slider_bitrate.setRange(1, 150)
        self.slider_bitrate.setValue(20)
        self.slider_bitrate.valueChanged.connect(self._on_slider_bitrate_changed)
        gv_layout.addWidget(self.slider_bitrate)

        # Codec
        row_codec = QHBoxLayout()
        row_codec.addWidget(QLabel("Chuẩn nén video:"))
        self.combo_codec = QComboBox()
        self.combo_codec.addItems([
            "Tự động (Khuyên dùng)",
            "H.264 (Tương thích cao)",
            "HEVC (H.265 - Nén tốt, độ trễ thấp)",
            "AV1 (Độ nén tối đa)",
        ])
        row_codec.addWidget(self.combo_codec, 1)
        gv_layout.addLayout(row_codec)

        # Video Decoder
        row_dec = QHBoxLayout()
        row_dec.addWidget(QLabel("Bộ giải mã video:"))
        self.combo_decoder = QComboBox()
        self.combo_decoder.addItems([
            "Tự động (AUTO - Phần cứng ưu tiên)",
            "Bắt buộc phần cứng (FORCE_HARDWARE)",
            "Bắt buộc phần mềm (FORCE_SOFTWARE)",
        ])
        row_dec.addWidget(self.combo_decoder, 1)
        gv_layout.addLayout(row_dec)

        # Window Mode
        row_wm = QHBoxLayout()
        row_wm.addWidget(QLabel("Chế độ hiển thị:"))
        self.combo_window_mode = QComboBox()
        self.combo_window_mode.addItems([
            "Không viền (Borderless - Khuyên dùng)",
            "Toàn màn hình (Fullscreen)",
            "Cửa sổ (Windowed)",
        ])
        row_wm.addWidget(self.combo_window_mode, 1)
        gv_layout.addLayout(row_wm)

        # V-Sync & Overlay
        self.chk_vsync = QCheckBox("Đồng bộ khung hình (V-Sync)")
        gv_layout.addWidget(self.chk_vsync)

        self.chk_overlay = QCheckBox("Hiện bảng thống kê stream (Ctrl+Alt+Shift+S)")
        gv_layout.addWidget(self.chk_overlay)

        content_layout.addWidget(group_video)

        # ==========================================
        # Group 2: Chuột & Bàn Phím
        # ==========================================
        group_input = QGroupBox("Chuột && Bàn Phím")
        gi_layout = QVBoxLayout(group_input)
        gi_layout.setSpacing(10)

        # Mouse mode
        row_mm = QHBoxLayout()
        row_mm.addWidget(QLabel("Chế độ chuột:"))
        self.combo_mouse_mode = QComboBox()
        self.combo_mouse_mode.addItems([
            "Chuột tương đối (Khóa chuột trong game 3D / FPS)",
            "Chuột tuyệt đối (Desktop / RPG / Game chiến thuật)",
        ])
        row_mm.addWidget(self.combo_mouse_mode, 1)
        gi_layout.addLayout(row_mm)

        # Capture sys keys (tri-state: Tắt / Khi toàn màn hình / Luôn luôn)
        row_csk = QHBoxLayout()
        lbl_csk = QLabel("Bắt phím hệ thống:")
        lbl_csk.setToolTip(
            "Khuyến nghị tắt gõ tiếng Việt Unikey/EVKey khi đang stream để tránh xung đột phím."
        )
        row_csk.addWidget(lbl_csk)
        self.combo_capture_sys_keys = QComboBox()
        self.combo_capture_sys_keys.addItem("Tắt", "off")
        self.combo_capture_sys_keys.addItem("Khi toàn màn hình", "fullscreen")
        self.combo_capture_sys_keys.addItem("Luôn luôn", "always")
        self.combo_capture_sys_keys.setToolTip(
            "Khuyến nghị tắt gõ tiếng Việt Unikey/EVKey khi đang stream để tránh xung đột phím."
        )
        row_csk.addWidget(self.combo_capture_sys_keys, 1)
        gi_layout.addLayout(row_csk)

        self.chk_swap_mouse = QCheckBox("Đảo phím chuột trái / phải")
        gi_layout.addWidget(self.chk_swap_mouse)

        self.chk_reverse_scroll = QCheckBox("Đảo chiều cuộn chuột")
        gi_layout.addWidget(self.chk_reverse_scroll)

        content_layout.addWidget(group_input)

        # ==========================================
        # Group 3: Tay Cầm (Gamepad)
        # ==========================================
        group_gamepad = QGroupBox("Tay Cầm (Gamepad)")
        gg_layout = QVBoxLayout(group_gamepad)
        gg_layout.setSpacing(10)

        self.chk_multi_controller = QCheckBox("Hỗ trợ nhiều tay cầm đồng thời")
        gg_layout.addWidget(self.chk_multi_controller)

        self.chk_swap_face_buttons = QCheckBox("Đảo phím A/B, X/Y (kiểu Nintendo)")
        gg_layout.addWidget(self.chk_swap_face_buttons)

        self.chk_gamepad_mouse = QCheckBox("Dùng tay cầm điều khiển chuột (giữ nút Start 1.5 giây)")
        gg_layout.addWidget(self.chk_gamepad_mouse)

        self.chk_background_gamepad = QCheckBox("Nhận tín hiệu tay cầm khi cửa sổ stream mất tiêu điểm")
        gg_layout.addWidget(self.chk_background_gamepad)

        content_layout.addWidget(group_gamepad)

        # ==========================================
        # Group 4: Hệ Thống & Tính Năng Apollo
        # ==========================================
        group_sys = QGroupBox("Hệ Thống && Nâng Cao")
        gs_layout = QVBoxLayout(group_sys)
        gs_layout.setSpacing(10)

        row_audio = QHBoxLayout()
        row_audio.addWidget(QLabel("Cấu hình âm thanh:"))
        self.combo_audio_channels = QComboBox()
        self.combo_audio_channels.addItems([
            "Stereo (2 kênh - mặc định)",
            "Âm thanh vòm 5.1 (6 kênh)",
            "Âm thanh vòm 7.1 (8 kênh)",
        ])
        row_audio.addWidget(self.combo_audio_channels, 1)
        gs_layout.addLayout(row_audio)

        self.chk_mute_on_focus_loss = QCheckBox("Tắt tiếng khi cửa sổ mất tiêu điểm")
        gs_layout.addWidget(self.chk_mute_on_focus_loss)

        self.chk_keep_awake = QCheckBox("Giữ máy không ngủ khi đang stream (Keep Awake)")
        gs_layout.addWidget(self.chk_keep_awake)

        self.chk_virtual_display = QCheckBox("Bật màn hình ảo trên máy chủ (Virtual Display)")
        gs_layout.addWidget(self.chk_virtual_display)

        self.chk_clipboard = QCheckBox("Tự động đồng bộ Clipboard hai chiều (Apollo)")
        gs_layout.addWidget(self.chk_clipboard)

        self.chk_quit_after = QCheckBox("Tắt game trên máy chủ khi ngắt phiên stream")
        gs_layout.addWidget(self.chk_quit_after)

        content_layout.addWidget(group_sys)

        scroll.setWidget(content_widget)
        root_layout.addWidget(scroll, 1)

        # Action Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        btn_cancel = QPushButton("Hủy")
        btn_cancel.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_cancel.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #ffffff;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 6px;
                padding: 7px 18px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.15);
            }
        """)
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_cancel)

        btn_save = QPushButton("Lưu Cài Đặt")
        btn_save.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_save.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #d97706, stop:1 #b45309);
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 7px 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
            }
        """)
        btn_save.clicked.connect(self._save_and_close)
        btn_row.addWidget(btn_save)

        root_layout.addLayout(btn_row)

    def _get_current_res_and_fps(self) -> tuple[int, int, int]:
        try:
            res_text = self.combo_res.currentText().split(" ")[0]
            w_str, h_str = res_text.split("x")
            w, h = int(w_str), int(h_str)
        except Exception:
            w, h = 1920, 1080
        try:
            fps_text = self.combo_fps.currentText().split(" ")[0]
            fps = int(fps_text)
        except Exception:
            fps = 60
        return w, h, fps

    def _update_bitrate_label(self, mbps: int):
        w, h, fps = self._get_current_res_and_fps()
        def_mbps = default_bitrate_kbps(w, h, fps) // 1000
        if mbps == def_mbps:
            self.lbl_bitrate.setText(f"{mbps} Mbps (mặc định)")
        else:
            self.lbl_bitrate.setText(f"{mbps} Mbps")

    def _on_slider_bitrate_changed(self, val: int):
        self._update_bitrate_label(val)

    def _on_res_or_fps_changed(self):
        w, h, fps = self._get_current_res_and_fps()
        def_mbps = default_bitrate_kbps(w, h, fps) // 1000
        def_mbps = max(1, min(150, def_mbps))
        self.slider_bitrate.setValue(def_mbps)
        self._update_bitrate_label(def_mbps)

    def _load_current_values(self):
        s = self.settings

        self.combo_res.blockSignals(True)
        self.combo_fps.blockSignals(True)
        self.slider_bitrate.blockSignals(True)

        # Resolution
        res_str = f"{s.width}x{s.height}"
        for i in range(self.combo_res.count()):
            if res_str in self.combo_res.itemText(i):
                self.combo_res.setCurrentIndex(i)
                break

        # FPS
        for i in range(self.combo_fps.count()):
            if str(s.fps) in self.combo_fps.itemText(i):
                self.combo_fps.setCurrentIndex(i)
                break

        self.combo_res.blockSignals(False)
        self.combo_fps.blockSignals(False)
        self.slider_bitrate.blockSignals(False)

        # Bitrate
        mbps = max(1, min(150, s.bitrate_kbps // 1000))
        self.slider_bitrate.setValue(mbps)
        self._update_bitrate_label(mbps)

        # Codec
        if s.codec == VideoCodec.AUTO:
            self.combo_codec.setCurrentIndex(0)
        elif s.codec == VideoCodec.H264:
            self.combo_codec.setCurrentIndex(1)
        elif s.codec == VideoCodec.HEVC:
            self.combo_codec.setCurrentIndex(2)
        elif s.codec == VideoCodec.AV1:
            self.combo_codec.setCurrentIndex(3)

        # Video Decoder
        dec = str(s.video_decoder).upper()
        if dec == "FORCE_HARDWARE":
            self.combo_decoder.setCurrentIndex(1)
        elif dec == "FORCE_SOFTWARE":
            self.combo_decoder.setCurrentIndex(2)
        else:
            self.combo_decoder.setCurrentIndex(0)

        # Window Mode
        wm = str(s.window_mode).lower()
        if wm == "fullscreen":
            self.combo_window_mode.setCurrentIndex(1)
        elif wm == "windowed":
            self.combo_window_mode.setCurrentIndex(2)
        else:
            self.combo_window_mode.setCurrentIndex(0)

        self.chk_vsync.setChecked(s.vsync)
        self.chk_overlay.setChecked(s.show_performance_overlay)

        # Mouse mode
        self.combo_mouse_mode.setCurrentIndex(1 if s.absolute_mouse else 0)

        # Capture sys keys
        idx_csk = self.combo_capture_sys_keys.findData(s.capture_sys_keys)
        if idx_csk >= 0:
            self.combo_capture_sys_keys.setCurrentIndex(idx_csk)
        else:
            self.combo_capture_sys_keys.setCurrentIndex(0)
        self.chk_swap_mouse.setChecked(s.swap_mouse_buttons)
        self.chk_reverse_scroll.setChecked(s.reverse_scroll)

        self.chk_multi_controller.setChecked(s.multi_controller)
        self.chk_swap_face_buttons.setChecked(s.swap_face_buttons)
        self.chk_gamepad_mouse.setChecked(s.gamepad_mouse)
        self.chk_background_gamepad.setChecked(s.background_gamepad)

        if s.audio_channels == 6:
            self.combo_audio_channels.setCurrentIndex(1)
        elif s.audio_channels == 8:
            self.combo_audio_channels.setCurrentIndex(2)
        else:
            self.combo_audio_channels.setCurrentIndex(0)

        self.chk_mute_on_focus_loss.setChecked(s.mute_on_focus_loss)
        self.chk_keep_awake.setChecked(s.keep_awake)
        self.chk_virtual_display.setChecked(s.enable_virtual_display)
        self.chk_clipboard.setChecked(s.clipboard_sync)
        self.chk_quit_after.setChecked(s.quit_app_after)

    def _save_and_close(self):
        s = self.settings

        # Resolution
        res_text = self.combo_res.currentText().split(" ")[0]
        w_str, h_str = res_text.split("x")
        s.width = int(w_str)
        s.height = int(h_str)

        # FPS
        fps_text = self.combo_fps.currentText().split(" ")[0]
        s.fps = int(fps_text)

        # Bitrate
        s.bitrate_kbps = self.slider_bitrate.value() * 1000

        # Codec
        c_idx = self.combo_codec.currentIndex()
        if c_idx == 0:
            s.codec = VideoCodec.AUTO
        elif c_idx == 1:
            s.codec = VideoCodec.H264
        elif c_idx == 2:
            s.codec = VideoCodec.HEVC
        elif c_idx == 3:
            s.codec = VideoCodec.AV1

        # Decoder
        d_idx = self.combo_decoder.currentIndex()
        if d_idx == 1:
            s.video_decoder = "FORCE_HARDWARE"
        elif d_idx == 2:
            s.video_decoder = "FORCE_SOFTWARE"
        else:
            s.video_decoder = "AUTO"

        # Window Mode
        wm_idx = self.combo_window_mode.currentIndex()
        if wm_idx == 1:
            s.window_mode = "fullscreen"
        elif wm_idx == 2:
            s.window_mode = "windowed"
        else:
            s.window_mode = "borderless"

        s.vsync = self.chk_vsync.isChecked()
        s.show_performance_overlay = self.chk_overlay.isChecked()

        # Mouse mode
        s.absolute_mouse = (self.combo_mouse_mode.currentIndex() == 1)

        # Capture sys keys
        s.capture_sys_keys = str(self.combo_capture_sys_keys.currentData() or "off")
        s.swap_mouse_buttons = self.chk_swap_mouse.isChecked()
        s.reverse_scroll = self.chk_reverse_scroll.isChecked()

        s.multi_controller = self.chk_multi_controller.isChecked()
        s.swap_face_buttons = self.chk_swap_face_buttons.isChecked()
        s.gamepad_mouse = self.chk_gamepad_mouse.isChecked()
        s.background_gamepad = self.chk_background_gamepad.isChecked()

        audio_idx = self.combo_audio_channels.currentIndex()
        s.audio_channels = 6 if audio_idx == 1 else (8 if audio_idx == 2 else 2)

        s.mute_on_focus_loss = self.chk_mute_on_focus_loss.isChecked()
        s.keep_awake = self.chk_keep_awake.isChecked()
        s.enable_virtual_display = self.chk_virtual_display.isChecked()
        s.clipboard_sync = self.chk_clipboard.isChecked()
        s.quit_app_after = self.chk_quit_after.isChecked()

        self.manager.save_settings(s)
        self.accept()
