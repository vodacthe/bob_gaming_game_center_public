"""
Host Card Widget for displaying Sunshine / Apollo / GameStream PC hosts.
Follows Bob Gaming Titanium Violet & Champagne Gold luxury design.
"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QGraphicsDropShadowEffect
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont, QCursor

from app.core.remote.models import RemoteHost, PairState
from app.ui.icons import make_svg_pixmap


class HostCard(QFrame):
    """Card representing a remote gaming host computer."""

    clicked = Signal(str)  # host_uuid
    pair_requested = Signal(str)  # host_uuid
    remove_requested = Signal(str)  # host_uuid

    def __init__(self, host: RemoteHost, is_selected: bool = False, parent=None):
        super().__init__(parent)
        self.host = host
        self._is_selected = is_selected
        self._hovered = False

        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        self.setMinimumWidth(260)
        self.setFixedHeight(115)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)  # controller navigation (gamepad_nav)

        self._setup_ui()
        self._update_style()

    def set_selected(self, selected: bool):
        self._is_selected = selected
        self._update_style()

    def update_host(self, host: RemoteHost):
        self.host = host
        self.name_label.setText(host.hostname)
        self.ip_label.setText(f"{host.ip}:{host.port}")
        self.apollo_badge.setVisible(bool(host.is_apollo))

        # Update status pill
        if not host.is_online:
            self.status_pill.setText("OFFLINE")
            self.status_pill.setStyleSheet("background-color: rgba(239, 68, 68, 0.2); color: #f87171; border: none; border-radius: 4px; padding: 2px 6px; font-weight: bold; font-size: 10px;")
        elif host.current_game_id > 0:
            self.status_pill.setText("STREAMING")
            self.status_pill.setStyleSheet("background-color: rgba(59, 130, 246, 0.2); color: #60a5fa; border: none; border-radius: 4px; padding: 2px 6px; font-weight: bold; font-size: 10px;")
        elif host.pair_state == PairState.PAIRED:
            self.status_pill.setText("SẴN SÀNG")
            self.status_pill.setStyleSheet("background-color: rgba(16, 185, 129, 0.2); color: #34d399; border: none; border-radius: 4px; padding: 2px 6px; font-weight: bold; font-size: 10px;")
        else:
            self.status_pill.setText("CHƯA GHÉP ĐÔI")
            self.status_pill.setStyleSheet("background-color: rgba(245, 158, 11, 0.2); color: #fbbf24; border: none; border-radius: 4px; padding: 2px 6px; font-weight: bold; font-size: 10px;")

        # Update button
        if host.pair_state == PairState.PAIRED:
            self.action_btn.setText("Đã ghép")
            self.action_btn.setEnabled(False)
            self.action_btn.setStyleSheet("background: transparent; color: #10b981; border: 1px solid rgba(16, 185, 129, 0.4); border-radius: 6px; padding: 3px 8px; font-size: 11px;")
        else:
            self.action_btn.setText("Ghép đôi")
            self.action_btn.setEnabled(True)
            self.action_btn.setStyleSheet("background: #d97706; color: #ffffff; border: none; border-radius: 6px; padding: 4px 10px; font-size: 11px; font-weight: bold;")

    def _setup_ui(self):
        self.setObjectName("hostCard")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(6)

        # Top row: Hostname & Apollo Badge
        top_row = QHBoxLayout()
        top_row.setSpacing(8)

        self.icon_label = QLabel()
        self.icon_label.setPixmap(make_svg_pixmap("remote", color="#fbbf24", size=18))
        self.icon_label.setStyleSheet("background: transparent; border: none;")
        top_row.addWidget(self.icon_label)

        self.name_label = QLabel(self.host.hostname)
        self.name_label.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        self.name_label.setStyleSheet("color: #ffffff; background: transparent; border: none;")
        top_row.addWidget(self.name_label, 1)

        self.apollo_badge = QLabel("APOLLO", self)    # parented: shown while parentless it would flash as a window
        self.apollo_badge.setStyleSheet("""
            background-color: rgba(168, 85, 247, 0.25);
            color: #c084fc;
            border: none;
            border-radius: 4px;
            padding: 1px 5px;
            font-size: 9px;
            font-weight: 700;
        """)
        self.apollo_badge.setVisible(bool(self.host.is_apollo))
        top_row.addWidget(self.apollo_badge)

        self.status_pill = QLabel()
        self.status_pill.setStyleSheet("border: none;")
        top_row.addWidget(self.status_pill)
        layout.addLayout(top_row)

        # Middle row: IP address and version
        self.ip_label = QLabel(f"{self.host.ip}:{self.host.port}")
        self.ip_label.setStyleSheet("color: #94a3b8; font-size: 11px; font-family: monospace; background: transparent; border: none;")
        layout.addWidget(self.ip_label)

        # Bottom row: Action Button and Delete
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(8)

        self.action_btn = QPushButton("Ghép đôi")
        self.action_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.action_btn.clicked.connect(lambda: self.pair_requested.emit(self.host.uuid))
        bottom_row.addWidget(self.action_btn)

        bottom_row.addStretch()

        self.del_btn = QPushButton("✕")
        self.del_btn.setToolTip("Xóa host này")
        self.del_btn.setFixedSize(22, 22)
        self.del_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.del_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #64748b;
                border: none;
                border-radius: 4px;
                font-size: 12px;
            }
            QPushButton:hover {
                background: rgba(239, 68, 68, 0.2);
                color: #ef4444;
            }
        """)
        self.del_btn.clicked.connect(lambda: self.remove_requested.emit(self.host.uuid))
        bottom_row.addWidget(self.del_btn)

        layout.addLayout(bottom_row)

        self.update_host(self.host)

    def _update_style(self):
        if self._is_selected:
            self.setStyleSheet("""
                #hostCard {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1e1b4b, stop:1 #171727);
                    border: 1.5px solid #fbbf24;
                    border-radius: 10px;
                }
                #hostCard QLabel {
                    border: none;
                    background: transparent;
                }
            """)
        elif self._hovered:
            self.setStyleSheet("""
                #hostCard {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1b1a2e, stop:1 #131221);
                    border: 1px solid rgba(251, 191, 36, 0.5);
                    border-radius: 10px;
                }
                #hostCard QLabel {
                    border: none;
                    background: transparent;
                }
            """)
        else:
            self.setStyleSheet("""
                #hostCard {
                    background: rgba(22, 22, 34, 0.7);
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 10px;
                }
                #hostCard QLabel {
                    border: none;
                    background: transparent;
                }
            """)

    def enterEvent(self, event):
        self._hovered = True
        self._update_style()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hovered = False
        self._update_style()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.host.uuid)
        super().mousePressEvent(event)

    # ── Controller navigation (app/ui/gamepad_nav.py) ──

    def gamepad_activate(self):
        self.clicked.emit(self.host.uuid)

    def gamepad_secondary(self):
        if self.action_btn.isVisible() and self.action_btn.isEnabled():
            self.action_btn.click()

    def gamepad_tertiary(self):
        self.del_btn.click()

    def gamepad_hints(self) -> list[tuple[str, str]]:
        hints = [("A", "Chọn máy")]
        if self.action_btn.isVisible() and self.action_btn.isEnabled():
            hints.append(("X", self.action_btn.text()))
        hints.append(("Y", "Xoá host"))
        return hints
