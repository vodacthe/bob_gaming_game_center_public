"""
Main Remote Gaming Screen for Bob Gaming Game Center.
Features luxury Hero banner, horizontal Host PC selector, Box Art Game Grid,
and seamless integration with Python & Native streaming engines.
"""

from __future__ import annotations

import logging
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
    QScrollArea, QFrame, QSizePolicy, QMessageBox, QProgressDialog
)
from PySide6.QtCore import Qt, QTimer, Signal, QObject
from PySide6.QtGui import QFont, QCursor

from app.core.remote.manager import RemoteGamingManager
from app.core.remote.models import PairState, RemoteApp, RemoteHost
from app.ui.flow_layout import FlowLayout
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.remote.host_card import HostCard
from app.ui.remote.host_dialog import AddHostDialog
from app.ui.remote.pairing_dialog import PairingDialog
from app.ui.remote.remote_game_card import RemoteGameCard
from app.ui.remote.server_cmd_dialog import ServerCommandDialog
from app.ui.remote.settings_dialog import StreamSettingsDialog
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader

logger = logging.getLogger(__name__)


class RemoteScreen(QWidget):
    """Central Remote Gaming Screen."""

    back_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.manager = RemoteGamingManager.get()
        self._host_cards: dict[str, HostCard] = {}
        self._selected_host: Optional[RemoteHost] = None

        self._setup_ui()
        self._wire_signals()

        # Initial discovery & host population
        self._refresh_hosts()
        self.manager.discovery.start_discovery()

    def _setup_ui(self):
        self.setStyleSheet("""
            QWidget {
                background-color: transparent;
                color: #ffffff;
            }
            QLineEdit {
                background: rgba(26, 26, 46, 0.8);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 8px;
                color: #ffffff;
                padding: 7px 14px;
                font-size: 12px;
            }
            QLineEdit:focus {
                border: 1.5px solid #fbbf24;
            }
        """)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # 1. HEADER (shared component)
        header = ScreenHeader(
            "Remote Gaming", "cast",
            subtitle="Sunshine & Apollo · chơi game từ PC máy chủ với độ trễ cực thấp, hỗ trợ giải mã phần cứng và đồng bộ tay cầm.")
        header.back_requested.connect(self.back_requested.emit)
        self.btn_rescan = header.add_button("Quét mạng", "secondary", icon="sync")
        self.btn_rescan.clicked.connect(self._on_rescan_clicked)
        self.btn_add_host = header.add_button("Thêm host", "secondary", icon="globe")
        self.btn_add_host.clicked.connect(self._on_add_host_clicked)
        self.btn_server_cmd = header.add_button("Lệnh máy chủ", "secondary", icon="terminal")
        self.btn_server_cmd.clicked.connect(self._on_server_cmd_clicked)
        self.btn_server_cmd.setEnabled(False)
        self.btn_server_cmd.setToolTip("Chọn một máy chủ để mở bảng lệnh")
        self.btn_settings = header.add_button("Cài đặt", "secondary", icon="settings")
        self.btn_settings.clicked.connect(self._on_settings_clicked)
        outer.addWidget(header)

        body = QWidget()
        main_layout = QVBoxLayout(body)
        main_layout.setContentsMargins(*CONTENT_MARGINS)
        main_layout.setSpacing(18)
        outer.addWidget(body, 1)


        # 2. HOST SELECTOR BAR (Horizontal Scroll)
        host_section_title = QLabel("MÁY CHỦ TRONG MẠNG LAN")
        host_section_title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        host_section_title.setStyleSheet("color: #cbd5e1; letter-spacing: 0.5px;")
        main_layout.addWidget(host_section_title)

        host_scroll = QScrollArea()
        host_scroll.setFixedHeight(135)
        host_scroll.setWidgetResizable(True)
        host_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        host_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        host_scroll.setStyleSheet("background: transparent; border: none;")

        self.host_container = QWidget()
        self.host_container_layout = QHBoxLayout(self.host_container)
        self.host_container_layout.setContentsMargins(0, 0, 0, 0)
        self.host_container_layout.setSpacing(12)
        self.host_container_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        host_scroll.setWidget(self.host_container)
        main_layout.addWidget(host_scroll)

        # 3. GAMES GRID AREA
        games_header = QHBoxLayout()
        self.games_section_title = QLabel("DANH SÁCH TRÒ CHƠI")
        self.games_section_title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        self.games_section_title.setStyleSheet("color: #cbd5e1; letter-spacing: 0.5px;")
        games_header.addWidget(self.games_section_title)

        games_header.addStretch()

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Tìm kiếm trò chơi trên máy chủ...")
        self.search_input.setFixedWidth(260)
        self.search_input.textChanged.connect(self._filter_games)
        games_header.addWidget(self.search_input)

        self.btn_refresh_games = QPushButton("Làm Mới")
        self.btn_refresh_games.setIcon(make_svg_icon("sync", color="#ffffff", size=13))
        self.btn_refresh_games.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_refresh_games.setToolTip("Tải lại danh sách game từ máy chủ")
        self.btn_refresh_games.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #ffffff;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 8px;
                padding: 6px 14px;
                font-weight: 600;
                font-size: 11px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.18);
                border-color: #fbbf24;
            }
        """)
        self.btn_refresh_games.clicked.connect(self._on_refresh_games_clicked)
        games_header.addWidget(self.btn_refresh_games)

        self.btn_stop_game = QPushButton("Dừng Game Đang Chạy")
        self.btn_stop_game.setIcon(make_svg_icon("close", color="#f87171", size=13))
        self.btn_stop_game.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_stop_game.setToolTip("Dừng phiên stream hoặc game đang chạy trên máy chủ này")
        self.btn_stop_game.setStyleSheet("""
            QPushButton {
                background: rgba(239, 68, 68, 0.15);
                color: #fca5a5;
                border: 1px solid rgba(239, 68, 68, 0.35);
                border-radius: 8px;
                padding: 6px 14px;
                font-weight: 600;
                font-size: 11px;
            }
            QPushButton:hover {
                background: rgba(239, 68, 68, 0.28);
                border-color: #ef4444;
                color: #ffffff;
            }
        """)
        self.btn_stop_game.clicked.connect(self._on_stop_running_game_clicked)
        self.btn_stop_game.setVisible(False)
        games_header.addWidget(self.btn_stop_game)

        main_layout.addLayout(games_header)

        # Scrollable Games Content
        games_scroll = QScrollArea()
        games_scroll.setWidgetResizable(True)
        games_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        games_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        games_scroll.setStyleSheet("background: transparent; border: none;")

        self.games_content = QWidget()
        self.games_flow_layout = FlowLayout(self.games_content, margin=0, spacing=14)
        games_scroll.setWidget(self.games_content)

        main_layout.addWidget(games_scroll, 1)

    def _wire_signals(self):
        self.manager.hosts_changed.connect(self._refresh_hosts)
        self.manager.host_selected.connect(self._on_host_selected)
        self.manager.apps_updated.connect(self._on_apps_updated)
        self.manager.stream_started.connect(self._on_stream_started)
        self.manager.stream_stopped.connect(self._on_stream_stopped)
        self.manager.stream_error.connect(self._on_stream_error)

    def _update_server_cmd_button_state(self):
        """Enable host management and server command dialog whenever a host is selected."""
        has_host = self._selected_host is not None
        self.btn_server_cmd.setEnabled(has_host)
        if has_host:
            self.btn_server_cmd.setToolTip(
                f"Quản lý nhanh và gửi lệnh điều khiển tới {self._selected_host.hostname}"
            )
        else:
            self.btn_server_cmd.setToolTip("Chọn một máy chủ để mở bảng lệnh")

    # ==================== HOST SELECTION & REFRESH ====================

    def _refresh_hosts(self):
        hosts = self.manager.get_hosts()

        # Clear existing host cards
        while self.host_container_layout.count():
            item = self.host_container_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self._host_cards.clear()

        if not hosts:
            empty_lbl = QLabel("Chưa tìm thấy máy chủ Sunshine/Apollo nào. Bấm 'Quét Mạng' hoặc 'Thêm Host'.")
            empty_lbl.setStyleSheet("color: #64748b; font-size: 12px; font-style: italic; padding: 20px;")
            self.host_container_layout.addWidget(empty_lbl)
            self._render_empty_games_view("Không có máy chủ nào được chọn")
            self._update_server_cmd_button_state()
            return

        for host in hosts:
            card = HostCard(host, is_selected=(self._selected_host and self._selected_host.uuid == host.uuid))
            card.clicked.connect(self._on_host_card_clicked)
            card.pair_requested.connect(self._on_pair_requested)
            card.remove_requested.connect(self._on_remove_host_requested)
            self.host_container_layout.addWidget(card)
            self._host_cards[host.uuid] = card

        # Select first host if none selected, or sync selected host's online/running UI state
        if not self._selected_host and hosts:
            self._on_host_card_clicked(hosts[0].uuid)
        elif self._selected_host:
            latest = self.manager.get_host(self._selected_host.uuid)
            if latest is not None:
                self._selected_host = latest
                self._update_server_cmd_button_state()
                self.btn_stop_game.setVisible(self._is_host_game_running(latest))
                if latest.pair_state == PairState.PAIRED and latest.apps:
                    self._render_games(latest.apps)
            elif hosts:
                self._on_host_card_clicked(hosts[0].uuid)

    @staticmethod
    def _is_host_game_running(host: Optional[RemoteHost]) -> bool:
        return bool(host and host.is_online and host.current_game_id > 0)

    def _on_host_card_clicked(self, host_uuid: str):
        for uid, card in self._host_cards.items():
            card.set_selected(uid == host_uuid)

        self.manager.select_host(host_uuid)

    def _on_host_selected(self, host: RemoteHost):
        self._selected_host = host
        self._update_server_cmd_button_state()
        self.btn_stop_game.setVisible(self._is_host_game_running(host))

        if host.pair_state != PairState.PAIRED:
            self._render_unpaired_view(host)
        elif not host.apps:
            self._render_empty_games_view(
                f"Đang tải danh sách game từ {host.hostname}...",
                show_refresh=True,
            )
        else:
            self._render_games(host.apps)

    def _on_apps_updated(self, host: RemoteHost):
        if self._selected_host and self._selected_host.uuid == host.uuid:
            self._selected_host = host
            self._update_server_cmd_button_state()
            self.btn_stop_game.setVisible(self._is_host_game_running(host))
            if not host.apps:
                self._render_empty_games_view(
                    f"Không tìm thấy game nào trên {host.hostname} hoặc chưa kết nối được tới dịch vụ AppList.",
                    show_refresh=True,
                )
            else:
                self._render_games(host.apps)

    def _on_refresh_games_clicked(self):
        if self._selected_host and self._selected_host.pair_state == PairState.PAIRED:
            self._render_empty_games_view(
                f"Đang tải lại danh sách game từ {self._selected_host.hostname}...",
                show_refresh=False,
            )
            self.manager.refresh_host_apps(self._selected_host)

    def _on_stop_running_game_clicked(self):
        if not self._selected_host:
            return
        reply = QMessageBox.question(
            self,
            "Dừng Game Đang Chạy",
            f"Bạn có chắc muốn dừng phiên game / stream đang chạy trên {self._selected_host.hostname} không?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            success = self.manager.quit_current_app(self._selected_host)
            if success:
                self.btn_stop_game.setVisible(False)
                self.manager.refresh_host_apps(self._selected_host)

    # ==================== GAMES RENDERING ====================

    def _clear_games_layout(self):
        while self.games_flow_layout.count():
            item = self.games_flow_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

    def _render_games(self, apps: list[RemoteApp]):
        self._clear_games_layout()
        query = self.search_input.text().strip().lower()

        filtered = [a for a in apps if not query or query in a.title.lower()]

        if not filtered:
            lbl = QLabel("Không tìm thấy trò chơi nào phù hợp với từ khóa.")
            lbl.setStyleSheet("color: #64748b; font-size: 13px; padding: 20px;")
            self.games_flow_layout.addWidget(lbl)
            return

        host_online = bool(self._selected_host and self._selected_host.is_online)
        for app in filtered:
            card = RemoteGameCard(app, host_online=host_online)
            card.play_requested.connect(self._on_game_play_requested)
            self.games_flow_layout.addWidget(card)

    def _filter_games(self, text: str):
        if self._selected_host and self._selected_host.pair_state == PairState.PAIRED:
            self._render_games(self._selected_host.apps)

    def _render_unpaired_view(self, host: RemoteHost):
        self._clear_games_layout()
        banner = QFrame()
        banner.setObjectName("unpairedBanner")
        banner.setStyleSheet("""
            #unpairedBanner {
                background: rgba(30, 27, 75, 0.7);
                border: 1.5px dashed rgba(251, 191, 36, 0.4);
                border-radius: 12px;
                padding: 24px;
            }
            #unpairedBanner QLabel {
                border: none;
                background: transparent;
            }
        """)
        bl = QVBoxLayout(banner)
        bl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        bl.setSpacing(12)

        lbl = QLabel(f"Máy chủ {host.hostname} chưa được ghép đôi.")
        lbl.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        lbl.setStyleSheet("color: #fbbf24;")
        bl.addWidget(lbl, 0, Qt.AlignmentFlag.AlignCenter)

        desc = QLabel("Hãy ghép đôi thiết bị để xem danh sách trò chơi và bắt đầu stream.")
        desc.setStyleSheet("color: #cbd5e1; font-size: 12px;")
        bl.addWidget(desc, 0, Qt.AlignmentFlag.AlignCenter)

        pair_btn = QPushButton("Ghép Đôi Thiết Bị Ngay")
        pair_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        pair_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #d97706, stop:1 #b45309);
                color: #ffffff;
                border: none;
                border-radius: 8px;
                padding: 10px 24px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
            }
        """)
        pair_btn.clicked.connect(lambda: self._on_pair_requested(host.uuid))
        bl.addWidget(pair_btn, 0, Qt.AlignmentFlag.AlignCenter)

        self.games_flow_layout.addWidget(banner)

    def _render_empty_games_view(self, message: str, show_refresh: bool = False):
        self._clear_games_layout()
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(14)
        layout.setContentsMargins(20, 40, 20, 40)

        lbl = QLabel(message)
        lbl.setStyleSheet("color: #94a3b8; font-size: 13px; font-weight: 500;")
        layout.addWidget(lbl, 0, Qt.AlignmentFlag.AlignCenter)

        if show_refresh and self._selected_host and self._selected_host.pair_state == PairState.PAIRED:
            retry_btn = QPushButton("Tải Lại Danh Sách Game")
            retry_btn.setIcon(make_svg_icon("sync", color="#fbbf24", size=14))
            retry_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            retry_btn.setStyleSheet("""
                QPushButton {
                    background: rgba(251, 191, 36, 0.12);
                    color: #fbbf24;
                    border: 1px solid rgba(251, 191, 36, 0.35);
                    border-radius: 8px;
                    padding: 8px 20px;
                    font-weight: 600;
                    font-size: 12px;
                }
                QPushButton:hover {
                    background: rgba(251, 191, 36, 0.22);
                    border-color: #fbbf24;
                }
            """)
            retry_btn.clicked.connect(self._on_refresh_games_clicked)
            layout.addWidget(retry_btn, 0, Qt.AlignmentFlag.AlignCenter)

        self.games_flow_layout.addWidget(container)

    # ==================== STREAM LAUNCH & PLAYER ====================

    def _on_game_play_requested(self, app: RemoteApp):
        if not self._selected_host:
            return

        controller = self.manager.stream_controller
        if controller.is_active:
            QMessageBox.information(
                self,
                "Remote Gaming",
                "Một phiên truyền phát đang hoạt động. Vui lòng đóng phiên hiện tại trước khi bắt đầu phiên mới.",
            )
            return

        host = self._selected_host
        if not host.is_online:
            mac_clean = (host.mac or "").replace(":", "").replace("-", "").strip()
            if len(mac_clean) == 12 and mac_clean != "0" * 12:
                reply = QMessageBox.question(
                    self,
                    "Máy Chủ Đang Ngoại Tuyến",
                    f"Máy chủ {host.hostname} hiện đang OFFLINE.\n"
                    "Bạn có muốn gửi tín hiệu đánh thức (Wake-on-LAN) tới máy chủ không?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                )
                if reply == QMessageBox.StandardButton.Yes and self.manager.wake_host(host):
                    QMessageBox.information(
                        self,
                        "Đã Gửi Tín Hiệu Đánh Thức",
                        f"Đã gửi gói tin Wake-on-LAN tới {host.hostname}.\n"
                        "Vui lòng đợi máy chủ khởi động rồi bấm 'Chơi' lại.",
                    )
            else:
                QMessageBox.information(
                    self,
                    "Máy Chủ Đang Ngoại Tuyến",
                    f"Máy chủ {host.hostname} hiện đang OFFLINE.\n"
                    "Vui lòng bật máy chủ và dịch vụ Sunshine/Apollo trước khi kết nối.",
                )
            self.manager.refresh_host_apps(host)
            return

        logger.info(f"Launching stream: {app.title} on {host.hostname}...")

        # Non-blocking progress indicator
        progress = QProgressDialog(
            f"Đang kết nối tới {host.hostname}...\nKhởi tạo luồng phát cho {app.title}",
            "Hủy", 0, 0, self
        )
        progress.setWindowTitle("Khởi Động Remote Gaming")
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(200)
        progress.setStyleSheet("""
            QProgressDialog { background-color: #0f172a; border: 1px solid #334155; border-radius: 8px; }
            QLabel { color: #e2e8f0; font-size: 13px; font-family: 'Segoe UI', sans-serif; }
            QPushButton { background-color: #334155; color: white; border-radius: 4px; padding: 6px 16px; font-weight: bold; }
            QPushButton:hover { background-color: #ef4444; }
            QProgressBar { background-color: #1e293b; border: 1px solid #334155; border-radius: 4px; }
            QProgressBar::chunk { background-color: #38bdf8; border-radius: 3px; }
        """)

        user_canceled = False
        started = False

        def on_user_cancel():
            nonlocal user_canceled
            user_canceled = True
            controller.cancel()

        def on_stage(stage_name: str):
            progress.setLabelText(f"Đang kết nối tới {host.hostname}...\nGiai đoạn: {stage_name}")

        def on_started():
            nonlocal started
            started = True
            try:
                progress.accept()
            except Exception:
                pass

        def on_ended(term_code: int, message: str):
            # Disconnect progress.canceled before closing to prevent treating failure as user cancel (Part 1 Item 12)
            try:
                progress.canceled.disconnect(on_user_cancel)
            except Exception:
                pass
            try:
                progress.close()
            except Exception:
                pass

            try:
                controller.stage_changed.disconnect(on_stage)
            except Exception:
                pass
            try:
                controller.session_started.disconnect(on_started)
            except Exception:
                pass
            try:
                controller.session_ended.disconnect(on_ended)
            except Exception:
                pass

            if message and not user_canceled:
                if not started:
                    title = "Không Thể Khởi Động Stream"
                    content = f"Không thể bắt đầu stream:\n{message}"
                else:
                    title = "Phiên Truyền Phát Đã Kết Thúc"
                    content = f"Phiên truyền phát đã kết thúc:\n{message}"
                QMessageBox.warning(self, title, content)

            # Refresh host's app list so play state reflects reality
            try:
                self.manager.refresh_host_apps(host)
            except Exception as e:
                logger.warning(f"[RemoteScreen] Failed to refresh apps after stream: {e}")

        controller.stage_changed.connect(on_stage)
        controller.session_started.connect(on_started)
        controller.session_ended.connect(on_ended)
        progress.canceled.connect(on_user_cancel)

        progress.show()
        controller.start(host, app)

    def _on_stream_started(self, host: RemoteHost, app: RemoteApp):
        logger.info(f"Stream running for {app.title}")
        self._update_server_cmd_button_state()

    def _on_stream_stopped(self):
        self._update_server_cmd_button_state()

    def _on_stream_error(self, error: str):
        # Dialog is handled exclusively in on_ended to avoid duplicate dialogs (Part 1 Item 12)
        logger.error(f"[RemoteScreen] Stream error received: {error}")

    # ==================== ACTIONS & DIALOGS ====================

    def _on_rescan_clicked(self):
        self.manager.rescan_hosts()
        self._refresh_hosts()

    def _on_add_host_clicked(self):
        dlg = AddHostDialog(self)
        dlg.exec()

    def _on_pair_requested(self, host_uuid: str):
        host = self.manager.get_host(host_uuid)
        if host:
            dlg = PairingDialog(host, self)
            dlg.exec()

    def _on_remove_host_requested(self, host_uuid: str):
        host = self.manager.get_host(host_uuid)
        name = host.hostname if host else "máy chủ này"
        reply = QMessageBox.question(
            self,
            "Xác nhận xóa host",
            f"Bạn có chắc muốn xóa {name} khỏi danh sách Remote Gaming?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.manager.remove_host(host_uuid)

    def _on_server_cmd_clicked(self):
        if self._selected_host:
            host = self.manager.get_host(self._selected_host.uuid) or self._selected_host
            self._selected_host = host
            dlg = ServerCommandDialog(host, self)
            dlg.exec()

    def _on_settings_clicked(self):
        dlg = StreamSettingsDialog(self)
        dlg.exec()
