"""
Remote Game Card Widget with box art, hover glow, and stream launch button.
Follows Bob Gaming luxury visual aesthetic.
"""

from __future__ import annotations

import os
from typing import Optional

from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QGraphicsDropShadowEffect
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap, QPainter, QColor, QFont, QCursor

from app.core.remote.models import RemoteApp
from app.ui.icons import make_svg_pixmap


class RemoteGameCard(QFrame):
    """Card representing a game installed on the remote PC."""

    play_requested = Signal(object)  # RemoteApp

    def __init__(self, app: RemoteApp, parent=None, host_online: bool = True):
        super().__init__(parent)
        self.app = app
        self._host_online = host_online
        self._hovered = False

        self.setFixedSize(170, 240)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)  # controller navigation (gamepad_nav)
        self._setup_ui()
        self._update_style()

    def _setup_ui(self):
        self.setObjectName("remoteGameCard")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # Image poster container
        self.poster_label = QLabel()
        self.poster_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.poster_label.setFixedHeight(160)
        self.poster_label.setStyleSheet("border-radius: 8px; background-color: #1a1a2e; border: none;")

        self._load_box_art()
        layout.addWidget(self.poster_label)

        # Title
        self.title_label = QLabel(self.app.title)
        self.title_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        self.title_label.setStyleSheet("color: #ffffff; background: transparent; border: none;")
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.title_label.setWordWrap(False)
        layout.addWidget(self.title_label)

        # Bottom row: Status and Launch button
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(4)

        is_running = bool(self.app.is_running and self._host_online)
        if is_running:
            self.status_tag = QLabel("ĐANG CHẠY")
            self.status_tag.setStyleSheet("""
                background-color: rgba(16, 185, 129, 0.25);
                color: #34d399;
                border: none;
                border-radius: 4px;
                padding: 1px 4px;
                font-size: 9px;
                font-weight: 700;
            """)
            bottom_row.addWidget(self.status_tag)
        elif self.app.is_hdr_supported:
            self.hdr_tag = QLabel("HDR")
            self.hdr_tag.setStyleSheet("""
                background-color: rgba(245, 158, 11, 0.25);
                color: #fbbf24;
                border: none;
                border-radius: 4px;
                padding: 1px 4px;
                font-size: 9px;
                font-weight: 700;
            """)
            bottom_row.addWidget(self.hdr_tag)

        bottom_row.addStretch()

        btn_text = "Tiếp tục" if is_running else "Chơi"
        self.play_btn = QPushButton(btn_text)
        self.play_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.play_btn.clicked.connect(lambda: self.play_requested.emit(self.app))
        self.play_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #d97706, stop:1 #b45309);
                color: #ffffff;
                border: none;
                border-radius: 5px;
                padding: 3px 10px;
                font-size: 11px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
            }
        """)
        bottom_row.addWidget(self.play_btn)

        layout.addLayout(bottom_row)

    def _load_box_art(self):
        if self.app.box_art_path and os.path.exists(self.app.box_art_path):
            pix = QPixmap(self.app.box_art_path)
            if not pix.isNull():
                scaled = pix.scaled(
                    154, 160,
                    Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                    Qt.TransformationMode.SmoothTransformation,
                )
                self.poster_label.setPixmap(scaled)
                return

        # Fallback default poster
        self.poster_label.setPixmap(make_svg_pixmap("gamepad", color="#64748b", size=48))

    def _update_style(self):
        if self._hovered:
            self.setStyleSheet("""
                #remoteGameCard {
                    background: rgba(30, 27, 75, 0.85);
                    border: 1px solid rgba(251, 191, 36, 0.6);
                    border-radius: 10px;
                }
                #remoteGameCard QLabel {
                    border: none;
                    background: transparent;
                }
            """)
        else:
            self.setStyleSheet("""
                #remoteGameCard {
                    background: rgba(22, 22, 34, 0.7);
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 10px;
                }
                #remoteGameCard QLabel {
                    border: none;
                    background: transparent;
                }
            """)

    def enterEvent(self, event):
        self._hovered = True
        self._update_style()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hovered = False
        self._update_style()
        super().leaveEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.play_requested.emit(self.app)
        super().mouseDoubleClickEvent(event)

    # ── Controller navigation (app/ui/gamepad_nav.py) ──

    def gamepad_activate(self):
        self.play_requested.emit(self.app)

    def gamepad_hints(self) -> list[tuple[str, str]]:
        return [("A", self.play_btn.text())]
