"""
UI components for Remote Gaming in Bob Gaming Game Center.
"""

from app.ui.remote.host_card import HostCard
from app.ui.remote.host_dialog import AddHostDialog
from app.ui.remote.pairing_dialog import PairingDialog
from app.ui.remote.remote_game_card import RemoteGameCard
from app.ui.remote.remote_screen import RemoteScreen
from app.ui.remote.server_cmd_dialog import ServerCommandDialog
from app.ui.remote.settings_dialog import StreamSettingsDialog

__all__ = [
    "RemoteScreen",
    "HostCard",
    "RemoteGameCard",
    "PairingDialog",
    "AddHostDialog",
    "StreamSettingsDialog",
    "ServerCommandDialog",
]
