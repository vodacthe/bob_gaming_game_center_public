"""
Steam Artwork & Non-Steam Game Manager Dialog for Bob Gaming Game Center.
Allows users to add non-Steam games to Steam, manage shortcuts, and automatically
download and deploy all 5 Steam artwork asset types (Poster, Grid, Hero, Logo, Icon).
"""

from concurrent.futures import ThreadPoolExecutor, as_completed
import logging
import os
import threading

from PySide6.QtCore import QObject, Qt, QThread, Signal, Slot
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader
from app.config import STEAMGRIDB_API_KEY
from app.core.steam_artwork import download_and_apply_steam_artworks
from app.core.steam_manager import (
    add_non_steam_game,
    close_steam,
    find_game_executable,
    find_steam_path,
    get_all_steam_shortcuts,
    get_steam_user_ids,
    is_steam_running,
)

logger = logging.getLogger(__name__)
TAG = "[SteamArtwork]"

# A QThread must never be garbage-collected while it runs (that aborts the whole process), so every running sync keeps
# a strong reference here until its thread has really finished.
_active_syncs: set = set()
_done_callbacks: set = set()
_quit_hooked = False


def _hook_quit() -> None:
    global _quit_hooked
    app = QApplication.instance()
    if app is not None and not _quit_hooked:
        app.aboutToQuit.connect(_stop_syncs_on_quit)
        _quit_hooked = True


def _stop_syncs_on_quit() -> None:
    for worker, thread in list(_active_syncs):
        try:
            worker.cancel()
            thread.quit()
            if not thread.wait(5000):
                logger.warning(f"{TAG} a sync thread was still running at exit")
        except RuntimeError:
            pass   # the Qt objects are already gone


class _MainThreadCall(QObject):
    """Runs `fn` in the thread this object was created in (the GUI thread) when `call` is triggered by a signal."""

    def __init__(self, fn):
        super().__init__()
        self._fn = fn

    @Slot()
    def call(self):
        try:
            self._fn()
        except Exception:
            logger.exception(f"{TAG} callback failed")


class _SteamSyncWorker(QObject):
    """Background worker for downloading and applying Steam artworks concurrently."""

    progress = Signal(int, int, str)  # (current, total, message)
    item_done = Signal(dict)          # summary dict for finished game
    finished = Signal()

    def __init__(self, tasks: list[dict], steam_path: str, user_ids: list[str]):
        super().__init__()
        self.tasks = tasks  # list of {"game_name": str, "uint_appid": int}
        self.steam_path = steam_path
        self.user_ids = user_ids
        self._is_cancelled = False
        self._lock = threading.Lock()
        self._completed_count = 0

    def cancel(self):
        self._is_cancelled = True

    def _process_task(self, task: dict, total: int):
        if self._is_cancelled:
            return None

        gname = task["game_name"]
        appid = task["uint_appid"]

        with self._lock:
            cur = self._completed_count
        self.progress.emit(cur, total, f"Fetching artworks for '{gname}'...")

        def _step_cb(asset_type, msg):
            if not self._is_cancelled:
                with self._lock:
                    c = self._completed_count
                self.progress.emit(c, total, f"[{gname}] {msg}")

        res = download_and_apply_steam_artworks(
            game_name=gname,
            uint_appid=appid,
            steam_path=self.steam_path,
            target_user_ids=self.user_ids,
            api_key=STEAMGRIDB_API_KEY,
            progress_callback=_step_cb,
        )

        with self._lock:
            self._completed_count += 1
            cur = self._completed_count

        self.progress.emit(cur, total, f"Completed artworks for '{gname}' ({cur}/{total})")
        self.item_done.emit(res)
        return res

    def run(self):
        total = len(self.tasks)
        try:
            if total == 0:
                self.progress.emit(0, 0, "All artwork tasks completed.")
                return
            logger.info(f"{TAG} syncing artworks for {total} game(s): {[t.get('game_name') for t in self.tasks]}")
            max_workers = min(4, total)
            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                futures = [pool.submit(self._process_task, task, total) for task in self.tasks]
                for f in as_completed(futures):
                    try:
                        f.result()
                    except Exception:
                        logger.exception(f"{TAG} error processing an artwork task")
            self.progress.emit(total, total, "All artwork tasks completed.")
            logger.info(f"{TAG} artwork sync finished ({total} game(s))")
        except Exception:
            logger.exception(f"{TAG} artwork sync crashed")
        finally:
            self.finished.emit()                      # always: the UI and the thread wait for this


class SteamArtworkDialog(QDialog):
    """Dialog for Steam shortcut and artwork management."""

    back_requested = Signal()

    def __init__(self, *args, **kwargs):
        parent = kwargs.pop("parent", None)
        config = kwargs.pop("config", None)
        initial_game = kwargs.pop("initial_game", None)

        if len(args) == 1:
            if isinstance(args[0], dict) and config is None:
                config = args[0]
            elif parent is None:
                parent = args[0]
        elif len(args) >= 2:
            if isinstance(args[0], dict):
                config = args[0]
                if isinstance(args[1], dict) or args[1] is None:
                    initial_game = args[1]
                else:
                    parent = args[1]
            else:
                parent = args[0]
                config = args[1]
                if len(args) >= 3:
                    initial_game = args[2]

        super().__init__(parent)
        self.config = config or {}
        self.initial_game = initial_game
        self.steam_path = find_steam_path()
        self.user_ids = get_steam_user_ids(self.steam_path) if self.steam_path else []

        self._thread: QThread | None = None
        self._worker: _SteamSyncWorker | None = None
        self._pending_tasks: list[dict] = []      # asked for while a sync is running: started after it finishes

        self.setWindowTitle("Quản lý ảnh bìa Steam & Game Non-Steam")
        self.resize(860, 620)
        self.setMinimumSize(780, 520)
        self.setStyleSheet("""
            QDialog {
                background-color: #0b0e14;
                border: 1px solid rgba(212, 175, 55, 0.35);
                border-radius: 10px;
            }
            QLabel {
                color: #c9d1d9;
                font-size: 13px;
            }
            QTabWidget::pane {
                border: 1px solid rgba(255, 255, 255, 0.08);
                background-color: #121620;
                border-radius: 6px;
            }
            QTabBar::tab {
                background-color: #161b24;
                color: #8b949e;
                padding: 8px 18px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 4px;
                font-weight: bold;
                font-size: 13px;
            }
            QTabBar::tab:selected {
                background-color: #121620;
                color: #a855f7;
                border-bottom: 2px solid #a855f7;
            }
            QTabBar::tab:hover {
                color: #ffffff;
            }
            QTableWidget {
                background-color: #161b22;
                color: #c9d1d9;
                gridline-color: #30363d;
                border: none;
                font-size: 12px;
                selection-background-color: #21262d;
                selection-color: #ffffff;
            }
            QHeaderView::section {
                background-color: #21262d;
                color: #8b949e;
                padding: 6px;
                border: 1px solid #30363d;
                font-weight: bold;
            }
            QPushButton {
                background-color: #21262d;
                color: #c9d1d9;
                border: 1px solid #30363d;
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 12px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #30363d;
                color: #ffffff;
            }
            QPushButton:disabled {
                background-color: #161b22;
                color: #484f58;
                border-color: #21262d;
            }
            QPushButton#secondaryBtn {
                background-color: rgba(255, 255, 255, 0.08);
                color: #cbd5e1;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 600;
                font-size: 12px;
            }
            QPushButton#secondaryBtn:hover {
                background-color: rgba(255, 255, 255, 0.16);
                color: #ffffff;
                border-color: rgba(255, 255, 255, 0.3);
            }
            QProgressBar {
                border: 1px solid #30363d;
                border-radius: 4px;
                background-color: #21262d;
                text-align: center;
                color: #ffffff;
                font-size: 11px;
                font-weight: bold;
                height: 16px;
            }
            QProgressBar::chunk {
                background-color: #2ed573;
                border-radius: 3px;
            }
            QTextEdit {
                background-color: #090d13;
                color: #8b949e;
                border: 1px solid #21262d;
                border-radius: 6px;
                font-family: 'Consolas', 'Courier New', monospace;
                font-size: 11px;
            }
        """)

        self._setup_ui()
        self._refresh_steam_status()
        self._load_steam_shortcuts()
        self._load_bob_games()

    def _on_back(self):
        self.back_requested.emit()
        self.close()

    def _setup_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # 1. Header
        steam_dir_text = self.steam_path if self.steam_path else "Không tìm thấy"
        user_count = len(self.user_ids)
        header = ScreenHeader(
            "Ảnh bìa Steam", "image",
            subtitle=f"Đường dẫn Steam: {steam_dir_text}  •  {user_count} Hồ sơ người dùng",
        )
        header.back_requested.connect(self._on_back)
        self.back_btn = header.back_btn
        self.steam_badge = header.add_badge("Đang kiểm tra Steam...", "off")
        self.close_steam_btn = header.add_button(
            "Đóng Steam", "danger", icon="close",
            tooltip="Cần đóng Steam trước khi lưu phím tắt để tránh bị Steam ghi đè dữ liệu.")
        self.close_steam_btn.clicked.connect(self._on_close_steam_clicked)
        outer.addWidget(header)

        body = QWidget()
        root_layout = QVBoxLayout(body)
        root_layout.setContentsMargins(*CONTENT_MARGINS)
        root_layout.setSpacing(12)
        outer.addWidget(body, 1)

        # 2. Main Tabs
        self.tabs = QTabWidget()

        # Tab A: Existing Steam Shortcuts
        self.tab_shortcuts = QWidget()
        self._setup_shortcuts_tab()
        self.tabs.addTab(self.tab_shortcuts, "Phím tắt Steam (Non-Steam)")

        # Tab B: Add Bob Gaming Games to Steam
        self.tab_add_games = QWidget()
        self._setup_add_games_tab()
        self.tabs.addTab(self.tab_add_games, "Thêm vào Steam && Tải ảnh bìa")

        root_layout.addWidget(self.tabs, 1)

        # 3. Bottom Progress & Log Stream
        bottom_box = QVBoxLayout()
        bottom_box.setSpacing(6)

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        bottom_box.addWidget(self.progress_bar)

        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: #8b949e; font-size: 12px;")
        bottom_box.addWidget(self.status_label)

        self.log_console = QTextEdit()
        self.log_console.setReadOnly(True)
        self.log_console.setFixedHeight(90)
        bottom_box.addWidget(self.log_console)

        root_layout.addLayout(bottom_box)

    def _setup_shortcuts_tab(self):
        from app.ui.icons import make_svg_icon
        layout = QVBoxLayout(self.tab_shortcuts)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        # Action toolbar
        toolbar = QHBoxLayout()
        desc = QLabel("Danh sách game Non-Steam phát hiện trong tệp shortcuts.vdf:")
        desc.setStyleSheet("color: #8b949e; font-size: 12px;")
        toolbar.addWidget(desc)
        toolbar.addStretch()

        self.select_all_shortcuts_btn = QPushButton("Chọn tất cả")
        self.select_all_shortcuts_btn.clicked.connect(self._select_all_shortcuts)
        toolbar.addWidget(self.select_all_shortcuts_btn)

        self.sync_selected_shortcuts_btn = QPushButton(" Tải ảnh bìa mục đã chọn")
        self.sync_selected_shortcuts_btn.setIcon(make_svg_icon("sync", 14, "#0b0e14"))
        self.sync_selected_shortcuts_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
                color: #0b0e14;
                font-weight: bold;
                border: none;
                border-radius: 6px;
                padding: 6px 14px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #fbbf24, stop:1 #f59e0b);
            }
        """)
        self.sync_selected_shortcuts_btn.clicked.connect(self._sync_selected_shortcuts)
        toolbar.addWidget(self.sync_selected_shortcuts_btn)

        self.refresh_shortcuts_btn = QPushButton(" Làm mới")
        self.refresh_shortcuts_btn.setIcon(make_svg_icon("refresh", 14, "#8c96a8"))
        self.refresh_shortcuts_btn.clicked.connect(self._load_steam_shortcuts)
        toolbar.addWidget(self.refresh_shortcuts_btn)

        layout.addLayout(toolbar)

        # Table
        self.shortcuts_table = QTableWidget()
        self.shortcuts_table.setColumnCount(5)
        self.shortcuts_table.setHorizontalHeaderLabels([
            "Chọn", "Tên trò chơi", "Đường dẫn thực thi (.exe)", "Trạng thái ảnh bìa", "Thao tác"
        ])
        self.shortcuts_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.shortcuts_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.shortcuts_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.shortcuts_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.shortcuts_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.shortcuts_table.verticalHeader().setVisible(False)
        layout.addWidget(self.shortcuts_table)

    def _setup_add_games_tab(self):
        from app.ui.icons import make_svg_icon
        layout = QVBoxLayout(self.tab_add_games)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        toolbar = QHBoxLayout()
        desc = QLabel("Game trong thư viện Bob Gaming sẵn sàng thêm vào Steam:")
        desc.setStyleSheet("color: #8b949e; font-size: 12px;")
        toolbar.addWidget(desc)
        toolbar.addStretch()

        self.select_all_bob_btn = QPushButton("Chọn tất cả")
        self.select_all_bob_btn.clicked.connect(self._select_all_bob_games)
        toolbar.addWidget(self.select_all_bob_btn)

        self.add_selected_btn = QPushButton(" Thêm vào Steam && Tải ảnh bìa")
        self.add_selected_btn.setIcon(make_svg_icon("plus", 14, "#0b0e14"))
        self.add_selected_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
                color: #0b0e14;
                font-weight: bold;
                border: none;
                border-radius: 6px;
                padding: 6px 16px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #fbbf24, stop:1 #f59e0b);
            }
        """)
        self.add_selected_btn.clicked.connect(self._add_selected_games_to_steam)
        toolbar.addWidget(self.add_selected_btn)

        layout.addLayout(toolbar)

        self.bob_table = QTableWidget()
        self.bob_table.setColumnCount(5)
        self.bob_table.setHorizontalHeaderLabels([
            "Chọn", "Tên trò chơi", "File thực thi (.exe)", "Trong Steam", "Thao tác"
        ])
        self.bob_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.bob_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.bob_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.bob_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.bob_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.bob_table.verticalHeader().setVisible(False)
        layout.addWidget(self.bob_table)

    def _refresh_steam_status(self):
        running = is_steam_running()
        if running:
            self.steam_badge.set_state("● Steam đang chạy (Cần đóng)", "warn")
            self.close_steam_btn.setEnabled(True)
            self.close_steam_btn.setVisible(True)
        else:
            self.steam_badge.set_state("● Steam đã tắt (An toàn để lưu)", "ok")
            self.close_steam_btn.setEnabled(False)
            self.close_steam_btn.setVisible(False)

    def _on_close_steam_clicked(self):
        self._append_log("Đang tiến hành đóng ứng dụng Steam an toàn...")
        self.status_label.setText("Đang đóng Steam...")
        success = close_steam(timeout=8, steam_path=self.steam_path)
        self._refresh_steam_status()
        if success:
            self._append_log("Đã đóng Steam thành công. An toàn để cập nhật phím tắt.")
            self.status_label.setText("Steam đã đóng.")
            QMessageBox.information(self, "Steam đã đóng", "Ứng dụng Steam đã được đóng an toàn.")
        else:
            self._append_log("Không thể đóng hoàn toàn ứng dụng Steam.")
            QMessageBox.warning(self, "Cảnh báo Steam", "Không thể tự động tắt Steam. Vui lòng đóng Steam thủ công trước khi thao tác.")

    def _append_log(self, text: str):
        self.log_console.append(text)
        logger.info(f"[SteamDialog] {text}")

    def _load_steam_shortcuts(self):
        """Populate the Steam shortcuts table."""
        self.shortcuts_table.setRowCount(0)
        shortcuts = get_all_steam_shortcuts(self.steam_path)
        self._steam_shortcuts_data = shortcuts

        for row, s in enumerate(shortcuts):
            self.shortcuts_table.insertRow(row)

            # Col 0: Checkbox
            cb_item = QTableWidgetItem()
            cb_item.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            cb_item.setCheckState(Qt.CheckState.Unchecked)
            self.shortcuts_table.setItem(row, 0, cb_item)

            # Col 1: Name
            name_item = QTableWidgetItem(s["appname"])
            name_item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self.shortcuts_table.setItem(row, 1, name_item)

            # Col 2: Exe
            exe_item = QTableWidgetItem(s["exe"])
            exe_item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self.shortcuts_table.setItem(row, 2, exe_item)

            # Col 3: Artwork badges
            art = s["artworks"]
            badge_widget = QWidget()
            b_layout = QHBoxLayout(badge_widget)
            b_layout.setContentsMargins(4, 2, 4, 2)
            b_layout.setSpacing(4)

            labels = [
                ("Poster", art.get("poster")),
                ("Grid", art.get("grid")),
                ("Hero", art.get("hero")),
                ("Logo", art.get("logo")),
                ("Icon", art.get("icon")),
            ]
            for title, present in labels:
                lbl = QLabel(title)
                lbl.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
                if present:
                    lbl.setStyleSheet("background-color: rgba(46, 213, 115, 0.2); color: #2ed573; border-radius: 3px; padding: 1px 4px;")
                else:
                    lbl.setStyleSheet("background-color: rgba(255, 255, 255, 0.05); color: #8b949e; border-radius: 3px; padding: 1px 4px;")
                b_layout.addWidget(lbl)
            self.shortcuts_table.setCellWidget(row, 3, badge_widget)

            # Col 4: Action button
            sync_btn = QPushButton("Tải ảnh bìa")
            sync_btn.clicked.connect(lambda checked=False, sc=s: self._sync_single_shortcut(sc))
            self.shortcuts_table.setCellWidget(row, 4, sync_btn)

    def _load_bob_games(self):
        """Populate the Bob Gaming library games table."""
        self.bob_table.setRowCount(0)
        config_games = self.config.get("games", {})

        # Build list of existing steam shortcut names for quick checking
        existing_steam_names = {
            s["appname"].lower() for s in getattr(self, "_steam_shortcuts_data", [])
        }

        # Collect all non-steam games from both config_games and manual_games
        games_dict: dict[str, dict] = {}
        for name, data in config_games.items():
            if data.get("source") != "steam":
                games_dict[name] = data

        for name in self.config.get("manual_games", []):
            if name not in games_dict:
                games_dict[name] = config_games.get(name, {})

        row = 0
        for name, data in games_dict.items():
            self.bob_table.insertRow(row)

            # Col 0: Checkbox
            cb_item = QTableWidgetItem()
            cb_item.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            is_initial = self.initial_game and self.initial_game.get("name") == name
            cb_item.setCheckState(Qt.CheckState.Checked if is_initial else Qt.CheckState.Unchecked)
            self.bob_table.setItem(row, 0, cb_item)

            # Col 1: Name
            name_item = QTableWidgetItem(name)
            name_item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self.bob_table.setItem(row, 1, name_item)

            # Col 2: Executable with browse button
            exe_widget = QWidget()
            exe_layout = QHBoxLayout(exe_widget)
            exe_layout.setContentsMargins(2, 2, 2, 2)
            exe_layout.setSpacing(6)

            exe_path = data.get("exe_path", "")
            if not exe_path:
                install_dir = data.get("install_location") or data.get("save_path")
                if install_dir and os.path.isdir(install_dir):
                    auto_exe = find_game_executable(install_dir, name)
                    if auto_exe:
                        exe_path = auto_exe
                        data["exe_path"] = auto_exe

            exe_label = QLabel(exe_path if exe_path else "— Chưa cấu hình .exe —")
            exe_label.setStyleSheet("color: #ffffff;" if exe_path else "color: #a855f7; font-style: italic;")
            exe_layout.addWidget(exe_label, 1)

            browse_btn = QPushButton("...")
            browse_btn.setFixedWidth(30)
            browse_btn.clicked.connect(lambda checked=False, r=row, gn=name, gdata=data: self._browse_exe(r, gn, gdata))
            exe_layout.addWidget(browse_btn)

            self.bob_table.setCellWidget(row, 2, exe_widget)

            # Col 3: Already in Steam?
            in_steam = name.lower() in existing_steam_names
            status_lbl = QLabel("● Đã trong Steam" if in_steam else "○ Chưa có")
            status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            if in_steam:
                status_lbl.setStyleSheet("color: #2ed573; font-weight: bold;")
            else:
                status_lbl.setStyleSheet("color: #8b949e;")
            self.bob_table.setCellWidget(row, 3, status_lbl)

            # Col 4: Action button
            add_btn = QPushButton("Thêm && Tải ảnh")
            add_btn.clicked.connect(lambda checked=False, gn=name, gdata=data: self._add_single_game(gn, gdata))
            self.bob_table.setCellWidget(row, 4, add_btn)

            row += 1

    def _browse_exe(self, row: int, game_name: str, game_data: dict):
        current_dir = game_data.get("install_location") or "C:\\"
        file_path, _ = QFileDialog.getOpenFileName(
            self, f"Select executable for {game_name}", current_dir, "Executable Files (*.exe)"
        )
        if file_path:
            game_data["exe_path"] = file_path
            # Update cell label
            cell_widget = self.bob_table.cellWidget(row, 2)
            if cell_widget:
                lbl = cell_widget.findChild(QLabel)
                if lbl:
                    lbl.setText(file_path)
                    lbl.setStyleSheet("color: #ffffff;")
            self._append_log(f"Set executable for '{game_name}': {file_path}")

    def _select_all_shortcuts(self):
        for row in range(self.shortcuts_table.rowCount()):
            item = self.shortcuts_table.item(row, 0)
            if item:
                item.setCheckState(Qt.CheckState.Checked)

    def _select_all_bob_games(self):
        for row in range(self.bob_table.rowCount()):
            item = self.bob_table.item(row, 0)
            if item:
                item.setCheckState(Qt.CheckState.Checked)

    def _sync_single_shortcut(self, shortcut: dict):
        tasks = [{
            "game_name": shortcut["appname"],
            "uint_appid": shortcut["uint_appid"],
        }]
        self._start_sync_tasks(tasks)

    def _sync_selected_shortcuts(self):
        tasks = []
        for row in range(self.shortcuts_table.rowCount()):
            item = self.shortcuts_table.item(row, 0)
            if item and item.checkState() == Qt.CheckState.Checked:
                s = self._steam_shortcuts_data[row]
                tasks.append({
                    "game_name": s["appname"],
                    "uint_appid": s["uint_appid"],
                })

        if not tasks:
            QMessageBox.information(self, "No Selection", "Please check at least one game to sync.")
            return

        self._start_sync_tasks(tasks)

    def _add_single_game(self, game_name: str, game_data: dict):
        exe = game_data.get("exe_path")
        if not exe or not os.path.exists(exe):
            QMessageBox.warning(
                self,
                "Missing Executable",
                f"Please specify a valid .exe path for '{game_name}' using the browse button.",
            )
            return

        # Check steam running
        if is_steam_running():
            reply = QMessageBox.question(
                self,
                "Steam is Running",
                "Steam is currently running. Adding a shortcut while Steam is running may cause Steam to overwrite it upon closing.\n\n"
                "Would you like to close Steam automatically now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.Yes:
                close_steam(timeout=6, steam_path=self.steam_path)
                self._refresh_steam_status()

        add_res = add_non_steam_game(
            game_name=game_name,
            exe_path=exe,
            steam_path=self.steam_path,
            target_user_ids=self.user_ids,
        )

        if not add_res["success"]:
            QMessageBox.critical(self, "Add Failed", add_res.get("message", "Error adding game to Steam."))
            return

        self._append_log(f"Added '{game_name}' to Steam shortcuts (AppID: {add_res['appid']}).")

        # Start artwork download
        tasks = [{
            "game_name": game_name,
            "uint_appid": add_res["appid"],
        }]
        self._start_sync_tasks(tasks)

    def _add_selected_games_to_steam(self):
        selected_games = []
        config_games = self.config.get("games", {})

        for row in range(self.bob_table.rowCount()):
            item = self.bob_table.item(row, 0)
            if item and item.checkState() == Qt.CheckState.Checked:
                name_item = self.bob_table.item(row, 1)
                if name_item:
                    gn = name_item.text()
                    gdata = config_games.get(gn, {})
                    selected_games.append((gn, gdata))

        if not selected_games:
            QMessageBox.information(self, "No Selection", "Please check at least one game to add.")
            return

        # Check missing exes
        missing_exes = [gn for gn, gd in selected_games if not gd.get("exe_path") or not os.path.exists(gd.get("exe_path"))]
        if missing_exes:
            QMessageBox.warning(
                self,
                "Missing Executables",
                "The following game(s) do not have a valid .exe set:\n\n"
                + "\n".join(f"• {g}" for g in missing_exes[:5])
                + "\n\nPlease configure their .exe path before adding.",
            )
            return

        if is_steam_running():
            reply = QMessageBox.question(
                self,
                "Steam is Running",
                "Steam is running. To safely write shortcuts, Steam should be closed.\n\n"
                "Close Steam automatically now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.Yes:
                close_steam(timeout=6, steam_path=self.steam_path)
                self._refresh_steam_status()

        tasks = []
        for gn, gd in selected_games:
            res = add_non_steam_game(
                game_name=gn,
                exe_path=gd["exe_path"],
                steam_path=self.steam_path,
                target_user_ids=self.user_ids,
            )
            if res["success"]:
                self._append_log(f"Added '{gn}' (AppID: {res['appid']})")
                tasks.append({
                    "game_name": gn,
                    "uint_appid": res["appid"],
                })

        if tasks:
            self._start_sync_tasks(tasks)

    def _sync_running(self) -> bool:
        thread = self._thread
        try:
            return thread is not None and thread.isRunning()
        except RuntimeError:                         # the QThread was already deleted
            return False

    def _start_sync_tasks(self, tasks: list[dict]):
        """Download + apply the artworks of these games. One sync at a time: a request made while one is running is
        queued and started when it ends (starting a second QThread over the first one used to crash the app)."""
        if not tasks:
            return
        if self._sync_running():
            known = {t["uint_appid"] for t in self._pending_tasks}
            added = [t for t in tasks if t["uint_appid"] not in known]
            self._pending_tasks.extend(added)
            names = ", ".join(t["game_name"] for t in added) or "(đã có trong hàng đợi)"
            logger.info(f"{TAG} a sync is running; queued {len(added)} game(s): {names}")
            self.status_label.setText(f"Đang tải ảnh bìa, đã xếp hàng thêm: {names}")
            self._append_log(f"Đã xếp hàng: {names}")
            return

        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, len(tasks))
        self.progress_bar.setValue(0)
        self.status_label.setText(f"Starting artwork sync for {len(tasks)} game(s)...")

        thread = QThread()
        worker = _SteamSyncWorker(tasks, self.steam_path, self.user_ids)
        worker.moveToThread(thread)
        self._thread, self._worker = thread, worker
        _hook_quit()
        entry = [worker, thread, None]
        _active_syncs.add(tuple(entry[:2]))

        thread.started.connect(worker.run)
        worker.progress.connect(self._on_sync_progress)
        worker.item_done.connect(self._on_item_done)
        worker.finished.connect(self._on_sync_finished)
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)

        def thread_done():
            _active_syncs.discard((worker, thread))
            _done_callbacks.discard(callback)
            thread.deleteLater()
            if self._thread is thread:
                self._thread = self._worker = None
            self._start_next_pending()

        callback = _MainThreadCall(thread_done)      # lives in the GUI thread, so the queue is started there
        _done_callbacks.add(callback)
        thread.finished.connect(callback.call)
        thread.start()
        logger.info(f"{TAG} sync thread started for {len(tasks)} game(s)")

    def _start_next_pending(self):
        try:
            if self._pending_tasks and not self._sync_running():
                tasks, self._pending_tasks = self._pending_tasks, []
                logger.info(f"{TAG} starting the queued sync ({len(tasks)} game(s))")
                self._start_sync_tasks(tasks)
        except RuntimeError:                         # the dialog was closed meanwhile
            self._pending_tasks = []
        except Exception:
            logger.exception(f"{TAG} could not start the queued sync")

    def _on_sync_progress(self, current: int, total: int, msg: str):
        self.progress_bar.setValue(current)
        self.status_label.setText(msg)
        self._append_log(msg)

    def _on_item_done(self, result: dict):
        gname = result.get("game_name", "")
        down = result.get("downloaded", {})
        down_list = [k.capitalize() for k, v in down.items() if v]
        down_str = ", ".join(down_list) if down_list else "None"
        self._append_log(f"Đã tải ảnh bìa cho '{gname}': {down_str}")

    def _on_sync_finished(self):
        self.status_label.setText("Đồng bộ ảnh bìa thành công!")
        self.progress_bar.setVisible(False)
        self._load_steam_shortcuts()
        self._load_bob_games()
        if self._pending_tasks:                      # more games are queued: report once, when the last one is done
            return
        QMessageBox.information(
            self,
            "Hoàn tất đồng bộ",
            "Toàn bộ ảnh bìa đã được tải về và thiết lập vào thư mục Steam Grid.\n\n"
            "Mẹo: Nếu Steam đang mở, vui lòng khởi động lại Steam để cập nhật hiển thị.",
        )


SteamArtworkScreen = SteamArtworkDialog
