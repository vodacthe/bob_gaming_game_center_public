"""
In-app screen under KHO GAME displaying paid Steam games and paid DLCs currently
running a 100%-off ("Forever to Keep") promotion, with live verification status,
manual refresh, single-click claim, and direct Steam Store page link.
"""

from __future__ import annotations

import functools
import inspect
import json
import logging
import os
import subprocess
import sys
import webbrowser

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from app.core import steam_free_keep, steam_manager
from app.core.online_fix.extractor import clean_subprocess_env
from app.core.steam_chat import cdp, steam_debug
from app.ui.game_card import DARK_BTN_STYLE, GREEN_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_pixmap
from app.ui.online_fix.common import (
    STATUS_COLORS,
    SpinningLoader,
    Task,
    make_button,
    render_rounded_image,
)
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader

logger = logging.getLogger(__name__)
TAG = "[Steam/FreeKeepUI]"

_MUTED_DISABLED_RULE = (
    "QPushButton:disabled { color: rgba(255, 255, 255, 0.42); "
    "background-color: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255, 255, 255, 0.08); }"
)


def _safe_slot(func):
    """Guard Qt slots so exceptions log with traceback and never reach Qt's event loop."""
    params = list(inspect.signature(func).parameters.values())[1:]
    accepts_varargs = any(p.kind is inspect.Parameter.VAR_POSITIONAL for p in params)
    max_args = len([p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if not accepts_varargs:
            args = args[:max_args]
        try:
            if not isValid(self):
                return None
            return func(self, *args, **kwargs)
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} {type(self).__name__}.{func.__name__} failed")
            return None

    return wrapper


def _allow_foreground_handoff() -> None:
    """Let Steam bring its Store window in front of our elevated app after the user clicks 'Mở Steam'."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.user32.AllowSetForegroundWindow(ctypes.c_uint32(0xFFFFFFFF))
    except Exception:  # noqa: BLE001
        pass


def open_steam_store_page(appid: int, store_url: str = "", port: int = cdp.DEFAULT_PORT) -> bool:
    """Open the game/DLC page inside Steam Desktop if installed, falling back to HTTPS browser URL."""
    fallback = store_url or (steam_free_keep.APP_PAGE_URL.format(appid=appid) if appid > 0 else "")
    if appid > 0:
        steam_uri = f"steam://store/{appid}"
        _state, target = steam_debug.probe(port=port)
        ws_url = str((target or {}).get("webSocketDebuggerUrl") or "")
        if ws_url:
            try:
                sess = cdp.CdpSession(ws_url, connect_timeout=2.0)
                try:
                    sess.evaluate(
                        f"(window.SteamClient.URL.ExecuteSteamURL({json.dumps(steam_uri)}), true)",
                        timeout=3.0,
                        await_promise=False,
                    )
                    logger.info(f"{TAG} Opened Steam Store page via Steam CEF: {steam_uri}")
                    return True
                finally:
                    sess.close()
            except Exception as exc:  # noqa: BLE001
                logger.warning(f"{TAG} Steam CEF ExecuteSteamURL failed for {steam_uri}: {exc}")

        steam_path = steam_manager.find_steam_path()
        if steam_path:
            if sys.platform == "win32":
                try:
                    os.startfile(steam_uri)
                    logger.info(f"{TAG} Opened Steam Store page via steam:// URI: {steam_uri}")
                    return True
                except OSError as exc:
                    logger.warning(f"{TAG} os.startfile({steam_uri}) failed: {exc}")
            steam_cmd = steam_manager.get_steam_executable(steam_path)
            if steam_cmd:
                cmd = (
                    ["flatpak", "run", "com.valvesoftware.Steam", steam_uri]
                    if steam_cmd == "flatpak"
                    else [steam_cmd, steam_uri]
                )
                try:
                    subprocess.Popen(
                        cmd,
                        cwd=steam_path if os.path.isdir(steam_path) else None,
                        env=clean_subprocess_env(),
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    )
                    logger.info(f"{TAG} Opened Steam Store page via Steam client ({steam_cmd}): {steam_uri}")
                    return True
                except OSError as exc:
                    logger.warning(f"{TAG} Steam launch failed for {steam_uri} ({steam_cmd}): {exc}")

    if fallback and webbrowser.open(fallback):
        logger.info(f"{TAG} Opened Steam Store page in browser: {fallback}")
        return True
    logger.warning(f"{TAG} Failed to open Steam Store page for appid={appid} ({fallback})")
    return False


class _PromoItemCard(QFrame):
    """Single row card representing an active 100%-off paid Steam game or DLC."""

    claim_requested = Signal(dict)  # item dict
    open_requested = Signal(dict)   # item dict

    THUMB_W = 184
    THUMB_H = 86

    def __init__(self, item: dict, parent=None):
        super().__init__(parent)
        self.item = dict(item)
        self.setObjectName("steamFreeCard")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet("""
            #steamFreeCard {
                background-color: rgba(15, 21, 34, 0.86);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 12px;
            }
            #steamFreeCard:hover {
                border-color: rgba(139, 92, 246, 0.45);
                background-color: rgba(20, 28, 45, 0.92);
            }
            #steamFreeCard QLabel { background: transparent; border: none; }
        """)

        row = QHBoxLayout(self)
        row.setContentsMargins(14, 12, 16, 12)
        row.setSpacing(16)

        # Left thumbnail banner
        self.thumb_lbl = QLabel()
        self.thumb_lbl.setFixedSize(self.THUMB_W, self.THUMB_H)
        self.thumb_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thumb_lbl.setStyleSheet(
            "background-color: rgba(10, 14, 24, 0.95); "
            "border: 1px solid rgba(255, 255, 255, 0.07); border-radius: 8px;"
        )
        self.thumb_lbl.setPixmap(make_svg_pixmap("steam", size=28, color="#475569"))
        row.addWidget(self.thumb_lbl)

        # Middle details column
        mid = QVBoxLayout()
        mid.setContentsMargins(0, 0, 0, 0)
        mid.setSpacing(5)

        title_row = QHBoxLayout()
        title_row.setSpacing(8)

        is_dlc = str(self.item.get("item_type") or "").lower() == "dlc"
        self.type_badge = QLabel("DLC" if is_dlc else "GAME")
        if is_dlc:
            self.type_badge.setStyleSheet(
                "color: #fbbf24; background-color: rgba(245, 158, 11, 0.16); "
                "border: 1px solid rgba(245, 158, 11, 0.45); border-radius: 5px; "
                "padding: 1px 7px; font-size: 10px; font-weight: 800;"
            )
        else:
            self.type_badge.setStyleSheet(
                "color: #38bdf8; background-color: rgba(56, 189, 248, 0.16); "
                "border: 1px solid rgba(56, 189, 248, 0.45); border-radius: 5px; "
                "padding: 1px 7px; font-size: 10px; font-weight: 800;"
            )
        self.type_badge.setFixedHeight(20)
        title_row.addWidget(self.type_badge)

        self.discount_badge = QLabel("-100%")
        self.discount_badge.setStyleSheet(
            "color: #052e16; background-color: #2ed573; border-radius: 5px; "
            "padding: 1px 7px; font-size: 10px; font-weight: 800;"
        )
        self.discount_badge.setFixedHeight(20)
        title_row.addWidget(self.discount_badge)

        self.title_lbl = QLabel(str(self.item.get("title") or f"App {self.item.get('appid')}"))
        self.title_lbl.setStyleSheet("color: #f8fafc; font-size: 14px; font-weight: 700;")
        self.title_lbl.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        title_row.addWidget(self.title_lbl, 1)
        mid.addLayout(title_row)

        orig_price = str(self.item.get("original_price") or "").strip()
        base_name = str(self.item.get("base_game_name") or "").strip()
        price_parts: list[str] = []
        if orig_price:
            price_parts.append(
                f'<span style="color:#64748b; text-decoration:line-through;">{orig_price}</span>'
                ' &nbsp;<span style="color:#2ed573; font-weight:700;">0đ (Giữ vĩnh viễn)</span>'
            )
        else:
            price_parts.append('<span style="color:#2ed573; font-weight:700;">0đ (Khuyến mãi 100% · Giữ vĩnh viễn)</span>')
        if is_dlc and base_name:
            price_parts.append(f'<span style="color:#94a3b8;"> · Cần game gốc: {base_name}</span>')

        self.price_lbl = QLabel("".join(price_parts))
        self.price_lbl.setTextFormat(Qt.TextFormat.RichText)
        self.price_lbl.setStyleSheet("font-size: 12px;")
        mid.addWidget(self.price_lbl)

        self.state_lbl = QLabel("")
        self.state_lbl.setWordWrap(True)
        mid.addWidget(self.state_lbl)
        mid.addStretch(1)
        row.addLayout(mid, 1)

        # Right action buttons
        actions = QHBoxLayout()
        actions.setSpacing(8)

        self.claim_btn = make_button("Nhận ngay", GREEN_BTN_STYLE + _MUTED_DISABLED_RULE, "plus")
        self.claim_btn.clicked.connect(lambda: self.claim_requested.emit(self.item))
        actions.addWidget(self.claim_btn)

        self.open_btn = make_button("Mở Steam", DARK_BTN_STYLE, "steam")
        self.open_btn.setToolTip("Mở trang trò chơi trên Steam Store")
        self.open_btn.clicked.connect(lambda: self.open_requested.emit(self.item))
        actions.addWidget(self.open_btn)

        row.addLayout(actions)
        self.refresh_state()

    def set_banner_pixmap(self, pix: QPixmap | None):
        if pix is not None and not pix.isNull():
            self.thumb_lbl.setStyleSheet("background: transparent; border: none;")
            self.thumb_lbl.setPixmap(pix)

    def set_claiming(self, busy: bool):
        if busy:
            self.claim_btn.setEnabled(False)
            self.claim_btn.setStyleSheet(DARK_BTN_STYLE + _MUTED_DISABLED_RULE)
            self.claim_btn.setText("Đang nhận...")
            self.state_lbl.setText("Đang gửi yêu cầu nhận miễn phí vào tài khoản Steam...")
            self.state_lbl.setStyleSheet(f"color: {STATUS_COLORS['busy']}; font-size: 11px;")
        else:
            self.refresh_state()

    def update_status(self, new_status: str, custom_note: str = ""):
        self.item["status"] = new_status
        self.refresh_state(custom_note=custom_note)

    def refresh_state(self, custom_note: str = ""):
        status = str(self.item.get("status") or "available")
        if status == "claimed":
            self.claim_btn.setStyleSheet(DARK_BTN_STYLE + _MUTED_DISABLED_RULE)
            self.claim_btn.setText("Đã nhận")
            self.claim_btn.setEnabled(False)
            note = custom_note or "Đã tự động thêm vĩnh viễn vào tài khoản Steam."
            self.state_lbl.setText(note)
            self.state_lbl.setStyleSheet(f"color: {STATUS_COLORS['ok']}; font-size: 11px; font-weight: 600;")
        elif status == "owned":
            self.claim_btn.setStyleSheet(DARK_BTN_STYLE + _MUTED_DISABLED_RULE)
            self.claim_btn.setText("Đã sở hữu")
            self.claim_btn.setEnabled(False)
            note = custom_note or "Tài khoản Steam của bạn đã sở hữu mục này."
            self.state_lbl.setText(note)
            self.state_lbl.setStyleSheet(f"color: {STATUS_COLORS['ok']}; font-size: 11px;")
        elif status == "missing_base":
            self.claim_btn.setStyleSheet(DARK_BTN_STYLE + _MUTED_DISABLED_RULE)
            self.claim_btn.setText("Thiếu game gốc")
            self.claim_btn.setEnabled(False)
            note = custom_note or "Không thể tự nhận DLC do tài khoản Steam chưa sở hữu game gốc."
            self.state_lbl.setText(note)
            self.state_lbl.setStyleSheet(f"color: {STATUS_COLORS['warn']}; font-size: 11px;")
        else:
            self.claim_btn.setStyleSheet(GREEN_BTN_STYLE + _MUTED_DISABLED_RULE)
            self.claim_btn.setText("Nhận ngay")
            self.claim_btn.setEnabled(True)
            note = custom_note or "Đang miễn phí 100% trên Steam — bấm 'Nhận ngay' để thêm vào tài khoản."
            self.state_lbl.setText(note)
            self.state_lbl.setStyleSheet(f"color: {STATUS_COLORS['info']}; font-size: 11px;")


class SteamFreeScreen(QWidget):
    """Full-screen KHO GAME sub-view listing active 100%-off Steam games & DLCs."""

    back_requested = Signal()
    promos_updated = Signal(dict)  # result payload from fetch_active_free_promos

    def __init__(self, config: dict, parent=None, auto_load: bool | None = None):
        super().__init__(parent)
        self.setObjectName("steamFreeScreen")
        self.config = config
        self._items: list[dict] = []
        self._cards_by_appid: dict[int, _PromoItemCard] = {}
        self._banner_cache: dict[str, QPixmap] = {}
        self._request_id = 0
        self._scanning = False
        self._scan_task: Task | None = None

        self._setup_ui()
        self.sync_config(config)
        logger.info(f"{TAG} Screen created")

        should_load = (
            (os.environ.get("BOBGAMING_FREEKEEP_DISABLE") != "1")
            if auto_load is None
            else bool(auto_load)
        )
        if should_load:
            QTimer.singleShot(0, self.refresh_promos)

    def deleteLater(self):
        self._request_id += 1
        super().deleteLater()

    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.header = ScreenHeader(
            "Steam Miễn Phí 100%",
            "gift",
            subtitle=(
                "Danh sách Game & DLC có phí đang giảm 100% về 0đ (giữ vĩnh viễn) trên Steam — "
                "không bao gồm game Free-to-Play"
            ),
        )
        self.header.back_requested.connect(self._on_back)
        self.auto_badge = self.header.add_badge("TỰ ĐỘNG NHẬN: ĐANG BẬT", "ok")
        self.scan_btn = self.header.add_button(
            "Quét ngay",
            "primary",
            icon="refresh",
            tooltip="Kiểm tra trực tiếp các Game và DLC đang miễn phí 100% trên Steam Store",
        )
        self.scan_btn.clicked.connect(self._on_manual_scan)
        root.addWidget(self.header)

        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(*CONTENT_MARGINS)
        lay.setSpacing(14)

        # Status / Monitor Banner
        info_card = QFrame()
        info_card.setObjectName("steamFreeStatusBar")
        info_card.setStyleSheet("""
            #steamFreeStatusBar {
                background-color: rgba(15, 21, 34, 0.72);
                border: 1px solid rgba(255, 255, 255, 0.07);
                border-radius: 10px;
            }
            #steamFreeStatusBar QLabel { background: transparent; border: none; }
        """)
        info_lay = QHBoxLayout(info_card)
        info_lay.setContentsMargins(14, 10, 14, 10)
        info_lay.setSpacing(10)

        self.inline_spinner = SpinningLoader(size=16, line_width=2, color="#38bdf8", parent=info_card)
        self.inline_spinner.hide()
        info_lay.addWidget(self.inline_spinner)

        self.status_label = QLabel("Nhấn 'Quét ngay' để kiểm tra khuyến mãi miễn phí 100% trên Steam.")
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet(f"color: {STATUS_COLORS['info']}; font-size: 12px;")
        info_lay.addWidget(self.status_label, 1)

        self.steam_conn_lbl = QLabel("Steam Desktop: Chưa kiểm tra")
        self.steam_conn_lbl.setStyleSheet(
            "color: #94a3b8; background-color: rgba(148, 163, 184, 0.12); "
            "border: 1px solid rgba(148, 163, 184, 0.25); border-radius: 7px; "
            "padding: 3px 10px; font-size: 11px; font-weight: 700;"
        )
        info_lay.addWidget(self.steam_conn_lbl)
        lay.addWidget(info_card)

        # Content stack: 0 = loading, 1 = empty / notice, 2 = list of promos
        self.stack = QStackedWidget()

        # Page 0: Loading
        loading_page = QWidget()
        loading_lay = QVBoxLayout(loading_page)
        loading_lay.setContentsMargins(0, 48, 0, 48)
        loading_lay.setSpacing(12)
        loading_lay.addStretch()
        self.center_spinner = SpinningLoader(size=42, line_width=4, color="#8b5cf6", parent=loading_page)
        loading_lay.addWidget(self.center_spinner, 0, Qt.AlignmentFlag.AlignCenter)
        load_title = QLabel("Đang quét khuyến mãi miễn phí 100% trên Steam Store...")
        load_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        load_title.setStyleSheet("color: #f1f5f9; font-size: 14px; font-weight: 700; background: transparent;")
        loading_lay.addWidget(load_title)
        load_sub = QLabel("Đang đối chiếu danh sách giảm giá -100% và kiểm tra quyền sở hữu tài khoản Steam")
        load_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        load_sub.setStyleSheet("color: #64748b; font-size: 12px; background: transparent;")
        loading_lay.addWidget(load_sub)
        loading_lay.addStretch()
        self.stack.addWidget(loading_page)

        # Page 1: Empty / Error State
        empty_page = QWidget()
        empty_outer = QVBoxLayout(empty_page)
        empty_outer.setContentsMargins(0, 24, 0, 24)
        empty_outer.addStretch()

        empty_card = QFrame()
        empty_card.setObjectName("steamFreeEmptyCard")
        empty_card.setMaximumWidth(640)
        empty_card.setStyleSheet("""
            #steamFreeEmptyCard {
                background-color: rgba(15, 21, 34, 0.78);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 16px;
            }
            #steamFreeEmptyCard QLabel { background: transparent; border: none; }
        """)
        ec_lay = QVBoxLayout(empty_card)
        ec_lay.setContentsMargins(36, 36, 36, 36)
        ec_lay.setSpacing(12)

        self.empty_icon = QLabel()
        self.empty_icon.setFixedSize(48, 48)
        self.empty_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_icon.setPixmap(make_svg_pixmap("gift", size=40, color="#8b5cf6"))
        ec_lay.addWidget(self.empty_icon, 0, Qt.AlignmentFlag.AlignCenter)

        self.empty_title_lbl = QLabel("Hiện không có game nào đang miễn phí, kiểm tra lại sau")
        self.empty_title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_title_lbl.setWordWrap(True)
        self.empty_title_lbl.setStyleSheet("color: #f8fafc; font-size: 16px; font-weight: 700;")
        ec_lay.addWidget(self.empty_title_lbl)

        self.empty_desc_lbl = QLabel(
            "Hiện không có Game hoặc DLC trả phí nào đang chạy chương trình giảm 100% về 0đ trên Steam. "
            "Tính năng tự động quét vẫn đang hoạt động ngầm mỗi 1 giờ — vui lòng kiểm tra lại sau."
        )
        self.empty_desc_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_desc_lbl.setWordWrap(True)
        self.empty_desc_lbl.setStyleSheet("color: #94a3b8; font-size: 13px;")
        ec_lay.addWidget(self.empty_desc_lbl)

        ec_lay.addSpacing(6)
        self.empty_retry_btn = make_button("Kiểm tra lại ngay", PURPLE_BTN_STYLE, "refresh")
        self.empty_retry_btn.clicked.connect(self._on_manual_scan)
        ec_lay.addWidget(self.empty_retry_btn, 0, Qt.AlignmentFlag.AlignCenter)

        empty_row = QHBoxLayout()
        empty_row.addStretch()
        empty_row.addWidget(empty_card, 1)
        empty_row.addStretch()
        empty_outer.addLayout(empty_row)
        empty_outer.addStretch()
        self.stack.addWidget(empty_page)

        # Page 2: Scrollable list of active 100%-off games & DLCs
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        self.list_container = QWidget()
        self.list_container.setStyleSheet("background: transparent;")
        self.list_layout = QVBoxLayout(self.list_container)
        self.list_layout.setContentsMargins(0, 0, 4, 8)
        self.list_layout.setSpacing(10)
        self.list_layout.addStretch(1)
        self.scroll.setWidget(self.list_container)
        self.stack.addWidget(self.scroll)

        self.stack.setCurrentIndex(1)
        lay.addWidget(self.stack, 1)
        root.addWidget(body, 1)

    def sync_config(self, config: dict):
        self.config = config
        enabled = bool(config.get("auto_claim_steam_free_games", True))
        if enabled:
            self.auto_badge.set_state("TỰ ĐỘNG NHẬN: ĐANG BẬT", "ok")
        else:
            self.auto_badge.set_state("TỰ ĐỘNG NHẬN: ĐANG TẮT", "off")

    def _set_status(self, text: str, kind: str = "info"):
        self.status_label.setText(text)
        self.status_label.setStyleSheet(f"color: {STATUS_COLORS[kind]}; font-size: 12px;")

    def _set_steam_connected_pill(self, connected: bool):
        if connected:
            self.steam_conn_lbl.setText("Steam Desktop: Đã kết nối")
            self.steam_conn_lbl.setStyleSheet(
                "color: #2ed573; background-color: rgba(46, 213, 115, 0.14); "
                "border: 1px solid rgba(46, 213, 115, 0.45); border-radius: 7px; "
                "padding: 3px 10px; font-size: 11px; font-weight: 700;"
            )
        else:
            self.steam_conn_lbl.setText("Steam Desktop: Chế độ xem")
            self.steam_conn_lbl.setStyleSheet(
                "color: #e3b341; background-color: rgba(210, 153, 34, 0.15); "
                "border: 1px solid rgba(210, 153, 34, 0.45); border-radius: 7px; "
                "padding: 3px 10px; font-size: 11px; font-weight: 700;"
            )

    @_safe_slot
    def _on_back(self):
        self.back_requested.emit()

    @_safe_slot
    def _on_manual_scan(self):
        logger.info(f"{TAG} User clicked manual scan button")
        self.refresh_promos()

    @_safe_slot
    def refresh_promos(self):
        if self._scanning:
            return
        self.sync_config(self.config)
        self._scanning = True
        self._request_id += 1
        req_id = self._request_id

        self.scan_btn.setEnabled(False)
        self.empty_retry_btn.setEnabled(False)
        self.inline_spinner.start()
        self._set_status("Đang quét danh sách Game & DLC miễn phí 100% trên Steam Store...", "busy")

        if not self._items:
            self.center_spinner.start()
            self.stack.setCurrentIndex(0)

        auto_claim = bool(self.config.get("auto_claim_steam_free_games", True))
        task = Task(
            lambda: steam_free_keep.fetch_active_free_promos(auto_claim=auto_claim),
            label="steam-free-list",
        )
        self._scan_task = task
        task.done.connect(lambda result, err, r=req_id: self._on_promos_loaded(r, result, err))
        task.start_tracked()

    @_safe_slot
    def _on_promos_loaded(self, req_id: int, result: object, error: str):
        if req_id != self._request_id:
            return
        self._scanning = False
        self.scan_btn.setEnabled(True)
        self.empty_retry_btn.setEnabled(True)
        self.inline_spinner.stop()
        self.center_spinner.stop()

        if error or not isinstance(result, dict):
            msg = error or "Không đọc được dữ liệu từ Steam Store."
            logger.warning(f"{TAG} Promo scan returned error: {msg}")
            self._show_empty_or_error(is_error=True, detail=msg)
            self._set_status(f"Lỗi kiểm tra Steam Store: {msg}", "error")
            return

        steam_connected = bool(result.get("steam_connected"))
        self._set_steam_connected_pill(steam_connected)

        if result.get("network_error"):
            self._show_empty_or_error(
                is_error=True,
                detail="Không thể kết nối tới Steam Store. Vui lòng kiểm tra kết nối mạng và bấm 'Kiểm tra lại ngay'.",
            )
            self._set_status("Không kết nối được tới Steam Store. Vui lòng thử lại sau.", "error")
            return

        items = list(result.get("items") or [])
        checked_at = str(result.get("checked_at") or "")
        claimed = list(result.get("claimed") or [])
        self._items = items
        self._rebuild_cards(items)

        auto_on = bool(self.config.get("auto_claim_steam_free_games", True))
        mode_note = "Tự động quét ngầm mỗi 1 giờ đang BẬT" if auto_on else "Tự động nhận đang TẮT trong Cài đặt"
        time_prefix = f"Kiểm tra lúc {checked_at} · " if checked_at else ""

        if not items:
            self._show_empty_or_error(is_error=False)
            self._set_status(
                f"{time_prefix}Không có Game hoặc DLC trả phí nào đang miễn phí 100% ({mode_note}).",
                "info",
            )
        else:
            self.stack.setCurrentIndex(2)
            games_cnt = sum(1 for x in items if x.get("item_type") != "dlc")
            dlc_cnt = sum(1 for x in items if x.get("item_type") == "dlc")
            summary = f"{games_cnt} Game, {dlc_cnt} DLC" if dlc_cnt else f"{games_cnt} Game"
            if claimed:
                self._set_status(
                    f"{time_prefix}Đang có {summary} miễn phí 100% — vừa tự động nhận {len(claimed)} mục mới!",
                    "ok",
                )
            else:
                self._set_status(
                    f"{time_prefix}Đang có {summary} giảm 100% về 0đ trên Steam ({mode_note}).",
                    "ok",
                )

        self.promos_updated.emit(result)

    def _show_empty_or_error(self, is_error: bool, detail: str = ""):
        auto_on = bool(self.config.get("auto_claim_steam_free_games", True))
        if is_error:
            self.empty_icon.setPixmap(make_svg_pixmap("alert", size=40, color="#f87171"))
            self.empty_title_lbl.setText("Không thể kiểm tra khuyến mãi Steam lúc này")
            self.empty_desc_lbl.setText(detail or "Vui lòng kiểm tra kết nối mạng và thử lại sau.")
        else:
            self.empty_icon.setPixmap(make_svg_pixmap("gift", size=40, color="#8b5cf6"))
            self.empty_title_lbl.setText("Hiện không có game nào đang miễn phí, kiểm tra lại sau")
            if auto_on:
                self.empty_desc_lbl.setText(
                    "Hiện không có Game hoặc DLC trả phí nào đang giảm 100% về 0đ trên Steam. "
                    "Tính năng tự động nhận vẫn đang hoạt động ngầm mỗi 1 giờ — vui lòng kiểm tra lại sau."
                )
            else:
                self.empty_desc_lbl.setText(
                    "Hiện không có Game hoặc DLC trả phí nào đang giảm 100% về 0đ trên Steam. "
                    "Vui lòng kiểm tra lại sau (bạn có thể bật tự động nhận ngầm trong mục Cài đặt)."
                )
        self.stack.setCurrentIndex(1)

    def _rebuild_cards(self, items: list[dict]):
        for old_card in self._cards_by_appid.values():
            if isValid(old_card):
                old_card.hide()
                old_card.deleteLater()
        self._cards_by_appid.clear()

        while self.list_layout.count() > 1:
            li = self.list_layout.takeAt(0)
            w = li.widget()
            if w is not None and isValid(w):
                w.deleteLater()

        for idx, item in enumerate(items):
            appid = int(item.get("appid") or 0)
            card = _PromoItemCard(item, self.list_container)
            card.claim_requested.connect(self._on_claim_item)
            card.open_requested.connect(self._on_open_item)
            self._cards_by_appid[appid] = card
            self.list_layout.insertWidget(idx, card)

            banner_url = str(item.get("header_image") or "").strip()
            if banner_url:
                cached = self._banner_cache.get(banner_url)
                if cached is not None and not cached.isNull():
                    card.set_banner_pixmap(cached)
                else:
                    self._load_banner_async(appid, banner_url)

    def _load_banner_async(self, appid: int, url: str):
        def _work():
            raw = steam_free_keep.fetch_banner_bytes(url)
            if not raw:
                return None
            return render_rounded_image(raw, _PromoItemCard.THUMB_W, _PromoItemCard.THUMB_H, 8, top_only=False)

        t = Task(_work, label=f"steam-free-banner-{appid}")
        t.done.connect(lambda img, _err, a=appid, u=url: self._on_banner_ready(a, u, img))
        t.start_tracked()

    @_safe_slot
    def _on_banner_ready(self, appid: int, url: str, img: object):
        if img is None:
            return
        pix = QPixmap.fromImage(img)
        if pix.isNull():
            return
        self._banner_cache[url] = pix
        card = self._cards_by_appid.get(appid)
        if card is not None and isValid(card):
            card.set_banner_pixmap(pix)

    @_safe_slot
    def _on_claim_item(self, item: dict):
        appid = int(item.get("appid") or 0)
        subid = int(item.get("subid") or 0)
        title = str(item.get("title") or f"App {appid}")
        item_type = str(item.get("item_type") or "game")
        card = self._cards_by_appid.get(appid)
        if card is not None and isValid(card):
            card.set_claiming(True)

        logger.info(f"{TAG} User clicked claim on {title!r} (appid={appid})")
        t = Task(
            lambda: steam_free_keep.claim_single_promo(
                appid=appid, subid=subid, title=title, item_type=item_type
            ),
            label=f"steam-free-claim-{appid}",
        )
        t.done.connect(lambda res, err, a=appid: self._on_claim_finished(a, res, err))
        t.start_tracked()

    @_safe_slot
    def _on_claim_finished(self, appid: int, res: object, err: str):
        card = self._cards_by_appid.get(appid)
        if err or not isinstance(res, dict):
            msg = err or "Không thể thực hiện yêu cầu nhận game."
            if card is not None and isValid(card):
                card.set_claiming(False)
            self._set_status(msg, "error")
            return

        outcome = str(res.get("outcome") or "")
        msg = str(res.get("message") or "")
        if res.get("ok"):
            self._set_steam_connected_pill(True)
            new_state = "claimed" if outcome == "claimed" else "owned"
            if card is not None and isValid(card):
                card.update_status(new_state, custom_note=msg)
            self._set_status(msg, "ok")
        elif outcome == "missing_base":
            if card is not None and isValid(card):
                card.update_status("missing_base", custom_note=msg)
            self._set_status(msg, "warn")
        else:
            if card is not None and isValid(card):
                card.set_claiming(False)
            self._set_status(msg, "warn")

    @_safe_slot
    def _on_open_item(self, item: dict):
        appid = int(item.get("appid") or 0)
        store_url = str(item.get("store_url") or "")
        title = str(item.get("title") or f"App {appid}")
        logger.info(f"{TAG} User opened Steam Store page for {title!r} (appid={appid})")
        _allow_foreground_handoff()
        t = Task(
            lambda: open_steam_store_page(appid, store_url),
            label=f"steam-free-open-{appid}",
        )
        t.done.connect(lambda ok, err, ttl=title: self._on_open_finished(ttl, ok, err))
        t.start_tracked()

    @_safe_slot
    def _on_open_finished(self, title: str, ok: object, err: str):
        if err or not ok:
            logger.warning(f"{TAG} Could not open Steam Store page for {title!r}: {err or 'open returned False'}")
            self._set_status(f'Không thể mở trang Steam cho "{title}".', "warn")
