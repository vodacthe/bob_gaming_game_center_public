"""
Shared plumbing for the Online-Fix screens: slot guard, tracked worker thread, poster loader and the few styles
the screen header does not cover. Widgets only ever touch Qt objects on the UI thread; workers hand results back
through queued signals.
"""

import functools
import inspect
import logging
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor

from PySide6.QtCore import QBuffer, QIODevice, QObject, QRectF, QSize, QThread, QTimer, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QImage, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import QApplication, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QWidget

from shiboken6 import isValid

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/UI]"


def safe_slot(func):
    """Slot guard: an exception in a handler is logged, never reaches Qt's event loop (where it could abort the app).
    Extra signal arguments (clicked(bool), ...) are dropped."""
    params = list(inspect.signature(func).parameters.values())[1:]
    accepts_varargs = any(p.kind is inspect.Parameter.VAR_POSITIONAL for p in params)
    max_args = len([p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if not accepts_varargs:
            args = args[:max_args]
        try:
            if not isValid(self):
                return None
            return func(self, *args, **kwargs)
        except Exception:   # noqa: BLE001 - see docstring
            logger.exception(f"{TAG} {type(self).__name__}.{func.__name__} failed")
            return None
    return wrapper


# ------------------------------------------------------------------ worker thread

_running: set = set()       # strong refs: a QThread must outlive the widget that started it
_running_lock = threading.Lock()
_quit_hooked = False


def _stop_all_on_quit():
    with _running_lock:
        tasks = list(_running)
    for t in tasks:
        if not t.wait(3000):
            logger.warning(f"{TAG} task {t.label!r} still running at exit")


class Task(QThread):
    """Run fn() off the UI thread; emits done(result, error_text). Expected errors (expected_errors) become the
    error text as-is; anything else is logged with a traceback. Never raises."""

    done = Signal(object, str)

    def __init__(self, fn, label: str, expected_errors: tuple = ()):
        super().__init__(None)                  # no parent: deleting the screen must not destroy a running thread
        self.label = label
        self._fn = fn
        self._expected = expected_errors
        self.setObjectName(f"onlinefix-{label}")

    def start_tracked(self):
        global _quit_hooked
        app = QApplication.instance()
        if app is not None and not _quit_hooked:
            app.aboutToQuit.connect(_stop_all_on_quit)
            _quit_hooked = True
        with _running_lock:
            _running.add(self)
        self.finished.connect(self._forget)
        self.start()

    def _forget(self):
        with _running_lock:
            _running.discard(self)

    def run(self):
        started = time.monotonic()
        result, error = None, ""
        try:
            result = self._fn()
        except self._expected as e:
            error = str(e) or e.__class__.__name__
        except Exception as e:   # noqa: BLE001 - surfaced to the user instead of killing the thread silently
            logger.exception(f"{TAG} task {self.label!r} crashed")
            error = f"Lỗi không mong muốn: {e}"
        logger.debug(f"{TAG} task {self.label!r} done in {time.monotonic() - started:.2f}s"
                     + (f" (error: {error})" if error else ""))
        try:
            self.done.emit(result, error)
        except Exception:   # noqa: BLE001 - the receiver may already be gone
            logger.exception(f"{TAG} task {self.label!r}: could not deliver the result")


# ------------------------------------------------------------------ posters

CARD_POSTER_W = 188
CARD_POSTER_H = 248
CARD_POSTER_RADIUS = 14


def render_rounded_image(
    data: bytes, width: int, height: int, radius: int, top_only: bool = False
) -> QImage | None:
    """Thread-safe off-UI-thread QImage decode, smooth scale-to-fill, and rounded corner clip."""
    if not data:
        return None
    src = QImage.fromData(data)
    if src.isNull():
        return None
    scaled = src.scaled(
        width,
        height,
        Qt.AspectRatioMode.KeepAspectRatioByExpanding,
        Qt.TransformationMode.SmoothTransformation,
    )
    x = max(0, (scaled.width() - width) // 2)
    y = max(0, (scaled.height() - height) // 2)
    out = QImage(width, height, QImage.Format.Format_ARGB32_Premultiplied)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    path = QPainterPath()
    if top_only:
        path.addRoundedRect(QRectF(0, 0, width, height + radius), radius, radius)
    else:
        path.addRoundedRect(QRectF(0, 0, width, height), radius, radius)
    p.setClipPath(path)
    p.drawImage(0, 0, scaled, x, y, width, height)
    # Wide landscape provider banners (e.g. SteamRIP 460x215): draw full uncropped banner over darkened ambient backdrop
    if height > width and src.width() > src.height() * 1.25:
        p.fillRect(0, 0, width, height, QColor(11, 15, 25, 190))
        fitted = src.scaled(width, height, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        fx = (width - fitted.width()) // 2
        fy = (height - fitted.height()) // 2
        p.drawImage(fx, fy, fitted)
    p.end()
    return out


class PosterLoader(QObject):
    """Downloads & pre-renders poster QImages on a worker pool; `loaded(url, bytes)` fires on the UI thread.
    `card_pixmap(url)` converts pre-rendered QImage -> QPixmap once on the UI thread and caches it across cards."""

    loaded = Signal(str, bytes)
    MAX_CACHE = 400

    def __init__(self, fetch):
        super().__init__(QApplication.instance())
        self._fetch = fetch
        self._pool = ThreadPoolExecutor(max_workers=8, thread_name_prefix="onlinefix-poster")
        self._cache: OrderedDict[str, bytes] = OrderedDict()
        self._card_images: OrderedDict[str, QImage] = OrderedDict()
        self._card_pixmaps: OrderedDict[str, QPixmap] = OrderedDict()
        self._pending: set[str] = set()
        self._failed: set[str] = set()
        self._lock = threading.Lock()
        self._failures = 0
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(lambda: self._pool.shutdown(wait=False, cancel_futures=True))

    def has_failed(self, url: str) -> bool:
        if not url:
            return False
        with self._lock:
            return url in self._failed

    def cached(self, url: str) -> bytes | None:
        with self._lock:
            data = self._cache.get(url)
            if data is not None:
                self._cache.move_to_end(url)
            return data

    def card_pixmap(self, url: str) -> QPixmap | None:
        """Return cached UI-thread QPixmap for a 188x248 game card (zero PNG decode or scale on UI thread)."""
        if not url:
            return None
        pix = self._card_pixmaps.get(url)
        if pix is not None and not pix.isNull():
            self._card_pixmaps.move_to_end(url)
            return pix
        with self._lock:
            img = self._card_images.get(url)
            if img is not None:
                self._card_images.move_to_end(url)
            raw = self._cache.get(url) if img is None else None
        if img is None and raw:
            img = render_rounded_image(
                raw, CARD_POSTER_W, CARD_POSTER_H, CARD_POSTER_RADIUS, top_only=True
            )
        if img is None or img.isNull():
            return None
        pix = QPixmap.fromImage(img)
        if pix.isNull():
            return None
        self._card_pixmaps[url] = pix
        while len(self._card_pixmaps) > self.MAX_CACHE:
            self._card_pixmaps.popitem(last=False)
        return pix

    def request(self, url: str):
        if not url:
            return
        with self._lock:
            if url in self._cache or url in self._pending or url in self._failed:
                return
            self._pending.add(url)
        try:
            self._pool.submit(self._work, url)
        except RuntimeError:            # pool shut down (app exiting)
            with self._lock:
                self._pending.discard(url)

    def _work(self, url: str):
        from app.core.online_fix.store_cache import (
            load_cached_poster_bytes,
            load_cached_poster_thumb_bytes,
            save_cached_poster_bytes,
            save_cached_poster_thumb_bytes,
        )

        card_img: QImage | None = None
        thumb_bytes = load_cached_poster_thumb_bytes(url)
        if thumb_bytes is not None:
            loaded_thumb = QImage.fromData(thumb_bytes)
            if not loaded_thumb.isNull():
                card_img = loaded_thumb

        data = load_cached_poster_bytes(url)
        if data is None and thumb_bytes is not None and card_img is not None:
            data = thumb_bytes
        if data is None:
            try:
                data = self._fetch(url)
            except Exception as e:   # noqa: BLE001 - notify waiters with empty bytes so provider fallback runs
                with self._lock:
                    self._pending.discard(url)
                    self._failed.add(url)
                    self._failures += 1
                    failures = self._failures
                if failures <= 3 or failures % 25 == 0:      # don't flood the log when the CDN is down
                    logger.warning(f"{TAG} Poster download failed ({failures} so far): {e} ({url})")
                try:
                    self.loaded.emit(url, b"")
                except RuntimeError:
                    pass
                return
            save_cached_poster_bytes(url, data)

        if card_img is None and data:
            card_img = render_rounded_image(
                data, CARD_POSTER_W, CARD_POSTER_H, CARD_POSTER_RADIUS, top_only=True
            )
            if card_img is not None and not card_img.isNull():
                buf = QBuffer()
                if buf.open(QIODevice.OpenModeFlag.WriteOnly):
                    if card_img.save(buf, "PNG"):
                        save_cached_poster_thumb_bytes(url, bytes(buf.data()))
                    buf.close()

        valid_img = card_img is not None and not card_img.isNull()
        with self._lock:
            self._pending.discard(url)
            if valid_img and data:
                self._cache[url] = data
                while len(self._cache) > self.MAX_CACHE:
                    self._cache.popitem(last=False)
                self._card_images[url] = card_img
                while len(self._card_images) > self.MAX_CACHE:
                    self._card_images.popitem(last=False)
            else:
                self._failed.add(url)
        try:
            self.loaded.emit(url, data if valid_img else b"")
        except RuntimeError:
            pass


_poster_loader: PosterLoader | None = None


def poster_loader(fetch) -> PosterLoader:
    global _poster_loader
    if _poster_loader is None or not isValid(_poster_loader):
        _poster_loader = PosterLoader(fetch)
    return _poster_loader


def rounded_cover(data: bytes, width: int, height: int, radius: int, top_only: bool = False) -> QPixmap | None:
    """Scale-to-fill and round the corners of an image (UI thread only). None when the bytes are not an image."""
    img = render_rounded_image(data, width, height, radius, top_only=top_only)
    return QPixmap.fromImage(img) if img is not None else None


# ------------------------------------------------------------------ buttons

class FitButton(QPushButton):
    """Button whose size hint is measured with the bold stylesheet font + padding + icon, so a Fixed-width button
    never clips its text (QPushButton measures with the default font and ignores stylesheet padding)."""

    def __init__(self, text: str, font_px: int = 12, height: int = 32, parent=None):
        super().__init__(text, parent)
        self._font_px, self._height = font_px, height

    def sizeHint(self):
        font = QFont("Segoe UI")
        font.setPixelSize(self._font_px)
        font.setBold(True)
        icon_w = (self.iconSize().width() + 8) if not self.icon().isNull() else 0
        return QSize(QFontMetrics(font).horizontalAdvance(self.text()) + icon_w + 34, self._height)

    def minimumSizeHint(self):
        return self.sizeHint()

    def setText(self, text: str):
        super().setText(text)
        self.updateGeometry()


def make_button(text: str, style: str, icon: str = "", small: bool = False, icon_color: str = "#ffffff") -> QPushButton:
    """Body button in one of the app's styles (game_card.*_BTN_STYLE) with an SVG icon, sized to its text."""
    from app.ui.icons import make_svg_icon
    btn = FitButton(text, font_px=11 if small else 12, height=26 if small else 32)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    btn.setStyleSheet(style + ("QPushButton { height: 26px; min-height: 26px; max-height: 26px; font-size: 11px; }"
                               if small else ""))
    if icon:
        size = 13 if small else 14
        btn.setIcon(make_svg_icon(icon, size=size, normal_color=icon_color))
        btn.setIconSize(QSize(size, size))
    btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
    return btn


_clipboard_seq = 0


def copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard on the UI thread, retrying briefly if Windows Clipboard History holds OpenClipboard."""
    global _clipboard_seq
    _clipboard_seq += 1
    seq = _clipboard_seq
    cb = QApplication.clipboard()
    if cb is None:
        return False
    cb.setText(text)
    if cb.text() == text:
        return True
    for attempt in range(1, 4):
        QTimer.singleShot(35 * attempt, lambda t=text, s=seq: _retry_clipboard_set(t, s))
    return False


def _retry_clipboard_set(text: str, seq: int) -> None:
    if seq != _clipboard_seq:
        return
    cb = QApplication.clipboard()
    if cb is not None and cb.text() != text:
        cb.setText(text)


# ------------------------------------------------------------------ styles

INPUT_STYLE = """
    QLineEdit {
        background-color: rgba(18, 22, 34, 0.8); border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 8px; padding: 0 12px; color: #ffffff; font-size: 13px;
    }
    QLineEdit:focus { border-color: #8b5cf6; }
"""

COMBO_STYLE = """
    QComboBox {
        background-color: rgba(18, 22, 34, 0.8); border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 8px; padding: 0 12px; color: #ffffff; font-size: 13px; min-height: 34px;
    }
    QComboBox:focus { border-color: #8b5cf6; }
    QComboBox::drop-down { border: none; width: 24px; }
    QComboBox QAbstractItemView {
        background-color: #121826; color: #e2e8f0; border: 1px solid rgba(255, 255, 255, 0.1);
        selection-background-color: rgba(139, 92, 246, 0.35);
    }
"""

CHECKBOX_STYLE = "QCheckBox { color: #cbd5e1; font-size: 12px; spacing: 8px; }"

STATUS_COLORS = {"info": "#94a3b8", "busy": "#38bdf8", "ok": "#2ed573", "warn": "#e3b341", "error": "#f87171"}


def progress_style(color: str) -> str:
    return (
        "QProgressBar { background-color: rgba(255, 255, 255, 0.06); border: none; border-radius: 3px; }"
        f"QProgressBar::chunk {{ background-color: {color}; border-radius: 3px; }}"
    )


def source_display_name(source: str) -> str:
    if source == "fitgirl":
        return "FitGirl Repacks"
    if source == "steamrip":
        return "SteamRIP"
    if source == "ankergames": return "AnkerGames"
    return "Online-Fix.me"


_BADGE_ICON_PIXMAPS: dict[tuple[str, str], QPixmap] = {}


def _badge_icon_pixmap(icon_name: str, color: str) -> QPixmap:
    key = (icon_name, color)
    pix = _BADGE_ICON_PIXMAPS.get(key)
    if pix is None or pix.isNull():
        from app.ui.icons import make_svg_pixmap
        pix = make_svg_pixmap(icon_name, size=11, color=color)
        _BADGE_ICON_PIXMAPS[key] = pix
    return pix


def source_theme(source: str) -> tuple[str, str, str, str, str, str]:
    """Return (bg, border, fg, icon_name, full_label, short_label) for a store source."""
    if source == "fitgirl":
        return ("rgba(28, 12, 20, 0.88)", "rgba(244, 63, 94, 0.65)", "#fb7185", "package", "FITGIRL", "FG")
    if source == "steamrip":
        return ("rgba(28, 20, 10, 0.88)", "rgba(245, 158, 11, 0.68)", "#fbbf24", "steam", "STEAMRIP", "SR")
    if source == "ankergames": return ("rgba(10, 28, 24, 0.88)", "rgba(16, 185, 129, 0.68)", "#34d399", "bolt", "ANKERGAMES", "AG")
    return ("rgba(12, 22, 36, 0.88)", "rgba(56, 189, 248, 0.60)", "#38bdf8", "users", "ONLINE-FIX", "OF")


class SourceBadge(QWidget):
    """Compact vector icon + text pill identifying a game's store source (Online-Fix, FitGirl, or SteamRIP)."""

    def __init__(self, source: str, parent=None, compact: bool = False):
        super().__init__(parent)
        self.source = source or "online_fix"
        self.compact = bool(compact)
        self.setObjectName("ofSourceBadge")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)

        self._lay = QHBoxLayout(self)
        self.icon_lbl = QLabel()
        self.icon_lbl.setFixedSize(11, 11)
        self._lay.addWidget(self.icon_lbl)
        self.text_lbl = QLabel()
        self._lay.addWidget(self.text_lbl)
        self.setFixedHeight(20)
        self.set_source(self.source, compact=self.compact)

    def set_source(self, source: str, compact: bool | None = None):
        self.source = source or "online_fix"
        if compact is not None:
            self.compact = bool(compact)
        bg, border, fg, icon_name, full_label, short_label = source_theme(self.source)
        pad_h = 5 if self.compact else 6
        self._lay.setContentsMargins(pad_h, 2, pad_h, 2)
        self._lay.setSpacing(3 if self.compact else 4)
        self.setStyleSheet(
            f"#ofSourceBadge {{ background-color: {bg}; border: 1px solid {border}; border-radius: 6px; }}"
            f"#ofSourceBadge QLabel {{ background: transparent; border: none; color: {fg}; "
            f"font-size: 10px; font-weight: 700; letter-spacing: 0.4px; }}"
        )
        self.icon_lbl.setPixmap(_badge_icon_pixmap(icon_name, fg))
        self.text_lbl.setText(short_label if self.compact else full_label)
        self.adjustSize()

class SpinningLoader(QWidget):
    """Smooth rotating circular loading spinner drawn with QPainter."""

    def __init__(self, size: int = 36, line_width: int = 3, color: str = "#8b5cf6", parent=None):
        super().__init__(parent)
        self._size = size
        self._line_width = line_width
        self._color = QColor(color)
        self._track_color = QColor(255, 255, 255, 32)
        self._angle = 0
        self.setFixedSize(size, size)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._timer = QTimer(self)
        self._timer.setInterval(30)
        self._timer.timeout.connect(self._tick)

    def _tick(self):
        self._angle = (self._angle - 15) % 360
        self.update()

    def start(self):
        self.show()
        if not self._timer.isActive():
            self._timer.start()

    def stop(self):
        if self._timer.isActive():
            self._timer.stop()
        self.hide()

    def is_spinning(self) -> bool:
        return self._timer.isActive()

    def hideEvent(self, event):
        if self._timer.isActive():
            self._timer.stop()
        super().hideEvent(event)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        pad = self._line_width / 2.0 + 1.5
        rect = QRectF(pad, pad, self._size - pad * 2, self._size - pad * 2)

        track_pen = QPen(self._track_color, self._line_width)
        track_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(track_pen)
        p.drawEllipse(rect)

        arc_pen = QPen(self._color, self._line_width)
        arc_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(arc_pen)
        # Qt drawArc angles are in 1/16th of a degree
        p.drawArc(rect, int(self._angle * 16), int(105 * 16))
        p.end()
