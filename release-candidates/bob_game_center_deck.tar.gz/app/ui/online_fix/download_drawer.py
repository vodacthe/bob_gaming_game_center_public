"""
Download list panel of the Online-Fix screen: one row per task with torrent progress, extraction status and the
actions that fit its state (cancel, open folder, play, remove).
"""

import logging
import os
import shutil
import subprocess
import sys

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QProgressBar, QPushButton, QScrollArea, QSizePolicy, QVBoxLayout, QWidget,
)

from app.core.online_fix.manager import OnlineFixManager
from app.core.online_fix.models import DownloadTask, SOURCE_ANKERGAMES, SOURCE_FITGIRL, SOURCE_STEAMRIP, TaskStatus
from app.ui.game_card import DARK_BTN_STYLE, GREEN_BTN_STYLE
from app.ui.icons import make_svg_icon
from app.ui.online_fix.common import STATUS_COLORS, SourceBadge, make_button, progress_style, safe_slot

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/Downloads]"

_ICON_BTN_STYLE = """
    QPushButton { background-color: rgba(255, 255, 255, 0.06); border: 1px solid rgba(255, 255, 255, 0.1);
                  border-radius: 6px; padding: 0px; margin: 0px;
                  min-width: 26px; max-width: 26px; min-height: 26px; max-height: 26px; }
    QPushButton:hover { background-color: rgba(239, 68, 68, 0.25); border-color: rgba(239, 68, 68, 0.6); }
"""   # explicit size/padding: the app-wide QPushButton style (padding 8px 18px) would stretch it


def _small_button(text: str, style: str, icon: str) -> QPushButton:
    return make_button(text, style, icon, small=True)


def _format_size_progress(task: DownloadTask) -> str:
    """Return 'Đã tải: X / Y · Còn lại: Z' when byte counts are available."""
    from app.core.online_fix.aria2_downloader import format_bytes

    total_b = int(getattr(task, "total_bytes", 0) or 0)
    done_b = int(getattr(task, "downloaded_bytes", 0) or 0)
    if total_b > 0:
        if done_b <= 0 and getattr(task, "progress_percent", 0.0) > 0:
            done_b = int(total_b * (float(task.progress_percent) / 100.0))
        done_b = min(done_b, total_b)
        rem_b = max(0, total_b - done_b)
        return f"Đã tải: {format_bytes(done_b)} / {format_bytes(total_b)}  ·  Còn lại: {format_bytes(rem_b)}"
    if done_b > 0:
        return f"Đã tải: {format_bytes(done_b)}"
    return ""


class _DownloadItemWidget(QFrame):
    pause_requested = Signal(str)
    resume_requested = Signal(str)
    cancel_requested = Signal(str)
    remove_requested = Signal(str)
    launch_requested = Signal(dict)

    def __init__(self, task: DownloadTask, parent=None):
        super().__init__(parent)
        self.task = task
        self.setObjectName("ofDownloadItem")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet("""
            #ofDownloadItem { background-color: rgba(13, 20, 30, 0.85); border: 1px solid rgba(255, 255, 255, 0.06);
                              border-radius: 10px; }
            #ofDownloadItem QLabel { background: transparent; border: none; }
        """)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(6)

        top = QHBoxLayout()
        top.setSpacing(10)
        self.source_badge = SourceBadge(getattr(task, "source", "online_fix"))
        top.addWidget(self.source_badge)
        self.title_lbl = QLabel(task.game_title)
        self.title_lbl.setStyleSheet("color: #ffffff; font-size: 13px; font-weight: 700;")
        top.addWidget(self.title_lbl, 1)
        self.speed_lbl = QLabel("")
        self.speed_lbl.setStyleSheet("color: #c084fc; font-size: 11px; font-weight: 700;")
        top.addWidget(self.speed_lbl)
        self.eta_lbl = QLabel("")
        self.eta_lbl.setStyleSheet("color: #94a3b8; font-size: 11px;")
        top.addWidget(self.eta_lbl)
        self.cancel_btn = QPushButton()
        self.cancel_btn.setFixedSize(26, 26)
        self.cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cancel_btn.setToolTip("Hủy tải và xóa tệp đã tải")
        self.cancel_btn.setIcon(make_svg_icon("close", size=12, normal_color="#cbd5e1"))
        self.cancel_btn.setIconSize(QSize(12, 12))
        self.cancel_btn.setStyleSheet(_ICON_BTN_STYLE)
        self.cancel_btn.clicked.connect(lambda: self.cancel_requested.emit(self.task.task_id))
        top.addWidget(self.cancel_btn)
        lay.addLayout(top)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setRange(0, 100)
        lay.addWidget(self.progress_bar)

        bottom = QHBoxLayout()
        bottom.setSpacing(8)
        self.status_lbl = QLabel("")
        self.status_lbl.setWordWrap(True)
        bottom.addWidget(self.status_lbl, 1)
        self.pause_btn = _small_button("Tạm dừng", DARK_BTN_STYLE, "pause")
        self.pause_btn.clicked.connect(lambda: self.pause_requested.emit(self.task.task_id))
        bottom.addWidget(self.pause_btn)
        self.resume_btn = _small_button("Tiếp tục", GREEN_BTN_STYLE, "play")
        self.resume_btn.clicked.connect(lambda: self.resume_requested.emit(self.task.task_id))
        bottom.addWidget(self.resume_btn)
        self.open_folder_btn = _small_button("Mở thư mục", DARK_BTN_STYLE, "folder")
        self.open_folder_btn.clicked.connect(self._open_folder)
        bottom.addWidget(self.open_folder_btn)
        self.play_btn = _small_button("Chơi ngay", GREEN_BTN_STYLE, "play")
        self.play_btn.clicked.connect(self._launch)
        bottom.addWidget(self.play_btn)
        self.remove_btn = _small_button("Xóa khỏi danh sách", DARK_BTN_STYLE, "trash")
        self.remove_btn.clicked.connect(lambda: self.remove_requested.emit(self.task.task_id))
        bottom.addWidget(self.remove_btn)
        lay.addLayout(bottom)

        self.refresh()

    def _set_status(self, text: str, kind: str):
        self.status_lbl.setText(text)
        self.status_lbl.setStyleSheet(f"color: {STATUS_COLORS[kind]}; font-size: 11px;")

    def refresh(self):
        """Redraw from the task's current state."""
        t = self.task
        src = getattr(t, "source", "")
        is_fg = (src == SOURCE_FITGIRL)
        bar_color = "#10b981" if (is_fg or src == SOURCE_ANKERGAMES) else ("#f59e0b" if src == SOURCE_STEAMRIP else "#38bdf8")
        active = t.status in (TaskStatus.QUEUED, TaskStatus.PREPARING, TaskStatus.DOWNLOADING, TaskStatus.EXTRACTING)
        can_pause = t.status in (TaskStatus.QUEUED, TaskStatus.PREPARING, TaskStatus.DOWNLOADING)
        can_resume = t.status in (TaskStatus.PAUSED, TaskStatus.FAILED, TaskStatus.CANCELLED)

        self.pause_btn.setVisible(can_pause)
        self.resume_btn.setVisible(can_resume)
        self.resume_btn.setText(
            "Tải lại" if t.status == TaskStatus.CANCELLED else ("Thử lại" if t.status == TaskStatus.FAILED else "Tiếp tục")
        )
        self.cancel_btn.setVisible(active or t.status == TaskStatus.PAUSED)
        self.remove_btn.setVisible(not active)
        folder_path = t.target_install_dir if t.auto_extract else t.download_temp_dir
        self.open_folder_btn.setVisible(
            t.status == TaskStatus.COMPLETED
            or (t.status == TaskStatus.FAILED and bool(folder_path) and os.path.isdir(folder_path))
        )
        self.play_btn.setVisible(t.status == TaskStatus.COMPLETED and bool(t.extracted_exe_path)
                                 and os.path.isfile(t.extracted_exe_path))
        self.progress_bar.setValue(int(t.progress_percent))

        is_cdn = str(getattr(t, "source_url", "")).startswith(("fitgirl-direct:", "steamrip-", "ankergames-", "aria2-list:", "list:"))
        if t.status in (TaskStatus.QUEUED, TaskStatus.PREPARING):
            if t.progress_percent > 0:
                self.progress_bar.setRange(0, 100)
                self.progress_bar.setValue(int(t.progress_percent))
            else:
                self.progress_bar.setRange(0, 0)                # busy indicator while the source is resolved
            self.progress_bar.setStyleSheet(progress_style(bar_color))
            self.speed_lbl.setText("")
            self.eta_lbl.setText(f"{int(t.progress_percent)}%" if t.progress_percent > 0 else "")
            if is_cdn:
                prep_msg = (
                    "Đang kết nối lại máy chủ CDN để tiếp tục tải…"
                    if t.progress_percent > 0
                    else "Đang lấy liên kết tải tốc độ cao (Direct CDN)…"
                )
            else:
                prep_msg = (
                    "Đang kết nối lại để tiếp tục tải…"
                    if t.progress_percent > 0
                    else "Đang lấy tệp torrent / magnet…"
                )
            self._set_status(prep_msg, "busy")
            return
        self.progress_bar.setRange(0, 100)
        size_info = _format_size_progress(t)
        if t.status == TaskStatus.DOWNLOADING:
            self.progress_bar.setStyleSheet(progress_style(bar_color))
            self.speed_lbl.setText(t.download_speed)
            self.eta_lbl.setText(f"Còn {t.eta}" if t.eta and t.eta not in ("--", "--:--") else "")
            status_txt = f"Đang tải: {int(t.progress_percent)}%" + (f"  ·  {size_info}" if size_info else "")
            self._set_status(status_txt, "info")
        elif t.status == TaskStatus.PAUSED:
            self.progress_bar.setStyleSheet(progress_style("#f59e0b"))
            self.speed_lbl.setText("Tạm dừng")
            self.eta_lbl.setText(f"{int(t.progress_percent)}%")
            if size_info:
                msg = f"Đã tạm dừng ({int(t.progress_percent)}%)  ·  {size_info} — bấm 'Tiếp tục' để tải tiếp."
            else:
                msg = t.eta if t.eta and t.eta not in ("--", "--:--") else f"Đã tạm dừng ở {int(t.progress_percent)}% — bấm 'Tiếp tục' để tải tiếp."
            self._set_status(msg, "warn")
        elif t.status == TaskStatus.EXTRACTING:
            self.progress_bar.setStyleSheet(progress_style("#e3b341"))
            self.speed_lbl.setText("Cài đặt" if is_fg else "Giải nén")
            self.eta_lbl.setText(f"{int(t.progress_percent)}%")
            default_msg = "Đang cài đặt Repack…" if is_fg else "Đang giải nén…"
            self._set_status(t.eta or default_msg, "info")
        elif t.status == TaskStatus.COMPLETED:
            self.progress_bar.setValue(100)
            self.progress_bar.setStyleSheet(progress_style("#2ed573"))
            self.speed_lbl.setText("")
            self.eta_lbl.setText("")
            if not t.auto_extract:
                self._set_status("Đã tải xong (chưa cài đặt/giải nén).", "ok")
            elif t.extracted_exe_path:
                verb = "cài đặt" if is_fg else "giải nén"
                self._set_status(f"Đã tải và {verb} xong, đã thêm vào Thư viện.", "ok")
            else:
                verb = "cài đặt" if is_fg else "giải nén"
                self._set_status(f"Đã {verb} xong nhưng không tìm thấy file .exe của game: thêm thủ công.", "warn")
        elif t.status == TaskStatus.FAILED:
            self.progress_bar.setStyleSheet(progress_style("#ef4444"))
            self.speed_lbl.setText("")
            self.eta_lbl.setText(f"{int(t.progress_percent)}%" if t.progress_percent > 0 else "")
            self._set_status(t.error_message or "Thất bại.", "error")
        elif t.status == TaskStatus.CANCELLED:
            self.progress_bar.setStyleSheet(progress_style("#475569"))
            self.speed_lbl.setText("")
            self.eta_lbl.setText("")
            self._set_status("Đã hủy tải và xóa tệp tạm — bấm 'Tải lại' nếu muốn tải lại từ đầu.", "info")

    @safe_slot
    def _open_folder(self):
        t = self.task
        target = t.target_install_dir if t.auto_extract else t.download_temp_dir
        if not os.path.isdir(target):
            logger.warning(f"{TAG} Folder no longer exists: {target}")
            self._set_status("Thư mục không còn tồn tại.", "warn")
            return
        logger.info(f"{TAG} User opened folder {target}")
        norm_target = os.path.normpath(target)
        if sys.platform == "win32":
            os.startfile(norm_target)
        else:
            opener = shutil.which("xdg-open") or ("open" if sys.platform == "darwin" else "xdg-open")
            subprocess.Popen([opener, norm_target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    @safe_slot
    def _launch(self):
        exe = self.task.extracted_exe_path
        if not exe or not os.path.isfile(exe):
            self._set_status("Không tìm thấy file .exe của game.", "warn")
            return
        from app.core.online_fix.translate import title_to_vietnamese
        name = title_to_vietnamese(self.task.game_title) if self.task.game_title else self.task.game_title
        logger.info(f"{TAG} User requested launch for {name!r} ({exe})")
        self._set_status("Đang khởi chạy trò chơi...", "info")
        self.launch_requested.emit({
            "name": name,
            "exe_path": exe,
            "install_location": self.task.target_install_dir,
            "online_fix": True,
        })
        return
        try:
            from app.core.online_fix.extractor import clean_subprocess_env
            subprocess.Popen([exe], cwd=os.path.dirname(exe), env=clean_subprocess_env())
        except OSError as e:
            logger.error(f"{TAG} Could not launch {exe}: {e}")
            self._set_status(f"Không chạy được game: {e}", "error")


class DownloadDrawer(QWidget):
    """Collapsible list of download tasks, kept in sync with the manager's signals."""

    collapse_requested = Signal()
    launch_requested = Signal(dict)

    def __init__(self, manager: OnlineFixManager, parent=None):
        super().__init__(parent)
        self.manager = manager
        self._items: dict[str, _DownloadItemWidget] = {}
        self.setObjectName("ofDrawer")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet("""
            #ofDrawer { background-color: rgba(13, 16, 26, 0.55); border: 1px solid rgba(255, 255, 255, 0.06);
                        border-radius: 12px; }
            #ofDrawer QLabel#ofDrawerTitle { color: #ffffff; font-size: 13px; font-weight: 700; background: transparent; }
            #ofDrawer QLabel#ofDrawerEmpty { color: #64748b; font-size: 12px; background: transparent; }
        """)
        self._setup_ui()
        manager.task_added.connect(self._on_task_added)
        manager.task_progress.connect(self._on_task_changed)
        manager.task_paused.connect(self._on_task_changed)
        manager.task_resumed.connect(self._on_task_changed)
        manager.task_extracting.connect(self._on_task_changed)
        manager.task_completed.connect(self._on_task_changed)
        manager.task_failed.connect(self._on_task_changed)
        manager.task_cancelled.connect(self._on_task_changed)
        manager.tasks_removed.connect(self._on_tasks_removed)
        for task in manager.list_tasks():          # screen re-created or restored from config.json
            self._on_task_added(task)
        self._update_clear_button()

    def _setup_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 12)
        lay.setSpacing(8)

        header = QHBoxLayout()
        title = QLabel("Danh sách tải về")
        title.setObjectName("ofDrawerTitle")
        header.addWidget(title)
        header.addStretch()
        self.clear_completed_btn = _small_button(
            "Xóa mục đã hoàn tất",
            DARK_BTN_STYLE
            + "QPushButton:disabled { color: rgba(255, 255, 255, 0.35); background-color: rgba(255, 255, 255, 0.03); border-color: rgba(255, 255, 255, 0.07); }",
            "trash",
        )
        self.clear_completed_btn.setToolTip(
            "Xóa toàn bộ game đã tải và cài đặt xong khỏi danh sách tải (giữ nguyên file game)"
        )
        self.clear_completed_btn.clicked.connect(self._on_clear_completed)
        header.addWidget(self.clear_completed_btn)
        self.collapse_btn = _small_button("Thu gọn", DARK_BTN_STYLE, "chevron_down")
        self.collapse_btn.clicked.connect(self.collapse_requested.emit)
        header.addWidget(self.collapse_btn)
        lay.addLayout(header)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        self.container = QWidget()
        self.container.setStyleSheet("background: transparent;")
        self.container_layout = QVBoxLayout(self.container)
        self.container_layout.setContentsMargins(0, 0, 0, 0)
        self.container_layout.setSpacing(8)
        self.empty_label = QLabel("Chưa có lượt tải nào. Chọn một game rồi bấm 'Bắt đầu tải'.")
        self.empty_label.setObjectName("ofDrawerEmpty")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.container_layout.addWidget(self.empty_label)
        self.container_layout.addStretch()
        self.scroll.setWidget(self.container)
        lay.addWidget(self.scroll, 1)

    @safe_slot
    def _on_task_added(self, task: DownloadTask):
        if task.task_id in self._items:
            return
        self.empty_label.hide()
        item = _DownloadItemWidget(task, self.container)
        item.pause_requested.connect(self._on_pause)
        item.resume_requested.connect(self._on_resume)
        item.cancel_requested.connect(self._on_cancel)
        item.remove_requested.connect(self._on_remove)
        item.launch_requested.connect(self.launch_requested.emit)
        self._items[task.task_id] = item
        self.container_layout.insertWidget(0, item)           # newest on top
        self._update_clear_button()
        self.show()

    @safe_slot
    def _on_task_changed(self, task_id: str, *_):
        item = self._items.get(task_id)
        if item is not None:
            item.refresh()
        self._update_clear_button()

    @safe_slot
    def _on_pause(self, task_id: str):
        logger.info(f"{TAG} User paused task {task_id}")
        self.manager.pause_task(task_id)

    @safe_slot
    def _on_resume(self, task_id: str):
        logger.info(f"{TAG} User resumed task {task_id}")
        self.manager.resume_task(task_id)

    @safe_slot
    def _on_cancel(self, task_id: str):
        logger.info(f"{TAG} User cancelled task {task_id}")
        self.manager.cancel_task(task_id)

    @safe_slot
    def _on_remove(self, task_id: str):
        self.manager.remove_task(task_id)
        item = self._items.pop(task_id, None)
        if item is not None:
            item.deleteLater()
        self.empty_label.setVisible(not self._items)
        self._update_clear_button()

    @safe_slot
    def _on_tasks_removed(self, task_ids: list):
        for tid in task_ids or []:
            item = self._items.pop(str(tid), None)
            if item is not None:
                item.deleteLater()
        self.empty_label.setVisible(not self._items)
        self._update_clear_button()

    @safe_slot
    def _on_clear_completed(self):
        logger.info(f"{TAG} User requested clearing all completed tasks")
        removed_ids = self.manager.clear_completed_tasks()
        for tid in removed_ids:
            item = self._items.pop(tid, None)
            if item is not None:
                item.deleteLater()
        self.empty_label.setVisible(not self._items)
        self._update_clear_button()

    def _update_clear_button(self):
        completed_cnt = sum(1 for item in self._items.values() if item.task.status == TaskStatus.COMPLETED)
        txt = f"Xóa mục đã hoàn tất ({completed_cnt})" if completed_cnt else "Xóa mục đã hoàn tất"
        if self.clear_completed_btn.text() != txt:
            self.clear_completed_btn.setText(txt)
        self.clear_completed_btn.setEnabled(completed_cnt > 0)

