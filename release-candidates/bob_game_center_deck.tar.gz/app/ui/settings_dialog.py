"""
Settings dialog for Bob Gaming Game Center.
"""

import sys
import os
import logging

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QCheckBox, QComboBox, QListView, QWidget, QMessageBox,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

from app.config import load_config, save_config, APP_NAME
from app.core import updater

logger = logging.getLogger(__name__)

# Task and registry constants for Windows auto-start
TASK_NAME = "BobGamingGameCenter"
REGISTRY_RUN_KEY = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
REGISTRY_APP_NAME = "BobGamingGameCenter"


def _is_admin() -> bool:
    """Check if current process has Administrator privileges."""
    try:
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False


def _get_target_command_info() -> tuple[str, str, str]:
    """Return (executable_path, arguments, working_directory)."""
    if getattr(sys, 'frozen', False):
        exe = sys.executable
        args = "--minimized"
        work_dir = os.path.dirname(sys.executable)
    else:
        # Running as script — use pythonw to avoid console window
        python_dir = os.path.dirname(sys.executable)
        pythonw = os.path.join(python_dir, "pythonw.exe")
        if not os.path.exists(pythonw):
            pythonw = sys.executable
        main_script = os.path.abspath(os.path.join(
            os.path.dirname(__file__), "..", "..", "main.py"
        ))
        exe = pythonw
        args = f'"{main_script}" --minimized'
        work_dir = os.path.dirname(main_script)
    return exe, args, work_dir


def set_auto_start(enabled: bool):
    """Set or remove the app from Windows startup.
    
    Because BobGamingGameCenter requires Administrator privileges (--uac-admin),
    standard Windows Run registry keys are silently blocked by Explorer at logon.
    We use Windows Task Scheduler with Highest Privileges (/RL HIGHEST) so the app
    starts automatically on logon without UAC prompts.
    """
    import subprocess

    # 1. First, always remove any legacy Run registry entry
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            REGISTRY_RUN_KEY,
            0,
            winreg.KEY_SET_VALUE,
        )
        try:
            winreg.DeleteValue(key, REGISTRY_APP_NAME)
        except FileNotFoundError:
            pass
        finally:
            winreg.CloseKey(key)
    except Exception:
        pass

    # 2. Configure Windows Task Scheduler
    try:
        if enabled:
            exe, args, work_dir = _get_target_command_info()
            ps_script = f"""
            $action = New-ScheduledTaskAction -Execute '{exe}' -Argument '{args}' -WorkingDirectory '{work_dir}'
            $trigger = New-ScheduledTaskTrigger -AtLogOn
            $principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest
            $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
            Register-ScheduledTask -TaskName '{TASK_NAME}' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
            """
            if _is_admin():
                cmd = ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script]
            else:
                cmd = [
                    "powershell", "-NoProfile", "-Command",
                    f"Start-Process powershell -ArgumentList '-NoProfile', '-Command', @'\n{ps_script.strip()}\n'@ -Verb RunAs -Wait"
                ]

            res = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
            )
            if res.returncode == 0:
                logger.info("Auto-start enabled via Windows Task Scheduler (Highest Privileges)")
            else:
                logger.error(f"Failed to create auto-start scheduled task: {res.stderr}")
        else:
            ps_script = f"Unregister-ScheduledTask -TaskName '{TASK_NAME}' -Confirm:$false -ErrorAction SilentlyContinue"
            if _is_admin():
                cmd = ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script]
            else:
                cmd = [
                    "powershell", "-NoProfile", "-Command",
                    f"Start-Process powershell -ArgumentList '-NoProfile', '-Command', '{ps_script}' -Verb RunAs -Wait"
                ]

            res = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
            )
            if res.returncode == 0:
                logger.info("Auto-start disabled (Scheduled Task removed)")
            else:
                logger.error(f"Failed to remove auto-start scheduled task: {res.stderr}")
    except Exception as e:
        logger.error(f"Error managing auto-start: {e}")


def is_auto_start_enabled() -> bool:
    """Check if auto-start is enabled via Task Scheduler or registry."""
    import subprocess
    try:
        res = subprocess.run(
            ["schtasks", "/Query", "/TN", TASK_NAME],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
        )
        if res.returncode == 0:
            return True
    except Exception:
        pass

    # Fallback to check registry (in case user migrated from older version)
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            REGISTRY_RUN_KEY,
            0,
            winreg.KEY_QUERY_VALUE,
        )
        try:
            winreg.QueryValueEx(key, REGISTRY_APP_NAME)
            return True
        except FileNotFoundError:
            return False
        finally:
            winreg.CloseKey(key)
    except Exception:
        return False


from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.styles import CHEVRON_DOWN_ICON_PATH

_DLG_STEAM_COMBO_STYLE = """
    QComboBox {
        background-color: #23262e;
        color: #e6edf3;
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 6px;
        padding: 0 30px 0 12px;
        font-size: 12px;
        font-weight: 600;
    }
    QComboBox:hover {
        background-color: #2b303b;
        border-color: rgba(255, 255, 255, 0.24);
        color: #ffffff;
    }
    QComboBox::drop-down {
        subcontrol-origin: padding;
        subcontrol-position: top right;
        width: 26px;
        border: none;
        background: transparent;
    }
    QComboBox::down-arrow {
        image: url("__CHEVRON_DOWN_ICON_PATH__");
        width: 12px;
        height: 12px;
        margin-right: 6px;
        border: none;
    }
    QComboBox QAbstractItemView {
        background-color: #1d2129;
        color: #e6edf3;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 6px;
        padding: 4px;
        outline: none;
        selection-background-color: #3b82f6;
        selection-color: #ffffff;
    }
    QComboBox QAbstractItemView::item {
        min-height: 28px;
        padding: 4px 10px;
        border-radius: 4px;
    }
""".replace("__CHEVRON_DOWN_ICON_PATH__", CHEVRON_DOWN_ICON_PATH)


class SettingsDialog(QDialog):
    """Settings dialog for app configuration."""

    settings_changed = Signal(dict)        # Emits updated config
    update_channel_changed = Signal(str)   # Emits immediately when update channel changes
    reset_requested = Signal()             # Emits when factory reset is confirmed

    def __init__(self, config: dict, parent=None):
        super().__init__(parent)
        self.config = config.copy()
        self.setWindowTitle("Cài đặt hệ thống")
        self.setFixedSize(460, 720)
        self.setWindowFlags(
            Qt.WindowType.Dialog
            | Qt.WindowType.WindowTitleHint
            | Qt.WindowType.WindowCloseButtonHint
        )
        self._setup_ui()

    def _setup_ui(self):
        """Set up the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(8)

        # Title
        title_row = QHBoxLayout()
        title_icon = QLabel()
        title_icon.setPixmap(make_svg_pixmap("settings", 20, "#f59e0b"))
        title = QLabel("Cài đặt hệ thống")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        title.setStyleSheet("color: #ffffff; background: transparent;")
        title_row.addWidget(title_icon)
        title_row.addWidget(title)
        title_row.addStretch()

        # Separator
        separator = QWidget()
        separator.setFixedHeight(1)
        separator.setStyleSheet("background-color: rgba(255, 255, 255, 0.08);")

        # ---- Update Channel (Steam-style row) ----
        channel_row = QHBoxLayout()
        channel_row.setSpacing(12)
        channel_label = QLabel("Kênh cập nhật ứng dụng")
        channel_label.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        channel_row.addWidget(channel_label, 1)

        self.channel_combo = QComboBox()
        self.channel_combo.setView(QListView(self.channel_combo))
        self.channel_combo.setFixedSize(190, 34)
        self.channel_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.channel_combo.setStyleSheet(_DLG_STEAM_COMBO_STYLE)
        self.channel_combo.addItem("Stable", updater.CHANNEL_STABLE)
        self.channel_combo.addItem("Release Candidates", updater.CHANNEL_RC)
        self._refresh_channel_combo(self.config.get("update_channel", updater.CHANNEL_STABLE))
        self.channel_combo.currentIndexChanged.connect(self._on_channel_combo_changed)
        channel_row.addWidget(self.channel_combo, 0, Qt.AlignmentFlag.AlignRight)

        # ---- Auto-start ----
        self.auto_start_cb = QCheckBox("Khởi động cùng Windows")
        self.auto_start_cb.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3; padding: 6px 0;")
        self.auto_start_cb.setChecked(is_auto_start_enabled())

        auto_start_desc = QLabel(
            "Tự động kích hoạt Bob Gaming Game Center khi đăng nhập vào máy tính."
        )
        auto_start_desc.setStyleSheet(
            "font-size: 11px; color: #8b949e; background: transparent; padding-left: 24px;"
        )
        auto_start_desc.setWordWrap(True)

        # ---- Minimize to tray ----
        self.minimize_tray_cb = QCheckBox("Thu nhỏ xuống khay hệ thống khi đóng")
        self.minimize_tray_cb.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3; padding: 6px 0;")
        self.minimize_tray_cb.setChecked(self.config.get("minimize_to_tray", True))

        minimize_desc = QLabel(
            "Khi bấm nút đóng [X], ứng dụng sẽ thu nhỏ xuống thanh tác vụ thay vì tắt hẳn."
        )
        minimize_desc.setStyleSheet(
            "font-size: 11px; color: #8b949e; background: transparent; padding-left: 24px;"
        )
        minimize_desc.setWordWrap(True)

        # ---- Hide Steam games ----
        self.hide_steam_cb = QCheckBox("Ẩn trò chơi Steam trong thư viện")
        self.hide_steam_cb.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3; padding: 6px 0;")
        self.hide_steam_cb.setChecked(self.config.get("hide_steam_games", True))

        hide_steam_desc = QLabel(
            "Chỉ ẩn trò chơi mua từ Steam (do đã có Steam Cloud). Trò chơi Non-Steam thêm vào Steam hoặc game cài ngoài vẫn luôn hiển thị."
        )
        hide_steam_desc.setStyleSheet(
            "font-size: 11px; color: #8b949e; background: transparent; padding-left: 24px;"
        )
        hide_steam_desc.setWordWrap(True)

        # ---- Auto-claim Steam 100%-off games ----
        self.auto_claim_steam_cb = QCheckBox("Tự động nhận game trả phí đang miễn phí 100% trên Steam")
        self.auto_claim_steam_cb.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3; padding: 6px 0;")
        self.auto_claim_steam_cb.setChecked(self.config.get("auto_claim_steam_free_games", True))

        auto_claim_steam_desc = QLabel(
            "Quét ngầm mỗi 1 giờ để tìm game và DLC trả phí đang giảm 100% về 0đ rồi tự thêm vào tài khoản Steam."
        )
        auto_claim_steam_desc.setStyleSheet(
            "font-size: 11px; color: #8b949e; background: transparent; padding-left: 24px;"
        )
        auto_claim_steam_desc.setWordWrap(True)

        # ---- Buttons ----
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)

        cancel_btn = QPushButton("Hủy bỏ")
        cancel_btn.setObjectName("secondaryBtn")
        cancel_btn.setMinimumHeight(38)
        cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        cancel_btn.clicked.connect(self.reject)

        save_btn = QPushButton(" Lưu cài đặt")
        save_btn.setIcon(make_svg_icon("save", 16, "#000000"))
        save_btn.setMinimumHeight(38)
        save_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        save_btn.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        save_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
                color: #0b0e14;
                font-weight: bold;
                border-radius: 8px;
                padding: 6px 18px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #fbbf24, stop:1 #f59e0b);
            }
        """)
        save_btn.clicked.connect(self._on_save)

        btn_layout.addWidget(cancel_btn)
        btn_layout.addWidget(save_btn)

        # ---- Cloud Provider Info ----
        provider = self.config.get("cloud_provider", "")
        provider_names = {
            "nextcloud": "Nextcloud (Tự lưu trữ)",
            "google_drive": "Google Drive",
        }
        provider_display = provider_names.get(provider, "Chưa kết nối Cloud")

        provider_label = QLabel("Dịch vụ lưu trữ Cloud")
        provider_label.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3; padding: 6px 0;")

        provider_value = QLabel(f"Trạng thái: {provider_display}")
        provider_value.setStyleSheet(
            f"font-size: 12px; color: {'#2ed573' if provider else '#8b949e'}; "
            f"background: transparent; padding-left: 24px;"
        )

        provider_hint = QLabel(
            "Để đổi dịch vụ đám mây, vui lòng đăng xuất và đăng nhập lại bằng dịch vụ khác."
        )
        provider_hint.setStyleSheet(
            "font-size: 11px; color: #8b949e; background: transparent; padding-left: 24px;"
        )
        provider_hint.setWordWrap(True)

        sep2 = QWidget()
        sep2.setFixedHeight(1)
        sep2.setStyleSheet("background-color: rgba(255, 255, 255, 0.08);")

        # ---- Danger Zone (Factory Reset) ----
        sep3 = QWidget()
        sep3.setFixedHeight(1)
        sep3.setStyleSheet("background-color: rgba(255, 71, 87, 0.3);")

        danger_title = QLabel("Vùng nguy hiểm")
        danger_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #ff4757; padding-top: 4px;")

        danger_desc = QLabel(
            "Khôi phục cấu hình gốc, đăng xuất tài khoản Cloud, xóa nhật ký và khởi động lại ứng dụng."
        )
        danger_desc.setStyleSheet(
            "font-size: 11px; color: #8b949e; background: transparent; padding-left: 24px;"
        )
        danger_desc.setWordWrap(True)

        reset_btn_layout = QHBoxLayout()
        reset_btn_layout.setContentsMargins(24, 0, 0, 0)
        self.reset_btn = QPushButton(" Khôi phục cài đặt gốc (Factory Reset)")
        self.reset_btn.setIcon(make_svg_icon("alert", 14, "#ff4757"))
        self.reset_btn.setObjectName("dangerBtn")
        self.reset_btn.setMinimumHeight(34)
        self.reset_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.reset_btn.clicked.connect(self._on_reset_clicked)
        reset_btn_layout.addWidget(self.reset_btn)

        # Add to layout
        layout.addLayout(title_row)
        layout.addSpacing(4)
        layout.addWidget(separator)
        layout.addSpacing(8)
        layout.addWidget(provider_label)
        layout.addWidget(provider_value)
        layout.addWidget(provider_hint)
        layout.addSpacing(4)
        layout.addWidget(sep2)
        layout.addSpacing(6)
        layout.addLayout(channel_row)
        layout.addSpacing(4)
        layout.addWidget(self.auto_start_cb)
        layout.addWidget(auto_start_desc)
        layout.addSpacing(4)
        layout.addWidget(self.minimize_tray_cb)
        layout.addWidget(minimize_desc)
        layout.addSpacing(4)
        layout.addWidget(self.hide_steam_cb)
        layout.addWidget(hide_steam_desc)
        layout.addSpacing(4)
        layout.addWidget(self.auto_claim_steam_cb)
        layout.addWidget(auto_claim_steam_desc)
        layout.addSpacing(6)
        layout.addWidget(sep3)
        layout.addSpacing(4)
        layout.addWidget(danger_title)
        layout.addWidget(danger_desc)
        layout.addSpacing(6)
        layout.addLayout(reset_btn_layout)
        layout.addStretch()
        layout.addLayout(btn_layout)

    def _refresh_channel_combo(self, channel: str | None):
        ch = updater.normalize_channel(channel)
        idx = self.channel_combo.findData(ch)
        if idx < 0:
            idx = 0
        self.channel_combo.blockSignals(True)
        try:
            self.channel_combo.setCurrentIndex(idx)
        finally:
            self.channel_combo.blockSignals(False)

    def _on_channel_combo_changed(self, _index: int):
        self._select_update_channel(str(self.channel_combo.currentData() or updater.CHANNEL_STABLE))

    def _select_update_channel(self, channel: str):
        target = updater.normalize_channel(channel)
        current = updater.normalize_channel(self.config.get("update_channel", updater.CHANNEL_STABLE))
        self._refresh_channel_combo(target)
        if target == current:
            return
        self.config["update_channel"] = target
        self.config["skipped_version"] = ""
        save_config(self.config)
        logger.info(f"[Settings] Update channel selected via dialog: {current} -> {target}")
        self.update_channel_changed.emit(target)

    def _on_reset_clicked(self):
        """Prompt user for confirmation before resetting config."""
        msg = QMessageBox(self)
        msg.setWindowTitle("Xác nhận khôi phục cài đặt gốc")
        msg.setText("<b>Bạn có chắc chắn muốn đặt lại tất cả cài đặt về mặc định?</b>")
        msg.setInformativeText(
            "Hành động này sẽ:\n"
            "- Đặt lại mọi tùy chọn ứng dụng về ban đầu\n"
            "- Đăng xuất tài khoản lưu trữ Cloud\n"
            "- Xóa sạch các file nhật ký (logs)\n"
            "- Khởi động lại ứng dụng\n\n"
            "Thao tác này không thể hoàn tác."
        )
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setStandardButtons(
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel
        )
        msg.setDefaultButton(QMessageBox.StandardButton.Cancel)

        yes_btn = msg.button(QMessageBox.StandardButton.Yes)
        if yes_btn:
            yes_btn.setText("Đồng ý, Đặt lại && Khởi động lại")
            yes_btn.setObjectName("dangerBtn")

        cancel_btn = msg.button(QMessageBox.StandardButton.Cancel)
        if cancel_btn:
            cancel_btn.setText("Hủy bỏ")
            cancel_btn.setObjectName("secondaryBtn")

        if msg.exec() == QMessageBox.StandardButton.Yes:
            self.reset_requested.emit()
            self.reject()

    def _on_save(self):
        """Save settings and close."""
        auto_start = self.auto_start_cb.isChecked()
        minimize_to_tray = self.minimize_tray_cb.isChecked()
        hide_steam = self.hide_steam_cb.isChecked()

        # Update registry for auto-start
        set_auto_start(auto_start)

        # Update config
        self.config["auto_start"] = auto_start
        self.config["minimize_to_tray"] = minimize_to_tray
        self.config["hide_steam_games"] = hide_steam
        self.config["auto_claim_steam_free_games"] = self.auto_claim_steam_cb.isChecked()
        self.config["update_channel"] = updater.normalize_channel(
            self.channel_combo.currentData() or self.config.get("update_channel", updater.CHANNEL_STABLE)
        )

        self.settings_changed.emit(self.config)
        self.accept()
