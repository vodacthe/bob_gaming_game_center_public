"""
Background worker classes for Bob Gaming Game Center.
Extracted from main_window.py for better separation of concerns.
"""

import logging
import queue
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from PySide6.QtCore import QObject, Signal

from app.core.cloud_provider import CloudProvider
from app.core.image_cache import ImageCache
from app.core.sync_manager import SyncManager, determine_sync_action
from app.core.game_scanner import scan_all_games, scan_steam_games

logger = logging.getLogger(__name__)


class CloudCheckBatchWorker(QObject):
    """Worker that checks cloud status for multiple games sequentially (single thread)."""
    game_checked = Signal(str, bool, str)  # game_name, on_cloud, cloud_save_path
    all_done = Signal()

    def __init__(self, cloud_client: CloudProvider, game_names: list[str]):
        super().__init__()
        self.cloud_client = cloud_client
        self.game_names = game_names
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        for game_name in self.game_names:
            if self._cancelled:
                logger.info("[CloudCheck] Batch check cancelled")
                break
            try:
                logger.info(f"[CloudCheck] Checking cloud status for: {game_name}")
                on_cloud = self.cloud_client.check_game_exists(game_name)
                if self._cancelled:
                    logger.info("[CloudCheck] Batch check cancelled")
                    break
                cloud_save_path = ""
                if on_cloud:
                    cloud_save_path = self.cloud_client.get_save_location(game_name) or ""
                logger.info(f"[CloudCheck] {game_name}: on_cloud={on_cloud}, cloud_save_path={cloud_save_path}")
                if not self._cancelled:
                    self.game_checked.emit(game_name, on_cloud, cloud_save_path)
            except Exception as e:
                logger.error(f"[CloudCheck] Error checking {game_name}: {e}")
                if not self._cancelled:
                    self.game_checked.emit(game_name, False, "")
        self.all_done.emit()


class CloudGameDiscoveryWorker(QObject):
    """Worker that discovers games on the cloud that aren't in the local list."""
    finished = Signal(list)  # list of cloud game names
    error = Signal(str)

    def __init__(self, cloud_client: CloudProvider):
        super().__init__()
        self.cloud_client = cloud_client

    def run(self):
        try:
            logger.info("[CloudDiscovery] Listing cloud games...")
            cloud_games = self.cloud_client.list_synced_games()
            logger.info(f"[CloudDiscovery] Found {len(cloud_games)} cloud games: {cloud_games}")
            self.finished.emit(cloud_games)
        except Exception as e:
            logger.error(f"[CloudDiscovery] Error: {e}")
            self.error.emit(str(e))


class ImageLoadWorker(QObject):
    """Worker for loading game images in parallel using thread pool."""
    image_ready = Signal(str, str)  # game_name, image_path
    finished = Signal()

    MAX_WORKERS = 8  # Download 8 images concurrently

    def __init__(self, image_cache: ImageCache, game_names: list[str]):
        super().__init__()
        self.image_cache = image_cache
        self.game_names = game_names
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def _load_single(self, name: str) -> tuple[str, str | None]:
        """Load a single game image (runs in thread pool)."""
        if self._cancelled:
            return (name, None)
        try:
            path = self.image_cache.get_game_image(name)
            return (name, path)
        except Exception as e:
            logger.error(f"Failed to load image for {name}: {e}")
            return (name, None)

    def run(self):
        with ThreadPoolExecutor(max_workers=self.MAX_WORKERS) as pool:
            futures = {pool.submit(self._load_single, name): name for name in self.game_names}
            for future in as_completed(futures):
                if self._cancelled:
                    break
                try:
                    name, path = future.result()
                    if path and not self._cancelled:
                        self.image_ready.emit(name, path)
                except Exception as e:
                    logger.error(f"Image load future error: {e}")

        self.finished.emit()


class AsyncImageLoader(QObject):
    """
    Dedicated background image loader that processes games from a thread-safe queue.
    Prevents thread churn, UI freezing, and destroyed QThread crashes when many games
    are scanned or unhidden simultaneously.
    """
    image_ready = Signal(str, str)  # game_name, image_path

    def __init__(self, image_cache: ImageCache, max_workers: int = 4, parent=None):
        super().__init__(parent)
        self.image_cache = image_cache
        self.max_workers = max_workers
        self._queue: queue.Queue = queue.Queue()
        self._queued_names: set = set()
        self._lock = threading.Lock()
        self._worker_thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    def enqueue(self, game_names: list[str]):
        """Enqueue game names for background cover fetching."""
        if not self.image_cache or not game_names:
            return

        added_any = False
        with self._lock:
            for name in game_names:
                if not name or name in self._queued_names:
                    continue
                self._queued_names.add(name)
                self._queue.put(name)
                added_any = True

        if added_any:
            self._ensure_worker_running()

    def _ensure_worker_running(self):
        with self._lock:
            if self._worker_thread is None or not self._worker_thread.is_alive():
                self._stop_event.clear()
                self._worker_thread = threading.Thread(
                    target=self._run_loop,
                    name="AsyncImageLoader",
                    daemon=True,
                )
                self._worker_thread.start()

    def _run_loop(self):
        with ThreadPoolExecutor(max_workers=self.max_workers, thread_name_prefix="ImgWorker") as pool:
            while not self._stop_event.is_set():
                try:
                    game_name = self._queue.get(timeout=3.0)
                except queue.Empty:
                    with self._lock:
                        if self._queue.empty():
                            break
                    continue

                if self._stop_event.is_set():
                    break

                def _fetch(name=game_name):
                    try:
                        path = self.image_cache.get_game_image(name)
                        if path and not self._stop_event.is_set():
                            self.image_ready.emit(name, path)
                    except Exception as e:
                        logger.error(f"[AsyncImageLoader] Error loading image for {name}: {e}")
                    finally:
                        with self._lock:
                            self._queued_names.discard(name)

                pool.submit(_fetch)

    def stop(self):
        self._stop_event.set()


class SyncWorker(QObject):
    """Worker for sync operations in background."""
    progress = Signal(str, int, int, float, int, int)  # game_name, current, total, speed, bytes_done, total_bytes
    finished = Signal(str, bool, str)  # game_name, success, message

    def __init__(self, sync_manager: SyncManager, operation: str,
                 game_name: str, save_path: str = ""):
        super().__init__()
        self.sync_manager = sync_manager
        self.operation = operation
        self.game_name = game_name
        self.save_path = save_path

    def _on_sync_progress(self, game_name: str, current: int, total: int, speed: float = 0.0, bytes_done: int = 0, total_bytes: int = 0, *args, **kwargs):
        if game_name == self.game_name:
            self.progress.emit(game_name, current, total, speed, bytes_done, total_bytes)

    def run(self):
        logger.info(f"[SyncWorker] Started '{self.operation}' for '{self.game_name}'")
        try:
            if hasattr(self.sync_manager, "sync_progress"):
                self.sync_manager.sync_progress.connect(self._on_sync_progress)

            if self.operation == "upload":
                success = self.sync_manager.setup_game_sync(self.game_name, self.save_path)
                msg = "Saves uploaded successfully!" if success else "Upload failed"
            elif self.operation == "download":
                success = self.sync_manager.download_game_saves(self.game_name, self.save_path)
                msg = "Saves downloaded successfully!" if success else "Download failed"
            elif self.operation == "sync":
                success = self.sync_manager.sync_game(self.game_name)
                msg = "Sync completed!" if success else "Sync failed"
            else:
                success = False
                msg = f"Unknown operation: {self.operation}"

            logger.info(f"[SyncWorker] Finished '{self.operation}' for '{self.game_name}': success={success}, msg={msg}")
            self.finished.emit(self.game_name, success, msg)
        except Exception as e:
            logger.error(f"[SyncWorker] Error in '{self.operation}' for '{self.game_name}': {e}", exc_info=True)
            self.finished.emit(self.game_name, False, str(e))
        finally:
            try:
                if hasattr(self.sync_manager, "sync_progress"):
                    self.sync_manager.sync_progress.disconnect(self._on_sync_progress)
            except Exception:
                pass


class LocalScanWorker(QObject):
    """Worker that scans for locally installed games only (no network calls)."""
    finished = Signal(list, list)  # (non_steam_games, steam_games)

    def run(self):
        try:
            logger.info("[LocalScan] Scanning for installed games...")
            games = scan_all_games()
            logger.info(f"[LocalScan] Found {len(games)} non-Steam games")
            steam = scan_steam_games()
            logger.info(f"[LocalScan] Found {len(steam)} Steam games")
            self.finished.emit(games, steam)
        except Exception as e:
            logger.error(f"[LocalScan] Error: {e}")
            self.finished.emit([], [])


class SyncNowCheckWorker(QObject):
    """Worker that checks local vs cloud timestamps and returns a sync decision."""
    result_ready = Signal(str, str, float, float, float)  # game_name, decision, local_time, remote_time, last_sync

    def __init__(self, sync_manager: SyncManager, game_name: str):
        super().__init__()
        self.sync_manager = sync_manager
        self.game_name = game_name

    def run(self):
        try:
            game_config = self.sync_manager.config.get("games", {}).get(self.game_name, {})
            last_sync = game_config.get("last_sync", 0.0)

            local_time = self.sync_manager.get_local_modified_time(self.game_name)
            remote_time = self.sync_manager.get_remote_modified_time(self.game_name)

            logger.info(
                f"[SyncNowCheck] {self.game_name}: "
                f"local={local_time}, remote={remote_time}, last_sync={last_sync}"
            )

            lt = local_time or 0.0
            rt = remote_time or 0.0

            action = determine_sync_action(local_time, remote_time, last_sync)
            self.result_ready.emit(self.game_name, action, lt, rt, last_sync)

        except Exception as e:
            logger.error(f"[SyncNowCheck] Error checking {self.game_name}: {e}")
            self.result_ready.emit(self.game_name, "error", 0.0, 0.0, 0.0)


class SteamScanWorker(QObject):
    """Worker that scans for Steam games in background."""
    finished = Signal(list)  # list of steam game dicts

    def run(self):
        try:
            steam = scan_steam_games()
            logger.info(f"[SteamScan] Found {len(steam)} Steam games")
            self.finished.emit(steam)
        except Exception as e:
            logger.error(f"[SteamScan] Error: {e}")
            self.finished.emit([])


class NonSteamShortcutsScanWorker(QObject):
    """Worker that scans for Steam Non-Steam shortcuts in background."""
    finished = Signal(list)  # list of non-steam shortcut game dicts

    def run(self):
        try:
            from app.core.game_scanner import scan_steam_shortcuts
            shortcuts = scan_steam_shortcuts()
            logger.info(f"[ShortcutScan] Found {len(shortcuts)} Non-Steam shortcuts")
            self.finished.emit(shortcuts)
        except Exception as e:
            logger.error(f"[ShortcutScan] Error: {e}")
            self.finished.emit([])


class SteamDeckSetupWorker(QObject):
    """Worker running in a QThread to perform non-blocking Steam Deck setup."""
    finished = Signal(dict)

    def __init__(
        self,
        app_dir: str | None = None,
        script_path: str | None = None,
        icon_path: str | None = None,
        steam_path: str | None = None,
        desktop_dir: str | None = None,
        app_name: str = "Bob Game Center",
        dry_run: bool = False,
        parent: QObject | None = None,
    ):
        super().__init__(parent)
        self.app_dir = app_dir
        self.script_path = script_path
        self.icon_path = icon_path
        self.steam_path = steam_path
        self.desktop_dir = desktop_dir
        self.app_name = app_name
        self.dry_run = dry_run

    def run(self):
        try:
            from app.core.desktop_integration import setup_deck_integration
            result = setup_deck_integration(
                app_dir=self.app_dir,
                script_path=self.script_path,
                icon_path=self.icon_path,
                steam_path=self.steam_path,
                desktop_dir=self.desktop_dir,
                app_name=self.app_name,
                dry_run=self.dry_run,
            )
        except Exception as exc:
            logger.exception("[Desktop/Integration] Unexpected error in SteamDeckSetupWorker")
            result = {
                "success": False,
                "message": f"Unexpected error: {exc}",
            }
        self.finished.emit(result)


