"""
Settings Screen for Bob Gaming Game Center.
Full-screen in-app settings with standard back button navigation.
"""

import sys
import os
import logging

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QCheckBox, QComboBox, QListView, QMessageBox, QScrollArea, QFrame,
    QLineEdit, QFileDialog, QSizePolicy,
)
from PySide6.QtCore import QSize, QTimer, Qt, Signal
from PySide6.QtGui import QFont, QGuiApplication
from PySide6.QtWidgets import QSystemTrayIcon

from app.config import load_config, save_config, APP_NAME
from app.core import updater
from app.core.i18n import (
    LANGUAGE_LABELS,
    SUPPORTED_LANGUAGES,
    current_language,
    normalize_language,
    set_language,
)
from app.ui import notifications
from app.core.online_fix.models import (
    ALL_STORE_SOURCES,
    SOURCE_ANKERGAMES,
    SOURCE_FITGIRL,
    SOURCE_ONLINE_FIX,
    SOURCE_STEAMRIP,
    normalize_enabled_stores,
)
from app.ui.icons import get_flag_icon, make_svg_icon, make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader, guard_scroll_wheel
from app.ui.styles import CHEVRON_DOWN_ICON_PATH
from app.ui.settings_dialog import (
    is_auto_start_enabled,
    set_auto_start,
    _is_admin,
)

logger = logging.getLogger(__name__)
TAG = "[Settings]"

STORE_SETTING_OPTIONS: tuple[tuple[str, str], ...] = (
    (SOURCE_ONLINE_FIX, "Online-Fix.me (Co-op / Multiplayer)"),
    (SOURCE_FITGIRL, "FitGirl Repacks (Repack nén dung lượng cao)"),
    (SOURCE_STEAMRIP, "SteamRIP (Game cài sẵn - Pre-installed)"),
    (SOURCE_ANKERGAMES, "AnkerGames (Direct CDN - Pre-installed)"),
)

STEAM_COMBO_STYLE = """
    QComboBox {
        background-color: #23262e;
        color: #e6edf3;
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 6px;
        padding: 0 34px 0 14px;
        font-size: 13px;
        font-weight: 600;
    }
    QComboBox:hover {
        background-color: #2b303b;
        border-color: rgba(255, 255, 255, 0.24);
        color: #ffffff;
    }
    QComboBox:on {
        background-color: #2b303b;
        border-color: #3b82f6;
    }
    QComboBox::drop-down {
        subcontrol-origin: padding;
        subcontrol-position: top right;
        width: 30px;
        border: none;
        background: transparent;
    }
    QComboBox::down-arrow {
        image: url("__CHEVRON_DOWN_ICON_PATH__");
        width: 14px;
        height: 14px;
        margin-right: 8px;
        border: none;
    }
    QComboBox QAbstractItemView {
        background-color: #1d2129;
        color: #e6edf3;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 6px;
        padding: 4px;
        outline: none;
        selection-background-color: #323846;
        selection-color: #ffffff;
    }
    QComboBox QAbstractItemView::item {
        min-height: 32px;
        padding: 4px 12px;
        border-radius: 4px;
    }
    QComboBox QAbstractItemView::item:hover {
        background-color: #2a303c;
        color: #ffffff;
    }
    QComboBox QAbstractItemView::item:selected {
        background-color: #3b82f6;
        color: #ffffff;
    }
""".replace("__CHEVRON_DOWN_ICON_PATH__", CHEVRON_DOWN_ICON_PATH)


class SettingsScreen(QWidget):
    """Full-screen in-app Settings view."""

    back_requested = Signal()
    settings_changed = Signal(dict)
    update_channel_changed = Signal(str)
    language_changed = Signal(str)
    reset_requested = Signal()

    def __init__(self, config: dict, parent=None):
        super().__init__(parent)
        self.config = config.copy()
        self._syncing_store_cbs = False
        self._loading_settings = False
        self.store_checkboxes: dict[str, QCheckBox] = {}
        self._saved_hide_timer = QTimer(self)
        self._saved_hide_timer.setSingleShot(True)
        self._saved_hide_timer.setInterval(2500)
        self._saved_hide_timer.timeout.connect(self._hide_saved_badge)
        self._notify_status_timer = QTimer(self)
        self._notify_status_timer.setInterval(500)
        self._notify_status_timer.timeout.connect(self._refresh_notify_debug_status)
        self._app_state_connected = False
        self._setup_ui()
        self._wire_auto_save()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Header Bar ──
        header = ScreenHeader("Cài đặt hệ thống", "settings")
        header.back_requested.connect(self._on_back)
        self.save_badge = header.add_badge("Đã lưu cấu hình", "ok")
        self.save_badge.hide()
        self.save_btn = header.add_button("Lưu cài đặt", "primary", icon="save")
        self.save_btn.clicked.connect(self._on_save)
        main_layout.addWidget(header)

        # ── Scroll Area Content ──
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")

        content_widget = QWidget()
        content_widget.setStyleSheet("background: transparent;")
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(*CONTENT_MARGINS)
        content_layout.setSpacing(20)

        # 0. Card: Ngôn ngữ hiển thị (Language Selector with flag icons)
        self.language_card = self._create_card("Ngôn ngữ hiển thị", "globe")
        lang_card_layout = QHBoxLayout(self.language_card)
        lang_card_layout.setContentsMargins(20, 16, 20, 16)
        lang_card_layout.setSpacing(20)

        lang_text_col = QVBoxLayout()
        lang_text_col.setSpacing(4)

        lang_title = QLabel("Ngôn ngữ hiển thị")
        lang_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        lang_text_col.addWidget(lang_title)

        lang_desc = QLabel(
            "Chọn ngôn ngữ giao diện cho toàn bộ ứng dụng. Thay đổi được áp dụng ngay lập tức mà không cần khởi động lại."
        )
        lang_desc.setStyleSheet("font-size: 12px; color: #8b949e;")
        lang_desc.setWordWrap(True)
        lang_desc.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        lang_text_col.addWidget(lang_desc)

        lang_card_layout.addLayout(lang_text_col, 1)

        self.language_combo = QComboBox()
        self.language_combo.setProperty("_i18n_skip", True)
        self.language_combo.setView(QListView(self.language_combo))
        self.language_combo.setIconSize(QSize(22, 16))
        self.language_combo.setFixedSize(220, 38)
        self.language_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.language_combo.setStyleSheet(STEAM_COMBO_STYLE)
        for lang_code in SUPPORTED_LANGUAGES:
            self.language_combo.addItem(get_flag_icon(lang_code, 22), LANGUAGE_LABELS[lang_code], lang_code)
        self._refresh_language_combo(self.config.get("language", current_language()))
        self.language_combo.currentIndexChanged.connect(self._on_language_combo_changed)
        lang_card_layout.addWidget(
            self.language_combo, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        )

        content_layout.addWidget(self.language_card)

        # 1. Card: Nguồn cửa hàng game (Kho Game) — placed below Language card
        self.stores_card = self._create_card("Nguồn cửa hàng game (Kho Game)", "store")
        stores_card_layout = QVBoxLayout(self.stores_card)
        stores_card_layout.setContentsMargins(20, 16, 20, 20)
        stores_card_layout.setSpacing(10)

        stores_label = QLabel("Nguồn cửa hàng game (Kho Game)")
        stores_label.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        stores_card_layout.addWidget(stores_label)

        stores_desc = QLabel(
            "Chọn các cửa hàng game được phép tải dữ liệu danh mục và tải game trong Kho Game "
            "(bắt buộc bật ít nhất 1 nguồn)."
        )
        stores_desc.setStyleSheet("font-size: 12px; color: #8b949e;")
        stores_desc.setWordWrap(True)
        stores_card_layout.addWidget(stores_desc)

        enabled_stores = set(normalize_enabled_stores(self.config.get("enabled_game_stores")))
        for src_id, src_label in STORE_SETTING_OPTIONS:
            cb = QCheckBox(src_label)
            cb.setStyleSheet("font-size: 13px; font-weight: 600; color: #e6edf3; padding-left: 4px;")
            cb.setChecked(src_id in enabled_stores)
            cb.toggled.connect(lambda checked, s=src_id: self._on_store_checkbox_toggled(s, checked))
            stores_card_layout.addWidget(cb)
            self.store_checkboxes[src_id] = cb

        content_layout.addWidget(self.stores_card)

        # 2. Card: Kênh cập nhật ứng dụng (Steam-style horizontal row + dropdown)
        self.update_channel_card = self._create_card("Kênh cập nhật ứng dụng", "sync")
        channel_card_layout = QHBoxLayout(self.update_channel_card)
        channel_card_layout.setContentsMargins(20, 16, 20, 16)
        channel_card_layout.setSpacing(20)

        channel_text_col = QVBoxLayout()
        channel_text_col.setSpacing(4)

        channel_title = QLabel("Kênh cập nhật ứng dụng")
        channel_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        channel_text_col.addWidget(channel_title)

        channel_desc = QLabel(
            "Chọn kênh nhận bản cập nhật tự động. Chuyển sang Release Candidates để nhận sớm các bản "
            "thử nghiệm từ /release-candidates/*, hoặc chọn lại Stable để dùng bản chính thức ổn định."
        )
        channel_desc.setStyleSheet("font-size: 12px; color: #8b949e;")
        channel_desc.setWordWrap(True)
        channel_desc.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        channel_text_col.addWidget(channel_desc)

        self.channel_status_label = QLabel("")
        self.channel_status_label.setWordWrap(True)
        self.channel_status_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        channel_text_col.addWidget(self.channel_status_label)

        channel_card_layout.addLayout(channel_text_col, 1)

        self.channel_combo = QComboBox()
        self.channel_combo.setView(QListView(self.channel_combo))
        self.channel_combo.setFixedSize(220, 38)
        self.channel_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.channel_combo.setStyleSheet(STEAM_COMBO_STYLE)
        self.channel_combo.addItem("Stable", updater.CHANNEL_STABLE)
        self.channel_combo.addItem("Release Candidates", updater.CHANNEL_RC)
        self._refresh_channel_combo(self.config.get("update_channel", updater.CHANNEL_STABLE))
        self.channel_combo.currentIndexChanged.connect(self._on_channel_combo_changed)
        channel_card_layout.addWidget(
            self.channel_combo, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        )

        content_layout.addWidget(self.update_channel_card)

        # 3. Card: Khởi động & Hệ thống
        sys_card = self._create_card("Hành vi & Khởi động Windows", "monitor")
        sys_card_layout = QVBoxLayout(sys_card)
        sys_card_layout.setContentsMargins(20, 16, 20, 20)
        sys_card_layout.setSpacing(12)

        self.auto_start_cb = QCheckBox("Tự động khởi động cùng Windows")
        self.auto_start_cb.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        self.auto_start_cb.setChecked(is_auto_start_enabled())
        sys_card_layout.addWidget(self.auto_start_cb)

        auto_start_desc = QLabel("Tự động kích hoạt Bob Gaming Game Center khi đăng nhập vào máy tính.")
        auto_start_desc.setStyleSheet("font-size: 12px; color: #8b949e; padding-left: 24px;")
        auto_start_desc.setWordWrap(True)
        sys_card_layout.addWidget(auto_start_desc)

        sys_card_layout.addSpacing(6)

        self.minimize_tray_cb = QCheckBox("Thu nhỏ xuống khay hệ thống khi đóng")
        self.minimize_tray_cb.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        self.minimize_tray_cb.setChecked(self.config.get("minimize_to_tray", True))
        sys_card_layout.addWidget(self.minimize_tray_cb)

        minimize_desc = QLabel("Khi bấm nút đóng [X], ứng dụng sẽ thu nhỏ xuống thanh tác vụ thay vì tắt hẳn.")
        minimize_desc.setStyleSheet("font-size: 12px; color: #8b949e; padding-left: 24px;")
        minimize_desc.setWordWrap(True)
        sys_card_layout.addWidget(minimize_desc)

        sys_card_layout.addSpacing(6)

        self.prevent_sleep_cb = QCheckBox("Giữ máy không ngủ khi đang tải và cài đặt game")
        self.prevent_sleep_cb.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        self.prevent_sleep_cb.setChecked(self.config.get("prevent_sleep_while_downloading", True))
        sys_card_layout.addWidget(self.prevent_sleep_cb)

        prevent_sleep_desc = QLabel(
            "Ngăn Steam Deck / máy tính tự chuyển sang chế độ ngủ trong lúc tải xuống, giải nén và cài đặt game; "
            "tự động cho phép máy ngủ lại sau khi tất cả game đã cài đặt xong."
        )
        prevent_sleep_desc.setStyleSheet("font-size: 12px; color: #8b949e; padding-left: 24px;")
        prevent_sleep_desc.setWordWrap(True)
        sys_card_layout.addWidget(prevent_sleep_desc)

        content_layout.addWidget(sys_card)

        # 4. Card: Thư viện Game
        lib_card = self._create_card("Quản lý Thư viện Game", "gamepad")
        lib_card_layout = QVBoxLayout(lib_card)
        lib_card_layout.setContentsMargins(20, 16, 20, 20)
        lib_card_layout.setSpacing(12)

        self.hide_steam_cb = QCheckBox("Ẩn trò chơi Steam trong thư viện")
        self.hide_steam_cb.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        self.hide_steam_cb.setChecked(self.config.get("hide_steam_games", True))
        lib_card_layout.addWidget(self.hide_steam_cb)

        hide_steam_desc = QLabel("Chỉ ẩn trò chơi mua từ Steam (do đã có Steam Cloud). Trò chơi Non-Steam thêm vào Steam hoặc game cài ngoài vẫn luôn hiển thị.")
        hide_steam_desc.setStyleSheet("font-size: 12px; color: #8b949e; padding-left: 24px;")
        hide_steam_desc.setWordWrap(True)
        lib_card_layout.addWidget(hide_steam_desc)

        lib_card_layout.addSpacing(6)

        self.auto_claim_steam_cb = QCheckBox("Tự động nhận game trả phí đang miễn phí 100% trên Steam")
        self.auto_claim_steam_cb.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        self.auto_claim_steam_cb.setChecked(self.config.get("auto_claim_steam_free_games", True))
        lib_card_layout.addWidget(self.auto_claim_steam_cb)

        auto_claim_steam_desc = QLabel(
            "Quét ngầm mỗi 1 giờ để tìm game và DLC trả phí đang giảm 100% về 0đ "
            "(giữ vĩnh viễn, bỏ qua game Free-to-Play) rồi tự thêm vào tài khoản Steam đang mở trên máy."
        )
        auto_claim_steam_desc.setStyleSheet("font-size: 12px; color: #8b949e; padding-left: 24px;")
        auto_claim_steam_desc.setWordWrap(True)
        lib_card_layout.addWidget(auto_claim_steam_desc)

        lib_card_layout.addSpacing(8)

        install_dir_label = QLabel("Thư mục cài đặt game mặc định")
        install_dir_label.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        lib_card_layout.addWidget(install_dir_label)

        install_dir_desc = QLabel("Thư mục lưu trữ các game tải về từ Kho Game / Tải Game.")
        install_dir_desc.setStyleSheet("font-size: 12px; color: #8b949e;")
        lib_card_layout.addWidget(install_dir_desc)

        dir_row = QHBoxLayout()
        dir_row.setSpacing(8)

        from app.core.online_fix.manager import get_online_fix_manager
        current_install_root = self.config.get("online_fix_install_root", "") or get_online_fix_manager().get_install_root()

        self.install_dir_input = QLineEdit(current_install_root)
        self.install_dir_input.setFixedHeight(36)
        self.install_dir_input.setStyleSheet("""
            QLineEdit {
                background: rgba(13, 17, 23, 0.8);
                color: #e6edf3;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 6px;
                padding: 0 10px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #3b82f6;
            }
        """)
        dir_row.addWidget(self.install_dir_input, 1)

        browse_btn = QPushButton("Chọn…")
        browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        browse_btn.setFixedHeight(36)
        browse_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.08);
                color: #e6edf3;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 6px;
                padding: 0 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.15);
            }
        """)
        browse_btn.clicked.connect(self._on_browse_install_dir)
        dir_row.addWidget(browse_btn)

        lib_card_layout.addLayout(dir_row)

        content_layout.addWidget(lib_card)

        # 4b. Card: Giả lập Android (Android Emulator)
        android_card = self._create_card("Giả lập Android (Android Emulator)", "android")
        android_lay = QVBoxLayout(android_card)
        android_lay.setContentsMargins(20, 16, 20, 20)
        android_lay.setSpacing(12)

        android_title = QLabel("Giả lập Android (Android Runtime & Kho Game Android)")
        android_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        android_lay.addWidget(android_title)

        from app.core.android.manager import get_android_manager
        from app.core.android.runtime import get_emulator_hardware_options, get_emulator_settings

        current_android_root = self.config.get("android_install_root", "") or get_android_manager().get_install_root()
        self.android_paths_desc = QLabel()
        self.android_paths_desc.setStyleSheet("font-size: 12px; color: #8b949e;")
        self.android_paths_desc.setWordWrap(True)
        android_lay.addWidget(self.android_paths_desc)

        android_dir_row = QHBoxLayout()
        android_dir_row.setSpacing(8)

        self.android_dir_input = QLineEdit(current_android_root)
        self.android_dir_input.setFixedHeight(36)
        self.android_dir_input.setStyleSheet(self.install_dir_input.styleSheet())
        self.android_dir_input.textChanged.connect(self._refresh_android_subpaths_label)
        android_dir_row.addWidget(self.android_dir_input, 1)

        android_browse_btn = QPushButton("Chọn...")
        android_browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        android_browse_btn.setFixedHeight(36)
        android_browse_btn.setStyleSheet(browse_btn.styleSheet())
        android_browse_btn.clicked.connect(self._on_browse_android_dir)
        android_dir_row.addWidget(android_browse_btn)

        android_open_btn = QPushButton("Mở thư mục")
        android_open_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        android_open_btn.setFixedHeight(36)
        android_open_btn.setStyleSheet(browse_btn.styleSheet())
        android_open_btn.clicked.connect(self._on_open_android_dir)
        android_dir_row.addWidget(android_open_btn)

        android_lay.addLayout(android_dir_row)
        self._refresh_android_subpaths_label(current_android_root)

        hw_cfg = get_emulator_settings(self.config)
        hw_grid = QHBoxLayout()
        hw_grid.setSpacing(12)

        def _make_hw_col(label_txt: str, options: list[tuple[str, object]], cur_val: object) -> QComboBox:
            col = QVBoxLayout()
            col.setSpacing(4)
            lbl = QLabel(label_txt)
            lbl.setStyleSheet("font-size: 12px; font-weight: 600; color: #cbd5e1;")
            col.addWidget(lbl)
            cb = QComboBox()
            cb.setView(QListView(cb))
            cb.setFixedHeight(36)
            cb.setCursor(Qt.CursorShape.PointingHandCursor)
            cb.setStyleSheet(STEAM_COMBO_STYLE)
            sel = 0
            for idx, (opt_label, opt_data) in enumerate(options):
                cb.addItem(opt_label, opt_data)
                if opt_data == cur_val:
                    sel = idx
            cb.setCurrentIndex(sel)
            col.addWidget(cb)
            hw_grid.addLayout(col, 1)
            return cb

        cpu_opts, ram_opts = get_emulator_hardware_options()
        valid_cpu_vals = {val for _lbl, val in cpu_opts}
        raw_cpu = int(self.config.get("android_cpu_cores") or 0)
        self.android_cpu_combo = _make_hw_col(
            "Số nhân CPU",
            cpu_opts,
            raw_cpu if raw_cpu in valid_cpu_vals else 0,
        )
        valid_ram_vals = {val for _lbl, val in ram_opts}
        raw_ram = int(self.config.get("android_ram_mb") or 0)
        self.android_ram_combo = _make_hw_col(
            "Dung lượng RAM",
            ram_opts,
            raw_ram if raw_ram in valid_ram_vals else 0,
        )
        self.android_res_combo = _make_hw_col(
            "Độ phân giải",
            [
                ("720x1280 (HD Dọc · Nhẹ)", "720x1280"),
                ("900x1600 (HD+ Dọc)", "900x1600"),
                ("1080x1920 (Full HD Dọc)", "1080x1920"),
            ],
            hw_cfg["resolution"],
        )
        self.android_fps_combo = _make_hw_col(
            "Giới hạn FPS",
            [("60 FPS", 60), ("90 FPS", 90), ("120 FPS", 120)],
            hw_cfg["fps"],
        )
        guard_scroll_wheel(
            self.language_combo,
            self.channel_combo,
            self.android_cpu_combo,
            self.android_ram_combo,
            self.android_res_combo,
            self.android_fps_combo,
        )
        android_lay.addLayout(hw_grid)

        hw_hint = QLabel(
            "Thay đổi CPU / RAM / Độ phân giải / FPS sẽ tự động áp dụng vào lần khởi động máy ảo Android tiếp theo."
        )
        hw_hint.setStyleSheet("font-size: 11px; color: #64748b;")
        hw_hint.setWordWrap(True)
        android_lay.addWidget(hw_hint)

        content_layout.addWidget(android_card)

        # 5. Card: Tích hợp Steam Deck
        deck_card = self._create_card("Tích hợp Steam Deck", "gamepad")
        deck_card_layout = QVBoxLayout(deck_card)
        deck_card_layout.setContentsMargins(20, 16, 20, 20)
        deck_card_layout.setSpacing(12)

        deck_title = QLabel("Tích hợp Steam Deck (Desktop & Game Mode)")
        deck_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        deck_card_layout.addWidget(deck_title)

        deck_desc = QLabel(
            "Tự động tạo lối tắt trên màn hình Desktop Mode (.desktop) và đăng ký "
            "Bob Game Center vào thư viện Steam để khởi chạy thuận tiện từ Game Mode."
        )
        deck_desc.setStyleSheet("font-size: 12px; color: #8b949e;")
        deck_desc.setWordWrap(True)
        deck_card_layout.addWidget(deck_desc)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)

        self.deck_setup_btn = QPushButton("Cài đặt biểu tượng && Game Mode")
        self.deck_setup_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.deck_setup_btn.setFixedHeight(36)
        self.deck_setup_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(59, 130, 246, 0.2);
                color: #60a5fa;
                border: 1px solid rgba(59, 130, 246, 0.4);
                border-radius: 6px;
                font-weight: bold;
                padding: 0 16px;
            }
            QPushButton:hover {
                background-color: rgba(59, 130, 246, 0.35);
                border-color: rgba(59, 130, 246, 0.7);
            }
            QPushButton:disabled {
                background-color: rgba(255, 255, 255, 0.05);
                color: #64748b;
                border-color: rgba(255, 255, 255, 0.1);
            }
        """)
        self.deck_setup_btn.clicked.connect(self._on_deck_setup_clicked)
        btn_row.addWidget(self.deck_setup_btn, 0, Qt.AlignmentFlag.AlignLeft)

        self.deck_status_label = QLabel("")
        self.deck_status_label.setStyleSheet("font-size: 12px; color: #94a3b8;")
        btn_row.addWidget(self.deck_status_label, 1)

        deck_card_layout.addLayout(btn_row)
        content_layout.addWidget(deck_card)

        # 5b. Card: Debug — Kiểm tra thông báo hệ thống
        self.debug_card = self._create_card("Debug", "terminal")
        debug_card_layout = QVBoxLayout(self.debug_card)
        debug_card_layout.setContentsMargins(20, 16, 20, 20)
        debug_card_layout.setSpacing(10)

        debug_title = QLabel("Debug — Kiểm tra thông báo")
        debug_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #e6edf3;")
        debug_card_layout.addWidget(debug_title)

        debug_desc = QLabel(
            "Kiểm tra cổng chặn thông báo khi ứng dụng đang hiển thị ở tiền cảnh "
            "(bao gồm chế độ Game Mode trên Steam Deck)."
        )
        debug_desc.setStyleSheet("font-size: 12px; color: #8b949e;")
        debug_desc.setWordWrap(True)
        debug_card_layout.addWidget(debug_desc)

        self.notify_debug_status_label = QLabel("")
        self.notify_debug_status_label.setWordWrap(True)
        debug_card_layout.addWidget(self.notify_debug_status_label)

        self.force_notify_test_cb = QCheckBox("Buộc hiện khi test")
        self.force_notify_test_cb.setStyleSheet("font-size: 13px; font-weight: 600; color: #e6edf3;")
        self.force_notify_test_cb.toggled.connect(self._on_force_notify_toggled)
        debug_card_layout.addWidget(self.force_notify_test_cb)

        notify_btn_row = QHBoxLayout()
        notify_btn_row.setSpacing(12)

        self.test_notify_btn = QPushButton("Test notification")
        self.test_notify_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.test_notify_btn.setFixedHeight(36)
        self.test_notify_btn.setStyleSheet(self.deck_setup_btn.styleSheet())
        self.test_notify_btn.clicked.connect(self._on_test_notification_clicked)
        notify_btn_row.addWidget(self.test_notify_btn, 0, Qt.AlignmentFlag.AlignLeft)

        self.notify_test_result_label = QLabel("")
        self.notify_test_result_label.setStyleSheet("font-size: 12px; color: #94a3b8;")
        self.notify_test_result_label.setWordWrap(True)
        notify_btn_row.addWidget(self.notify_test_result_label, 1)

        debug_card_layout.addLayout(notify_btn_row)
        self._refresh_notify_debug_status()
        content_layout.addWidget(self.debug_card)

        # 6. Card: Bảo trì & Khôi phục gốc
        maint_card = self._create_card("Bảo trì & Khôi phục gốc", "warning")
        maint_card_layout = QVBoxLayout(maint_card)
        maint_card_layout.setContentsMargins(20, 16, 20, 20)
        maint_card_layout.setSpacing(12)

        reset_info = QLabel("Khôi phục toàn bộ cài đặt ứng dụng, xóa phiên đăng nhập và dữ liệu tạm về mặc định ban đầu.")
        reset_info.setStyleSheet("font-size: 12px; color: #94a3b8;")
        reset_info.setWordWrap(True)
        maint_card_layout.addWidget(reset_info)

        reset_btn = QPushButton("Khôi phục cài đặt gốc (Factory Reset)")
        reset_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        reset_btn.setFixedHeight(36)
        reset_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(220, 38, 38, 0.15);
                color: #f87171;
                border: 1px solid rgba(239, 68, 68, 0.4);
                border-radius: 6px;
                font-weight: bold;
                padding: 0 16px;
            }
            QPushButton:hover {
                background-color: rgba(220, 38, 38, 0.3);
                border-color: rgba(239, 68, 68, 0.7);
            }
        """)
        reset_btn.clicked.connect(self._on_reset_clicked)
        maint_card_layout.addWidget(reset_btn, 0, Qt.AlignmentFlag.AlignLeft)

        content_layout.addWidget(maint_card)

        content_layout.addStretch()
        scroll.setWidget(content_widget)
        main_layout.addWidget(scroll)

    def _create_card(self, title_text: str, icon_name: str) -> QFrame:
        card = QFrame()
        card.setObjectName("settingsCard")
        card.setStyleSheet("""
            #settingsCard {
                background-color: rgba(18, 22, 34, 0.7);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 12px;
            }
            #settingsCard QLabel {
                border: none;
                background: transparent;
            }
        """)
        return card

    def _refresh_channel_combo(self, channel: str | None):
        ch = updater.normalize_channel(channel)
        idx = self.channel_combo.findData(ch)
        if idx < 0:
            idx = 0
        self.channel_combo.blockSignals(True)
        try:
            self.channel_combo.setCurrentIndex(idx)
        finally:
            self.channel_combo.blockSignals(False)

        if ch == updater.CHANNEL_RC:
            self.channel_status_label.setText(
                f"Phiên bản hiện tại: v{updater.APP_VERSION} — Đang theo dõi kênh Release Candidates (/release-candidates/*)."
            )
            self.channel_status_label.setStyleSheet("font-size: 12px; color: #fbbf24;")
        else:
            self.channel_status_label.setText(
                f"Phiên bản hiện tại: v{updater.APP_VERSION} — Đang theo dõi kênh Stable (Bản chính thức ổn định)."
            )
            self.channel_status_label.setStyleSheet("font-size: 12px; color: #64748b;")

    def _on_channel_combo_changed(self, _index: int):
        self._select_update_channel(str(self.channel_combo.currentData() or updater.CHANNEL_STABLE))

    def _select_update_channel(self, channel: str):
        try:
            target = updater.normalize_channel(channel)
            current = updater.normalize_channel(self.config.get("update_channel", updater.CHANNEL_STABLE))
            self._refresh_channel_combo(target)
            if target == current:
                return
            self.config["update_channel"] = target
            self.config["skipped_version"] = ""
            save_config(self.config)
            logger.info(f"{TAG} Update channel selected: {current} -> {target}")
            self._flash_saved()
            self.update_channel_changed.emit(target)
        except Exception as e:
            logger.error(f"{TAG} Failed to switch update channel to {channel!r}: {e}", exc_info=True)
            QMessageBox.critical(self, "Cài đặt", f"Không thể đổi kênh cập nhật: {e}")

    def _refresh_language_combo(self, lang: str | None) -> None:
        code = normalize_language(lang, default=current_language())
        idx = self.language_combo.findData(code)
        if idx < 0:
            idx = 0
        self.language_combo.blockSignals(True)
        try:
            self.language_combo.setCurrentIndex(idx)
        finally:
            self.language_combo.blockSignals(False)

    def _on_language_combo_changed(self, _index: int) -> None:
        if self._loading_settings:
            return
        self._select_language(str(self.language_combo.currentData() or current_language()))

    def _select_language(self, lang: str) -> None:
        try:
            target = normalize_language(lang, default=current_language())
            current = normalize_language(self.config.get("language", current_language()))
            self._refresh_language_combo(target)
            if target == current and target == current_language():
                return
            self.config["language"] = target
            save_config(self.config)
            set_language(target)
            self.retranslate_ui()
            logger.info(f"{TAG} Language selected: {current} -> {target}")
            self._flash_saved()
            self.language_changed.emit(target)
            self.settings_changed.emit(self.config)
        except Exception as e:
            logger.error(f"{TAG} Failed to switch language to {lang!r}: {e}", exc_info=True)
            QMessageBox.critical(self, "Cài đặt", f"Không thể đổi ngôn ngữ: {e}")

    def retranslate_ui(self) -> None:
        """Refresh composite dynamic labels when the active language changes."""
        self._refresh_channel_combo(self.config.get("update_channel", updater.CHANNEL_STABLE))
        self._refresh_android_subpaths_label(self.android_dir_input.text())
        self._refresh_notify_debug_status()

    def _on_back(self):
        self.back_requested.emit()

    def selected_stores(self) -> list[str]:
        chosen = [s for s in ALL_STORE_SOURCES if s in self.store_checkboxes and self.store_checkboxes[s].isChecked()]
        return chosen if chosen else normalize_enabled_stores(self.config.get("enabled_game_stores"))

    def _wire_auto_save(self) -> None:
        for cb in (
            self.auto_start_cb,
            self.minimize_tray_cb,
            self.prevent_sleep_cb,
            self.hide_steam_cb,
            self.auto_claim_steam_cb,
        ):
            cb.toggled.connect(self._on_auto_save)
        for combo in (
            self.android_cpu_combo,
            self.android_ram_combo,
            self.android_res_combo,
            self.android_fps_combo,
        ):
            combo.currentIndexChanged.connect(self._on_auto_save)
        self.install_dir_input.editingFinished.connect(self._on_dir_editing_finished)
        self.android_dir_input.editingFinished.connect(self._on_dir_editing_finished)

    def _on_dir_editing_finished(self) -> None:
        if self._loading_settings:
            return
        raw_install = self.install_dir_input.text().strip()
        raw_android = self.android_dir_input.text().strip()
        cur_install = os.path.normpath(raw_install) if raw_install else ""
        cur_android = os.path.normpath(raw_android) if raw_android else ""
        changed = (
            self.install_dir_input.isModified()
            or self.android_dir_input.isModified()
            or (bool(cur_install) and cur_install != self.config.get("online_fix_install_root", ""))
            or (bool(cur_android) and cur_android != self.config.get("android_install_root", ""))
        )
        self.install_dir_input.setModified(False)
        self.android_dir_input.setModified(False)
        if changed:
            self._on_auto_save()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._notify_status_timer.start()
        app_inst = QGuiApplication.instance()
        if app_inst is not None and not self._app_state_connected:
            try:
                app_inst.applicationStateChanged.connect(
                    self._on_app_state_changed, Qt.ConnectionType.UniqueConnection
                )
                self._app_state_connected = True
            except Exception:
                pass
        self._refresh_notify_debug_status()

    def hideEvent(self, event) -> None:
        self._notify_status_timer.stop()
        app_inst = QGuiApplication.instance()
        if app_inst is not None and self._app_state_connected:
            self._app_state_connected = False
            try:
                app_inst.applicationStateChanged.disconnect(self._on_app_state_changed)
            except Exception:
                pass
        self._on_dir_editing_finished()
        super().hideEvent(event)

    def _on_app_state_changed(self, _state) -> None:
        self._refresh_notify_debug_status()

    def _on_force_notify_toggled(self, _checked: bool) -> None:
        self._refresh_notify_debug_status()

    def _resolve_notify_window(self) -> QWidget:
        main_win = notifications.get_main_window()
        if main_win is not None:
            return main_win
        return self.window()

    def _refresh_notify_debug_status(self) -> None:
        try:
            win = self._resolve_notify_window()
            is_active_fg = notifications.app_is_foreground(window=win)
            force_checked = self.force_notify_test_cb.isChecked()
            if is_active_fg:
                if force_checked:
                    text = "App đang active → notification sẽ bị chặn (đang bật buộc hiện khi test)"
                else:
                    text = "App đang active → notification sẽ bị chặn"
                style = "font-size: 12px; font-weight: 600; color: #fbbf24;"
            else:
                text = "App đang ẩn/minimized → notification sẽ hiện"
                style = "font-size: 12px; font-weight: 600; color: #4ade80;"
            if getattr(self.notify_debug_status_label, "_i18n_src_text", None) != text:
                self.notify_debug_status_label.setText(text)
            if self.notify_debug_status_label.styleSheet() != style:
                self.notify_debug_status_label.setStyleSheet(style)
        except RuntimeError:
            return

    def _on_test_notification_clicked(self) -> None:
        try:
            win = self._resolve_notify_window()
            force = self.force_notify_test_cb.isChecked()
            tray = getattr(self, "tray_icon", None) or getattr(win, "tray_icon", None)
            is_active_fg = notifications.app_is_foreground(window=win)
            logger.info(
                f"{TAG} User triggered test notification (force={force}, app_is_foreground={is_active_fg})"
            )
            sent = notifications.notify_user(
                APP_NAME,
                "Thông báo thử nghiệm từ mục Debug trong Cài đặt hệ thống.",
                kind="debug_test",
                icon=QSystemTrayIcon.MessageIcon.Information,
                duration_ms=4000,
                tray_icon=tray,
                window=win,
                force=force,
            )
            self._refresh_notify_debug_status()
            if sent:
                if force and is_active_fg:
                    self.notify_test_result_label.setText(
                        "Đã phát thông báo thử nghiệm (buộc hiện khi app đang active)."
                    )
                else:
                    self.notify_test_result_label.setText("Đã phát thông báo thử nghiệm qua khay hệ thống.")
                self.notify_test_result_label.setStyleSheet("font-size: 12px; color: #4ade80;")
            elif is_active_fg and not force:
                self.notify_test_result_label.setText(
                    "Đã chặn thông báo thử nghiệm do app đang active."
                )
                self.notify_test_result_label.setStyleSheet("font-size: 12px; color: #fbbf24;")
            else:
                self.notify_test_result_label.setText(
                    "Không thể hiển thị thông báo (khay hệ thống chưa sẵn sàng)."
                )
                self.notify_test_result_label.setStyleSheet("font-size: 12px; color: #f87171;")
        except Exception as exc:
            logger.error(f"{TAG} Error running test notification: {exc}", exc_info=True)
            self.notify_test_result_label.setText(f"Lỗi kiểm tra thông báo: {exc}")
            self.notify_test_result_label.setStyleSheet("font-size: 12px; color: #f87171;")

    def _flash_saved(self, text: str = "Đã lưu cấu hình") -> None:
        self.save_badge.set_state(text, "ok")
        self.save_badge.show()
        self._saved_hide_timer.start()

    def _hide_saved_badge(self) -> None:
        self.save_badge.hide()

    def _on_auto_save(self, *_args) -> None:
        if self._loading_settings or self._syncing_store_cbs:
            return
        self._save_settings()

    def sync_config(self, config: dict):
        """Refresh UI controls from the latest MainWindow config."""
        self._loading_settings = True
        try:
            self.config = config.copy()
            self.minimize_tray_cb.setChecked(self.config.get("minimize_to_tray", True))
            self.prevent_sleep_cb.setChecked(self.config.get("prevent_sleep_while_downloading", True))
            self.hide_steam_cb.setChecked(self.config.get("hide_steam_games", True))
            self.auto_claim_steam_cb.setChecked(self.config.get("auto_claim_steam_free_games", True))
            self._refresh_language_combo(self.config.get("language", current_language()))
            self._refresh_channel_combo(self.config.get("update_channel", updater.CHANNEL_STABLE))
            install_root = self.config.get("online_fix_install_root", "")
            if install_root:
                self.install_dir_input.setText(install_root)
            from app.core.android.manager import get_android_manager
            from app.core.android.runtime import get_emulator_settings

            android_root = self.config.get("android_install_root", "") or get_android_manager().get_install_root()
            if android_root:
                self.android_dir_input.setText(android_root)
            hw_cfg = get_emulator_settings(self.config)
            for combo, val in (
                (self.android_cpu_combo, int(self.config.get("android_cpu_cores") or 0)),
                (self.android_ram_combo, int(self.config.get("android_ram_mb") or 0)),
                (self.android_res_combo, hw_cfg["resolution"]),
                (self.android_fps_combo, hw_cfg["fps"]),
            ):
                idx = combo.findData(val)
                combo.setCurrentIndex(idx if idx >= 0 else 0)
            enabled = set(normalize_enabled_stores(self.config.get("enabled_game_stores")))
            self._syncing_store_cbs = True
            try:
                for src_id, cb in self.store_checkboxes.items():
                    cb.setChecked(src_id in enabled)
            finally:
                self._syncing_store_cbs = False
        finally:
            self._loading_settings = False

    def _on_store_checkbox_toggled(self, source: str, checked: bool):
        if self._syncing_store_cbs or self._loading_settings:
            return
        try:
            if not checked and not any(cb.isChecked() for cb in self.store_checkboxes.values()):
                self._syncing_store_cbs = True
                try:
                    self.store_checkboxes[source].setChecked(True)
                finally:
                    self._syncing_store_cbs = False
                logger.warning(f"{TAG} Refused disabling {source!r}: at least 1 game store must remain enabled")
                QMessageBox.warning(
                    self,
                    "Cài đặt Kho Game",
                    "Cần bật ít nhất 1 nguồn cửa hàng game để sử dụng Kho Game.",
                )
                return
            logger.info(f"{TAG} Store option {source!r} toggled -> {checked} (selected={self.selected_stores()})")
            self._save_settings()
        except Exception as e:
            logger.error(f"{TAG} Unexpected error toggling store checkbox {source!r}: {e}", exc_info=True)

    def _on_save(self):
        self._save_settings()

    def _save_settings(self):
        try:
            new_auto_start = self.auto_start_cb.isChecked()
            new_minimize_tray = self.minimize_tray_cb.isChecked()
            new_prevent_sleep = self.prevent_sleep_cb.isChecked()
            new_hide_steam = self.hide_steam_cb.isChecked()

            old_auto_start = is_auto_start_enabled()
            if new_auto_start != old_auto_start:
                set_auto_start(new_auto_start)

            self.config["auto_start"] = new_auto_start
            self.config["minimize_to_tray"] = new_minimize_tray
            self.config["prevent_sleep_while_downloading"] = new_prevent_sleep
            self.config["hide_steam_games"] = new_hide_steam
            self.config["auto_claim_steam_free_games"] = self.auto_claim_steam_cb.isChecked()
            self.config["language"] = normalize_language(
                self.language_combo.currentData() or self.config.get("language", current_language())
            )
            self.config["update_channel"] = updater.normalize_channel(
                self.channel_combo.currentData() or self.config.get("update_channel", updater.CHANNEL_STABLE)
            )

            chosen_stores = normalize_enabled_stores(self.selected_stores())
            try:
                from app.core.online_fix.manager import get_online_fix_manager
                chosen_stores = get_online_fix_manager().save_enabled_stores(chosen_stores)
            except Exception as e:
                logger.warning(f"{TAG} Could not persist enabled_game_stores via manager: {e}")
            self.config["enabled_game_stores"] = chosen_stores

            new_install_root = self.install_dir_input.text().strip()
            if new_install_root:
                new_install_root = os.path.normpath(new_install_root)
                self.config["online_fix_install_root"] = new_install_root
                try:
                    from app.core.online_fix.manager import get_online_fix_manager
                    get_online_fix_manager().save_install_root(new_install_root)
                except Exception as e:
                    logger.warning(f"{TAG} Could not save online fix install root: {e}")

            new_android_root = self.android_dir_input.text().strip()
            if new_android_root:
                from app.core.android.manager import get_android_manager
                from app.core.android.models import is_valid_android_root

                if not is_valid_android_root(new_android_root):
                    QMessageBox.warning(
                        self,
                        "Thư mục Android không hợp lệ",
                        "Không được chọn thư mục cấu hình Bob Gaming hoặc gốc ổ đĩa hệ thống. Hãy chọn thư mục lưu game riêng (vd: O:\\Games).",
                    )
                    return
                norm_android = os.path.normpath(new_android_root)
                self.config["android_install_root"] = norm_android
                get_android_manager().set_install_root(norm_android)
            self.config["android_cpu_cores"] = int(self.android_cpu_combo.currentData() or 0)
            self.config["android_ram_mb"] = int(self.android_ram_combo.currentData() or 0)
            self.config["android_resolution"] = str(self.android_res_combo.currentData() or "1280x720")
            self.config["android_fps"] = int(self.android_fps_combo.currentData() or 60)
            try:
                from app.core.android.manager import get_android_manager
                from app.core.android.models import get_runtime_dir
                from app.core.android.runtime import sync_avd_hardware_settings

                sync_avd_hardware_settings(get_runtime_dir(get_android_manager().get_install_root()), cfg=self.config)
            except Exception as e:
                logger.warning(f"{TAG} Could not sync AVD hardware config: {e}")

            save_config(self.config)
            logger.info(
                f"{TAG} Saved system settings (enabled_game_stores={chosen_stores}, "
                f"update_channel={self.config['update_channel']}, "
                f"hide_steam={new_hide_steam}, minimize_to_tray={new_minimize_tray}, "
                f"prevent_sleep={new_prevent_sleep})"
            )

            self.settings_changed.emit(self.config)
            self._flash_saved()
        except Exception as e:
            logger.error(f"{TAG} Failed to save settings: {e}", exc_info=True)
            QMessageBox.critical(self, "Cài đặt", f"Không thể lưu cài đặt hệ thống: {e}")

    def _refresh_android_subpaths_label(self, raw_root: str) -> None:
        base = os.path.normpath((raw_root or "").strip()) if (raw_root or "").strip() else ""
        if base:
            rt_p = os.path.join(base, "AndroidRuntime")
            apps_p = os.path.join(base, "AndroidApps")
            self.android_paths_desc.setText(
                f"Máy ảo Android cài tại: {rt_p}  ·  Game APK/XAPK/OBB lưu tại: {apps_p}"
            )
        else:
            self.android_paths_desc.setText("Chọn thư mục ổ đĩa lưu máy ảo AndroidRuntime và kho game AndroidApps.")

    def _on_browse_android_dir(self) -> None:
        chosen = QFileDialog.getExistingDirectory(
            self, "Chọn thư mục lưu Android Emulator & Game", self.android_dir_input.text().strip()
        )
        if chosen:
            self.android_dir_input.setText(os.path.normpath(chosen))
            self._on_auto_save()

    def _on_open_android_dir(self) -> None:
        target = os.path.normpath(self.android_dir_input.text().strip())
        if not target:
            return
        os.makedirs(target, exist_ok=True)
        try:
            from PySide6.QtCore import QUrl
            from PySide6.QtGui import QDesktopServices

            QDesktopServices.openUrl(QUrl.fromLocalFile(target))
        except Exception as exc:
            logger.warning(f"{TAG} Could not open Android directory {target}: {exc}")

    def _on_browse_install_dir(self):
        chosen = QFileDialog.getExistingDirectory(self, "Chọn thư mục cài đặt game", self.install_dir_input.text().strip())
        if chosen:
            self.install_dir_input.setText(os.path.normpath(chosen))
            self._on_auto_save()

    def _on_reset_clicked(self):
        reply = QMessageBox.warning(
            self,
            "Xác nhận khôi phục cài đặt gốc",
            "Toàn bộ cấu hình tài khoản đám mây, ánh xạ phím và cài đặt sẽ bị xóa.\n"
            "Ứng dụng sẽ tự động khởi động lại.\n\nBạn có chắc chắn muốn tiếp tục?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.reset_requested.emit()

    def _on_deck_setup_clicked(self):
        try:
            self.deck_setup_btn.setEnabled(False)
            self.deck_status_label.setText("Đang cài đặt biểu tượng và Game Mode...")
            self.deck_status_label.setStyleSheet("font-size: 12px; color: #60a5fa;")

            from PySide6.QtCore import QThread
            from app.ui.workers import SteamDeckSetupWorker

            self._deck_thread = QThread(self)
            self._deck_worker = SteamDeckSetupWorker()
            self._deck_worker.moveToThread(self._deck_thread)

            self._deck_thread.started.connect(self._deck_worker.run)
            self._deck_worker.finished.connect(self._on_deck_setup_finished)
            self._deck_worker.finished.connect(self._deck_thread.quit)
            self._deck_worker.finished.connect(self._deck_worker.deleteLater)
            self._deck_thread.finished.connect(self._deck_thread.deleteLater)

            self._deck_thread.start()
        except Exception as exc:
            logger.error(f"{TAG} Failed to start Steam Deck setup worker: {exc}", exc_info=True)
            self.deck_setup_btn.setEnabled(True)
            self.deck_status_label.setText(f"Lỗi khởi chạy tiến trình: {exc}")
            self.deck_status_label.setStyleSheet("font-size: 12px; color: #f87171;")

    def _on_deck_setup_finished(self, result: dict):
        self.deck_setup_btn.setEnabled(True)
        if result.get("success"):
            self.deck_status_label.setText("Đã cài đặt thành công lối tắt Desktop và Game Mode!")
            self.deck_status_label.setStyleSheet("font-size: 12px; color: #4ade80;")
        else:
            msg = result.get("message", "Thất bại không rõ nguyên nhân")
            self.deck_status_label.setText(f"Cài đặt thất bại: {msg}")
            self.deck_status_label.setStyleSheet("font-size: 12px; color: #f87171;")
