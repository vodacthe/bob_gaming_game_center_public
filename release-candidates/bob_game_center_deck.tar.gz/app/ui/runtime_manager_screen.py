"""
Game Runtime & Proton Prefix Dependencies Screen for Bob Gaming Game Center.
Installs Microsoft Visual C++ 2015-2022 (x64/x86), DirectX Jun 2010, .NET, OpenAL,
and game-bundled prerequisites (e.g. UEPrereqSetup_x64.exe) directly into a game's
Steam Proton prefix on Steam Deck / Linux or onto Windows.
"""

from __future__ import annotations

import functools
import inspect
import logging
import os
import sys
import threading
import time

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from shiboken6 import isValid

from app.core.game_runtimes import (
    RUNTIME_CATALOG,
    RuntimeGameTarget,
    RuntimeInstallError,
    detect_installed_runtimes,
    install_custom_executable,
    install_runtime_package,
    list_runtime_targets,
)
from app.ui.game_card import DARK_BTN_STYLE, GREEN_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader

logger = logging.getLogger(__name__)
TAG = "[Runtime/UI]"

_running_tasks: set = set()
_running_lock = threading.Lock()
_quit_hooked = False


def _stop_all_tasks_on_quit() -> None:
    with _running_lock:
        tasks = list(_running_tasks)
    for t in tasks:
        t.cancel()
    for t in tasks:
        if not t.wait(3000):
            logger.warning(f"{TAG} runtime task {t.label!r} still running at exit")


def _hook_quit() -> None:
    global _quit_hooked
    app = QApplication.instance()
    if app is not None and not _quit_hooked:
        app.aboutToQuit.connect(_stop_all_tasks_on_quit)
        _quit_hooked = True


def _safe(func):
    """Slot guard: logs unexpected exceptions and surfaces them in the status bar instead of crashing Qt."""
    params = [p for p in inspect.signature(func).parameters.values()][1:]
    accepts_varargs = any(p.kind is inspect.Parameter.VAR_POSITIONAL for p in params)
    max_args = len([p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if not accepts_varargs:
            args = args[:max_args]
        try:
            return func(self, *args, **kwargs)
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} {func.__name__} failed")
            try:
                if isValid(self):
                    self._set_busy(False, "Có lỗi không mong muốn (chi tiết trong Nhật ký Logs).")
            except Exception:  # noqa: BLE001
                logger.exception(f"{TAG} could not report failure of {func.__name__}")
            return None

    return wrapper


class _RuntimeTask(QThread):
    """Unparented tracked QThread for scanning or installing runtime packages off the UI thread."""

    progress = Signal(int, int, str)
    done = Signal(object, str)

    def __init__(self, fn, label: str):
        super().__init__(None)
        self.label = label
        self._fn = fn
        self._cancel = False
        self.setObjectName(f"runtime-{label}")

    def cancel(self) -> None:
        self._cancel = True

    def start_tracked(self) -> None:
        _hook_quit()
        with _running_lock:
            _running_tasks.add(self)
        self.finished.connect(self._forget)
        self.start()

    def _forget(self) -> None:
        with _running_lock:
            _running_tasks.discard(self)

    def run(self) -> None:
        t0 = time.monotonic()
        logger.info(f"{TAG} Task {self.label!r} started")
        result, error = None, ""
        try:
            result = self._fn(
                lambda cur, tot, msg: self.progress.emit(cur, tot, msg),
                lambda: self._cancel,
            )
        except RuntimeInstallError as exc:
            error = str(exc)
            logger.warning(f"{TAG} Task {self.label!r} failed: {error}")
        except Exception as exc:  # noqa: BLE001
            logger.exception(f"{TAG} Task {self.label!r} crashed")
            error = f"Lỗi không mong muốn: {exc}"
        else:
            logger.info(f"{TAG} Task {self.label!r} finished in {time.monotonic() - t0:.2f}s")

        try:
            self.done.emit(result, error)
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Task {self.label!r} could not emit done signal")


class RuntimeManagerScreen(QWidget):
    """Full-screen manager for installing Windows/Proton game runtime dependencies."""

    back_requested = Signal()

    def __init__(
        self,
        config: dict,
        games_provider=None,
        initial_game: dict | None = None,
        parent=None,
    ):
        super().__init__(parent)
        self.config = config or {}
        self._games_provider = games_provider or (lambda: [])
        self._initial_game_name = str((initial_game or {}).get("name") or "").strip()
        self._targets: list[RuntimeGameTarget] = []
        self._installed_map: dict[str, bool] = {pkg.id: False for pkg in RUNTIME_CATALOG}
        self._task: _RuntimeTask | None = None
        self._busy = False

        self._setup_ui()
        QTimer.singleShot(0, self.refresh)

    def set_initial_game(self, game_data: dict | None) -> None:
        """Select a specific game target when opening the screen from a Game Card context menu."""
        name = str((game_data or {}).get("name") or "").strip()
        if not name:
            return
        self._initial_game_name = name
        if self._targets:
            self._select_target_by_name(name)
        else:
            self.refresh()

    def _setup_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        subtitle = (
            "Cài Microsoft Visual C++, DirectX, .NET vào Proton Prefix (Steam Deck) hoặc Windows"
            if sys.platform != "win32"
            else "Cài Microsoft Visual C++, DirectX, .NET và gói hỗ trợ cho game trên Windows"
        )
        header = ScreenHeader("Thư viện Runtime", "package", subtitle=subtitle)
        header.back_requested.connect(self.back_requested.emit)
        self.custom_exe_btn = header.add_button(
            "Chạy file .exe/.msi...",
            "secondary",
            icon="folder",
            tooltip="Chạy bộ cài đặt Windows (.exe hoặc .msi) trực tiếp trong Proton Prefix của game đang chọn.",
        )
        self.custom_exe_btn.clicked.connect(self._on_run_custom_exe)
        self.refresh_btn = header.add_button("Quét lại", "secondary", icon="refresh")
        self.refresh_btn.clicked.connect(self.refresh)
        root.addWidget(header)

        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(*CONTENT_MARGINS)
        lay.setSpacing(12)

        # Target selection & 1-click recommended install card
        target_card = QFrame()
        target_card.setStyleSheet(
            "QFrame { background-color: rgba(18, 22, 34, 0.78); "
            "border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 10px; } "
            "QLabel { border: none; background: transparent; }"
        )
        tc_lay = QVBoxLayout(target_card)
        tc_lay.setContentsMargins(16, 12, 16, 12)
        tc_lay.setSpacing(8)

        top_row = QHBoxLayout()
        top_row.setSpacing(10)

        icon_lbl = QLabel()
        icon_lbl.setPixmap(make_svg_pixmap("gamepad", size=20, color="#a855f7"))
        top_row.addWidget(icon_lbl)

        lbl = QLabel("Trò chơi / Proton Prefix:")
        lbl.setStyleSheet("color: #e2e8f0; font-size: 13px; font-weight: 700;")
        top_row.addWidget(lbl)

        self.target_combo = QComboBox()
        self.target_combo.setMinimumHeight(34)
        self.target_combo.setStyleSheet(
            "QComboBox { background-color: rgba(12, 16, 26, 0.9); color: #ffffff; "
            "border: 1px solid rgba(139, 92, 246, 0.4); border-radius: 8px; padding: 4px 10px; font-size: 13px; } "
            "QComboBox QAbstractItemView { background-color: #121622; color: #e2e8f0; "
            "selection-background-color: rgba(139, 92, 246, 0.35); }"
        )
        self.target_combo.currentIndexChanged.connect(self._on_target_changed)
        top_row.addWidget(self.target_combo, 1)

        self.install_rec_btn = QPushButton(" Cài gói khuyến nghị (VC++ + DirectX)")
        self.install_rec_btn.setIcon(make_svg_icon("bolt", size=14, color="#042612"))
        self.install_rec_btn.setStyleSheet(GREEN_BTN_STYLE)
        self.install_rec_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.install_rec_btn.clicked.connect(self._on_install_recommended)
        top_row.addWidget(self.install_rec_btn)
        tc_lay.addLayout(top_row)

        self.prefix_info_label = QLabel("Đang quét danh sách trò chơi...")
        self.prefix_info_label.setWordWrap(True)
        self.prefix_info_label.setStyleSheet("color: #94a3b8; font-size: 12px;")
        tc_lay.addWidget(self.prefix_info_label)

        # Bundled redistributables container (hidden unless game folder has UEPrereqSetup / vcredist / DXSETUP)
        self.bundled_frame = QFrame()
        self.bundled_frame.setStyleSheet(
            "QFrame { background-color: rgba(139, 92, 246, 0.10); "
            "border: 1px solid rgba(139, 92, 246, 0.32); border-radius: 8px; } "
            "QLabel { border: none; background: transparent; }"
        )
        self.bundled_layout = QHBoxLayout(self.bundled_frame)
        self.bundled_layout.setContentsMargins(12, 8, 12, 8)
        self.bundled_layout.setSpacing(8)
        self.bundled_frame.hide()
        tc_lay.addWidget(self.bundled_frame)

        lay.addWidget(target_card)

        # Progress bar & status line
        self.progress = QProgressBar()
        self.progress.setFixedHeight(8)
        self.progress.setTextVisible(False)
        self.progress.setStyleSheet(
            "QProgressBar { background-color: rgba(255, 255, 255, 0.07); border: none; border-radius: 4px; } "
            "QProgressBar::chunk { background-color: #8b5cf6; border-radius: 4px; }"
        )
        self.progress.hide()
        lay.addWidget(self.progress)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("color: #94a3b8; font-size: 12px;")
        lay.addWidget(self.status_label)

        # Runtime catalog table
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Gói thư viện", "Công dụng", "Dung lượng", "Trạng thái", "Thao tác"])
        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setStyleSheet(
            "QTableWidget { background-color: rgba(14, 18, 26, 0.85); color: #e2e8f0; font-size: 13px; "
            "gridline-color: rgba(255, 255, 255, 0.06); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 8px; } "
            "QHeaderView::section { background-color: rgba(20, 26, 38, 0.95); color: #94a3b8; padding: 8px; "
            "border: 1px solid rgba(255, 255, 255, 0.06); font-weight: bold; }"
        )
        lay.addWidget(self.table, 1)

        root.addWidget(body, 1)

    def _current_target(self) -> RuntimeGameTarget | None:
        idx = self.target_combo.currentIndex()
        if 0 <= idx < len(self._targets):
            return self._targets[idx]
        return None

    def _set_busy(self, busy: bool, status_text: str = "") -> None:
        self._busy = busy
        self.refresh_btn.setEnabled(not busy)
        self.custom_exe_btn.setEnabled(not busy)
        self.install_rec_btn.setEnabled(not busy)
        self.target_combo.setEnabled(not busy)
        self.progress.setVisible(busy)
        if not busy:
            self.progress.setValue(0)
        if status_text:
            self.status_label.setText(status_text)
        self._populate_table()

    def _run_task(self, label: str, fn, on_done) -> None:
        if self._task is not None and self._task.isRunning():
            logger.debug(f"{TAG} Ignored {label!r}: another runtime task is already running")
            return
        task = _RuntimeTask(fn, label)
        self._task = task
        task.progress.connect(self._on_task_progress)

        def _wrapped_done(result, error):
            if self._task is task:
                self._task = None
            if isValid(self):
                on_done(result, error)

        task.done.connect(_wrapped_done)
        task.start_tracked()

    @_safe
    def _on_task_progress(self, cur: int, tot: int, msg: str) -> None:
        if tot > 0:
            self.progress.setRange(0, tot)
            self.progress.setValue(cur)
        else:
            self.progress.setRange(0, 0)
        if msg:
            self.status_label.setText(msg)

    @_safe
    def refresh(self) -> None:
        if self._busy:
            return
        library_games = list(self._games_provider())
        self._set_busy(True, "Đang quét danh sách game và trạng thái thư viện Runtime...")
        self.progress.setRange(0, 0)

        def _work(_prog, _cancel):
            targets = list_runtime_targets(library_games)
            selected = targets[0] if targets else None
            if self._initial_game_name:
                low = self._initial_game_name.lower()
                for t in targets:
                    if t.name.lower() == low:
                        selected = t
                        break
            compat = selected.compatdata_path if selected else ""
            installed = detect_installed_runtimes(compat)
            return targets, installed

        self._run_task("scan", _work, self._on_scan_done)

    @_safe
    def _on_scan_done(self, result, error: str) -> None:
        if error or not result:
            self._set_busy(False, error or "Không quét được danh sách trò chơi.")
            return
        targets, installed = result
        self._targets = targets
        self._installed_map = installed

        self.target_combo.blockSignals(True)
        self.target_combo.clear()
        for t in self._targets:
            suffix = f" [AppID {t.uint_appid}]" if t.uint_appid else ""
            self.target_combo.addItem(f"{t.name}{suffix}")
        self.target_combo.blockSignals(False)

        if self._initial_game_name:
            self._select_target_by_name(self._initial_game_name, trigger_detect=False)
        self._update_target_details()
        self._set_busy(
            False,
            f"Tìm thấy {len(self._targets)} trò chơi. Chọn game rồi bấm Cài đặt để bổ sung thư viện còn thiếu.",
        )

    def _select_target_by_name(self, name: str, trigger_detect: bool = True) -> None:
        low = name.strip().lower()
        for idx, t in enumerate(self._targets):
            if t.name.lower() == low:
                self.target_combo.blockSignals(not trigger_detect)
                self.target_combo.setCurrentIndex(idx)
                self.target_combo.blockSignals(False)
                if not trigger_detect:
                    self._update_target_details()
                return

    @_safe
    def _on_target_changed(self, _index: int) -> None:
        target = self._current_target()
        self._update_target_details()
        compat = target.compatdata_path if target else ""
        self._set_busy(True, "Đang kiểm tra các gói Runtime đã cài...")
        self.progress.setRange(0, 0)

        def _work(_prog, _cancel):
            return detect_installed_runtimes(compat)

        self._run_task("detect", _work, self._on_detect_done)

    @_safe
    def _on_detect_done(self, result, error: str) -> None:
        if not error and isinstance(result, dict):
            self._installed_map = result
        missing_rec = [p.name for p in RUNTIME_CATALOG if p.recommended and not self._installed_map.get(p.id)]
        if missing_rec:
            msg = f"Thiếu {len(missing_rec)} gói khuyến nghị: {', '.join(missing_rec)}."
        else:
            msg = "Tất cả gói khuyến nghị (VC++ 2015–2022 & DirectX) đã sẵn sàng."
        self._set_busy(False, error or msg)

    def _update_target_details(self) -> None:
        target = self._current_target()
        if sys.platform == "win32":
            if target:
                self.prefix_info_label.setText(
                    f"Hệ điều hành: Windows (cài toàn hệ thống)  •  Thư mục game: {target.install_dir or '(chưa cấu hình)'}"
                )
            else:
                self.prefix_info_label.setText("Hệ điều hành: Windows (cài trực tiếp toàn hệ thống).")
        else:
            if target:
                proton_name = os.path.basename(os.path.dirname(target.proton_path)) if target.proton_path else "Chưa tìm thấy Proton"
                pfx_exists = os.path.isdir(os.path.join(target.compatdata_path, "pfx")) if target.compatdata_path else False
                pfx_note = "Đã khởi tạo" if pfx_exists else "Sẽ tự tạo mới khi cài"
                self.prefix_info_label.setText(
                    f"Proton: {proton_name}  •  Prefix ({pfx_note}): {target.compatdata_path or '(chưa xác định)'}"
                )
            else:
                self.prefix_info_label.setText(
                    "Chưa có game Non-Steam nào trong thư viện. Hãy thêm game vào Steam trước khi cài Runtime vào Prefix."
                )

        # Rebuild bundled redistributables bar
        while self.bundled_layout.count():
            item = self.bundled_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

        bundled = target.bundled_redists if target else ()
        if bundled:
            lbl = QLabel(f"Phát hiện bộ cài đi kèm trong thư mục game ({len(bundled)}):")
            lbl.setStyleSheet("color: #c4b5fd; font-size: 12px; font-weight: 700;")
            self.bundled_layout.addWidget(lbl)
            for path in bundled[:3]:
                btn = QPushButton(f" Chạy {os.path.basename(path)}")
                btn.setIcon(make_svg_icon("download", size=13, color="#f1f5f9"))
                btn.setStyleSheet(DARK_BTN_STYLE)
                btn.setCursor(Qt.CursorShape.PointingHandCursor)
                btn.setEnabled(not self._busy)
                btn.clicked.connect(lambda _checked=False, p=path: self._install_bundled_exe(p))
                self.bundled_layout.addWidget(btn)
            self.bundled_layout.addStretch()
            self.bundled_frame.show()
        else:
            self.bundled_frame.hide()

    def _populate_table(self) -> None:
        self.table.setRowCount(len(RUNTIME_CATALOG))
        for row, pkg in enumerate(RUNTIME_CATALOG):
            self.table.setRowHeight(row, 48)

            name_text = f"{pkg.name} (Khuyến nghị)" if pkg.recommended else pkg.name
            name_item = QTableWidgetItem(name_text)
            font = QFont("Segoe UI", 10, QFont.Weight.Bold if pkg.recommended else QFont.Weight.DemiBold)
            name_item.setFont(font)
            self.table.setItem(row, 0, name_item)

            desc_item = QTableWidgetItem(pkg.description)
            desc_item.setToolTip(pkg.description)
            self.table.setItem(row, 1, desc_item)

            size_item = QTableWidgetItem(pkg.size_hint)
            size_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 2, size_item)

            is_installed = bool(self._installed_map.get(pkg.id, False))
            status_lbl = QLabel("Đã cài" if is_installed else "Chưa cài")
            status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            status_lbl.setStyleSheet(
                "color: #2ed573; font-weight: 700; font-size: 12px; background: transparent;"
                if is_installed
                else "color: #fbbf24; font-weight: 700; font-size: 12px; background: transparent;"
            )
            self.table.setCellWidget(row, 3, status_lbl)

            btn_wrap = QWidget()
            btn_lay = QHBoxLayout(btn_wrap)
            btn_lay.setContentsMargins(6, 4, 6, 4)
            btn_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
            btn = QPushButton("Cài lại" if is_installed else "Cài ngay")
            btn.setStyleSheet(DARK_BTN_STYLE if is_installed else PURPLE_BTN_STYLE)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setEnabled(not self._busy)
            btn.clicked.connect(lambda _checked=False, pid=pkg.id: self._install_single(pid))
            btn_lay.addWidget(btn)
            self.table.setCellWidget(row, 4, btn_wrap)

    def _validate_target_before_install(self) -> tuple[bool, RuntimeGameTarget | None]:
        target = self._current_target()
        if sys.platform != "win32" and (target is None or not target.compatdata_path):
            QMessageBox.warning(
                self,
                "Chưa chọn trò chơi",
                "Trên Steam Deck / Linux, bạn cần chọn một trò chơi trong danh sách để xác định Proton Prefix cần cài Runtime.",
            )
            return False, None
        return True, target

    @_safe
    def _install_single(self, pkg_id: str) -> None:
        ok, target = self._validate_target_before_install()
        if not ok:
            return
        self._set_busy(True, f"Đang chuẩn bị cài đặt gói {pkg_id}...")

        def _work(prog, cancel):
            res = install_runtime_package(pkg_id, target=target, progress_cb=prog, is_cancelled=cancel)
            compat = target.compatdata_path if target else ""
            refreshed = detect_installed_runtimes(compat)
            return res, refreshed

        self._run_task(f"install-{pkg_id}", _work, self._on_install_done)

    @_safe
    def _on_install_recommended(self) -> None:
        ok, target = self._validate_target_before_install()
        if not ok:
            return
        to_install = [p.id for p in RUNTIME_CATALOG if p.recommended and not self._installed_map.get(p.id)]
        if not to_install:
            to_install = [p.id for p in RUNTIME_CATALOG if p.recommended]

        self._set_busy(True, f"Đang cài đặt {len(to_install)} gói Runtime khuyến nghị...")

        def _work(prog, cancel):
            results = []
            total_pkgs = len(to_install)
            for idx, pid in enumerate(to_install):
                if cancel():
                    raise RuntimeInstallError("Đã hủy cài đặt theo yêu cầu.")

                def _sub_prog(c, t, msg, i=idx):
                    base = int((i / total_pkgs) * 100)
                    span = max(1, int(100 / total_pkgs))
                    scaled = base + int((c / max(1, t)) * span)
                    prog(min(99, scaled), 100, f"[{i + 1}/{total_pkgs}] {msg}")

                res = install_runtime_package(pid, target=target, progress_cb=_sub_prog, is_cancelled=cancel)
                results.append(res)
                if not res.get("success"):
                    break

            compat = target.compatdata_path if target else ""
            refreshed = detect_installed_runtimes(compat)
            all_ok = all(r.get("success") for r in results) and len(results) == len(to_install)
            failed = next((r for r in results if not r.get("success")), None)
            summary = {
                "success": all_ok,
                "message": (
                    f"Đã cài đặt thành công {len(results)}/{len(to_install)} gói khuyến nghị. Bạn có thể khởi chạy game ngay."
                    if all_ok
                    else (failed.get("message") if failed else "Quá trình cài đặt chưa hoàn tất.")
                ),
            }
            return summary, refreshed

        self._run_task("install-recommended", _work, self._on_install_done)

    @_safe
    def _install_bundled_exe(self, exe_path: str) -> None:
        ok, target = self._validate_target_before_install()
        if not ok:
            return
        self._set_busy(True, f"Đang chạy {os.path.basename(exe_path)}...")
        self.progress.setRange(0, 0)

        def _work(_prog, _cancel):
            res = install_custom_executable(exe_path, target=target)
            compat = target.compatdata_path if target else ""
            refreshed = detect_installed_runtimes(compat)
            return res, refreshed

        self._run_task("install-bundled", _work, self._on_install_done)

    @_safe
    def _on_run_custom_exe(self) -> None:
        ok, target = self._validate_target_before_install()
        if not ok:
            return
        start_dir = (target.install_dir if target and os.path.isdir(target.install_dir) else os.path.expanduser("~"))
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Chọn bộ cài đặt Runtime / Plugin (.exe hoặc .msi)",
            start_dir,
            "Bộ cài Windows (*.exe *.msi);;Tất cả tệp (*.*)",
        )
        if not file_path:
            return
        self._install_bundled_exe(file_path)

    @_safe
    def _on_install_done(self, result, error: str) -> None:
        if error:
            self._set_busy(False, error)
            QMessageBox.warning(self, "Cài đặt thất bại", error)
            return
        res, refreshed = result
        if isinstance(refreshed, dict):
            self._installed_map = refreshed
        msg = str((res or {}).get("message") or "Hoàn tất.")
        self._set_busy(False, msg)
        if (res or {}).get("success"):
            QMessageBox.information(self, "Cài đặt hoàn tất", msg)
        else:
            QMessageBox.warning(self, "Cài đặt chưa thành công", msg)
