"""
Windows 11 Mica and Acrylic backdrop helper for PySide6.
Applies native Windows 11 dark mode titlebar and backdrop blur (Mica Alt / Acrylic).
Gracefully degrades on older Windows versions or non-Windows systems.
"""

import sys
import platform
import ctypes
import logging

logger = logging.getLogger(__name__)

# DWM Window Attributes
DWMWA_USE_IMMERSIVE_DARK_MODE_BEFORE_20H1 = 19
DWMWA_USE_IMMERSIVE_DARK_MODE = 20
DWMWA_SYSTEMBACKDROP_TYPE = 38
DWMWA_MICA_EFFECT = 1029

# System Backdrop Types (Windows 11 22H2 / Build 22621+)
DWMSBT_AUTO = 0
DWMSBT_NONE = 1
DWMSBT_MAINWINDOW = 2       # Mica
DWMSBT_TRANSIENTWINDOW = 3   # Acrylic
DWMSBT_TABBEDWINDOW = 4      # Mica Alt (Tabbed)


def is_windows_11() -> bool:
    """Check if host is running Windows 11 (build >= 22000)."""
    if sys.platform != "win32":
        return False
    try:
        win_ver = sys.getwindowsversion()
        return win_ver.major == 10 and win_ver.build >= 22000
    except Exception:
        return False


def get_windows_build() -> int:
    """Return the Windows build number, or 0 if not Windows."""
    if sys.platform != "win32":
        return 0
    try:
        return sys.getwindowsversion().build
    except Exception:
        return 0


def apply_dark_titlebar(hwnd: int) -> bool:
    """Enable dark mode titlebar on Windows 10 (1809+) and Windows 11."""
    if sys.platform != "win32" or not hwnd:
        return False
    try:
        dwmapi = ctypes.windll.dwmapi
        val = ctypes.c_int(1)
        # Try modern attribute 20 first (20H1+)
        hr = dwmapi.DwmSetWindowAttribute(
            hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE,
            ctypes.byref(val), ctypes.sizeof(val)
        )
        if hr != 0:
            # Fallback to older 19 for 1809-1909
            dwmapi.DwmSetWindowAttribute(
                hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE_BEFORE_20H1,
                ctypes.byref(val), ctypes.sizeof(val)
            )
        return True
    except Exception as e:
        logger.debug(f"[Mica] Dark titlebar failed: {e}")
        return False


def apply_mica_or_acrylic(window, prefer_acrylic: bool = True) -> bool:
    """
    Apply native Windows 11 backdrop material (Acrylic or Mica Alt).
    
    Args:
        window: QWidget or QMainWindow instance
        prefer_acrylic: If True, uses Acrylic (transient blur); otherwise Mica Alt.
    
    Returns:
        bool: True if backdrop applied, False if not supported/failed.
    """
    if sys.platform != "win32":
        return False

    build = get_windows_build()
    if build < 22000:
        return False

    try:
        hwnd = int(window.winId())
        if not hwnd:
            return False

        # Always apply dark titlebar
        apply_dark_titlebar(hwnd)

        dwmapi = ctypes.windll.dwmapi

        if build >= 22621:
            # Win 11 22H2+: Use DWMWA_SYSTEMBACKDROP_TYPE
            backdrop_type = DWMSBT_TRANSIENTWINDOW if prefer_acrylic else DWMSBT_TABBEDWINDOW
            val = ctypes.c_int(backdrop_type)
            hr = dwmapi.DwmSetWindowAttribute(
                hwnd, DWMWA_SYSTEMBACKDROP_TYPE,
                ctypes.byref(val), ctypes.sizeof(val)
            )
            success = (hr == 0)
            if success:
                logger.info(f"[Mica] Native backdrop ({backdrop_type}) applied successfully")
            return success
        else:
            # Win 11 21H2 (22000): Use undocumented Mica attribute 1029
            val = ctypes.c_int(1)
            hr = dwmapi.DwmSetWindowAttribute(
                hwnd, DWMWA_MICA_EFFECT,
                ctypes.byref(val), ctypes.sizeof(val)
            )
            return (hr == 0)

    except Exception as e:
        logger.debug(f"[Mica] Backdrop application error: {e}")
        return False
