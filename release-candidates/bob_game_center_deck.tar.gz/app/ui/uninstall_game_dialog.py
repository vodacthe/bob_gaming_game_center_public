"""
Confirmation dialog for uninstalling a game from the Bob Gaming Library.
Displays the resolved game folder, Non-Steam shortcut cleanup status, Steam restart option,
and an unchecked-by-default local Save deletion option.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.styles import CHECK_ICON_PATH


def _escape_mnemonic(text: str) -> str:
    return (text or "").replace("&", "&&")


class UninstallGameDialog(QDialog):
    """Dark confirmation dialog for safe game uninstallation."""

    def __init__(
        self,
        game_name: str,
        resolved_dir: str,
        refusal_reason: str = "",
        has_shortcut: bool = False,
        steam_running: bool = False,
        save_path: str = "",
        save_deletable: bool = False,
        parent=None,
    ):
        super().__init__(parent)
        self.game_name = game_name
        self.resolved_dir = resolved_dir
        self.refusal_reason = refusal_reason
        self.has_shortcut = has_shortcut
        self.steam_running = steam_running
        self.save_path = save_path
        self.save_deletable = save_deletable

        self.setWindowTitle("Gỡ cài đặt trò chơi")
        self.setMinimumWidth(520)
        self.setModal(True)
        self.setStyleSheet(f"""
            QDialog {{
                background-color: #0d141e;
                color: #e2e8f0;
            }}
            QLabel {{
                background: transparent;
                border: none;
            }}
            QCheckBox {{
                color: #e2e8f0;
                font-size: 12px;
                spacing: 8px;
                background: transparent;
            }}
            QCheckBox::indicator {{
                width: 16px;
                height: 16px;
                border-radius: 4px;
                border: 1px solid rgba(148, 163, 184, 0.45);
                background-color: #0b0f17;
            }}
            QCheckBox::indicator:checked {{
                background-color: #dc2626;
                border-color: #ef4444;
                image: url("{CHECK_ICON_PATH}");
            }}
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 18)
        root.setSpacing(14)

        # Header
        header_row = QHBoxLayout()
        header_row.setSpacing(12)
        icon_lbl = QLabel()
        icon_lbl.setFixedSize(36, 36)
        icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_lbl.setStyleSheet(
            "background-color: rgba(239, 68, 68, 0.14); "
            "border: 1px solid rgba(239, 68, 68, 0.35); border-radius: 10px;"
        )
        icon_lbl.setPixmap(make_svg_pixmap("trash", size=18, color="#ef4444"))
        header_row.addWidget(icon_lbl)

        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        title_lbl = QLabel(f"Gỡ cài đặt \"{game_name}\"?")
        title_lbl.setWordWrap(True)
        title_lbl.setStyleSheet("color: #f8fafc; font-size: 15px; font-weight: 700;")
        sub_lbl = QLabel("Thao tác này sẽ xóa trò chơi khỏi máy tính và khỏi danh sách thư viện.")
        sub_lbl.setWordWrap(True)
        sub_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")
        title_col.addWidget(title_lbl)
        title_col.addWidget(sub_lbl)
        header_row.addLayout(title_col, 1)
        root.addLayout(header_row)

        # Folder box
        folder_frame = QFrame()
        folder_frame.setObjectName("folderBox")
        folder_frame.setStyleSheet(
            "QFrame#folderBox { background-color: #111927; "
            "border: 1px solid rgba(239, 68, 68, 0.32); border-radius: 8px; } "
            "QLabel { border: none; background: transparent; }"
        )
        folder_layout = QVBoxLayout(folder_frame)
        folder_layout.setContentsMargins(12, 10, 12, 10)
        folder_layout.setSpacing(4)

        folder_caption = QLabel("Thư mục cài đặt sẽ bị xóa vĩnh viễn:")
        folder_caption.setStyleSheet("color: #fca5a5; font-size: 11px; font-weight: 600;")
        folder_layout.addWidget(folder_caption)

        self.path_label = QLabel(resolved_dir if resolved_dir else "(Chưa xác định được thư mục an toàn)")
        self.path_label.setWordWrap(True)
        self.path_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.path_label.setStyleSheet(
            "color: #f8fafc; font-family: Consolas, 'Segoe UI', monospace; font-size: 12px;"
        )
        folder_layout.addWidget(self.path_label)

        if refusal_reason:
            self.refusal_label = QLabel(refusal_reason)
            self.refusal_label.setWordWrap(True)
            self.refusal_label.setStyleSheet("color: #fbbf24; font-size: 12px; font-weight: 600; padding-top: 4px;")
            folder_layout.addWidget(self.refusal_label)
        else:
            self.refusal_label = None

        root.addWidget(folder_frame)

        # Non-Steam Library info + Steam restart option
        steam_frame = QFrame()
        steam_frame.setObjectName("steamBox")
        steam_frame.setStyleSheet(
            "QFrame#steamBox { background-color: #111927; "
            "border: 1px solid rgba(56, 189, 248, 0.22); border-radius: 8px; } "
            "QLabel { border: none; background: transparent; }"
        )
        steam_layout = QVBoxLayout(steam_frame)
        steam_layout.setContentsMargins(12, 10, 12, 10)
        steam_layout.setSpacing(6)

        steam_row = QHBoxLayout()
        steam_row.setSpacing(8)
        steam_ico = QLabel()
        steam_ico.setFixedSize(16, 16)
        steam_ico.setPixmap(make_svg_pixmap("steam", size=15, color="#38bdf8"))
        steam_row.addWidget(steam_ico)

        steam_text = (
            "Sẽ xóa phím tắt Non-Steam và bộ ảnh bìa Grid khỏi thư viện Steam."
            if has_shortcut
            else "Không phát hiện phím tắt Non-Steam trong Steam trên máy này."
        )
        self.steam_status_label = QLabel(steam_text)
        self.steam_status_label.setWordWrap(True)
        self.steam_status_label.setStyleSheet("color: #cbd5e1; font-size: 12px;")
        steam_row.addWidget(self.steam_status_label, 1)
        steam_layout.addLayout(steam_row)

        self.restart_steam_cb = QCheckBox(
            "Tự động khởi động lại Steam để cập nhật Non-Steam Library ngay"
        )
        self.restart_steam_cb.setChecked(False)
        self.restart_steam_cb.hide()
        if has_shortcut and steam_running:
            steam_hint = QLabel(
                "Steam đang chạy sẽ được giữ nguyên; mục Non-Steam sẽ tự cập nhật ở lần mở Steam kế tiếp."
            )
            steam_hint.setWordWrap(True)
            steam_hint.setStyleSheet("color: #64748b; font-size: 11px; padding-left: 24px;")
            steam_layout.addWidget(steam_hint)

        root.addWidget(steam_frame)

        # Optional local save deletion (unchecked by default!)
        self.delete_save_cb = QCheckBox(
            _escape_mnemonic(f"Xóa luôn dữ liệu Save trên máy ({save_path})")
        )
        self.delete_save_cb.setChecked(False)
        if save_deletable and save_path:
            save_frame = QFrame()
            save_frame.setObjectName("saveBox")
            save_frame.setStyleSheet(
                "QFrame#saveBox { background-color: #111927; "
                "border: 1px solid rgba(148, 163, 184, 0.18); border-radius: 8px; } "
                "QLabel { border: none; background: transparent; }"
            )
            save_layout = QVBoxLayout(save_frame)
            save_layout.setContentsMargins(12, 10, 12, 10)
            save_layout.setSpacing(4)
            save_layout.addWidget(self.delete_save_cb)
            save_hint = QLabel("Bản sao lưu trên đám mây (Cloud) nếu có sẽ được giữ nguyên.")
            save_hint.setWordWrap(True)
            save_hint.setStyleSheet("color: #64748b; font-size: 11px; padding-left: 24px;")
            save_layout.addWidget(save_hint)
            root.addWidget(save_frame)
        else:
            self.delete_save_cb.hide()

        # Action buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)
        btn_row.addStretch()

        self.cancel_btn = QPushButton("Hủy bỏ")
        self.cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cancel_btn.setFixedHeight(36)
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #e2e8f0;
                border: 1px solid rgba(148, 163, 184, 0.28);
                border-radius: 8px;
                padding: 0 18px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #334155;
            }
        """)
        self.cancel_btn.clicked.connect(self.reject)
        self.cancel_btn.setDefault(True)
        btn_row.addWidget(self.cancel_btn)

        self.confirm_btn = QPushButton(" Gỡ cài đặt")
        self.confirm_btn.setIcon(make_svg_icon("trash", size=14, color="#ffffff"))
        self.confirm_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.confirm_btn.setFixedHeight(36)
        self.confirm_btn.setEnabled(bool(resolved_dir) and not refusal_reason)
        self.confirm_btn.setStyleSheet("""
            QPushButton {
                background-color: #dc2626;
                color: #ffffff;
                border: none;
                border-radius: 8px;
                padding: 0 18px;
                font-weight: 700;
            }
            QPushButton:hover {
                background-color: #ef4444;
            }
            QPushButton:disabled {
                background-color: #3f1d24;
                color: #94a3b8;
            }
        """)
        self.confirm_btn.clicked.connect(self.accept)
        btn_row.addWidget(self.confirm_btn)

        root.addLayout(btn_row)

    @property
    def should_delete_save(self) -> bool:
        return bool(self.save_deletable and self.delete_save_cb.isChecked())

    @property
    def should_restart_steam(self) -> bool:
        return False
