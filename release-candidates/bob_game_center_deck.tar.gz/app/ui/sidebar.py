"""
Luxury Collapsible Sidebar for Bob Gaming Game Center.
Featuring the authentic Bob Gaming logo and razor-sharp vector SVG icons.
Unified Cyberpunk Titanium Violet & Emerald Design Language.
"""

import logging
import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QFrame, QSizePolicy
)
from PySide6.QtCore import Qt, Signal, QRectF, QSize
from PySide6.QtGui import QFont, QPixmap, QPainter, QColor, QLinearGradient

from app.config import get_app_dir
from app.ui.icons import make_svg_pixmap
from app.version import APP_VERSION

TAG = "[UI/Sidebar]"
logger = logging.getLogger(__name__)


class _ClickableLabel(QLabel):
    clicked = Signal()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)


class _SidebarGroupHeader(QPushButton):
    """Clickable group header allowing users to collapse/expand each sidebar section."""

    def __init__(self, section_id: str, title: str, parent=None):
        super().__init__(title, parent)
        self.section_id = section_id
        self.title_text = title
        self._group_collapsed = False
        self._hovered = False
        self._has_active_child = False
        self._has_live_daemon = False

        self.setObjectName("sidebarGroupLabel")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(28)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._sync_tooltip()

    def minimumSizeHint(self) -> QSize:
        return QSize(40, 28)

    def sizeHint(self) -> QSize:
        return QSize(120, 28)

    def set_group_collapsed(self, collapsed: bool):
        self._group_collapsed = bool(collapsed)
        self._sync_tooltip()
        self.update()

    def is_group_collapsed(self) -> bool:
        return self._group_collapsed

    def set_indicators(self, has_active_child: bool, has_live_daemon: bool):
        if (self._has_active_child, self._has_live_daemon) != (has_active_child, has_live_daemon):
            self._has_active_child = has_active_child
            self._has_live_daemon = has_live_daemon
            self.update()

    def _sync_tooltip(self):
        action = "mở rộng" if self._group_collapsed else "thu gọn"
        self.setToolTip(f"Bấm để {action} nhóm {self.title_text}")

    def enterEvent(self, event):
        self._hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hovered = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        rect = self.rect()
        pill_rect = rect.adjusted(2, 4, -2, -1)
        if self._hovered:
            painter.setBrush(QColor(255, 255, 255, 12))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(pill_rect, 6, 6)

        # Chevron on right
        chevron_size = 13
        chevron_x = rect.width() - chevron_size - 8
        chevron_y = pill_rect.top() + (pill_rect.height() - chevron_size) // 2
        fg_hex = "#cbd5e1" if self._hovered else "#64748b"
        chevron_icon = "chevron_right" if self._group_collapsed else "chevron_down"
        pix = make_svg_pixmap(chevron_icon, size=chevron_size, color=fg_hex)
        if not pix.isNull():
            painter.drawPixmap(chevron_x, chevron_y, pix)

        # Subtle status dot when section is collapsed so active item / [ON] daemon stays noticeable
        right_reserve = chevron_size + 14
        if self._group_collapsed and (self._has_active_child or self._has_live_daemon):
            dot_color = QColor("#8b5cf6") if self._has_active_child else QColor("#10b981")
            dot_x = chevron_x - 10
            dot_y = pill_rect.top() + (pill_rect.height() - 6) // 2
            painter.setBrush(dot_color)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(QRectF(dot_x, dot_y, 6, 6))
            right_reserve += 12

        font = QFont("Segoe UI", 8)
        font.setWeight(QFont.Weight.Bold)
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 0.8)
        painter.setFont(font)
        painter.setPen(QColor(fg_hex))

        text_rect = QRectF(10, pill_rect.top(), max(10, rect.width() - 10 - right_reserve), pill_rect.height())
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self.title_text)
        painter.end()


class _SidebarNavButton(QPushButton):
    """A sleek navigation item with razor-sharp vector icon and luxury styling."""

    def __init__(self, key: str, icon_name: str, text: str, badge_text: str = "", parent=None):
        super().__init__(parent)
        self.key = key
        self.icon_name = icon_name
        self.label_text = text
        self.badge_text = badge_text
        self.is_collapsed = False
        self._is_active = False
        self._hovered = False

        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(36)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        self._update_text()

    def minimumSizeHint(self) -> QSize:
        return QSize(40, 36)

    def sizeHint(self) -> QSize:
        return QSize(120, 36)

    def set_active(self, active: bool):
        self._is_active = active
        self.setProperty("active", "true" if active else "false")
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def set_badge(self, text: str, is_highlight: bool = False):
        self.badge_text = text
        self._badge_highlight = is_highlight
        self._update_text()
        self.update()

    def set_collapsed(self, collapsed: bool):
        self.is_collapsed = collapsed
        self._update_text()
        self.update()

    def _update_text(self):
        """Update QPushButton text for backwards compatibility and test assertions."""
        badge_str = f"  [{self.badge_text}]" if self.badge_text else ""
        if self.is_collapsed:
            self.setText("")
            tooltip = self.label_text
            if self.badge_text:
                tooltip += f" [{self.badge_text}]"
            self.setToolTip(tooltip)
        else:
            self.setText(f"  {self.label_text}{badge_str}")
            self.setToolTip(self.label_text if ("@" in self.label_text or len(self.label_text) > 20) else "")

    def enterEvent(self, event):
        self._hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hovered = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        """Pixel-perfect custom painting matching mockup without text overlap."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        rect = self.rect()

        # 1. Background (Rounded pill)
        if self._is_active:
            grad = QLinearGradient(0, 0, rect.width(), 0)
            grad.setColorAt(0, QColor("#6d28d9"))
            grad.setColorAt(1, QColor("#5b21b6"))
            painter.setBrush(grad)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(rect.adjusted(2, 2, -2, -2), 8, 8)
        elif self._hovered:
            painter.setBrush(QColor(255, 255, 255, 14))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(rect.adjusted(2, 2, -2, -2), 8, 8)

        # 2. Icon
        icon_size = 18
        if self.is_collapsed:
            icon_x = (rect.width() - icon_size) // 2
        else:
            icon_x = 12
        icon_y = (rect.height() - icon_size) // 2

        icon_color = "#ffffff" if self._is_active else ("#ffffff" if self._hovered else "#8c96a8")
        pix = make_svg_pixmap(self.icon_name, size=icon_size, color=icon_color)
        if not pix.isNull():
            painter.drawPixmap(icon_x, icon_y, pix)

        # In collapsed mode, do not draw text or badges
        if self.is_collapsed:
            painter.end()
            return

        # 3. Badge geometry & pre-measurement
        badge_w = 0
        badge_draw_fn = None

        if self.badge_text:
            badge_font = QFont("Segoe UI", 9, QFont.Weight.Bold)
            painter.setFont(badge_font)
            metrics = painter.fontMetrics()

            if self.badge_text in ["ON", "ONLINE"]:
                txt = f"[{self.badge_text}]"
                txt_w = metrics.horizontalAdvance(txt)
                badge_w = txt_w + 4
                badge_x = rect.width() - badge_w - 10
                badge_rect = QRectF(badge_x, 0, badge_w, rect.height())

                def _draw_status():
                    painter.setFont(badge_font)
                    painter.setPen(QColor("#10b981"))
                    painter.drawText(badge_rect, Qt.AlignmentFlag.AlignCenter, txt)

                badge_draw_fn = _draw_status
            else:
                txt_w = metrics.horizontalAdvance(self.badge_text)
                pill_w = max(22, txt_w + 12)
                pill_h = 18
                badge_w = pill_w
                pill_x = rect.width() - pill_w - 10
                pill_y = (rect.height() - pill_h) // 2
                pill_rect = QRectF(pill_x, pill_y, pill_w, pill_h)

                def _draw_pill():
                    painter.setFont(badge_font)
                    if self.badge_text == "HOT":            # red pill, active or not
                        painter.setBrush(QColor("#ef4444"))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawRoundedRect(pill_rect, 6, 6)
                        painter.setPen(QColor("#ffffff"))
                    elif self.badge_text == "NEW":          # emerald pill for newly added features
                        painter.setBrush(QColor("#10b981"))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawRoundedRect(pill_rect, 6, 6)
                        painter.setPen(QColor("#052e16"))
                    elif self._is_active:
                        painter.setBrush(QColor(255, 255, 255, 45))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawRoundedRect(pill_rect, 6, 6)
                        painter.setPen(QColor("#ffffff"))
                    else:
                        painter.setBrush(QColor(255, 255, 255, 20))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawRoundedRect(pill_rect, 6, 6)
                        painter.setPen(QColor("#94a3b8"))
                    painter.drawText(pill_rect, Qt.AlignmentFlag.AlignCenter, self.badge_text)

                badge_draw_fn = _draw_pill

        # 4. Text Label (strictly elided so it NEVER collides with badge)
        text_color = QColor("#ffffff") if self._is_active else (QColor("#ffffff") if self._hovered else QColor("#94a3b8"))
        font = QFont("Segoe UI", 10)
        font.setWeight(QFont.Weight.DemiBold if self._is_active else QFont.Weight.Medium)
        painter.setFont(font)
        painter.setPen(text_color)

        text_x = 38
        right_reserve = (badge_w + 14) if badge_w > 0 else 8
        available_text_w = max(10, rect.width() - text_x - right_reserve)
        elide_mode = Qt.TextElideMode.ElideMiddle if "@" in self.label_text else Qt.TextElideMode.ElideRight
        elided_text = painter.fontMetrics().elidedText(self.label_text, elide_mode, int(available_text_w))

        text_rect = QRectF(text_x, 0, available_text_w, rect.height())
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, elided_text)

        # Draw badge after text
        if badge_draw_fn:
            badge_draw_fn()

        painter.end()


class SidebarWidget(QWidget):
    """
    Main Navigation Sidebar featuring authentic Bob Gaming branding,
    vector navigation icons, and collapsible luxury design.
    """

    # Signals
    category_selected = Signal(str)          # 'all', 'installed', 'favorites', 'synced'
    tool_triggered = Signal(str)             # 'net_unblock', 'steam_chat', 'cloud_sync', 'steam_artwork', 'upscaler', 'lan_drop'
    device_triggered = Signal(str)           # 'controller'
    system_triggered = Signal(str)           # 'settings', 'logs', 'account'
    collapse_toggled = Signal(bool)
    collapsed_groups_changed = Signal(list)  # list[str] of collapsed section IDs
    version_clicked = Signal()               # check for updates now

    EXPANDED_WIDTH = 256
    COLLAPSED_WIDTH = 68

    GROUP_STORE = "store"
    GROUP_LIBRARY = "library"
    GROUP_TOOLS = "tools"
    GROUP_DEVICES = "devices"
    GROUP_SYSTEM = "system"
    ALL_GROUPS = (GROUP_STORE, GROUP_LIBRARY, GROUP_TOOLS, GROUP_DEVICES, GROUP_SYSTEM)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("sidebar")
        self._collapsed = False
        self._nav_buttons: dict[str, _SidebarNavButton] = {}
        self._group_labels: list[_SidebarGroupHeader] = []
        self._group_headers: dict[str, _SidebarGroupHeader] = {}
        self._section_containers: dict[str, QWidget] = {}
        self._section_buttons: dict[str, list[_SidebarNavButton]] = {}
        self._collapsed_groups: dict[str, bool] = {gid: False for gid in self.ALL_GROUPS}

        self.setFixedWidth(self.EXPANDED_WIDTH)
        self._setup_ui()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(8, 10, 8, 10)
        main_layout.setSpacing(4)

        # ---- Official Bob Gaming Brand Header ----
        self.header_widget = QWidget()
        self.header_widget.setCursor(Qt.CursorShape.PointingHandCursor)
        header_layout = QVBoxLayout(self.header_widget)
        header_layout.setContentsMargins(0, 0, 0, 4)
        header_layout.setSpacing(2)
        header_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        app_dir = get_app_dir()
        logo_path = os.path.join(app_dir, "assets", "logo.png")
        icon_path = os.path.join(app_dir, "assets", "icon.png")

        # Outer logo container
        self.logo_card = QFrame()
        self.logo_card.setObjectName("logoCard")
        self.logo_card.setStyleSheet("""
            #logoCard {
                border: none;
                background-color: transparent;
            }
        """)
        logo_card_layout = QVBoxLayout(self.logo_card)
        logo_card_layout.setContentsMargins(2, 2, 2, 2)
        logo_card_layout.setSpacing(2)
        logo_card_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Full logo for expanded mode
        self.logo_full_label = QLabel()
        self.logo_full_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo_full_label.setStyleSheet("background: transparent; border: none;")
        if os.path.exists(logo_path):
            pix_full = QPixmap(logo_path)
            scaled_full = pix_full.scaledToWidth(160, Qt.TransformationMode.SmoothTransformation)
            self.logo_full_label.setPixmap(scaled_full)
        else:
            self.logo_full_label.setText("BOB GAMING")
            self.logo_full_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #ffffff;")

        self.logo_subtitle = QLabel("Game Center")
        self.logo_subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo_subtitle.setStyleSheet("color: #94a3b8; font-size: 11px; font-weight: 600; letter-spacing: 0.5px; background: transparent; border: none;")

        logo_card_layout.addWidget(self.logo_full_label)
        logo_card_layout.addWidget(self.logo_subtitle)

        # Icon logo for collapsed mode
        self.logo_icon_label = QLabel()
        self.logo_icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo_icon_label.setStyleSheet("background: transparent; border: none;")
        if os.path.exists(icon_path):
            pix_icon = QPixmap(icon_path)
            scaled_icon = pix_icon.scaledToHeight(38, Qt.TransformationMode.SmoothTransformation)
            self.logo_icon_label.setPixmap(scaled_icon)
        else:
            self.logo_icon_label.setText("BG")
            self.logo_icon_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #a855f7;")
        self.logo_icon_label.hide()

        header_layout.addWidget(self.logo_card)
        header_layout.addWidget(self.logo_icon_label)
        main_layout.addWidget(self.header_widget)

        # Subtle divider below logo
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("background-color: rgba(255, 255, 255, 0.07); max-height: 1px;")
        main_layout.addWidget(sep)

        # ---- Scrollable Navigation Body ----
        scroll = QScrollArea()
        scroll.setObjectName("sidebarScroll")
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 4px;
                margin: 0;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 2px;
                min-height: 24px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(139, 92, 246, 0.6);
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0;
                background: transparent;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: transparent;
            }
        """)

        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(0, 4, 4, 0)
        body_layout.setSpacing(2)

        # 1. GROUP: KHO GAME (GAME STORE — TOP SECTION ABOVE LIBRARY)
        store_layout = self._add_group_section(body_layout, self.GROUP_STORE, "KHO GAME")
        self._add_nav_item(store_layout, "online_fix", "store", "Cửa hàng miễn phí", group="tool", badge="HOT", section=self.GROUP_STORE)
        self._add_nav_item(store_layout, "store_steam_free", "gift", "Steam Miễn Phí", group="tool", section=self.GROUP_STORE)

        # 2. GROUP: THƯ VIỆN (LIBRARY)
        lib_layout = self._add_group_section(body_layout, self.GROUP_LIBRARY, "THƯ VIỆN")
        self._add_nav_item(lib_layout, "all", "gamepad", "Tất cả trò chơi", group="lib", active=True, badge="0", section=self.GROUP_LIBRARY)
        self._add_nav_item(lib_layout, "installed", "download", "Đã cài đặt", group="lib", badge="0", section=self.GROUP_LIBRARY)
        self._add_nav_item(lib_layout, "synced", "cloud", "Đã đồng bộ", group="lib", badge="0", section=self.GROUP_LIBRARY)
        self._add_nav_item(lib_layout, "favorites", "star", "Yêu thích", group="lib", badge="0", section=self.GROUP_LIBRARY)

        # 3. GROUP: CÔNG CỤ NÂNG CAO (PRO TOOLS)
        tools_layout = self._add_group_section(body_layout, self.GROUP_TOOLS, "CÔNG CỤ NÂNG CAO")
        self._add_nav_item(tools_layout, "remote_gaming", "cast", "Remote Gaming", group="tool", badge="", section=self.GROUP_TOOLS)
        self._add_nav_item(tools_layout, "lan_drop", "share", "Chia sẻ LAN", group="tool", badge="", section=self.GROUP_TOOLS)
        self._add_nav_item(tools_layout, "trainer", "bolt", "Game Trainer", group="tool", badge="NEW", section=self.GROUP_TOOLS)
        self._add_nav_item(tools_layout, "net_unblock", "globe", "Mở chặn mạng", group="tool", badge="", section=self.GROUP_TOOLS)
        self._add_nav_item(tools_layout, "steam_chat", "chat", "Steam Chat Overlay", group="tool", badge="", section=self.GROUP_TOOLS)
        self._add_nav_item(tools_layout, "cloud_sync", "sync", "Đồng bộ đám mây", group="tool", section=self.GROUP_TOOLS)
        self._add_nav_item(tools_layout, "steam_artwork", "image", "Ảnh bìa Steam", group="tool", section=self.GROUP_TOOLS)
        self._add_nav_item(tools_layout, "upscaler", "sliders", "Upscaler", group="tool", section=self.GROUP_TOOLS)

        # 4. GROUP: THIẾT BỊ (DEVICES)
        dev_layout = self._add_group_section(body_layout, self.GROUP_DEVICES, "THIẾT BỊ")
        self._add_nav_item(dev_layout, "controller", "controller", "Quản lý tay cầm", group="device", section=self.GROUP_DEVICES)

        # 5. GROUP: HỆ THỐNG (SYSTEM)
        sys_layout = self._add_group_section(body_layout, self.GROUP_SYSTEM, "HỆ THỐNG")
        self._add_nav_item(sys_layout, "logs", "terminal", "Nhật ký Logs", group="system", section=self.GROUP_SYSTEM)
        self._add_nav_item(sys_layout, "settings", "settings", "Cài đặt", group="system", section=self.GROUP_SYSTEM)
        self._add_nav_item(sys_layout, "account", "user", "Tài khoản Cloud", group="system", badge="", section=self.GROUP_SYSTEM)

        body_layout.addStretch()
        scroll.setWidget(body)
        main_layout.addWidget(scroll)

        # ---- Bottom Bar (Collapse Button) ----
        bottom_widget = QWidget()
        bottom_layout = QVBoxLayout(bottom_widget)
        bottom_layout.setContentsMargins(2, 6, 2, 2)
        bottom_layout.setSpacing(6)

        self.version_label = _ClickableLabel(f"v{APP_VERSION}")
        self.version_label.setObjectName("sidebarVersion")
        self.version_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.version_label.setToolTip(f"Bob Gaming Game Center v{APP_VERSION} · Bấm để kiểm tra cập nhật")
        self.version_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self.version_label.clicked.connect(self.version_clicked)
        self.version_label.setStyleSheet(
            "color: #64748b; font-size: 11px; font-weight: 600; background: transparent; border: none;")
        bottom_layout.addWidget(self.version_label)

        self.collapse_btn = QPushButton("◀ Thu gọn")
        self.collapse_btn.setObjectName("secondaryBtn")
        self.collapse_btn.setFixedHeight(34)
        self.collapse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.collapse_btn.clicked.connect(self.toggle_collapse)

        bottom_layout.addWidget(self.collapse_btn)
        main_layout.addWidget(bottom_widget)
        self._sync_group_indicators()

    def _add_group_section(self, parent_layout: QVBoxLayout, section_id: str, title: str) -> QVBoxLayout:
        hdr = _SidebarGroupHeader(section_id, title, parent=self)
        hdr.clicked.connect(lambda _checked=False, sid=section_id: self.toggle_group(sid))
        parent_layout.addWidget(hdr)
        self._group_labels.append(hdr)
        self._group_headers[section_id] = hdr

        container = QWidget(self)
        container.setObjectName(f"sidebarSection_{section_id}")
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(0, 0, 0, 2)
        container_layout.setSpacing(2)
        parent_layout.addWidget(container)
        self._section_containers[section_id] = container
        self._section_buttons[section_id] = []
        return container_layout

    def _add_nav_item(self, layout: QVBoxLayout, key: str, icon_name: str,
                      text: str, group: str, active: bool = False, badge: str = "",
                      section: str = ""):
        btn = _SidebarNavButton(key, icon_name, text, badge_text=badge, parent=self)
        btn.setObjectName("sidebarItem")
        if active:
            btn.set_active(True)

        btn.clicked.connect(lambda: self._on_item_clicked(key, group))
        layout.addWidget(btn)
        self._nav_buttons[key] = btn
        if section in self._section_buttons:
            self._section_buttons[section].append(btn)

    def _sync_group_indicators(self):
        for sec_id, hdr in self._group_headers.items():
            buttons = self._section_buttons.get(sec_id, [])
            has_active = any(b._is_active for b in buttons)
            has_daemon = any(b.badge_text in ("ON", "ONLINE") for b in buttons)
            hdr.set_indicators(has_active, has_daemon)

    def toggle_group(self, section_id: str):
        """Toggle collapsed / expanded state of an individual sidebar group."""
        if section_id not in self._group_headers:
            return
        new_state = not self._collapsed_groups.get(section_id, False)
        self.set_group_collapsed(section_id, new_state, emit_signal=True)

    def set_group_collapsed(self, section_id: str, collapsed: bool, emit_signal: bool = False):
        """Set collapsed state for a single section ID."""
        if section_id not in self._group_headers:
            return
        is_collapsed = bool(collapsed)
        self._collapsed_groups[section_id] = is_collapsed
        self._group_headers[section_id].set_group_collapsed(is_collapsed)
        self._section_containers[section_id].setVisible(not is_collapsed)
        self._sync_group_indicators()
        if emit_signal:
            logger.info(f"{TAG} Group {section_id!r} {'collapsed' if is_collapsed else 'expanded'}")
            self.collapsed_groups_changed.emit(self.get_collapsed_groups())

    def is_group_collapsed(self, section_id: str) -> bool:
        return bool(self._collapsed_groups.get(section_id, False))

    def get_collapsed_groups(self) -> list[str]:
        """Return ordered list of currently collapsed group IDs for config persistence."""
        return [gid for gid in self.ALL_GROUPS if self._collapsed_groups.get(gid, False)]

    def set_collapsed_groups(self, collapsed_ids: list[str] | set[str] | tuple[str, ...]):
        """Restore collapsed group state from persisted config without emitting change signal."""
        wanted = {str(x) for x in (collapsed_ids or ())}
        for gid in self.ALL_GROUPS:
            is_col = gid in wanted
            self._collapsed_groups[gid] = is_col
            self._group_headers[gid].set_group_collapsed(is_col)
            self._section_containers[gid].setVisible(not is_col)
        self._sync_group_indicators()

    def _on_item_clicked(self, key: str, group: str):
        self.set_active_item(key)
        if group == "lib":
            self.category_selected.emit(key)
        elif group == "tool":
            self.tool_triggered.emit(key)
        elif group == "device":
            self.device_triggered.emit(key)
        elif group == "system":
            self.system_triggered.emit(key)

    def set_active_item(self, key: str):
        """Set active navigation item across all groups with pixel-perfect highlight."""
        for k, btn in self._nav_buttons.items():
            btn.set_active(k == key)
        self._sync_group_indicators()

    def set_active_category(self, key: str):
        """Set active category / nav item across all sidebar items."""
        self.set_active_item(key)

    def active_button(self):
        """The highlighted nav button (first one if none), used as controller focus anchor."""
        for sec_id, buttons in self._section_buttons.items():
            for btn in buttons:
                if btn._is_active:
                    if self._collapsed_groups.get(sec_id, False) and not self._collapsed:
                        return self._group_headers.get(sec_id, btn)
                    return btn
        return next(iter(self._nav_buttons.values()), None)

    def update_counts(self, total: int = 0, installed: int = 0, uninstalled: int = 0,
                      synced: int = 0, unsynced: int = 0, favorites: int = 0, *args, **kwargs):
        """Update category count badges in sidebar."""
        badges = {
            "all": str(total),
            "installed": str(installed),
            "uninstalled": str(uninstalled),
            "synced": str(synced),
            "unsynced": str(unsynced),
            "favorites": str(favorites),
        }
        for key, val in badges.items():
            if key in self._nav_buttons:
                self._nav_buttons[key].set_badge(val)

    def set_net_unblock_status(self, is_active: bool):
        """Update live status indicator on Net Unblock nav button."""
        btn = self._nav_buttons.get("net_unblock")
        if btn:
            btn.set_badge("ON" if is_active else "", is_highlight=is_active)
            self._sync_group_indicators()

    def set_lan_drop_status(self, is_active: bool):
        """Update live status indicator on the BobDrop LAN sharing nav button."""
        btn = self._nav_buttons.get("lan_drop")
        if btn:
            btn.set_badge("ON" if is_active else "", is_highlight=is_active)
            self._sync_group_indicators()

    def set_steam_chat_status(self, is_active: bool):
        """Update live status indicator on the Steam Chat Overlay nav button."""
        btn = self._nav_buttons.get("steam_chat")
        if btn:
            btn.set_badge("ON" if is_active else "", is_highlight=is_active)
            self._sync_group_indicators()

    def set_account_status(self, logged_in: bool, display_name: str = ""):
        """Update the account button text based on login state (no redundant ONLINE badge)."""
        btn = self._nav_buttons.get("account")
        if btn:
            if logged_in:
                btn.label_text = display_name if display_name else "Đã kết nối Cloud"
            else:
                btn.label_text = "Tài khoản Cloud"
            btn.set_badge("")
            btn._update_text()
            btn.update()

    def toggle_collapse(self):
        """Toggle collapsed / expanded sidebar mode."""
        self._collapsed = not self._collapsed
        target_width = self.COLLAPSED_WIDTH if self._collapsed else self.EXPANDED_WIDTH
        self.setFixedWidth(target_width)

        # Toggle logo visibility
        self.logo_card.setVisible(not self._collapsed)
        self.logo_icon_label.setVisible(self._collapsed)

        for lbl in self._group_labels:
            lbl.setVisible(not self._collapsed)

        for btn in self._nav_buttons.values():
            btn.set_collapsed(self._collapsed)

        if self._collapsed:
            self.collapse_btn.setText("▶")
            self.collapse_btn.setToolTip("Mở rộng menu")
        else:
            self.collapse_btn.setText("◀ Thu gọn")
            self.collapse_btn.setToolTip("")

        self.collapse_toggled.emit(self._collapsed)
