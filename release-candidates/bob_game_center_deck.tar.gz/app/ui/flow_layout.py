"""
Flow Layout for Bob Gaming Game Center.
Custom QLayout that wraps widgets like CSS flexbox wrap.
"""

from PySide6.QtWidgets import QLayout, QSizePolicy
from PySide6.QtCore import QRect, QSize, Qt, QPoint


class FlowLayout(QLayout):
    """A layout that arranges widgets in a flow, wrapping to the next line when needed."""

    def __init__(self, parent=None, margin: int = 0, spacing: int = -1):
        super().__init__(parent)
        if margin >= 0:
            self.setContentsMargins(margin, margin, margin, margin)
        if spacing >= 0:
            self.setSpacing(spacing)
        self._item_list: list = []

    def __del__(self):
        while self.takeAt(0):
            pass

    def addItem(self, item):
        """Add an item to the layout."""
        self._item_list.append(item)

    def count(self) -> int:
        """Return the number of items."""
        return len(self._item_list)

    def itemAt(self, index: int):
        """Return the item at the given index."""
        if 0 <= index < len(self._item_list):
            return self._item_list[index]
        return None

    def takeAt(self, index: int):
        """Remove and return the item at the given index."""
        if 0 <= index < len(self._item_list):
            return self._item_list.pop(index)
        return None

    def expandingDirections(self):
        """Return the expanding directions."""
        return Qt.Orientation(0)

    def hasHeightForWidth(self) -> bool:
        """This layout supports height-for-width."""
        return True

    def heightForWidth(self, width: int) -> int:
        """Calculate the required height for the given width."""
        return self._do_layout(QRect(0, 0, width, 0), test_only=True)

    def setGeometry(self, rect: QRect):
        """Set the geometry of all items in the layout."""
        super().setGeometry(rect)
        self._do_layout(rect, test_only=False)

    def sizeHint(self) -> QSize:
        """Return the preferred size."""
        return self.minimumSize()

    def minimumSize(self) -> QSize:
        """Return the minimum size needed by the layout."""
        size = QSize()
        for item in self._item_list:
            size = size.expandedTo(item.minimumSize())
        margins = self.contentsMargins()
        size += QSize(
            margins.left() + margins.right(),
            margins.top() + margins.bottom()
        )
        return size

    def _do_layout(self, rect: QRect, test_only: bool) -> int:
        """
        Perform the layout calculation.

        Args:
            rect: The available rectangle
            test_only: If True, only calculate height without moving widgets

        Returns:
            The total height used
        """
        margins = self.contentsMargins()
        effective_rect = rect.adjusted(
            margins.left(), margins.top(),
            -margins.right(), -margins.bottom()
        )

        x = effective_rect.x()
        y = effective_rect.y()
        line_height = 0
        spacing = self.spacing()

        for item in self._item_list:
            widget = item.widget()
            if widget and widget.isHidden():
                continue

            item_size = item.sizeHint()
            next_x = x + item_size.width() + spacing

            if next_x - spacing > effective_rect.right() and line_height > 0:
                x = effective_rect.x()
                y = y + line_height + spacing
                next_x = x + item_size.width() + spacing
                line_height = 0

            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), item_size))

            x = next_x
            line_height = max(line_height, item_size.height())

        return y + line_height - rect.y() + margins.bottom()
