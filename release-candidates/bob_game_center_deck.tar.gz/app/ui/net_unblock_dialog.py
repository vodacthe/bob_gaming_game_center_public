"""
Network Unblock control panel for Bob Gaming Game Center.

Lets the user diagnose which sites their ISP blocks (DNS poisoning / SNI blocking), apply the fix
(hosts-file block + local split-ClientHello proxy), refresh it, or undo everything.

All manager calls that can block run on a worker QThread; the GUI thread only touches
settings, status() and view_changes(), which are cheap.
"""

import os
import logging
import threading
import time

from app.config import get_app_dir

CHECK_ICON_PATH = os.path.join(get_app_dir(), "assets", "checkbox_check.svg").replace("\\", "/")

from PySide6.QtCore import QEvent, QObject, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.net_unblock.dpi_engine import DEFAULT_PRESET, PRESETS, get_preset
from app.core.net_unblock.models import EngineState, EngineStatus, HostRow, HostStatus, Verdict
from app.core.net_unblock.presets import GROUPS, MAX_CUSTOM_DOMAINS, normalize_host
from app.core.net_unblock.settings import CONSENT_VERSION
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader

logger = logging.getLogger(__name__)

_STOP_WAIT_MS = 3000        # how long closing the dialog waits for a cancelled operation
_STATUS_REFRESH_MS = 5000   # engine badge refresh interval
_CUSTOM_COMMIT_MS = 600     # debounce for the custom-domains editor

_GREEN, _GREY, _AMBER, _RED, _BLUE = "#2ed573", "#8b949e", "#d29922", "#ff4757", "#388bfd"

_VERDICT_LABELS = {
    Verdict.OK: "OK",
    Verdict.DNS_POISON: "DNS blocked",
    Verdict.SNI_RST: "SNI blocked",
    Verdict.IP_BLACKHOLE: "IP blocked",
    Verdict.UNREACHABLE: "Unreachable",
    Verdict.OFFLINE: "Offline",
}

_STATUS_LABELS = {
    HostStatus.NOTHING_BLOCKED: "Not blocked",
    HostStatus.NEEDS_FIX: "Would fix",
    HostStatus.APPLIED_HOSTS: "Hosts applied",
    HostStatus.APPLIED_PROXY: "Proxy applied",
    HostStatus.APPLIED_BOTH: "Hosts + proxy",
    HostStatus.APPLIED_DPI: "Packet engine",
    HostStatus.MANUAL_OK: "Your entry works",
    HostStatus.MANUAL_STALE: "Your entry is stale",
    HostStatus.NOT_FIXABLE: "Can't fix",
    HostStatus.OFFLINE: "Offline",
    HostStatus.FAILED: "Failed",
}

_STATUS_COLORS = {
    HostStatus.NOTHING_BLOCKED: _GREY,
    HostStatus.OFFLINE: _GREY,
    HostStatus.APPLIED_HOSTS: _GREEN,
    HostStatus.APPLIED_PROXY: _GREEN,
    HostStatus.APPLIED_BOTH: _GREEN,
    HostStatus.APPLIED_DPI: _GREEN,
    HostStatus.MANUAL_OK: _GREEN,
    HostStatus.MANUAL_STALE: _AMBER,
    HostStatus.NEEDS_FIX: _AMBER,
    HostStatus.NOT_FIXABLE: _RED,
    HostStatus.FAILED: _RED,
}

# state -> (badge text, text/border colour, translucent background)
_STATE_BADGES = {
    EngineState.OFF: ("OFF", _GREY, "rgba(139, 148, 158, 0.15)"),
    EngineState.ACTIVE: ("ACTIVE", _GREEN, "rgba(46, 213, 115, 0.15)"),
    EngineState.HOSTS_ONLY: ("HOSTS ONLY", _BLUE, "rgba(31, 111, 235, 0.20)"),
    EngineState.DEGRADED: ("DEGRADED", _AMBER, "rgba(210, 153, 34, 0.20)"),
    EngineState.NOT_ADMIN: ("NEEDS ADMIN", _RED, "rgba(255, 71, 87, 0.15)"),
}

_STATE_KINDS = {
    EngineState.OFF: "off", EngineState.ACTIVE: "ok", EngineState.HOSTS_ONLY: "info",
    EngineState.DEGRADED: "warn", EngineState.NOT_ADMIN: "error",
}

_OP_TITLES = {"diagnose": "Diagnose", "apply": "Scan & Apply", "refresh": "Refresh IPs", "restore": "Restore everything"}

_TABLE_HEADERS = ("Host", "Group", "Verdict", "System DNS", "Fix", "Status", "RTT (ms)")

_CONSENT_TEXT = (
    "Network Unblock helps you reach websites that your internet provider blocks. "
    "Here is exactly what it changes:\n\n"
    "• It edits a clearly marked block in the Windows hosts file (a backup is kept).\n"
    "• While this app runs, it may set a local proxy auto-config (PAC) URL in your Windows "
    "internet settings.\n"
    "• It runs a small proxy on 127.0.0.1 (your own computer only).\n"
    "• Public DNS-over-HTTPS providers (Cloudflare, Quad9, Google) will see the domain names "
    "that are looked up.\n"
    "• Using it may be restricted by law or by your ISP's terms where you live. "
    "You are responsible for how you use it.\n\n"
    "Everything can be undone at any time with \"Restore everything\"."
)

_STYLE = """
QDialog { background-color: #0b0e14; border: 1px solid rgba(212, 175, 55, 0.25); border-radius: 12px; }
QLabel { color: #e2e8f0; font-size: 13px; background: transparent; }
QFrame#card { background-color: rgba(18, 23, 33, 0.75); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 10px; }
QLabel#banner {
    background-color: rgba(18, 23, 33, 0.8); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 6px;
    padding: 8px 10px; font-size: 12px;
}
QLabel#adminBanner {
    background-color: rgba(212, 175, 55, 0.15); color: #f5d061; border: 1px solid rgba(212, 175, 55, 0.45);
    border-radius: 6px; padding: 8px 10px; font-size: 12px; font-weight: bold;
}
QCheckBox { color: #cbd5e1; font-size: 12px; spacing: 8px; background: transparent; }
QCheckBox::indicator {
    width: 16px; height: 16px; border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 4px; background-color: rgba(12, 16, 24, 0.8);
}
QCheckBox::indicator:hover { border-color: rgba(139, 92, 246, 0.6); }
QCheckBox::indicator:unchecked { image: none; }
QCheckBox::indicator:checked { background-color: #8b5cf6; border: 1px solid #a78bfa; border-radius: 4px; image: url("__CHECK_ICON_PATH__"); }
QCheckBox::indicator:checked:hover { background-color: #7c3aed; border-color: #c084fc; }
QCheckBox:disabled { color: #475569; }
QPlainTextEdit {
    background-color: rgba(10, 14, 22, 0.9); color: #cbd5e1; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 6px;
    font-family: 'Consolas', 'Courier New', monospace; font-size: 11px;
}
QPlainTextEdit#log { color: #94a3b8; border-color: rgba(255, 255, 255, 0.06); }
QTableWidget {
    background-color: rgba(14, 18, 26, 0.85); alternate-background-color: rgba(20, 26, 38, 0.85); color: #e2e8f0;
    gridline-color: rgba(255, 255, 255, 0.06); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 6px; font-size: 12px;
    selection-background-color: rgba(139, 92, 246, 0.25); selection-color: #ffffff;
}
QHeaderView::section {
    background-color: rgba(20, 26, 38, 0.95); color: #94a3b8; padding: 6px; border: 1px solid rgba(255, 255, 255, 0.06); font-weight: bold;
}
QPushButton {
    background-color: rgba(255, 255, 255, 0.05); color: #cbd5e1; border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 6px;
    padding: 6px 14px; font-size: 12px; font-weight: bold;
}
QPushButton:hover { background-color: rgba(255, 255, 255, 0.1); color: #ffffff; border-color: rgba(139, 92, 246, 0.5); }
QPushButton:disabled { background-color: rgba(255, 255, 255, 0.02); color: #475569; border-color: rgba(255, 255, 255, 0.04); }
QPushButton#primaryBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #8b5cf6, stop:0.5 #7c3aed, stop:1 #6d28d9);
    color: #ffffff; border: 1px solid rgba(168, 85, 247, 0.6);
}
QPushButton#primaryBtn:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #a855f7, stop:0.5 #8b5cf6, stop:1 #7c3aed);
}
QPushButton#successBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #10b981, stop:1 #047857);
    color: #ffffff; border: 1px solid rgba(52, 211, 153, 0.5);
}
QPushButton#successBtn:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #34d399, stop:1 #059669);
}
QPushButton#dangerBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #dc2626, stop:1 #991b1b);
    color: #ffffff; border: 1px solid rgba(248, 113, 113, 0.5);
}
QPushButton#dangerBtn:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ef4444, stop:1 #b91c1c);
}
QPushButton#primaryBtn:disabled, QPushButton#successBtn:disabled, QPushButton#dangerBtn:disabled {
    background-color: rgba(255, 255, 255, 0.02); color: #475569; border-color: rgba(255, 255, 255, 0.04);
}
QProgressBar {
    border: 1px solid #30363d; border-radius: 4px; background-color: #21262d; text-align: center;
    color: #ffffff; font-size: 11px; font-weight: bold; height: 14px;
}
QProgressBar::chunk { background-color: #2ed573; border-radius: 3px; }
""".replace("__CHECK_ICON_PATH__", CHECK_ICON_PATH)


# --------------------------------------------------------------------------------------------
# Pure helpers (no Qt widgets) - easy to unit test
# --------------------------------------------------------------------------------------------

def verdict_label(verdict: Verdict) -> str:
    return _VERDICT_LABELS.get(verdict, str(getattr(verdict, "value", verdict)))


def status_label(status: HostStatus) -> str:
    return _STATUS_LABELS.get(status, str(getattr(status, "value", status)))


def state_label(state: EngineState) -> str:
    return _STATE_BADGES.get(state, (str(getattr(state, "value", state)),))[0]


def group_label(group_id: str) -> str:
    group = GROUPS.get(group_id)
    return group.label if group else str(group_id).capitalize()


def _format_time(ts: float | None) -> str:
    if not ts:
        return "never"
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))


def _row_cells(row: HostRow) -> list[str]:
    """The seven display strings of one result row (shared by the table and the text report)."""
    ips = list(row.local_ips or [])
    dns = ", ".join(ips[:2]) + (f" (+{len(ips) - 2})" if len(ips) > 2 else "")
    return [
        row.host,
        group_label(row.group),
        verdict_label(row.verdict),
        dns or "—",
        row.chosen or "—",
        status_label(row.status),
        f"{row.rtt_ms:.0f}" if row.rtt_ms and row.rtt_ms > 0 else "—",
    ]


def _status_lines(status: EngineStatus) -> list[str]:
    if status.proxy_port:
        proxy = f"127.0.0.1:{status.proxy_port} ({'all sites' if status.all_sites else f'{status.proxy_hosts} hosts'})"
    else:
        proxy = "not running"
    return [
        f"Engine: {state_label(status.state)} (administrator: {'yes' if status.is_admin else 'no'})",
        f"Hosts-file entries: {status.hosts_applied}",
        f"Local proxy: {proxy}",
        "Packet engine: " + (f"running (preset {status.dpi_preset})" if status.dpi else "not running"),
        f"Last refresh: {_format_time(status.last_refresh)}",
    ]


def build_banners(rows: list[HostRow], status: EngineStatus | None) -> list[str]:
    """Plain-text notes shown under the results table, derived from the rows and engine status."""
    out: list[str] = []
    if rows and all(r.status == HostStatus.NOTHING_BLOCKED for r in rows):
        out.append("Nothing is blocked on your network right now — no changes were needed.")
    if any(r.verdict == Verdict.IP_BLACKHOLE or r.status == HostStatus.NOT_FIXABLE for r in rows):
        out.append(
            "Some sites are blocked by IP address. A hosts file or proxy cannot fix that — "
            "you need a VPN or Cloudflare WARP."
        )
    if any(r.status in (HostStatus.APPLIED_PROXY, HostStatus.APPLIED_BOTH) for r in rows):
        out.append(
            "The local proxy covers browsers and apps that use the Windows proxy settings. "
            "The Steam client's own downloads may not be covered."
        )
    if status is not None and status.all_sites:
        out.append(
            "All-sites mode is on: browsers send every HTTPS site through the local proxy, which only splits the "
            "hello of sites that get reset. Apps that ignore the Windows proxy settings (Steam client, games) and "
            "IP-address blocks are not covered."
        )
    if status is not None and status.dpi:
        out.append(
            "The packet engine is running: it reshapes the start of every HTTPS connection system-wide, so any app "
            "is covered. It stops by itself when anti-cheat software starts; IP-address blocks are not covered."
        )
    if any(r.verdict == Verdict.OFFLINE or r.status == HostStatus.OFFLINE for r in rows):
        out.append("No internet connection detected.")
    if status is not None:
        out.extend(w for w in status.warnings if w)
    return out


def format_report(rows: list[HostRow], status: EngineStatus, changes_text: str, now: float | None = None) -> str:
    """Plain-text support report: engine status, last results table and what is applied on this PC."""
    lines = [
        "Bob Gaming Game Center - Network Unblock report",
        f"Generated: {_format_time(now if now is not None else time.time())}",
        "",
        *_status_lines(status),
        *(f"Warning: {w}" for w in status.warnings),
        "",
    ]
    if rows:
        table = [list(_TABLE_HEADERS)] + [_row_cells(r) for r in rows]
        widths = [max(len(line[c]) for line in table) for c in range(len(_TABLE_HEADERS))]
        for line in table:
            lines.append("  ".join(cell.ljust(widths[c]) for c, cell in enumerate(line)).rstrip())
        notes = [f"  {r.host}: {r.note}" for r in rows if r.note]
        if notes:
            lines += ["", "Notes:", *notes]
    else:
        lines.append("No results yet (run Diagnose first).")
    lines += ["", "Currently applied on this PC:", (changes_text or "").strip() or "(nothing)", ""]
    return "\n".join(lines)


# --------------------------------------------------------------------------------------------
# Worker
# --------------------------------------------------------------------------------------------

class _NetWorker(QObject):
    """Runs one blocking manager operation off the GUI thread."""

    progress = Signal(int, int, str)  # (done, total, message)
    finished = Signal(list)           # list[HostRow] (list[str] messages for "restore")
    failed = Signal(str)

    def __init__(self, manager, op: str):
        super().__init__()
        self.manager = manager
        self.op = op
        self.cancel_event = threading.Event()

    def cancel(self):
        self.cancel_event.set()

    def _on_progress(self, done: int, total: int, message: str = ""):
        self.progress.emit(int(done), int(total), str(message))

    def run(self):
        try:
            if self.op == "restore":
                result = self.manager.restore_all()
            else:
                method = {
                    "diagnose": self.manager.diagnose,
                    "apply": self.manager.apply_auto,
                    "refresh": self.manager.refresh,
                }[self.op]
                result = method(progress=self._on_progress, cancel=self.cancel_event)
            self.finished.emit(list(result or []))
        except Exception as e:  # anything the manager raises must reach the UI
            logger.exception(f"[NetUnblock] {self.op} failed")
            self.failed.emit(str(e) or e.__class__.__name__)


# --------------------------------------------------------------------------------------------
# Dialog
# --------------------------------------------------------------------------------------------

class NetUnblockDialog(QDialog):
    """Control panel for the Network Unblock feature."""

    back_requested = Signal()
    status_changed = Signal(bool)

    def __init__(self, parent=None, manager=None):
        if manager is None:
            raise ValueError("NetUnblockDialog requires a NetUnblockManager")
        super().__init__(parent)
        self.manager = manager
        self._is_admin = bool(manager.is_admin())
        self._thread: QThread | None = None
        self._worker: _NetWorker | None = None
        self._current_op = ""
        self._rows: list[HostRow] = []
        self._status = EngineStatus()
        self._loading = True            # True while widgets are filled from settings
        self._close_when_idle = False

        self.setWindowTitle("Network Unblock")
        self.resize(880, 680)
        self.setMinimumSize(760, 560)
        self.setSizeGripEnabled(True)
        self.setStyleSheet(_STYLE)

        self._build_ui()
        self._load_settings_into_widgets()
        self._loading = False

        self._custom_timer = QTimer(self)
        self._custom_timer.setSingleShot(True)
        self._custom_timer.setInterval(_CUSTOM_COMMIT_MS)
        self._custom_timer.timeout.connect(lambda: self._commit_custom_domains(report=False))

        self._timer = QTimer(self)
        self._timer.setInterval(_STATUS_REFRESH_MS)
        self._timer.timeout.connect(self._on_timer)
        self._timer.start()

        self._refresh_status()
        self._update_buttons()

    def _on_back(self):
        self.back_requested.emit()
        self.close()

    # ---- UI construction ------------------------------------------------------------------

    @staticmethod
    def _hint(text: str, indent: int = 0) -> QLabel:
        label = QLabel(text)
        label.setWordWrap(True)
        label.setStyleSheet("color: #8b949e; font-size: 11px; background: transparent;")
        label.setContentsMargins(indent, 0, 0, 0)
        return label

    def _make_button(self, text: str, slot, name: str = "", tip: str = "") -> QPushButton:
        btn = QPushButton(text)
        if name:
            btn.setObjectName(name)
        if tip:
            btn.setToolTip(tip)
        btn.clicked.connect(slot)
        return btn

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        header = ScreenHeader(
            "Mở chặn mạng", "globe",
            subtitle="Vượt chặn DNS / SNI của nhà mạng (không hỗ trợ chặn IP)")
        header.back_requested.connect(self._on_back)
        self.last_refresh_label = header.add_hint("Last refresh: never")
        self.master_toggle_btn = header.add_button("▶ BẬT MỞ CHẶN MẠNG", "success")
        self.master_toggle_btn.clicked.connect(self._on_master_toggle_clicked)
        self.status_badge = header.add_badge("OFF", "off")
        outer.addWidget(header)

        body = QWidget()
        root = QVBoxLayout(body)
        root.setContentsMargins(*CONTENT_MARGINS)
        root.setSpacing(8)
        outer.addWidget(body, 1)

        self.admin_banner = QLabel("Run Bob Gaming Game Center as Administrator to apply changes. "
                                   "Diagnose works without it.")
        self.admin_banner.setObjectName("adminBanner")
        self.admin_banner.setWordWrap(True)
        root.addWidget(self.admin_banner)
        self.admin_banner.setVisible(not self._is_admin)    # after addWidget: parentless it flashes as a window

        # Settings (disabled while an operation runs)
        self._settings_panel = QWidget()
        panel = QVBoxLayout(self._settings_panel)
        panel.setContentsMargins(0, 0, 0, 0)
        panel.setSpacing(8)
        panel.addLayout(self._build_sites_row())
        panel.addLayout(self._build_options_row())
        root.addWidget(self._settings_panel)

        # Action buttons
        buttons = QHBoxLayout()
        self.diagnose_btn = self._make_button(
            "Chẩn đoán", self._on_diagnose_clicked, "primaryBtn", "Kiểm tra danh sách các trang web bị chặn (Diagnose).")
        self.diagnose_btn.setIcon(make_svg_icon("search", size=14, color="#0b0e14"))
        self.apply_btn = self._make_button(
            "Quét và Mở chặn", self._on_apply_clicked, "successBtn", "Tìm IP hoạt động và áp dụng mở chặn trang web (Bật mở chặn)")
        self.apply_btn.setIcon(make_svg_icon("shield", size=14, color="#ffffff"))
        self.refresh_btn = self._make_button(
            "Làm mới IP", self._on_refresh_clicked, tip="Kiểm tra lại các địa chỉ IP đang được áp dụng (Refresh IPs)")
        self.refresh_btn.setIcon(make_svg_icon("refresh", size=14, color="#cbd5e1"))
        self.restore_btn = self._make_button(
            "Khôi phục gốc", self._on_restore_clicked, "dangerBtn", "Dừng mở chặn và khôi phục cài đặt mạng ban đầu (Tắt mở chặn)")
        self.restore_btn.setIcon(make_svg_icon("trash", size=14, color="#ffffff"))
        self.copy_btn = self._make_button(
            "Sao chép báo cáo", self._on_copy_clicked, tip="Sao chép báo cáo chẩn đoán vào bộ nhớ tạm")
        self.copy_btn.setIcon(make_svg_icon("copy", size=14, color="#cbd5e1"))
        self.cancel_btn = self._make_button("Hủy", self._on_cancel_clicked, tip="Dừng thao tác đang chạy (Cancel)")
        self.cancel_btn.setIcon(make_svg_icon("close", size=14, color="#ffffff"))
        for btn in (self.diagnose_btn, self.apply_btn, self.refresh_btn, self.restore_btn):
            buttons.addWidget(btn)
        buttons.addStretch()
        for btn in (self.copy_btn, self.cancel_btn):
            buttons.addWidget(btn)
        self.cancel_btn.setVisible(False)
        if not self._is_admin:
            for btn in (self.apply_btn, self.refresh_btn, self.restore_btn):
                btn.setToolTip(f"{btn.toolTip()} (requires Administrator)")
        root.addLayout(buttons)

        # Results table
        self.table = QTableWidget(0, len(_TABLE_HEADERS))
        self.table.setHorizontalHeaderLabels([
            "Máy chủ (Host)", "Nhóm (Group)", "Kết luận (Verdict)", "DNS Hệ thống", "Địa chỉ sửa (Fix)", "Trạng thái", "Độ trễ RTT (ms)"
        ])
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setMinimumHeight(110)
        hdr = self.table.horizontalHeader()
        for col in range(len(_TABLE_HEADERS)):
            hdr.setSectionResizeMode(
                col, QHeaderView.ResizeMode.Stretch if col == 0 else QHeaderView.ResizeMode.ResizeToContents)
        root.addWidget(self.table, 1)

        self.banner_label = QLabel()
        self.banner_label.setObjectName("banner")
        self.banner_label.setWordWrap(True)
        self.banner_label.setTextFormat(Qt.TextFormat.PlainText)
        self.banner_label.setVisible(False)
        root.addWidget(self.banner_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        root.addWidget(self.progress_bar)
        self.status_label = QLabel("Sẵn sàng. Bấm Chẩn đoán để kiểm tra kết nối (không thay đổi hệ thống).")
        self.status_label.setStyleSheet("color: #8b949e; font-size: 12px;")
        root.addWidget(self.status_label)

        self.log_console = QPlainTextEdit()
        self.log_console.setObjectName("log")
        self.log_console.setReadOnly(True)
        self.log_console.setMaximumBlockCount(2000)
        self.log_console.setFixedHeight(80)
        root.addWidget(self.log_console)

    def _build_sites_row(self) -> QHBoxLayout:
        row = QHBoxLayout()
        row.setSpacing(10)

        sites = QFrame()
        sites.setObjectName("card")
        sites_layout = QVBoxLayout(sites)
        sites_layout.setContentsMargins(14, 12, 14, 12)
        sites_layout.setSpacing(8)
        heading = QLabel("Danh sách trang web (Sites)")
        heading.setStyleSheet("color: #ffffff; font-weight: bold;")
        sites_layout.addWidget(heading)
        grid = QGridLayout()
        grid.setHorizontalSpacing(20)
        grid.setVerticalSpacing(8)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        self.group_checks: dict[str, QCheckBox] = {}
        for i, (gid, group) in enumerate(GROUPS.items()):
            cell = QVBoxLayout()
            cell.setSpacing(2)
            cb = QCheckBox(group.label)
            cb.toggled.connect(lambda checked, g=gid: self._on_group_toggled(g, checked))
            self.group_checks[gid] = cb
            cell.addWidget(cb)
            cell.addWidget(self._hint(group.description, indent=24))
            grid.addLayout(cell, i // 2, i % 2)
        sites_layout.addLayout(grid)
        sites_layout.addStretch(1)
        row.addWidget(sites, 3)

        custom = QFrame()
        custom.setObjectName("card")
        custom_layout = QVBoxLayout(custom)
        custom_layout.setContentsMargins(14, 12, 14, 12)
        custom_layout.setSpacing(8)
        heading = QLabel("Tên miền tùy chỉnh (Custom domains)")
        heading.setStyleSheet("color: #ffffff; font-weight: bold;")
        custom_layout.addWidget(heading)
        self.custom_edit = QPlainTextEdit()
        self.custom_edit.setPlaceholderText("example.com")
        self.custom_edit.setMinimumHeight(60)
        self.custom_edit.textChanged.connect(self._on_custom_text_changed)
        self.custom_edit.installEventFilter(self)
        custom_layout.addWidget(self.custom_edit, 1)
        custom_layout.addWidget(self._hint(f"Nhập 1 tên miền mỗi dòng (tối đa {MAX_CUSTOM_DOMAINS}). Các dòng không hợp lệ sẽ bị bỏ qua."))
        row.addWidget(custom, 2)
        return row

    def _build_options_row(self) -> QVBoxLayout:
        box = QVBoxLayout()
        box.setSpacing(8)
        row = QHBoxLayout()
        row.setSpacing(16)
        self.auto_apply_cb = QCheckBox("Tự động áp dụng khi khởi động ứng dụng")
        self.auto_apply_cb.toggled.connect(lambda checked: self._on_option_toggled("auto_apply", checked))
        self.takeover_cb = QCheckBox("Ghi đè các mục hosts cũ không hoạt động (Nâng cao)")
        self.takeover_cb.toggled.connect(lambda checked: self._on_option_toggled("takeover", checked))
        for cb, hint in (
            (self.auto_apply_cb, "Tự động kiểm tra lại IP và khởi động proxy cục bộ mỗi lần mở ứng dụng"),
            (self.takeover_cb, "Chỉ các dòng hosts cũ bị hỏng mới được thay thế; hệ thống luôn lưu bản backup"),
        ):
            col = QVBoxLayout()
            col.setSpacing(0)
            col.addWidget(cb)
            col.addWidget(self._hint(hint, indent=24))
            row.addLayout(col, 1)
        box.addLayout(row)
        self.all_sites_cb = QCheckBox("Mở chặn toàn bộ trang web trên trình duyệt (Adaptive Proxy)")
        self.all_sites_cb.toggled.connect(self._on_all_sites_toggled)
        col = QVBoxLayout()
        col.setSpacing(0)
        col.addWidget(self.all_sites_cb)
        col.addWidget(self._hint("Áp dụng cho mọi trang web. Thử kết nối trực tiếp trước và chỉ "
                                 "chia nhỏ ClientHello khi bị chặn. Có hiệu lực khi Quét & Mở chặn.", indent=24))
        box.addLayout(col)
        box.addLayout(self._build_dpi_row())
        return box

    def _build_dpi_row(self) -> QVBoxLayout:
        col = QVBoxLayout()
        col.setSpacing(0)
        head = QHBoxLayout()
        head.setSpacing(12)
        self.dpi_cb = QCheckBox("Packet engine cho mọi ứng dụng (GoodbyeDPI / WinDivert)")
        self.dpi_cb.toggled.connect(self._on_dpi_toggled)
        self.dpi_preset_combo = QComboBox()
        for preset in PRESETS.values():
            self.dpi_preset_combo.addItem(preset.label, preset.id)
        self.dpi_preset_combo.currentIndexChanged.connect(self._on_dpi_preset_changed)
        head.addWidget(self.dpi_cb)
        head.addWidget(self.dpi_preset_combo)
        head.addStretch(1)
        col.addLayout(head)
        self.dpi_hint = self._hint("", indent=24)
        col.addWidget(self.dpi_hint)
        return col

    def _load_settings_into_widgets(self):
        s = self.manager.settings
        for gid, cb in self.group_checks.items():
            on = bool(s.groups.get(gid, GROUPS[gid].default_enabled))
            if GROUPS[gid].adult and not s.adult_confirmed:
                on = False  # the core ignores the adult group until confirmed; show the effective state
            cb.setChecked(on)
        self.auto_apply_cb.setChecked(bool(s.auto_apply))
        self.takeover_cb.setChecked(bool(s.takeover))
        self.all_sites_cb.setChecked(bool(s.all_sites))
        self.dpi_cb.setChecked(bool(s.dpi_engine))
        index = self.dpi_preset_combo.findData(get_preset(s.dpi_preset).id)
        self.dpi_preset_combo.setCurrentIndex(max(index, 0))
        self._update_dpi_widgets()
        self.custom_edit.setPlainText("\n".join(s.custom_domains))

    # ---- settings handlers ----------------------------------------------------------------

    def _save(self):
        try:
            self.manager.save_settings()
        except Exception as e:
            self._append_log(f"Could not save settings: {e}")

    def _on_group_toggled(self, gid: str, checked: bool):
        if self._loading:
            return
        s = self.manager.settings
        if checked and GROUPS[gid].adult and not s.adult_confirmed:
            reply = QMessageBox.question(
                self,
                "Xác nhận độ tuổi",
                "This enables unblocking adult websites. You must be 18 or older.\n\n"
                "Tính năng này cho phép mở chặn các trang web người lớn. Bạn phải từ 18 tuổi trở lên để tiếp tục. Bạn có đồng ý?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.Yes:
                s.adult_confirmed = True
            else:
                checked = False
                cb = self.group_checks[gid]
                cb.blockSignals(True)
                cb.setChecked(False)
                cb.blockSignals(False)
        s.groups[gid] = checked
        self._save()

    def _on_option_toggled(self, field: str, checked: bool):
        if self._loading:
            return
        setattr(self.manager.settings, field, checked)
        self._save()

    def _on_all_sites_toggled(self, checked: bool):
        if self._loading:
            return
        if checked:
            reply = QMessageBox.question(
                self,
                "Mở chặn mọi trang web",
                "Sau khi Quét & Mở chặn, mọi trang web HTTPS mở trên trình duyệt sẽ đi qua proxy cục bộ trên máy (127.0.0.1).\n"
                "Hệ thống sẽ kết nối trực tiếp trước và chỉ can thiệp với các trang bị chặn. Nếu proxy dừng, trình duyệt sẽ tự động kết nối trực tiếp bình thường.\n\n"
                "Không áp dụng cho: các ứng dụng bỏ qua proxy của Windows (Steam client, games, Discord) và các trang bị chặn theo dải IP.\n\nBạn có muốn bật tính năng này?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                self.all_sites_cb.blockSignals(True)
                self.all_sites_cb.setChecked(False)
                self.all_sites_cb.blockSignals(False)
                return
        self.manager.settings.all_sites = checked
        self._save()

    def _update_dpi_widgets(self):
        self.dpi_preset_combo.setEnabled(self.dpi_cb.isChecked())
        preset = get_preset(self.dpi_preset_combo.currentData() or DEFAULT_PRESET)
        self.dpi_hint.setText(preset.description + " Takes effect on Scan & Apply; replaces the local proxy while it runs.")

    def _on_dpi_toggled(self, checked: bool):
        if self._loading:
            return
        if checked:
            reply = QMessageBox.question(
                self,
                "Packet engine (GoodbyeDPI)",
                "Tính năng này nạp driver WinDivert để phân tách gói tin HTTPS cho mọi ứng dụng trên máy tính. Cần quyền Quản trị viên (Administrator).\n\n"
                "Lưu ý rủi ro: Một số hệ thống chống gian lận trong game (EasyAntiCheat, BattlEye, Vanguard, FACEIT) hoặc phần mềm diệt virus có thể cảnh báo driver can thiệp gói tin. Động cơ sẽ tự động dừng khi phát hiện anti-cheat đang chạy, tuy nhiên bạn nên chủ động tắt trước khi khởi động game có bảo vệ nghiêm ngặt.\n\nBạn có muốn bật tính năng này?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                self.dpi_cb.blockSignals(True)
                self.dpi_cb.setChecked(False)
                self.dpi_cb.blockSignals(False)
                return
        self.manager.settings.dpi_engine = checked
        self._update_dpi_widgets()
        self._save()

    def _on_dpi_preset_changed(self, _index: int):
        if self._loading:
            return
        self.manager.settings.dpi_preset = self.dpi_preset_combo.currentData() or DEFAULT_PRESET
        self._update_dpi_widgets()
        self._save()

    def _on_custom_text_changed(self):
        if not self._loading:
            self._custom_timer.start()

    def eventFilter(self, obj, event):
        # Clean up the editor (and log dropped lines) when the user leaves it for another control.
        if obj is self.custom_edit and event.type() == QEvent.Type.FocusOut and event.reason() not in (
            Qt.FocusReason.ActiveWindowFocusReason, Qt.FocusReason.PopupFocusReason,
        ):
            self._custom_timer.stop()
            self._commit_custom_domains(report=True)
        return super().eventFilter(obj, event)

    def _commit_custom_domains(self, report: bool = True):
        """Validate the editor text into settings.custom_domains. With report=True, also rewrite
        the editor with the clean list and log everything that was dropped."""
        domains: list[str] = []
        invalid: list[str] = []
        extra = 0
        for line in self.custom_edit.toPlainText().splitlines():
            line = line.strip()
            if not line:
                continue
            host = normalize_host(line)
            if host is None:
                invalid.append(line)
            elif host in domains:
                continue
            elif len(domains) >= MAX_CUSTOM_DOMAINS:
                extra += 1
            else:
                domains.append(host)

        s = self.manager.settings
        if domains != list(s.custom_domains):
            s.custom_domains = domains
            self._save()
        if not report:
            return
        for bad in invalid:
            self._append_log(f"Ignored invalid or not-allowed domain: {bad}")
        if extra:
            self._append_log(f"Only the first {MAX_CUSTOM_DOMAINS} custom domains are used; ignored {extra} more.")
        clean = "\n".join(domains)
        if clean != self.custom_edit.toPlainText():
            self._loading = True
            self.custom_edit.setPlainText(clean)
            self._loading = False

    # ---- status / banners / table ---------------------------------------------------------

    def _append_log(self, text: str):
        self.log_console.appendPlainText(text)
        logger.info(f"[NetUnblock] {text}")

    def _on_timer(self):
        # status() may wait on the engine lock while an operation runs; never risk freezing the GUI.
        if self._thread is None:
            self._refresh_status()

    def _refresh_status(self):
        try:
            st = self.manager.status()
        except Exception as e:
            logger.warning(f"[NetUnblock] status() failed: {e}")
            return
        self._status = st
        text = _STATE_BADGES.get(st.state, _STATE_BADGES[EngineState.OFF])[0]
        self.status_badge.set_state(text, _STATE_KINDS.get(st.state, "off"))
        self.status_badge.setToolTip("\n".join(_status_lines(st)))
        self.last_refresh_label.setText(f"Last refresh: {_format_time(st.last_refresh)}")
        self._update_banners()
        is_active = st.state in (EngineState.ACTIVE, EngineState.HOSTS_ONLY) or bool(self.manager.settings.enabled)
        if hasattr(self, "master_toggle_btn"):
            if is_active:
                self.master_toggle_btn.setText("⏹ TẮT MỞ CHẶN MẠNG")
                ScreenHeader.set_button_kind(self.master_toggle_btn, "danger")
                self.master_toggle_btn.setToolTip("Dừng toàn bộ driver can thiệp gói tin, proxy cục bộ và khôi phục cài đặt mạng")
            else:
                self.master_toggle_btn.setText("▶ BẬT MỞ CHẶN MẠNG")
                ScreenHeader.set_button_kind(self.master_toggle_btn, "success")
                self.master_toggle_btn.setToolTip("Quét IP và kích hoạt mở chặn mạng")
        self.status_changed.emit(is_active)

    def _update_banners(self):
        lines = build_banners(self._rows, self._status)
        self.banner_label.setText("\n".join(lines))
        self.banner_label.setVisible(bool(lines))

    def _fill_table(self, rows: list[HostRow]):
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, text in enumerate(_row_cells(row)):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                if row.note:
                    item.setToolTip(row.note)
                if c == 5:
                    item.setForeground(QColor(_STATUS_COLORS.get(row.status, _GREY)))
                elif c == 6:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                self.table.setItem(r, c, item)

    @staticmethod
    def _summarize(rows: list[HostRow]) -> str:
        if not rows:
            return "No sites were checked."
        counts: dict[str, int] = {}
        for r in rows:
            label = status_label(r.status)
            counts[label] = counts.get(label, 0) + 1
        return f"Checked {len(rows)} host(s): " + ", ".join(f"{n} {label.lower()}" for label, n in counts.items())

    def _update_buttons(self):
        busy = self._thread is not None
        if hasattr(self, "master_toggle_btn"):
            self.master_toggle_btn.setEnabled(not busy)
        self.diagnose_btn.setEnabled(not busy)
        for btn in (self.apply_btn, self.refresh_btn, self.restore_btn):
            btn.setEnabled(not busy and self._is_admin)
        self.cancel_btn.setVisible(busy and self._current_op != "restore")  # restore_all() is not cancellable
        self.cancel_btn.setEnabled(busy)
        self._settings_panel.setEnabled(not busy)

    # ---- operations -----------------------------------------------------------------------

    def _start_op(self, op: str) -> bool:
        if self._thread is not None:
            self._append_log("Another operation is still running — wait for it or press Cancel.")
            return False
        self._commit_custom_domains(report=True)

        worker = _NetWorker(self.manager, op)
        thread = QThread()
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_progress)
        worker.finished.connect(self._on_op_finished)
        worker.failed.connect(self._on_op_failed)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(self._on_thread_finished)

        self._thread, self._worker, self._current_op = thread, worker, op
        self.progress_bar.setRange(0, 0)  # busy indicator until the first progress message
        self.progress_bar.setVisible(True)
        self.status_label.setText(f"{_OP_TITLES[op]}…")
        self._append_log(f"{_OP_TITLES[op]} started.")
        self._update_buttons()
        thread.start()
        return True

    def _on_diagnose_clicked(self):
        self._start_op("diagnose")

    def _on_refresh_clicked(self):
        self._start_op("refresh")

    def _on_apply_clicked(self):
        if self._thread is not None or not self._ensure_consent():
            return
        s = self.manager.settings
        if not s.enabled:
            s.enabled = True  # the user explicitly asked to turn the feature on
            self._save()
        self._start_op("apply")

    def _on_master_toggle_clicked(self):
        st = self._status
        is_active = st.state in (EngineState.ACTIVE, EngineState.HOSTS_ONLY) or bool(self.manager.settings.enabled)
        if is_active:
            reply = QMessageBox.question(
                self,
                "Tắt mở chặn mạng",
                "Bạn có muốn dừng hoàn toàn tính năng Mở chặn mạng và khôi phục cài đặt mạng ban đầu của máy tính?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )
            if reply == QMessageBox.StandardButton.Yes:
                self._start_op("restore")
        else:
            self._on_apply_clicked()

    def _on_restore_clicked(self):
        if self._thread is not None:
            return
        reply = QMessageBox.question(
            self,
            "Khôi phục cài đặt gốc",
            "Remove every change made by Network Unblock (hosts block, proxy settings)?\n\n"
            "Hành động này sẽ hủy bỏ mọi thay đổi đã thực hiện và khôi phục cài đặt mạng ban đầu. Bạn có đồng ý?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self._start_op("restore")

    def _ensure_consent(self) -> bool:
        s = self.manager.settings
        if s.consent_version >= CONSENT_VERSION:
            return True
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Information)
        box.setWindowTitle("Before you continue")
        box.setTextFormat(Qt.TextFormat.PlainText)
        box.setText(_CONSENT_TEXT)
        box.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel)
        box.button(QMessageBox.StandardButton.Ok).setText("I understand, continue")
        box.setDefaultButton(QMessageBox.StandardButton.Cancel)
        if box.exec() != QMessageBox.StandardButton.Ok:
            self._append_log("Cancelled: no changes were made.")
            return False
        s.consent_version = CONSENT_VERSION
        s.enabled = True
        self._save()
        return True

    def _on_cancel_clicked(self):
        if self._worker is not None:
            self._worker.cancel()
            self.cancel_btn.setEnabled(False)
            self.status_label.setText("Cancelling…")
            self._append_log("Cancel requested; stopping after the current step.")

    def _on_progress(self, done: int, total: int, message: str):
        if total > 0:
            self.progress_bar.setRange(0, total)
            self.progress_bar.setValue(min(done, total))
        if message:
            self.status_label.setText(message)
            self._append_log(message)

    def _on_op_finished(self, result: list):
        if self._worker is None:  # dialog was closed while the result was in flight
            return
        title = _OP_TITLES.get(self._current_op, "Operation")
        cancelled = self._worker.cancel_event.is_set()
        if self._current_op == "restore":
            for msg in result:
                self._append_log(str(msg))
            self._rows = []
            self._fill_table([])
            summary = "Everything was restored."
        else:
            self._rows = list(result)
            self._fill_table(self._rows)
            summary = self._summarize(self._rows)
            if cancelled:
                summary = f"{title} cancelled. Showing partial results. {summary}"
        self.status_label.setText(summary)
        self._append_log(summary)
        self._refresh_status()

    def _on_op_failed(self, message: str):
        if self._worker is None:
            return
        title = _OP_TITLES.get(self._current_op, "Operation")
        self.status_label.setText(f"{title} failed.")
        self._append_log(f"{title} failed: {message}")
        self._refresh_status()
        QMessageBox.warning(self, "Network Unblock", f"{title} failed:\n\n{message}")

    def _on_thread_finished(self):
        self._release_thread()
        self.progress_bar.setVisible(False)
        self._update_buttons()
        if self._close_when_idle:
            self._close_when_idle = False
            QTimer.singleShot(0, self.close)

    def _release_thread(self):
        thread = self._thread
        if thread is not None:
            thread.wait(1000)  # finished() was emitted; let the thread fully exit before dropping references
        self._thread = self._worker = None

    def _on_copy_clicked(self):
        self._refresh_status()
        try:
            changes = self.manager.view_changes()
        except Exception as e:
            changes = f"(could not read the current changes: {e})"
        QApplication.clipboard().setText(format_report(self._rows, self._status, changes))
        self.status_label.setText("Report copied to the clipboard.")
        self._append_log("Report copied to the clipboard.")

    # ---- closing --------------------------------------------------------------------------

    def _stop_worker(self) -> bool:
        """Cancel the running operation and join its thread. False if it did not stop in time."""
        thread = self._thread
        if thread is None:
            return True
        if self._worker is not None:
            self._worker.cancel()
        thread.quit()
        if not thread.wait(_STOP_WAIT_MS):
            return False
        self._release_thread()
        return True

    def _begin_shutdown(self) -> bool:
        if self._custom_timer.isActive():
            self._custom_timer.stop()
            self._commit_custom_domains(report=False)
        if not self._stop_worker():
            self._close_when_idle = True
            self.status_label.setText("Stopping…")
            self._append_log("Stopping… the window will close as soon as the current operation has stopped.")
            return False
        self._timer.stop()
        return True

    def closeEvent(self, event):
        if self._begin_shutdown():
            super().closeEvent(event)
        else:
            event.ignore()

    def done(self, result):
        # accept()/reject() (Esc, Close button) all end here
        if self._begin_shutdown():
            super().done(result)

    def showEvent(self, event):
        super().showEvent(event)
        if not self._timer.isActive():
            self._timer.start()
        self._refresh_status()


# Export alias as in-app Screen
NetUnblockScreen = NetUnblockDialog
