import os
from datetime import datetime

from app.utils.helpers import format_timestamp

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QWidget, QFrame
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

from app.ui.icons import make_svg_icon, make_svg_pixmap


class ConflictDialog(QDialog):
    """
    Dialog to resolve save file conflicts (Local vs Cloud).
    Emits resolution: "local" (upload) or "cloud" (download)
    """
    resolved = Signal(str, str)  # game_name, resolution ("local" or "cloud")

    def __init__(self, game_name: str, local_time: float, remote_time: float, parent=None):
        super().__init__(parent)
        self.game_name = game_name
        self.local_time = local_time
        self.remote_time = remote_time

        self.setWindowTitle("Phát hiện xung đột dữ liệu lưu game")
        self.setFixedSize(580, 390)
        self.setModal(True)
        self.setWindowFlags(
            Qt.WindowType.Dialog
            | Qt.WindowType.WindowTitleHint
            | Qt.WindowType.WindowCloseButtonHint
        )
        self.setStyleSheet("""
            QDialog {
                background-color: #0b0e14;
                border: 1px solid rgba(212, 175, 55, 0.35);
                border-radius: 12px;
                color: #e6edf3;
            }
            QLabel {
                color: #e6edf3;
            }
            QPushButton {
                background-color: #1a202c;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 8px;
                color: #e6edf3;
                padding: 12px;
                font-size: 13px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #242c3d;
                border-color: #a855f7;
            }
            #primaryBtn {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8b5cf6, stop:1 #6d28d9);
                border: none;
                color: #ffffff;
            }
            #primaryBtn:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #a855f7, stop:1 #7c3aed);
            }
            .Card {
                background-color: #121620;
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
            }
        """)

        self._setup_ui()

    def _format_time(self, timestamp: float) -> str:
        """Format a float timestamp to a human-friendly Vietnamese string."""
        if not timestamp:
            return "Không xác định"
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime("%d/%m/%Y lúc %H:%M:%S")

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)

        # Title
        title_layout = QHBoxLayout()
        icon_label = QLabel()
        icon_label.setPixmap(make_svg_pixmap("alert", 26, "#f59e0b"))
        
        title_text = QLabel("Xung đột file lưu game")
        title_text.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_text.setStyleSheet("color: #ffffff;")
        
        title_layout.addWidget(icon_label)
        title_layout.addWidget(title_text)
        title_layout.addStretch()
        layout.addLayout(title_layout)

        # Message
        msg = QLabel(
            f"File lưu trên máy này và bản lưu trên Cloud của <b>{self.game_name}</b> "
            "có sự thay đổi độc lập từ lần đồng bộ trước.<br>"
            "Bạn muốn giữ lại phiên bản lưu game nào?"
        )
        msg.setWordWrap(True)
        msg.setStyleSheet("font-size: 13px; color: #8b949e; line-height: 1.4;")
        layout.addWidget(msg)

        # Cards layout
        cards_layout = QHBoxLayout()
        cards_layout.setSpacing(16)

        # Local Card
        local_card = QFrame()
        local_card.setProperty("class", "Card")
        local_layout = QVBoxLayout(local_card)
        local_layout.setContentsMargins(16, 16, 16, 16)
        
        l_header = QHBoxLayout()
        l_icon = QLabel()
        l_icon.setPixmap(make_svg_pixmap("folder", 18, "#a855f7"))
        l_title = QLabel("Bản lưu trên máy (Local)")
        l_title.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        l_header.addWidget(l_icon)
        l_header.addWidget(l_title)
        l_header.addStretch()

        l_time = QLabel(f"Cập nhật: {self._format_time(self.local_time)}")
        l_time.setStyleSheet("color: #8b949e; margin-top: 6px; font-size: 11px;")
        
        l_btn = QPushButton("Giữ bản trên máy\n(Tải lên Cloud)")
        l_btn.setObjectName("primaryBtn" if self.local_time >= self.remote_time else "secondaryBtn")
        l_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        l_btn.clicked.connect(self._keep_local)

        local_layout.addLayout(l_header)
        local_layout.addWidget(l_time)
        local_layout.addStretch()
        local_layout.addWidget(l_btn)

        # Cloud Card
        cloud_card = QFrame()
        cloud_card.setProperty("class", "Card")
        cloud_layout = QVBoxLayout(cloud_card)
        cloud_layout.setContentsMargins(16, 16, 16, 16)
        
        c_header = QHBoxLayout()
        c_icon = QLabel()
        c_icon.setPixmap(make_svg_pixmap("cloud", 18, "#38bdf8"))
        c_title = QLabel("Bản lưu trên Cloud")
        c_title.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        c_header.addWidget(c_icon)
        c_header.addWidget(c_title)
        c_header.addStretch()

        c_time = QLabel(f"Cập nhật: {self._format_time(self.remote_time)}")
        c_time.setStyleSheet("color: #8b949e; margin-top: 6px; font-size: 11px;")
        
        c_btn = QPushButton("Giữ bản trên Cloud\n(Tải về máy này)")
        c_btn.setObjectName("primaryBtn" if self.remote_time > self.local_time else "secondaryBtn")
        c_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        c_btn.clicked.connect(self._keep_cloud)

        cloud_layout.addLayout(c_header)
        cloud_layout.addWidget(c_time)
        cloud_layout.addStretch()
        cloud_layout.addWidget(c_btn)

        cards_layout.addWidget(local_card)
        cards_layout.addWidget(cloud_card)
        layout.addLayout(cards_layout)

        # Warning
        warning = QLabel("Lưu ý: Dữ liệu bản lưu bị ghi đè sẽ mất vĩnh viễn và không thể khôi phục.")
        warning.setStyleSheet("color: #ff4757; font-size: 12px; margin-top: 6px;")
        warning.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(warning)

    def _keep_local(self):
        self.resolved.emit(self.game_name, "local")
        self.accept()

    def _keep_cloud(self):
        self.resolved.emit(self.game_name, "cloud")
        self.accept()
