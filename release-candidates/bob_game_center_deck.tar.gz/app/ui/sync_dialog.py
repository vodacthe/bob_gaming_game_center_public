"""
Game Details & Cloud Sync configuration dialog for Bob Gaming Game Center.
Provides Vietnamese localization (Viet Hoa) one-click install/uninstall controls,
game executable configuration, and Cloud Save synchronization settings.
"""

import logging
import os
import webbrowser
from urllib.parse import quote_plus

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.config import (
    PLATFORM_OS,
    SYNC_STATUS_ERROR,
    SYNC_STATUS_NOT_CONFIGURED,
    SYNC_STATUS_NOT_SYNCED,
    SYNC_STATUS_SYNCED,
    get_status_display,
)
from app.core.viethoa import find_localization_match, get_active_translation
from app.ui.game_card import get_game_viethoa_status
from app.ui.icons import make_svg_icon

logger = logging.getLogger(__name__)

TAG_VH_UI = "[VietHoa/UI]"


def _is_official_steam_game(game_data: dict) -> bool:
    """Return True if game_data represents an official Steam Store game with Steam Cloud."""
    if not isinstance(game_data, dict) or game_data.get("is_non_steam"):
        return False
    source = str(game_data.get("source") or "").strip().lower()
    if source == "steam_shortcut":
        return False
    return source == "steam" or game_data.get("save_path") == "Steam Cloud"


class SyncDialog(QDialog):
    """Modal dialog for viewing game details, Vietnamese localization, and Cloud Sync settings."""

    sync_requested = Signal(str, str)  # game_name, save_path
    download_requested = Signal(str)  # game_name
    sync_now_requested = Signal(str, str)  # game_name, save_path
    unsync_requested = Signal(str, bool)  # game_name, delete_remote
    exe_path_changed = Signal(str, str)  # game_name, new_exe_path
    exclude_patterns_changed = Signal(str, list)  # game_name, patterns
    viethoa_install_requested = Signal(dict)  # game_data
    viethoa_uninstall_requested = Signal(dict)  # game_data

    def __init__(self, game_data: dict, parent=None):
        super().__init__(parent)
        self.game_data = game_data
        self.game_name = game_data.get("name", "Unknown")
        self.save_path = game_data.get("save_path", "")
        self.exe_path = game_data.get("exe_path", "")
        self.on_cloud = game_data.get("on_cloud", False)
        self.status = game_data.get("status", SYNC_STATUS_NOT_CONFIGURED)
        self.exclude_patterns = list(game_data.get("exclude_patterns", []))
        self._is_official_steam = _is_official_steam_game(game_data)
        self._current_operation = "sync"

        # Auto-load existing ignore file if no patterns in config
        if (
            not self._is_official_steam
            and not self.exclude_patterns
            and self.save_path
            and os.path.isdir(self.save_path)
        ):
            from app.core.exclude_filter import ExcludeFilter

            f = ExcludeFilter((), save_dir=self.save_path)
            if f.patterns:
                self.exclude_patterns = list(f.patterns)

        self.setWindowTitle(f"Chi tiết trò chơi - {self.game_name}")
        self.setFixedWidth(560)

        self.setWindowFlags(
            Qt.WindowType.Dialog
            | Qt.WindowType.WindowTitleHint
            | Qt.WindowType.WindowCloseButtonHint
        )

        self._setup_ui()
        self._update_ui_state()
        self._update_viethoa_section()

    def _setup_ui(self):
        """Set up the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 22, 26, 22)
        layout.setSpacing(10)

        # ---- Game Title + VN Badge ----
        title_row = QHBoxLayout()
        title_row.setSpacing(10)

        self.title_label = QLabel(self.game_name)
        self.title_label.setObjectName("titleLabel")
        self.title_label.setWordWrap(True)
        title_row.addWidget(self.title_label, 1)

        self.vn_tag_label = QLabel("VN")
        self.vn_tag_label.setFixedSize(32, 22)
        self.vn_tag_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.vn_tag_label.setToolTip("Trò chơi có hỗ trợ bản dịch tiếng Việt")
        self.vn_tag_label.setStyleSheet("""
            QLabel {
                background-color: rgba(218, 37, 29, 0.92);
                color: #ffff00;
                border: 1px solid rgba(255, 255, 0, 0.65);
                border-radius: 5px;
                font-size: 11px;
                font-weight: 800;
                letter-spacing: 0.6px;
            }
        """)
        self.vn_tag_label.hide()
        title_row.addWidget(self.vn_tag_label, 0, Qt.AlignmentFlag.AlignTop)

        # ---- Status + Inline Viet Hoa Status ----
        status_row = QHBoxLayout()
        status_row.setSpacing(8)
        status_label = QLabel("Trạng thái:")
        status_label.setStyleSheet("color: #8b949e; font-size: 13px;")

        self.status_indicator = QLabel()
        self._update_status_label()

        self.viethoa_inline_badge = QLabel("")
        self.viethoa_inline_badge.setStyleSheet("color: #10b981; font-size: 13px; font-weight: 600;")
        self.viethoa_inline_badge.hide()

        status_row.addWidget(status_label)
        status_row.addWidget(self.status_indicator)
        status_row.addSpacing(8)
        status_row.addWidget(self.viethoa_inline_badge)
        status_row.addStretch()

        # ---- Cloud Info ----
        cloud_row = QHBoxLayout()
        cloud_label = QLabel("Lưu trữ Cloud:")
        cloud_label.setStyleSheet("color: #8b949e; font-size: 13px;")
        if self._is_official_steam:
            cloud_txt = "● Tự động qua Steam Cloud"
            cloud_color = "#38bdf8"
        elif self.on_cloud:
            cloud_txt = "● Đã lưu trên Cloud"
            cloud_color = "#2ed573"
        else:
            cloud_txt = "○ Chưa có trên Cloud"
            cloud_color = "#8b949e"
        self.cloud_indicator = QLabel(cloud_txt)
        self.cloud_indicator.setStyleSheet(f"color: {cloud_color}; font-size: 13px; font-weight: 600;")
        cloud_row.addWidget(cloud_label)
        cloud_row.addWidget(self.cloud_indicator)
        cloud_row.addStretch()

        # ---- Vietnamese Localization (Viet Hoa) Section ----
        self.viethoa_box = QFrame(self)
        self.viethoa_box.setObjectName("viethoaSectionBox")
        self.viethoa_box.setStyleSheet("""
            QFrame#viethoaSectionBox {
                background-color: rgba(16, 185, 129, 0.07);
                border: 1px solid rgba(16, 185, 129, 0.28);
                border-radius: 10px;
            }
        """)
        vh_layout = QVBoxLayout(self.viethoa_box)
        vh_layout.setContentsMargins(14, 12, 14, 12)
        vh_layout.setSpacing(8)

        vh_header_row = QHBoxLayout()
        vh_title = QLabel("Việt Hoá trò chơi")
        vh_title.setStyleSheet("color: #f8fafc; font-size: 13px; font-weight: 700; background: transparent; border: none;")
        self.viethoa_meta_label = QLabel("")
        self.viethoa_meta_label.setStyleSheet("color: #34d399; font-size: 11px; font-weight: 600; background: transparent; border: none;")
        vh_header_row.addWidget(vh_title)
        vh_header_row.addStretch()
        vh_header_row.addWidget(self.viethoa_meta_label)
        vh_layout.addLayout(vh_header_row)

        self.viethoa_msg_label = QLabel("Tự động tải gói Việt Hoá, sao lưu file gốc và chép thẳng vào thư mục game.")
        self.viethoa_msg_label.setWordWrap(True)
        self.viethoa_msg_label.setStyleSheet("color: #94a3b8; font-size: 12px; background: transparent; border: none;")
        vh_layout.addWidget(self.viethoa_msg_label)

        self.viethoa_progress_bar = QProgressBar()
        self.viethoa_progress_bar.setRange(0, 100)
        self.viethoa_progress_bar.setValue(0)
        self.viethoa_progress_bar.setTextVisible(True)
        self.viethoa_progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #0f172a;
                border: 1px solid rgba(245, 158, 11, 0.4);
                border-radius: 5px;
                text-align: center;
                color: #fef3c7;
                font-size: 11px;
                font-weight: 700;
                min-height: 16px;
                max-height: 16px;
            }
            QProgressBar::chunk {
                background-color: #f59e0b;
                border-radius: 4px;
            }
        """)
        self.viethoa_progress_bar.hide()
        vh_layout.addWidget(self.viethoa_progress_bar)

        vh_btn_row = QHBoxLayout()
        vh_btn_row.setSpacing(8)

        self.viethoa_install_btn = QPushButton(" Cài đặt Việt Hoá")
        self.viethoa_install_btn.setIcon(make_svg_icon("download", 15, "#052e16"))
        self.viethoa_install_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.viethoa_install_btn.setMinimumHeight(36)
        self.viethoa_install_btn.clicked.connect(self._on_viethoa_install_clicked)
        vh_btn_row.addWidget(self.viethoa_install_btn, 1)

        self.viethoa_uninstall_btn = QPushButton(" Gỡ Việt Hoá")
        self.viethoa_uninstall_btn.setIcon(make_svg_icon("trash", 15, "#f87171"))
        self.viethoa_uninstall_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.viethoa_uninstall_btn.setMinimumHeight(36)
        self.viethoa_uninstall_btn.setToolTip("Gỡ bản Việt Hoá và khôi phục tệp gốc")
        self.viethoa_uninstall_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(239, 68, 68, 0.12);
                color: #f87171;
                border: 1px solid rgba(239, 68, 68, 0.42);
                border-radius: 8px;
                font-size: 12px;
                font-weight: 700;
                padding: 6px 14px;
            }
            QPushButton:hover {
                background-color: rgba(239, 68, 68, 0.25);
                border-color: #ef4444;
            }
            QPushButton:disabled {
                color: #64748b;
                border-color: rgba(100, 116, 139, 0.3);
                background-color: transparent;
            }
        """)
        self.viethoa_uninstall_btn.clicked.connect(self._on_viethoa_uninstall_clicked)
        self.viethoa_uninstall_btn.hide()
        vh_btn_row.addWidget(self.viethoa_uninstall_btn)

        vh_layout.addLayout(vh_btn_row)
        self.viethoa_box.hide()

        # ---- Official Steam Game Info Panel ----
        self.steam_info_box = QFrame(self)
        self.steam_info_box.setObjectName("steamCloudInfoBox")
        self.steam_info_box.setStyleSheet("""
            QFrame#steamCloudInfoBox {
                background-color: rgba(56, 189, 248, 0.08);
                border: 1px solid rgba(56, 189, 248, 0.25);
                border-radius: 10px;
            }
        """)
        steam_layout = QVBoxLayout(self.steam_info_box)
        steam_layout.setContentsMargins(14, 12, 14, 12)
        steam_layout.setSpacing(6)

        steam_title = QLabel("Đồng bộ Steam Cloud")
        steam_title.setStyleSheet("color: #38bdf8; font-size: 13px; font-weight: 700; background: transparent; border: none;")
        steam_desc = QLabel(
            "Trò chơi bản quyền Steam được Steam Cloud tự động sao lưu dữ liệu lưu game. "
            "Không cần cấu hình đường dẫn lưu thủ công."
        )
        steam_desc.setWordWrap(True)
        steam_desc.setStyleSheet("color: #cbd5e1; font-size: 12px; background: transparent; border: none;")
        steam_layout.addWidget(steam_title)
        steam_layout.addWidget(steam_desc)

        install_loc = str(self.game_data.get("install_location") or "").strip()
        if install_loc:
            loc_lbl = QLabel(f"Thư mục cài đặt: {install_loc}")
            loc_lbl.setWordWrap(True)
            loc_lbl.setStyleSheet("color: #94a3b8; font-size: 11px; background: transparent; border: none;")
            steam_layout.addWidget(loc_lbl)

        self.steam_info_box.setVisible(self._is_official_steam)

        # ---- Non-Steam Manual & Cloud Sync Container ----
        self.non_steam_sync_container = QWidget(self)
        ns_layout = QVBoxLayout(self.non_steam_sync_container)
        ns_layout.setContentsMargins(0, 0, 0, 0)
        ns_layout.setSpacing(10)

        sep1 = QWidget()
        sep1.setObjectName("separator")
        sep1.setFixedHeight(1)

        # Save Location Section
        save_header_row = QHBoxLayout()
        save_header = QLabel("Vị trí lưu game (Save Location)")
        save_header.setStyleSheet("font-size: 13px; font-weight: bold; color: #ffffff;")
        self.search_save_btn = QPushButton(" Tra cứu vị trí save")
        self.search_save_btn.setIcon(make_svg_icon("globe", 13, "#38bdf8"))
        self.search_save_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.search_save_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #38bdf8;
                border: none;
                font-size: 11px;
                font-weight: 600;
                padding: 2px 6px;
            }
            QPushButton:hover {
                color: #7dd3fc;
                text-decoration: underline;
            }
        """)
        self.search_save_btn.clicked.connect(self._on_search_save_location)
        save_header_row.addWidget(save_header)
        save_header_row.addStretch()
        save_header_row.addWidget(self.search_save_btn)

        path_row = QHBoxLayout()
        self.path_input = QLineEdit()
        self.path_input.setReadOnly(True)
        self.path_input.setPlaceholderText("Chưa chọn thư mục lưu game...")
        self.path_input.setMinimumHeight(38)
        if self.save_path:
            self.path_input.setText(self.save_path)

        self.browse_btn = QPushButton(" Duyệt...")
        self.browse_btn.setIcon(make_svg_icon("folder", 16, "#38bdf8"))
        self.browse_btn.setObjectName("secondaryBtn")
        self.browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.browse_btn.setFixedWidth(116)
        self.browse_btn.clicked.connect(self._on_browse)

        path_row.addWidget(self.path_input)
        path_row.addWidget(self.browse_btn)

        # Exclude Files Section
        exclude_header = QLabel("Quy tắc loại trừ file (Configs, Graphics, Logs)")
        exclude_header.setStyleSheet("font-size: 13px; font-weight: bold; color: #ffffff;")

        exclude_row = QHBoxLayout()
        self.exclude_summary = QLabel()
        self._update_exclude_summary()

        self.exclude_btn = QPushButton(" Quy tắc...")
        self.exclude_btn.setIcon(make_svg_icon("shield", 16, "#8c96a8"))
        self.exclude_btn.setObjectName("secondaryBtn")
        self.exclude_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.exclude_btn.setFixedWidth(124)
        self.exclude_btn.clicked.connect(self._on_open_exclude_dialog)

        exclude_row.addWidget(self.exclude_summary)
        exclude_row.addStretch()
        exclude_row.addWidget(self.exclude_btn)

        # Game Executable (.exe) Section
        exe_header = QLabel("File thực thi game (.exe) — Tự động đồng bộ khi thoát")
        exe_header.setStyleSheet("font-size: 13px; font-weight: bold; color: #ffffff;")

        exe_row = QHBoxLayout()
        self.exe_input = QLineEdit()
        self.exe_input.setReadOnly(True)
        self.exe_input.setPlaceholderText("Chọn file .exe để tự động tải lên khi tắt game...")
        self.exe_input.setMinimumHeight(38)
        if self.exe_path:
            self.exe_input.setText(self.exe_path)

        self.exe_browse_btn = QPushButton(" Duyệt...")
        self.exe_browse_btn.setIcon(make_svg_icon("folder", 16, "#38bdf8"))
        self.exe_browse_btn.setObjectName("secondaryBtn")
        self.exe_browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.exe_browse_btn.setFixedWidth(116)
        self.exe_browse_btn.clicked.connect(self._on_browse_exe)

        exe_row.addWidget(self.exe_input)
        exe_row.addWidget(self.exe_browse_btn)

        sep2 = QWidget()
        sep2.setObjectName("separator")
        sep2.setFixedHeight(1)

        # Sync Actions Section
        actions_header = QLabel("Tác vụ đồng bộ Cloud")
        actions_header.setStyleSheet("font-size: 13px; font-weight: bold; color: #ffffff;")

        self.upload_btn = QPushButton(" Tải lên Cloud")
        self.upload_btn.setIcon(make_svg_icon("upload", 16, "#ffffff"))
        self.upload_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.upload_btn.setMinimumHeight(40)
        self.upload_btn.clicked.connect(self._on_upload)

        self.download_btn = QPushButton(" Tải về từ Cloud")
        self.download_btn.setIcon(make_svg_icon("download", 16, "#ffffff"))
        self.download_btn.setObjectName("successBtn")
        self.download_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.download_btn.setMinimumHeight(40)
        self.download_btn.clicked.connect(self._on_download)

        self.sync_now_btn = QPushButton(" Đồng bộ ngay")
        self.sync_now_btn.setIcon(make_svg_icon("sync", 16, "#2ed573"))
        self.sync_now_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.sync_now_btn.setMinimumHeight(40)
        self.sync_now_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(46, 213, 115, 0.15);
                color: #2ed573;
                border: 1px solid #2ed573;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: rgba(46, 213, 115, 0.3);
            }
            QPushButton:pressed {
                background-color: rgba(46, 213, 115, 0.45);
            }
            QPushButton:disabled {
                color: #555;
                border-color: #555;
                background-color: rgba(85, 85, 85, 0.1);
            }
        """)
        self.sync_now_btn.clicked.connect(self._on_sync_now)

        self.unsync_btn = QPushButton(" Hủy liên kết Cloud")
        self.unsync_btn.setIcon(make_svg_icon("trash", 16, "#ff4757"))
        self.unsync_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.unsync_btn.setMinimumHeight(36)
        self.unsync_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 71, 87, 0.15);
                color: #ff4757;
                border: 1px solid rgba(255, 71, 87, 0.4);
                border-radius: 8px;
                font-size: 13px;
                font-weight: bold;
                padding: 6px 14px;
            }
            QPushButton:hover {
                background-color: rgba(255, 71, 87, 0.3);
                border-color: #ff4757;
            }
            QPushButton:disabled {
                color: #555;
                border-color: #444;
                background-color: transparent;
            }
        """)
        self.unsync_btn.clicked.connect(self._on_unsync)

        ns_layout.addWidget(sep1)
        ns_layout.addLayout(save_header_row)
        ns_layout.addLayout(path_row)
        ns_layout.addWidget(exclude_header)
        ns_layout.addLayout(exclude_row)
        ns_layout.addWidget(exe_header)
        ns_layout.addLayout(exe_row)
        ns_layout.addWidget(sep2)
        ns_layout.addWidget(actions_header)
        ns_layout.addWidget(self.sync_now_btn)
        ns_layout.addWidget(self.upload_btn)
        ns_layout.addWidget(self.download_btn)
        ns_layout.addWidget(self.unsync_btn)

        self.non_steam_sync_container.setVisible(not self._is_official_steam)

        # ---- Progress Bar ----
        self.progress_bar = QProgressBar()
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #161b22;
                border: 1px solid #30363d;
                border-radius: 6px;
                text-align: center;
                color: #e6edf3;
                font-size: 11px;
                font-weight: bold;
                min-height: 18px;
                max-height: 18px;
            }
            QProgressBar::chunk {
                background-color: #2ed573;
                border-radius: 5px;
            }
        """)
        self.progress_bar.hide()

        # ---- Status Message ----
        self.message_label = QLabel("")
        self.message_label.setObjectName("subtitleLabel")
        self.message_label.setWordWrap(True)
        self.message_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # ---- Close Button ----
        self.close_btn = QPushButton("Đóng")
        self.close_btn.setObjectName("secondaryBtn")
        self.close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_btn.setMinimumHeight(36)
        self.close_btn.clicked.connect(self.accept)

        # ---- Assemble Layout ----
        layout.addLayout(title_row)
        layout.addLayout(status_row)
        layout.addLayout(cloud_row)
        layout.addWidget(self.viethoa_box)
        layout.addWidget(self.steam_info_box)
        layout.addWidget(self.non_steam_sync_container)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.message_label)
        layout.addStretch()
        layout.addWidget(self.close_btn)

    # ===================== VIET HOA CONTROLS =====================

    def _resolve_viethoa_meta_text(self) -> str:
        steam_appid = self.game_data.get("steam_appid") or self.game_data.get("appid")
        match_res = find_localization_match(self.game_name, steam_appid=steam_appid)
        if not match_res:
            return ""
        _, entry = match_res
        translation = get_active_translation(entry)
        if not translation:
            return ""
        parts = []
        if translation.team:
            parts.append(f"Nhóm dịch: {translation.team}")
        if translation.version:
            parts.append(f"v{translation.version}")
        return " • ".join(parts)

    def _update_viethoa_section(self, message: str = ""):
        """Refresh Viet Hoa badge, buttons, and progress widgets from self.game_data."""
        status = get_game_viethoa_status(self.game_data)
        if status == "not_available":
            self.vn_tag_label.hide()
            self.viethoa_inline_badge.hide()
            self.viethoa_box.hide()
            return

        self.vn_tag_label.show()
        self.viethoa_box.show()
        self.viethoa_meta_label.setText(self._resolve_viethoa_meta_text())

        if status == "available":
            self.viethoa_inline_badge.hide()
            self.viethoa_progress_bar.hide()
            self.viethoa_uninstall_btn.hide()
            self.viethoa_install_btn.setEnabled(True)
            self.viethoa_install_btn.setIcon(make_svg_icon("download", 15, "#052e16"))
            self.viethoa_install_btn.setText(" Cài đặt Việt Hoá")
            self.viethoa_install_btn.setStyleSheet("""
                QPushButton {
                    background-color: #10b981;
                    color: #052e16;
                    border: none;
                    border-radius: 8px;
                    font-size: 13px;
                    font-weight: 700;
                    padding: 6px 16px;
                }
                QPushButton:hover {
                    background-color: #34d399;
                }
            """)
            self.viethoa_msg_label.setText(
                message or "Tự động tải gói Việt Hoá, sao lưu file gốc và chép thẳng vào thư mục game."
            )
            self.viethoa_msg_label.setStyleSheet(
                "color: #94a3b8; font-size: 12px; background: transparent; border: none;"
            )
        elif status == "installing":
            pct = self.game_data.get("viethoa_progress")
            has_pct = isinstance(pct, int) and 0 <= pct <= 100
            pct_val = pct if has_pct else 0
            self.viethoa_inline_badge.setText(
                f"● Đang Việt Hoá {pct_val}%" if has_pct else "● Đang Việt Hoá..."
            )
            self.viethoa_inline_badge.setStyleSheet("color: #fbbf24; font-size: 13px; font-weight: 600;")
            self.viethoa_inline_badge.show()

            self.viethoa_progress_bar.setValue(pct_val)
            self.viethoa_progress_bar.show()
            self.viethoa_uninstall_btn.hide()

            self.viethoa_install_btn.setEnabled(False)
            self.viethoa_install_btn.setIcon(make_svg_icon("sync", 15, "#fbbf24"))
            self.viethoa_install_btn.setText(
                f" Đang cài đặt... {pct_val}%" if has_pct else " Đang cài đặt..."
            )
            self.viethoa_install_btn.setStyleSheet("""
                QPushButton {
                    background-color: rgba(245, 158, 11, 0.14);
                    color: #fbbf24;
                    border: 1px solid rgba(245, 158, 11, 0.45);
                    border-radius: 8px;
                    font-size: 13px;
                    font-weight: 700;
                    padding: 6px 16px;
                }
            """)
            self.viethoa_msg_label.setText(message or "Đang tải và cài đặt gói Việt Hoá...")
            self.viethoa_msg_label.setStyleSheet(
                "color: #fde68a; font-size: 12px; background: transparent; border: none;"
            )
        elif status == "installed":
            self.viethoa_inline_badge.setText("● Đã Việt Hoá")
            self.viethoa_inline_badge.setStyleSheet("color: #10b981; font-size: 13px; font-weight: 600;")
            self.viethoa_inline_badge.show()
            self.viethoa_progress_bar.hide()

            self.viethoa_install_btn.setEnabled(True)
            self.viethoa_install_btn.setIcon(make_svg_icon("sync", 15, "#34d399"))
            self.viethoa_install_btn.setText(" Cài đặt lại Việt Hoá")
            self.viethoa_install_btn.setStyleSheet("""
                QPushButton {
                    background-color: rgba(16, 185, 129, 0.14);
                    color: #34d399;
                    border: 1px solid rgba(16, 185, 129, 0.45);
                    border-radius: 8px;
                    font-size: 12px;
                    font-weight: 700;
                    padding: 6px 14px;
                }
                QPushButton:hover {
                    background-color: rgba(16, 185, 129, 0.28);
                }
            """)
            self.viethoa_uninstall_btn.setEnabled(True)
            self.viethoa_uninstall_btn.setText(" Gỡ Việt Hoá")
            self.viethoa_uninstall_btn.show()
            self.viethoa_msg_label.setText(
                message or "Đã cài đặt bản dịch tiếng Việt. Có thể cài đặt lại hoặc khôi phục tệp gốc."
            )
            self.viethoa_msg_label.setStyleSheet(
                "color: #a7f3d0; font-size: 12px; background: transparent; border: none;"
            )

    def set_viethoa_progress(self, percent: int, status_message: str = ""):
        """Update live Viet Hoa installation progress inside the open dialog."""
        self.game_data["viethoa_status"] = "installing"
        self.game_data["viethoa_progress"] = percent
        self.game_data["is_installing_viethoa"] = True
        self._update_viethoa_section(message=status_message)

    def set_viethoa_state(self, state: str, percent: int = 0, message: str = ""):
        """Update Viet Hoa state ('available', 'installing', 'installed') inside the open dialog."""
        self.game_data["viethoa_status"] = state
        if state == "installing":
            self.game_data["is_installing_viethoa"] = True
            self.game_data["viethoa_progress"] = percent
        elif state == "installed":
            self.game_data["is_installing_viethoa"] = False
            self.game_data["viethoa_installed"] = True
        else:
            self.game_data["is_installing_viethoa"] = False
            if state == "available":
                self.game_data["viethoa_installed"] = False
        self._update_viethoa_section(message=message)

    def _on_viethoa_install_clicked(self):
        status = get_game_viethoa_status(self.game_data)
        logger.info(f"{TAG_VH_UI} Dialog install button clicked for {self.game_name!r} (status={status})")
        self.viethoa_install_requested.emit(self.game_data)

    def _on_viethoa_uninstall_clicked(self):
        logger.info(f"{TAG_VH_UI} Dialog uninstall button clicked for {self.game_name!r}")
        self.viethoa_install_btn.setEnabled(False)
        self.viethoa_uninstall_btn.setEnabled(False)
        self.viethoa_uninstall_btn.setText(" Đang gỡ...")
        self.viethoa_uninstall_requested.emit(self.game_data)

    def _on_search_save_location(self):
        """Open browser search for the game's save directory on explicit user click."""
        search_query = quote_plus(f"{self.game_name} save location {PLATFORM_OS}")
        webbrowser.open(f"https://www.google.com/search?q={search_query}")

    # ===================== CLOUD SYNC CONTROLS =====================

    def _update_status_label(self):
        """Update the status indicator label."""
        display = get_status_display(self.status)
        self.status_indicator.setText(f"{display['emoji']} {display['text']}")
        self.status_indicator.setStyleSheet(
            f"color: {display['color']}; font-size: 13px; font-weight: bold;"
        )

    def _update_ui_state(self):
        """Enable/disable buttons based on current state."""
        has_path = bool(self.save_path)

        self.upload_btn.setEnabled(has_path)
        self.download_btn.setEnabled(self.on_cloud)
        self.sync_now_btn.setEnabled(has_path)
        is_synced = self.status == SYNC_STATUS_SYNCED
        self.unsync_btn.setEnabled(is_synced)
        self.unsync_btn.setVisible(is_synced)

        if not has_path:
            self.upload_btn.setToolTip("Vui lòng chọn thư mục lưu game trước")
            self.sync_now_btn.setToolTip("Vui lòng chọn thư mục lưu game trước")
        if not self.on_cloud:
            self.download_btn.setToolTip("Chưa có bản lưu trên Cloud cho trò chơi này")

    def _on_browse_exe(self):
        """Pick an executable file for the game."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            f"Chọn file thực thi (.exe) cho {self.game_name}",
            os.path.dirname(self.exe_path) if self.exe_path else "",
            "Tệp thực thi (*.exe);;Tất cả tệp (*.*)",
        )
        if file_path:
            file_path = os.path.abspath(file_path).replace("\\", "/")
            self.exe_path = file_path
            self.exe_input.setText(file_path)
            self.game_data["exe_path"] = file_path
            self.exe_path_changed.emit(self.game_name, file_path)
            self.show_message(f"Đã đặt file thực thi: {os.path.basename(file_path)}", "info")

    def _on_unsync(self):
        """Handle un-sync request with clear user choice."""
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Hủy liên kết Cloud")
        msg_box.setText(f'Bạn có chắc chắn muốn hủy liên kết cho "{self.game_name}"?')
        msg_box.setInformativeText("Chọn cách xử lý dữ liệu lưu game trên máy chủ Cloud:")

        btn_keep_cloud = msg_box.addButton("Giữ lại bản lưu trên Cloud", QMessageBox.ButtonRole.ActionRole)
        btn_delete_cloud = msg_box.addButton("Xóa dữ liệu trên Cloud", QMessageBox.ButtonRole.DestructiveRole)
        btn_cancel = msg_box.addButton("Hủy bỏ", QMessageBox.ButtonRole.RejectRole)

        btn_delete_cloud.setObjectName("dangerBtn")
        btn_cancel.setObjectName("secondaryBtn")

        msg_box.setDefaultButton(btn_keep_cloud)
        msg_box.exec()

        clicked = msg_box.clickedButton()
        if clicked == btn_cancel or clicked is None:
            return

        delete_remote = clicked == btn_delete_cloud
        self.status = SYNC_STATUS_NOT_SYNCED
        if delete_remote:
            self.on_cloud = False
        self.game_data["status"] = self.status
        self.game_data["on_cloud"] = self.on_cloud
        self._update_status_label()
        self._update_ui_state()
        self.unsync_requested.emit(self.game_name, delete_remote)
        self.accept()

    def _update_exclude_summary(self):
        """Update the label summarizing active exclude rules."""
        count = len(self.exclude_patterns)
        if count == 0:
            self.exclude_summary.setText("Chưa có quy tắc (đồng bộ tất cả tệp)")
            self.exclude_summary.setStyleSheet("color: #8b949e; font-size: 12px;")
        else:
            first_patterns = ", ".join(self.exclude_patterns[:2])
            if count > 2:
                first_patterns += f" (+{count - 2} quy tắc khác)"
            self.exclude_summary.setText(f"● Đang áp dụng {count} quy tắc: {first_patterns}")
            self.exclude_summary.setStyleSheet("color: #2ed573; font-size: 12px; font-weight: 500;")

    def _on_open_exclude_dialog(self):
        """Open the ExcludeDialog modal to configure exclude rules."""
        try:
            from app.ui.exclude_dialog import ExcludeDialog

            dialog = ExcludeDialog(
                self.game_name,
                self.save_path,
                self.exclude_patterns,
                parent=self,
            )
            if dialog.exec():
                self.exclude_patterns = dialog.get_patterns()
                self.game_data["exclude_patterns"] = self.exclude_patterns
                self._update_exclude_summary()
                self.exclude_patterns_changed.emit(self.game_name, self.exclude_patterns)
        except Exception as e:
            logger.error(f"Error opening ExcludeDialog: {e}", exc_info=True)
            QMessageBox.critical(self, "Lỗi", f"Không thể mở hộp thoại quy tắc loại trừ:\n{e}")

    def _on_browse(self):
        """Handle browse button click."""
        if self.save_path and os.path.isdir(self.save_path):
            start_dir = self.save_path
        else:
            start_dir = os.environ.get("APPDATA", os.path.expanduser("~"))

        folder = QFileDialog.getExistingDirectory(
            self,
            f"Chọn thư mục lưu game cho {self.game_name}",
            start_dir,
            QFileDialog.Option.ShowDirsOnly,
        )

        if folder:
            self.save_path = folder
            self.path_input.setText(folder)
            self.game_data["save_path"] = folder
            if not self.exclude_patterns:
                from app.core.exclude_filter import ExcludeFilter

                f = ExcludeFilter((), save_dir=folder)
                if f.patterns:
                    self.exclude_patterns = list(f.patterns)
                    self.game_data["exclude_patterns"] = self.exclude_patterns
                    self.exclude_patterns_changed.emit(self.game_name, self.exclude_patterns)
            self._update_exclude_summary()
            self._update_ui_state()
            self.show_message(f"Đã đặt thư mục lưu game: {folder}", "info")

    def _on_upload(self):
        """Handle upload button click."""
        if not self.save_path:
            self.show_message("Vui lòng chọn thư mục lưu game trước", "error")
            return

        if not os.path.isdir(self.save_path):
            self.show_message(f"Không tìm thấy thư mục: {self.save_path}", "error")
            return

        self._current_operation = "upload"
        self.show_progress(True)
        self.show_message("Đang quét và chuẩn bị tệp tải lên...", "info")
        self.sync_requested.emit(self.game_name, self.save_path)

    def _on_download(self):
        """Handle download button click."""
        self._current_operation = "download"
        self.show_progress(True)
        self.show_message("Đang kiểm tra và chuẩn bị tải về từ Cloud...", "info")
        self.download_requested.emit(self.game_name)

    def _on_sync_now(self):
        """Handle Sync Now button click."""
        if not self.save_path:
            self.show_message("Vui lòng chọn thư mục lưu game trước", "error")
            return

        if not os.path.isdir(self.save_path):
            self.show_message(f"Không tìm thấy thư mục: {self.save_path}", "error")
            return

        self._current_operation = "sync"
        self.show_progress(True)
        self.show_message("Đang so khớp thời gian lưu game...", "info")
        self.sync_now_requested.emit(self.game_name, self.save_path)

    def show_progress(self, show: bool):
        """Show or hide the progress bar."""
        self.progress_bar.setVisible(show)
        if show:
            self.progress_bar.setRange(0, 0)
            self.progress_bar.setTextVisible(False)
            self.upload_btn.setEnabled(False)
            self.download_btn.setEnabled(False)
            self.sync_now_btn.setEnabled(False)
            self.unsync_btn.setEnabled(False)
            self.browse_btn.setEnabled(False)
            self.exclude_btn.setEnabled(False)
        else:
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(0)
            self.progress_bar.setTextVisible(False)
            self._update_ui_state()
            self.browse_btn.setEnabled(True)
            self.exclude_btn.setEnabled(True)

    def update_progress(
        self, current: int, total: int, speed: float = 0.0, bytes_done: int = 0, total_bytes: int = 0
    ):
        """Update the progress bar, file count, and transfer speed."""
        if total > 0:
            if total_bytes > 0:
                percent = min(100, int((bytes_done / total_bytes) * 100))
            else:
                percent = min(100, int((current / total) * 100))

            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(percent)
            self.progress_bar.setTextVisible(True)
            self.progress_bar.setFormat(f"{percent}% ({current}/{total} tệp)")

            from app.core.transfer_tracker import format_speed

            speed_str = format_speed(speed)

            op = getattr(self, "_current_operation", "sync")
            if op == "upload":
                op_title = "Đang tải lên"
            elif op == "download":
                op_title = "Đang tải về"
            else:
                op_title = "Đang đồng bộ"

            if speed > 0:
                self.show_message(f"{op_title}: {current}/{total} tệp ({percent}%) • {speed_str}", "info")
            else:
                self.show_message(f"{op_title}: {current}/{total} tệp ({percent}%)", "info")

    def on_sync_complete(self, success: bool, message: str):
        """Handle sync completion."""
        self.show_progress(False)
        self.browse_btn.setEnabled(True)

        if success:
            self.status = SYNC_STATUS_SYNCED
            self.on_cloud = True
            self.cloud_indicator.setText("● Đã lưu trên Cloud")
            self.cloud_indicator.setStyleSheet("color: #2ed573; font-size: 13px; font-weight: 600;")
            self.show_message(message, "success")
        else:
            self.status = SYNC_STATUS_ERROR
            self.show_message(message, "error")

        self._update_status_label()
        self._update_ui_state()

    def show_message(self, message: str, msg_type: str = "info"):
        """Show a status message."""
        colors = {
            "info": "#8b949e",
            "success": "#2ed573",
            "error": "#ff4757",
            "warning": "#ffa502",
        }
        color = colors.get(msg_type, "#8b949e")
        self.message_label.setStyleSheet(f"color: {color}; font-size: 12px;")
        self.message_label.setText(message)
