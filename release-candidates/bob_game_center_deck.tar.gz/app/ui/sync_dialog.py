"""
Sync dialog for Bob Gaming Game Center.
Modal dialog for configuring and triggering Bob Gaming Game Center.
"""

import os
import logging
import webbrowser
from urllib.parse import quote_plus

logger = logging.getLogger(__name__)

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QProgressBar, QFileDialog,
    QWidget, QMessageBox,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

from app.config import (
    SYNC_STATUS_SYNCED, SYNC_STATUS_SYNCING, SYNC_STATUS_NOT_SYNCED,
    SYNC_STATUS_NOT_CONFIGURED, SYNC_STATUS_ERROR, PLATFORM_OS,
    get_status_display,
)
from app.ui.icons import make_svg_icon


class SyncDialog(QDialog):
    """Modal dialog for configuring Bob Gaming Game Center."""

    sync_requested = Signal(str, str)   # game_name, save_path
    download_requested = Signal(str)    # game_name
    sync_now_requested = Signal(str, str)  # game_name, save_path
    unsync_requested = Signal(str, bool)   # game_name, delete_remote
    exe_path_changed = Signal(str, str)    # game_name, new_exe_path
    exclude_patterns_changed = Signal(str, list)  # game_name, patterns

    def __init__(self, game_data: dict, parent=None):
        super().__init__(parent)
        self.game_data = game_data
        self.game_name = game_data.get("name", "Unknown")
        self.save_path = game_data.get("save_path", "")
        self.exe_path = game_data.get("exe_path", "")
        self.on_cloud = game_data.get("on_cloud", False)
        self.status = game_data.get("status", SYNC_STATUS_NOT_CONFIGURED)
        self.exclude_patterns = list(game_data.get("exclude_patterns", []))
        self._current_operation = "sync"

        # Auto-load existing ignore file if no patterns in config
        if not self.exclude_patterns and self.save_path and os.path.isdir(self.save_path):
            from app.core.exclude_filter import ExcludeFilter
            f = ExcludeFilter((), save_dir=self.save_path)
            if f.patterns:
                self.exclude_patterns = list(f.patterns)

        self.setWindowTitle(f"Cấu hình đồng bộ - {self.game_name}")
        self.setFixedSize(540, 680)

        self.setWindowFlags(
            Qt.WindowType.Dialog
            | Qt.WindowType.WindowTitleHint
            | Qt.WindowType.WindowCloseButtonHint
        )

        self._setup_ui()
        self._update_ui_state()

        # Auto-open Google search for save location if game not yet on cloud
        if not self.on_cloud and not self.save_path:
            search_query = quote_plus(f"{self.game_name} save location {PLATFORM_OS}")
            webbrowser.open(f"https://www.google.com/search?q={search_query}")

    def _setup_ui(self):
        """Set up the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(12)

        # ---- Game Title ----
        title = QLabel(self.game_name)
        title.setObjectName("titleLabel")
        title.setWordWrap(True)

        # ---- Status ----
        status_row = QHBoxLayout()
        status_label = QLabel("Trạng thái:")
        status_label.setStyleSheet("color: #8b949e; font-size: 13px;")

        self.status_indicator = QLabel()
        self._update_status_label()

        status_row.addWidget(status_label)
        status_row.addWidget(self.status_indicator)
        status_row.addStretch()

        # ---- Cloud Info ----
        cloud_row = QHBoxLayout()
        cloud_label = QLabel("Lưu trữ Cloud:")
        cloud_label.setStyleSheet("color: #8b949e; font-size: 13px;")
        self.cloud_indicator = QLabel("● Đã lưu trên Cloud" if self.on_cloud else "○ Chưa có trên Cloud")
        self.cloud_indicator.setStyleSheet(f"color: {'#2ed573' if self.on_cloud else '#8b949e'}; font-size: 13px;")
        cloud_row.addWidget(cloud_label)
        cloud_row.addWidget(self.cloud_indicator)
        cloud_row.addStretch()

        # ---- Separator ----
        sep1 = QWidget()
        sep1.setObjectName("separator")
        sep1.setFixedHeight(1)

        # ---- Save Location Section ----
        save_header = QLabel("Vị trí lưu game (Save Location)")
        save_header.setStyleSheet("font-size: 14px; font-weight: bold; color: #ffffff;")

        path_row = QHBoxLayout()
        self.path_input = QLineEdit()
        self.path_input.setReadOnly(True)
        self.path_input.setPlaceholderText("Chưa chọn thư mục lưu game...")
        self.path_input.setMinimumHeight(40)
        if self.save_path:
            self.path_input.setText(self.save_path)

        self.browse_btn = QPushButton(" Duyệt...")
        self.browse_btn.setIcon(make_svg_icon("folder", 16, "#a855f7"))
        self.browse_btn.setObjectName("secondaryBtn")
        self.browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.browse_btn.setFixedWidth(120)
        self.browse_btn.clicked.connect(self._on_browse)

        path_row.addWidget(self.path_input)
        path_row.addWidget(self.browse_btn)

        # ---- Exclude Files Section ----
        exclude_header = QLabel("Quy tắc loại trừ file (Configs, Graphics, Logs)")
        exclude_header.setStyleSheet("font-size: 14px; font-weight: bold; color: #ffffff;")

        exclude_row = QHBoxLayout()
        self.exclude_summary = QLabel()
        self._update_exclude_summary()

        self.exclude_btn = QPushButton(" Quy tắc...")
        self.exclude_btn.setIcon(make_svg_icon("shield", 16, "#8c96a8"))
        self.exclude_btn.setObjectName("secondaryBtn")
        self.exclude_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.exclude_btn.setFixedWidth(130)
        self.exclude_btn.clicked.connect(self._on_open_exclude_dialog)

        exclude_row.addWidget(self.exclude_summary)
        exclude_row.addStretch()
        exclude_row.addWidget(self.exclude_btn)

        # ---- Game Executable (.exe) Section ----
        exe_header = QLabel("File thực thi game (.exe) — Tự động đồng bộ khi thoát")
        exe_header.setStyleSheet("font-size: 14px; font-weight: bold; color: #ffffff;")

        exe_row = QHBoxLayout()
        self.exe_input = QLineEdit()
        self.exe_input.setReadOnly(True)
        self.exe_input.setPlaceholderText("Chọn file .exe để tự động tải lên khi tắt game...")
        self.exe_input.setMinimumHeight(40)
        if self.exe_path:
            self.exe_input.setText(self.exe_path)

        self.exe_browse_btn = QPushButton(" Duyệt...")
        self.exe_browse_btn.setIcon(make_svg_icon("folder", 16, "#a855f7"))
        self.exe_browse_btn.setObjectName("secondaryBtn")
        self.exe_browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.exe_browse_btn.setFixedWidth(120)
        self.exe_browse_btn.clicked.connect(self._on_browse_exe)

        exe_row.addWidget(self.exe_input)
        exe_row.addWidget(self.exe_browse_btn)

        # ---- Separator ----
        sep2 = QWidget()
        sep2.setObjectName("separator")
        sep2.setFixedHeight(1)

        # ---- Sync Actions Section ----
        actions_header = QLabel("Tác vụ đồng bộ Cloud")
        actions_header.setStyleSheet("font-size: 14px; font-weight: bold; color: #ffffff;")

        # Upload button
        self.upload_btn = QPushButton(" Tải lên Cloud")
        self.upload_btn.setIcon(make_svg_icon("upload", 16, "#ffffff"))
        self.upload_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.upload_btn.setMinimumHeight(42)
        self.upload_btn.clicked.connect(self._on_upload)

        # Download button
        self.download_btn = QPushButton(" Tải về từ Cloud")
        self.download_btn.setIcon(make_svg_icon("download", 16, "#ffffff"))
        self.download_btn.setObjectName("successBtn")
        self.download_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.download_btn.setMinimumHeight(42)
        self.download_btn.clicked.connect(self._on_download)

        # Sync Now button
        self.sync_now_btn = QPushButton(" Đồng bộ ngay")
        self.sync_now_btn.setIcon(make_svg_icon("sync", 16, "#2ed573"))
        self.sync_now_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.sync_now_btn.setMinimumHeight(42)
        self.sync_now_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(46, 213, 115, 0.15);
                color: #2ed573;
                border: 1px solid #2ed573;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: rgba(46, 213, 115, 0.3);
            }
            QPushButton:pressed {
                background-color: rgba(46, 213, 115, 0.45);
            }
            QPushButton:disabled {
                color: #555;
                border-color: #555;
                background-color: rgba(85, 85, 85, 0.1);
            }
        """)
        self.sync_now_btn.clicked.connect(self._on_sync_now)

        # Un-sync button
        self.unsync_btn = QPushButton(" Hủy liên kết Cloud")
        self.unsync_btn.setIcon(make_svg_icon("trash", 16, "#ff4757"))
        self.unsync_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.unsync_btn.setMinimumHeight(38)
        self.unsync_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 71, 87, 0.15);
                color: #ff4757;
                border: 1px solid rgba(255, 71, 87, 0.4);
                border-radius: 8px;
                font-size: 13px;
                font-weight: bold;
                padding: 6px 14px;
            }
            QPushButton:hover {
                background-color: rgba(255, 71, 87, 0.3);
                border-color: #ff4757;
            }
            QPushButton:disabled {
                color: #555;
                border-color: #444;
                background-color: transparent;
            }
        """)
        self.unsync_btn.clicked.connect(self._on_unsync)

        # ---- Progress Bar ----
        self.progress_bar = QProgressBar()
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #161b22;
                border: 1px solid #30363d;
                border-radius: 6px;
                text-align: center;
                color: #e6edf3;
                font-size: 11px;
                font-weight: bold;
                min-height: 18px;
                max-height: 18px;
            }
            QProgressBar::chunk {
                background-color: #2ed573;
                border-radius: 5px;
            }
        """)
        self.progress_bar.hide()

        # ---- Status Message ----
        self.message_label = QLabel("")
        self.message_label.setObjectName("subtitleLabel")
        self.message_label.setWordWrap(True)
        self.message_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # ---- Close Button ----
        self.close_btn = QPushButton("Đóng")
        self.close_btn.setObjectName("secondaryBtn")
        self.close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_btn.clicked.connect(self.accept)

        # ---- Assemble Layout ----
        layout.addWidget(title)
        layout.addLayout(status_row)
        layout.addLayout(cloud_row)
        layout.addSpacing(4)
        layout.addWidget(sep1)
        layout.addSpacing(4)
        layout.addWidget(save_header)
        layout.addLayout(path_row)
        layout.addSpacing(2)
        layout.addWidget(exclude_header)
        layout.addLayout(exclude_row)
        layout.addSpacing(4)
        layout.addWidget(exe_header)
        layout.addLayout(exe_row)
        layout.addSpacing(4)
        layout.addWidget(sep2)
        layout.addSpacing(4)
        layout.addWidget(actions_header)
        layout.addWidget(self.sync_now_btn)
        layout.addWidget(self.upload_btn)
        layout.addWidget(self.download_btn)
        layout.addWidget(self.unsync_btn)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.message_label)
        layout.addStretch()
        layout.addWidget(self.close_btn)

    def _update_status_label(self):
        """Update the status indicator label."""
        display = get_status_display(self.status)
        self.status_indicator.setText(f"{display['emoji']} {display['text']}")
        self.status_indicator.setStyleSheet(
            f"color: {display['color']}; font-size: 13px; font-weight: bold;"
        )

    def _update_ui_state(self):
        """Enable/disable buttons based on current state."""
        has_path = bool(self.save_path)

        self.upload_btn.setEnabled(has_path)
        self.download_btn.setEnabled(self.on_cloud)
        self.sync_now_btn.setEnabled(has_path)
        is_synced = (self.status == SYNC_STATUS_SYNCED)
        self.unsync_btn.setEnabled(is_synced)
        self.unsync_btn.setVisible(is_synced)

        if not has_path:
            self.upload_btn.setToolTip("Vui lòng chọn thư mục lưu game trước")
            self.sync_now_btn.setToolTip("Vui lòng chọn thư mục lưu game trước")
        if not self.on_cloud:
            self.download_btn.setToolTip("Chưa có bản lưu trên Cloud cho trò chơi này")

    def _on_browse_exe(self):
        """Pick an executable file for the game."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            f"Chọn file thực thi (.exe) cho {self.game_name}",
            os.path.dirname(self.exe_path) if self.exe_path else "",
            "Tệp thực thi (*.exe);;Tất cả tệp (*.*)"
        )
        if file_path:
            file_path = os.path.abspath(file_path).replace("\\", "/")
            self.exe_path = file_path
            self.exe_input.setText(file_path)
            self.game_data["exe_path"] = file_path
            self.exe_path_changed.emit(self.game_name, file_path)
            self.show_message(f"Đã đặt file thực thi: {os.path.basename(file_path)}", "info")

    def _on_unsync(self):
        """Handle un-sync request with clear user choice."""
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Hủy liên kết Cloud")
        msg_box.setText(f"Bạn có chắc chắn muốn hủy liên kết cho \"{self.game_name}\"?")
        msg_box.setInformativeText("Chọn cách xử lý dữ liệu lưu game trên máy chủ Cloud:")

        btn_keep_cloud = msg_box.addButton("Giữ lại bản lưu trên Cloud", QMessageBox.ButtonRole.ActionRole)
        btn_delete_cloud = msg_box.addButton("Xóa dữ liệu trên Cloud", QMessageBox.ButtonRole.DestructiveRole)
        btn_cancel = msg_box.addButton("Hủy bỏ", QMessageBox.ButtonRole.RejectRole)

        btn_delete_cloud.setObjectName("dangerBtn")
        btn_cancel.setObjectName("secondaryBtn")

        msg_box.setDefaultButton(btn_keep_cloud)
        msg_box.exec()

        clicked = msg_box.clickedButton()
        if clicked == btn_cancel or clicked is None:
            return

        delete_remote = (clicked == btn_delete_cloud)
        self.status = SYNC_STATUS_NOT_SYNCED
        if delete_remote:
            self.on_cloud = False
        self.game_data["status"] = self.status
        self.game_data["on_cloud"] = self.on_cloud
        self._update_status_label()
        self._update_ui_state()
        self.unsync_requested.emit(self.game_name, delete_remote)
        self.accept()


    def _update_exclude_summary(self):
        """Update the label summarizing active exclude rules."""
        count = len(self.exclude_patterns)
        if count == 0:
            self.exclude_summary.setText("Chưa có quy tắc (đồng bộ tất cả tệp)")
            self.exclude_summary.setStyleSheet("color: #8b949e; font-size: 12px;")
        else:
            first_patterns = ", ".join(self.exclude_patterns[:2])
            if count > 2:
                first_patterns += f" (+{count - 2} quy tắc khác)"
            self.exclude_summary.setText(f"● Đang áp dụng {count} quy tắc: {first_patterns}")
            self.exclude_summary.setStyleSheet("color: #2ed573; font-size: 12px; font-weight: 500;")

    def _on_open_exclude_dialog(self):
        """Open the ExcludeDialog modal to configure exclude rules."""
        try:
            from app.ui.exclude_dialog import ExcludeDialog
            dialog = ExcludeDialog(
                self.game_name,
                self.save_path,
                self.exclude_patterns,
                parent=self,
            )
            if dialog.exec():
                self.exclude_patterns = dialog.get_patterns()
                self.game_data["exclude_patterns"] = self.exclude_patterns
                self._update_exclude_summary()
                self.exclude_patterns_changed.emit(self.game_name, self.exclude_patterns)
        except Exception as e:
            logger.error(f"Error opening ExcludeDialog: {e}", exc_info=True)
            QMessageBox.critical(self, "Lỗi", f"Không thể mở hộp thoại quy tắc loại trừ:\n{e}")

    def _on_browse(self):
        """Handle browse button click."""
        if self.save_path and os.path.isdir(self.save_path):
            start_dir = self.save_path
        else:
            start_dir = os.environ.get("APPDATA", os.path.expanduser("~"))

        folder = QFileDialog.getExistingDirectory(
            self,
            f"Chọn thư mục lưu game cho {self.game_name}",
            start_dir,
            QFileDialog.Option.ShowDirsOnly,
        )

        if folder:
            self.save_path = folder
            self.path_input.setText(folder)
            self.game_data["save_path"] = folder
            if not self.exclude_patterns:
                from app.core.exclude_filter import ExcludeFilter
                f = ExcludeFilter((), save_dir=folder)
                if f.patterns:
                    self.exclude_patterns = list(f.patterns)
                    self.game_data["exclude_patterns"] = self.exclude_patterns
                    self.exclude_patterns_changed.emit(self.game_name, self.exclude_patterns)
            self._update_exclude_summary()
            self._update_ui_state()
            self.show_message(f"Đã đặt thư mục lưu game: {folder}", "info")

    def _on_upload(self):
        """Handle upload button click."""
        if not self.save_path:
            self.show_message("Vui lòng chọn thư mục lưu game trước", "error")
            return

        if not os.path.isdir(self.save_path):
            self.show_message(f"Không tìm thấy thư mục: {self.save_path}", "error")
            return

        self._current_operation = "upload"
        self.show_progress(True)
        self.show_message("Đang quét và chuẩn bị tệp tải lên...", "info")
        self.sync_requested.emit(self.game_name, self.save_path)

    def _on_download(self):
        """Handle download button click."""
        self._current_operation = "download"
        self.show_progress(True)
        self.show_message("Đang kiểm tra và chuẩn bị tải về từ Cloud...", "info")
        self.download_requested.emit(self.game_name)

    def _on_sync_now(self):
        """Handle Sync Now button click."""
        if not self.save_path:
            self.show_message("Vui lòng chọn thư mục lưu game trước", "error")
            return

        if not os.path.isdir(self.save_path):
            self.show_message(f"Không tìm thấy thư mục: {self.save_path}", "error")
            return

        self._current_operation = "sync"
        self.show_progress(True)
        self.show_message("Đang so khớp thời gian lưu game...", "info")
        self.sync_now_requested.emit(self.game_name, self.save_path)

    def show_progress(self, show: bool):
        """Show or hide the progress bar."""
        self.progress_bar.setVisible(show)
        if show:
            self.progress_bar.setRange(0, 0)  # Indeterminate animation sweeps while checking/preparing
            self.progress_bar.setTextVisible(False)
            self.upload_btn.setEnabled(False)
            self.download_btn.setEnabled(False)
            self.sync_now_btn.setEnabled(False)
            self.unsync_btn.setEnabled(False)
            self.browse_btn.setEnabled(False)
            self.exclude_btn.setEnabled(False)
        else:
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(0)
            self.progress_bar.setTextVisible(False)
            self._update_ui_state()
            self.browse_btn.setEnabled(True)
            self.exclude_btn.setEnabled(True)

    def update_progress(self, current: int, total: int, speed: float = 0.0, bytes_done: int = 0, total_bytes: int = 0):
        """Update the progress bar, file count, and transfer speed."""
        if total > 0:
            if total_bytes > 0:
                percent = min(100, int((bytes_done / total_bytes) * 100))
            else:
                percent = min(100, int((current / total) * 100))

            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(percent)
            self.progress_bar.setTextVisible(True)
            self.progress_bar.setFormat(f"{percent}% ({current}/{total} tệp)")

            from app.core.transfer_tracker import format_speed
            speed_str = format_speed(speed)

            op = getattr(self, "_current_operation", "sync")
            if op == "upload":
                op_title = "Đang tải lên"
            elif op == "download":
                op_title = "Đang tải về"
            else:
                op_title = "Đang đồng bộ"

            if speed > 0:
                self.show_message(f"{op_title}: {current}/{total} tệp ({percent}%) • {speed_str}", "info")
            else:
                self.show_message(f"{op_title}: {current}/{total} tệp ({percent}%)", "info")

    def on_sync_complete(self, success: bool, message: str):
        """Handle sync completion."""
        self.show_progress(False)
        self.browse_btn.setEnabled(True)

        if success:
            self.status = SYNC_STATUS_SYNCED
            self.on_cloud = True
            self.cloud_indicator.setText("● Đã lưu trên Cloud")
            self.cloud_indicator.setStyleSheet("color: #2ed573; font-size: 13px;")
            self.show_message(message, "success")
        else:
            self.status = SYNC_STATUS_ERROR
            self.show_message(message, "error")

        self._update_status_label()
        self._update_ui_state()

    def show_message(self, message: str, msg_type: str = "info"):
        """Show a status message."""
        colors = {
            "info": "#8b949e",
            "success": "#2ed573",
            "error": "#ff4757",
            "warning": "#ffa502",
        }
        color = colors.get(msg_type, "#8b949e")
        self.message_label.setStyleSheet(f"color: {color}; font-size: 12px;")
        self.message_label.setText(message)
