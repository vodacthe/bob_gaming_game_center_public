"""
Upscaler screen: OptiScaler / FSR DLL swaps and the optional HelixSR backend, per game.
All disk / network work runs in worker threads; the core logic lives in app.core.upscaler.
"""

import functools
import inspect
import logging
import os
import threading
import time

from PySide6.QtCore import QObject, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFileDialog, QFormLayout, QFrame, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QMessageBox, QProgressBar, QPushButton, QTabBar, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from shiboken6 import isValid

from app.core.upscaler import downloader, gpu, helixsr, installer, platforms, service
from app.core.upscaler.installer import InstallError
from app.core.upscaler.settings import MIN_COLUMN_WIDTH, SettingsStore, clean_column_widths
from app.ui.icons import make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader

logger = logging.getLogger(__name__)
TAG = "[Upscaler/UI]"

HELIXSR_NOTICE = (
    "HelixSR là dự án độc lập, không liên quan tới NVIDIA hay AMD.\n\n"
    "• Bob tải gói chính chủ từ GitHub và chạy setup của HelixSR trong cửa sổ console riêng.\n"
    "• Setup sẽ hỏi tải DLL DLSS của NVIDIA (theo giấy phép của NVIDIA) rồi build mạng neural trên máy bạn.\n"
    "• Các DLL sau khi build chứa mạng của NVIDIA: chỉ dùng trên máy bạn, KHÔNG chia sẻ hay tải lên.\n"
    "• Bob tự đóng console ngay khi mạng build xong (trước khi setup hỏi cài cho từng game): Bob sẽ cài cho từng game.\n"
    "• Chỉ hỗ trợ GPU AMD RDNA 1 trở lên và game Direct3D 12."
)

_BTN = ("background-color: rgba(139, 92, 246, 0.2); color: #c084fc; border: 1px solid rgba(139, 92, 246, 0.4); "
        "border-radius: 4px; padding: 0 10px;")
_BTN_PLAIN = ("background-color: rgba(255, 255, 255, 0.05); color: #cbd5e1; border: 1px solid rgba(255, 255, 255, 0.1); "
              "border-radius: 4px; padding: 0 10px;")
# table columns: (header, sort key or None)
_COLUMNS = (("Trò chơi", "name"), ("Nền tảng", "platform"), ("Công nghệ", "tech"), ("Hiện tại", "current"),
            ("Chế độ", "mode"), ("Thao tác", None))
_COL_MODE, _COL_ACTIONS = 4, 5
_DEFAULT_WIDTHS = (300, 110, 130, 230, 270, 420)       # name, platform, technology, current, mode, actions
_STATE_TEXT = {helixsr.STATE_MISSING: "Chưa tải", helixsr.STATE_DOWNLOADED: "Đã tải", helixsr.STATE_BUILT: "Đã build"}


def _safe(func):
    """Slot guard: an exception in a handler is logged and reported in the status line; it never reaches Qt's event
    loop (where it could abort the app). Extra signal arguments (clicked(bool), ...) are dropped."""
    params = [p for p in inspect.signature(func).parameters.values()][1:]
    accepts_varargs = any(p.kind is inspect.Parameter.VAR_POSITIONAL for p in params)
    max_args = len([p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if not accepts_varargs:
            args = args[:max_args]
        try:
            return func(self, *args, **kwargs)
        except Exception:   # noqa: BLE001 - see docstring
            logger.exception(f"{TAG} {func.__name__} failed")
            try:
                if isValid(self):
                    self._set_busy("")
                    self.status.setText("Có lỗi không mong muốn (chi tiết trong Nhật ký Logs).")
            except Exception:   # noqa: BLE001
                logger.exception(f"{TAG} could not report the failure of {func.__name__}")
            return None
    return wrapper


_running_tasks: set = set()          # strong refs: a QThread must outlive its screen (the user may leave the page)
_running_lock = threading.Lock()
_quit_hooked = False


def _stop_all_tasks_on_quit():
    with _running_lock:
        tasks = list(_running_tasks)
    for t in tasks:
        t.cancel()
    for t in tasks:
        if not t.wait(3000):
            logger.warning(f"{TAG} task {t.label!r} still running at exit")


def _hook_quit():
    global _quit_hooked
    app = QApplication.instance()
    if app is not None and not _quit_hooked:
        app.aboutToQuit.connect(_stop_all_tasks_on_quit)
        _quit_hooked = True


class _Task(QThread):
    """Run fn(progress_cb, is_cancelled) off the UI thread; emits done(result, error_text). Never raises."""

    progress = Signal(int, int)
    done = Signal(object, str)

    def __init__(self, fn, label: str):
        super().__init__(None)                       # no parent: deleting the screen must not destroy a running thread
        self.label = label
        self._fn = fn
        self._cancel = False
        self.setObjectName(f"upscaler-{label}")

    def cancel(self):
        self._cancel = True

    def start_tracked(self):
        _hook_quit()
        with _running_lock:
            _running_tasks.add(self)
        self.finished.connect(self._forget)
        self.start()

    @_safe
    def _forget(self):
        with _running_lock:
            _running_tasks.discard(self)

    def run(self):
        started = time.monotonic()
        logger.info(f"{TAG} task {self.label!r} started on thread {threading.current_thread().name}")
        result, error = None, ""
        try:
            result = self._fn(lambda d, t: self.progress.emit(d, t), lambda: self._cancel)
        except (InstallError, downloader.DownloadError) as e:
            error = str(e) or e.__class__.__name__
            logger.warning(f"{TAG} task {self.label!r} failed: {error}")
        except Exception as e:   # noqa: BLE001 - surfaced to the user instead of killing the thread silently
            logger.exception(f"{TAG} task {self.label!r} crashed")
            error = f"Lỗi không mong muốn: {e}"
        else:
            logger.info(f"{TAG} task {self.label!r} finished in {time.monotonic() - started:.2f}s")
        try:
            self.done.emit(result, error)
        except Exception:   # noqa: BLE001 - the receiver (screen) may already be gone
            logger.exception(f"{TAG} task {self.label!r}: could not deliver the result")


class _BuildWatcher(QObject):
    """Watches the HelixSR setup console. Process-wide, so it still finishes the job if the user leaves the page.

    Once the network is in the DLL it ends the console: the setup would otherwise ask, game by game, whether to
    install (Enter = yes), which Bob wants to do itself.
    """

    finished = Signal(bool)

    def __init__(self):
        super().__init__(QApplication.instance())
        self._proc = None
        self._ready_polls = 0
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._poll)

    @property
    def running(self) -> bool:
        return self._proc is not None

    def start(self, proc) -> None:
        self._proc, self._ready_polls = proc, 0
        self._timer.start()

    def _finish(self, built: bool) -> None:
        self._timer.stop()
        self._proc = None
        logger.info(f"{TAG} HelixSR build finished (network built: {built})")
        self.finished.emit(built)

    def _poll(self) -> None:
        try:
            proc = self._proc
            if proc is None:
                self._timer.stop()
                return
            built = helixsr.build_state(downloader.package_dir(downloader.HELIXSR)) == helixsr.STATE_BUILT
            self._ready_polls = self._ready_polls + 1 if built else 0
            if self._ready_polls >= 2:               # tag present on two polls in a row: the DLL is fully written
                helixsr.stop_process_tree(proc)
            elif proc.poll() is None:
                return
            self._finish(built)
        except Exception:   # noqa: BLE001 - a timer slot must never raise
            logger.exception(f"{TAG} build watcher failed")
            self._finish(False)


_watcher: _BuildWatcher | None = None


def build_watcher() -> _BuildWatcher:
    global _watcher
    if _watcher is None or not isValid(_watcher):
        _watcher = _BuildWatcher()
    return _watcher


class _SharpeningDialog(QDialog):
    def __init__(self, exe_dir: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Độ sắc nét HelixSR")
        cur = helixsr.get_sharpening(exe_dir)
        form = QFormLayout(self)
        self.mode = QComboBox()
        self.mode.addItems(helixsr.SHARPENERS)
        self.mode.setCurrentText(cur["sharpener"])
        self.amount = QDoubleSpinBox()
        self.amount.setRange(0.0, 1.0)
        self.amount.setSingleStep(0.05)
        self.amount.setValue(cur["sharpness"])
        self.slider = QCheckBox("Theo thanh trượt sắc nét của game")
        self.slider.setChecked(cur["use_game_slider"])
        form.addRow("Bộ lọc", self.mode)
        form.addRow("Cường độ (0–1)", self.amount)
        form.addRow(self.slider)
        form.addRow(QLabel("Mặc định tắt (giống DLSS). nvidia = bộ lọc của NVIDIA, rcas = của AMD FSR."))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def values(self):
        return self.mode.currentText(), self.amount.value(), self.slider.isChecked()


class UpscalerScreen(QWidget):
    """Full-screen Upscaler manager."""

    back_requested = Signal()

    def __init__(self, config: dict, games_provider=None, parent=None):
        super().__init__(parent)
        self.config = config
        self._games_provider = games_provider or (lambda: [])   # Library game dicts (name, install_location, exe_path)
        self._store = SettingsStore()
        self._gpu = None
        self._entries: list[service.GameEntry] = []
        self._states: dict[str, str] = {}
        self._platform: str | None = None          # active tab (None = all)
        self._tab_keys: list = [None]
        self._sort = ("name", False)               # (sort key, descending)
        self._mode_choice: dict[str, str] = {}     # folder -> mode picked in the row's combo (kept across re-sorts)
        self._task: _Task | None = None
        self._setup_ui()
        build_watcher().finished.connect(self._on_build_finished)
        QTimer.singleShot(0, self.refresh)

    # ------------------------------------------------------------ layout

    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        header = ScreenHeader("Upscaler", "sliders", subtitle="OptiScaler, FSR và HelixSR cho từng game")
        header.back_requested.connect(self.back_requested.emit)
        self.add_btn = header.add_button("Thêm thư mục game", "secondary", icon="plus")
        self.add_btn.clicked.connect(self._add_folder)
        self.refresh_btn = header.add_button("Quét lại", "secondary", icon="refresh")
        self.refresh_btn.clicked.connect(self.refresh)
        root.addWidget(header)

        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(*CONTENT_MARGINS)
        lay.setSpacing(14)

        cards = QHBoxLayout()
        cards.setSpacing(14)
        self.gpu_card, self.gpu_val, self.gpu_sub = self._card("GPU", "cast", "#38bdf8")
        self.opti_card, self.opti_val, self.opti_btn = self._card("OptiScaler", "download", "#a855f7", button=True)
        self.helix_card, self.helix_val, self.helix_btn = self._card("HelixSR", "sync", "#2ed573", button=True)
        for c in (self.gpu_card, self.opti_card, self.helix_card):
            cards.addWidget(c, 1)
        lay.addLayout(cards)
        self.opti_btn.clicked.connect(self._download_optiscaler)
        self.helix_btn.clicked.connect(self._helix_primary_action)

        self.progress = QProgressBar()
        self.progress.setFixedHeight(8)
        self.progress.setTextVisible(False)
        self.progress.hide()
        lay.addWidget(self.progress)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.status.setStyleSheet("color: #94a3b8; font-size: 12px;")
        lay.addWidget(self.status)

        bar = QHBoxLayout()
        bar.setSpacing(10)
        self.tabs = QTabBar()
        self.tabs.setExpanding(False)
        self.tabs.setDrawBase(False)
        self.tabs.setCursor(Qt.CursorShape.PointingHandCursor)
        self.tabs.setStyleSheet("""
            QTabBar::tab { background: rgba(255,255,255,0.05); color: #cbd5e1; padding: 6px 14px; margin-right: 6px;
                           border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; font-size: 12px; }
            QTabBar::tab:selected { background: #8b5cf6; color: #ffffff; font-weight: bold; }
        """)
        self.tabs.currentChanged.connect(self._on_tab_changed)
        bar.addWidget(self.tabs, 1)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Tìm tên game…")
        self.search.setClearButtonEnabled(True)
        self.search.setFixedSize(260, 34)
        self.search.setStyleSheet("QLineEdit { background-color: rgba(18,22,34,0.8); border: 1px solid rgba(255,255,255,0.1); "
                                  "border-radius: 8px; padding: 0 10px; color: #ffffff; } QLineEdit:focus { border-color: #8b5cf6; }")
        self.search.textChanged.connect(self._on_search_changed)
        bar.addWidget(self.search)
        lay.addLayout(bar)

        self.table = QTableWidget(0, len(_COLUMNS))
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)      # every column can be dragged to any width
        h.setMinimumSectionSize(MIN_COLUMN_WIDTH)
        h.setStretchLastSection(True)
        h.setSectionsClickable(True)
        h.sectionClicked.connect(self._on_header_clicked)
        self._apply_column_widths()
        self._width_timer = QTimer(self)                                # save the widths once the dragging stops
        self._width_timer.setSingleShot(True)
        self._width_timer.setInterval(500)
        self._width_timer.timeout.connect(self._save_column_widths)
        h.sectionResized.connect(self._on_section_resized)
        self._update_header_labels()
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setStyleSheet("""
            QTableWidget { background-color: rgba(14, 18, 26, 0.85); color: #e2e8f0; font-size: 13px;
                           gridline-color: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; }
            QHeaderView::section { background-color: rgba(20,26,38,0.95); color: #94a3b8; padding: 8px;
                                   border: 1px solid rgba(255,255,255,0.06); font-weight: bold; }
            QHeaderView::section:hover { color: #ffffff; }
        """)
        lay.addWidget(self.table, 1)
        self.empty_label = QLabel("")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_label.setStyleSheet("color: #8b949e; font-size: 13px; padding: 8px;")
        lay.addWidget(self.empty_label)
        root.addWidget(body, 1)

    def _card(self, title, icon, color, button=False):
        card = QFrame()
        card.setStyleSheet("QFrame { background-color: rgba(18,22,34,0.7); border: 1px solid rgba(255,255,255,0.08); "
                           "border-radius: 10px; } QLabel { border: none; background: transparent; }")
        row = QHBoxLayout(card)
        row.setContentsMargins(16, 12, 16, 12)
        ic = QLabel()
        ic.setPixmap(make_svg_pixmap(icon, size=22, color=color))
        row.addWidget(ic)
        col = QVBoxLayout()
        col.setSpacing(2)
        t = QLabel(title)
        t.setStyleSheet("color: #8b949e; font-size: 11px;")
        v = QLabel("…")
        v.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        v.setStyleSheet("color: #ffffff;")
        v.setWordWrap(True)
        col.addWidget(t)
        col.addWidget(v)
        row.addLayout(col, 1)
        if button:
            b = QPushButton("")
            b.setFixedHeight(30)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setStyleSheet(_BTN)
            row.addWidget(b)
            return card, v, b
        sub = QLabel("")
        sub.setStyleSheet("color: #94a3b8; font-size: 11px;")
        col.addWidget(sub)
        return card, v, sub

    # ------------------------------------------------------------ data

    @_safe
    def refresh(self):
        if self._task is not None:
            logger.debug(f"{TAG} refresh ignored: a task is running")
            return
        library = list(self._games_provider())      # read on the UI thread: the Library's cards are Qt objects

        def work(_p, _c):
            from app.core.game_scanner import scan_steam_games
            try:
                steam = scan_steam_games()                   # games of every Steam library (registry "Steam App" keys)
            except Exception:   # noqa: BLE001 - a registry hiccup must not hide the Library games
                logger.exception("[Upscaler] Steam scan failed")
                steam = []
            return gpu.primary_gpu(), service.component_states(), service.list_games(library, self._store.data, steam)

        self._run(work, self._on_refreshed, "Đang quét game…", "scan")

    @_safe
    def _on_refreshed(self, result):
        try:
            self._apply_refresh(result)
        finally:
            self._set_busy("")

    def _apply_refresh(self, result):
        self._gpu, self._states, self._entries = result
        logger.info(f"{TAG} list refreshed: {len(self._entries)} games, GPU {self._gpu.name if self._gpu else 'unknown'}, "
                    f"components {self._states}")
        g = self._gpu
        if g is None:
            self.gpu_val.setText("Không nhận diện được GPU")
            self.gpu_sub.setText("")
        else:
            self.gpu_val.setText(g.name)
            note = {"rdna": "Hỗ trợ HelixSR (RDNA 1+)", "legacy": "Quá cũ cho HelixSR (không có wave32)",
                    "unknown": "Chưa rõ thế hệ"}.get(g.amd_generation, "")
            self.gpu_sub.setText(note if g.vendor == "AMD" else f"{g.vendor}: không dùng được HelixSR")
        self._update_components()
        self._rebuild_tabs()
        self._populate()

    def _update_components(self):
        ready = self._states.get("optiscaler") != helixsr.STATE_MISSING
        self.opti_val.setText("Đã tải" if ready else "Chưa tải")
        self.opti_btn.setText("Đã sẵn sàng" if ready else "Tải xuống")
        self.opti_btn.setEnabled(not ready)
        hs = self._states.get("helixsr", helixsr.STATE_MISSING)
        self.helix_val.setText(_STATE_TEXT[hs] + ("" if not (self._gpu and not self._gpu.helixsr_supported) else " (GPU không hỗ trợ)"))
        self.helix_btn.setText({"missing": "Tải xuống", "downloaded": "Build", "built": "Build lại"}[hs])
        self.helix_btn.setEnabled(bool(self._gpu and self._gpu.helixsr_supported) and not build_watcher().running)

    # ------------------------------------------------------------ tabs / search / sort

    def _rebuild_tabs(self):
        counts = service.platform_counts(self._entries)
        keys = [None] + [k for k, _label in platforms.PLATFORMS if counts.get(k)]
        self.tabs.blockSignals(True)
        while self.tabs.count():
            self.tabs.removeTab(0)
        self.tabs.addTab(f"Tất cả ({len(self._entries)})")
        for k in keys[1:]:
            self.tabs.addTab(f"{platforms.LABELS[k]} ({counts[k]})")
        self._tab_keys = keys
        if self._platform not in keys:
            self._platform = None
        self.tabs.setCurrentIndex(keys.index(self._platform))
        self.tabs.blockSignals(False)

    def _apply_column_widths(self):
        widths = clean_column_widths(self._store.data.column_widths) or list(_DEFAULT_WIDTHS)
        for i, w in enumerate(widths):
            self.table.setColumnWidth(i, w)

    def _on_section_resized(self, _index: int, _old: int, _new: int):
        self._width_timer.start()

    @_safe
    def _save_column_widths(self):
        widths = clean_column_widths([self.table.columnWidth(i) for i in range(len(_COLUMNS))])
        if widths and widths != self._store.data.column_widths:
            self._store.data.column_widths = widths
            self._store.save()
            logger.debug(f"{TAG} column widths saved: {widths}")

    @_safe
    def _on_tab_changed(self, index: int):
        if 0 <= index < len(self._tab_keys):
            self._platform = self._tab_keys[index]
            self._populate()

    @_safe
    def _on_search_changed(self, _text: str):
        self._populate()

    @_safe
    def _on_header_clicked(self, column: int):
        key = _COLUMNS[column][1] if 0 <= column < len(_COLUMNS) else None
        if key is None:
            return
        self._sort = (key, not self._sort[1]) if self._sort[0] == key else (key, False)
        self._update_header_labels()
        self._populate()

    def _update_header_labels(self):
        labels = []
        for title, key in _COLUMNS:
            arrow = (" ▼" if self._sort[1] else " ▲") if key and key == self._sort[0] else ""
            labels.append(title + arrow)
        self.table.setHorizontalHeaderLabels(labels)

    def _chosen_mode_label(self, entry: service.GameEntry) -> str:
        mode = self._mode_choice.get(entry.folder)
        if mode:
            return service.MODE_LABELS.get(mode, "")
        usable = [m for m, _l, r in service.available_modes(entry, self._gpu, self._states) if not r]
        return service.MODE_LABELS.get(usable[0], "") if usable else ""

    def visible_entries(self) -> list[service.GameEntry]:
        shown = service.filter_entries(self._entries, self._platform, self.search.text())
        return service.sort_entries(shown, self._sort[0], self._sort[1], self._chosen_mode_label)

    def _populate(self):
        entries = self.visible_entries()
        self.table.setRowCount(0)
        for entry in entries:
            row = self.table.rowCount()
            self.table.insertRow(row)
            name = QTableWidgetItem(entry.name)
            name.setToolTip(entry.folder)
            self.table.setItem(row, 0, name)
            self.table.setItem(row, 1, QTableWidgetItem(platforms.LABELS.get(entry.platform, "")))
            self.table.setItem(row, 2, QTableWidgetItem(", ".join(entry.technologies) or "—"))
            self.table.setItem(row, 3, QTableWidgetItem(service.current_label(entry)))
            self._fill_row_widgets(row, entry)
        if entries:
            self.empty_label.setText("")
        elif self._entries:
            self.empty_label.setText("Không có game nào khớp bộ lọc / từ khoá tìm kiếm.")
        else:
            self.empty_label.setText("Chưa có game nào: thêm game vào Thư viện hoặc bấm 'Thêm thư mục game'.")

    def _fill_row_widgets(self, row: int, entry: service.GameEntry):
        combo = QComboBox()
        modes = service.available_modes(entry, self._gpu, self._states)
        for mode, label, reason in modes:
            combo.addItem(label if not reason else f"{label} — {reason}", mode)
            if reason:
                combo.model().item(combo.count() - 1).setEnabled(False)
        usable = [i for i, (_m, _l, r) in enumerate(modes) if not r]
        if usable:
            combo.setCurrentIndex(usable[0])
            kept = combo.findData(self._mode_choice.get(entry.folder))
            if kept in usable:
                combo.setCurrentIndex(kept)
            combo.currentIndexChanged.connect(
                lambda _i, f=entry.folder, c=combo: self._mode_choice.__setitem__(f, c.currentData()))
        combo.setEnabled(bool(usable))
        self.table.setCellWidget(row, _COL_MODE, combo)

        w = QWidget()
        hb = QHBoxLayout(w)
        hb.setContentsMargins(4, 2, 4, 2)
        hb.setSpacing(6)

        def btn(text, style, slot, enabled=True):
            b = QPushButton(text)
            b.setFixedHeight(28)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setStyleSheet(style)
            b.setEnabled(enabled)
            b.clicked.connect(slot)
            hb.addWidget(b)

        installed = bool(entry.status.mode)
        btn("Áp dụng", _BTN, lambda _=False, e=entry, c=combo: self._apply(e, c.currentData()), bool(usable))
        btn("Gỡ", _BTN_PLAIN, lambda _=False, e=entry: self._remove(e), installed or entry.status.pending)
        if entry.status.mode in (installer.MODE_HELIXSR_F, installer.MODE_HELIXSR_O):
            btn("Độ sắc nét", _BTN_PLAIN, lambda _=False, e=entry: self._sharpening(e))
        if entry.scan.helixsr_foreign and self._states.get("helixsr") != helixsr.STATE_MISSING:
            btn("Gỡ bằng HelixSR", _BTN_PLAIN, lambda _=False, e=entry: self._official_uninstall(e))
        if helixsr.existing_logs(entry.exe_dir):
            btn("Log", _BTN_PLAIN, lambda _=False, e=entry: self._open_logs(e))
        btn("Thư mục", _BTN_PLAIN, lambda _=False, e=entry: self._open_folder(e))
        if entry.source == "manual":
            btn("Bỏ", _BTN_PLAIN, lambda _=False, e=entry: self._forget(e), not installed)
        self.table.setCellWidget(row, _COL_ACTIONS, w)
        self.table.setRowHeight(row, 40)

    # ------------------------------------------------------------ tasks

    def _set_busy(self, text: str, busy: bool | None = None):
        busy = bool(text) if busy is None else busy
        self.status.setText(text)
        for b in (self.add_btn, self.refresh_btn, self.table):
            b.setEnabled(not busy)
        self.opti_btn.setEnabled(not busy and self._states.get("optiscaler") == helixsr.STATE_MISSING)
        if not busy:
            self.progress.hide()
            self._update_components()

    def _run(self, fn, on_ok, busy_text: str, label: str, error_title: str = "Upscaler") -> bool:
        """Start `fn` on a worker thread. One task at a time per screen; returns False if it was not started."""
        if self._task is not None:
            logger.warning(f"{TAG} {label!r} not started: task {self._task.label!r} is still running")
            return False
        self._set_busy(busy_text)
        task = _Task(fn, label)
        self._task = task
        task.progress.connect(self._on_progress)
        me = self

        def finished(result, error):
            if not isValid(me):                      # the user left the page: the work is done, nothing to update
                logger.info(f"{TAG} task {label!r} finished after its screen was closed")
                return
            try:
                me._task = None
                if error:
                    me._set_busy("")
                    QMessageBox.warning(me, error_title, error)
                    me.refresh()
                    return
                on_ok(result)
            except Exception:   # noqa: BLE001 - never let a result handler escape into the event loop
                logger.exception(f"{TAG} handler of task {label!r} failed")
                try:
                    me._set_busy("")
                except Exception:   # noqa: BLE001
                    pass

        task.done.connect(finished)
        task.start_tracked()
        return True

    def _on_progress(self, done: int, total: int):
        self.progress.show()
        self.progress.setRange(0, max(total, 1))
        self.progress.setValue(done)

    def _download_optiscaler(self):
        logger.info(f"{TAG} user: download OptiScaler")

        def work(progress, cancel):
            downloader.install_package(downloader.OPTISCALER, progress=progress, is_cancelled=cancel)

        self._run(work, lambda _r: self.refresh(), "Đang tải OptiScaler…", "download-optiscaler")

    def _helix_primary_action(self):
        state = self._states.get("helixsr", helixsr.STATE_MISSING)
        logger.info(f"{TAG} user: HelixSR button (state {state})")
        if not self._store.data.helixsr_disclaimer_ok:
            if QMessageBox.question(self, "HelixSR", HELIXSR_NOTICE + "\n\nBạn đồng ý và tiếp tục?") != QMessageBox.StandardButton.Yes:
                logger.info(f"{TAG} user declined the HelixSR notice")
                return
            self._store.data.helixsr_disclaimer_ok = True
            self._store.save()
        if state == helixsr.STATE_MISSING:
            self._run(lambda p, c: downloader.install_package(downloader.HELIXSR, progress=p, is_cancelled=c),
                      lambda _r: self.refresh(), "Đang tải HelixSR…", "download-helixsr")
        else:
            self._start_build()

    def _start_build(self):
        if build_watcher().running:
            logger.info(f"{TAG} a HelixSR build is already running")
            return
        helix_dir = downloader.package_dir(downloader.HELIXSR)
        dlss = self._store.data.helixsr_dlss_path
        if not dlss:
            found = helixsr.find_dlss_dll([e.folder for e in self._entries])
            if found and QMessageBox.question(
                    self, "HelixSR", f"Tìm thấy DLSS trong game:\n{found}\n\nDùng file này để build (bỏ qua bước tải của NVIDIA)?"
                    "\nSetup sẽ tự kiểm tra phiên bản (cần 310.7.0 hoặc 310.2)."
            ) == QMessageBox.StandardButton.Yes:
                dlss = found
        try:
            proc = helixsr.start_build(helix_dir, dlss)
        except InstallError as e:
            QMessageBox.warning(self, "HelixSR", str(e))
            return
        self.helix_btn.setEnabled(False)
        self.status.setText("HelixSR đang build trong cửa sổ console (khoảng 1–2 phút). Bob sẽ tự đóng nó khi xong.")
        build_watcher().start(proc)

    def _on_build_finished(self, built: bool):
        try:
            if not isValid(self):
                return
            self.status.setText("HelixSR build xong." if built else
                                "Setup HelixSR kết thúc nhưng DLL chưa chứa mạng. Hãy bấm Build lại và đọc thông báo trong console.")
            self.refresh()
        except Exception:   # noqa: BLE001 - a signal slot must never raise
            logger.exception(f"{TAG} could not handle the end of the HelixSR build")

    # ------------------------------------------------------------ row actions

    def _apply(self, entry, mode):
        if not mode:
            return
        logger.info(f"{TAG} user: apply {mode} to {entry.name!r}")
        if mode in (installer.MODE_HELIXSR_F, installer.MODE_HELIXSR_O) and not self._store.data.helixsr_disclaimer_ok:
            QMessageBox.information(self, "HelixSR", "Hãy thực hiện bước tải/build HelixSR ở thẻ phía trên trước.")
            return
        self._run(lambda _p, _c: service.apply_mode(entry, mode, self._gpu), lambda _r: self.refresh(),
                  f"Đang cài cho {entry.name}…", f"apply-{entry.name}")

    def _remove(self, entry):
        logger.info(f"{TAG} user: remove the upscaler from {entry.name!r}")
        self._run(lambda _p, _c: service.remove_mode(entry), lambda _r: self.refresh(),
                  f"Đang gỡ khỏi {entry.name}…", f"remove-{entry.name}")

    def _sharpening(self, entry):
        dlg = _SharpeningDialog(entry.exe_dir, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            try:
                helixsr.set_sharpening(entry.exe_dir, *dlg.values())
            except InstallError as e:
                QMessageBox.warning(self, "HelixSR", str(e))

    def _official_uninstall(self, entry):
        if QMessageBox.question(self, "HelixSR", f"Chạy uninstaller chính chủ của HelixSR cho:\n{entry.folder}?") \
                != QMessageBox.StandardButton.Yes:
            return
        try:
            helixsr.start_official_uninstall(downloader.package_dir(downloader.HELIXSR), entry.folder)
        except InstallError as e:
            QMessageBox.warning(self, "HelixSR", str(e))
            return
        self.status.setText("Uninstaller của HelixSR đang chạy trong console. Bấm 'Quét lại' khi xong.")

    @_safe
    def _open_folder(self, entry):
        try:
            os.startfile(entry.exe_dir)
        except OSError as e:
            logger.warning(f"{TAG} cannot open {entry.exe_dir}: {e}")
            QMessageBox.warning(self, "Upscaler", f"Không mở được thư mục: {e}")

    def _open_logs(self, entry):
        for p in helixsr.existing_logs(entry.exe_dir):
            try:
                os.startfile(p)
            except OSError as e:
                logger.warning(f"{TAG} cannot open {p}: {e}")

    def _add_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục game")
        if folder:
            logger.info(f"{TAG} user: add game folder {folder}")
            self._store.add_game(folder)
            self.refresh()

    def _forget(self, entry):
        logger.info(f"{TAG} user: forget game folder {entry.folder}")
        self._store.remove_game(entry.folder)
        self.refresh()
