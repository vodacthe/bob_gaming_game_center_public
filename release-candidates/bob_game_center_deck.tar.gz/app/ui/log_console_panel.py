"""
Live Log Console panel for Bob Gaming Game Center.
Streams real-time application logs in a collapsible right-side dock/panel.
"""

import collections
import logging
import os
import re
from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QPlainTextEdit, QComboBox, QLineEdit, QCheckBox, QApplication
)
from PySide6.QtCore import Qt, Signal, QObject, QTimer
from PySide6.QtGui import QFont, QTextCursor

from app.config import LOG_FILE
from app.ui.icons import make_svg_icon
from app.ui.styles import CHECK_ICON_PATH

logger = logging.getLogger(__name__)


class LogEmitter(QObject):
    """QObject wrapper to safely emit log records across threads to Qt GUI thread."""
    log_record = Signal(dict)


class QtLogHandler(logging.Handler):
    """Custom logging Handler routing log records to LogEmitter."""

    def __init__(self, emitter: LogEmitter):
        super().__init__()
        self.emitter = emitter
        # Format similar to standard logger
        self.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))

    def emit(self, record: logging.LogRecord):
        try:
            formatted = self.format(record)
            data = {
                "timestamp": getattr(record, "asctime", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                "level": record.levelname,
                "name": record.name,
                "message": record.getMessage(),
                "formatted": formatted,
            }
            self.emitter.log_record.emit(data)
        except Exception:
            self.handleError(record)


class LogConsolePanel(QWidget):
    """Collapsible right-side panel that displays live streaming logs."""

    closed = Signal()

    MAX_BUFFER_LINES = 2000
    FLUSH_INTERVAL_MS = 150     # log lines are rendered in batches, never one GUI call per line
    MAX_FLUSH_BATCH = 200       # per flush; the rest waits for the next tick so the UI stays responsive

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("logConsolePanel")
        self.setMinimumWidth(320)

        # Buffer for log history
        self._all_records = collections.deque(maxlen=self.MAX_BUFFER_LINES)
        self._pending: list[dict] = []   # received while visible, not yet rendered
        self._dirty = False              # records arrived while hidden: re-render on show
        self._flush_timer = QTimer(self)
        self._flush_timer.setSingleShot(True)
        self._flush_timer.setInterval(self.FLUSH_INTERVAL_MS)
        self._flush_timer.timeout.connect(self.flush_pending)

        # Handler setup
        self.emitter = LogEmitter()
        self.handler = QtLogHandler(self.emitter)
        self.emitter.log_record.connect(self._on_log_received)

        # Register handler to root logger
        logging.getLogger().addHandler(self.handler)

        self._setup_ui()
        self.preload_from_file()

    def _setup_ui(self):
        self.setStyleSheet("""
            #logConsolePanel {
                background-color: #0c101d;
                border-left: 1px solid #1c2234;
            }
        """)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(8)

        # ================= TOP HEADER =================
        header_row = QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)
        header_row.setSpacing(8)

        from app.ui.icons import make_svg_icon, make_svg_pixmap

        title_icon = QLabel()
        title_icon.setPixmap(make_svg_pixmap("terminal", 18, "#a855f7"))
        title_icon.setStyleSheet("background: transparent; border: none;")
        header_row.addWidget(title_icon)

        title_label = QLabel("Nhật ký hệ thống (Live Logs)")
        title_label.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #ffffff; background: transparent; border: none;")
        header_row.addWidget(title_label)

        # Live status badge
        self.live_badge = QLabel("● TRỰC TIẾP")
        self.live_badge.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        self.live_badge.setStyleSheet("""
            QLabel {
                color: #2ed573;
                background-color: rgba(46, 213, 115, 0.12);
                border: 1px solid rgba(46, 213, 115, 0.3);
                border-radius: 9px;
                padding: 2px 8px;
            }
        """)
        header_row.addWidget(self.live_badge)

        header_row.addStretch()

        # Close button (×)
        self.close_btn = QPushButton("×")
        self.close_btn.setObjectName("logCloseBtn")
        self.close_btn.setFixedSize(28, 28)
        self.close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_btn.setStyleSheet("""
            QPushButton#logCloseBtn {
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 6px;
                color: #8b949e;
                font-family: 'Segoe UI', Arial, sans-serif;
                font-size: 16px;
                font-weight: bold;
                padding: 0px;
                min-height: 0px;
            }
            QPushButton#logCloseBtn:hover {
                background: rgba(255, 71, 87, 0.2);
                color: #ff4d4d;
                border-color: rgba(255, 71, 87, 0.4);
            }
        """)
        self.close_btn.clicked.connect(self._on_close_clicked)
        header_row.addWidget(self.close_btn)

        main_layout.addLayout(header_row)

        # ================= CONTROLS ROW 1 =================
        controls_row1 = QHBoxLayout()
        controls_row1.setContentsMargins(0, 0, 0, 0)
        controls_row1.setSpacing(6)

        # Level filter combo
        level_lbl = QLabel("Mức:")
        level_lbl.setStyleSheet("color: #7a828e; font-size: 11px; background: transparent;")
        controls_row1.addWidget(level_lbl)

        self.level_combo = QComboBox()
        self.level_combo.addItems(["ALL", "INFO", "WARNING", "ERROR", "DEBUG"])
        self.level_combo.setCurrentText("ALL")
        self.level_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.level_combo.setStyleSheet("""
            QComboBox {
                background-color: #121625;
                border: 1px solid #1c2234;
                border-radius: 6px;
                padding: 3px 8px;
                color: #e0e0e0;
                font-size: 11px;
                min-width: 75px;
            }
            QComboBox:hover {
                border-color: #a855f7;
            }
            QComboBox QAbstractItemView {
                background-color: #121625;
                border: 1px solid #1c2234;
                selection-background-color: rgba(139, 92, 246, 0.25);
                selection-color: #ffffff;
                color: #e0e0e0;
            }
        """)
        self.level_combo.currentTextChanged.connect(self._reapply_filter)
        controls_row1.addWidget(self.level_combo)

        # Search filter input
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Tìm kiếm / Lọc nội dung...")
        self.search_input.setStyleSheet("""
            QLineEdit {
                background-color: #121625;
                border: 1px solid #1c2234;
                border-radius: 6px;
                padding: 3px 8px;
                color: #e0e0e0;
                font-size: 11px;
            }
            QLineEdit:focus {
                border-color: #a855f7;
            }
        """)
        self.search_input.textChanged.connect(self._reapply_filter)
        controls_row1.addWidget(self.search_input, 1)

        main_layout.addLayout(controls_row1)

        # ================= CONTROLS ROW 2 (ACTIONS) =================
        controls_row2 = QHBoxLayout()
        controls_row2.setContentsMargins(0, 0, 0, 0)
        controls_row2.setSpacing(6)

        # Auto-scroll checkbox
        self.auto_scroll_cb = QCheckBox("Tự cuộn")
        self.auto_scroll_cb.setChecked(True)
        self.auto_scroll_cb.setCursor(Qt.CursorShape.PointingHandCursor)
        self.auto_scroll_cb.setStyleSheet(f"""
            QCheckBox {{
                color: #9fa6b2;
                font-size: 11px;
                background: transparent;
            }}
            QCheckBox::indicator {{
                width: 14px;
                height: 14px;
                border-radius: 3px;
                border: 1px solid #1c2234;
                background-color: #121625;
            }}
            QCheckBox::indicator:unchecked {{
                image: none;
            }}
            QCheckBox::indicator:checked {{
                background-color: #7c3aed;
                border-color: #8b5cf6;
                image: url("{CHECK_ICON_PATH}");
            }}
        """)
        controls_row2.addWidget(self.auto_scroll_cb)

        controls_row2.addStretch()

        btn_style = """
            QPushButton {
                background-color: #141829;
                border: 1px solid #20273d;
                border-radius: 6px;
                padding: 4px 10px;
                color: #9fa6b2;
                font-size: 11px;
                font-weight: 600;
                min-height: 0px;
            }
            QPushButton:hover {
                background-color: #1c223a;
                color: #ffffff;
                border-color: #a855f7;
            }
            QPushButton:pressed {
                background-color: #283050;
            }
        """

        self.copy_btn = QPushButton(" Sao chép")
        self.copy_btn.setIcon(make_svg_icon("copy", 13, "#8c96a8"))
        self.copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.copy_btn.setStyleSheet(btn_style)
        self.copy_btn.clicked.connect(self._copy_to_clipboard)
        controls_row2.addWidget(self.copy_btn)

        self.clear_btn = QPushButton(" Xóa nhật ký")
        self.clear_btn.setIcon(make_svg_icon("trash", 13, "#8c96a8"))
        self.clear_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.clear_btn.setStyleSheet(btn_style)
        self.clear_btn.clicked.connect(self._clear_logs)
        controls_row2.addWidget(self.clear_btn)

        main_layout.addLayout(controls_row2)

        # ================= LOG TEXT AREA =================
        self.text_edit = QPlainTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setMaximumBlockCount(self.MAX_BUFFER_LINES)

        font = QFont("Cascadia Code", 9)
        if not font.exactMatch():
            font = QFont("Consolas", 9)
            if not font.exactMatch():
                font = QFont("Courier New", 9)
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.text_edit.setFont(font)

        self.text_edit.setStyleSheet("""
            QPlainTextEdit {
                background-color: #070a12;
                border: 1px solid #161b26;
                border-radius: 8px;
                padding: 8px;
                color: #d1d5db;
                line-height: 1.4;
            }
        """)
        main_layout.addWidget(self.text_edit, 1)

        # ================= FOOTER STATS =================
        footer_row = QHBoxLayout()
        footer_row.setContentsMargins(2, 0, 2, 0)
        self.stats_label = QLabel("0 logs")
        self.stats_label.setStyleSheet("color: #4e5563; font-size: 10px; background: transparent;")
        footer_row.addWidget(self.stats_label)
        footer_row.addStretch()

        self.path_label = QLabel(f"File: {os.path.basename(LOG_FILE)}")
        self.path_label.setToolTip(LOG_FILE)
        self.path_label.setStyleSheet("color: #4e5563; font-size: 10px; background: transparent;")
        footer_row.addWidget(self.path_label)

        main_layout.addLayout(footer_row)

    def _on_close_clicked(self):
        """Hide panel and notify parent."""
        self.hide()
        self.closed.emit()

    def _matches_filter(self, record: dict) -> bool:
        """Check if record satisfies current level and search filter."""
        target_level = self.level_combo.currentText().upper()
        rec_level = record.get("level", "INFO").upper()

        if target_level not in ("ALL", "TẤT CẢ"):
            if target_level == "ERROR" and rec_level not in ("ERROR", "CRITICAL"):
                return False
            elif target_level == "WARNING" and rec_level not in ("WARNING", "ERROR", "CRITICAL"):
                return False
            elif target_level == "INFO" and rec_level not in ("INFO", "WARNING", "ERROR", "CRITICAL"):
                return False
            elif target_level == "DEBUG" and rec_level != "DEBUG":
                return False

        search_query = self.search_input.text().strip().lower()
        if search_query:
            line_text = record.get("formatted", "").lower()
            if search_query not in line_text:
                return False

        return True

    def _format_html_line(self, record: dict) -> str:
        """Format a single log record with syntax colors."""
        ts = record.get("timestamp", "")
        level = record.get("level", "INFO").upper()
        name = record.get("name", "")
        msg = record.get("message", "")

        # HTML escape message
        msg_escaped = (
            msg.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
        )

        level_colors = {
            "DEBUG": "#747d8c",
            "INFO": "#54a0ff",
            "WARNING": "#ffa502",
            "ERROR": "#ff4757",
            "CRITICAL": "#ff6b81",
        }
        level_color = level_colors.get(level, "#54a0ff")

        return (
            f"<span style='color: #57606f;'>{ts}</span> "
            f"<span style='color: {level_color}; font-weight: bold;'>[{level}]</span> "
            f"<span style='color: #747d8c;'>{name}:</span> "
            f"<span style='color: #e4e7eb;'>{msg_escaped}</span>"
        )

    def _on_log_received(self, record: dict):
        """Slot called whenever a new log entry is emitted.

        Runs inside the logging handler (any thread's log call), so it only queues the record: touching the
        text widget here once froze the whole app, because every thread logs through the same handler lock.
        """
        self._all_records.append(record)

        if not self.isVisible():
            self._dirty = True      # nothing is drawn while the panel is hidden
            return
        self._pending.append(record)
        if len(self._pending) > self.MAX_BUFFER_LINES:
            del self._pending[:-self.MAX_BUFFER_LINES]
        if not self._flush_timer.isActive():
            self._flush_timer.start()

    def flush_pending(self):
        """Render queued records into the text widget (one batch per call)."""
        if not self._pending:
            return
        batch, self._pending = self._pending[:self.MAX_FLUSH_BATCH], self._pending[self.MAX_FLUSH_BATCH:]
        shown = [r for r in batch if self._matches_filter(r)]
        if shown:
            self.text_edit.setUpdatesEnabled(False)
            try:
                for record in shown:
                    self.text_edit.appendHtml(self._format_html_line(record))
                if self.auto_scroll_cb.isChecked():
                    self.text_edit.moveCursor(QTextCursor.MoveOperation.End)
            finally:
                self.text_edit.setUpdatesEnabled(True)
        self._update_stats()
        if self._pending:
            self._flush_timer.start()

    def showEvent(self, event):
        super().showEvent(event)
        if self._dirty:
            self._dirty = False
            self._pending.clear()
            self._reapply_filter()

    def hideEvent(self, event):
        super().hideEvent(event)
        self._flush_timer.stop()
        self._pending.clear()
        self._dirty = True

    def _reapply_filter(self):
        """Re-render all buffered records using current filters."""
        self._pending.clear()
        self.text_edit.clear()

        for record in self._all_records:
            if self._matches_filter(record):
                self.text_edit.appendHtml(self._format_html_line(record))

        if self.auto_scroll_cb.isChecked():
            self.text_edit.moveCursor(QTextCursor.MoveOperation.End)

        self._update_stats()

    def _update_stats(self):
        """Update count in footer."""
        total = len(self._all_records)
        errors = sum(1 for r in self._all_records if r.get("level") in ("ERROR", "CRITICAL"))
        warnings = sum(1 for r in self._all_records if r.get("level") == "WARNING")
        self.stats_label.setText(f"{total} bản ghi ({errors} lỗi, {warnings} cảnh báo)")

    def _clear_logs(self):
        """Clear memory buffer and UI view."""
        self._pending.clear()
        self._all_records.clear()
        self.text_edit.clear()
        self._update_stats()

    def _copy_to_clipboard(self):
        """Copy visible log text to system clipboard."""
        while self._pending:
            self.flush_pending()   # include lines still queued
        text = self.text_edit.toPlainText()
        clipboard = QApplication.clipboard()
        if clipboard:
            clipboard.setText(text)
            orig_text = self.copy_btn.text()
            self.copy_btn.setText("Đã sao chép")
            self.copy_btn.setIcon(make_svg_icon("check", size=13, color="#2ed573"))
            self.copy_btn.setStyleSheet("""
                QPushButton {
                    background-color: #1e3a2f;
                    border: 1px solid #2ed573;
                    border-radius: 6px;
                    padding: 4px 10px;
                    color: #2ed573;
                    font-size: 11px;
                    font-weight: 600;
                }
            """)
            from PySide6.QtCore import QTimer
            QTimer.singleShot(1500, lambda: self._restore_copy_btn(orig_text))

    def _restore_copy_btn(self, orig_text: str):
        self.copy_btn.setText(orig_text)
        self.copy_btn.setIcon(make_svg_icon("copy", size=13, color="#9fa6b2"))
        self.copy_btn.setStyleSheet("""
            QPushButton {
                background-color: #141829;
                border: 1px solid #20273d;
                border-radius: 6px;
                padding: 4px 10px;
                color: #9fa6b2;
                font-size: 11px;
                font-weight: 600;
                min-height: 0px;
            }
            QPushButton:hover {
                background-color: #1c223a;
                color: #ffffff;
                border-color: #a855f7;
            }
        """)

    def preload_from_file(self, max_lines: int = 150):
        """Load last N lines from app.log if available."""
        if not os.path.exists(LOG_FILE):
            return

        try:
            with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()

            recent_lines = lines[-max_lines:]
            log_pattern = re.compile(
                r"^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:,\d+)?)\s+\[([A-Z]+)\]\s+([\w\.]+):\s+(.*)$"
            )

            for line in recent_lines:
                line_str = line.strip()
                if not line_str:
                    continue
                match = log_pattern.match(line_str)
                if match:
                    ts, level, name, msg = match.groups()
                    record = {
                        "timestamp": ts,
                        "level": level,
                        "name": name,
                        "message": msg,
                        "formatted": line_str,
                    }
                else:
                    record = {
                        "timestamp": "",
                        "level": "INFO",
                        "name": "system",
                        "message": line_str,
                        "formatted": line_str,
                    }
                self._all_records.append(record)

            self._reapply_filter()
        except Exception as e:
            logger.debug(f"Preload log file failed: {e}")

    def cleanup(self):
        """Detach QtLogHandler from root logger when destroyed."""
        self._flush_timer.stop()
        try:
            logging.getLogger().removeHandler(self.handler)
        except Exception:
            pass

