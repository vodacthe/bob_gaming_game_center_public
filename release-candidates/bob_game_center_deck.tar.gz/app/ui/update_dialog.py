"""Update popup: shows what is new, lets the user update now, postpone, or skip this version."""

import logging

from PySide6.QtCore import QObject, Qt, QThread, Signal
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QDialog, QHBoxLayout, QLabel, QProgressBar, QPushButton, QTextEdit, QVBoxLayout,
)

from app.core import updater
from app.core.updater import UpdateInfo
from app.version import APP_VERSION

logger = logging.getLogger(__name__)

_STYLE = """
QDialog { background-color: #0b0e14; border: 1px solid rgba(168, 85, 247, 0.45); border-radius: 12px; }
QLabel { color: #e2e8f0; background: transparent; font-size: 13px; }
QLabel#title { color: #ffffff; font-size: 17px; font-weight: 700; }
QLabel#muted { color: #8b949e; font-size: 12px; }
QTextEdit {
    background-color: rgba(10, 14, 22, 0.9); color: #cbd5e1; border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 8px; padding: 8px; font-size: 12px;
}
QCheckBox { color: #cbd5e1; font-size: 12px; spacing: 8px; background: transparent; }
QPushButton {
    background-color: rgba(30, 36, 56, 0.7); border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 8px;
    color: #cbd5e1; font-weight: 700; font-size: 12px; padding: 0 18px; min-height: 36px;
}
QPushButton:hover { background-color: rgba(45, 54, 82, 0.85); border-color: rgba(139, 92, 246, 0.45); color: #ffffff; }
QPushButton:disabled { color: rgba(255, 255, 255, 0.3); }
QPushButton#primary {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8b5cf6, stop:1 #6d28d9);
    border: 1px solid rgba(168, 85, 247, 0.5); color: #ffffff;
}
QPushButton#primary:hover { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #a855f7, stop:1 #7c3aed); }
QProgressBar { border: 1px solid #30363d; border-radius: 6px; background-color: #161b22; text-align: center;
    color: #ffffff; font-size: 11px; height: 18px; }
QProgressBar::chunk { background-color: #8b5cf6; border-radius: 5px; }
"""


class UpdateCheckWorker(QObject):
    """Runs updater.fetch_update_info() off the GUI thread."""

    finished = Signal(object)   # UpdateInfo | None

    def __init__(self, channel: str = updater.CHANNEL_STABLE):
        super().__init__()
        self.channel = updater.normalize_channel(channel)

    def run(self):
        try:
            self.finished.emit(updater.fetch_update_info(channel=self.channel))
        except Exception as e:   # never let a check kill the thread silently
            logger.warning(f"[Update] check crashed (channel={self.channel}): {e}")
            self.finished.emit(None)


class _DownloadWorker(QObject):
    progress = Signal(int, int)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, channel: str = updater.CHANNEL_STABLE):
        super().__init__()
        self._cancelled = False
        self.channel = updater.normalize_channel(channel)

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            path = updater.download_update(self.progress.emit, lambda: self._cancelled, channel=self.channel)
            self.done.emit(path)
        except updater.UpdateCancelled:
            self.failed.emit("")
        except Exception as e:
            logger.warning(f"[Update] download failed (channel={self.channel}): {e}")
            self.failed.emit(str(e) or e.__class__.__name__)


class UpdateDialog(QDialog):
    """Modal popup. After exec(): `downloaded_path` is set when the user updated, `skip_requested` when they
    postponed with 'Bỏ qua phiên bản này' ticked."""

    def __init__(self, info: UpdateInfo, parent=None, can_install: bool | None = None):
        super().__init__(parent)
        self.info = info
        self.downloaded_path = ""
        self.skip_requested = False
        self._thread: QThread | None = None
        self._worker: _DownloadWorker | None = None
        self._can_install = updater.can_self_update() if can_install is None else can_install

        is_rc = updater.normalize_channel(info.channel) == updater.CHANNEL_RC or updater.is_rc_version(info.version)
        if info.allow_downgrade:
            win_title = "Chuyển về bản Stable"
            heading_text = f"Quay về bản Stable: v{info.version}"
            subtitle_text = (
                f"Bạn đang dùng bản thử nghiệm v{APP_VERSION}. "
                f"Cài đặt lại bản chính thức ổn định v{info.version} dưới đây."
            )
            primary_text = "Quay về Stable" if self._can_install else "Tải bản Stable"
        elif is_rc:
            win_title = "Có bản cập nhật Release Candidate"
            heading_text = f"Có bản thử nghiệm (RC) mới: v{info.version}"
            subtitle_text = (
                f"Bạn đang dùng v{APP_VERSION} (kênh Release Candidates). "
                "Cập nhật để thử nghiệm các thay đổi dưới đây."
            )
            primary_text = "Cập nhật bản RC" if self._can_install else "Tải bản RC"
        else:
            win_title = "Có bản cập nhật mới"
            heading_text = f"Có phiên bản mới: v{info.version}"
            subtitle_text = f"Bạn đang dùng v{APP_VERSION}. Cập nhật để có các thay đổi dưới đây."
            primary_text = "Cập nhật ngay" if self._can_install else "Tải bản mới"

        self.setAttribute(Qt.WidgetAttribute.WA_QuitOnClose, False)
        if parent is None:
            self.setWindowFlag(Qt.WindowType.Window, True)
            self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
            app_icon = QApplication.windowIcon()
            if not app_icon.isNull():
                self.setWindowIcon(app_icon)
        self.setWindowTitle(win_title)
        self.setStyleSheet(_STYLE)
        self.setMinimumSize(520, 420)
        self.resize(560, 460)

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 22, 24, 20)
        root.setSpacing(12)

        self.title_label = QLabel(heading_text)
        self.title_label.setObjectName("title")
        root.addWidget(self.title_label)
        self.subtitle_label = QLabel(subtitle_text)
        self.subtitle_label.setObjectName("muted")
        self.subtitle_label.setWordWrap(True)
        root.addWidget(self.subtitle_label)

        self.notes = QTextEdit()
        self.notes.setReadOnly(True)
        self.notes.setMarkdown(info.notes or "_Không có ghi chú cho bản này._")
        root.addWidget(self.notes, 1)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        root.addWidget(self.progress)
        self.status = QLabel("")
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)
        self.status.setVisible(False)
        root.addWidget(self.status)

        self.skip_cb = QCheckBox("Bỏ qua phiên bản này")
        root.addWidget(self.skip_cb)

        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        buttons.addStretch()
        self.later_btn = QPushButton("Để sau")
        self.later_btn.clicked.connect(self._on_later)
        buttons.addWidget(self.later_btn)
        self.update_btn = QPushButton(primary_text)
        self.update_btn.setObjectName("primary")
        self.update_btn.setDefault(True)
        self.update_btn.clicked.connect(self._start_download)
        buttons.addWidget(self.update_btn)
        root.addLayout(buttons)

    # ── actions ──

    def _on_later(self):
        if self._worker is not None:
            self._worker.cancel()
        self.skip_requested = self.skip_cb.isChecked()
        self.reject()

    def _start_download(self):
        self.update_btn.setEnabled(False)
        self.skip_cb.setEnabled(False)
        self.progress.setRange(0, 0)
        self.progress.setVisible(True)
        self.status.setText("Đang tải bản cập nhật...")
        self.status.setVisible(True)

        self._thread = QThread(self)
        self._worker = _DownloadWorker(channel=self.info.channel)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self._on_progress)
        self._worker.done.connect(self._on_downloaded)
        self._worker.failed.connect(self._on_failed)
        for sig in (self._worker.done, self._worker.failed):
            sig.connect(self._thread.quit)
        self._thread.start()

    def _on_progress(self, done: int, total: int):
        if total > 0:
            self.progress.setRange(0, total)
            self.progress.setValue(done)
            self.progress.setFormat(f"{done / 1_048_576:.1f} / {total / 1_048_576:.1f} MB")
        else:
            self.status.setText(f"Đang tải... {done / 1_048_576:.1f} MB")

    def _on_downloaded(self, path: str):
        self.downloaded_path = path
        self.status.setText("Đã tải xong." if self._can_install else f"Đã tải xong, file nằm ở: {path}")
        self.accept()

    def _on_failed(self, reason: str):
        if not reason:   # cancelled
            return
        self.status.setText(f"Không tải được bản cập nhật: {reason}")
        self.update_btn.setText("Thử lại")
        self.update_btn.setEnabled(True)
        self.skip_cb.setEnabled(True)
        self.progress.setVisible(False)

    def showEvent(self, event):
        super().showEvent(event)
        if self.parentWidget() is None:
            screen = QGuiApplication.primaryScreen()
            if screen is not None:
                avail = screen.availableGeometry()
                self.move(
                    avail.x() + (avail.width() - self.width()) // 2,
                    avail.y() + (avail.height() - self.height()) // 2,
                )
            self.setWindowState(
                (self.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive
            )
            self.raise_()
            self.activateWindow()
            QApplication.alert(self, 0)

    def reject(self):
        if self._worker is not None and not self.downloaded_path:
            self._worker.cancel()
        if self._thread is not None:
            self._thread.quit()
            self._thread.wait(2000)
        super().reject()

    def done(self, result):
        if self._thread is not None and self._thread.isRunning():
            self._thread.quit()
            self._thread.wait(2000)
        super().done(result)
