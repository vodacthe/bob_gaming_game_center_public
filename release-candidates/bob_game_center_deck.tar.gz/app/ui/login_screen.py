"""
Login dialog for Bob Gaming Game Center.
Provides cloud provider selection and credentials input.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLineEdit,
    QPushButton, QLabel, QCheckBox, QWidget, QStackedWidget,
    QRadioButton, QButtonGroup, QFrame,
)
from PySide6.QtCore import Qt, Signal, QThread
from PySide6.QtGui import QFont

from app.config import (
    load_config, save_config, encode_password, decode_password,
    PROVIDER_NEXTCLOUD, PROVIDER_GOOGLE_DRIVE,
)
from app.core.nextcloud_client import NextcloudClient
from app.ui.icons import make_svg_icon, make_svg_pixmap


class ConnectionTestThread(QThread):
    """Background thread for testing Nextcloud connection."""
    result = Signal(bool, str)  # success, message

    def __init__(self, cloud_url: str, username: str, password: str):
        super().__init__()
        self.cloud_url = cloud_url
        self.username = username
        self.password = password

    def run(self):
        try:
            client = NextcloudClient(self.cloud_url, self.username, self.password)
            if client.test_connection():
                self.result.emit(True, "Kết nối Nextcloud thành công!")
            else:
                self.result.emit(False, "Kết nối thất bại. Vui lòng kiểm tra lại thông tin.")
        except Exception as e:
            self.result.emit(False, f"Lỗi kết nối: {str(e)}")


class GoogleAuthThread(QThread):
    """Background thread for Google Drive OAuth2 flow."""
    result = Signal(bool, str)  # success, message

    def run(self):
        try:
            from app.core.google_drive_client import GoogleDriveClient
            client = GoogleDriveClient()
            if client.authenticate():
                if client.test_connection():
                    self.result.emit(True, "Kết nối Google Drive thành công!")
                else:
                    self.result.emit(False, "Xác thực thành công nhưng kiểm tra kết nối thất bại.")
            else:
                self.result.emit(False, "Xác thực Google Drive thất bại.")
        except Exception as e:
            self.result.emit(False, f"Lỗi xác thực: {str(e)}")


class LoginDialog(QDialog):
    """Login dialog with cloud provider selection."""

    login_successful = Signal(dict)  # Emits config dict on success

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Kết nối Cloud")
        self.setFixedSize(480, 560)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)
        self._test_thread = None
        self._login_success = False
        self._setup_ui()
        self._load_saved_config()

    def _setup_ui(self):
        """Set up the login dialog UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 24, 32, 24)
        layout.setSpacing(6)

        # App icon
        icon_label = QLabel()
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_label.setPixmap(make_svg_pixmap("gamepad", 36, "#a855f7"))
        icon_label.setStyleSheet("background: transparent;")

        # Title
        title = QLabel("Kết nối Cloud")
        title.setObjectName("titleLabel")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Subtitle
        subtitle = QLabel("Chọn dịch vụ đám mây để lưu trữ và đồng bộ dữ liệu game")
        subtitle.setObjectName("subtitleLabel")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # ── Provider Selector ──
        provider_frame = QFrame()
        provider_frame.setObjectName("loginProviderFrame")
        provider_frame.setStyleSheet("""
            #loginProviderFrame {
                background-color: #121620;
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 8px;
                padding: 6px;
            }
            #loginProviderFrame QLabel {
                border: none;
                background: transparent;
            }
        """)
        provider_layout = QHBoxLayout(provider_frame)
        provider_layout.setContentsMargins(8, 4, 8, 4)
        provider_layout.setSpacing(12)

        self.provider_group = QButtonGroup(self)

        self.nc_radio = QRadioButton("Nextcloud (Máy chủ riêng)")
        self.nc_radio.setStyleSheet("font-size: 13px; font-weight: bold; padding: 6px 4px; color: #e6edf3;")
        self.nc_radio.setChecked(True)

        self.gd_radio = QRadioButton("Google Drive")
        self.gd_radio.setStyleSheet("font-size: 13px; font-weight: bold; padding: 6px 4px; color: #e6edf3;")

        self.provider_group.addButton(self.nc_radio, 0)
        self.provider_group.addButton(self.gd_radio, 1)

        provider_layout.addWidget(self.nc_radio)
        provider_layout.addWidget(self.gd_radio)

        # Separator
        separator = QWidget()
        separator.setObjectName("separator")
        separator.setFixedHeight(1)

        # ── Stacked pages for each provider ──
        self.stacked = QStackedWidget()

        # Page 0: Nextcloud
        nc_page = QWidget()
        nc_layout = QVBoxLayout(nc_page)
        nc_layout.setContentsMargins(0, 0, 0, 0)
        nc_layout.setSpacing(6)

        url_label = QLabel("Địa chỉ máy chủ Nextcloud")
        url_label.setStyleSheet("font-size: 12px; color: #8b949e; background: transparent; border: none;")
        self.cloud_url_input = QLineEdit()
        self.cloud_url_input.setPlaceholderText("https://nextcloud.example.com")
        self.cloud_url_input.setMinimumHeight(40)

        user_label = QLabel("Tên tài khoản")
        user_label.setStyleSheet("font-size: 12px; color: #8b949e; background: transparent;")
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Tên đăng nhập Nextcloud")
        self.username_input.setMinimumHeight(40)

        pass_label = QLabel("Mật khẩu / App Token")
        pass_label.setStyleSheet("font-size: 12px; color: #8b949e; background: transparent;")
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Mật khẩu ứng dụng")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setMinimumHeight(40)

        self.remember_checkbox = QCheckBox("Ghi nhớ thông tin trên máy này")
        self.remember_checkbox.setChecked(True)
        self.remember_checkbox.setStyleSheet("color: #8b949e; font-size: 12px; padding: 4px 0;")

        nc_layout.addWidget(url_label)
        nc_layout.addWidget(self.cloud_url_input)
        nc_layout.addSpacing(4)
        nc_layout.addWidget(user_label)
        nc_layout.addWidget(self.username_input)
        nc_layout.addSpacing(4)
        nc_layout.addWidget(pass_label)
        nc_layout.addWidget(self.password_input)
        nc_layout.addSpacing(4)
        nc_layout.addWidget(self.remember_checkbox)

        # Page 1: Google Drive
        gd_page = QWidget()
        gd_layout = QVBoxLayout(gd_page)
        gd_layout.setContentsMargins(0, 8, 0, 0)
        gd_layout.setSpacing(12)

        gd_info = QLabel(
            "Đăng nhập bằng tài khoản Google của bạn.\n"
            "Cửa sổ trình duyệt web sẽ tự động mở để xác thực an toàn.\n"
            "Bob Gaming chỉ truy cập các tệp do chính ứng dụng tạo ra."
        )
        gd_info.setStyleSheet("font-size: 12px; color: #8b949e; background: transparent; line-height: 1.4;")
        gd_info.setWordWrap(True)
        gd_info.setAlignment(Qt.AlignmentFlag.AlignCenter)

        gd_icon = QLabel()
        gd_icon.setPixmap(make_svg_pixmap("folder", 40, "#a855f7"))
        gd_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        gd_icon.setStyleSheet("background: transparent;")

        gd_layout.addStretch()
        gd_layout.addWidget(gd_icon)
        gd_layout.addWidget(gd_info)
        gd_layout.addStretch()

        self.stacked.addWidget(nc_page)
        self.stacked.addWidget(gd_page)

        # Connect radio to stacked switch
        self.provider_group.idToggled.connect(self._on_provider_changed)

        # Connect button
        self.connect_btn = QPushButton(" Kết nối Nextcloud")
        self.connect_btn.setIcon(make_svg_icon("cloud", 18, "#000000"))
        self.connect_btn.setMinimumHeight(44)
        self.connect_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.connect_btn.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        self.connect_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
                color: #0b0e14;
                border: none;
                border-radius: 8px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #fbbf24, stop:1 #f59e0b);
            }
            QPushButton:disabled {
                background: #2d3748;
                color: #718096;
            }
        """)
        self.connect_btn.clicked.connect(self._on_connect)

        # Status label
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("background: transparent;")

        # Assemble
        layout.addWidget(icon_label)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(6)
        layout.addWidget(provider_frame)
        layout.addSpacing(4)
        layout.addWidget(separator)
        layout.addSpacing(4)
        layout.addWidget(self.stacked)
        layout.addSpacing(8)
        layout.addWidget(self.connect_btn)
        layout.addWidget(self.status_label)

    def _on_provider_changed(self, button_id: int, checked: bool):
        """Switch between provider input pages."""
        if checked:
            self.stacked.setCurrentIndex(button_id)
            if button_id == 0:
                self.connect_btn.setText(" Kết nối Nextcloud")
            else:
                self.connect_btn.setText(" Đăng nhập với Google")

    def _load_saved_config(self):
        """Load saved credentials if available."""
        config = load_config()
        if config.get("cloud_url"):
            self.cloud_url_input.setText(config["cloud_url"])
        if config.get("username"):
            self.username_input.setText(config["username"])
        if config.get("password"):
            self.password_input.setText(decode_password(config["password"]))
        self.remember_checkbox.setChecked(config.get("remember_me", True))

        # Set provider radio
        provider = config.get("cloud_provider", "")
        if provider == PROVIDER_GOOGLE_DRIVE:
            self.gd_radio.setChecked(True)
        else:
            self.nc_radio.setChecked(True)

    def _get_selected_provider(self) -> str:
        """Get the currently selected provider type."""
        if self.gd_radio.isChecked():
            return PROVIDER_GOOGLE_DRIVE
        return PROVIDER_NEXTCLOUD

    def _on_connect(self):
        """Handle connect button click."""
        provider = self._get_selected_provider()

        if provider == PROVIDER_NEXTCLOUD:
            self._connect_nextcloud()
        else:
            self._connect_google_drive()

    def _connect_nextcloud(self):
        """Handle Nextcloud connection."""
        cloud_url = self.cloud_url_input.text().strip()
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()

        if not cloud_url:
            self._show_error("Vui lòng nhập địa chỉ máy chủ Nextcloud")
            return
        if not username:
            self._show_error("Vui lòng nhập tên người dùng")
            return
        if not password:
            self._show_error("Vui lòng nhập mật khẩu hoặc App Token")
            return

        if not cloud_url.startswith("http"):
            cloud_url = f"https://{cloud_url}"
            self.cloud_url_input.setText(cloud_url)

        self.connect_btn.setEnabled(False)
        self.connect_btn.setText(" Đang kết nối...")
        self._show_info("Đang kiểm tra kết nối máy chủ...")

        self._test_thread = ConnectionTestThread(cloud_url, username, password)
        self._test_thread.result.connect(self._on_nc_connection_result)
        self._test_thread.start()

    def _on_nc_connection_result(self, success: bool, message: str):
        """Handle Nextcloud connection test result."""
        self.connect_btn.setEnabled(True)
        self.connect_btn.setText(" Kết nối Nextcloud")

        if success:
            self._show_success(message)
            self._login_success = True

            config = load_config()
            config["cloud_provider"] = PROVIDER_NEXTCLOUD
            config["cloud_url"] = self.cloud_url_input.text().strip()
            config["username"] = self.username_input.text().strip()
            config["password"] = encode_password(self.password_input.text().strip())
            config["remember_me"] = self.remember_checkbox.isChecked()

            if self.remember_checkbox.isChecked():
                save_config(config)

            self.login_successful.emit(config)
            self.accept()
        else:
            self._show_error(message)

    def _connect_google_drive(self):
        """Handle Google Drive connection via OAuth2."""
        self.connect_btn.setEnabled(False)
        self.connect_btn.setText(" Đang chờ cấp quyền Google...")
        self._show_info("Cửa sổ trình duyệt web đang mở. Vui lòng đăng nhập Google.")

        self._test_thread = GoogleAuthThread()
        self._test_thread.result.connect(self._on_gd_connection_result)
        self._test_thread.start()

    def _on_gd_connection_result(self, success: bool, message: str):
        """Handle Google Drive auth result."""
        self.connect_btn.setEnabled(True)
        self.connect_btn.setText(" Đăng nhập với Google")

        if success:
            self._show_success(message)
            self._login_success = True

            config = load_config()
            config["cloud_provider"] = PROVIDER_GOOGLE_DRIVE
            if config.get("cloud_url") == "https://drive.vdthe.com":
                config["cloud_url"] = ""

            save_config(config)
            self.login_successful.emit(config)
            self.accept()
        else:
            self._show_error(message)

    def was_successful(self) -> bool:
        """Check if login was successful."""
        return self._login_success

    def _show_error(self, message: str):
        self.status_label.setStyleSheet("color: #ff4757; font-size: 12px; background: transparent;")
        self.status_label.setText(f"● {message}")

    def _show_success(self, message: str):
        self.status_label.setStyleSheet("color: #2ed573; font-size: 12px; background: transparent;")
        self.status_label.setText(f"● {message}")

    def _show_info(self, message: str):
        self.status_label.setStyleSheet("color: #8b949e; font-size: 12px; background: transparent;")
        self.status_label.setText(message)
