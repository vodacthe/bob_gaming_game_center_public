"""Gamepad UI navigation: drives every Qt window of the app with a controller.

GamepadMonitor emits `nav_action` names; GamepadNavigator turns them into focus moves and clicks on
whichever app window is active (never while the app is in the background):

    D-pad / left stick   move focus spatially (nearest widget in that direction)
    A                    activate (click button, open combo, type into a text field, toggle a list item)
    B                    back: close popup / dialog, or the window's own `gamepad_button("b")`
    X / Y                secondary / tertiary action of a composite widget (e.g. game card: Play / Menu)
    LB / RB              previous / next tab of a QTabWidget, otherwise previous / next widget in focus order
    Right stick          scroll the scroll area around the focus

Optional protocol for custom widgets:
    gamepad_activate()              makes the widget one focus target; its children are not targeted
    gamepad_secondary() / gamepad_tertiary()   X / Y
    gamepad_hints() -> [(button, label), ...]  shown in the hint bar
Optional protocol for top-level windows:
    gamepad_button(action) -> bool  handle an action first (return True to consume it)
    gamepad_default_focus() -> QWidget | None   where focus lands when nothing is focused
    gamepad_hide_hints = True       do not draw the hint bar on this window
"""

import logging

import shiboken6
from PySide6.QtCore import QEvent, QObject, QPoint, QPointF, QRect, Qt, QTimer
from PySide6.QtGui import QColor, QCursor, QEnterEvent, QFont, QFontMetrics, QKeyEvent, QMouseEvent, QPainter, QPen
from PySide6.QtWidgets import (
    QAbstractButton, QAbstractItemView, QAbstractScrollArea, QAbstractSlider, QAbstractSpinBox, QApplication,
    QComboBox, QDialog, QKeySequenceEdit, QLineEdit, QMenu, QPlainTextEdit, QPushButton, QScrollArea, QTabBar,
    QTabWidget, QTextEdit, QTreeView, QWidget,
)

logger = logging.getLogger(__name__)

DIRECTIONS = ("up", "down", "left", "right")
_TICK_MS = 33
_SCROLL_STEPS = 2   # scrollbar single-steps per right-stick tick

_ARROW_KEYS = {
    "up": Qt.Key.Key_Up, "down": Qt.Key.Key_Down,
    "left": Qt.Key.Key_Left, "right": Qt.Key.Key_Right,
}

# Widgets whose internals (line edit, header/corner buttons, cell editors) are never targets themselves
_OPAQUE_CONTAINERS = (QComboBox, QAbstractSpinBox, QKeySequenceEdit, QAbstractItemView, QTextEdit, QPlainTextEdit)

_HINT_COLORS = {"A": "#22c55e", "B": "#ef4444", "X": "#3b82f6", "Y": "#eab308"}


def _valid(obj) -> bool:
    return obj is not None and shiboken6.isValid(obj)


def _cursor_over(w: QWidget) -> bool:
    # Not underMouse(): our synthetic Enter events set WA_UnderMouse too
    return w.rect().contains(w.mapFromGlobal(QCursor.pos()))


def _global_rect(w: QWidget) -> tuple[int, int, int, int]:
    p = w.mapToGlobal(QPoint(0, 0))
    return p.x(), p.y(), p.x() + w.width(), p.y() + w.height()


# ── Spatial search (same rules as Android's FocusFinder) ──

def _is_candidate_rect(d: str, src, dst) -> bool:
    l, t, r, b = src
    L, T, R, B = dst
    if d == "left":
        return (r > R or l >= R) and l > L
    if d == "right":
        return (l < L or r <= L) and r < R
    if d == "up":
        return (b > B or t >= B) and t > T
    return (t < T or b <= T) and b < B


def _beams_overlap(d: str, src, dst) -> bool:
    if d in ("left", "right"):
        return dst[3] > src[1] and dst[1] < src[3]
    return dst[2] > src[0] and dst[0] < src[2]


def _is_to_direction_of(d: str, src, dst) -> bool:
    return {"left": src[0] >= dst[2], "right": src[2] <= dst[0],
            "up": src[1] >= dst[3], "down": src[3] <= dst[1]}[d]


def _major(d: str, src, dst) -> int:
    v = {"left": src[0] - dst[2], "right": dst[0] - src[2], "up": src[1] - dst[3], "down": dst[1] - src[3]}[d]
    return max(0, v)


def _major_far(d: str, src, dst) -> int:
    v = {"left": src[0] - dst[0], "right": dst[2] - src[2], "up": src[1] - dst[1], "down": dst[3] - src[3]}[d]
    return max(1, v)


def _minor(d: str, src, dst) -> float:
    if d in ("left", "right"):
        return abs((src[1] + src[3]) / 2 - (dst[1] + dst[3]) / 2)
    return abs((src[0] + src[2]) / 2 - (dst[0] + dst[2]) / 2)


def _beam_beats(d: str, src, r1, r2) -> bool:
    """r1 is in the beam and r2 is not, and that should decide the comparison."""
    if _beams_overlap(d, src, r2) or not _beams_overlap(d, src, r1):
        return False
    if not _is_to_direction_of(d, src, r2):
        return True
    if d in ("left", "right"):
        return True
    return _major(d, src, r1) < _major_far(d, src, r2)


def _weighted(d: str, src, dst) -> float:
    ma, mi = _major(d, src, dst), _minor(d, src, dst)
    return 13 * ma * ma + mi * mi


def find_in_direction(d: str, src, candidates: list):
    """Pick the best (item, rect) from candidates for moving from `src` toward `d`. Rects are (l, t, r, b)."""
    best = None
    for item, rect in candidates:
        if not _is_candidate_rect(d, src, rect):
            continue
        if best is None:
            best = (item, rect)
            continue
        br = best[1]
        if _beam_beats(d, src, rect, br):
            best = (item, rect)
        elif _beam_beats(d, src, br, rect):
            continue
        elif _weighted(d, src, rect) < _weighted(d, src, br):
            best = (item, rect)
    return best[0] if best else None


# ── Overlay widgets ──

class _FocusRing(QWidget):
    """Glowing outline drawn over the focused widget (child of its window, ignores the mouse)."""

    PAD = 4

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setObjectName("gamepadFocusRing")
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.rect().adjusted(3, 3, -3, -3)
        radius = min(12.0, r.height() / 2)
        p.setPen(QPen(QColor(168, 85, 247, 70), 6))
        p.drawRoundedRect(r, radius, radius)
        p.setPen(QPen(QColor("#d8b4fe"), 2))
        p.drawRoundedRect(r, radius, radius)
        p.end()


class _HintBar(QWidget):
    """Pill listing the controller buttons that do something for the current focus."""

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setObjectName("gamepadHintBar")
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._items: list[tuple[str, str]] = []
        self._font = QFont("Segoe UI", 9)
        self._btn_font = QFont("Segoe UI", 8, QFont.Weight.Bold)

    def set_items(self, items: list[tuple[str, str]]):
        if items == self._items:
            return
        self._items = list(items)
        fm, bfm = QFontMetrics(self._font), QFontMetrics(self._btn_font)
        width = 16
        for btn, label in self._items:
            width += max(18, bfm.horizontalAdvance(btn) + 10) + 6 + fm.horizontalAdvance(label) + 14
        self.resize(width, 30)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(QColor(168, 85, 247, 90), 1))
        p.setBrush(QColor(10, 12, 19, 225))
        p.drawRoundedRect(self.rect().adjusted(0, 0, -1, -1), 15, 15)
        fm, bfm = QFontMetrics(self._font), QFontMetrics(self._btn_font)
        x = 10
        for btn, label in self._items:
            bw = max(18, bfm.horizontalAdvance(btn) + 10)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(_HINT_COLORS.get(btn, "#475569")))
            p.drawRoundedRect(x, 6, bw, 18, 9, 9)
            p.setPen(QColor("#ffffff") if btn not in ("Y",) else QColor("#111827"))
            p.setFont(self._btn_font)
            p.drawText(QRect(x, 6, bw, 18), Qt.AlignmentFlag.AlignCenter, btn)
            x += bw + 6
            p.setPen(QColor("#e2e8f0"))
            p.setFont(self._font)
            lw = fm.horizontalAdvance(label)
            p.drawText(QRect(x, 0, lw + 2, 30), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, label)
            x += lw + 14
        p.end()


# ── Navigator ──

class GamepadNavigator(QObject):
    """Receives GamepadMonitor.nav_action on the GUI thread and drives focus/clicks in the active window."""

    def __init__(self, monitor=None, parent=None):
        super().__init__(parent)
        self._active = False          # gamepad mode: ring shown, last input came from the controller
        self._current: QWidget | None = None
        self._last_rect = None
        self._ring: _FocusRing | None = None
        self._hint: _HintBar | None = None
        self._cursor_pos = None
        self._ring_target = None
        self._timer = QTimer(self)
        self._timer.setInterval(_TICK_MS)
        self._timer.timeout.connect(self._tick)
        if monitor is not None:
            monitor.nav_action.connect(self.handle_action)
            monitor.set_nav_enabled(True)

    # ── public ──

    @property
    def active(self) -> bool:
        return self._active

    def focus(self, w: QWidget):
        """Move gamepad focus to `w` (also usable by windows' gamepad_button hooks)."""
        if not _valid(w):
            return
        old = self._current
        w.setFocus(Qt.FocusReason.OtherFocusReason)
        self._ensure_visible(w)
        if _valid(old) and old is not w and not _cursor_over(old):
            QApplication.sendEvent(old, QEvent(QEvent.Type.Leave))
        if old is not w:
            c = QPointF(w.width() / 2, w.height() / 2)
            QApplication.sendEvent(w, QEnterEvent(c, c, QPointF(w.mapToGlobal(c.toPoint()))))
        self._current = w
        self._last_rect = _global_rect(w)
        if self._active:
            QTimer.singleShot(0, self._tick)

    def handle_action(self, action: str):
        try:
            self._handle(action)
        except RuntimeError as e:   # a widget died under us (dialog closed mid-action)
            logger.debug(f"[GamepadNav] {action}: {e}")

    # ── dispatch ──

    @staticmethod
    def _active_popup():
        return QApplication.activePopupWidget()

    @staticmethod
    def _active_window():
        return QApplication.activeWindow()

    def _handle(self, action: str):
        popup = self._active_popup()
        window = self._active_window()
        if popup is None and window is None:
            return   # app is in the background: the controller belongs to the game

        entering = not self._active
        self._enter_gamepad_mode()

        if popup is not None:
            self._handle_popup(popup, action)
            return

        hook = getattr(window, "gamepad_button", None)
        if callable(hook) and hook(action):
            return

        focus = self._resolve_focus(window)

        if entering and action in DIRECTIONS + ("a", "x", "y"):
            # First press after mouse use only reveals where the focus is
            if focus is None:
                focus = self._initial_focus(window)
            if focus is not None:
                self.focus(focus)
            return

        if action in DIRECTIONS:
            self._move(window, focus, action)
        elif action == "a":
            if focus is not None:
                self._activate(focus)
        elif action == "b":
            self._send_key(window, Qt.Key.Key_Escape, "\x1b")
        elif action == "x":
            self._call(focus, "gamepad_secondary")
        elif action == "y":
            if not self._call(focus, "gamepad_tertiary") and focus is not None:
                if focus.contextMenuPolicy() == Qt.ContextMenuPolicy.CustomContextMenu:
                    focus.customContextMenuRequested.emit(QPoint(focus.width() // 2, focus.height() // 2))
        elif action in ("lb", "rb"):
            self._cycle(window, focus, -1 if action == "lb" else 1)
        elif action in ("scroll_up", "scroll_down"):
            self._scroll(window, focus, -1 if action == "scroll_up" else 1)

    def _handle_popup(self, popup: QWidget, action: str):
        key = {"a": (Qt.Key.Key_Return, "\r"), "b": (Qt.Key.Key_Escape, "\x1b")}.get(action)
        if action in _ARROW_KEYS:
            key = (_ARROW_KEYS[action], "")
        if key is None:
            return
        target = popup
        if not isinstance(popup, QMenu):
            target = popup.findChild(QAbstractItemView) or popup   # QComboBox's popup list
        self._send_key(target, *key)

    @staticmethod
    def _call(w, name: str) -> bool:
        fn = getattr(w, name, None) if w is not None else None
        if callable(fn):
            fn()
            return True
        return False

    @staticmethod
    def _send_key(target: QWidget, key, text: str = ""):
        for t in (QEvent.Type.KeyPress, QEvent.Type.KeyRelease):
            QApplication.sendEvent(target, QKeyEvent(t, key, Qt.KeyboardModifier.NoModifier, text))

    # ── focus targets ──

    @staticmethod
    def _composite_of(w: QWidget, window: QWidget):
        """Outermost ancestor-or-self implementing gamepad_activate, else None."""
        found = None
        p = w
        while p is not None:
            if hasattr(p, "gamepad_activate"):
                found = p
            if p is window or p.isWindow():
                break
            p = p.parentWidget()
        return found

    def _is_candidate(self, w: QWidget, window: QWidget) -> bool:
        if isinstance(w, (_FocusRing, _HintBar, QScrollArea, QTabWidget)):
            return False
        if not w.isVisible() or not w.isEnabled() or w.width() <= 1 or w.height() <= 1:
            return False
        if not (w.focusPolicy().value & Qt.FocusPolicy.TabFocus.value):
            return False
        if w.focusProxy() is not None or w.window() is not window:
            return False
        p = w.parentWidget()
        while p is not None and p is not window:
            if hasattr(p, "gamepad_activate") or isinstance(p, _OPAQUE_CONTAINERS):
                return False
            p = p.parentWidget()
        return True

    def _candidates(self, window: QWidget) -> list[QWidget]:
        cands = [w for w in window.findChildren(QWidget) if self._is_candidate(w, window)]
        # Containers that hold other targets (e.g. a screen with StrongFocus) are not targets themselves
        ids = {id(w) for w in cands}
        containers = set()
        for w in cands:
            p = w.parentWidget()
            while p is not None and p is not window:
                if id(p) in ids:
                    containers.add(id(p))
                p = p.parentWidget()
        return [w for w in cands if id(w) not in containers]

    def _resolve_focus(self, window: QWidget):
        fw = window.focusWidget()
        if _valid(fw) and fw.isVisible():
            comp = self._composite_of(fw, window)
            if comp is not None:
                return comp
            if self._is_candidate(fw, window) and not self._has_candidate_children(fw, window):
                return fw
        cur = self._current
        if _valid(cur) and cur.window() is window and self._is_candidate(cur, window):
            return cur
        return None

    def _has_candidate_children(self, w: QWidget, window: QWidget) -> bool:
        return any(self._is_candidate(c, window) for c in w.findChildren(QWidget))

    def _initial_focus(self, window: QWidget):
        hook = getattr(window, "gamepad_default_focus", None)
        if callable(hook):
            w = hook()
            if _valid(w) and self._is_candidate(w, window):
                return w
        cands = self._candidates(window)
        if not cands:
            return None
        if self._last_rect is not None:
            cx = (self._last_rect[0] + self._last_rect[2]) / 2
            cy = (self._last_rect[1] + self._last_rect[3]) / 2

            def dist(w):
                r = _global_rect(w)
                return ((r[0] + r[2]) / 2 - cx) ** 2 + ((r[1] + r[3]) / 2 - cy) ** 2
            return min(cands, key=dist)
        for w in cands:
            if isinstance(w, QPushButton) and w.isDefault():
                return w
        return min(cands, key=lambda w: (lambda r: (r[1] + r[0], r[1]))(_global_rect(w)))

    # ── actions ──

    def _move(self, window: QWidget, focus, d: str):
        if focus is not None and self._move_inside(focus, d):
            return
        if focus is None:
            target = self._initial_focus(window)
        else:
            cands = [(w, _global_rect(w)) for w in self._candidates(window) if w is not focus]
            target = find_in_direction(d, _global_rect(focus), cands)
        if target is not None:
            self.focus(target)

    def _move_inside(self, w: QWidget, d: str) -> bool:
        """Directions that adjust the focused widget itself; False lets focus leave it."""
        if isinstance(w, QAbstractItemView):
            def state():
                idx = w.currentIndex()
                expanded = w.isExpanded(idx) if isinstance(w, QTreeView) and idx.isValid() else None
                return (idx.row(), idx.column(), idx.internalId(), expanded,
                        w.horizontalScrollBar().value(), w.verticalScrollBar().value())
            before = state()
            self._send_key(w, _ARROW_KEYS[d])
            return state() != before
        if isinstance(w, QTabBar) and d in ("left", "right"):
            step = -1 if d == "left" else 1
            i = w.currentIndex() + step
            while 0 <= i < w.count() and not w.isTabEnabled(i):
                i += step
            if 0 <= i < w.count():
                w.setCurrentIndex(i)
                return True
            return False
        if isinstance(w, QAbstractSlider) and w.orientation() == Qt.Orientation.Horizontal and d in ("left", "right"):
            before = w.value()
            step = max(w.singleStep(), (w.maximum() - w.minimum()) // 30)
            w.setValue(before + (step if d == "right" else -step))
            return w.value() != before
        if isinstance(w, QAbstractSpinBox) and d in ("left", "right"):
            before = w.text()
            w.stepBy(1 if d == "right" else -1)
            return w.text() != before
        return False

    def _activate(self, w: QWidget):
        if self._call(w, "gamepad_activate"):
            return
        if isinstance(w, QAbstractButton):
            w.animateClick()
        elif isinstance(w, QComboBox):
            w.showPopup()
        elif isinstance(w, QLineEdit):
            if not w.isReadOnly():
                self._edit_text(w)
        elif isinstance(w, (QPlainTextEdit, QTextEdit)):
            if not w.isReadOnly():
                self._edit_text(w)
        elif isinstance(w, QAbstractItemView):
            self._activate_item(w)
        elif isinstance(w, (QTabBar, QAbstractSlider, QAbstractSpinBox, QKeySequenceEdit)):
            pass
        else:
            c = QPointF(w.width() / 2, w.height() / 2)
            g = QPointF(w.mapToGlobal(c.toPoint()))
            for t, buttons in ((QEvent.Type.MouseButtonPress, Qt.MouseButton.LeftButton),
                               (QEvent.Type.MouseButtonRelease, Qt.MouseButton.NoButton)):
                QApplication.sendEvent(w, QMouseEvent(t, c, g, Qt.MouseButton.LeftButton, buttons,
                                                      Qt.KeyboardModifier.NoModifier))

    def _activate_item(self, view: QAbstractItemView):
        idx = view.currentIndex()
        if not idx.isValid():
            self._send_key(view, Qt.Key.Key_Down)
            return
        model = view.model()
        row_cells = [idx] + [idx.siblingAtColumn(c) for c in range(model.columnCount(idx.parent())) if c != idx.column()]
        for cell in row_cells:
            # QTableWidgetItem is UserCheckable by default: only cells that actually show a checkbox count
            state = cell.data(Qt.ItemDataRole.CheckStateRole) if cell.isValid() else None
            if state is not None and cell.flags() & Qt.ItemFlag.ItemIsUserCheckable and cell.flags() & Qt.ItemFlag.ItemIsEnabled:
                checked = state in (Qt.CheckState.Checked, Qt.CheckState.Checked.value)
                new = Qt.CheckState.Unchecked if checked else Qt.CheckState.Checked
                model.setData(cell, new.value, Qt.ItemDataRole.CheckStateRole)
                return
        if isinstance(view, QTreeView) and model.hasChildren(idx):
            view.setExpanded(idx, not view.isExpanded(idx))
            return
        self._send_key(view, Qt.Key.Key_Return, "\r")   # emits `activated` (e.g. QFileDialog opens the entry)

    def _edit_text(self, w: QWidget):
        from app.ui.virtual_keyboard import edit_with_virtual_keyboard
        edit_with_virtual_keyboard(w)

    def _cycle(self, window: QWidget, focus, step: int):
        p = focus
        while p is not None and not isinstance(p, QTabWidget):
            p = p.parentWidget() if p is not window else None
        if isinstance(p, QTabWidget) and p.count() > 1:
            i = (p.currentIndex() + step) % p.count()
            while not p.isTabEnabled(i) and i != p.currentIndex():
                i = (i + step) % p.count()
            p.setCurrentIndex(i)
            self.focus(p.tabBar())
            return
        start = focus or window
        w = start
        for _ in range(500):
            w = w.nextInFocusChain() if step > 0 else w.previousInFocusChain()
            if w is None or w is start:
                return
            comp = self._composite_of(w, window)
            if comp is not None and comp is not focus and self._is_candidate(comp, window):
                self.focus(comp)
                return
            if comp is None and self._is_candidate(w, window) and not self._has_candidate_children(w, window):
                self.focus(w)
                return

    def _scroll(self, window: QWidget, focus, direction: int):
        area = None
        p = focus
        while p is not None:
            if isinstance(p, QAbstractScrollArea) and p.verticalScrollBar().maximum() > 0:
                area = p
                break
            p = p.parentWidget() if p is not window else None
        if area is None:
            areas = [a for a in window.findChildren(QAbstractScrollArea)
                     if a.isVisible() and a.verticalScrollBar().maximum() > 0]
            if not areas:
                return
            area = max(areas, key=lambda a: a.width() * a.height())
        sb = area.verticalScrollBar()
        sb.setValue(sb.value() + direction * max(1, sb.singleStep()) * _SCROLL_STEPS)

    @staticmethod
    def _ensure_visible(w: QWidget):
        p = w.parentWidget()
        while p is not None and not p.isWindow():
            if isinstance(p, QScrollArea) and p.widget() is not None:
                p.ensureWidgetVisible(w, 24, 24)
            p = p.parentWidget()

    # ── gamepad mode / overlay ──

    def _enter_gamepad_mode(self):
        self._cursor_pos = QCursor.pos()
        if self._active:
            return
        self._active = True
        # Native Windows file pickers cannot be driven by the controller; use Qt's own while in gamepad mode
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeDialogs, True)
        self._timer.start()

    def _exit_gamepad_mode(self):
        if not self._active:
            return
        self._active = False
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeDialogs, False)
        self._timer.stop()
        self._hide_overlay()
        cur = self._current
        if _valid(cur) and not _cursor_over(cur):
            QApplication.sendEvent(cur, QEvent(QEvent.Type.Leave))

    def _hide_overlay(self):
        for w in (self._ring, self._hint):
            if _valid(w):
                w.hide()
        self._ring_target = None

    def _tick(self):
        if not self._active:
            return
        if QCursor.pos() != self._cursor_pos:
            self._exit_gamepad_mode()
            return
        window = self._active_window()
        if window is None or self._active_popup() is not None:
            self._hide_overlay()
            return
        target = self._resolve_focus(window)
        if target is None:
            self._hide_overlay()
            return
        # intersected(): a QGraphicsEffect (card drop shadow) inflates visibleRegion beyond the widget
        vis = target.visibleRegion().boundingRect().intersected(target.rect())
        if vis.isEmpty():
            self._hide_overlay()
            return

        if not _valid(self._ring) or self._ring.parentWidget() is not window:
            for w in (self._ring, self._hint):
                if _valid(w):
                    w.deleteLater()
            self._ring = _FocusRing(window)
            self._hint = _HintBar(window)

        pad = _FocusRing.PAD
        top_left = target.mapTo(window, vis.topLeft())
        geo = QRect(top_left, vis.size()).adjusted(-pad, -pad, pad, pad)
        if self._ring.geometry() != geo:
            self._ring.setGeometry(geo)
        self._ring.show()
        self._ring.raise_()

        if getattr(window, "gamepad_hide_hints", False):
            self._hint.hide()
        else:
            if target is not self._ring_target:
                self._hint.set_items(self._hints_for(target, window))
            self._place_hint(window, geo)
            self._hint.show()
            self._hint.raise_()
        self._ring_target = target

    def _place_hint(self, window: QWidget, ring_geo: QRect):
        m = 14
        hw, hh = self._hint.width(), self._hint.height()
        spots = (QPoint(window.width() - hw - m, window.height() - hh - m),
                 QPoint(m, window.height() - hh - m),
                 QPoint((window.width() - hw) // 2, m + 24))
        for pos in spots:
            if not QRect(pos, self._hint.size()).intersects(ring_geo):
                break
        if self._hint.pos() != pos:
            self._hint.move(pos)

    def _hints_for(self, w: QWidget, window: QWidget) -> list[tuple[str, str]]:
        custom = getattr(w, "gamepad_hints", None)
        if callable(custom):
            items = list(custom())
        elif isinstance(w, QComboBox):
            items = [("A", "Mở danh sách")]
        elif isinstance(w, (QLineEdit, QPlainTextEdit, QTextEdit)):
            items = [] if w.isReadOnly() else [("A", "Nhập chữ")]
        elif isinstance(w, (QAbstractSlider, QAbstractSpinBox)):
            items = [("◀▶", "Điều chỉnh")]
        elif isinstance(w, QTabBar):
            items = [("◀▶", "Đổi tab")]
        elif isinstance(w, QAbstractItemView):
            items = [("A", "Chọn")]
        elif isinstance(w, QKeySequenceEdit):
            items = []
        else:
            items = [("A", "Chọn")]
        items.append(("B", "Quay lại" if not isinstance(window, QDialog) else "Đóng"))
        return items
