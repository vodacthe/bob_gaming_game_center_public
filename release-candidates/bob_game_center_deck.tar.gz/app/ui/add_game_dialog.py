"""
Add Game Dialog for Bob Gaming Game Center.
Allows users to add a game with its name, executable (.exe), and save folder.
"""

import os
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QFileDialog, QMessageBox,
    QWidget
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

from app.ui.icons import make_svg_icon, make_svg_pixmap


class AddGameDialog(QDialog):
    """Dialog for adding a custom game with .exe selection and save folder."""

    game_added = Signal(dict)  # Emits game data dict

    def __init__(self, existing_names=None, parent=None):
        super().__init__(parent)
        self.existing_names = set(existing_names or [])
        self.setWindowTitle("Thêm trò chơi mới")
        self.setFixedSize(540, 390)
        self.setStyleSheet("""
            QDialog {
                background-color: #0b0e14;
                border: 1px solid rgba(212, 175, 55, 0.35);
                border-radius: 12px;
            }
            QLabel {
                color: #e6edf3;
                font-size: 13px;
            }
            QLineEdit {
                background-color: #121620;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 8px;
                padding: 8px 12px;
                color: #ffffff;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #a855f7;
            }
        """)

        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 24, 26, 24)
        layout.setSpacing(14)

        # Header
        header_row = QHBoxLayout()
        icon_lbl = QLabel()
        icon_lbl.setPixmap(make_svg_pixmap("plus", 20, "#a855f7"))
        title = QLabel("Thêm trò chơi mới")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        title.setStyleSheet("color: #ffffff;")
        header_row.addWidget(icon_lbl)
        header_row.addWidget(title)
        header_row.addStretch()
        layout.addLayout(header_row)

        desc = QLabel("Cấu hình thông tin game, đường dẫn thực thi (.exe) để tự động đồng bộ khi thoát và thư mục lưu game.")
        desc.setStyleSheet("color: #8b949e; font-size: 12px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # 1. Game Name
        name_label = QLabel("Tên trò chơi *")
        name_label.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        layout.addWidget(name_label)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Ví dụ: Black Myth: Wukong")
        layout.addWidget(self.name_input)

        # 2. Executable (.exe) Selection
        exe_label = QLabel("File thực thi game (.exe) — Tự động đồng bộ khi thoát")
        exe_label.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        layout.addWidget(exe_label)

        exe_row = QHBoxLayout()
        exe_row.setSpacing(8)
        self.exe_input = QLineEdit()
        self.exe_input.setPlaceholderText("Tùy chọn: Chọn file .exe của trò chơi")
        exe_row.addWidget(self.exe_input)

        exe_browse_btn = QPushButton(" Duyệt...")
        exe_browse_btn.setIcon(make_svg_icon("folder", 16, "#a855f7"))
        exe_browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        exe_browse_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.06);
                color: #e6edf3;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 8px;
                padding: 8px 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: #a855f7;
            }
        """)
        exe_browse_btn.clicked.connect(self._on_browse_exe)
        exe_row.addWidget(exe_browse_btn)
        layout.addLayout(exe_row)

        # 3. Save Folder Selection
        save_label = QLabel("Đường dẫn thư mục lưu game (Save Folder)")
        save_label.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        layout.addWidget(save_label)

        save_row = QHBoxLayout()
        save_row.setSpacing(8)
        self.save_input = QLineEdit()
        self.save_input.setPlaceholderText("Tùy chọn: Chọn thư mục lưu ngay hoặc cấu hình sau")
        save_row.addWidget(self.save_input)

        save_browse_btn = QPushButton(" Duyệt...")
        save_browse_btn.setIcon(make_svg_icon("folder", 16, "#a855f7"))
        save_browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        save_browse_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.06);
                color: #e6edf3;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 8px;
                padding: 8px 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: #a855f7;
            }
        """)
        save_browse_btn.clicked.connect(self._on_browse_save)
        save_row.addWidget(save_browse_btn)
        layout.addLayout(save_row)

        layout.addStretch()

        # Action Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)
        btn_row.addStretch()

        cancel_btn = QPushButton("Hủy bỏ")
        cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #8b949e;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 8px;
                padding: 8px 18px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.06);
                color: white;
            }
        """)
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)

        add_btn = QPushButton(" Thêm trò chơi")
        add_btn.setIcon(make_svg_icon("plus", 16, "#000000"))
        add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        add_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
                color: #0b0e14;
                border: none;
                border-radius: 8px;
                padding: 8px 22px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #fbbf24, stop:1 #f59e0b);
            }
        """)
        add_btn.clicked.connect(self._on_submit)
        btn_row.addWidget(add_btn)

        layout.addLayout(btn_row)

    def _on_browse_exe(self):
        """Pick an executable file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Chọn file thực thi (.exe)",
            "",
            "Tệp thực thi (*.exe);;Tất cả tệp (*.*)"
        )
        if file_path:
            file_path = os.path.abspath(file_path).replace("\\", "/")
            self.exe_input.setText(file_path)

            # Auto-suggest name if name input is blank
            if not self.name_input.text().strip():
                base_name = os.path.splitext(os.path.basename(file_path))[0]
                if base_name.lower() in ("game", "launcher", "start", "shipping", "app") or base_name.endswith("-Win64-Shipping"):
                    parent_dir = os.path.basename(os.path.dirname(file_path))
                    self.name_input.setText(parent_dir)
                else:
                    self.name_input.setText(base_name)

    def _on_browse_save(self):
        """Pick a save directory."""
        dir_path = QFileDialog.getExistingDirectory(
            self,
            "Chọn thư mục lưu game",
            os.environ.get("APPDATA", os.path.expanduser("~")),
            QFileDialog.Option.ShowDirsOnly
        )
        if dir_path:
            dir_path = os.path.abspath(dir_path).replace("\\", "/")
            self.save_input.setText(dir_path)

    def _on_submit(self):
        """Validate and emit game data."""
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Thông báo", "Vui lòng nhập tên trò chơi.")
            return

        if name in self.existing_names:
            QMessageBox.warning(self, "Trùng lặp", f'Trò chơi \"{name}\" đã có trong thư viện.')
            return

        exe_path = self.exe_input.text().strip()
        save_path = self.save_input.text().strip()

        data = {
            "name": name,
            "exe_path": exe_path,
            "save_path": save_path,
        }
        self.game_added.emit(data)
        self.accept()
