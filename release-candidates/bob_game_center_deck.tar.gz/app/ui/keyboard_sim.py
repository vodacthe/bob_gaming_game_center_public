"""Simulate keyboard shortcuts using Windows SendInput API with hardware scan codes.

Works globally across desktop applications and DirectX/Unreal/Unity games
running in borderless or fullscreen mode.
"""

import ctypes
from ctypes import wintypes
import logging
import sys
import time

logger = logging.getLogger(__name__)
TAG = "[KeyboardSim]"

is_windows = sys.platform == "win32" and hasattr(ctypes, "windll")

# Win32 Constants
INPUT_KEYBOARD = 1
KEYEVENTF_KEYDOWN = 0x0000
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008

# Virtual key codes
VK_MAP = {
    "ctrl": 0x11, "alt": 0x12, "shift": 0x10, "win": 0x5B, "lwin": 0x5B, "rwin": 0x5C,
    "a": 0x41, "b": 0x42, "c": 0x43, "d": 0x44, "e": 0x45,
    "f": 0x46, "g": 0x47, "h": 0x48, "i": 0x49, "j": 0x4A,
    "k": 0x4B, "l": 0x4C, "m": 0x4D, "n": 0x4E, "o": 0x4F,
    "p": 0x50, "q": 0x51, "r": 0x52, "s": 0x53, "t": 0x54,
    "u": 0x55, "v": 0x56, "w": 0x57, "x": 0x58, "y": 0x59,
    "z": 0x5A,
    "0": 0x30, "1": 0x31, "2": 0x32, "3": 0x33, "4": 0x34,
    "5": 0x35, "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39,
    "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73,
    "f5": 0x74, "f6": 0x75, "f7": 0x76, "f8": 0x77,
    "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
    "space": 0x20, "enter": 0x0D, "tab": 0x09, "esc": 0x1B,
    "backspace": 0x08, "delete": 0x2E, "insert": 0x2D,
    "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
    "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27,
    "printscreen": 0x2C, "prtscn": 0x2C, "pause": 0x13, "numlock": 0x90,
}

# Extended keys that require KEYEVENTF_EXTENDEDKEY (0xE0 prefix in PS/2 scan codes)
EXTENDED_VKS = {
    0x21, 0x22, 0x23, 0x24,  # pageup, pagedown, end, home
    0x25, 0x26, 0x27, 0x28,  # left, up, right, down
    0x2C, 0x2D, 0x2E,        # printscreen, insert, delete
    0x5B, 0x5C,              # lwin, rwin
    0x90,                    # numlock
}

# Explicit DirectInput / PS/2 Set 1 hardware scan codes for all supported keys
SCAN_CODE_MAP = {
    "esc": 0x01,
    "1": 0x02, "2": 0x03, "3": 0x04, "4": 0x05, "5": 0x06,
    "6": 0x07, "7": 0x08, "8": 0x09, "9": 0x0A, "0": 0x0B,
    "backspace": 0x0E, "tab": 0x0F,
    "q": 0x10, "w": 0x11, "e": 0x12, "r": 0x13, "t": 0x14,
    "y": 0x15, "u": 0x16, "i": 0x17, "o": 0x18, "p": 0x19,
    "enter": 0x1C,
    "ctrl": 0x1D,
    "win": 0x5B, "lwin": 0x5B, "rwin": 0x5C,
    "a": 0x1E, "s": 0x1F, "d": 0x20, "f": 0x21, "g": 0x22,
    "h": 0x23, "j": 0x24, "k": 0x25, "l": 0x26,
    "shift": 0x2A,
    "z": 0x2C, "x": 0x2D, "c": 0x2E, "v": 0x2F, "b": 0x30,
    "n": 0x31, "m": 0x32,
    "alt": 0x38,
    "space": 0x39,
    "f1": 0x3B, "f2": 0x3C, "f3": 0x3D, "f4": 0x3E, "f5": 0x3F,
    "f6": 0x40, "f7": 0x41, "f8": 0x42, "f9": 0x43, "f10": 0x44,
    "numlock": 0x45,
    "home": 0x47, "up": 0x48, "pageup": 0x49,
    "left": 0x4B, "right": 0x4D,
    "end": 0x4F, "down": 0x50, "pagedown": 0x51,
    "insert": 0x52, "delete": 0x53,
    "f11": 0x57, "f12": 0x58,
    "printscreen": 0x54, "prtscn": 0x54, "pause": 0xC5,
}

# --- Ctypes Win32 Struct Definitions for SendInput ---
class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ("uMsg", wintypes.DWORD),
        ("wParamL", wintypes.WORD),
        ("wParamH", wintypes.WORD),
    ]


class _INPUT_UNION(ctypes.Union):
    _fields_ = [
        ("mi", MOUSEINPUT),
        ("ki", KEYBDINPUT),
        ("hi", HARDWAREINPUT),
    ]


class INPUT(ctypes.Structure):
    _fields_ = [
        ("type", wintypes.DWORD),
        ("u", _INPUT_UNION),
    ]


LPINPUT = ctypes.POINTER(INPUT)
if sys.platform == "win32":
    try:
        _user32 = ctypes.windll.user32
        _user32.SendInput.argtypes = [wintypes.UINT, LPINPUT, ctypes.c_int]
        _user32.SendInput.restype = wintypes.UINT
    except Exception:
        _user32 = None
else:
    _user32 = None


def _ensure_desktop_access():
    """Ensure current thread is attached to the active input desktop."""
    if not _user32:
        return
    try:
        desk = _user32.OpenInputDesktop(0, False, 0x01FF)
        if desk:
            _user32.SetThreadDesktop(desk)
            _user32.CloseDesktop(desk)
    except Exception:
        pass


def _get_scan_code(key_name: str, vk: int) -> int:
    """Get hardware scan code for key."""
    if key_name in SCAN_CODE_MAP:
        return SCAN_CODE_MAP[key_name]
    if not _user32:
        return 0
    try:
        sc = _user32.MapVirtualKeyW(vk, 0)
        return sc if sc else 0
    except Exception:
        return 0


def _send_key_event(vk: int, sc: int, down: bool):
    """Send a single key press or release event using SendInput with scan code."""
    if not _user32:
        logger.debug(f"{TAG} _user32 unavailable, skipping key event vk=0x{vk:02X}")
        return

    flags = KEYEVENTF_SCANCODE
    if not down:
        flags |= KEYEVENTF_KEYUP
    if vk in EXTENDED_VKS:
        flags |= KEYEVENTF_EXTENDEDKEY

    inp = INPUT(type=INPUT_KEYBOARD)
    inp.u.ki = KEYBDINPUT(wVk=vk, wScan=sc, dwFlags=flags, time=0, dwExtraInfo=0)

    _ensure_desktop_access()
    res = _user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))

    # If SendInput fails (res == 0) or for system hotkey key VK_SNAPSHOT (0x2C), also invoke keybd_event
    if res == 0 or vk == 0x2C:
        kb_flags = (0 if down else KEYEVENTF_KEYUP) | (KEYEVENTF_EXTENDEDKEY if vk in EXTENDED_VKS else 0)
        _user32.keybd_event(vk, sc, kb_flags, 0)


def send_key_combo(keys: list[str]):
    """Send a keyboard combo reliably across desktop apps and DirectX games.
    
    Keys is a list like ['ctrl', 'alt', 's'].
    Modifiers are pressed first, then action keys are pressed and held for sufficient
    frames (~60ms) before releasing in reverse order.
    """
    if not keys:
        return
    if sys.platform != "win32" or not _user32:
        logger.debug(f"{TAG} send_key_combo({keys}) skipped on non-Windows platform")
        return

    # Categorize modifiers vs action keys
    modifier_names = {"ctrl", "alt", "shift", "win", "lwin", "rwin"}
    mod_keys = []
    action_keys = []

    for k in keys:
        name = k.lower().strip()
        vk = VK_MAP.get(name)
        if not vk:
            continue
        sc = _get_scan_code(name, vk)
        item = (name, vk, sc)
        if name in modifier_names:
            mod_keys.append(item)
        else:
            action_keys.append(item)

    if not mod_keys and not action_keys:
        return

    # 1. Press all modifiers in order
    for name, vk, sc in mod_keys:
        _send_key_event(vk, sc, down=True)
        time.sleep(0.02)

    # 2. Press action keys
    for name, vk, sc in action_keys:
        _send_key_event(vk, sc, down=True)
        time.sleep(0.02)

    # 3. Hold time: 60ms ensures game engine input loop catches it (even at 30/60 FPS)
    time.sleep(0.06)

    # 4. Release action keys in reverse order
    for name, vk, sc in reversed(action_keys):
        _send_key_event(vk, sc, down=False)
        time.sleep(0.02)

    # 5. Release modifiers in reverse order
    for name, vk, sc in reversed(mod_keys):
        _send_key_event(vk, sc, down=False)
        time.sleep(0.02)


# All available keyboard keys for UI display
AVAILABLE_KEYS = sorted(VK_MAP.keys())

# Qt key code → our key name (for keyboard recording)
QT_KEY_TO_NAME = {
    0x01000000: "esc", 0x01000001: "tab", 0x01000003: "backspace",
    0x01000004: "enter", 0x01000005: "enter",  # Return & Enter
    0x01000006: "insert", 0x01000007: "delete",
    0x01000008: "pause", 0x01000009: "printscreen",
    0x01000010: "home", 0x01000011: "end",
    0x01000012: "left", 0x01000013: "up",
    0x01000014: "right", 0x01000015: "down",
    0x01000016: "pageup", 0x01000017: "pagedown",
    0x01000020: "shift", 0x01000021: "ctrl", 0x01000023: "alt", 0x01000024: "win",
    0x01000030: "f1", 0x01000031: "f2", 0x01000032: "f3",
    0x01000033: "f4", 0x01000034: "f5", 0x01000035: "f6",
    0x01000036: "f7", 0x01000037: "f8", 0x01000038: "f9",
    0x01000039: "f10", 0x0100003a: "f11", 0x0100003b: "f12",
    0x20: "space", 0x01000025: "numlock",
}
# Add A-Z (Qt.Key_A=0x41 .. Qt.Key_Z=0x5a)
for _i in range(26):
    QT_KEY_TO_NAME[0x41 + _i] = chr(ord('a') + _i)
# Add 0-9 (Qt.Key_0=0x30 .. Qt.Key_9=0x39)
for _i in range(10):
    QT_KEY_TO_NAME[0x30 + _i] = str(_i)


def qt_key_to_name(qt_key: int) -> str | None:
    """Convert a Qt.Key value to our key name. Returns None if unknown."""
    return QT_KEY_TO_NAME.get(qt_key)

