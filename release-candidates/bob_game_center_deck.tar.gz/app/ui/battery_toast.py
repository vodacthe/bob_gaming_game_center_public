"""Low controller battery: a small always-on-top, click-through notice at the bottom centre of the game's screen."""

from __future__ import annotations

import logging
import time

from PySide6.QtCore import QEasingCurve, QObject, QPropertyAnimation, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QGuiApplication, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget

from app.core import gamepad_battery as battery

logger = logging.getLogger(__name__)
TAG = "[GamepadBattery]"

BOTTOM_MARGIN = 72          # px above the bottom edge of the screen
SHOW_SECONDS = 6.0
SHOW_SECONDS_URGENT = 10.0
RECHECK_MS = 30_000         # re-evaluate the reminders even when the level does not change


class BatteryToast(QWidget):
    """Frameless pill that never takes focus or clicks; fades out by itself."""

    def __init__(self):
        flags = (Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool | Qt.WindowType.WindowStaysOnTopHint
                 | Qt.WindowType.WindowTransparentForInput | Qt.WindowType.WindowDoesNotAcceptFocus)
        super().__init__(None, flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setWindowTitle("Bob Gaming - Pin tay cầm")
        self._text, self._urgent = "", False
        self._font = QFont("Segoe UI", 13, QFont.Weight.DemiBold)
        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._fade_out)
        self._topmost_timer = QTimer(self)          # games push themselves on top: re-assert while visible
        self._topmost_timer.setInterval(1000)
        self._topmost_timer.timeout.connect(self._keep_topmost)
        self._fade = QPropertyAnimation(self, b"windowOpacity", self)
        self._fade.setDuration(600)
        self._fade.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self._fade.finished.connect(self._on_fade_done)

    @property
    def text(self) -> str:
        return self._text

    def show_alert(self, text: str, urgent: bool = False) -> None:
        self._text, self._urgent = text, urgent
        metrics = QFontMetrics(self._font)
        self.setFixedSize(metrics.horizontalAdvance(text) + 64, metrics.height() + 26)
        self._place()
        self._fade.stop()
        self.setWindowOpacity(1.0)
        self.show()
        self.raise_()
        self._keep_topmost()
        try:
            from app.ui.steam_chat import win32
            win32.set_click_through(int(self.winId()), True)
        except Exception:   # noqa: BLE001 - click-through is a nicety; Qt's flag already passes input through
            logger.debug(f"{TAG} could not make the notice click-through", exc_info=True)
        self._topmost_timer.start()
        self._hide_timer.start(int((SHOW_SECONDS_URGENT if urgent else SHOW_SECONDS) * 1000))
        self.update()

    def target_screen(self):
        """The screen the game is on (the foreground window's monitor), else the primary screen."""
        try:
            from app.ui.steam_chat import win32
            info = win32.foreground_info()
            if info.monitor_origin is not None:
                for screen in QGuiApplication.screens():
                    top_left = screen.geometry().topLeft()
                    if (top_left.x(), top_left.y()) == tuple(info.monitor_origin):
                        return screen
        except Exception:   # noqa: BLE001
            logger.debug(f"{TAG} could not find the game's screen", exc_info=True)
        return QGuiApplication.primaryScreen()

    def _place(self) -> None:
        screen = self.target_screen()
        if screen is None:
            return
        g = screen.geometry()
        self.move(g.x() + (g.width() - self.width()) // 2, g.y() + g.height() - self.height() - BOTTOM_MARGIN)

    def _keep_topmost(self) -> None:
        try:
            from app.ui.steam_chat import win32
            win32.keep_topmost(int(self.winId()))
        except Exception:   # noqa: BLE001
            pass

    def _fade_out(self) -> None:
        self._fade.stop()
        self._fade.setStartValue(self.windowOpacity())
        self._fade.setEndValue(0.0)
        self._fade.start()

    def _on_fade_done(self) -> None:
        if self.windowOpacity() <= 0.01:
            self.hide()
            self._topmost_timer.stop()

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        path = QPainterPath()
        path.addRoundedRect(rect, rect.height() / 2, rect.height() / 2)
        accent = QColor("#ef4444") if self._urgent else QColor("#f59e0b")
        p.fillPath(path, QColor(12, 14, 22, 230))
        p.setPen(QPen(accent, 2))
        p.drawPath(path)
        p.setFont(self._font)
        p.setPen(QColor("#fde68a") if not self._urgent else QColor("#fecaca"))
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, f"🪫  {self._text}")
        p.end()


class BatteryNotifier(QObject):
    """Feeds the gamepad monitor's battery readings to BatteryWatch and shows the warnings it decides on."""

    summary_changed = Signal(str)

    def __init__(self, parent=None, toast: BatteryToast | None = None, clock=time.monotonic):
        super().__init__(parent)
        self.watch = battery.BatteryWatch()
        self._toast = toast
        self._clock = clock
        self._timer = QTimer(self)
        self._timer.setInterval(RECHECK_MS)
        self._timer.timeout.connect(self._recheck)
        self._timer.start()

    @property
    def toast(self) -> BatteryToast:
        if self._toast is None:
            self._toast = BatteryToast()
        return self._toast

    def on_levels(self, raw) -> None:
        """Slot for GamepadMonitor.battery_changed ({device: SDL power level}). Never raises."""
        try:
            levels = {str(name): battery.from_sdl(value) for name, value in dict(raw or {}).items()}
            self._apply(levels)
        except Exception:   # noqa: BLE001
            logger.exception(f"{TAG} could not handle a battery reading")

    def _recheck(self) -> None:
        try:
            self._apply(dict(self.watch.levels))
        except Exception:   # noqa: BLE001
            logger.exception(f"{TAG} reminder check failed")

    def _apply(self, levels: dict) -> None:
        before = self.watch.summary()
        alerts = self.watch.update(levels, self._clock())
        if alerts:
            urgent = any(a.urgent for a in alerts)
            self.toast.show_alert("   ·   ".join(a.text for a in alerts), urgent)
        after = self.watch.summary()
        if after != before:
            self.summary_changed.emit(after)
