"""
Cloud Sync Screen for Bob Gaming Game Center.
Comprehensive cloud sync management dashboard with standard header and back button.
"""

import os
import logging
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QTableWidget, QTableWidgetItem,
    QHeaderView, QFrame, QScrollArea, QMessageBox,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

from app.config import (
    SYNC_STATUS_SYNCED, SYNC_STATUS_SYNCING, SYNC_STATUS_NOT_SYNCED,
    SYNC_STATUS_NOT_CONFIGURED, SYNC_STATUS_ERROR,
    PROVIDER_NEXTCLOUD, PROVIDER_GOOGLE_DRIVE,
)
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader

logger = logging.getLogger(__name__)


class CloudSyncScreen(QWidget):
    """Full-screen Cloud Sync Management view."""

    back_requested = Signal()
    sync_all_requested = Signal()
    sync_game_requested = Signal(str, str)
    download_game_requested = Signal(str)
    unsync_game_requested = Signal(str, bool)

    def __init__(self, config: dict, games: list[dict] = None, is_logged_in: bool = False, parent=None):
        super().__init__(parent)
        self.config = config.copy()
        self._games = list(games or [])
        self._is_logged_in = is_logged_in
        self._filter_mode = "all"
        self._setup_ui()

    def update_data(self, config: dict, games: list[dict], is_logged_in: bool):
        """Update cloud sync screen data dynamically."""
        self.config = config.copy()
        self._games = list(games)
        self._is_logged_in = is_logged_in
        self._update_metrics()
        self._populate_table()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Header Bar ──
        header = ScreenHeader("Đồng bộ đám mây", "cloud", subtitle="Quản lý lưu game trên Cloud (Cloud Sync)")
        header.back_requested.connect(self._on_back)
        self.sync_all_btn = header.add_button("Đồng bộ tất cả ngay", "primary", icon="sync")
        self.sync_all_btn.clicked.connect(lambda: self.sync_all_requested.emit())
        main_layout.addWidget(header)

        # ── Scroll / Main Container ──
        body = QWidget()
        body.setStyleSheet("background: transparent;")
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(*CONTENT_MARGINS)
        body_layout.setSpacing(16)

        # ── 3 Summary Metric Cards ──
        metrics_layout = QHBoxLayout()
        metrics_layout.setSpacing(16)

        self.metric_provider = self._create_metric_card("Dịch vụ lưu trữ", "Nextcloud", "cloud", "#a855f7")
        self.metric_synced = self._create_metric_card("Game đã đồng bộ", "0 / 0", "check", "#2ed573")
        self.metric_autosync = self._create_metric_card("Tự động sao lưu", "Đang bật", "refresh", "#38bdf8")

        metrics_layout.addWidget(self.metric_provider)
        metrics_layout.addWidget(self.metric_synced)
        metrics_layout.addWidget(self.metric_autosync)
        body_layout.addLayout(metrics_layout)

        # ── Filter & Search Bar ──
        filter_bar = QHBoxLayout()
        filter_bar.setSpacing(10)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Tìm kiếm trò chơi trong danh sách đồng bộ...")
        self.search_input.setFixedHeight(36)
        self.search_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(18, 22, 34, 0.8);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 8px;
                padding: 0 12px;
                color: #ffffff;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #8b5cf6;
            }
        """)
        self.search_input.textChanged.connect(self._populate_table)
        filter_bar.addWidget(self.search_input, 1)

        self.btn_filter_all = QPushButton("Tất cả game")
        self.btn_filter_synced = QPushButton("Đã đồng bộ")
        self.btn_filter_unsynced = QPushButton("Chưa đồng bộ")

        for mode, btn in [("all", self.btn_filter_all), ("synced", self.btn_filter_synced), ("unsynced", self.btn_filter_unsynced)]:
            btn.setFixedHeight(36)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _, m=mode: self._set_filter_mode(m))
            filter_bar.addWidget(btn)

        body_layout.addLayout(filter_bar)

        # ── Games Table ──
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Trò chơi", "Đường dẫn Save Game", "Trạng thái", "Thời gian lưu", "Thao tác"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setColumnWidth(0, 220)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setStyleSheet("""
            QTableWidget {
                background-color: rgba(14, 18, 26, 0.85);
                alternate-background-color: rgba(20, 26, 38, 0.85);
                color: #e2e8f0;
                gridline-color: rgba(255, 255, 255, 0.06);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 8px;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: rgba(20, 26, 38, 0.95);
                color: #94a3b8;
                padding: 8px;
                border: 1px solid rgba(255, 255, 255, 0.06);
                font-weight: bold;
            }
        """)
        body_layout.addWidget(self.table, 1)

        main_layout.addWidget(body)

        self._update_metrics()
        self._set_filter_mode("all")

    def _create_metric_card(self, title: str, val: str, icon_name: str, color: str) -> QFrame:
        card = QFrame()
        card.setObjectName("metricCard")
        card.setFixedHeight(80)
        card.setStyleSheet("""
            #metricCard {
                background-color: rgba(18, 22, 34, 0.7);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 10px;
            }
            #metricCard QLabel {
                border: none;
                background: transparent;
            }
        """)
        layout = QHBoxLayout(card)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(14)

        icon_lbl = QLabel()
        icon_lbl.setFixedSize(42, 42)
        icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_lbl.setStyleSheet("background-color: rgba(255, 255, 255, 0.05); border: none; border-radius: 8px;")
        icon_lbl.setPixmap(make_svg_pixmap(icon_name, size=22, color=color))
        layout.addWidget(icon_lbl)

        v_box = QVBoxLayout()
        v_box.setSpacing(2)
        t_lbl = QLabel(title)
        t_lbl.setStyleSheet("color: #8b949e; font-size: 11px; font-weight: 500; border: none; background: transparent;")
        v_box.addWidget(t_lbl)

        val_lbl = QLabel(val)
        val_lbl.setObjectName("valLabel")
        val_lbl.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        val_lbl.setStyleSheet("color: #ffffff; border: none; background: transparent;")
        v_box.addWidget(val_lbl)
        layout.addLayout(v_box)
        layout.addStretch()

        return card

    def _update_metrics(self):
        # Provider
        p = self.config.get("cloud_provider", PROVIDER_NEXTCLOUD)
        p_name = "Google Drive" if p == PROVIDER_GOOGLE_DRIVE else "Nextcloud"
        conn_str = f"{p_name} (Đã kết nối)" if self._is_logged_in else "Chưa đăng nhập"
        self.metric_provider.findChild(QLabel, "valLabel").setText(conn_str)

        # Synced count
        synced_count = sum(1 for g in self._games if g.get("status") in [SYNC_STATUS_SYNCED, SYNC_STATUS_SYNCING] or g.get("on_cloud"))
        total = len(self._games)
        self.metric_synced.findChild(QLabel, "valLabel").setText(f"{synced_count} / {total} Game")

        # Auto sync
        self.metric_autosync.findChild(QLabel, "valLabel").setText("Đang theo dõi" if self._is_logged_in else "Tạm ngưng")

    def _set_filter_mode(self, mode: str):
        self._filter_mode = mode
        active_style = "background-color: #8b5cf6; color: #ffffff; font-weight: bold; border-radius: 6px; padding: 0 14px;"
        inactive_style = "background-color: rgba(255, 255, 255, 0.05); color: #cbd5e1; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 6px; padding: 0 14px;"

        self.btn_filter_all.setStyleSheet(active_style if mode == "all" else inactive_style)
        self.btn_filter_synced.setStyleSheet(active_style if mode == "synced" else inactive_style)
        self.btn_filter_unsynced.setStyleSheet(active_style if mode == "unsynced" else inactive_style)

        self._populate_table()

    def _populate_table(self):
        query = self.search_input.text().strip().lower()
        self.table.setRowCount(0)

        for game in self._games:
            name = game.get("name", "Unknown")
            save_path = game.get("save_path", "")
            status = game.get("status", SYNC_STATUS_NOT_CONFIGURED)
            on_cloud = bool(game.get("on_cloud", False))

            if query and query not in name.lower():
                continue

            is_synced = (status in [SYNC_STATUS_SYNCED, SYNC_STATUS_SYNCING]) or on_cloud
            if self._filter_mode == "synced" and not is_synced:
                continue
            if self._filter_mode == "unsynced" and is_synced:
                continue

            row = self.table.rowCount()
            self.table.insertRow(row)

            # 0: Game Name
            name_item = QTableWidgetItem(name)
            name_item.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
            self.table.setItem(row, 0, name_item)

            # 1: Save Path
            path_item = QTableWidgetItem(save_path if save_path else "(Chưa cấu hình đường dẫn)")
            path_item.setForeground(Qt.GlobalColor.gray if not save_path else Qt.GlobalColor.white)
            self.table.setItem(row, 1, path_item)

            # 2: Status
            status_text = "Đã đồng bộ" if is_synced else "Chưa đồng bộ"
            status_item = QTableWidgetItem(status_text)
            status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if is_synced:
                status_item.setForeground(Qt.GlobalColor.green)
            else:
                status_item.setForeground(Qt.GlobalColor.yellow)
            self.table.setItem(row, 2, status_item)

            # 3: Time
            mtime = game.get("local_mtime") or game.get("remote_mtime")
            time_str = "—"
            if mtime:
                import time
                time_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime))
            time_item = QTableWidgetItem(time_str)
            time_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row, 3, time_item)

            # 4: Actions Widget
            actions_widget = QWidget()
            act_layout = QHBoxLayout(actions_widget)
            act_layout.setContentsMargins(4, 2, 4, 2)
            act_layout.setSpacing(6)

            sync_btn = QPushButton("Đồng bộ")
            sync_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            sync_btn.setFixedHeight(28)
            sync_btn.setStyleSheet("background-color: rgba(139, 92, 246, 0.2); color: #c084fc; border: 1px solid rgba(139, 92, 246, 0.4); border-radius: 4px; padding: 0 8px;")
            sync_btn.clicked.connect(lambda _, g=name, p=save_path: self.sync_game_requested.emit(g, p))
            act_layout.addWidget(sync_btn)

            if save_path and os.path.isdir(save_path):
                open_btn = QPushButton("Mở thư mục")
                open_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                open_btn.setFixedHeight(28)
                open_btn.setStyleSheet("background-color: rgba(255, 255, 255, 0.05); color: #cbd5e1; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 4px; padding: 0 8px;")
                open_btn.clicked.connect(lambda _, p=save_path: os.startfile(p) if os.path.exists(p) else None)
                act_layout.addWidget(open_btn)

            self.table.setCellWidget(row, 4, actions_widget)

    def _on_back(self):
        self.back_requested.emit()
