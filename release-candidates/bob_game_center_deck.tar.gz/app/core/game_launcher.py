"""
Non-Steam game launcher for Bob Gaming Game Center.
Launches Non-Steam games through Steam (`steam://rungameid/<uint64_id>`) when registered in shortcuts.vdf,
automatically restarting Steam if the shortcut was added while the current Steam session was already open,
and falling back to direct .exe execution if Steam is unavailable or fails.
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
import time

from PySide6.QtCore import QObject, Signal, Slot

from app.core.online_fix.extractor import clean_subprocess_env
from app.core.steam_manager import (
    add_non_steam_game,
    clear_steam_reload_flag,
    close_steam,
    find_matching_steam_shortcuts,
    find_steam_path,
    get_steam_executable,
    is_steam_running,
    needs_steam_reload_for_shortcut,
)
from app.core.steam_vdf import calculate_shortcut_appid

logger = logging.getLogger(__name__)
TAG = "[Library/Launch]"

# Valve CGameID type nibble for Non-Steam shortcuts: EGameIDType::k_EGameIDTypeShortcut = 2 (bits 24..31)
STEAM_SHORTCUT_TYPE_MASK = 0x02000000


def shortcut_uint_to_rungameid(uint_appid: int) -> int:
    """Convert a 32-bit shortcut AppID into Valve's 64-bit CGameID integer for steam://rungameid/."""
    return ((int(uint_appid) & 0xFFFFFFFF) << 32) | STEAM_SHORTCUT_TYPE_MASK


def build_steam_rungame_url(uint_appid: int) -> str:
    """Build the steam://rungameid/<uint64> URI for a Non-Steam shortcut."""
    return f"steam://rungameid/{shortcut_uint_to_rungameid(uint_appid)}"


def _spawn_direct_exe(
    clean_exe: str,
    env_overrides: dict[str, str] | None = None,
    game_dir: str = "",
    is_online_fix: bool = False,
) -> None:
    """Launch a game executable directly in its own working directory with a sanitized environment."""
    env = clean_subprocess_env()
    if env_overrides:
        env.update(env_overrides)

    cwd = os.path.dirname(clean_exe) if os.path.isfile(clean_exe) else (game_dir or None)

    # On Linux, route Online-Fix games or Windows .exe through start_game.sh or wine
    if sys.platform != "win32" and (is_online_fix or clean_exe.lower().endswith(".exe")):
        search_dirs = [d for d in [game_dir, cwd, os.path.dirname(cwd) if cwd else None] if d and os.path.isdir(d)]
        start_sh = None
        for d in search_dirs:
            candidate = os.path.join(d, "start_game.sh")
            if os.path.isfile(candidate):
                start_sh = candidate
                break

        if start_sh:
            logger.info(f"{TAG} Routing Linux direct execution through {start_sh}")
            cmd = [start_sh] if os.access(start_sh, os.X_OK) else ["bash", start_sh]
            subprocess.Popen(cmd, cwd=os.path.dirname(start_sh), env=env)
            return

        wine_bin = shutil.which("wine")
        if wine_bin:
            logger.info(f"{TAG} Routing Linux direct execution through wine for {clean_exe}")
            subprocess.Popen([wine_bin, clean_exe], cwd=cwd, env=env)
            return

    try:
        subprocess.Popen(
            [clean_exe],
            cwd=cwd,
            env=env,
        )
    except OSError as err:
        if sys.platform != "win32" and getattr(err, "errno", None) == 8:
            logger.warning(f"{TAG} Direct ELF execution failed with Exec format error: {err}")
            start_sh = os.path.join(cwd or "", "start_game.sh")
            if os.path.isfile(start_sh):
                logger.info(f"{TAG} Exec format error fallback: executing {start_sh}")
                cmd = [start_sh] if os.access(start_sh, os.X_OK) else ["bash", start_sh]
                subprocess.Popen(cmd, cwd=cwd, env=env)
                return
            wine_bin = shutil.which("wine")
            if wine_bin:
                logger.info(f"{TAG} Exec format error fallback: executing via wine")
                subprocess.Popen([wine_bin, clean_exe], cwd=cwd, env=env)
                return
        raise


def launch_game(
    game_name: str,
    exe_path: str,
    install_location: str = "",
    force_direct_exe: bool = False,
    steam_path: str | None = None,
    persisted_pending_ts: float | None = None,
    ensure_shortcut_if_pending: bool = False,
) -> dict:
    """
    Launch a game via Steam Non-Steam shortcut if present (or pending reload), otherwise directly via .exe.
    Intended to run on GameLaunchWorker (QThread) so Steam shutdown/relaunch never blocks the UI thread.
    """
    t0 = time.monotonic()
    clean_exe = (exe_path or "").strip().strip('"')
    effective_name = (game_name or "").strip() or (
        os.path.splitext(os.path.basename(clean_exe))[0] if clean_exe else "Game"
    )
    logger.info(
        f"{TAG} Starting launch for {effective_name!r} "
        f"(exe={clean_exe!r}, force_direct={force_direct_exe})"
    )

    if not clean_exe or not os.path.isfile(clean_exe):
        msg = f"Không tìm thấy file thực thi (.exe) của trò chơi:\n{clean_exe or '(trống)'}"
        logger.warning(f"{TAG} Refused launch for {effective_name!r}: executable missing ({clean_exe!r})")
        return {"success": False, "game_name": game_name, "exe_path": clean_exe, "mode": "none", "error": msg}

    target_dir = install_location or os.path.dirname(clean_exe)
    is_of_game = False
    of_env: dict[str, str] = {}
    of_launch_options: str = ""

    try:
        from app.core.online_fix.runner import (
            DEFAULT_ONLINEFIX_DLL_OVERRIDES,
            detect_online_fix_game,
            prepare_online_fix_launch,
        )
        detection = detect_online_fix_game(target_dir)
        if detection.get("is_online_fix"):
            is_of_game = True
            app_id = detection.get("appid") or 480
            prep = prepare_online_fix_launch(target_dir, clean_exe, app_id=app_id)
            of_launch_options = prep.get("launch_options", "")
            of_env = prep.get("env", {"WINEDLLOVERRIDES": DEFAULT_ONLINEFIX_DLL_OVERRIDES})
    except Exception as exc:
        logger.warning(f"{TAG} Failed checking Online-Fix status for {effective_name!r}: {exc}")

    def _run_direct(mode: str, reason: str = "") -> dict:
        try:
            if is_of_game:
                _spawn_direct_exe(
                    clean_exe,
                    env_overrides=of_env,
                    game_dir=target_dir,
                    is_online_fix=True,
                )
            else:
                _spawn_direct_exe(clean_exe)
            elapsed = time.monotonic() - t0

            logger.info(
                f"{TAG} Launched {effective_name!r} via {mode} in {elapsed:.2f}s"
                + (f" ({reason})" if reason else "")
            )
            return {
                "success": True,
                "game_name": game_name,
                "exe_path": clean_exe,
                "mode": mode,
                "steam_restarted": False,
                "elapsed": elapsed,
            }
        except OSError as exc:
            elapsed = time.monotonic() - t0
            logger.error(
                f"{TAG} Failed to launch executable {clean_exe} for {effective_name!r} "
                f"after {elapsed:.2f}s: {exc}",
                exc_info=True,
            )
            return {
                "success": False,
                "game_name": game_name,
                "exe_path": clean_exe,
                "mode": "none",
                "error": f"Không thể khởi chạy file trò chơi:\n{clean_exe}\n\nChi tiết: {exc}",
            }

    if force_direct_exe:
        return _run_direct("direct", "user requested direct .exe launch")

    resolved_steam = steam_path or find_steam_path()
    steam_cmd = get_steam_executable(resolved_steam) if resolved_steam else None
    if not steam_cmd and sys.platform != "win32" and shutil.which("xdg-open"):
        steam_cmd = shutil.which("xdg-open")
    if not resolved_steam or not steam_cmd:
        return _run_direct("direct_fallback", "Steam installation not found")

    matches = find_matching_steam_shortcuts(effective_name, clean_exe, steam_path=resolved_steam)
    reload_needed = needs_steam_reload_for_shortcut(
        effective_name,
        clean_exe,
        persisted_pending_ts=persisted_pending_ts,
    )

    if not matches and (reload_needed or ensure_shortcut_if_pending):
        if is_steam_running():
            reload_needed = True
        else:
            start_dir = install_location or os.path.dirname(clean_exe)
            add_res = add_non_steam_game(
                game_name=effective_name,
                exe_path=clean_exe,
                start_dir=start_dir,
                launch_options=of_launch_options,
                steam_path=resolved_steam,
            )
            clear_steam_reload_flag(effective_name, clean_exe)
            if add_res.get("success"):
                matches = find_matching_steam_shortcuts(effective_name, clean_exe, steam_path=resolved_steam)

    if not matches and not reload_needed:
        return _run_direct("direct", "no Non-Steam shortcut registered in Steam")

    steam_restarted = False
    if reload_needed:
        logger.info(
            f"{TAG} Shortcut for {effective_name!r} was added while Steam was running; "
            f"restarting Steam to load shortcuts.vdf"
        )
        closed = close_steam(timeout=10, steam_path=resolved_steam)
        if not closed:
            logger.warning(
                f"{TAG} Could not close running Steam cleanly for {effective_name!r}; "
                f"falling back to direct .exe"
            )
            return _run_direct("direct_fallback", "Steam did not close within timeout")

        # Re-ensure shortcut in shortcuts.vdf after Steam shutdown (Steam flushes in-RAM shortcuts on exit)
        start_dir = install_location or os.path.dirname(clean_exe)
        add_non_steam_game(
            game_name=effective_name,
            exe_path=clean_exe,
            start_dir=start_dir,
            launch_options=of_launch_options,
            steam_path=resolved_steam,
        )
        clear_steam_reload_flag(effective_name, clean_exe)
        matches = find_matching_steam_shortcuts(effective_name, clean_exe, steam_path=resolved_steam)
        steam_restarted = True


    uint_appid = 0
    if matches:
        uint_appid = int(matches[0].get("uint_appid") or 0)
    if not uint_appid:
        _, uint_appid, _ = calculate_shortcut_appid(clean_exe, effective_name)

    steam_url = build_steam_rungame_url(uint_appid)
    cmd = (
        ["flatpak", "run", "com.valvesoftware.Steam", steam_url]
        if steam_cmd == "flatpak"
        else [steam_cmd, steam_url]
    )
    try:
        subprocess.Popen(
            cmd,
            cwd=resolved_steam if os.path.isdir(resolved_steam) else None,
            env=clean_subprocess_env(),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        clear_steam_reload_flag(effective_name, clean_exe)
        elapsed = time.monotonic() - t0
        logger.info(
            f"{TAG} Launched {effective_name!r} via Steam ({steam_url}, uint_appid={uint_appid}, "
            f"steam_restarted={steam_restarted}) in {elapsed:.2f}s"
        )
        return {
            "success": True,
            "game_name": game_name,
            "exe_path": clean_exe,
            "mode": "steam",
            "uint_appid": uint_appid,
            "steam_url": steam_url,
            "steam_restarted": steam_restarted,
            "elapsed": elapsed,
        }
    except OSError as exc:
        logger.warning(
            f"{TAG} Failed to invoke Steam ({steam_cmd} {steam_url}) for {effective_name!r}: {exc}; "
            f"falling back to direct .exe"
        )
        return _run_direct("direct_fallback", f"Steam invocation error: {exc}")


class GameLaunchWorker(QObject):
    """Background QThread worker for launching a game via Steam or direct .exe without freezing the UI."""

    finished = Signal(dict)

    def __init__(
        self,
        game_name: str,
        exe_path: str,
        install_location: str = "",
        force_direct_exe: bool = False,
        steam_path: str | None = None,
        persisted_pending_ts: float | None = None,
        ensure_shortcut_if_pending: bool = False,
        parent: QObject | None = None,
    ):
        super().__init__(parent)
        self.game_name = game_name
        self.exe_path = exe_path
        self.install_location = install_location
        self.force_direct_exe = force_direct_exe
        self.steam_path = steam_path
        self.persisted_pending_ts = persisted_pending_ts
        self.ensure_shortcut_if_pending = ensure_shortcut_if_pending

    @Slot()
    def run(self):
        try:
            res = launch_game(
                game_name=self.game_name,
                exe_path=self.exe_path,
                install_location=self.install_location,
                force_direct_exe=self.force_direct_exe,
                steam_path=self.steam_path,
                persisted_pending_ts=self.persisted_pending_ts,
                ensure_shortcut_if_pending=self.ensure_shortcut_if_pending,
            )
            self.finished.emit(res)
        except Exception as exc:
            logger.exception(f"{TAG} Unexpected error in GameLaunchWorker for {self.game_name!r}")
            self.finished.emit({
                "success": False,
                "game_name": self.game_name,
                "exe_path": self.exe_path,
                "mode": "none",
                "error": f"Lỗi không mong muốn khi khởi chạy trò chơi: {exc}",
            })
