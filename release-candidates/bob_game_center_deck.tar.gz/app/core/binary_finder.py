"""
app/core/binary_finder.py - Single Source of Truth for External Binary Resolution.

Platform-agnostic discovery for external helper binaries (aria2c, 7z/7zz, tar).
Searches PyInstaller bundle, executable directory, environment overrides,
bundled project directories, user-space paths, and system PATH.
Enforces POSIX executable permissions (0o755) on Linux.
"""
from __future__ import annotations

import logging
import os
import shutil
import stat
import sys
from typing import Optional, Sequence

logger = logging.getLogger(__name__)
TAG = "[Core/BinaryFinder]"

IS_WIN = sys.platform == "win32"


def get_app_dir() -> str:
    """Resolve the root directory of the application."""
    if hasattr(sys, "_MEIPASS"):
        return getattr(sys, "_MEIPASS")
    # app/core/binary_finder.py -> app/core -> app -> root
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def ensure_executable_permission(path: str) -> bool:
    """Ensure file has executable permission (0o755) on POSIX platforms."""
    if sys.platform == "win32" or not os.path.isfile(path):
        return True
    try:
        st = os.stat(path)
        needed_bits = stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
        if (st.st_mode & needed_bits) != needed_bits:
            new_mode = st.st_mode | needed_bits
            os.chmod(path, new_mode)
            logger.debug(f"{TAG} Updated executable bits on {path}: {oct(new_mode)}")
        return True
    except OSError as exc:
        logger.warning(f"{TAG} Failed to set executable permission on {path}: {exc}")
        return False


def _normalize_return_path(p: str) -> str:
    """Preserve POSIX paths on non-Windows (or in mocked POSIX tests) without drive letters."""
    if p.startswith("/") and not p.startswith("//"):
        return p
    return os.path.abspath(p)


def get_search_directories(existing_only: bool = False) -> list[str]:
    """
    Return ordered list of directories to probe for executable binaries.

    Priority Search Order:
    1. PyInstaller _MEIPASS bundle directory
    2. sys.executable directory (e.g. venv/bin or python dir)
    3. BOB_BIN_DIR environment variable override
    4. Bundled application directories:
       - Windows: native/bin/x64, native/bin/x86, bin
       - Linux: native/bin/linux, bin/linux, bin
    5. User-space SteamOS paths (Linux only):
       - /home/deck/Applications/BobGameCenter/native/bin/linux
       - /home/deck/Applications/BobGameCenter/bin
       - ~/.local/bin
    6. App root directory and app_root/downloads
    """
    dirs: list[str] = []
    app_root = get_app_dir()

    # 1. PyInstaller _MEIPASS
    if hasattr(sys, "_MEIPASS"):
        dirs.append(getattr(sys, "_MEIPASS"))

    # 2. sys.executable directory
    exe_dir = os.path.dirname(os.path.abspath(sys.executable))
    dirs.append(exe_dir)

    # 3. BOB_BIN_DIR environment override
    env_bin = os.environ.get("BOB_BIN_DIR")
    if env_bin:
        dirs.append(env_bin)

    # 4. Bundled directories
    if sys.platform == "win32":
        dirs.append(os.path.join(app_root, "native", "bin", "x64"))
        dirs.append(os.path.join(os.path.dirname(app_root), "native", "bin", "x64"))
        dirs.append(os.path.join(app_root, "native", "bin", "x86"))
        dirs.append(os.path.join(app_root, "bin"))
    else:
        dirs.append(os.path.join(app_root, "native", "bin", "linux"))
        dirs.append(os.path.join(os.path.dirname(app_root), "native", "bin", "linux"))
        dirs.append(os.path.join(app_root, "bin", "linux"))
        dirs.append(os.path.join(app_root, "bin"))
        # 5. User-space SteamOS paths
        dirs.append("/home/deck/Applications/BobGameCenter/native/bin/linux")
        dirs.append("/home/deck/Applications/BobGameCenter/bin")
        dirs.append(os.path.expanduser("~/.local/bin"))

    # 6. App root & downloads
    dirs.append(app_root)
    dirs.append(os.path.join(app_root, "downloads"))

    seen: set[str] = set()
    ordered_dirs: list[str] = []
    for d in dirs:
        norm = d if (sys.platform != "win32" and d.startswith("/")) else (
            os.path.normpath(os.path.abspath(d)) if os.path.isabs(d) else os.path.normpath(d)
        )
        if norm not in seen:
            seen.add(norm)
            if existing_only:
                if os.path.isdir(norm):
                    ordered_dirs.append(norm)
            else:
                ordered_dirs.append(norm)

    return ordered_dirs


def find_binary(
    base_name: str,
    alternate_names: Sequence[str] = (),
    system_fallbacks: Sequence[str] = (),
) -> Optional[str]:
    """
    Resolve an executable binary across candidate search directories, system PATH,
    and fallback locations. On POSIX, sets 0o755 executable bits if needed.
    """
    search_dirs = get_search_directories(existing_only=False)
    all_names = [base_name] + [n for n in alternate_names if n != base_name]

    # 1. Probe search directories
    for d in search_dirs:
        for name in all_names:
            candidate = (
                f"{d.rstrip('/')}/{name}"
                if (sys.platform != "win32" and d.startswith("/"))
                else os.path.join(d, name)
            )
            if os.path.isfile(candidate):
                if sys.platform != "win32":
                    ensure_executable_permission(candidate)
                logger.debug(f"{TAG} Found binary '{name}' at: {candidate}")
                return _normalize_return_path(candidate)

    # 2. Probe system PATH
    for name in all_names:
        system_path = shutil.which(name)
        if system_path:
            if sys.platform != "win32":
                ensure_executable_permission(system_path)
            logger.debug(f"{TAG} Found binary '{name}' on PATH: {system_path}")
            return _normalize_return_path(system_path)

    # 3. Probe well-known fallback paths
    for fallback in system_fallbacks:
        if os.path.isfile(fallback):
            if sys.platform != "win32":
                ensure_executable_permission(fallback)
            logger.debug(f"{TAG} Found binary at fallback location: {fallback}")
            return _normalize_return_path(fallback)

    logger.debug(f"{TAG} Binary '{base_name}' not found across search directories or PATH")
    return None


def find_aria2c() -> Optional[str]:
    """
    Resolve aria2c executable for current platform.
    Never searches for .exe on Linux.
    """
    if sys.platform == "win32":
        return find_binary("aria2c.exe", alternate_names=("aria2.exe", "aria2c", "aria2"))
    return find_binary(
        "aria2c",
        alternate_names=("aria2",),
        system_fallbacks=(
            "/usr/bin/aria2c",
            "/usr/bin/aria2",
            "/usr/local/bin/aria2c",
            "/home/deck/.local/bin/aria2c",
        ),
    )


def find_7z() -> Optional[str]:
    """
    Resolve 7z / 7zz / 7za executable for current platform.
    """
    if sys.platform == "win32":
        return find_binary(
            "7z.exe",
            alternate_names=("7za.exe", "7z", "7zz"),
            system_fallbacks=(
                r"C:\Program Files\7-Zip\7z.exe",
                r"C:\Program Files (x86)\7-Zip\7z.exe",
            ),
        )
    return find_binary(
        "7zz",
        alternate_names=("7z", "7za"),
        system_fallbacks=(
            "/usr/bin/7zz",
            "/usr/bin/7z",
            "/usr/bin/7za",
            "/usr/local/bin/7zz",
            "/usr/local/bin/7z",
        ),
    )


def find_tar() -> Optional[str]:
    """
    Resolve tar / bsdtar executable for current platform.
    """
    if sys.platform == "win32":
        sys_root = os.environ.get("SystemRoot", r"C:\Windows")
        return find_binary(
            "tar.exe",
            alternate_names=("tar", "bsdtar.exe", "bsdtar"),
            system_fallbacks=(os.path.join(sys_root, "System32", "tar.exe"),),
        )
    return find_binary(
        "bsdtar",
        alternate_names=("tar",),
        system_fallbacks=(
            "/usr/bin/tar",
            "/usr/bin/bsdtar",
            "/bin/tar",
        ),
    )
