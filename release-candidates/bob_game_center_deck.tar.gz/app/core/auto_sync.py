import os
import time
import logging

from PySide6.QtCore import QObject, Signal, QTimer
from PySide6.QtCore import QFileSystemWatcher

from app.core.sync_manager import SyncManager, determine_sync_action
from app.utils.helpers import format_timestamp

logger = logging.getLogger(__name__)

class AutoSyncManager(QObject):
    """
    Background manager for tracking local file changes and polling the cloud
    for new changes to automatically synchronize saves.
    """
    # Signals emitted to MainWindow
    upload_needed = Signal(str, str)     # game_name, save_path
    download_needed = Signal(str, str)   # game_name, save_path
    conflict_detected = Signal(str, dict, float, float)  # game_name, game_data, local_time, remote_time

    def __init__(self, sync_manager: SyncManager, parent=None):
        super().__init__(parent)
        self.sm = sync_manager
        
        # Debounce tracking for local uploads
        self._local_debounce_timers = {}  # game_name -> QTimer
        
        # File watcher for local changes
        self.watcher = QFileSystemWatcher(self)
        self.watcher.directoryChanged.connect(self._on_local_directory_changed)
        self.watcher.fileChanged.connect(self._on_local_directory_changed)
        
        # Map path -> game_name for reverse lookup in watcher
        self._path_to_game = {}

        # No internal poll timer — MainWindow._periodic_cloud_check drives polling.

    def start_watching(self, game_name: str, save_path: str):
        """Start tracking local saves for a game."""
        if not save_path or not os.path.exists(save_path):
            return
            
        # Add the directory and all its subdirectories to the watcher
        self._add_paths_recursive(game_name, save_path)

    def stop_watching(self, game_name: str):
        """Stop tracking a game."""
        paths_to_remove = [p for p, g in self._path_to_game.items() if g == game_name]
        for p in paths_to_remove:
            if p in self.watcher.directories() or p in self.watcher.files():
                self.watcher.removePath(p)
            del self._path_to_game[p]
            
        if game_name in self._local_debounce_timers:
            self._local_debounce_timers[game_name].stop()
            self._local_debounce_timers[game_name].deleteLater()
            del self._local_debounce_timers[game_name]

    def _add_paths_recursive(self, game_name: str, base_path: str):
        """Recursively watch directories."""
        if not os.path.exists(base_path):
            return
            
        self.watcher.addPath(base_path)
        self._path_to_game[base_path] = game_name
        
        exclude_filter = self.sm.get_exclude_filter(game_name, base_path)
        for root, dirs, files in os.walk(base_path):
            if exclude_filter:
                dirs[:] = [
                    d for d in dirs
                    if not exclude_filter.is_excluded(
                        os.path.relpath(os.path.join(root, d), base_path) + "/"
                    )
                ]
            for d in dirs:
                full_dir = os.path.join(root, d)
                self.watcher.addPath(full_dir)
                self._path_to_game[full_dir] = game_name

    def refresh_watched_games(self):
        """Re-scan config to watch all synced games."""
        games = self.sm.config.get("games", {})
        
        # Remove old paths
        for p in list(self._path_to_game.keys()):
            self.watcher.removePath(p)
        self._path_to_game.clear()
        
        for name, data in games.items():
            if data.get("status") == "synced" and data.get("save_path"):
                self.start_watching(name, data["save_path"])

    def _on_local_directory_changed(self, path: str):
        """Called by QFileSystemWatcher when a local file/folder changes."""
        game_name = self._path_to_game.get(path)
        if not game_name:
            return
            
        # Ignore changes if game is currently syncing
        game_data = self.sm.config.get("games", {}).get(game_name, {})
        if game_data.get("status") == "syncing":
            return

        save_path = game_data.get("save_path")
        if save_path and os.path.isfile(path):
            exclude_filter = self.sm.get_exclude_filter(game_name, save_path)
            rel_path = os.path.relpath(path, save_path)
            if exclude_filter.is_excluded(rel_path):
                logger.debug(f"[AutoSync] Ignoring change in excluded file: {rel_path}")
                return

        logger.info(f"Local change detected for {game_name} at {path}")

        # Restart debounce timer
        if game_name in self._local_debounce_timers:
            self._local_debounce_timers[game_name].stop()
        else:
            timer = QTimer(self)
            timer.setSingleShot(True)
            timer.setInterval(5000) # Wait 5 seconds after last change
            # Use a default argument to bind the current game_name to the lambda
            timer.timeout.connect(lambda g=game_name: self._check_sync_decision(g, reason="local_change"))
            self._local_debounce_timers[game_name] = timer
            
        self._local_debounce_timers[game_name].start()

    def _poll_cloud(self):
        """Called periodically to check the cloud for newer saves."""
        logger.debug("Polling cloud for changes...")
        try:
            games = dict(self.sm.config.get("games", {}))  # Snapshot to avoid mutation during iteration
        except Exception:
            return
        for game_name, data in games.items():
            if data.get("status") == "synced" and data.get("save_path"):
                try:
                    self._check_sync_decision(game_name, reason="polling")
                except Exception as e:
                    logger.error(f"[AutoSync] Error checking {game_name}: {e}")

    def _check_sync_decision(self, game_name: str, reason: str):
        """
        Compare timestamps and decide whether to upload, download, or show conflict dialog.
        Delegates to the shared determine_sync_action() for the actual comparison.
        """
        # If currently syncing, skip to avoid double triggers
        game_data = self.sm.config.get("games", {}).get(game_name, {})
        if game_data.get("status") == "syncing":
            return

        last_sync = game_data.get("last_sync", 0.0)
        save_path = game_data.get("save_path")

        if not save_path:
            return

        local_time = self.sm.get_local_modified_time(game_name)
        remote_time = self.sm.get_remote_modified_time(game_name)

        # Skip if no local save
        if local_time is None:
            logger.debug(f"[{game_name}] No local save found, skipping.")
            return

        action = determine_sync_action(local_time, remote_time, last_sync)

        _fmt = format_timestamp
        log_suffix = (
            f"Local={_fmt(local_time)}, Cloud={_fmt(remote_time)}, LastSync={_fmt(last_sync)}"
        )

        if action == "upload":
            logger.info(f"[{game_name}] ⬆ UPLOAD needed — {log_suffix}")
            self.upload_needed.emit(game_name, save_path)
        elif action == "download":
            logger.info(f"[{game_name}] ⬇ DOWNLOAD needed — {log_suffix}")
            self.download_needed.emit(game_name, save_path)
        elif action == "conflict":
            logger.warning(f"[{game_name}] ⚠ CONFLICT — {log_suffix}")
            self.conflict_detected.emit(game_name, game_data, local_time, remote_time)
        else:
            logger.info(f"[{game_name}] ✓ Up to date — {log_suffix}")
