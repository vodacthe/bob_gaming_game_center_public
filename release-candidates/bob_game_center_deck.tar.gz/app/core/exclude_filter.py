"""
Exclude filter for Bob Gaming Game Center.
Provides gitignore-style pattern matching to exclude machine-specific
configuration files (graphics, resolution, hardware, bindings) from cloud sync.
"""

import os
import fnmatch
import logging
from typing import Iterable, List

logger = logging.getLogger(__name__)

# Common config presets
PRESET_CONFIG_EXTS = ["*.ini", "*.cfg", "*.xml", "*.json", "*.conf", "*.config"]
PRESET_GRAPHICS_PATTERNS = ["*graphic*", "*display*", "*video*", "*resolution*", "*render*", "*hardware*"]
PRESET_LOGS_CACHE = ["*.log", "*.bak", "*.tmp", "cache/", "logs/", "CrashDumps/"]


class ExcludeFilter:
    """
    Evaluates relative paths against a list of glob patterns similar to .gitignore.
    """

    def __init__(self, patterns: Iterable[str] = (), save_dir: str | None = None):
        self.raw_patterns: List[str] = []
        self.patterns: List[str] = []

        if patterns:
            for p in patterns:
                self.add_pattern(p)

        # Automatically check for .bobignore or .syncignore in the save directory
        if save_dir and os.path.isdir(save_dir):
            self._load_ignore_files(save_dir)

    def add_pattern(self, pattern: str):
        """Add a pattern line."""
        clean = pattern.strip()
        if clean and not clean.startswith("#"):
            self.raw_patterns.append(clean)
            self.patterns.append(clean)

    def _load_ignore_files(self, save_dir: str):
        """Load ignore patterns from files like .bobignore or .syncignore in save_dir."""
        for filename in [".bobignore", ".syncignore", ".gitignore"]:
            filepath = os.path.join(save_dir, filename)
            if os.path.isfile(filepath):
                try:
                    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                        for line in f:
                            self.add_pattern(line)
                    logger.info(f"Loaded {len(self.patterns)} exclude patterns from {filepath}")
                    break  # Use the first available ignore file
                except Exception as e:
                    logger.warning(f"Could not read ignore file {filepath}: {e}")

    def is_excluded(self, rel_path: str, is_dir: bool = False) -> bool:
        """
        Check if a relative path (e.g. 'settings.ini' or 'Config/display.cfg') is excluded.

        Rules supported:
        - Exact filename: 'config.ini' matches in any folder or root
        - Leading slash: '/config.ini' matches only at root
        - Trailing slash: 'logs/' matches only directories or paths inside that directory
        - Extensions & wildcards: '*.ini', '*config*', 'settings/*.cfg'
        """
        norm_rel = rel_path.replace("\\", "/").strip("/")
        if not norm_rel:
            return False

        filename = os.path.basename(norm_rel)

        # .bobignore, .syncignore, and platform save location markers are excluded from saves/ delta sync.
        # .bobignore is stored separately at the game root folder on the cloud (alongside save_location_*.txt).
        if filename in [".bobignore", ".syncignore",
                        "save_location_windows.txt", "save_location_linux.txt",
                        "save_location_steamos.txt", "save_location_macos.txt",
                        "save_location_android.txt"]:
            return True

        if not self.patterns:
            return False

        for pat in self.patterns:
            pat = pat.replace("\\", "/").strip()
            if not pat or pat.startswith("#"):
                continue

            # Directory rule (e.g. 'logs/', 'cache/')
            if pat.endswith("/"):
                dir_pat = pat.rstrip("/")
                # If path is explicitly marked as a dir
                if is_dir:
                    if fnmatch.fnmatch(norm_rel, dir_pat) or fnmatch.fnmatch(norm_rel, f"*/{dir_pat}"):
                        return True
                # If path is inside the excluded directory
                if norm_rel == dir_pat or norm_rel.startswith(f"{dir_pat}/") or f"/{dir_pat}/" in f"/{norm_rel}/":
                    return True
                continue

            # Root-specific rule (e.g. '/config.ini')
            if pat.startswith("/"):
                root_pat = pat.lstrip("/")
                if fnmatch.fnmatch(norm_rel, root_pat):
                    return True
                continue

            # Rule with subpath (e.g. 'settings/*.cfg' or 'Saved/Config/*.ini')
            if "/" in pat:
                if fnmatch.fnmatch(norm_rel, pat) or fnmatch.fnmatch(norm_rel, f"*/{pat}"):
                    return True
                continue

            # Generic filename / wildcard rule (e.g. '*.ini', 'graphics.xml', '*config*')
            # Matches against both filename directly and the full relative path
            if fnmatch.fnmatch(filename, pat) or fnmatch.fnmatch(norm_rel, pat):
                return True

        return False

    def filter_paths(self, rel_paths: Iterable[str]) -> List[str]:
        """Return only paths that are NOT excluded."""
        return [p for p in rel_paths if not self.is_excluded(p)]
