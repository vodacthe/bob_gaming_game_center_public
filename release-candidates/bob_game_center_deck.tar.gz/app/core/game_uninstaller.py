"""
Safe game uninstaller for Bob Gaming Game Center Library.
Resolves a game's root installation directory with strict anti-data-loss guards,
removes local game files (and optionally local saves), and cleans Non-Steam shortcuts + artworks
on a background worker thread without blocking the UI.
"""

from __future__ import annotations

import logging
import os
import shutil
import stat
import sys
import time
from typing import Sequence

from PySide6.QtCore import QObject, Signal, Slot

from app.config import CONFIG_DIR, get_app_dir
from app.core.steam_manager import (
    close_steam,
    find_steam_path,
    has_non_steam_shortcut,
    is_steam_running,
    launch_steam_silent,
    remove_non_steam_game,
)

logger = logging.getLogger(__name__)
TAG = "[Library/Uninstall]"

_PROTECTED_BASENAMES = frozenset({
    # Windows system folders
    "windows", "system32", "syswow64", "program files", "program files (x86)",
    "programdata", "users", "perflogs", "recovery", "$recycle.bin",
    "system volume information", "msocache",
    # Linux POSIX system folders
    "bin", "boot", "dev", "etc", "home", "lib", "lib32", "lib64",
    "media", "mnt", "opt", "proc", "root", "run", "sbin", "srv",
    "sys", "tmp", "usr", "var", "deck",
    # User standard folders
    "desktop", "documents", "downloads", "pictures", "music", "videos",
    "appdata", "local", "locallow", "roaming", "saved games", "my games",
    # Game containers & common launcher directories
    "games", "pc games", "steam", "steamlibrary", "steamapps", "common",
    "epic games", "gog games", "riot games", "ubisoft", "ubisoft game launcher",
    "ea games", "electronic arts", "origin games", "xboxgames", "battle.net",
    "bob gaming", "gamecenter",
})

_BINARY_SUBDIRS = frozenset({
    "bin", "bins", "binaries", "binary",
    "x64", "x86", "win64", "win32", "win_x64", "win_x86", "x86_64", "amd64",
    "retail", "release", "shipping", "final", "pc", "game_exe",
})


def _norm_case_abs(path: str) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(path)))


def _is_same_or_parent(parent_case: str, child_case: str) -> bool:
    try:
        return os.path.commonpath([parent_case, child_case]) == parent_case
    except ValueError:
        return False


def _collect_critical_paths(extra_protected_dirs: Sequence[str] = ()) -> tuple[list[str], list[str]]:
    """Return (cannot_be_same_or_ancestor_of, cannot_be_inside_of) normalized paths."""
    home = os.path.expanduser("~")
    ancestors_blocked: list[str] = []
    descendants_blocked: list[str] = []

    user_roots = [home]
    # Unconditionally protect /home/deck on all platforms (Linux Deck, Windows, CI)
    if "/home/deck" not in [_norm_case_abs(h) for h in user_roots if h]:
        user_roots.append("/home/deck")

    raw_protected = [
        "/",
        "/bin", "/sbin", "/boot", "/dev", "/etc", "/home",
        "/lib", "/lib32", "/lib64", "/opt", "/proc", "/root", "/run",
        "/sys", "/usr", "/var",
        CONFIG_DIR,
        os.path.dirname(CONFIG_DIR),
        get_app_dir(),
        os.path.dirname(os.path.abspath(sys.executable)),
        *extra_protected_dirs,
    ]

    for u_home in user_roots:
        if not u_home:
            continue
        raw_protected.extend([
            u_home,
            os.path.join(u_home, "Desktop"),
            os.path.join(u_home, "Documents"),
            os.path.join(u_home, "Downloads"),
            os.path.join(u_home, ".config"),
            os.path.join(u_home, ".local"),
            os.path.join(u_home, ".local", "share"),
            os.path.join(u_home, ".steam"),
            os.path.join(u_home, ".var"),
            os.path.join(u_home, ".ssh"),
        ])

    if sys.platform == "win32":
        raw_protected.extend([
            os.environ.get("SYSTEMROOT", r"C:\Windows"),
            os.environ.get("PROGRAMFILES", r"C:\Program Files"),
            os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
            os.environ.get("PROGRAMDATA", r"C:\ProgramData"),
            os.path.join(home, "AppData"),
            os.path.join(home, "AppData", "Local"),
            os.path.join(home, "AppData", "LocalLow"),
            os.path.join(home, "AppData", "Roaming"),
        ])

    for p in raw_protected:
        if p and str(p).strip():
            ancestors_blocked.append(_norm_case_abs(str(p).strip()))

    raw_descendants = [
        "/bin", "/sbin", "/boot", "/dev", "/etc",
        "/lib", "/lib32", "/lib64", "/proc", "/root", "/sys",
        "/usr", "/var",
        CONFIG_DIR,
        get_app_dir(),
    ]

    for u_home in user_roots:
        if not u_home:
            continue
        raw_descendants.extend([
            os.path.join(u_home, ".local"),
            os.path.join(u_home, ".config"),
            os.path.join(u_home, ".steam"),
            os.path.join(u_home, ".var"),
            os.path.join(u_home, ".ssh"),
        ])

    if sys.platform == "win32":
        raw_descendants.append(os.environ.get("SYSTEMROOT", r"C:\Windows"))

    for p in raw_descendants:
        if p and str(p).strip():
            descendants_blocked.append(_norm_case_abs(str(p).strip()))

    return ancestors_blocked, descendants_blocked


def is_safe_delete_dir(
    target_dir: str,
    other_game_exes: Sequence[str] = (),
    extra_protected_dirs: Sequence[str] = (),
) -> tuple[bool, str]:
    """
    Validate that target_dir is safe to recursively delete.
    Blocks drive roots, OS/user folders, generic multi-game containers, Bob Gaming folders,
    and any folder containing another library game's executable.
    """
    raw = (target_dir or "").strip().strip('"')
    if not raw:
        return False, "Không xác định được đường dẫn thư mục."

    norm = os.path.normpath(os.path.abspath(raw))
    norm_case = os.path.normcase(norm)
    _drive, tail = os.path.splitdrive(norm)
    parts = [p for p in tail.split(os.sep) if p]
    if not parts:
        return False, f"Từ chối xóa thư mục gốc của ổ đĩa ({norm})."

    # Block recursive wiping of any user profile root (/home/username or C:\Users\username)
    if len(parts) <= 2 and parts[0].strip().lower() in ("home", "users"):
        return False, f"Từ chối xóa thư mục người dùng ({norm})."

    basename_lower = parts[-1].strip().lower()
    if basename_lower in _PROTECTED_BASENAMES:
        if basename_lower in _BINARY_SUBDIRS and len(parts) > 1:
            pass
        else:
            return False, f"Từ chối xóa thư mục hệ thống hoặc thư mục chứa chung nhiều game ({norm})."

    ancestors_blocked, descendants_blocked = _collect_critical_paths(extra_protected_dirs)
    for crit in ancestors_blocked:
        if _is_same_or_parent(norm_case, crit):
            return False, f"Từ chối xóa thư mục quan trọng hoặc thư mục cha của hệ thống ({norm})."

    for crit in descendants_blocked:
        if _is_same_or_parent(crit, norm_case):
            return False, f"Từ chối xóa dữ liệu bên trong thư mục hệ thống / ứng dụng ({norm})."

    for other_exe in other_game_exes:
        clean_other = (other_exe or "").strip().strip('"')
        if not clean_other:
            continue
        other_case = _norm_case_abs(clean_other)
        if _is_same_or_parent(norm_case, other_case):
            return False, f"Thư mục ({norm}) đang chứa trò chơi khác trong thư viện, từ chối xóa để bảo vệ dữ liệu."

    return True, ""


def resolve_game_install_dir(
    game_data: dict,
    other_game_exes: Sequence[str] = (),
    extra_protected_dirs: Sequence[str] = (),
) -> tuple[str, str]:
    """
    Determine the root installation folder for a game.
    Prefers install_location when valid & safe; otherwise steps up out of binary subfolders from exe_path.
    Returns (resolved_dir, refusal_reason).
    """
    install_loc = str((game_data or {}).get("install_location") or "").strip().strip('"')
    exe_path = str((game_data or {}).get("exe_path") or "").strip().strip('"')

    last_reason = ""
    if install_loc:
        norm_loc = os.path.normpath(os.path.abspath(install_loc))
        ok, reason = is_safe_delete_dir(
            norm_loc,
            other_game_exes=other_game_exes,
            extra_protected_dirs=extra_protected_dirs,
        )
        if ok and os.path.basename(norm_loc).strip().lower() not in _BINARY_SUBDIRS:
            return norm_loc, ""
        last_reason = reason

    if not exe_path:
        return "", last_reason or "Trò chơi chưa có đường dẫn file chạy (.exe)."

    curr = os.path.dirname(os.path.normpath(os.path.abspath(exe_path)))
    stepped_binary = False

    for _ in range(3):
        base = os.path.basename(curr).strip().lower()
        parent = os.path.dirname(curr)
        if parent == curr or base not in _BINARY_SUBDIRS:
            break
        ok, _ = is_safe_delete_dir(
            parent,
            other_game_exes=other_game_exes,
            extra_protected_dirs=extra_protected_dirs,
        )
        if not ok:
            break
        curr = parent
        stepped_binary = True

    if stepped_binary:
        parent = os.path.dirname(curr)
        if parent != curr:
            ok, _ = is_safe_delete_dir(
                parent,
                other_game_exes=other_game_exes,
                extra_protected_dirs=extra_protected_dirs,
            )
            if ok and (
                os.path.isdir(os.path.join(parent, "Engine"))
                or os.path.basename(curr).strip().lower() == "game"
            ):
                curr = parent

    ok, reason = is_safe_delete_dir(
        curr,
        other_game_exes=other_game_exes,
        extra_protected_dirs=extra_protected_dirs,
    )
    if ok:
        return curr, ""
    return "", reason


def find_running_process_in_dir(target_dir: str) -> str:
    """Return the process name if an executable inside target_dir is currently running, else ''."""
    if not target_dir or not os.path.isdir(target_dir):
        return ""
    target_case = _norm_case_abs(target_dir)
    own_pid = os.getpid()
    try:
        import psutil
        for proc in psutil.process_iter(["pid", "name", "exe"]):
            try:
                if proc.info.get("pid") == own_pid:
                    continue
                p_exe = proc.info.get("exe") or ""
                if p_exe and _is_same_or_parent(target_case, _norm_case_abs(p_exe)):
                    return str(proc.info.get("name") or os.path.basename(p_exe))
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess, OSError):
                continue
    except ImportError:
        pass
    return ""


def _rmtree_force_writable(target_dir: str) -> None:
    """Recursively delete target_dir, clearing read-only attributes on Windows when needed."""
    if sys.version_info >= (3, 12):
        def _onexc(func, path, _exc):
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
            func(path)
        shutil.rmtree(target_dir, onexc=_onexc)
    else:
        def _onerror(func, path, _exc_info):
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
            func(path)
        shutil.rmtree(target_dir, onerror=_onerror)


def uninstall_game(
    game_name: str,
    exe_path: str = "",
    install_dir: str = "",
    delete_save: bool = False,
    save_path: str = "",
    remove_steam_shortcut: bool = True,
    restart_steam: bool = False,
    steam_path: str | None = None,
    other_game_exes: Sequence[str] = (),
    extra_protected_dirs: Sequence[str] = (),
) -> dict:
    """
    Synchronously uninstall a game (intended to run on GameUninstallWorker QThread).
    Deletes the game folder, optionally deletes local save_path, and cleans Non-Steam shortcuts + grid artworks.
    """
    t0 = time.monotonic()
    logger.info(
        f"{TAG} Starting uninstall for {game_name!r} "
        f"(install_dir={install_dir!r}, delete_save={delete_save}, restart_steam={restart_steam})"
    )

    if not game_name:
        msg = "Thiếu tên trò chơi cần gỡ cài đặt."
        logger.warning(f"{TAG} Refused uninstall: {msg}")
        return {"success": False, "game_name": game_name, "error": msg}

    if not install_dir:
        msg = "Không xác định được thư mục cài đặt an toàn để gỡ bỏ."
        logger.warning(f"{TAG} Refused uninstall for {game_name!r}: {msg}")
        return {"success": False, "game_name": game_name, "error": msg}

    safe_ok, safe_reason = is_safe_delete_dir(
        install_dir,
        other_game_exes=other_game_exes,
        extra_protected_dirs=extra_protected_dirs,
    )
    if not safe_ok:
        logger.warning(f"{TAG} Blocked unsafe uninstall dir for {game_name!r}: {safe_reason}")
        return {"success": False, "game_name": game_name, "error": safe_reason}

    running_proc = find_running_process_in_dir(install_dir)
    if running_proc:
        msg = f"Trò chơi đang chạy ({running_proc}). Vui lòng đóng game trước khi gỡ cài đặt."
        logger.warning(f"{TAG} Aborted uninstall for {game_name!r}: process {running_proc!r} is running")
        return {"success": False, "game_name": game_name, "error": msg}

    folder_deleted = False
    norm_install = os.path.normpath(os.path.abspath(install_dir))
    if os.path.exists(norm_install):
        try:
            _rmtree_force_writable(norm_install)
            folder_deleted = True
            logger.info(f"{TAG} Deleted game directory for {game_name!r}: {norm_install}")
        except OSError as exc:
            elapsed = time.monotonic() - t0
            logger.error(
                f"{TAG} Failed to delete game directory {norm_install} for {game_name!r} "
                f"after {elapsed:.2f}s: {exc}",
                exc_info=True,
            )
            return {
                "success": False,
                "game_name": game_name,
                "error": (
                    f"Không thể xóa thư mục trò chơi:\n{norm_install}\n\n"
                    f"Chi tiết: {exc}\nVui lòng đóng các tiến trình đang mở file của game rồi thử lại."
                ),
            }
    else:
        logger.warning(f"{TAG} Game directory already absent on disk for {game_name!r}: {norm_install}")
        folder_deleted = True

    warnings: list[str] = []
    save_deleted = False
    clean_save = (save_path or "").strip().strip('"')
    if delete_save and clean_save and os.path.exists(clean_save):
        norm_save = os.path.normpath(os.path.abspath(clean_save))
        if os.path.isdir(norm_save):
            save_ok, save_reason = is_safe_delete_dir(
                norm_save,
                other_game_exes=other_game_exes,
                extra_protected_dirs=extra_protected_dirs,
            )
            if not save_ok:
                logger.warning(f"{TAG} Refused local save deletion for {game_name!r}: {save_reason}")
                warnings.append(save_reason)
            else:
                try:
                    _rmtree_force_writable(norm_save)
                    save_deleted = True
                    logger.info(f"{TAG} Deleted local save folder for {game_name!r}: {norm_save}")
                except OSError as exc:
                    logger.warning(f"{TAG} Could not delete local save folder {norm_save}: {exc}")
                    warnings.append(f"Không thể xóa hết thư mục Save ({exc}).")
        elif os.path.isfile(norm_save):
            parent_ok, parent_reason = is_safe_delete_dir(
                os.path.dirname(norm_save),
                other_game_exes=other_game_exes,
                extra_protected_dirs=extra_protected_dirs,
            )
            other_cases = {_norm_case_abs(e) for e in other_game_exes if e and str(e).strip()}
            if not parent_ok:
                logger.warning(f"{TAG} Refused local save file deletion for {game_name!r}: {parent_reason}")
                warnings.append(parent_reason)
            elif _is_same_or_parent(_norm_case_abs(CONFIG_DIR), _norm_case_abs(norm_save)):
                logger.warning(f"{TAG} Refused deleting save file inside CONFIG_DIR: {norm_save}")
                warnings.append("Từ chối xóa file save bên trong thư mục cấu hình của ứng dụng.")
            elif _norm_case_abs(norm_save) in other_cases:
                logger.warning(f"{TAG} Refused deleting save file that is another game executable: {norm_save}")
                warnings.append("Từ chối xóa file save trùng với file thực thi của game khác.")
            else:
                try:
                    os.chmod(norm_save, stat.S_IWRITE | stat.S_IREAD)
                    os.remove(norm_save)
                    save_deleted = True
                    logger.info(f"{TAG} Deleted local save file for {game_name!r}: {norm_save}")
                except OSError as exc:
                    logger.warning(f"{TAG} Could not delete local save file {norm_save}: {exc}")
                    warnings.append(f"Không thể xóa file Save ({exc}).")

    steam_removed_count = 0
    steam_removed_artworks = 0
    steam_was_running = False
    steam_restarted = False

    if remove_steam_shortcut:
        resolved_steam = steam_path or find_steam_path()
        if resolved_steam and has_non_steam_shortcut(game_name, exe_path, steam_path=resolved_steam):
            steam_was_running = is_steam_running()
            steam_res = remove_non_steam_game(
                game_name=game_name,
                exe_path=exe_path,
                steam_path=resolved_steam,
            )
            steam_removed_count = int(steam_res.get("removed_count", 0))
            steam_removed_artworks = int(steam_res.get("removed_artworks", 0))
            if steam_res.get("success"):
                logger.info(
                    f"{TAG} Removed {steam_removed_count} Non-Steam shortcut(s) and "
                    f"{steam_removed_artworks} artwork(s) for {game_name!r} (steam_running={steam_was_running})"
                )
            else:
                warn_msg = str(steam_res.get("message") or "Không thể cập nhật shortcuts.vdf của Steam.")
                logger.warning(f"{TAG} Non-Steam cleanup warning for {game_name!r}: {warn_msg}")
                warnings.append(warn_msg)

    elapsed = time.monotonic() - t0
    logger.info(
        f"{TAG} Completed uninstall for {game_name!r} in {elapsed:.2f}s "
        f"(folder_deleted={folder_deleted}, save_deleted={save_deleted}, "
        f"steam_shortcuts={steam_removed_count}, artworks={steam_removed_artworks})"
    )
    return {
        "success": True,
        "game_name": game_name,
        "install_dir": norm_install,
        "folder_deleted": folder_deleted,
        "save_deleted": save_deleted,
        "steam_removed_count": steam_removed_count,
        "steam_removed_artworks": steam_removed_artworks,
        "steam_was_running": steam_was_running,
        "steam_restarted": steam_restarted,
        "warnings": warnings,
        "elapsed": elapsed,
    }


class GameUninstallWorker(QObject):
    """Background QThread worker for uninstalling a game without freezing the UI."""

    finished = Signal(dict)

    def __init__(
        self,
        game_name: str,
        exe_path: str = "",
        install_dir: str = "",
        delete_save: bool = False,
        save_path: str = "",
        remove_steam_shortcut: bool = True,
        restart_steam: bool = False,
        steam_path: str | None = None,
        other_game_exes: Sequence[str] = (),
        extra_protected_dirs: Sequence[str] = (),
        parent: QObject | None = None,
    ):
        super().__init__(parent)
        self.game_name = game_name
        self.exe_path = exe_path
        self.install_dir = install_dir
        self.delete_save = delete_save
        self.save_path = save_path
        self.remove_steam_shortcut = remove_steam_shortcut
        self.restart_steam = restart_steam
        self.steam_path = steam_path
        self.other_game_exes = list(other_game_exes)
        self.extra_protected_dirs = list(extra_protected_dirs)

    @Slot()
    def run(self):
        try:
            result = uninstall_game(
                game_name=self.game_name,
                exe_path=self.exe_path,
                install_dir=self.install_dir,
                delete_save=self.delete_save,
                save_path=self.save_path,
                remove_steam_shortcut=self.remove_steam_shortcut,
                restart_steam=self.restart_steam,
                steam_path=self.steam_path,
                other_game_exes=self.other_game_exes,
                extra_protected_dirs=self.extra_protected_dirs,
            )
            self.finished.emit(result)
        except Exception as exc:
            logger.exception(f"{TAG} Unexpected error in GameUninstallWorker for {self.game_name!r}")
            self.finished.emit({
                "success": False,
                "game_name": self.game_name,
                "error": f"Lỗi không mong muốn khi gỡ cài đặt: {exc}",
            })
