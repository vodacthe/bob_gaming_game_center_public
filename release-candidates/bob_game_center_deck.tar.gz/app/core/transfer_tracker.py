"""
Transfer progress tracker for cloud upload/download operations.
Calculates real-time transfer speed, file progress, and byte counts in a thread-safe manner.
"""

import time
import threading
from collections import deque
from typing import Callable, Dict, Optional


def format_speed(bps: float) -> str:
    """Format bytes per second into a human-readable string (KB/s, MB/s)."""
    if bps <= 0:
        return "0 KB/s"
    if bps < 1024 * 1024:
        return f"{bps / 1024:.1f} KB/s"
    return f"{bps / (1024 * 1024):.1f} MB/s"


def format_bytes(num_bytes: int) -> str:
    """Format bytes into B, KB, MB, GB."""
    if num_bytes < 1024:
        return f"{num_bytes} B"
    if num_bytes < 1024 * 1024:
        return f"{num_bytes / 1024:.1f} KB"
    if num_bytes < 1024 * 1024 * 1024:
        return f"{num_bytes / (1024 * 1024):.1f} MB"
    return f"{num_bytes / (1024 * 1024 * 1024):.2f} GB"


class TransferProgressTracker:
    """
    Thread-safe tracker for tracking file counts, chunk-level bytes transferred,
    and smoothed real-time transfer speed.
    """

    def __init__(
        self,
        total_files: int,
        file_sizes: Optional[Dict[str, int]] = None,
        callback: Optional[Callable] = None,
        min_interval: float = 0.1,
    ):
        self.total_files = max(0, total_files)
        self.file_sizes: Dict[str, int] = dict(file_sizes) if file_sizes else {}
        self.total_bytes = sum(max(0, s) for s in self.file_sizes.values())
        self.callback = callback
        self.min_interval = min_interval

        self.completed_files = 0
        self.file_bytes_done: Dict[str, int] = {f: 0 for f in self.file_sizes}
        self.total_bytes_done = 0
        self.lock = threading.Lock()

        self.start_time = time.time()
        self.last_update_time = 0.0
        self.current_speed = 0.0
        self.history: deque = deque()  # (timestamp, bytes_done)

    def set_file_size_if_unknown(self, rel_path: str, size: int):
        """Update or register file size dynamically if not known upfront."""
        with self.lock:
            old_size = self.file_sizes.get(rel_path, 0)
            if size > old_size:
                self.file_sizes[rel_path] = size
                self.total_bytes += (size - old_size)

    def update_file_chunk(self, rel_path: str, bytes_in_file: int):
        """Update progress for a specific file chunk."""
        with self.lock:
            prev_bytes = self.file_bytes_done.get(rel_path, 0)
            if bytes_in_file > prev_bytes:
                diff = bytes_in_file - prev_bytes
                self.file_bytes_done[rel_path] = bytes_in_file
                self.total_bytes_done += diff

                # Adjust total_bytes if file was larger than initially anticipated
                known_size = self.file_sizes.get(rel_path, 0)
                if bytes_in_file > known_size:
                    self.total_bytes += (bytes_in_file - known_size)
                    self.file_sizes[rel_path] = bytes_in_file

                self._record_speed_sample()

                now = time.time()
                if now - self.last_update_time >= self.min_interval:
                    self.last_update_time = now
                    self._emit_callback()

    def file_completed(self, rel_path: str):
        """Mark a file as completely transferred."""
        with self.lock:
            known_size = self.file_sizes.get(rel_path, 0)
            prev_bytes = self.file_bytes_done.get(rel_path, 0)
            if known_size > prev_bytes:
                diff = known_size - prev_bytes
                self.file_bytes_done[rel_path] = known_size
                self.total_bytes_done += diff

            self.completed_files += 1
            self._record_speed_sample()

            now = time.time()
            self.last_update_time = now
            self._emit_callback()

    def _record_speed_sample(self):
        """Record timestamp and byte count to calculate rolling smoothed speed."""
        now = time.time()
        self.history.append((now, self.total_bytes_done))

        # Keep rolling window to last 1.5 seconds
        while self.history and now - self.history[0][0] > 1.5:
            self.history.popleft()

        if len(self.history) >= 2:
            t_delta = self.history[-1][0] - self.history[0][0]
            b_delta = self.history[-1][1] - self.history[0][1]
            if t_delta > 0.05:
                instant_speed = b_delta / t_delta
                if self.current_speed > 0:
                    self.current_speed = 0.6 * self.current_speed + 0.4 * instant_speed
                else:
                    self.current_speed = instant_speed
        elif now - self.start_time > 0.1:
            self.current_speed = self.total_bytes_done / (now - self.start_time)

    def _emit_callback(self):
        """Invoke callback with current stats: (completed_files, total_files, speed, bytes_done, total_bytes)."""
        if not self.callback:
            return
        try:
            self.callback(
                self.completed_files,
                self.total_files,
                self.current_speed,
                self.total_bytes_done,
                self.total_bytes,
            )
        except Exception:
            pass
