import os
import json
import logging
import hashlib
from typing import Dict, Any
from app.config import get_app_dir

logger = logging.getLogger(__name__)

# ~/.bobgaming/sync_state.json
def _get_state_file() -> str:
    from app.config import CONFIG_DIR
    return os.path.join(CONFIG_DIR, "sync_state.json")

class SyncStateManager:
    """
    Manages the local state of file synchronization to support delta syncs.
    Structure:
    {
        "Game Name": {
            "saves/profile.dat": {"mtime": 170000000.0, "size": 1024},
            ...
        }
    }
    """
    def __init__(self):
        self.state_file = _get_state_file()
        self.state: Dict[str, Dict[str, Dict[str, Any]]] = self._load_state()

    def _load_state(self) -> dict:
        if not os.path.exists(self.state_file):
            return {}
        try:
            with open(self.state_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load sync state: {e}")
            return {}

    def save_state(self):
        try:
            os.makedirs(os.path.dirname(self.state_file), exist_ok=True)
            with open(self.state_file, "w", encoding="utf-8") as f:
                json.dump(self.state, f, indent=4)
        except Exception as e:
            logger.error(f"Failed to save sync state: {e}")

    def get_game_state(self, game_name: str) -> dict:
        """Get the last known state of files for a game."""
        return self.state.get(game_name, {})

    def update_game_state(self, game_name: str, new_state: dict):
        """Overwrite the tracked state for a game."""
        self.state[game_name] = new_state
        self.save_state()

    def remove_game_state(self, game_name: str):
        """Remove tracked state for a game."""
        if game_name in self.state:
            del self.state[game_name]
            self.save_state()

    @staticmethod
    def scan_local_directory(local_path: str, exclude_filter=None) -> dict:
        """
        Scan a local directory and return a dict of relative_path -> {mtime, size}.
        Optionally filters out files and directories matching exclude_filter.
        """
        state = {}
        if not os.path.exists(local_path):
            return state

        for root, dirs, files in os.walk(local_path):
            rel_root = os.path.relpath(root, local_path).replace("\\", "/")
            if rel_root == ".":
                rel_root = ""

            # Prune excluded directories from descending
            if exclude_filter:
                dirs[:] = [
                    d for d in dirs
                    if not exclude_filter.is_excluded(f"{rel_root}/{d}" if rel_root else d, is_dir=True)
                ]

            for f in files:
                rel_path = os.path.relpath(os.path.join(root, f), local_path).replace("\\", "/")
                if exclude_filter and exclude_filter.is_excluded(rel_path, is_dir=False):
                    continue

                file_path = os.path.join(root, f)
                try:
                    stat = os.stat(file_path)
                    state[rel_path] = {
                        "mtime": stat.st_mtime,
                        "size": stat.st_size
                    }
                except OSError:
                    pass
        return state
