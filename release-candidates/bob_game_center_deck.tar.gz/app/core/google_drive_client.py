"""
Google Drive client for Bob Gaming Game Center.
Handles all cloud storage operations via Google Drive API v3.

SETUP INSTRUCTIONS:
1. Go to https://console.cloud.google.com/
2. Create a new project (or select existing)
3. Enable "Google Drive API" (APIs & Services > Library)
4. Create OAuth 2.0 credentials (APIs & Services > Credentials > Create > OAuth client ID)
   - Application type: "Desktop app"
5. Copy the Client ID and Client Secret below
"""

import io
import os
import json
import logging
import threading
import functools
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

from app.core.secret_mask import decrypt
from app.config import CLOUD_ROOT_FOLDER, CONFIG_DIR, SAVE_LOCATION_FILENAME, BOBIGNORE_FILENAME
from app.core.cloud_provider import CloudProvider
from app.core.transfer_tracker import TransferProgressTracker

logger = logging.getLogger(__name__)

# ── Thread Safety Decorator ─────────────────────────────────────────
def synchronized(method):
    """Decorator to ensure thread safety for Google Drive client operations."""
    @functools.wraps(method)
    def wrapper(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    return wrapper

# ── OAuth2 Credentials ──────────────────────────────────────────────
# Replace with your own credentials from Google Cloud Console.
GOOGLE_CLIENT_ID = "1037271699108-2n93j7blnn3f7g15k4rigid6um16jhhp.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET = decrypt("2umuAEXEy_QvAx664hAV5ESkwqynCIq0UXu2j-ENdo6tFF_ute7VTR1HYvldj1_jTF5SdqUrkNjfd__aecTz")
SCOPES = ["https://www.googleapis.com/auth/drive.file"]

TOKEN_FILE = os.path.join(CONFIG_DIR, "gdrive_token.json")

# Google Drive MIME type for folders
_FOLDER_MIME = "application/vnd.google-apps.folder"


class GoogleDriveClient(CloudProvider):
    """Client for Google Drive API v3 operations."""

    def __init__(self):
        self._lock = threading.RLock()
        self.service = None
        self.creds = None
        self._folder_id_cache: dict[str, str] = {}  # path -> folder_id
        self._thread_local = threading.local()

    def _get_thread_service(self):
        """Get or initialize a thread-local Google Drive API service for concurrent operations."""
        if not hasattr(self._thread_local, "service") or self._thread_local.service is None:
            if not self.creds:
                return self.service
            try:
                import httplib2
                import google_auth_httplib2
                from googleapiclient.discovery import build
                http = httplib2.Http(timeout=60)
                authorized_http = google_auth_httplib2.AuthorizedHttp(self.creds, http=http)
                self._thread_local.service = build("drive", "v3", http=authorized_http, cache_discovery=False)
            except Exception as e:
                logger.warning(f"Could not build thread-local service: {e}, using main service")
                return self.service
        return self._thread_local.service


    # ── Authentication ───────────────────────────────────────────────

    @synchronized
    def authenticate(self) -> bool:
        """Run OAuth2 flow or load saved token. Returns True on success."""
        try:
            from google.oauth2.credentials import Credentials
            from google_auth_oauthlib.flow import InstalledAppFlow
            from google.auth.transport.requests import Request
            from googleapiclient.discovery import build
            import google_auth_httplib2

            # Load saved token
            if os.path.exists(TOKEN_FILE):
                self.creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)

            # Refresh or run new flow
            if not self.creds or not self.creds.valid:
                if self.creds and self.creds.expired and self.creds.refresh_token:
                    self.creds.refresh(Request())
                else:
                    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
                        logger.error("Google Drive credentials not configured")
                        return False

                    client_config = {
                        "installed": {
                            "client_id": GOOGLE_CLIENT_ID,
                            "client_secret": GOOGLE_CLIENT_SECRET,
                            "redirect_uris": ["http://localhost"],
                            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                            "token_uri": "https://oauth2.googleapis.com/token",
                        }
                    }
                    flow = InstalledAppFlow.from_client_config(client_config, SCOPES)
                    self.creds = flow.run_local_server(port=0)

                # Save token for next time
                with open(TOKEN_FILE, "w", encoding="utf-8") as f:
                    f.write(self.creds.to_json())

            import httplib2
            http = httplib2.Http(timeout=30)
            authorized_http = google_auth_httplib2.AuthorizedHttp(self.creds, http=http)
            self.service = build("drive", "v3", http=authorized_http)

            # Retrieve user email or display name
            try:
                about = self.service.about().get(fields="user").execute()
                user_info = about.get("user", {})
                email = user_info.get("emailAddress", "")
                display_name = user_info.get("displayName", "")
                from app.config import load_config, save_config
                cfg = load_config()
                if email or display_name:
                    cfg["username"] = email or display_name
                if cfg.get("cloud_url") == "https://drive.vdthe.com":
                    cfg["cloud_url"] = ""
                save_config(cfg)
            except Exception as ex:
                logger.debug(f"Could not retrieve Google user profile: {ex}")

            return True

        except Exception as e:
            logger.error(f"Google Drive authentication failed: {e}")
            return False

    @staticmethod
    def is_token_saved() -> bool:
        """Check if a saved Google token exists."""
        return os.path.exists(TOKEN_FILE)

    @staticmethod
    def clear_token():
        """Remove saved token (logout)."""
        if os.path.exists(TOKEN_FILE):
            os.remove(TOKEN_FILE)

    # ── CloudProvider interface ──────────────────────────────────────

    @synchronized
    def test_connection(self) -> bool:
        try:
            if not self.service:
                return False
            self.service.files().list(pageSize=1, fields="files(id)").execute()
            return True
        except Exception as e:
            logger.error(f"Google Drive connection test failed: {e}")
            return False

    @synchronized
    def check_game_exists(self, game_name: str) -> bool:
        try:
            root_id = self._get_folder_id(CLOUD_ROOT_FOLDER)
            if not root_id:
                return False
            game_id = self._get_folder_id(game_name, parent_id=root_id)
            return game_id is not None
        except Exception as e:
            logger.error(f"Failed to check game exists: {e}")
            return False

    @synchronized
    def create_game_folder(self, game_name: str):
        root_id = self._get_or_create_folder(CLOUD_ROOT_FOLDER)
        game_id = self._get_or_create_folder(game_name, parent_id=root_id)
        self._get_or_create_folder("saves", parent_id=game_id)

    def get_saves_path(self, game_name: str) -> str:
        return f"{CLOUD_ROOT_FOLDER}/{game_name}/saves"

    @synchronized
    def list_directory_recursive(self, remote_path: str) -> dict:
        state = {}
        try:
            folder_id = self._resolve_path_to_id(remote_path)
            if not folder_id:
                return state
            self._list_folder_recursive(folder_id, "", state)
        except Exception as e:
            logger.error(f"Failed to list directory {remote_path}: {e}")
        return state

    @synchronized
    def delete_remote_files(self, remote_base: str, rel_paths: list[str]):
        try:
            base_id = self._resolve_path_to_id(remote_base)
            if not base_id:
                return
            for rel_path in rel_paths:
                file_id = self._find_file_by_path(base_id, rel_path)
                if file_id:
                    self.service.files().delete(fileId=file_id).execute()
                    logger.info(f"Deleted remote file: {rel_path}")
        except Exception as e:
            logger.error(f"Failed to delete remote files: {e}")

    def upload_delta(self, local_base: str, remote_base: str,
                     files_to_upload: list[str], progress_callback=None):
        from googleapiclient.http import MediaFileUpload

        with self._lock:
            base_id = self._resolve_path_to_id(remote_base)
            if not base_id:
                base_id = self._ensure_path(remote_base)

            # Pre-create any required directory structures under lock
            folder_cache = {}
            for rel_path in files_to_upload:
                parts = rel_path.replace("\\", "/").split("/")
                parent_id = base_id
                current_path = ""
                for part in parts[:-1]:
                    current_path = f"{current_path}/{part}" if current_path else part
                    if current_path not in folder_cache:
                        folder_cache[current_path] = self._get_or_create_folder(part, parent_id=parent_id)
                    parent_id = folder_cache[current_path]

            # Fast single batch query for all existing files in remote_base
            remote_state = self.list_directory_recursive(remote_base)
            existing_file_ids = {
                path: info.get("id")
                for path, info in remote_state.items()
            }

        total = len(files_to_upload)
        if total == 0:
            return

        file_sizes = {}
        for rel_path in files_to_upload:
            local_file = os.path.join(local_base, rel_path)
            try:
                file_sizes[rel_path] = os.path.getsize(local_file) if os.path.exists(local_file) else 0
            except OSError:
                file_sizes[rel_path] = 0

        tracker = TransferProgressTracker(
            total_files=total,
            file_sizes=file_sizes,
            callback=progress_callback,
        )

        def _upload_single_file(rel_path: str):
            local_file = os.path.join(local_base, rel_path)
            if not os.path.exists(local_file):
                tracker.file_completed(rel_path)
                return

            parts = rel_path.replace("\\", "/").split("/")
            if len(parts) > 1:
                parent_path = "/".join(parts[:-1])
                parent_id = folder_cache.get(parent_path, base_id)
            else:
                parent_id = base_id

            filename = parts[-1]
            existing_id = existing_file_ids.get(rel_path)
            file_size = file_sizes.get(rel_path, 0)
            
            # Use multipart upload (resumable=False) for save files to avoid 308 redirect issues
            # and achieve 2x faster upload speed. Resumable only for very large files (>20MB).
            is_large = file_size > 20 * 1024 * 1024
            media = MediaFileUpload(local_file, resumable=is_large)
            svc = self._get_thread_service()

            try:
                if existing_id:
                    request = svc.files().update(
                        fileId=existing_id, media_body=media
                    )
                else:
                    metadata = {"name": filename, "parents": [parent_id]}
                    request = svc.files().create(
                        body=metadata, media_body=media, fields="id"
                    )

                if not is_large or file_size == 0:
                    request.execute()
                else:
                    response = None
                    while response is None:
                        status, response = request.next_chunk()
                        if status:
                            tracker.update_file_chunk(rel_path, status.resumable_progress)
                        elif response is not None:
                            tracker.update_file_chunk(rel_path, file_size)

                tracker.file_completed(rel_path)
                logger.info(f"[GoogleDrive] Uploaded (parallel): {rel_path}")
            except Exception as e:
                logger.error(f"[GoogleDrive] Failed to upload {rel_path}: {e}")
                raise e

        workers = min(4, total)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(_upload_single_file, p) for p in files_to_upload]
            for f in as_completed(futures):
                f.result()

    def download_delta(self, remote_base: str, local_base: str,
                       files_to_download: list[str], progress_callback=None,
                       file_sizes: dict[str, int] = None):
        from googleapiclient.http import MediaIoBaseDownload

        with self._lock:
            base_id = self._resolve_path_to_id(remote_base)
            if not base_id:
                raise FileNotFoundError(f"Remote path not found: {remote_base}")
            remote_state = self.list_directory_recursive(remote_base)
            file_id_map = {
                path: info.get("id")
                for path, info in remote_state.items()
                if path in files_to_download
            }
            # Fallback for any file not in remote_state map
            for rel_path in files_to_download:
                if rel_path not in file_id_map:
                    fid = self._find_file_by_path(base_id, rel_path)
                    if fid:
                        file_id_map[rel_path] = fid

        total = len(files_to_download)
        if total == 0:
            return

        tracker = TransferProgressTracker(
            total_files=total,
            file_sizes=file_sizes,
            callback=progress_callback,
        )

        def _download_single_file(rel_path: str):
            file_id = file_id_map.get(rel_path)
            if not file_id:
                logger.error(f"File not found on Drive: {rel_path}")
                tracker.file_completed(rel_path)
                return

            local_file = os.path.join(local_base, rel_path)
            os.makedirs(os.path.dirname(local_file), exist_ok=True)

            svc = self._get_thread_service()
            try:
                request = svc.files().get_media(fileId=file_id)
                with open(local_file, "wb") as f:
                    downloader = MediaIoBaseDownload(f, request, chunksize=512 * 1024)
                    done = False
                    while not done:
                        status, done = downloader.next_chunk()
                        if status:
                            if getattr(downloader, "_total_size", None):
                                tracker.set_file_size_if_unknown(rel_path, downloader._total_size)
                            tracker.update_file_chunk(rel_path, status.resumable_progress)
                        elif done and getattr(downloader, "_total_size", None):
                            tracker.update_file_chunk(rel_path, downloader._total_size)

                if os.path.exists(local_file):
                    tracker.set_file_size_if_unknown(rel_path, os.path.getsize(local_file))
                tracker.file_completed(rel_path)
                logger.info(f"[GoogleDrive] Downloaded (parallel): {rel_path}")
            except Exception as e:
                logger.error(f"[GoogleDrive] Failed to download {rel_path}: {e}")
                raise e

        workers = min(4, total)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(_download_single_file, p) for p in files_to_download]
            for f in as_completed(futures):
                f.result()

    @synchronized
    def upload_save_location(self, game_name: str, local_save_path: str):
        from googleapiclient.http import MediaInMemoryUpload

        self.create_game_folder(game_name)
        root_id = self._get_folder_id(CLOUD_ROOT_FOLDER)
        game_id = self._get_folder_id(game_name, parent_id=root_id)

        content = local_save_path.encode("utf-8")
        media = MediaInMemoryUpload(content, mimetype="text/plain")

        existing_id = self._get_file_id(SAVE_LOCATION_FILENAME, game_id)
        if existing_id:
            self.service.files().update(
                fileId=existing_id, media_body=media
            ).execute()
        else:
            metadata = {
                "name": SAVE_LOCATION_FILENAME,
                "parents": [game_id],
            }
            self.service.files().create(
                body=metadata, media_body=media, fields="id"
            ).execute()
        logger.info(f"Uploaded {SAVE_LOCATION_FILENAME} for {game_name}")

    @synchronized
    def get_save_location(self, game_name: str) -> str | None:
        from googleapiclient.http import MediaIoBaseDownload

        try:
            root_id = self._get_folder_id(CLOUD_ROOT_FOLDER)
            if not root_id:
                return None
            game_id = self._get_folder_id(game_name, parent_id=root_id)
            if not game_id:
                return None

            # Try OS-specific file first, fallback to generic
            file_id = self._get_file_id(SAVE_LOCATION_FILENAME, game_id)
            if not file_id:
                file_id = self._get_file_id("save_location.txt", game_id)
            if not file_id:
                return None

            request = self.service.files().get_media(fileId=file_id)
            buffer = io.BytesIO()
            downloader = MediaIoBaseDownload(buffer, request)
            done = False
            while not done:
                _, done = downloader.next_chunk()

            return buffer.getvalue().decode("utf-8").strip()
        except Exception as e:
            logger.error(f"Failed to read save_location for {game_name}: {e}")
            return None

    @synchronized
    def upload_bobignore(self, game_name: str, content: str):
        """Upload .bobignore to game root folder on Google Drive (alongside save_location_<platform>.txt)."""
        from googleapiclient.http import MediaInMemoryUpload

        self.create_game_folder(game_name)
        root_id = self._get_folder_id(CLOUD_ROOT_FOLDER)
        if not root_id:
            return
        game_id = self._get_folder_id(game_name, parent_id=root_id)
        if not game_id:
            return

        # 1. Clean up legacy .bobignore inside saves/ folder if present
        saves_id = self._get_folder_id("saves", parent_id=game_id)
        if saves_id:
            legacy_id = self._get_file_id(BOBIGNORE_FILENAME, saves_id)
            if legacy_id:
                try:
                    self.service.files().delete(fileId=legacy_id).execute()
                    logger.info(f"Cleaned up legacy {BOBIGNORE_FILENAME} inside saves/ for {game_name}")
                except Exception as e:
                    logger.warning(f"Could not delete legacy {BOBIGNORE_FILENAME} in saves/: {e}")

        # 2. Upload .bobignore to game_id (game root folder, alongside save_location_<platform>.txt)
        data = content.encode("utf-8")
        media = MediaInMemoryUpload(data, mimetype="text/plain")

        existing_id = self._get_file_id(BOBIGNORE_FILENAME, game_id)
        if existing_id:
            self.service.files().update(
                fileId=existing_id, media_body=media
            ).execute()
        else:
            metadata = {
                "name": BOBIGNORE_FILENAME,
                "parents": [game_id],
            }
            self.service.files().create(
                body=metadata, media_body=media, fields="id"
            ).execute()
        logger.info(f"Uploaded {BOBIGNORE_FILENAME} for {game_name} to game root folder (alongside {SAVE_LOCATION_FILENAME})")

    @synchronized
    def get_bobignore(self, game_name: str) -> str | None:
        """Read .bobignore from game root folder on Google Drive. Falls back to saves/ folder."""
        from googleapiclient.http import MediaIoBaseDownload

        try:
            root_id = self._get_folder_id(CLOUD_ROOT_FOLDER)
            if not root_id:
                return None
            game_id = self._get_folder_id(game_name, parent_id=root_id)
            if not game_id:
                return None

            # Look in game root folder first
            file_id = self._get_file_id(BOBIGNORE_FILENAME, game_id)
            if not file_id:
                # Fallback to legacy location in saves/
                saves_id = self._get_folder_id("saves", parent_id=game_id)
                if saves_id:
                    file_id = self._get_file_id(BOBIGNORE_FILENAME, saves_id)

            if not file_id:
                return None

            request = self.service.files().get_media(fileId=file_id)
            buffer = io.BytesIO()
            downloader = MediaIoBaseDownload(buffer, request)
            done = False
            while not done:
                _, done = downloader.next_chunk()

            return buffer.getvalue().decode("utf-8", errors="ignore")
        except Exception as e:
            logger.error(f"Failed to read {BOBIGNORE_FILENAME} for {game_name}: {e}")
            return None

    @synchronized
    def delete_bobignore(self, game_name: str):
        """Delete .bobignore from Google Drive game folder."""
        try:
            root_id = self._get_folder_id(CLOUD_ROOT_FOLDER)
            if not root_id:
                return
            game_id = self._get_folder_id(game_name, parent_id=root_id)
            if not game_id:
                return

            file_id = self._get_file_id(BOBIGNORE_FILENAME, game_id)
            if file_id:
                self.service.files().delete(fileId=file_id).execute()
                logger.info(f"Deleted {BOBIGNORE_FILENAME} for {game_name}")

            # Also clean legacy in saves/ if any
            saves_id = self._get_folder_id("saves", parent_id=game_id)
            if saves_id:
                leg_id = self._get_file_id(BOBIGNORE_FILENAME, saves_id)
                if leg_id:
                    self.service.files().delete(fileId=leg_id).execute()
        except Exception as e:
            logger.error(f"Failed to delete {BOBIGNORE_FILENAME} for {game_name}: {e}")

    @synchronized
    def list_synced_games(self) -> list[str]:
        try:
            root_id = self._get_or_create_folder(CLOUD_ROOT_FOLDER)
            query = (
                f"'{root_id}' in parents "
                f"and mimeType='{_FOLDER_MIME}' "
                f"and trashed=false"
            )
            games = []
            page_token = None
            while True:
                resp = self.service.files().list(
                    q=query, spaces="drive",
                    fields="nextPageToken, files(id, name)",
                    pageToken=page_token,
                ).execute()
                for f in resp.get("files", []):
                    games.append(f["name"])
                page_token = resp.get("nextPageToken")
                if not page_token:
                    break
            return games
        except Exception as e:
            logger.error(f"Failed to list synced games: {e}")
            return []

    @synchronized
    def get_remote_modified_time(self, game_name: str) -> float | None:
        try:
            saves_path = self.get_saves_path(game_name)
            folder_id = self._resolve_path_to_id(saves_path)
            if not folder_id:
                return None

            # Get the most recent file modification time in the saves folder
            query = f"'{folder_id}' in parents and trashed=false"
            resp = self.service.files().list(
                q=query, spaces="drive",
                fields="files(modifiedTime)",
                orderBy="modifiedTime desc",
                pageSize=1,
            ).execute()

            files = resp.get("files", [])
            if not files:
                return None

            mod_str = files[0]["modifiedTime"]
            dt = datetime.fromisoformat(mod_str.replace("Z", "+00:00"))
            return dt.timestamp()
        except Exception as e:
            logger.error(f"Failed to get remote modified time for {game_name}: {e}")
            return None

    @synchronized
    def check_saves_exist(self, game_name: str) -> bool:
        try:
            saves_path = self.get_saves_path(game_name)
            folder_id = self._resolve_path_to_id(saves_path)
            return folder_id is not None
        except Exception:
            return False

    @synchronized
    def delete_game_folder(self, game_name: str) -> bool:
        """Delete an entire game's folder from Google Drive."""
        try:
            root_id = self._get_folder_id(CLOUD_ROOT_FOLDER)
            if not root_id:
                return False
            game_id = self._get_folder_id(game_name, parent_id=root_id)
            if not game_id:
                return False
            self.service.files().delete(fileId=game_id).execute()
            # Clear cached IDs for this game
            to_remove = [k for k in self._folder_id_cache if game_name in k]
            for k in to_remove:
                del self._folder_id_cache[k]
            logger.info(f"Deleted cloud game folder for {game_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete cloud game folder for {game_name}: {e}")
            return False


    # ── Internal helpers ─────────────────────────────────────────────

    @synchronized
    def _get_folder_id(self, name: str, parent_id: str = None) -> str | None:
        """Find a folder by name. Returns folder ID or None."""
        cache_key = f"{parent_id or 'root'}/{name}"
        if cache_key in self._folder_id_cache:
            return self._folder_id_cache[cache_key]

        query = (
            f"name='{name}' "
            f"and mimeType='{_FOLDER_MIME}' "
            f"and trashed=false"
        )
        if parent_id:
            query += f" and '{parent_id}' in parents"

        resp = self.service.files().list(
            q=query, spaces="drive", fields="files(id)"
        ).execute()
        files = resp.get("files", [])
        if files:
            fid = files[0]["id"]
            self._folder_id_cache[cache_key] = fid
            return fid
        return None

    @synchronized
    def _get_or_create_folder(self, name: str, parent_id: str = None) -> str:
        """Find or create a folder. Returns folder ID."""
        fid = self._get_folder_id(name, parent_id)
        if fid:
            return fid

        metadata = {"name": name, "mimeType": _FOLDER_MIME}
        if parent_id:
            metadata["parents"] = [parent_id]

        result = self.service.files().create(
            body=metadata, fields="id"
        ).execute()
        fid = result["id"]

        cache_key = f"{parent_id or 'root'}/{name}"
        self._folder_id_cache[cache_key] = fid
        return fid

    @synchronized
    def _get_file_id(self, name: str, parent_id: str) -> str | None:
        """Find a file by name in a folder. Returns file ID or None."""
        query = (
            f"name='{name}' "
            f"and '{parent_id}' in parents "
            f"and trashed=false "
            f"and mimeType!='{_FOLDER_MIME}'"
        )
        resp = self.service.files().list(
            q=query, spaces="drive", fields="files(id)"
        ).execute()
        files = resp.get("files", [])
        return files[0]["id"] if files else None

    @synchronized
    def _resolve_path_to_id(self, path: str) -> str | None:
        """Resolve 'BobGamingGameCenter/Game/saves' to a folder ID."""
        parts = path.strip("/").split("/")
        current_id = None
        for part in parts:
            fid = self._get_folder_id(part, parent_id=current_id)
            if not fid:
                return None
            current_id = fid
        return current_id

    @synchronized
    def _ensure_path(self, path: str) -> str:
        """Ensure all folders in path exist. Returns the leaf folder ID."""
        parts = path.strip("/").split("/")
        current_id = None
        for part in parts:
            current_id = self._get_or_create_folder(part, parent_id=current_id)
        return current_id

    @synchronized
    def _find_file_by_path(self, base_folder_id: str, rel_path: str) -> str | None:
        """Find a file by its relative path from a base folder."""
        parts = rel_path.replace("\\", "/").split("/")
        current_id = base_folder_id

        # Navigate to parent folder
        for part in parts[:-1]:
            current_id = self._get_folder_id(part, parent_id=current_id)
            if not current_id:
                return None

        # Find the file
        return self._get_file_id(parts[-1], current_id)

    @synchronized
    def _list_folder_recursive(self, folder_id: str, prefix: str, state: dict):

        """Recursively list folder contents into state dict."""
        page_token = None
        while True:
            resp = self.service.files().list(
                q=f"'{folder_id}' in parents and trashed=false",
                spaces="drive",
                fields="nextPageToken, files(id, name, mimeType, size, modifiedTime)",
                pageToken=page_token,
            ).execute()

            for item in resp.get("files", []):
                rel_path = f"{prefix}{item['name']}" if prefix else item["name"]

                if item["mimeType"] == _FOLDER_MIME:
                    self._list_folder_recursive(item["id"], f"{rel_path}/", state)
                else:
                    mod_str = item.get("modifiedTime", "")
                    mtime = 0.0
                    if mod_str:
                        try:
                            dt = datetime.fromisoformat(
                                mod_str.replace("Z", "+00:00")
                            )
                            mtime = dt.timestamp()
                        except ValueError:
                            pass
                    state[rel_path] = {
                        "mtime": mtime,
                        "size": int(item.get("size", 0)),
                    }

            page_token = resp.get("nextPageToken")
            if not page_token:
                break
