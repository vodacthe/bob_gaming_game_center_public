"""
SteamGridDB image cache for Bob Gaming Game Center.
Downloads and caches game cover art from SteamGridDB.
"""

import os
import time
import logging

import requests
from PySide6.QtGui import QImageReader, QPainter, QColor, QFont, QLinearGradient, QPixmap, QPen
from PySide6.QtCore import Qt, QBuffer, QByteArray, QIODevice, QRectF

from app.config import IMAGE_CACHE_DIR
from app.utils.helpers import sanitize_filename

logger = logging.getLogger(__name__)
TAG = "[ImageCache]"
MIN_COVER_DIM = 121  # Rejects <=120px anti-hotlink stubs (e.g. online-fix 100x100 smiley placeholder)


def _read_cover_size_bytes(data: bytes) -> tuple[int, int]:
    """Read image header dimensions from raw bytes without decoding full pixel buffer."""
    if not data or len(data) < 64:
        return (0, 0)
    ba = QByteArray(data)
    buf = QBuffer(ba)
    if not buf.open(QIODevice.OpenModeFlag.ReadOnly):
        return (0, 0)
    try:
        reader = QImageReader(buf)
        reader.setDecideFormatFromContent(True)
        sz = reader.size()
        return (sz.width(), sz.height()) if sz.isValid() else (0, 0)
    finally:
        buf.close()


def is_valid_cover_bytes(data: bytes) -> bool:
    """Return True if raw image bytes represent a valid game cover larger than anti-hotlink stubs."""
    w, h = _read_cover_size_bytes(data)
    return w >= MIN_COVER_DIM and h >= MIN_COVER_DIM


def is_valid_cover_file(path: str) -> bool:
    """Return True if file exists and contains a valid game cover larger than anti-hotlink stubs."""
    if not path or not os.path.isfile(path):
        return False
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return False
    return is_valid_cover_bytes(data)


def _detect_image_ext(data: bytes, default: str = ".jpg") -> str:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    return default


class ImageCache:
    """Manages game cover art caching from SteamGridDB."""

    def __init__(self, api_key: str = ""):
        self.api_key = api_key
        self.sgdb = None
        self._fallback_urls: dict[str, str] = {}

        if self.api_key:
            try:
                from steamgrid import SteamGridDB
                self.sgdb = SteamGridDB(self.api_key)
                logger.info("SteamGridDB client initialized")
            except ImportError:
                logger.warning("python-steamgriddb not installed, using placeholders")
            except Exception as e:
                logger.error(f"Failed to init SteamGridDB: {e}")

    def has_api_key(self) -> bool:
        """Check if API key is configured."""
        return bool(self.api_key and self.sgdb)

    def set_fallback_url(self, game_name: str, poster_url: str) -> None:
        """Register a store poster URL used only if Steam CDN and SteamGridDB have no cover."""
        key = (game_name or "").strip().lower()
        url = (poster_url or "").strip()
        if not key or not url:
            return
        self._fallback_urls[key] = url
        placeholder_path = os.path.join(IMAGE_CACHE_DIR, f"{sanitize_filename(game_name)}_placeholder.png")
        if os.path.isfile(placeholder_path):
            try:
                os.remove(placeholder_path)
            except OSError:
                pass

    def get_game_image(self, game_name: str) -> str | None:
        """
        Get game cover image path. Downloads from Steam CDN or SteamGridDB.

        Priority: Cache -> Steam CDN (official) -> SteamGridDB -> Store Poster -> Placeholder
        """
        # Check cache first
        cached = self._check_cache(game_name)
        if cached:
            return cached

        # Try Steam CDN first (official assets)
        downloaded = self._download_from_steam_cdn(game_name)
        if downloaded:
            return downloaded

        # Fallback to SteamGridDB community art
        if self.has_api_key():
            downloaded = self._download_from_steamgriddb(game_name)
            if downloaded:
                return downloaded

        # Fallback to Store poster (via authenticated/Referer-aware OnlineFixManager client)
        downloaded = self._download_from_store_poster(game_name)
        if downloaded:
            return downloaded

        # Fallback to placeholder
        return self.create_placeholder(game_name)

    def _check_cache(self, game_name: str) -> str | None:
        """Check if a valid cover image is already cached locally, purging stub/corrupt files."""
        safe_name = sanitize_filename(game_name)
        valid_candidates: list[tuple[int, int, str]] = []
        purged_stub = False
        for ext in [".jpg", ".png", ".webp"]:
            path = os.path.join(IMAGE_CACHE_DIR, f"{safe_name}{ext}")
            if not os.path.exists(path):
                continue
            try:
                with open(path, "rb") as f:
                    data = f.read()
            except OSError:
                continue
            w, h = _read_cover_size_bytes(data)
            if w < MIN_COVER_DIM or h < MIN_COVER_DIM:
                purged_stub = True
                try:
                    os.remove(path)
                    logger.warning(f"{TAG} Purged invalid/stub cached image {path} ({w}x{h})")
                except OSError as e:
                    logger.warning(f"{TAG} Could not remove invalid cached image {path}: {e}")
                continue
            valid_candidates.append((1 if h > w else 0, w * h, path))

        if valid_candidates:
            return max(valid_candidates)[2]

        # Check placeholder
        placeholder_path = os.path.join(IMAGE_CACHE_DIR, f"{safe_name}_placeholder.png")
        if purged_stub and os.path.exists(placeholder_path):
            try:
                os.remove(placeholder_path)
            except OSError:
                pass
        elif os.path.exists(placeholder_path):
            return placeholder_path
        return None

    def _download_from_steam_cdn(self, game_name: str) -> str | None:
        """Download official Steam capsule art using Steam Store Search API."""
        try:
            # Search Steam Store for the game to get appid
            from urllib.parse import quote_plus
            search_url = f"https://store.steampowered.com/api/storesearch/?term={quote_plus(game_name)}&l=en&cc=US"
            resp = requests.get(search_url, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            items = data.get("items", [])
            if not items:
                logger.info(f"[SteamCDN] No Steam Store results for: {game_name}")
                return None

            # Find best match (exact or closest name)
            appid = items[0]["id"]
            matched_name = items[0].get("name", "")

            # Try exact name match first
            for item in items:
                if item.get("name", "").lower() == game_name.lower():
                    appid = item["id"]
                    matched_name = item["name"]
                    break

            logger.info(f"[SteamCDN] Found: {game_name} -> appid={appid} ({matched_name})")

            # Try Steam library capsule art (600x900 portrait - the Steam library format)
            cdn_urls = [
                f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_600x900_2x.jpg",
                f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_600x900.jpg",
                f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/header.jpg",
            ]

            for cdn_url in cdn_urls:
                try:
                    img_resp = requests.get(cdn_url, timeout=10)
                    if img_resp.status_code == 200 and is_valid_cover_bytes(img_resp.content):
                        safe_name = sanitize_filename(game_name)
                        os.makedirs(IMAGE_CACHE_DIR, exist_ok=True)
                        save_path = os.path.join(IMAGE_CACHE_DIR, f"{safe_name}.jpg")
                        with open(save_path, "wb") as f:
                            f.write(img_resp.content)
                        logger.info(f"[SteamCDN] Downloaded: {game_name} ({len(img_resp.content)} bytes)")
                        return save_path
                except requests.RequestException:
                    continue

            logger.info(f"[SteamCDN] No capsule art available for: {game_name}")
            return None

        except Exception as e:
            logger.warning(f"[SteamCDN] Error for {game_name}: {type(e).__name__}: {e}")
            return None

    def _download_from_steamgriddb(self, game_name: str) -> str | None:
        """Fallback: download community art from SteamGridDB."""
        if not self.sgdb:
            return None

        try:
            results = self.sgdb.search_game(game_name)
            if not results:
                return None

            game = results[0]
            grids = None
            try:
                grids = self.sgdb.get_grids_by_gameid(game_ids=[game.id])
            except Exception:
                pass

            if not grids:
                return None

            # Prefer portrait, static images
            portrait = [g for g in grids if getattr(g, 'height', 0) > getattr(g, 'width', 0)]
            candidates = portrait if portrait else grids

            selected = candidates[0]
            for grid in candidates:
                url = getattr(grid, 'url', '') or ''
                if not url.endswith('.webm') and not url.endswith('.gif'):
                    selected = grid
                    break

            img_resp = requests.get(selected.url, timeout=15)
            img_resp.raise_for_status()
            if not is_valid_cover_bytes(img_resp.content):
                logger.warning(f"[SteamGridDB] Rejected invalid image payload for {game_name}")
                return None

            content_type = img_resp.headers.get("content-type", "image/jpeg")
            ext = ".png" if "png" in content_type else ".webp" if "webp" in content_type else _detect_image_ext(img_resp.content)

            safe_name = sanitize_filename(game_name)
            os.makedirs(IMAGE_CACHE_DIR, exist_ok=True)
            save_path = os.path.join(IMAGE_CACHE_DIR, f"{safe_name}{ext}")
            with open(save_path, "wb") as f:
                f.write(img_resp.content)

            logger.info(f"[SteamGridDB] Downloaded: {game_name} ({selected.width}x{selected.height})")
            return save_path

        except Exception as e:
            logger.warning(f"[SteamGridDB] Error for {game_name}: {e}")
            return None

    def _download_from_store_poster(self, game_name: str) -> str | None:
        """Fallback: fetch store poster via OnlineFixManager (with Referer/User-Agent) or cached store poster."""
        candidates: list[str] = []
        explicit_url = self._fallback_urls.get((game_name or "").strip().lower(), "")
        if explicit_url:
            candidates.append(explicit_url)

        try:
            from app.core.online_fix.store_cache import (
                load_cached_poster_bytes,
                load_catalog_cache,
                normalize_game_cache_key,
            )
            norm_key = normalize_game_cache_key(game_name)
            if norm_key:
                for games in load_catalog_cache().values():
                    for g in games:
                        if normalize_game_cache_key(g.title) == norm_key:
                            for u in (g.poster_url, g.provider_poster_url):
                                if u and u not in candidates:
                                    candidates.append(u)
        except Exception as e:
            logger.debug(f"{TAG} Catalog cache lookup skipped for {game_name!r}: {e}")
            load_cached_poster_bytes = lambda _u: None  # noqa: E731

        if not candidates:
            return None

        mgr = None
        for url in candidates:
            t0 = time.monotonic()
            data = load_cached_poster_bytes(url)
            if not data or not is_valid_cover_bytes(data):
                try:
                    if mgr is None:
                        from app.core.online_fix.manager import get_online_fix_manager
                        mgr = get_online_fix_manager()
                    data = mgr.fetch_poster_bytes(url)
                except Exception as e:
                    logger.warning(
                        f"{TAG} Store poster fetch failed for {game_name!r} ({url}) in {time.monotonic() - t0:.2f}s: {e}"
                    )
                    continue

            if not data or not is_valid_cover_bytes(data):
                logger.warning(
                    f"{TAG} Rejected invalid/stub store poster for {game_name!r} from {url} ({len(data) if data else 0} bytes)"
                )
                continue

            ext = _detect_image_ext(data)
            safe_name = sanitize_filename(game_name)
            os.makedirs(IMAGE_CACHE_DIR, exist_ok=True)
            save_path = os.path.join(IMAGE_CACHE_DIR, f"{safe_name}{ext}")
            with open(save_path, "wb") as f:
                f.write(data)
            logger.info(f"{TAG} Saved fallback store poster for {game_name!r} from {url} ({len(data)} bytes)")
            return save_path

        return None

    def create_placeholder(self, game_name: str) -> str:
        """
        Generate a placeholder image with the game name.

        Args:
            game_name: Name of the game

        Returns:
            Path to the generated placeholder image
        """
        safe_name = sanitize_filename(game_name)
        save_path = os.path.join(IMAGE_CACHE_DIR, f"{safe_name}_placeholder.png")

        if os.path.exists(save_path):
            return save_path

        width, height = 200, 300
        pixmap = QPixmap(width, height)

        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Draw gradient background
        gradient = QLinearGradient(0, 0, width, height)
        # Generate consistent colors based on game name hash
        name_hash = hash(game_name)
        hue1 = abs(name_hash) % 360
        hue2 = (hue1 + 40) % 360

        gradient.setColorAt(0, QColor.fromHsl(hue1, 120, 40))
        gradient.setColorAt(1, QColor.fromHsl(hue2, 100, 25))
        painter.fillRect(0, 0, width, height, gradient)

        # Draw subtle pattern overlay
        painter.setPen(QPen(QColor(255, 255, 255, 15), 1))
        for i in range(0, width + height, 20):
            painter.drawLine(i, 0, i - height, height)

        # Draw game controller icon (simple unicode)
        painter.setPen(Qt.PenStyle.NoPen)
        icon_font = QFont("Segoe UI Emoji", 36)
        painter.setFont(icon_font)
        painter.setPen(QColor(255, 255, 255, 60))
        painter.drawText(QRectF(0, 80, width, 80), Qt.AlignmentFlag.AlignCenter, "🎮")

        # Draw game name
        painter.setPen(QColor(255, 255, 255, 230))
        name_font = QFont("Segoe UI", 11, QFont.Weight.Bold)
        painter.setFont(name_font)

        text_rect = QRectF(12, 180, width - 24, 100)
        painter.drawText(
            text_rect,
            Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap,
            game_name
        )

        painter.end()

        # Save the pixmap
        pixmap.save(save_path, "PNG")
        logger.info(f"Created placeholder for: {game_name}")
        return save_path
