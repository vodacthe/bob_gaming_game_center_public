"""
Abstract base class for cloud storage providers.
All cloud providers (Nextcloud, Google Drive) must implement this interface.
"""

from abc import ABC, abstractmethod


class CloudProvider(ABC):
    """Interface for cloud storage operations."""

    @abstractmethod
    def test_connection(self) -> bool:
        """Test if the connection to the cloud works."""
        ...

    @abstractmethod
    def check_game_exists(self, game_name: str) -> bool:
        """Check if a game folder exists on the cloud."""
        ...

    @abstractmethod
    def create_game_folder(self, game_name: str):
        """Create the game folder structure on the cloud."""
        ...

    @abstractmethod
    def get_saves_path(self, game_name: str) -> str:
        """Get the remote path/identifier for a game's saves folder."""
        ...

    @abstractmethod
    def list_directory_recursive(self, remote_path: str) -> dict:
        """
        Recursively list a remote directory.
        Returns: {relative_path: {"mtime": float, "size": int}}
        """
        ...

    @abstractmethod
    def delete_remote_files(self, remote_base: str, rel_paths: list[str]):
        """Delete specific files from the cloud."""
        ...

    @abstractmethod
    def upload_delta(self, local_base: str, remote_base: str,
                     files_to_upload: list[str], progress_callback=None):
        """Upload specific files to the cloud."""
        ...

    @abstractmethod
    def download_delta(self, remote_base: str, local_base: str,
                       files_to_download: list[str], progress_callback=None,
                       file_sizes: dict[str, int] = None):
        """Download specific files from the cloud."""
        ...

    @abstractmethod
    def upload_save_location(self, game_name: str, local_save_path: str):
        """Upload save_location.txt with the local save path."""
        ...

    @abstractmethod
    def get_save_location(self, game_name: str) -> str | None:
        """Read save_location.txt from cloud. Returns the path or None."""
        ...

    @abstractmethod
    def upload_bobignore(self, game_name: str, content: str):
        """Upload .bobignore to cloud game root folder (alongside save_location_<platform>.txt)."""
        ...

    @abstractmethod
    def get_bobignore(self, game_name: str) -> str | None:
        """Read .bobignore from cloud game root folder. Returns content or None."""
        ...

    @abstractmethod
    def delete_bobignore(self, game_name: str):
        """Delete .bobignore from cloud game root folder."""
        ...

    @abstractmethod
    def list_synced_games(self) -> list[str]:
        """List all game folders under the root."""
        ...

    @abstractmethod
    def get_remote_modified_time(self, game_name: str) -> float | None:
        """Get the remote modification time of a game's saves (UNIX timestamp)."""
        ...

    @abstractmethod
    def check_saves_exist(self, game_name: str) -> bool:
        """Check if saves folder exists for a game on cloud."""
        ...

    @abstractmethod
    def delete_game_folder(self, game_name: str) -> bool:
        """Delete an entire game's folder from the cloud."""
        ...
