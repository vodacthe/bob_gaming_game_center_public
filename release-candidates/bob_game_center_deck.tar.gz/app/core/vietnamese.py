"""Built-in Vietnamese typing (Telex / VNI) for the on-screen keyboard.

The on-screen keyboard (used with a controller) only has plain Latin keys, so it composes Vietnamese itself.

Stateless: `compose(word, key, method)` looks only at the word before the cursor, like Unikey does.
Tones go on the vowel the classic way (hòa, thúy), the default of Unikey.
"""

from __future__ import annotations

TELEX = "telex"
VNI = "vni"
OFF = "off"
METHODS = (TELEX, VNI, OFF)

# base vowel -> its forms with no tone, sắc, huyền, hỏi, ngã, nặng
_TONES = {
    "a": "aáàảãạ", "ă": "ăắằẳẵặ", "â": "âấầẩẫậ", "e": "eéèẻẽẹ", "ê": "êếềểễệ",
    "i": "iíìỉĩị", "o": "oóòỏõọ", "ô": "ôốồổỗộ", "ơ": "ơớờởỡợ", "u": "uúùủũụ",
    "ư": "ưứừửữự", "y": "yýỳỷỹỵ",
}
_SPLIT = {form: (base, tone) for base, forms in _TONES.items() for tone, form in enumerate(forms)}
_VOWELS = set(_TONES)
_PLAIN = {"ă": "a", "â": "a", "ê": "e", "ô": "o", "ơ": "o", "ư": "u"}
_MODDED = set(_PLAIN)

_INITIALS = {"", "b", "c", "ch", "d", "đ", "g", "gh", "gi", "h", "k", "kh", "l", "m", "n", "ng", "ngh", "nh",
             "p", "ph", "qu", "r", "s", "t", "th", "tr", "v", "x"}
_FINALS = {"", "c", "ch", "m", "n", "ng", "nh", "p", "t"}
# vowel clusters with the vowel marks removed, including half-typed ones ("uo" before it becomes "ươ")
_CLUSTERS = {"a", "e", "i", "o", "u", "y", "ai", "ao", "au", "ay", "eo", "eu", "ia", "ie", "iu", "oa", "oe",
             "oi", "oo", "ua", "ue", "ui", "uo", "uu", "uy", "ye", "ieu", "oai", "oao", "oay", "oeo", "uay",
             "uoi", "uou", "uya", "uye", "uyu", "yeu"}

_TELEX_TONES = {"s": 1, "f": 2, "r": 3, "x": 4, "j": 5, "z": 0}
_VNI_TONES = {"1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "0": 0}


class _Word:
    """A word split into lowercase base letters (vowel marks kept, tone removed), case flags and its tone."""

    def __init__(self, word: str):
        self.letters: list[str] = []
        self.upper: list[bool] = []
        self.tone = 0
        for ch in word:
            low = ch.lower()
            base, tone = _SPLIT.get(low, (low, 0))
            if tone:
                self.tone = tone
            self.letters.append(base)
            self.upper.append(ch != low)

    def parts(self) -> tuple[int, int] | None:
        """(start, end) of the vowel cluster when the word is shaped like a Vietnamese syllable."""
        s = "".join(self.letters)
        start = next((i for i, ch in enumerate(s) if ch in _VOWELS), len(s))
        # "qu" and "gi" are consonants when another vowel follows: quá, già (but gì)
        if s[:2] == "qu" or (s[:2] == "gi" and start == 1 and len(s) > 2 and s[2] in _VOWELS):
            start = 2
        end = start
        while end < len(s) and s[end] in _VOWELS:
            end += 1
        if s[:start] not in _INITIALS or s[end:] not in _FINALS:
            return None
        if start < end and "".join(_PLAIN.get(c, c) for c in s[start:end]) not in _CLUSTERS:
            return None
        return start, end

    def build(self) -> str:
        out = list(self.letters)
        span = self.parts()
        if self.tone and span and span[0] < span[1]:
            i = self._tone_index(*span)
            out[i] = _TONES[out[i]][self.tone]
        return "".join(ch.upper() if up else ch for ch, up in zip(out, self.upper))

    def _tone_index(self, start: int, end: int) -> int:
        cluster = self.letters[start:end]
        marked = [i for i, ch in enumerate(cluster) if ch in _MODDED]
        if marked:
            return start + marked[-1]                 # ươ -> ơ, iê -> ê
        if len(cluster) == 3:
            return start + 1                          # oai -> oái
        if len(cluster) == 2 and end == len(self.letters):
            return start                              # hòa, thúy, mía (no final consonant)
        return end - 1                                # hoàng, toán, or a single vowel

    def append(self, key: str) -> str:
        return self.build() + key


def compose(word: str, key: str, method: str = TELEX) -> str | None:
    """The word that replaces `word` when `key` is typed after it, or None to just insert `key`.

    `word` is the run of letters before the cursor. A key repeated on a mark it made undoes it
    (Telex "ass" -> "as", "aaa" -> "aa").
    """
    if method not in (TELEX, VNI) or len(key) != 1 or not word:
        return None                                  # a lone "w" stays "w" (gg wp)
    w = _Word(word)
    span = w.parts()
    if span is None:
        return None
    k = key.lower()
    tones = _TELEX_TONES if method == TELEX else _VNI_TONES
    if k in tones:
        return _apply_tone(w, span, tones[k], key)
    if method == TELEX:
        if k in "aeo":
            return _apply_mark(w, span, {k: {"a": "â", "e": "ê", "o": "ô"}[k]}, key, last=True)
        if k == "w":
            return _apply_horn(w, span, key, telex=True)
        if k == "d":
            return _apply_dd(w, key)
        return None
    if k == "6":
        return _apply_mark(w, span, {"a": "â", "e": "ê", "o": "ô"}, key, last=True)
    if k == "7":
        return _apply_horn(w, span, key, telex=False)
    if k == "8":
        return _apply_mark(w, span, {"a": "ă"}, key, last=True)
    if k == "9":
        return _apply_dd(w, key)
    return None


def _apply_tone(w: _Word, span: tuple[int, int], tone: int, key: str) -> str | None:
    start, end = span
    if start == end:
        return None
    if tone == 0:
        if not w.tone:
            return None
        w.tone = 0
        return w.build()
    if w.tone == tone:                               # same tone again: undo it, type the key
        w.tone = 0
        return w.append(key)
    if "".join(w.letters[end:]) in ("c", "ch", "p", "t") and tone not in (1, 5):
        return None                                  # those finals only take sắc / nặng
    w.tone = tone
    return w.build()


def _apply_mark(w: _Word, span: tuple[int, int], marks: dict[str, str], key: str, last: bool) -> str | None:
    start, end = span
    order = range(end - 1, start - 1, -1) if last else range(start, end)
    for i in order:
        ch = w.letters[i]
        if ch in marks.values():                     # already marked: undo, type the key
            w.letters[i] = _PLAIN[ch]
            return w.append(key)
        if ch in marks:
            w.letters[i] = marks[ch]
            return w.build()
    return None


def _apply_horn(w: _Word, span: tuple[int, int], key: str, telex: bool) -> str | None:
    """Telex w / VNI 7 (and Telex w on a): uo -> ươ, u -> ư, o -> ơ, a -> ă (Telex only)."""
    start, end = span
    s = w.letters
    cluster = "".join(s[start:end])
    plain = "".join(_PLAIN.get(c, c) for c in cluster)
    if "uo" in plain and cluster[plain.index("uo"):][:2] != "ươ":     # nguwow -> ngươ, not an undo
        i = start + plain.index("uo")
        s[i], s[i + 1] = "ư", "ơ"
        return w.build()
    horned = "ơư" + ("ă" if telex else "")
    if any(ch in horned for ch in cluster):          # already there: undo, type the key
        for i in range(start, end):
            if s[i] in horned:
                s[i] = _PLAIN[s[i]]
        return w.append(key)
    if not cluster:
        if telex and end == len(s):                  # "tr" + w -> "trư"
            return w.build() + ("Ư" if key == "W" else "ư")
        return None
    candidates = "aou" if telex else "ou"
    if telex and plain.startswith("oa"):             # hoă (hoặc)
        i = start + 1
    else:
        i = next((start + j for j, ch in enumerate(cluster) if ch in candidates), -1)
    if i < 0:
        return None
    s[i] = {"a": "ă", "o": "ơ", "u": "ư"}[s[i]]
    return w.build()


def _apply_dd(w: _Word, key: str) -> str | None:
    if not w.letters or w.letters[0] not in "dđ":
        return None
    if w.letters[0] == "đ":
        w.letters[0] = "d"
        return w.append(key)
    w.letters[0] = "đ"
    return w.build()
