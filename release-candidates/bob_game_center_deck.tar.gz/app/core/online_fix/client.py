"""
HTTP Client & Scraper for Online-Fix.me.
Handles game searching, metadata extraction, torrent link resolution,
and session cookie management.

Every network call is logged with its URL, status and duration. Network / HTTP failures raise OnlineFixError so the
UI can tell "nothing found" apart from "the site could not be reached".
"""

import json
import logging
import os
import re
import sys
import threading
import time
import urllib.parse
from typing import Dict, List

import bs4
import requests

from app.config import get_app_dir, load_config, update_online_fix_config
from app.core.online_fix.models import (
    DEFAULT_ARCHIVE_PASSWORD, LINK_TORRENT, LINK_WEB, OnlineFixGame, dotted_acronym_query, extract_update_ts, is_excluded_game, matches_search_query, parse_store_date_ts, sort_games_for_search,
)
from app.core.online_fix.translate import title_to_vietnamese, to_vietnamese

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/Client]"

BASE_URL = "https://online-fix.me"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
PAGE_TIMEOUT = 15
POSTER_TIMEOUT = 10
SEARCH_PAGE_SIZE = 21   # DLE search returns 21 results per page

_PASSWORD_RE = re.compile(r"Пароль от архива:\s*([^\s<]+)", re.IGNORECASE)
_JS_REDIRECT_RE = re.compile(r"location\.href\s*=\s*\\?['\"]([^'\"\\]+)")


class OnlineFixError(Exception):
    """Network / HTTP / parsing failure, with a user-facing (Vietnamese) message."""


def _is_test_env() -> bool:
    if getattr(sys, "frozen", False):
        return False
    app_dir = os.path.normcase(os.path.abspath(get_app_dir()))
    repo_dir = os.path.normcase(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
    return app_dir != repo_dir


def _test_config_path() -> str:
    return os.path.join(get_app_dir(), "config.json")


class OnlineFixClient:
    """Scraper and API client for online-fix.me. Safe to call from several threads (one session per thread)."""

    def __init__(self):
        self._cookies: Dict[str, str] = {}
        self._cookies_lock = threading.Lock()
        self._cookie_gen = 0   # bumped on every cookie change; per-thread sessions re-sync when it moves
        self._local = threading.local()
        self._load_saved_cookies()

    # ------------------------------------------------------------ session / cookies

    @property
    def session(self) -> requests.Session:
        """Per-thread requests session (requests.Session is not thread-safe), primed with the saved cookies."""
        s = getattr(self._local, "session", None)
        if s is None:
            s = requests.Session()
            s.headers.update({
                "User-Agent": USER_AGENT,
                "Accept-Language": "en-US,en;q=0.9,ru;q=0.8,vi;q=0.7",
                "Referer": BASE_URL + "/",
            })
            self._local.session = s
            self._local.cookie_gen = -1
        gen = self._cookie_gen
        if self._local.cookie_gen != gen:
            with self._cookies_lock:
                cookies = dict(self._cookies)
            for k, v in cookies.items():
                s.cookies.set(k, v, domain="online-fix.me")
            self._local.cookie_gen = gen
        return s

    def _load_saved_cookies(self):
        try:
            if _is_test_env():
                cfg_path = _test_config_path()
                if not os.path.exists(cfg_path):
                    logger.info(f"{TAG} No saved cookies (not logged in)")
                    return
                with open(cfg_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                cookies = data.get("online_fix_cookies", {}) if isinstance(data, dict) else {}
            else:
                cfg = load_config()
                cookies = cfg.get("online_fix_cookies", {})
            if not cookies:
                logger.info(f"{TAG} No saved cookies (not logged in)")
                return
            if not isinstance(cookies, dict):
                raise ValueError("online_fix_cookies is not a JSON object")
            with self._cookies_lock:
                self._cookies = {str(k): str(v) for k, v in cookies.items()}
            self._cookie_gen += 1
            logger.info(f"{TAG} Loaded {len(cookies)} cookies from config.json (logged in: {self.is_logged_in()})")
        except Exception as e:   # noqa: BLE001 - corrupt cookies must not break the store
            logger.warning(f"{TAG} Failed to load cookies from config.json: {e}")

    def save_cookies(self, cookies: Dict[str, str]):
        """Save the session cookies of a successful login into config.json."""
        with self._cookies_lock:
            self._cookies.update(cookies)
            merged = dict(self._cookies)
        self._cookie_gen = self._cookie_gen + 1
        try:
            if _is_test_env():
                cfg_path = _test_config_path()
                data = {}
                if os.path.exists(cfg_path):
                    try:
                        with open(cfg_path, "r", encoding="utf-8") as f:
                            loaded = json.load(f)
                            if isinstance(loaded, dict):
                                data = loaded
                    except Exception:
                        data = {}
                data["online_fix_cookies"] = merged
                os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
                with open(cfg_path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            else:
                update_online_fix_config(online_fix_cookies=merged)
            logger.info(f"{TAG} Saved {len(merged)} cookies to config.json (logged in: {self.is_logged_in()})")
        except Exception as e:   # noqa: BLE001
            logger.error(f"{TAG} Failed to save cookies to config.json: {e}")

    def login(self, username: str, password: str) -> None:
        """Sign in with the site's own login form (DLE): auth token -> POST credentials. Raises OnlineFixError.
        Only the resulting session cookies are stored; the password is never saved or logged."""
        started = time.monotonic()
        logger.info(f"{TAG} Login attempt for user {username!r}")
        s = requests.Session()
        s.headers.update(self.session.headers)
        try:
            tok = s.get(f"{BASE_URL}/engine/ajax/authtoken.php", timeout=PAGE_TIMEOUT,
                        headers={"X-Requested-With": "XMLHttpRequest"})
            token = tok.json() if tok.status_code == 200 else {}
            data = {"login_name": username, "login_password": password, "login": "submit"}
            if token.get("field"):
                data[token["field"]] = token.get("value", "")
            else:
                logger.warning(f"{TAG} Login: no auth token (HTTP {tok.status_code}); trying without it")
            resp = s.post(BASE_URL + "/", data=data, timeout=PAGE_TIMEOUT)
        except (requests.RequestException, ValueError) as e:
            logger.warning(f"{TAG} Login: network error {e.__class__.__name__}: {e}")
            raise OnlineFixError("Không kết nối được tới online-fix.me. Kiểm tra mạng rồi thử lại.")

        cookies = {k: v for k, v in s.cookies.get_dict().items()}
        if not cookies.get("dle_user_id"):
            wrong = "Ошибка авторизации" in resp.text
            logger.warning(f"{TAG} Login failed for {username!r} (HTTP {resp.status_code}, "
                           f"{'wrong credentials' if wrong else 'no session cookie'}) in {time.monotonic() - started:.2f}s")
            raise OnlineFixError("Sai tên đăng nhập hoặc mật khẩu." if wrong else
                                 "Đăng nhập không thành công (online-fix.me không trả về phiên đăng nhập).")
        self.save_cookies(cookies)
        logger.info(f"{TAG} Logged in as {username!r} in {time.monotonic() - started:.2f}s")

    def logout(self) -> None:
        """Forget the stored session cookies."""
        with self._cookies_lock:
            self._cookies = {}
        self._cookie_gen += 1
        self._local = threading.local()          # drop per-thread sessions that still carry the old cookies
        try:
            if _is_test_env():
                cfg_path = _test_config_path()
                if os.path.exists(cfg_path):
                    with open(cfg_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    if isinstance(data, dict) and "online_fix_cookies" in data:
                        data["online_fix_cookies"] = {}
                        with open(cfg_path, "w", encoding="utf-8") as f:
                            json.dump(data, f, indent=2, ensure_ascii=False)
            else:
                update_online_fix_config(online_fix_cookies={})
        except OSError as e:
            logger.warning(f"{TAG} Could not clear cookies in config.json: {e}")
        logger.info(f"{TAG} Logged out (cookies cleared)")

    def is_logged_in(self) -> bool:
        """Check if session has valid login cookies (dle_user_id or dle_password)."""
        with self._cookies_lock:
            return bool(self._cookies.get("dle_user_id") or self._cookies.get("dle_password"))

    # ------------------------------------------------------------ http

    def _get(self, url: str, what: str, timeout: float = PAGE_TIMEOUT, referer: str = "") -> requests.Response:
        started = time.monotonic()
        headers = {"Referer": referer} if referer else None
        try:
            resp = self.session.get(url, timeout=timeout, headers=headers)
        except requests.Timeout:
            logger.warning(f"{TAG} {what}: timeout after {timeout}s ({url})")
            raise OnlineFixError("online-fix.me không phản hồi (quá thời gian chờ). Thử lại sau.")
        except requests.RequestException as e:
            logger.warning(f"{TAG} {what}: network error {e.__class__.__name__}: {e} ({url})")
            raise OnlineFixError("Không kết nối được tới online-fix.me. Kiểm tra mạng hoặc bật 'Mở chặn mạng'.")
        elapsed = time.monotonic() - started
        if resp.status_code != 200:
            logger.warning(f"{TAG} {what}: HTTP {resp.status_code} in {elapsed:.2f}s ({url})")
            raise OnlineFixError(f"online-fix.me trả về lỗi HTTP {resp.status_code}.")
        logger.debug(f"{TAG} {what}: HTTP 200, {len(resp.content)} bytes in {elapsed:.2f}s ({url})")
        return resp

    def fetch_bytes(self, url: str, timeout: float = POSTER_TIMEOUT) -> bytes:
        """Download a small file (poster image). Raises OnlineFixError."""
        return self._get(url, "fetch", timeout=timeout).content

    # ------------------------------------------------------------ listing

    def search_games(self, query: str, page: int = 1) -> List[OnlineFixGame]:
        """Search for games by name on online-fix.me. Raises OnlineFixError."""
        if not query or len(query.strip()) < 2:
            return self.get_latest_games(page=page)

        q = query.strip()
        url = f"{BASE_URL}/index.php?do=search&subaction=search&story={urllib.parse.quote(q)}"
        if page > 1:
            url += f"&search_start={page}&result_from={(page - 1) * SEARCH_PAGE_SIZE + 1}"
        started = time.monotonic()
        raw_games = self._parse_game_list(self._get(url, f"search {q!r} p{page}").text)
        games = [g for g in raw_games if matches_search_query(q, g.title, g.url)]
        if len(games) != len(raw_games):
            logger.info(f"{TAG} Search {q!r} page {page}: filtered {len(raw_games) - len(games)} irrelevant hit(s)")
        if page == 1 and not games:
            dotted = dotted_acronym_query(q)
            if dotted:
                try:
                    d_url = f"{BASE_URL}/index.php?do=search&subaction=search&story={urllib.parse.quote(dotted)}"
                    d_raw = self._parse_game_list(self._get(d_url, f"search-dotted {dotted!r} p1").text)
                    games = [g for g in d_raw if matches_search_query(q, g.title, g.url)]
                except OnlineFixError:
                    pass
        games = sort_games_for_search(q, games)
        logger.info(f"{TAG} Search {q!r} page {page}: {len(games)} games in {time.monotonic() - started:.2f}s")
        return games

    def get_latest_games(self, page: int = 1) -> List[OnlineFixGame]:
        """Fetch latest updated games on online-fix.me. Raises OnlineFixError."""
        url = f"{BASE_URL}/page/{page}/" if page > 1 else BASE_URL
        started = time.monotonic()
        games = self._parse_game_list(self._get(url, f"latest p{page}").text)
        logger.info(f"{TAG} Latest games page {page}: {len(games)} games in {time.monotonic() - started:.2f}s")
        games.sort(key=lambda g: (0, -g.published_ts) if g.published_ts > 0 else (1, 0)); return games

    def _parse_game_list(self, html: str) -> List[OnlineFixGame]:
        """Parse game items from search or category list HTML."""
        soup = bs4.BeautifulSoup(html, "html.parser")
        games: List[OnlineFixGame] = []
        seen: set[str] = set()

        articles = soup.select(".news .article") or soup.select("article.news .article")
        if not articles:
            articles = soup.find_all("article")

        skipped = 0
        excluded = 0
        for art in articles:
            try:
                link_tag = art.find("a", class_="big-link") or art.find("h2", class_="title")
                if link_tag and link_tag.name == "h2":
                    link_tag = link_tag.find_parent("a") or link_tag.find("a")
                elif not link_tag:
                    link_tag = art.find("a")

                game_url = link_tag.get("href", "") if link_tag else ""
                if not game_url or not game_url.startswith("http") or game_url in seen:
                    continue

                title_tag = art.find("h2", class_="title") or art.find("h2")
                title = title_tag.text.strip() if title_tag else ""
                img_tag = art.find("img")
                if not title:
                    title = img_tag.get("alt", "").strip() if img_tag else ""
                if not title:
                    continue

                poster = ""
                if img_tag:
                    poster = img_tag.get("data-src") or img_tag.get("src") or ""
                    if poster.startswith("/"):
                        poster = BASE_URL + poster

                date_tag = art.find("time") or art.find("span", class_="info-date")
                edit_tag = art.find("div", class_="edit")

                clean_title = title_to_vietnamese(title)
                if is_excluded_game(clean_title, game_url):
                    excluded += 1
                    logger.debug(f"{TAG} Excluded game {clean_title!r} ({game_url})")
                    continue

                seen.add(game_url)
                games.append(OnlineFixGame(
                    id=os.path.basename(game_url).split("-")[0],   # 17429-palworld-po-seti.html -> 17429
                    title=clean_title,
                    url=game_url,
                    poster_url=poster,
                    date=to_vietnamese(date_tag.text.strip()) if date_tag else "",
                    update_info=to_vietnamese(" ".join(edit_tag.text.split())) if edit_tag else "", published_ts=parse_store_date_ts(str(date_tag.get("datetime") or date_tag.text.strip())) if date_tag else 0.0, updated_ts=extract_update_ts(" ".join(edit_tag.text.split())) if edit_tag else 0.0,
                ))
            except Exception as e:   # noqa: BLE001 - one odd article must not drop the whole page
                skipped += 1
                logger.debug(f"{TAG} Skipped parsing article item: {e}")

        if skipped:
            logger.warning(f"{TAG} {skipped} article(s) could not be parsed")
        if not games and articles and not excluded:
            logger.warning(f"{TAG} {len(articles)} article blocks found but no game parsed (site layout changed?)")
        games.sort(key=lambda g: (0, -g.published_ts) if g.published_ts > 0 else (1, 0)); return games

    # ------------------------------------------------------------ details

    def get_game_details(self, game_url: str) -> OnlineFixGame:
        """Fetch detailed information and download links for a specific game. Raises OnlineFixError."""
        started = time.monotonic()
        html = self._get(game_url, "details").text
        game = self._parse_game_details(html, game_url)
        kinds = {}
        for link in game.download_links:
            kinds[link["kind"]] = kinds.get(link["kind"], 0) + 1
        logger.info(f"{TAG} Details {game.title!r}: links {kinds or 'none'}, archive password "
                    f"{'custom' if game.archive_password != DEFAULT_ARCHIVE_PASSWORD else 'default'}, "
                    f"{time.monotonic() - started:.2f}s")
        return game

    def _parse_game_details(self, html: str, game_url: str) -> OnlineFixGame:
        soup = bs4.BeautifulSoup(html, "html.parser")

        title_tag = soup.find("h1", class_="title") or soup.find("h1")
        title = title_tag.text.strip() if title_tag else ""

        poster_tag = soup.select_one(".image img") or soup.select_one(".article-content img")
        poster_url = ""
        if poster_tag:
            poster_url = poster_tag.get("data-src") or poster_tag.get("src") or ""
            if poster_url.startswith("/"):
                poster_url = BASE_URL + poster_url

        edit_tag = soup.find("div", class_="edit")
        preview_tag = soup.find("div", class_="preview-text")

        # Download buttons live in the post body's quote blocks; everything else on the page (comments, footer,
        # sidebar) is navigation and must not be offered as a download.
        download_links: List[dict] = []
        seen: set[str] = set()
        buttons = soup.select("div.quote a.btn") or soup.select("a.btn[href*='/ext/'], a.btn[href*=':2053/']")
        for a in buttons:
            href = (a.get("href") or "").strip()
            if not href or href in seen:
                continue
            seen.add(href)
            label = " ".join(a.text.split()) or "Liên kết tải"
            download_links.append({"title": to_vietnamese(label), "url": href, "kind": self._classify_link(label, href)})

        password = DEFAULT_ARCHIVE_PASSWORD
        m = _PASSWORD_RE.search(soup.get_text(" "))
        if m:
            password = m.group(1).strip().rstrip(".")

        return OnlineFixGame(
            id=os.path.basename(game_url).split("-")[0],
            title=title_to_vietnamese(title),
            url=game_url,
            poster_url=poster_url,
            update_info=to_vietnamese(" ".join(edit_tag.text.split())) if edit_tag else "",
            game_modes=to_vietnamese(" ".join(preview_tag.text.split())) if preview_tag else "",
            archive_password=password,
            download_links=download_links,
        )

    @staticmethod
    def _classify_link(label: str, href: str) -> str:
        low_label, low_href = label.lower(), href.lower()
        if low_href.startswith("magnet:?") or low_href.endswith(".torrent") or "/torrents/" in low_href:
            return LINK_TORRENT
        if "torrent" in low_label or "торрент" in low_label:
            return LINK_TORRENT
        return LINK_WEB

    # ------------------------------------------------------------ torrent resolution

    def resolve_torrent_download(self, raw_url: str, referer: str = "") -> str:
        """
        Resolve a download button to a final .torrent URL or magnet URI:
        /ext/ redirect page -> uploads.online-fix.me:2053/torrents/<Game>/ listing -> <file>.torrent.
        Raises OnlineFixError when no torrent can be found.
        """
        url = raw_url.strip()
        for hop in range(3):
            if url.startswith("magnet:?") or url.lower().endswith(".torrent"):
                logger.info(f"{TAG} Resolved torrent source after {hop} hop(s): {url[:120]}")
                return url
            resp = self._get(url, f"resolve hop {hop + 1}", referer=referer or BASE_URL + "/")
            soup = bs4.BeautifulSoup(resp.text, "html.parser")

            torrent = next((a.get("href") for a in soup.find_all("a")
                            if (a.get("href") or "").lower().endswith(".torrent")), None)
            if torrent:
                url = urllib.parse.urljoin(resp.url, torrent)
                continue
            magnet = next((a.get("href") for a in soup.find_all("a")
                           if (a.get("href") or "").startswith("magnet:?")), None)
            if magnet:
                url = magnet
                continue
            m = _JS_REDIRECT_RE.search(resp.text)      # /ext/ interstitial: target is in a location.href script
            if m and m.group(1) != url:
                url = urllib.parse.urljoin(resp.url, m.group(1))
                continue
            if "авторизуйтесь" in resp.text or "зарегистрируйтесь" in resp.text:
                logger.warning(f"{TAG} Resolve {raw_url[:120]}: site asks for login")
                raise OnlineFixError("Liên kết tải trên online-fix.me hiện không khả dụng.")
            break

        logger.warning(f"{TAG} Resolve {raw_url[:120]}: no .torrent or magnet found (last page {url[:120]})")
        raise OnlineFixError("Không tìm thấy tệp .torrent trong liên kết này.")
