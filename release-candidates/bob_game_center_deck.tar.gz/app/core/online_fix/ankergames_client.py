"""
AnkerGamesClient: HTTP scraping & direct CDN resolver for https://ankergames.net/
Supports browsing latest pre-installed portable games, recent updates enrichment,
searching by title, category backfill, extracting game details, and resolving
direct CDN downloads (CSRF ticket + silent Chromium CDP Turnstile solver) for aria2c.

No login required. Network failures raise OnlineFixError with a clear Vietnamese message.
"""

from collections import OrderedDict
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from typing import Dict, List, Optional, Tuple
from urllib.parse import quote, unquote, urljoin, urlparse

import bs4
import requests

from app.core.online_fix.client import OnlineFixError
from app.core.online_fix.models import (
    ANKERGAMES_ARCHIVE_PASSWORD,
    LINK_TORRENT,
    LINK_WEB,
    SOURCE_ANKERGAMES,
    OnlineFixGame,
    _safe_utc_ts,
    dotted_acronym_query,
    format_ts_ddmmyyyy,
    has_hypervisor_marker,
    is_excluded_game,
    matches_search_query,
    parse_store_date_ts,
    sort_games_for_search,
)
from app.core.online_fix.steamrip_client import SteamRipClient
from app.core.online_fix.store_cache import _is_test_env, classify_game_categories
from app.utils.helpers import is_admin

logger = logging.getLogger(__name__)
TAG = "[AnkerGames/Client]"

ANKERGAMES_BASE_URL = "https://ankergames.net"
ANKERGAMES_PAGE_SIZE = 28
REQUEST_TIMEOUT = 18
_RECENT_UPDATES_TTL = 300.0

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

ANKERGAMES_CATEGORY_PATHS: dict[str, str] = {
    "coop": "/games/co-op",
    "action": "/genre/action",
    "rpg": "/genre/rpg",
    "adventure": "/genre/adventure",
    "horror": "/genre/horror",
    "strategy_sim": "/genre/simulation",
    "sports_racing": "/genre/racing",
    "indie": "/genre/indie",
}

_POSTER_UNIX_TS_RE = re.compile(r"_(\d{10})\.(?:jpg|jpeg|png|webp)\b", re.IGNORECASE)
_POSTER_MM_YYYY_RE = re.compile(r"/uploads/poster/(\d{1,2})-(\d{4})/", re.IGNORECASE)
_GEN_DL_ID_RE = re.compile(r"generateDownloadUrl\(\s*(\d+)\s*\)")
_TEMPLATE_BLOCK_RE = re.compile(r"<template\b[^>]*>([\s\S]*?)</template>", re.IGNORECASE)
_UPDATE_LABEL_RE = re.compile(
    r"(?:^(?:update|patch)\b|\b(?:update\s+only|patch\s+only|update\s+from|hotfix\s+only)\b)",
    re.IGNORECASE,
)
_FIX_LABEL_RE = re.compile(
    r"(?:^fix$|\b(?:online[\s_-]*fix|steam[\s_-]*fix|lan[\s_-]*fix|crack|fix[\s_-]*repair|fix\s+only)\b)",
    re.IGNORECASE,
)
_DL_PAGE_INIT_RE = re.compile(
    r"downloadPage\(\s*'([^']+)'(?:\s*,\s*[^,]+){4}\s*,\s*(\d+)\s*\)"
)
_DL_PAGE_URL_ONLY_RE = re.compile(r"downloadPage\(\s*'([^']+)'")
_REL_AGO_RE = re.compile(
    r"\b(\d+)\s*(m|min|mins|minute|minutes|h|hr|hrs|hour|hours|d|day|days)\s+ago\b",
    re.IGNORECASE,
)
_SIZE_TOKEN_RE = re.compile(r"\b\d+(?:\.\d+)?\s*(?:GB|MB|KB|TB)\b", re.IGNORECASE)


def extract_ankergames_poster_ts(poster_url: str) -> float:
    """Extract store upload timestamp from AnkerGames poster filename or MM-YYYY upload folder."""
    raw = (poster_url or "").strip()
    if not raw:
        return 0.0
    m_ts = _POSTER_UNIX_TS_RE.search(raw)
    if m_ts:
        ts = float(m_ts.group(1))
        if 1_500_000_000 <= ts <= 2_500_000_000:
            return ts
    m_my = _POSTER_MM_YYYY_RE.search(raw)
    if m_my:
        mon = int(m_my.group(1))
        year = int(m_my.group(2))
        return _safe_utc_ts(year, mon, 15, 12, 0, 0)
    return 0.0


def _normalize_url(href: str) -> str:
    h = (href or "").strip()
    if not h:
        return ""
    if h.startswith("//"):
        return "https:" + h
    if h.startswith("/"):
        return ANKERGAMES_BASE_URL + h
    return h


def _slug_from_url(url: str) -> str:
    path = urlparse(url or "").path.rstrip("/")
    return os.path.basename(path) or "ankergames"


class AnkerGamesClient:
    """Stateless-friendly HTTP client for AnkerGames store browsing and direct CDN resolution."""

    _DETAILS_CACHE_MAX = 192

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": USER_AGENT,
                "Accept-Language": "en-US,en;q=0.9",
            }
        )
        self._details_cache: OrderedDict[str, OnlineFixGame] = OrderedDict()
        self._cache_lock = threading.Lock()
        self._recent_lock = threading.Lock()
        self._recent_fetched_at: float = 0.0
        self._recent_by_slug: Dict[str, dict] = {}
        self._recent_games: List[OnlineFixGame] = []
        self._cdp_lock = threading.Lock()

    # ------------------------------------------------------------ low-level HTTP

    def _get(
        self,
        url: str,
        *,
        params: Optional[dict] = None,
        headers: Optional[dict] = None,
        allow_404_empty: bool = False,
        timeout: float = REQUEST_TIMEOUT,
    ) -> Optional[requests.Response]:
        started = time.monotonic()
        try:
            resp = self.session.get(url, params=params, headers=headers, timeout=timeout)
        except requests.RequestException as e:
            elapsed = time.monotonic() - started
            logger.warning(f"{TAG} GET {url} network error after {elapsed:.2f}s: {e}")
            raise OnlineFixError(
                "Không kết nối được tới AnkerGames (có thể mạng chập chờn hoặc bị chặn tạm thời). "
                "Hãy kiểm tra mạng hoặc bật 'Mở chặn mạng'."
            ) from e

        elapsed = time.monotonic() - started
        if allow_404_empty and resp.status_code in (400, 404):
            logger.info(f"{TAG} GET {url} returned HTTP {resp.status_code} in {elapsed:.2f}s (end of pages)")
            return None
        if resp.status_code >= 400:
            logger.warning(f"{TAG} GET {url} failed with HTTP {resp.status_code} in {elapsed:.2f}s")
            raise OnlineFixError(f"Máy chủ AnkerGames phản hồi lỗi HTTP {resp.status_code}.")
        return resp

    def fetch_bytes(self, url: str, referer: str = "") -> bytes:
        full_url = _normalize_url(url)
        if not full_url:
            raise OnlineFixError("URL ảnh AnkerGames trống.")
        started = time.monotonic()
        headers = {"Referer": referer or (ANKERGAMES_BASE_URL + "/")}
        try:
            resp = self.session.get(full_url, headers=headers, timeout=15)
        except requests.RequestException as e:
            logger.warning(f"{TAG} fetch_bytes {full_url} failed in {time.monotonic() - started:.2f}s: {e}")
            raise OnlineFixError(f"Không tải được ảnh AnkerGames: {e}") from e
        if resp.status_code >= 400:
            logger.warning(
                f"{TAG} fetch_bytes {full_url} returned HTTP {resp.status_code} in {time.monotonic() - started:.2f}s"
            )
            raise OnlineFixError(f"Không tải được ảnh AnkerGames (HTTP {resp.status_code}).")
        return resp.content

    # ------------------------------------------------------------ recent updates metadata

    @staticmethod
    def _parse_relative_ago_ts(text: str, now_ts: float) -> float:
        m = _REL_AGO_RE.search(text or "")
        if not m:
            return 0.0
        val = int(m.group(1))
        unit = m.group(2).lower()
        if unit.startswith("m"):
            return max(0.0, now_ts - val * 60.0)
        if unit.startswith("h"):
            return max(0.0, now_ts - val * 3600.0)
        if unit.startswith("d"):
            return max(0.0, now_ts - val * 86400.0)
        return 0.0

    @classmethod
    def _parse_recent_updates_html(cls, html: str, now_ts: Optional[float] = None) -> Tuple[Dict[str, dict], List[OnlineFixGame]]:
        """Parse /recent-updates into (slug -> update_meta, list of OnlineFixGame with original published_ts + fresh updated_ts)."""
        now_val = float(now_ts if now_ts is not None else time.time())
        soup = bs4.BeautifulSoup(html or "", "html.parser")
        by_slug: Dict[str, dict] = {}
        games: List[OnlineFixGame] = []
        current_day_ts = 0.0
        idx = 0

        for elem in soup.find_all(["h3", "article"]):
            if elem.name == "h3":
                heading = " ".join(elem.get_text(" ").split()).strip()
                parsed = parse_store_date_ts(heading)
                if parsed > 0:
                    current_day_ts = parsed + 43200.0  # noon UTC baseline for that date heading
                continue

            a_tag = elem.find("a", href=True)
            if not a_tag:
                continue
            href = _normalize_url(a_tag.get("href", ""))
            if "/game/" not in href:
                continue
            slug = _slug_from_url(href)
            if slug in by_slug:
                continue

            h4 = elem.find(["h4", "h3"])
            title = " ".join(h4.get_text(" ").split()).strip() if h4 else ""
            if not title:
                aria = (elem.get("aria-label") or "").strip()
                if aria.lower().startswith("game update:"):
                    title = aria.split(":", 1)[1].strip()
            if not title or is_excluded_game(title, href):
                continue

            poster_url = ""
            img = elem.select_one("picture img") or elem.find("img")
            if img:
                poster_url = _normalize_url(img.get("src") or img.get("data-src") or "")

            ver_text = ""
            is_hv = has_hypervisor_marker(title)
            for sp in elem.find_all("span"):
                t = " ".join(sp.get_text(" ").split()).strip()
                if not t:
                    continue
                if t.upper() in ("HV", "HYPERVISOR") or has_hypervisor_marker(t):
                    is_hv = True
                elif not ver_text and (t.upper().startswith(("V ", "V.", "BUILD ")) or re.match(r"^v?\d", t, re.IGNORECASE)):
                    ver_text = t

            card_text = " ".join(elem.get_text(" ").split())
            upd_ts = cls._parse_relative_ago_ts(card_text, now_val)
            if upd_ts <= 0.0:
                upd_ts = (current_day_ts - idx) if current_day_ts > 0 else 0.0
            idx += 1

            pub_ts = extract_ankergames_poster_ts(poster_url)
            if pub_ts <= 0.0:
                # Never inflate published_ts with update timestamp; fallback conservatively if poster lacks date
                pub_ts = 0.0
            date_str = format_ts_ddmmyyyy(pub_ts) or format_ts_ddmmyyyy(upd_ts)
            upd_date_str = format_ts_ddmmyyyy(upd_ts)
            upd_parts = []
            if upd_date_str:
                upd_parts.append(f"Cập nhật {upd_date_str}")
            if ver_text:
                upd_parts.append(ver_text)
            update_info = " · ".join(upd_parts)

            by_slug[slug] = {
                "updated_ts": upd_ts,
                "version": ver_text,
                "update_info": update_info,
                "poster_url": poster_url,
                "is_hypervisor": is_hv,
            }

            game = OnlineFixGame(
                id=slug,
                title=title,
                url=href,
                poster_url=poster_url,
                date=date_str,
                update_info=update_info,
                archive_password=ANKERGAMES_ARCHIVE_PASSWORD,
                source=SOURCE_ANKERGAMES,
                published_ts=pub_ts,
                updated_ts=upd_ts,
                is_hypervisor=is_hv,
            )
            game.categories = classify_game_categories(game)
            games.append(game)

        return by_slug, games

    def _ensure_recent_updates(self) -> Tuple[Dict[str, dict], List[OnlineFixGame]]:
        """Fetch /recent-updates with a 5-minute TTL cache; failures degrade gracefully."""
        now_mono = time.monotonic()
        with self._recent_lock:
            if self._recent_fetched_at > 0 and (now_mono - self._recent_fetched_at) < _RECENT_UPDATES_TTL:
                return dict(self._recent_by_slug), list(self._recent_games)

        url = f"{ANKERGAMES_BASE_URL}/recent-updates"
        started = time.monotonic()
        try:
            resp = self._get(url, timeout=12)
            if resp is None:
                return {}, []
            by_slug, games = self._parse_recent_updates_html(resp.text)
            with self._recent_lock:
                self._recent_by_slug = by_slug
                self._recent_games = games
                self._recent_fetched_at = time.monotonic()
            logger.info(
                f"{TAG} Loaded recent-updates metadata: {len(by_slug)} updated game(s) in {time.monotonic() - started:.2f}s"
            )
            return dict(by_slug), list(games)
        except Exception as e:   # noqa: BLE001
            logger.warning(f"{TAG} Optional /recent-updates fetch skipped after {time.monotonic() - started:.2f}s: {e}")
            return {}, []

    # ------------------------------------------------------------ card & listing parsers

    @classmethod
    def _parse_cards_html(
        cls,
        html: str,
        recent_by_slug: Optional[Dict[str, dict]] = None,
        preserve_list_order_ts: bool = False,
    ) -> List[OnlineFixGame]:
        soup = bs4.BeautifulSoup(html or "", "html.parser")
        recent_map = recent_by_slug or {}
        games: List[OnlineFixGame] = []
        seen_urls: set[str] = set()
        prev_ts = 0.0

        frames = soup.select("div.ui-post-frame")
        if not frames:
            frames = [a.parent for a in soup.select("a[href*='/game/']") if a.parent is not None]

        for frame in frames:
            a_tag = frame.select_one("a[href*='/game/']") or (
                frame if getattr(frame, "name", "") == "a" else None
            )
            if a_tag is None:
                continue
            href = _normalize_url(a_tag.get("href", ""))
            if "/game/" not in href or href in seen_urls:
                continue
            seen_urls.add(href)

            h3 = frame.find("h3")
            title = (
                (" ".join(h3.get_text(" ").split()).strip() if h3 else "")
                or (a_tag.get("title") or "").strip()
                or (" ".join(a_tag.get_text(" ").split()).strip())
            )
            if not title or is_excluded_game(title, href):
                continue

            poster_url = ""
            img = frame.select_one("picture img") or frame.find("img")
            if img:
                poster_url = _normalize_url(img.get("src") or img.get("data-src") or "")
            if not poster_url:
                src_el = frame.select_one("picture source[srcset]")
                if src_el:
                    poster_url = _normalize_url((src_el.get("srcset") or "").split()[0])

            version_str = ""
            is_hv = has_hypervisor_marker(title)
            for sp in frame.find_all("span"):
                st = " ".join(sp.get_text(" ").split()).strip()
                if not st:
                    continue
                if st.upper() in ("HV", "HYPERVISOR") or has_hypervisor_marker(st):
                    is_hv = True
                elif not version_str and (st.upper().startswith(("V ", "V.", "BUILD ")) or "bg-green-500" in " ".join(sp.get("class") or [])):
                    version_str = st

            genre_str = ""
            size_str = ""
            year_str = ""
            for p_tag in frame.find_all("p"):
                p_cls = " ".join(p_tag.get("class") or [])
                p_txt = " ".join(p_tag.get_text(" ").split()).strip()
                if not p_txt:
                    continue
                if "uppercase" in p_cls and not genre_str:
                    genre_str = p_txt
                else:
                    m_sz = _SIZE_TOKEN_RE.search(p_txt)
                    if m_sz:
                        size_str = m_sz.group(0)
                    m_yr = re.search(r"\b(19\d{2}|20\d{2})\b", p_txt)
                    if m_yr:
                        year_str = m_yr.group(1)

            pub_ts = extract_ankergames_poster_ts(poster_url)
            if preserve_list_order_ts:
                if pub_ts > 0 and prev_ts > 0 and pub_ts >= prev_ts:
                    pub_ts = prev_ts - 1.0
                elif pub_ts <= 0 and prev_ts > 0:
                    pub_ts = prev_ts - 60.0
                if pub_ts > 0:
                    prev_ts = pub_ts

            slug = _slug_from_url(href)
            rec = recent_map.get(slug)
            upd_ts = float(rec["updated_ts"]) if rec and rec.get("updated_ts") else 0.0
            if rec and rec.get("version") and not version_str:
                version_str = str(rec["version"])
            if rec and rec.get("is_hypervisor"):
                is_hv = True

            upd_parts = []
            if rec and rec.get("updated_ts"):
                upd_parts.append(f"Cập nhật {format_ts_ddmmyyyy(upd_ts)}")
            if version_str:
                upd_parts.append(version_str)
            if size_str:
                upd_parts.append(f"Dung lượng: {size_str}")
            update_info = " · ".join(p for p in upd_parts if p)

            mode_parts = []
            if genre_str:
                mode_parts.append(f"Thể loại: {genre_str}")
            if year_str:
                mode_parts.append(f"Năm: {year_str}")
            mode_parts.append("Portable cài sẵn")

            game = OnlineFixGame(
                id=slug,
                title=title,
                url=href,
                poster_url=poster_url,
                date=format_ts_ddmmyyyy(pub_ts),
                update_info=update_info,
                game_release=year_str,
                game_modes=" · ".join(mode_parts),
                archive_password=ANKERGAMES_ARCHIVE_PASSWORD,
                source=SOURCE_ANKERGAMES,
                published_ts=pub_ts,
                updated_ts=upd_ts,
                is_hypervisor=is_hv,
            )
            extra_genres = [g.strip() for g in re.split(r"[,/|]+", genre_str) if g.strip()]
            game.categories = classify_game_categories(game, extra_genres=extra_genres)
            games.append(game)

        hv_count = sum(1 for g in games if g.is_hypervisor)
        if hv_count:
            logger.info(f"{TAG} Detected {hv_count} Hypervisor (HV) game(s) in catalog page ({len(games)} total)")
        return games

    # ------------------------------------------------------------ public catalog API

    def get_latest_games(self, page: int = 1) -> List[OnlineFixGame]:
        page = max(1, int(page or 1))
        started = time.monotonic()
        recent_map, recent_games = self._ensure_recent_updates() if page == 1 else (self._recent_by_slug, [])

        url = f"{ANKERGAMES_BASE_URL}/games-list"
        params = {"page": page} if page > 1 else None
        resp = self._get(url, params=params, allow_404_empty=(page > 1))
        if resp is None:
            return []

        games = self._parse_cards_html(resp.text, recent_by_slug=recent_map, preserve_list_order_ts=True)

        # On page 1, append recently updated older releases at the tail (with their true original published_ts
        # and fresh updated_ts) so installed-game update detection and freshest-provider selection see them
        # without ever pushing old games above newer releases!
        if page == 1 and recent_games:
            seen_slugs = {g.id for g in games}
            for rg in recent_games:
                if rg.id not in seen_slugs:
                    seen_slugs.add(rg.id)
                    games.append(rg)

        logger.info(
            f"{TAG} get_latest_games(page={page}) returned {len(games)} game(s) in {time.monotonic() - started:.2f}s"
        )
        return games

    def search_games(self, query: str, page: int = 1) -> List[OnlineFixGame]:
        q = " ".join((query or "").split()).strip()
        if not q:
            return self.get_latest_games(page=page)
        page = max(1, int(page or 1))
        started = time.monotonic()
        url = f"{ANKERGAMES_BASE_URL}/search/{quote(q)}"
        params = {"page": page} if page > 1 else None
        resp = self._get(url, params=params, allow_404_empty=True)
        raw_games = (
            self._parse_cards_html(resp.text, recent_by_slug=self._recent_by_slug, preserve_list_order_ts=False)
            if resp is not None
            else []
        )
        games = [g for g in raw_games if matches_search_query(q, g.title, g.url)]
        if page == 1 and not games:
            dotted = dotted_acronym_query(q)
            if dotted:
                d_resp = self._get(f"{ANKERGAMES_BASE_URL}/search/{quote(dotted)}", allow_404_empty=True)
                if d_resp is not None:
                    d_raw = self._parse_cards_html(
                        d_resp.text, recent_by_slug=self._recent_by_slug, preserve_list_order_ts=False
                    )
                    games = [g for g in d_raw if matches_search_query(q, g.title, g.url)]
        games = sort_games_for_search(q, games)
        logger.info(
            f"{TAG} search_games(query={q!r}, page={page}) returned {len(games)} game(s) "
            f"(raw={len(raw_games)}) in {time.monotonic() - started:.2f}s"
        )
        return games

    def get_category_games(self, category_slug: str, page: int = 1) -> List[OnlineFixGame]:
        path = ANKERGAMES_CATEGORY_PATHS.get(category_slug)
        if not path:
            return []
        page = max(1, int(page or 1))
        started = time.monotonic()
        url = f"{ANKERGAMES_BASE_URL}{path}"
        params = {"page": page} if page > 1 else None
        resp = self._get(url, params=params, allow_404_empty=True)
        if resp is None:
            return []
        games = self._parse_cards_html(resp.text, recent_by_slug=self._recent_by_slug, preserve_list_order_ts=False)
        for g in games:
            if category_slug not in g.categories:
                g.categories = [category_slug] + [c for c in g.categories if c != "other"]
        logger.info(
            f"{TAG} get_category_games(cat={category_slug!r}, page={page}) returned {len(games)} game(s) "
            f"in {time.monotonic() - started:.2f}s"
        )
        return games

    # ------------------------------------------------------------ game details

    def get_game_details(self, game_url: str) -> OnlineFixGame:
        full_url = _normalize_url(game_url)
        if not full_url:
            raise OnlineFixError("URL trang game AnkerGames trống.")

        with self._cache_lock:
            cached = self._details_cache.get(full_url)
            if cached is not None:
                self._details_cache.move_to_end(full_url)
                return cached

        started = time.monotonic()
        resp = self._get(full_url)
        assert resp is not None
        game = self._parse_game_details_html(resp.text, full_url)

        with self._cache_lock:
            self._details_cache[full_url] = game
            if len(self._details_cache) > 192:
                self._details_cache.popitem(last=False)

        logger.info(
            f"{TAG} get_game_details({game.title!r}) extracted {len(game.download_links)} link(s) "
            f"in {time.monotonic() - started:.2f}s"
        )
        return game

    @classmethod
    def _parse_game_details_html(cls, html: str, game_url: str) -> OnlineFixGame:
        soup = bs4.BeautifulSoup(html or "", "html.parser")
        ld_obj: dict = {}
        for sc in soup.find_all("script", type="application/ld+json"):
            raw_json = (sc.string or "").strip()
            if not raw_json:
                continue
            try:
                parsed = json.loads(raw_json)
            except ValueError:
                continue
            items = parsed if isinstance(parsed, list) else [parsed]
            for it in items:
                if isinstance(it, dict) and str(it.get("@type") or "").lower() in ("videogame", "softwareapplication"):
                    ld_obj = it
                    break
            if ld_obj:
                break

        h1 = soup.find("h1")
        title = (
            str(ld_obj.get("name") or "").strip()
            or (" ".join(h1.get_text(" ").split()).strip() if h1 else "")
            or _slug_from_url(game_url).replace("-", " ").title()
        )

        poster_url = ""
        og_img = soup.find("meta", property="og:image")
        for img in soup.select("picture img"):
            cand = _normalize_url(img.get("src") or "")
            if "/uploads/poster/" in cand and "cover-" not in cand:
                poster_url = cand
                break
        if not poster_url and isinstance(ld_obj.get("image"), list):
            for im in ld_obj["image"]:
                if isinstance(im, str) and "cover-" not in im:
                    poster_url = _normalize_url(im)
                    break
        if not poster_url and og_img and og_img.get("content"):
            poster_url = _normalize_url(og_img["content"])

        pub_ts = extract_ankergames_poster_ts(poster_url)
        upd_ts = parse_store_date_ts(str(ld_obj.get("dateModified") or ""))
        if upd_ts <= 0:
            time_el = soup.find("time", datetime=True)
            if time_el:
                upd_ts = parse_store_date_ts(str(time_el.get("datetime") or ""))

        version_str = str(ld_obj.get("softwareVersion") or "").strip()
        file_size = str(ld_obj.get("fileSize") or "").strip()
        if not file_size:
            m_sz = _SIZE_TOKEN_RE.search(soup.get_text(" "))
            if m_sz:
                file_size = m_sz.group(0)

        raw_genres: list[str] = []
        ld_genre = ld_obj.get("genre")
        if isinstance(ld_genre, list):
            raw_genres = [str(g).strip() for g in ld_genre if str(g).strip()]
        elif isinstance(ld_genre, str) and ld_genre.strip():
            raw_genres = [g.strip() for g in re.split(r"[,/|]+", ld_genre) if g.strip()]

        steam_rel = str(ld_obj.get("datePublished") or "").strip()
        upd_parts = []
        if upd_ts > 0:
            upd_parts.append(f"Cập nhật {format_ts_ddmmyyyy(upd_ts)}")
        if version_str:
            upd_parts.append(version_str)
        if file_size:
            upd_parts.append(f"Dung lượng: {file_size}")
        update_info = " · ".join(upd_parts)

        mode_parts = []
        if raw_genres:
            mode_parts.append(f"Thể loại: {', '.join(raw_genres[:4])}")
        mode_parts.append("Portable cài sẵn (Giải nén chơi ngay)")

        dl_links: List[dict] = cls._build_download_links(
            html=html or "",
            soup=soup,
            game_url=game_url,
            file_size=file_size,
            version_str=version_str,
        )

        is_hv = has_hypervisor_marker(title) or any(
            (" ".join(sp.get_text(" ").split()).strip().upper() in ("HV", "HYPERVISOR"))
            for sp in soup.find_all("span")
        ) or any(has_hypervisor_marker(d.get("title", "")) for d in dl_links)
        game = OnlineFixGame(
            id=_slug_from_url(game_url),
            title=title,
            url=game_url,
            poster_url=poster_url,
            date=format_ts_ddmmyyyy(pub_ts) or format_ts_ddmmyyyy(upd_ts),
            update_info=update_info,
            game_release=steam_rel,
            game_modes=" · ".join(mode_parts),
            archive_password=ANKERGAMES_ARCHIVE_PASSWORD,
            download_links=dl_links,
            source=SOURCE_ANKERGAMES,
            published_ts=pub_ts,
            updated_ts=upd_ts,
            is_hypervisor=is_hv,
        )
        game.categories = classify_game_categories(game, extra_genres=raw_genres)
        return game

    @classmethod
    def _extract_download_options(cls, html: str) -> List[Tuple[str, str]]:
        """
        Extract `(dl_id, label)` items from AnkerGames `<template>` download modals and page DOM.
        HTML5 `<template>` contents are parsed explicitly so `<li>Online Fix</li>` vs `<li>Direct</li>`
        labels are never conflated or misordered.
        """
        raw_html = html or ""
        found: List[Tuple[str, str]] = []
        seen_ids: set[str] = set()

        fragments = [m.group(1) for m in _TEMPLATE_BLOCK_RE.finditer(raw_html) if "generateDownloadUrl" in m.group(1)]
        fragments.append(raw_html)

        for frag in fragments:
            frag_soup = bs4.BeautifulSoup(frag, "html.parser")
            for el in frag_soup.find_all(["a", "button"]):
                attr_blob = " ".join(str(v) for v in (el.attrs or {}).values())
                m_id = _GEN_DL_ID_RE.search(attr_blob)
                if not m_id:
                    continue
                dl_id = m_id.group(1)
                if dl_id in seen_ids:
                    continue
                row = el.find_parent("li")
                if row is None and el.parent is not None and el.parent.name in ("div", "td", "p"):
                    row = el.parent
                label = ""
                if row is not None:
                    row_copy = bs4.BeautifulSoup(str(row), "html.parser")
                    for junk in row_copy.find_all(["a", "button", "svg", "code", "script", "style"]):
                        junk.decompose()
                    raw_label = " ".join(row_copy.get_text(" ").split()).strip()
                    raw_label = re.split(r"\bfile\s+integrity\b", raw_label, maxsplit=1, flags=re.IGNORECASE)[0].strip()
                    if raw_label and len(raw_label) <= 120 and raw_label.lower() not in ("download", "loading..."):
                        label = raw_label
                seen_ids.add(dl_id)
                found.append((dl_id, label or "Direct"))

        for m_id in _GEN_DL_ID_RE.finditer(raw_html):
            dl_id = m_id.group(1)
            if dl_id not in seen_ids:
                seen_ids.add(dl_id)
                found.append((dl_id, "Direct"))

        return found

    @classmethod
    def _build_download_links(
        cls,
        *,
        html: str,
        soup: bs4.BeautifulSoup,
        game_url: str,
        file_size: str,
        version_str: str,
    ) -> List[dict]:
        dl_links: List[dict] = []
        options = cls._extract_download_options(html)
        meta_suffix = f" · {file_size}" if file_size else (f" · {version_str}" if version_str else "")

        main_items: List[Tuple[str, str]] = []
        update_items: List[Tuple[str, str]] = []
        fix_items: List[Tuple[str, str]] = []
        for dl_id, label in options:
            if _UPDATE_LABEL_RE.search(label):
                update_items.append((dl_id, label))
            elif _FIX_LABEL_RE.search(label):
                fix_items.append((dl_id, label))
            else:
                main_items.append((dl_id, label))

        if main_items and fix_items:
            combo_ids = ",".join([main_items[0][0]] + [fid for fid, _ in fix_items])
            dl_links.append(
                {
                    "title": f"Tải Full Game + Online Fix (AnkerGames CDN{meta_suffix})",
                    "url": f"ankergames-direct:{combo_ids}|{game_url}",
                    "kind": LINK_TORRENT,
                }
            )
            for mid, mlabel in main_items:
                clean_lbl = mlabel or "Direct"
                dl_links.append(
                    {
                        "title": f"Chỉ tải Full Game ({clean_lbl}{meta_suffix})",
                        "url": f"ankergames-direct:{mid}|{game_url}",
                        "kind": LINK_TORRENT,
                    }
                )
            for uid, ulabel in update_items:
                dl_links.append(
                    {
                        "title": f"Bản cập nhật lẻ ({ulabel})",
                        "url": f"ankergames-direct:{uid}|{game_url}",
                        "kind": LINK_TORRENT,
                    }
                )
            for fid, flabel in fix_items:
                dl_links.append(
                    {
                        "title": f"Chỉ tải {flabel} (AnkerGames CDN)",
                        "url": f"ankergames-direct:{fid}|{game_url}",
                        "kind": LINK_TORRENT,
                    }
                )
        elif main_items:
            first_id, _ = main_items[0]
            dl_links.append(
                {
                    "title": f"Tải Trực Tiếp (AnkerGames CDN{meta_suffix})",
                    "url": f"ankergames-direct:{first_id}|{game_url}",
                    "kind": LINK_TORRENT,
                }
            )
            for mid, mlabel in main_items[1:]:
                dl_links.append(
                    {
                        "title": f"Tải Trực Tiếp ({mlabel}{meta_suffix})",
                        "url": f"ankergames-direct:{mid}|{game_url}",
                        "kind": LINK_TORRENT,
                    }
                )
            for uid, ulabel in update_items:
                dl_links.append(
                    {
                        "title": f"Bản cập nhật lẻ ({ulabel})",
                        "url": f"ankergames-direct:{uid}|{game_url}",
                        "kind": LINK_TORRENT,
                    }
                )
        else:
            for uid, ulabel in update_items:
                dl_links.append(
                    {
                        "title": f"Bản cập nhật lẻ ({ulabel})",
                        "url": f"ankergames-direct:{uid}|{game_url}",
                        "kind": LINK_TORRENT,
                    }
                )
            for fid, flabel in fix_items:
                dl_links.append(
                    {
                        "title": f"Chỉ tải {flabel} (AnkerGames CDN)",
                        "url": f"ankergames-direct:{fid}|{game_url}",
                        "kind": LINK_TORRENT,
                    }
                )

        for a_tag in soup.find_all("a", href=True):
            href = (a_tag.get("href") or "").strip()
            if href.lower().startswith("magnet:?"):
                dl_links.append({"title": "Tải Torrent (Magnet)", "url": href, "kind": LINK_TORRENT})
                break

        dl_links.append({"title": "AnkerGames (Trình duyệt)", "url": game_url, "kind": LINK_WEB})
        return dl_links

    # ------------------------------------------------------------ direct CDN download resolution

    def resolve_torrent_download(self, url: str, referer: str = "") -> str:
        """Resolve `ankergames-direct:<id[,id2,...]>|<game_url>` into an `aria2-list:` payload for Aria2Downloader."""
        if not (url or "").startswith("ankergames-direct:"):
            return url
        payload = url[len("ankergames-direct:"):]
        if "|" in payload:
            raw_ids_str, game_url = payload.split("|", 1)
        else:
            raw_ids_str, game_url = payload, referer or (ANKERGAMES_BASE_URL + "/")
        dl_ids = list(dict.fromkeys(p.strip() for p in raw_ids_str.split(",") if p.strip()))
        game_url = _normalize_url(game_url) or (ANKERGAMES_BASE_URL + "/")
        if not dl_ids or not all(p.isdigit() for p in dl_ids):
            raise OnlineFixError(f"Mã tải AnkerGames không hợp lệ ({raw_ids_str.strip()!r}).")
        return self._resolve_direct_download(dl_ids, game_url)

    @staticmethod
    def _filename_from_cdn_url(cdn_url: str) -> str:
        parsed = urlparse(cdn_url or "")
        base = unquote(os.path.basename(parsed.path or "")).strip()
        if base and any(base.lower().endswith(ext) for ext in (".rar", ".zip", ".7z", ".iso", ".tar")):
            return base
        return ""

    def _resolve_direct_download(self, dl_ids: List[str] | str, game_url: str) -> str:
        ids = [dl_ids] if isinstance(dl_ids, str) else list(dl_ids)
        entries = [self._resolve_direct_download_entry(single_id, game_url) for single_id in ids]
        return "aria2-list:" + json.dumps(entries, ensure_ascii=False)

    def _resolve_direct_download_entry(self, dl_id: str, game_url: str) -> dict:
        started = time.monotonic()
        # Use an isolated session per download resolution so CSRF cookies never collide across concurrent tasks
        sess = requests.Session()
        sess.headers.update({"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9"})

        # Step 1: Fetch fresh session CSRF token (never log the token value!)
        csrf_url = f"{ANKERGAMES_BASE_URL}/csrf-token"
        try:
            r_csrf = sess.get(csrf_url, headers={"Referer": game_url, "Accept": "application/json"}, timeout=15)
        except requests.RequestException as e:
            logger.warning(f"{TAG} GET {csrf_url} failed after {time.monotonic() - started:.2f}s: {e}")
            raise OnlineFixError(
                "Không kết nối được tới AnkerGames để khởi tạo phiên tải. Hãy kiểm tra mạng hoặc bấm 'AnkerGames (Trình duyệt)'."
            ) from e
        if r_csrf.status_code != 200:
            logger.warning(
                f"{TAG} GET {csrf_url} returned HTTP {r_csrf.status_code} in {time.monotonic() - started:.2f}s"
            )
            raise OnlineFixError(f"Không lấy được phiên tải AnkerGames (HTTP {r_csrf.status_code}).")

        try:
            csrf_token = str((r_csrf.json() or {}).get("token") or "").strip()
        except ValueError as e:
            logger.warning(f"{TAG} Invalid JSON from {csrf_url} in {time.monotonic() - started:.2f}s")
            raise OnlineFixError("Phản hồi khởi tạo tải từ AnkerGames không hợp lệ.") from e
        if not csrf_token:
            raise OnlineFixError("AnkerGames không trả về mã phiên tải hợp lệ.")

        # Step 2: Generate stateless signed download ticket URL
        gen_url = f"{ANKERGAMES_BASE_URL}/generate-download-url/{dl_id}"
        try:
            r_gen = sess.post(
                gen_url,
                headers={
                    "X-CSRF-TOKEN": csrf_token,
                    "Referer": game_url,
                    "Accept": "application/json",
                    "X-Requested-With": "XMLHttpRequest",
                },
                json={},
                timeout=15,
            )
        except requests.RequestException as e:
            logger.warning(f"{TAG} POST {gen_url} failed after {time.monotonic() - started:.2f}s: {e}")
            raise OnlineFixError(f"Không tạo được liên kết tải AnkerGames: {e}") from e

        if r_gen.status_code >= 400:
            logger.warning(
                f"{TAG} POST {gen_url} returned HTTP {r_gen.status_code} in {time.monotonic() - started:.2f}s"
            )
            raise OnlineFixError(
                f"Máy chủ AnkerGames từ chối tạo liên kết tải (HTTP {r_gen.status_code}). "
                "Vui lòng bấm nút 'AnkerGames (Trình duyệt)'."
            )

        try:
            gen_data = r_gen.json() or {}
        except ValueError as e:
            logger.warning(f"{TAG} Invalid JSON from {gen_url} in {time.monotonic() - started:.2f}s")
            raise OnlineFixError("Dữ liệu vé tải từ AnkerGames không hợp lệ.") from e

        dl_page_url = _normalize_url(str(gen_data.get("download_url") or ""))
        if not dl_page_url:
            err_msg = str(gen_data.get("message") or gen_data.get("error") or "Không tìm thấy download_url.")
            logger.warning(f"{TAG} {gen_url} returned no download_url: {err_msg}")
            raise OnlineFixError(f"AnkerGames chưa cấp được liên kết tải ({err_msg}).")

        # Step 3: Inspect the download ticket page
        ticket_created_at = time.monotonic()
        try:
            r_dl = sess.get(dl_page_url, headers={"Referer": game_url}, timeout=15)
        except requests.RequestException as e:
            logger.warning(f"{TAG} GET download ticket page failed after {time.monotonic() - started:.2f}s: {e}")
            raise OnlineFixError(f"Không mở được trang vé tải AnkerGames: {e}") from e

        if r_dl.status_code >= 400:
            logger.warning(
                f"{TAG} GET download ticket page returned HTTP {r_dl.status_code} in {time.monotonic() - started:.2f}s"
            )
            raise OnlineFixError(f"Trang vé tải AnkerGames báo lỗi HTTP {r_dl.status_code}.")

        dl_html = r_dl.text or ""
        wait_seconds = 5
        m_init = _DL_PAGE_INIT_RE.search(dl_html)
        if m_init:
            raw_file_url = m_init.group(1).replace(r"\/", "/")
            wait_seconds = max(0, min(20, int(m_init.group(2) or 5)))
        else:
            m_only = _DL_PAGE_URL_ONLY_RE.search(dl_html)
            raw_file_url = m_only.group(1).replace(r"\/", "/") if m_only else ""

        download_file_base = _normalize_url(raw_file_url).split("?")[0]
        if not download_file_base:
            logger.warning(f"{TAG} Could not locate downloadPage() file URL on AnkerGames ticket page")
            raise OnlineFixError(
                "Không tìm thấy đường dẫn tệp trên trang tải AnkerGames. Vui lòng dùng nút 'AnkerGames (Trình duyệt)'."
            )

        soup_dl = bs4.BeautifulSoup(dl_html, "html.parser")
        has_turnstile = bool(soup_dl.select_one("[data-ag-turnstile], .cf-turnstile, [data-sitekey]"))

        if not has_turnstile:
            entry = self._resolve_unchallenged_link(
                sess,
                download_file_base=download_file_base,
                dl_page_url=dl_page_url,
                ticket_created_at=ticket_created_at,
                wait_seconds=wait_seconds,
            )
            if entry is not None:
                logger.info(
                    f"{TAG} Resolved AnkerGames direct CDN link (no Turnstile) for id={dl_id} "
                    f"in {time.monotonic() - started:.2f}s"
                )
                return entry

        cdp_entry = self._resolve_ankergames_via_cdp(
            dl_page_url=dl_page_url,
            download_file_base=download_file_base,
            game_url=game_url,
            wait_seconds=wait_seconds,
        )
        if cdp_entry is not None:
            logger.info(
                f"{TAG} Resolved AnkerGames direct CDN link via CDP for id={dl_id} "
                f"in {time.monotonic() - started:.2f}s"
            )
            return cdp_entry

        raise OnlineFixError(
            "AnkerGames đang bật xác thực Cloudflare Turnstile khắt khe hoặc không tìm thấy trình duyệt Chrome/Edge/Brave "
            "để giải tự động. Vui lòng bấm nút 'AnkerGames (Trình duyệt)' bên dưới để tải."
        )

    def _resolve_unchallenged_link(
        self,
        sess: requests.Session,
        *,
        download_file_base: str,
        dl_page_url: str,
        ticket_created_at: float,
        wait_seconds: int,
    ) -> Optional[dict]:
        remaining = (ticket_created_at + wait_seconds) - time.monotonic()
        if remaining > 0 and not _is_test_env():
            time.sleep(min(remaining + 0.25, 15.0))

        link_api = f"{download_file_base}/link"
        for attempt in range(2):
            try:
                resp = sess.get(
                    link_api,
                    headers={"Accept": "application/json", "Referer": dl_page_url},
                    timeout=15,
                )
            except requests.RequestException as e:
                logger.warning(f"{TAG} GET {link_api} failed: {e}")
                return None

            if resp.status_code == 425 and attempt == 0:
                retry_after = 2
                try:
                    retry_after = max(1, min(15, int((resp.json() or {}).get("retry_after") or 2)))
                except (ValueError, TypeError):
                    pass
                if not _is_test_env():
                    time.sleep(retry_after + 0.25)
                continue

            if resp.status_code == 200:
                try:
                    data = resp.json() or {}
                except ValueError:
                    data = {}
                cdn_link = str(data.get("link") or "").strip()
                if cdn_link.startswith(("http://", "https://")):
                    entry: dict = {
                        "url": cdn_link,
                        "headers": [f"Referer: {ANKERGAMES_BASE_URL}/", f"User-Agent: {USER_AGENT}"],
                    }
                    fname = self._filename_from_cdn_url(cdn_link)
                    if fname:
                        entry["out"] = fname
                    return entry

            logger.warning(f"{TAG} Unchallenged {link_api} returned HTTP {resp.status_code}")
            break

        # Fallback: check 302 redirect on download_file_base itself
        try:
            r_red = sess.get(
                download_file_base,
                headers={"Referer": dl_page_url},
                allow_redirects=False,
                timeout=15,
            )
            loc = (r_red.headers.get("Location") or "").strip()
            if loc.startswith(("http://", "https://")) and "ankergames.net/game/" not in loc:
                entry = {
                    "url": loc,
                    "headers": [f"Referer: {ANKERGAMES_BASE_URL}/", f"User-Agent: {USER_AGENT}"],
                }
                fname = self._filename_from_cdn_url(loc)
                if fname:
                    entry["out"] = fname
                return entry
        except requests.RequestException as e:
            logger.warning(f"{TAG} Fallback redirect probe failed on {download_file_base}: {e}")
        return None

    def _resolve_ankergames_via_cdp(
        self,
        *,
        dl_page_url: str,
        download_file_base: str,
        game_url: str,
        wait_seconds: int,
    ) -> Optional[dict]:
        """Solve AnkerGames Cloudflare Turnstile silently in an off-screen minimized Chromium window via CDP."""
        binaries = SteamRipClient._find_chromium_binaries()
        if not binaries:
            return None

        from app.core.steam_chat.cdp import CdpSession, CdpUnavailable, list_targets

        use_deelevated = (
            sys.platform == "win32"
            and not _is_test_env()
            and getattr(subprocess.Popen, "__module__", "") == "subprocess"
            and is_admin()
        )
        launch_modes = (True, False) if use_deelevated else (False,)
        started = time.monotonic()

        with self._cdp_lock:
            for browser_bin in binaries:
                for deelevate in launch_modes:
                    ud = tempfile.mkdtemp(prefix="bob_ag_cdp_")
                    port = SteamRipClient._pick_free_port()
                    proc = None
                    sess: Optional[CdpSession] = None
                    try:
                        cli_args = [
                            browser_bin,
                            f"--user-data-dir={ud}",
                            f"--remote-debugging-port={port}",
                            "--do-not-de-elevate",
                            "--no-first-run",
                            "--no-default-browser-check",
                            "--window-position=-32000,-32000",
                            "--window-size=900,680",
                            "--disable-background-timer-throttling",
                            "--disable-renderer-backgrounding",
                            "--disable-blink-features=AutomationControlled",
                            "--mute-audio",
                            "about:blank",
                        ]
                        if deelevate:
                            proc = SteamRipClient._spawn_deelevated_win32(cli_args)
                            if proc is None:
                                continue
                        else:
                            popen_kwargs: dict = {
                                "stdout": subprocess.DEVNULL,
                                "stderr": subprocess.DEVNULL,
                            }
                            if sys.platform == "win32":
                                si = subprocess.STARTUPINFO()
                                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                                si.wShowWindow = 7  # SW_SHOWMINNOACTIVE
                                popen_kwargs["startupinfo"] = si
                            proc = subprocess.Popen(cli_args, **popen_kwargs)

                        ws_url = ""
                        for _ in range(40):
                            if hasattr(proc, "poll") and proc.poll() is not None:
                                break
                            try:
                                targets = list_targets(port=port, timeout=1.0)
                                ws_url = next(
                                    (
                                        t["webSocketDebuggerUrl"]
                                        for t in targets
                                        if t.get("type") == "page" and t.get("webSocketDebuggerUrl")
                                    ),
                                    "",
                                )
                                if ws_url:
                                    break
                            except CdpUnavailable:
                                pass
                            time.sleep(0.15)

                        if not ws_url:
                            logger.warning(
                                f"{TAG} AnkerGames CDP target unavailable via {os.path.basename(browser_bin)} "
                                f"(port={port}, deelevate={deelevate})"
                            )
                            continue

                        sess = CdpSession(ws_url, connect_timeout=4.0)
                        try:
                            sess.call("Browser.setDownloadBehavior", {"behavior": "deny"}, timeout=3.0)
                        except Exception:   # noqa: BLE001
                            try:
                                sess.call("Page.setDownloadBehavior", {"behavior": "deny"}, timeout=3.0)
                            except Exception:   # noqa: BLE001
                                pass

                        nav_started = time.monotonic()
                        sess.call("Page.navigate", {"url": dl_page_url, "referrer": game_url}, timeout=12.0)

                        # Poll until Turnstile widget solves (clicking its checkbox once if escalated)
                        turnstile_ready = False
                        clicked_checkbox = False
                        for step in range(45):
                            time.sleep(0.5)
                            try:
                                st = sess.evaluate(
                                    "(() => {"
                                    "  if (!document.body) return {s: 'boot'};"
                                    "  if (window.agTurnstile) {"
                                    "    try { window.agTurnstile.ensure(); } catch (e) {}"
                                    "    const t = window.agTurnstile.token();"
                                    "    if (t) return {s: 'solved'};"
                                    "    const ifr = document.querySelector('iframe[src*=\"challenges.cloudflare.com\"]');"
                                    "    if (ifr) {"
                                    "      const r = ifr.getBoundingClientRect();"
                                    "      return {s: 'pending', x: r.left + 28, y: r.top + r.height / 2, w: r.width};"
                                    "    }"
                                    "    return {s: 'pending'};"
                                    "  }"
                                    "  if (document.querySelector('[data-ag-turnstile], .cf-turnstile')) return {s: 'boot'};"
                                    "  return {s: 'none'};"
                                    "})()",
                                    timeout=3.0,
                                    await_promise=False,
                                )
                            except Exception:   # noqa: BLE001
                                st = None
                            if not isinstance(st, dict):
                                continue
                            status_code = st.get("s")
                            if status_code in ("solved", "none"):
                                turnstile_ready = True
                                break
                            if (
                                status_code == "pending"
                                and not clicked_checkbox
                                and step >= 8
                                and float(st.get("w") or 0) > 40
                            ):
                                cx = float(st.get("x") or 0)
                                cy = float(st.get("y") or 0)
                                if cx > 0 and cy > 0:
                                    clicked_checkbox = True
                                    try:
                                        sess.call(
                                            "Input.dispatchMouseEvent",
                                            {"type": "mousePressed", "x": cx, "y": cy, "button": "left", "clickCount": 1},
                                            timeout=2.0,
                                        )
                                        sess.call(
                                            "Input.dispatchMouseEvent",
                                            {"type": "mouseReleased", "x": cx, "y": cy, "button": "left", "clickCount": 1},
                                            timeout=2.0,
                                        )
                                    except Exception:   # noqa: BLE001
                                        pass

                        if not turnstile_ready:
                            logger.warning(
                                f"{TAG} AnkerGames CDP Turnstile did not solve within timeout via {os.path.basename(browser_bin)}"
                            )
                            continue

                        # Ensure server-side countdown window has elapsed
                        left_wait = (nav_started + wait_seconds) - time.monotonic()
                        if left_wait > 0:
                            time.sleep(min(left_wait + 0.3, 12.0))

                        # Redeem `/download-file/<hash>/link` inside the browser (never returning or logging the token!)
                        base_js = json.dumps(download_file_base)
                        info = sess.evaluate(
                            f"(async () => {{"
                            f"  const base = {base_js};"
                            f"  const tok = (window.agTurnstile && window.agTurnstile.token()) ? String(window.agTurnstile.token()) : '';"
                            f"  const u = base + '/link' + (tok ? ('?cf-turnstile-response=' + encodeURIComponent(tok)) : '');"
                            f"  let r = await fetch(u, {{ headers: {{ 'Accept': 'application/json' }} }});"
                            f"  let d = await r.json().catch(() => ({{}}));"
                            f"  if (r.status === 425 && d && d.reason === 'wait_required') {{"
                            f"    const w = Math.min(15, Math.max(1, parseInt(d.retry_after, 10) || 2));"
                            f"    await new Promise(res => setTimeout(res, w * 1000 + 300));"
                            f"    r = await fetch(u, {{ headers: {{ 'Accept': 'application/json' }} }});"
                            f"    d = await r.json().catch(() => ({{}}));"
                            f"  }}"
                            f"  return {{"
                            f"    status: r.status,"
                            f"    link: (d && d.link) ? String(d.link) : '',"
                            f"    error: (d && d.error) ? String(d.error) : '',"
                            f"    ua: navigator.userAgent || ''"
                            f"  }};"
                            f"}})()",
                            timeout=22.0,
                            await_promise=True,
                        )
                        try:
                            sess.call("Browser.close", {}, timeout=1.5)
                        except Exception:   # noqa: BLE001
                            pass

                        if isinstance(info, dict) and str(info.get("link") or "").startswith(("http://", "https://")):
                            cdn_link = str(info["link"]).strip()
                            ua = str(info.get("ua") or USER_AGENT).strip()
                            entry: dict = {
                                "url": cdn_link,
                                "headers": [f"Referer: {ANKERGAMES_BASE_URL}/", f"User-Agent: {ua}"],
                            }
                            fname = self._filename_from_cdn_url(cdn_link)
                            if fname:
                                entry["out"] = fname
                            return entry

                        logger.warning(
                            f"{TAG} AnkerGames CDP /link returned status={info.get('status') if isinstance(info, dict) else None} "
                            f"error={info.get('error') if isinstance(info, dict) else info!r}"
                        )
                    except Exception as e:   # noqa: BLE001
                        logger.warning(
                            f"{TAG} AnkerGames CDP attempt ({os.path.basename(browser_bin)}, deelevate={deelevate}) "
                            f"failed after {time.monotonic() - started:.2f}s: {e}"
                        )
                    finally:
                        if sess is not None:
                            try:
                                sess.close()
                            except Exception:   # noqa: BLE001
                                pass
                        if proc is not None:
                            try:
                                if not hasattr(proc, "poll") or proc.poll() is None:
                                    proc.terminate()
                                proc.wait(timeout=3)
                            except Exception:   # noqa: BLE001
                                try:
                                    proc.kill()
                                except Exception:   # noqa: BLE001
                                    pass
                        shutil.rmtree(ud, ignore_errors=True)
        return None
