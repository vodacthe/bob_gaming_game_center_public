"""
Aria2c BitTorrent Downloader wrapper.
Spawns background aria2c process to download .torrent files and magnet links,
parsing real-time speed, progress, and ETA.
"""

import concurrent.futures
import http.server
import logging
import os
import random
import re
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
from collections import deque
from typing import Callable, Optional

from app.config import CONFIG_DIR, get_app_dir

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/Aria2]"

# Regex for parsing aria2c console progress line:
# e.g.: [#b8d2cb 32MiB/2.1GiB(1%) CN:8 SD:12 DL:4.2MiB ETA:8m20s]
PROGRESS_REGEX = re.compile(
    r"\[#\w+\s+([\d\.]+\w+)/([\d\.]+\w+)\((\d+)%\).*?DL:([\d\.]+\w+)(?:.*?ETA:([\w\d]+))?"
)
_GID_RE = re.compile(r"\[#(\w+)\s+")
_SIZE_STR_RE = re.compile(r"^\s*([\d\.]+)\s*([a-zA-Z]*)\s*$")
_INFOHASH_RE = re.compile(r"(?:xt=urn:btih:|Info Hash:\s*)([0-9a-fA-F]{40})", re.IGNORECASE)
_FILE_ROW_RE = re.compile(r"^\s*(\d+)\|(.+)$")


def parse_size_to_bytes(size_str: str) -> int:
    """Convert aria2c / human size strings like '32MiB', '1.9GiB', '380.2 MB' into integer bytes."""
    if not size_str:
        return 0
    s = size_str.strip()
    if s.isdigit():
        return int(s)
    m = _SIZE_STR_RE.match(s)
    if not m:
        return 0
    try:
        val = float(m.group(1))
    except ValueError:
        return 0
    unit = m.group(2).lower()
    if unit in ("k", "kb", "kib"):
        return int(val * 1024)
    if unit in ("m", "mb", "mib"):
        return int(val * (1024 ** 2))
    if unit in ("g", "gb", "gib"):
        return int(val * (1024 ** 3))
    if unit in ("t", "tb", "tib"):
        return int(val * (1024 ** 4))
    return int(val)


def format_bytes(num_bytes: int) -> str:
    """Format byte count into a human-readable string (e.g. '895.0 MB', '27.80 GB')."""
    b = max(0, int(num_bytes or 0))
    if b < 1024:
        return f"{b} B"
    if b < 1024 ** 2:
        return f"{b / 1024:.1f} KB"
    if b < 1024 ** 3:
        return f"{b / (1024 ** 2):.1f} MB"
    return f"{b / (1024 ** 3):.2f} GB"


def format_eta(seconds: float) -> str:
    """Format remaining seconds into aria2-style compact duration (e.g. '14m32s', '1h05m')."""
    sec = max(0, int(seconds))
    if sec <= 0:
        return "--"
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    if h > 0:
        return f"{h}h{m:02d}m"
    if m > 0:
        return f"{m}m{s:02d}s"
    return f"{s}s"

_UDP_TRACKERS = (
    ("tracker.opentrackr.org", 1337),
    ("open.demonii.com", 1337),
    ("open.stealth.si", 80),
    ("tracker.torrent.eu.org", 451),
    ("explodie.org", 6969),
    ("exodus.desync.com", 6969),
    ("p4p.arenabg.com", 1337),
    ("tracker.dler.org", 6969),
    ("tracker.openbittorrent.com", 6969),
    ("uploads.gamecoast.net", 6969),
    ("tracker.cyberia.is", 6969),
    ("tracker.tiny-vps.com", 6969),
    ("tracker.qu.ax", 6969),
    ("opentracker.io", 6969),
)

_LIVE_TRACKERS_CSV = (
    "http://tracker.opentrackr.org:1337/announce,"
    "udp://tracker.opentrackr.org:1337/announce,"
    "udp://open.stealth.si:80/announce,"
    "udp://tracker.torrent.eu.org:451/announce,"
    "udp://open.demonii.com:1337/announce,"
    "udp://exodus.desync.com:6969/announce,"
    "udp://tracker.dler.org:6969/announce"
)


def _query_udp_tracker(host_port: tuple[str, int], info_hash: bytes, timeout: float = 2.5) -> bytes:
    """Perform a BEP-15 UDP tracker connect + announce and return compact 6-byte IPv4 peers."""
    host, port = host_port
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout)
    try:
        tid = random.randint(1, 0x7FFFFFFF)
        sock.sendto(struct.pack("!QII", 0x41727101980, 0, tid), (host, port))
        data, _ = sock.recvfrom(1024)
        if len(data) < 16:
            return b""
        action, rtid, cid = struct.unpack("!IIQ", data[:16])
        if action != 0 or rtid != tid:
            return b""
        tid = random.randint(1, 0x7FFFFFFF)
        peer_id = b"-qB4650-" + os.urandom(12)
        pkt = struct.pack(
            "!QII20s20sQQQIIIiH",
            cid, 1, tid, info_hash, peer_id,
            0, 1024 * 1024 * 1024, 0,
            2, 0, random.randint(1, 0x7FFFFFFF), 200, 6881,
        )
        sock.sendto(pkt, (host, port))
        data, _ = sock.recvfrom(8192)
        if len(data) < 20:
            return b""
        action, rtid, _interval, _leechers, _seeders = struct.unpack("!IIIII", data[:20])
        if action != 1 or rtid != tid:
            return b""
        return data[20:]
    except OSError:
        return b""
    finally:
        sock.close()


class _LocalTrackerAggregator:
    """
    Queries multiple UDP trackers in parallel (numwant=200 each) and serves the combined
    compact peer list (typically 500–1,000 unique peers) to aria2c via a loopback HTTP tracker.
    """

    def __init__(self, info_hash: bytes):
        self.info_hash = info_hash
        self.peers: set[bytes] = set()
        self._server: Optional[http.server.HTTPServer] = None
        self.port: int = 0

    def start(self) -> Optional[str]:
        started = time.monotonic()
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(_UDP_TRACKERS)) as pool:
                results = list(pool.map(lambda hp: _query_udp_tracker(hp, self.info_hash), _UDP_TRACKERS))
            for raw in results:
                for i in range(0, len(raw) - 5, 6):
                    self.peers.add(raw[i:i + 6])
        except Exception as e:   # noqa: BLE001
            logger.debug(f"{TAG} Multi-tracker peer harvest failed: {e}")
            return None

        if not self.peers:
            return None

        peer_blob = b"".join(self.peers)

        class _Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self_h):
                body = (
                    b"d8:completei2000e10:incompletei2000e8:intervali45e12:min intervali20e5:peers"
                    + str(len(peer_blob)).encode("ascii")
                    + b":"
                    + peer_blob
                    + b"e"
                )
                self_h.send_response(200)
                self_h.send_header("Content-Type", "text/plain")
                self_h.send_header("Content-Length", str(len(body)))
                self_h.end_headers()
                self_h.wfile.write(body)

            def log_message(self_h, format, *args):   # noqa: A002
                pass

        try:
            self._server = http.server.HTTPServer(("127.0.0.1", 0), _Handler)
            self.port = self._server.server_port
            threading.Thread(target=self._server.serve_forever, daemon=True, name="aria2-tracker-agg").start()
            logger.info(
                f"{TAG} Multi-tracker aggregator harvested {len(self.peers)} unique peers in "
                f"{time.monotonic() - started:.2f}s (http://127.0.0.1:{self.port}/announce)"
            )
            return f"http://127.0.0.1:{self.port}/announce"
        except OSError as e:
            logger.debug(f"{TAG} Could not bind local tracker aggregator: {e}")
            return None

    def stop(self):
        srv = self._server
        self._server = None
        if srv is not None:
            try:
                srv.shutdown()
                srv.server_close()
            except Exception:   # noqa: BLE001
                pass


def find_aria2c_binary() -> Optional[str]:
    """Find aria2c or aria2 executable across platforms."""
    from app.core.binary_finder import find_aria2c
    return find_aria2c()



def _inspect_torrent(binary_path: str, torrent_path: str) -> tuple[Optional[bytes], Optional[str]]:
    """
    Run 'aria2c --show-files <torrent_path>' to extract the 20-byte info_hash
    for UDP tracker pre-probing. All files in the torrent (including optional packs) are downloaded.
    """
    if not os.path.isfile(binary_path) or not os.path.isfile(torrent_path):
        return None, None

    startupinfo = None
    creationflags = 0
    if sys.platform == "win32":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        creationflags = subprocess.CREATE_NO_WINDOW

    try:
        out = subprocess.check_output(
            [binary_path, "--show-files", torrent_path],
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=5,
            startupinfo=startupinfo,
            creationflags=creationflags,
        )
    except Exception as e:   # noqa: BLE001
        logger.debug(f"{TAG} Could not inspect torrent {torrent_path}: {e}")
        return None, None

    info_hash: Optional[bytes] = None
    m_ih = _INFOHASH_RE.search(out)
    if m_ih:
        try:
            info_hash = bytes.fromhex(m_ih.group(1))
        except ValueError:
            info_hash = None

    return info_hash, None


class Aria2Downloader:
    """Manages an active aria2c download process."""

    def __init__(
        self,
        source: str,
        download_dir: str,
        on_progress: Optional[Callable[[float, str, str, str], None]] = None,
        on_completed: Optional[Callable[[list[str]], None]] = None,
        on_error: Optional[Callable[[str], None]] = None,
    ):
        """
        :param source: Local path to .torrent file, magnet:? URI, or 'list:<input_file>'
        :param download_dir: Directory where downloaded game files will be saved
        :param on_progress: callback(percent: float, speed: str, downloaded_str: str, eta: str)
        :param on_completed: callback(downloaded_files: list[str])
        :param on_error: callback(error_message: str)
        """
        self.source = source
        self.download_dir = download_dir
        self.on_progress = on_progress
        self.on_completed = on_completed
        self.on_error = on_error
        self.initial_percent: float = 0.0

        self._process: Optional[subprocess.Popen] = None
        self._thread: Optional[threading.Thread] = None
        self._tracker_agg: Optional[_LocalTrackerAggregator] = None
        self._cancelled = False
        self._paused = False
        self._completed = False
        self._lock = threading.Lock()

    def start(self):
        """Start downloading in a background daemon thread."""
        binary = find_aria2c_binary()
        if not binary:
            logger.error(f"{TAG} Cannot start download into {self.download_dir}: aria2c missing")
            if self.on_error:
                exe_label = "aria2c.exe" if sys.platform == "win32" else "aria2c"
                self.on_error(f"Không tìm thấy tệp thực thi {exe_label} trên hệ thống.")
            return

        os.makedirs(self.download_dir, exist_ok=True)

        self._cancelled = False
        self._paused = False
        self._completed = False
        self._thread = threading.Thread(target=self._run_process, args=(binary,), daemon=True, name="aria2-download")
        self._thread.start()

    def _stop_process(self, graceful: bool = False):
        with self._lock:
            proc = self._process
            agg = self._tracker_agg
            self._tracker_agg = None
        if agg is not None:
            agg.stop()
        if proc and proc.poll() is None:
            try:
                if graceful and sys.platform == "win32":
                    import signal
                    try:
                        proc.send_signal(signal.CTRL_BREAK_EVENT)
                        proc.wait(timeout=1.5)
                        return
                    except Exception:
                        pass
                logger.info(f"{TAG} Terminating download process (pid {proc.pid})")
                proc.terminate()
                proc.wait(timeout=3)
            except Exception:   # noqa: BLE001
                try:
                    proc.kill()
                except Exception as e:   # noqa: BLE001
                    logger.warning(f"{TAG} Could not kill aria2c (pid {proc.pid}): {e}")

    def pause(self):
        """Pause the active download process, flushing aria2c control state for later resume."""
        with self._lock:
            self._paused = True
            self._cancelled = True
        self._stop_process(graceful=True)

    def cancel(self):
        """Cancel and terminate the active download process."""
        with self._lock:
            self._cancelled = True
        self._stop_process(graceful=False)

    def is_running(self) -> bool:
        return self._process is not None and self._process.poll() is None

    def _has_partial_files_without_aria2_control(self) -> bool:
        """Return True if payload files exist in download_dir without a .aria2 control file (e.g. hard crash)."""
        if not os.path.isdir(self.download_dir):
            return False
        has_ctrl = False
        has_payload = False
        try:
            for _, _, fns in os.walk(self.download_dir):
                for fn in fns:
                    low = fn.lower()
                    if low.endswith(".aria2"):
                        has_ctrl = True
                    elif not low.endswith((".torrent", ".txt")):
                        has_payload = True
        except OSError:
            return False
        return has_payload and not has_ctrl

    def _build_command(self, binary_path: str) -> tuple[list[str], int, Optional[str]]:
        """Build the aria2c command line, returning (cmd, total_parts, input_list_path)."""
        self._precompleted_parts = 0
        self._precompleted_bytes = 0
        self._known_total_bytes = 0
        if self.source.startswith("list:"):
            list_path = self.source[len("list:"):]
            total_parts = 1
            try:
                with open(list_path, "r", encoding="utf-8") as f:
                    lines = [ln.rstrip("\r\n") for ln in f]
                active_parts = sum(1 for ln in lines if ln.strip() and not ln.startswith((" ", "#")))
                pre_done = 0
                pre_bytes = 0
                known_total = 0
                for ln in lines:
                    if ln.startswith("# completed:"):
                        pre_done += 1
                        rest = ln[len("# completed:"):].strip()
                        parts_tab = rest.split("\t")
                        fname = parts_tab[0].strip()
                        sz = int(parts_tab[1]) if len(parts_tab) > 1 and parts_tab[1].isdigit() else 0
                        if sz <= 0 and fname:
                            fp = os.path.join(self.download_dir, fname)
                            if os.path.isfile(fp):
                                try:
                                    sz = os.path.getsize(fp)
                                except OSError:
                                    sz = 0
                        pre_bytes += sz
                        known_total += sz
                    elif ln.startswith("# size:"):
                        sz_str = ln[len("# size:"):].strip()
                        if sz_str.isdigit():
                            known_total += int(sz_str)
                self._precompleted_parts = pre_done
                self._precompleted_bytes = pre_bytes
                self._known_total_bytes = known_total
                total_parts = max(1, active_parts + pre_done)
            except OSError:
                pass
            cmd = [
                binary_path,
                f"--dir={self.download_dir}",
                f"--input-file={list_path}",
                "--max-connection-per-server=16",
                "--split=16",
                "--min-split-size=1M",
                "--max-concurrent-downloads=2",
                "--continue=true",
                "--auto-file-renaming=false",
                "--allow-overwrite=true",
                "--auto-save-interval=5",
                "--summary-interval=1",
                "--console-log-level=notice",
                "--file-allocation=none",
            ]
            return cmd, total_parts, list_path

        info_hash: Optional[bytes] = None
        select_arg: Optional[str] = None
        if self.source.startswith("magnet:?"):
            m_ih = _INFOHASH_RE.search(self.source)
            if m_ih:
                try:
                    info_hash = bytes.fromhex(m_ih.group(1))
                except ValueError:
                    info_hash = None
        else:
            info_hash, select_arg = _inspect_torrent(binary_path, self.source)

        agg_url: Optional[str] = None
        if info_hash is not None and not self._cancelled:
            agg = _LocalTrackerAggregator(info_hash)
            agg_url = agg.start()
            if agg_url:
                with self._lock:
                    self._tracker_agg = agg

        os.makedirs(CONFIG_DIR, exist_ok=True)
        dht_file = os.path.join(CONFIG_DIR, "dht.dat")

        cmd = [
            binary_path,
            f"--dir={self.download_dir}",
            "--continue=true",
            "--auto-save-interval=5",
            "--auto-file-renaming=false",
            "--allow-overwrite=true",
            "--enable-dht=true",
            "--dht-entry-point=dht.transmissionbt.com:6881",
            f"--dht-file-path={dht_file}",
            "--bt-enable-lpd=true",
            "--enable-peer-exchange=true",
            "--bt-max-peers=0",
            "--bt-request-peer-speed-limit=100M",
            "--bt-tracker-connect-timeout=5",
            "--bt-tracker-timeout=5",
            "--bt-load-saved-metadata=true",
            "--bt-save-metadata=true",
            "--peer-id-prefix=-qB4650-",
            "--peer-agent=qBittorrent/4.6.5",
            "--seed-time=0",
            "--summary-interval=1",
            "--max-connection-per-server=16",
            "--console-log-level=notice",
            "--file-allocation=none",
        ]
        if self._has_partial_files_without_aria2_control():
            cmd.append("--check-integrity=true")
        if select_arg:
            cmd.append(select_arg)
        if agg_url:
            cmd.append("--bt-exclude-tracker=*")
            cmd.append(f"--bt-tracker={agg_url},{_LIVE_TRACKERS_CSV}")
        else:
            cmd.append(f"--bt-tracker={_LIVE_TRACKERS_CSV}")
        cmd.append(self.source)
        return cmd, 1, None

    def _run_process(self, binary_path: str):
        cmd, total_parts, input_list_path = self._build_command(binary_path)

        logger.info(f"{TAG} Starting aria2c: source={self.source[:160]} dir={self.download_dir}")
        logger.debug(f"{TAG} Command: {' '.join(cmd)}")

        startupinfo = None
        creationflags = 0
        if sys.platform == "win32":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            creationflags = subprocess.CREATE_NO_WINDOW | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)

        started = time.monotonic()
        tail: deque[str] = deque(maxlen=8)   # last non-progress lines: the error message when aria2c fails
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                startupinfo=startupinfo,
                creationflags=creationflags,
                bufsize=1,
            )
            with self._lock:
                self._process = proc
                cancelled = self._cancelled
            if cancelled:                                    # cancel() ran before the process existed
                proc.terminate()
            logger.info(f"{TAG} aria2c running (pid {proc.pid})")

            last_percent = float(getattr(self, "initial_percent", 0.0) or 0.0)
            completed_parts = int(getattr(self, "_precompleted_parts", 0) or 0)
            precompleted_bytes = int(getattr(self, "_precompleted_bytes", 0) or 0)
            known_total_bytes = int(getattr(self, "_known_total_bytes", 0) or 0)
            gid_done: dict[str, int] = {}
            gid_total: dict[str, int] = {}
            gid_speed: dict[str, int] = {}
            gid_completed: set[str] = set()
            last_logged_decile = -1

            for line in proc.stdout:
                line_str = line.strip()
                if not line_str:
                    continue

                low_line = line_str.lower()
                if total_parts > 1 and ("download complete:" in low_line or "download already complete:" in low_line):
                    completed_parts = min(total_parts - 1, completed_parts + 1)
                    active_gids = [g for g in gid_done if g not in gid_completed]
                    if active_gids:
                        best_gid = max(active_gids, key=lambda g: gid_done[g] / max(1, gid_total.get(g, 1)))
                        gid_done[best_gid] = max(gid_done[best_gid], gid_total.get(best_gid, 0))
                        gid_speed[best_gid] = 0
                        gid_completed.add(best_gid)

                # Match progress
                match = PROGRESS_REGEX.search(line_str)
                if match:
                    done_str, total_str, percent_str, speed_str, eta_str = match.groups()
                    m_gid = _GID_RE.search(line_str)
                    gid = m_gid.group(1) if m_gid else "main"
                    done_b = parse_size_to_bytes(done_str)
                    total_b = parse_size_to_bytes(total_str)
                    spd_b = parse_size_to_bytes(speed_str.removesuffix("/s"))
                    gid_done[gid] = done_b
                    if total_b > 0:
                        gid_total[gid] = total_b
                    gid_speed[gid] = spd_b

                    try:
                        part_pct = float(percent_str)
                    except ValueError:
                        part_pct = last_percent

                    if total_parts > 1:
                        overall_done_b = precompleted_bytes + sum(gid_done.values())
                        if known_total_bytes > 0:
                            overall_total_b = max(known_total_bytes, overall_done_b)
                        else:
                            known_cnt = int(getattr(self, "_precompleted_parts", 0) or 0) + len(gid_total)
                            known_sum = precompleted_bytes + sum(gid_total.values())
                            if known_cnt > 0 and known_sum > 0:
                                avg_b = known_sum / known_cnt
                                overall_total_b = int(known_sum + max(0, total_parts - known_cnt) * avg_b)
                            else:
                                overall_total_b = total_b * total_parts
                        if overall_total_b > 0:
                            pct = min(99.0, (overall_done_b * 100.0) / overall_total_b)
                        else:
                            pct = min(99.0, ((completed_parts * 100.0) + part_pct) / total_parts)
                        active_spd_b = sum(v for k, v in gid_speed.items() if k not in gid_completed)
                        if active_spd_b > 0:
                            speed = f"{format_bytes(active_spd_b)}/s"
                            rem_b = max(0, overall_total_b - overall_done_b)
                            eta = format_eta(rem_b / active_spd_b) if rem_b > 0 else "--"
                        else:
                            eta = eta_str if eta_str else "--"
                            speed = f"{speed_str}/s" if not speed_str.endswith("/s") else speed_str
                    else:
                        overall_done_b = done_b
                        overall_total_b = total_b
                        pct = part_pct
                        eta = eta_str if eta_str else "--"
                        speed = f"{speed_str}/s" if not speed_str.endswith("/s") else speed_str

                    last_percent = max(last_percent, pct)
                    size_report = (
                        f"{overall_done_b}/{overall_total_b}"
                        if overall_total_b > 0
                        else f"{done_str}/{total_str}"
                    )

                    if int(last_percent) // 25 > last_logged_decile:     # milestones only: 0/25/50/75%
                        last_logged_decile = int(last_percent) // 25
                        logger.info(
                            f"{TAG} Progress {int(last_percent)}% "
                            f"({format_bytes(overall_done_b)}/{format_bytes(overall_total_b)}, {speed}, ETA {eta})"
                        )

                    if self.on_progress:
                        self.on_progress(last_percent, speed, size_report, eta)
                elif not line_str.startswith(("***", "===", "---", "FILE:")):
                    tail.append(line_str)

                if "download completed." in line_str.lower():
                    self._completed = True

            proc.wait()
            retcode = proc.returncode
            elapsed = time.monotonic() - started

            if self._paused:
                logger.info(f"{TAG} Download paused by user after {elapsed:.1f}s (progress {last_percent:.1f}%)")
                return
            if self._cancelled:
                logger.info(f"{TAG} Download cancelled by user after {elapsed:.1f}s")
                return

            if input_list_path and os.path.isfile(input_list_path):
                try:
                    os.remove(input_list_path)
                except OSError:
                    pass

            if retcode == 0 or self._completed:
                logger.info(f"{TAG} Download completed in {elapsed:.1f}s into {self.download_dir}")
                files = []
                for root, _, filenames in os.walk(self.download_dir):
                    for fn in filenames:
                        fn_low = fn.lower()
                        full_path = os.path.join(root, fn)
                        if fn_low.endswith(".aria2"):
                            try:
                                os.remove(full_path)
                            except OSError:
                                pass
                            continue
                        files.append(full_path)

                if self.on_completed:
                    self.on_completed(files)
            else:
                err_msg = f"Tải thất bại (aria2c mã lỗi {retcode})"
                logger.error(f"{TAG} aria2c exited with code {retcode} after {elapsed:.1f}s. "
                             f"Last output: {' | '.join(tail)}")
                if self.on_error:
                    self.on_error(err_msg)

        except Exception as e:   # noqa: BLE001 - thread boundary: report, never raise
            logger.error(f"{TAG} Exception in aria2 execution: {e}", exc_info=True)
            if not self._cancelled and self.on_error:
                self.on_error(str(e))
        finally:
            with self._lock:
                agg = self._tracker_agg
                self._tracker_agg = None
            if agg is not None:
                agg.stop()

