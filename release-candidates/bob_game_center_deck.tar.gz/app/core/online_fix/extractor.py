"""
Archive Extractor for Online-Fix games.
Extracts multi-volume and password-protected (.rar, .7z, .zip) archives
using bundled 7z.exe or py7zr fallback, then detects the game's main .exe.
"""

import os
import sys
import re
import shutil
import logging
import subprocess
import threading
import time
import uuid
from collections import deque
from typing import Callable, Optional

from app.config import get_app_dir
from app.core.online_fix.models import DEFAULT_ARCHIVE_PASSWORD, STEAMRIP_ARCHIVE_PASSWORD

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/Extract]"

DEFAULT_PASSWORD = DEFAULT_ARCHIVE_PASSWORD

# Exclude non-game executables during auto-detection
EXCLUDED_EXE_PATTERNS = {
    "unins000.exe", "uninstall.exe", "crashreport.exe", "unitycrashhandler64.exe",
    "unitycrashhandler32.exe", "dxsetup.exe", "dxwebsetup.exe", "vc_redist", "vcredist",
    "easyanticheat", "battleye", "epicgameslauncher", "originthinsetup",
    "dotnet", "directx", "setup.exe", "autorun.exe", "quicksfv.exe", "quicksfv",
    "aria2c.exe", "aria2.exe", "7z.exe", "7za.exe",
}

# Protected tool binaries that must NEVER be deleted during cleanup
PROTECTED_BINARIES = {
    "aria2c.exe", "aria2.exe", "aria2c", "aria2",
    "7z.exe", "7za.exe", "7z.dll", "7z", "7za", "7zz", "7zz.exe",
}


def is_protected_tool(name_or_path: str) -> bool:
    """Return True if the file is a system or bundled tool that must NEVER be deleted."""
    basename = os.path.basename(name_or_path).lower()
    return basename in PROTECTED_BINARIES


def find_7z_binary() -> Optional[str]:
    """Locate 7z / 7zz executable across platforms."""
    from app.core.binary_finder import find_7z
    res = find_7z()
    if res:
        logger.info(f"{TAG} Found 7z on system PATH: {res}")
    else:
        logger.warning(f"{TAG} 7z executable not found (RAR archives cannot be extracted)")
    return res



FIX_NAME_PATTERNS = (
    "fix_repair", "fix repair", "fix-repair",
    "onlinefix", "online-fix", "online_fix",
    "steamfix", "steam-fix", "steam_fix",
    "crack", "nodvd",
)


def is_fix_name(name: str) -> bool:
    """Check if file or folder name indicates an OnlineFix / crack / repair patch."""
    lower = name.lower()
    base, _ = os.path.splitext(lower)
    if any(pat in base for pat in FIX_NAME_PATTERNS):
        return True
    if re.search(r"(?:^|[\W_])fix(?:[\W_]|$)", base):
        return True
    return False


_FIRST_PART_RE = re.compile(r"(?:^|\.)part0*1\.(?:rar|7z)$", re.IGNORECASE)
_SECONDARY_PART_RE = re.compile(r"(?:^|\.)part(?!0*1\.)\d+\.(?:rar|7z)$", re.IGNORECASE)


def clean_subprocess_env() -> dict[str, str]:
    """
    Return a copy of os.environ stripped of PyInstaller bootloader variables
    (_MEIPASS, _MEIPASS2, PYTHONHOME, PYTHONPATH, QT_PLUGIN_PATH, etc.) and
    reset Windows' DLL search directory (SetDllDirectoryW(None)).
    Prevents child games packaged with PyInstaller (e.g. God of War III.exe)
    from failing with 'Failed to start embedded python interpreter' when launched
    from a frozen BobGamingGameCenter.exe build.
    """
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.kernel32.SetDllDirectoryW(None)
        except Exception:   # noqa: BLE001
            pass

    env = os.environ.copy()
    for var in (
        "_MEIPASS",
        "_MEIPASS2",
        "PYTHONHOME",
        "PYTHONPATH",
        "PYTHONEXECUTABLE",
        "PYINSTALLER_RESET_ENVIRONMENT",
        "TCL_LIBRARY",
        "TK_LIBRARY",
        "QT_PLUGIN_PATH",
        "QML2_IMPORT_PATH",
    ):
        env.pop(var, None)

    meipass = getattr(sys, "_MEIPASS", None)
    path_val = env.get("PATH", "")
    if path_val:
        parts = path_val.split(os.pathsep)
        cleaned_parts = [
            p for p in parts
            if p
            and (not meipass or os.path.normcase(os.path.abspath(p)) != os.path.normcase(os.path.abspath(meipass)))
            and "\\_mei" not in p.lower()
        ]
        env["PATH"] = os.pathsep.join(cleaned_parts)

    return env


def find_fix_archives(folder_path: str) -> list[str]:
    """Find archive files representing fix / crack / repair packages in folder."""
    fix_archives = []
    if not os.path.exists(folder_path):
        return fix_archives
    for root, _, files in os.walk(folder_path):
        for f in files:
            ext = f.lower()
            if ext.endswith((".rar", ".7z", ".zip")) and is_fix_name(f):
                if not _SECONDARY_PART_RE.search(f):
                    fix_archives.append(os.path.join(root, f))
    return fix_archives


def find_fix_directories(folder_path: str) -> list[str]:
    """Find subdirectories inside folder_path that represent fix / repair / crack folders."""
    results = []
    if not os.path.exists(folder_path):
        return results
    for root, dirs, _ in os.walk(folder_path):
        for d in list(dirs):
            if is_fix_name(d):
                results.append(os.path.join(root, d))
    return results


def overlay_directory(src_dir: str, dst_dir: str) -> int:
    """
    Recursively copy all files and subdirectories from src_dir to dst_dir,
    overwriting existing files. Returns count of files copied.
    """
    copied = 0
    if not os.path.isdir(src_dir):
        return copied
    os.makedirs(dst_dir, exist_ok=True)
    for root, _, files in os.walk(src_dir):
        rel_path = os.path.relpath(root, src_dir)
        target_sub = dst_dir if rel_path == "." else os.path.join(dst_dir, rel_path)
        os.makedirs(target_sub, exist_ok=True)
        for f in files:
            s_file = os.path.join(root, f)
            d_file = os.path.join(target_sub, f)
            try:
                shutil.copy2(s_file, d_file)
                copied += 1
            except OSError as e:
                logger.warning(f"{TAG} Could not copy {s_file} -> {d_file}: {e}")
    return copied


def get_game_root_dir(target_dir: str, game_title: str = "") -> str:
    """
    Return the effective game root directory inside target_dir.
    If target_dir contains a single subdirectory with game contents (ignoring uncleaned
    download archives/metadata), or a game-named subdirectory with the game .exe while
    target_dir root has no .exe, return that subdirectory.
    """
    if not os.path.exists(target_dir):
        return target_dir
    try:
        ignored_exts = (
            ".url", ".nfo", ".website", ".torrent", ".aria2",
            ".rar", ".7z", ".zip", ".txt", ".md5", ".png", ".jpg",
        )
        entries = [os.path.join(target_dir, e) for e in os.listdir(target_dir)]
        subdirs = [
            e for e in entries
            if os.path.isdir(e)
            and not is_fix_name(os.path.basename(e))
            and not os.path.basename(e).startswith(("_staging_", "_temp_flatten_"))
        ]
        non_ignored_files = [
            e for e in entries
            if os.path.isfile(e)
            and not is_protected_tool(os.path.basename(e))
            and not e.lower().endswith(ignored_exts)
        ]
        if len(subdirs) == 1 and not non_ignored_files:
            return subdirs[0]

        has_root_exe = any(
            os.path.isfile(e) and e.lower().endswith(".exe") and not is_protected_tool(os.path.basename(e))
            for e in entries
        )
        if not has_root_exe and subdirs:
            target_name = os.path.basename(os.path.normpath(target_dir)).lower()
            title_name = (game_title or "").strip().lower()
            for sub in subdirs:
                sub_low = os.path.basename(sub).lower()
                if sub_low in (target_name, title_name) and find_game_executable(sub, game_title):
                    return sub
    except OSError:
        pass
    return target_dir


def flatten_nested_directory(target_dir: str) -> bool:
    """
    If target_dir contains a single redundant subfolder (e.g. Games\\over the hill\\over the hill),
    move all files and directories from the subfolder up into target_dir and remove the subfolder.
    Returns True if flattened, False otherwise.
    """
    if not os.path.isdir(target_dir):
        return False

    try:
        entries = [os.path.join(target_dir, e) for e in os.listdir(target_dir)]
        subdirs = [e for e in entries if os.path.isdir(e) and not is_fix_name(os.path.basename(e))]

        # Check if there are other meaningful files at the top level
        ignored_exts = (".url", ".nfo", ".website", ".torrent", ".aria2", ".txt", ".png", ".jpg")
        meaningful_files = [
            e for e in entries
            if os.path.isfile(e) and not is_protected_tool(os.path.basename(e)) and not e.lower().endswith(ignored_exts)
        ]

        target_name = os.path.basename(os.path.normpath(target_dir))
        nested_dir = None
        if len(subdirs) == 1 and not meaningful_files:
            cand = subdirs[0]
            if os.path.basename(cand).lower() == target_name.lower() or bool(find_game_executable(cand)):
                nested_dir = cand
        else:
            has_root_exe = any(
                os.path.isfile(e) and e.lower().endswith(".exe") and not is_protected_tool(os.path.basename(e))
                for e in entries
            )
            if not has_root_exe:
                for cand in subdirs:
                    if os.path.basename(cand).lower() == target_name.lower() and find_game_executable(cand):
                        nested_dir = cand
                        break

        if not nested_dir:
            return False

        logger.info(f"{TAG} Flattening redundant nested folder: {nested_dir} -> {target_dir}")

        # Temporarily rename nested_dir to avoid collision with any item inside it
        temp_nested = os.path.join(target_dir, f"_temp_flatten_{uuid.uuid4().hex[:6]}")
        os.rename(nested_dir, temp_nested)

        # Move all contents up to target_dir
        for item in os.listdir(temp_nested):
            src_item = os.path.join(temp_nested, item)
            dst_item = os.path.join(target_dir, item)
            if os.path.exists(dst_item):
                if os.path.isdir(dst_item):
                    shutil.rmtree(dst_item, ignore_errors=True)
                else:
                    os.remove(dst_item)
            shutil.move(src_item, dst_item)

        # Remove the now empty temp folder
        try:
            os.rmdir(temp_nested)
        except OSError:
            shutil.rmtree(temp_nested, ignore_errors=True)

        logger.info(f"{TAG} Successfully flattened game folder into {target_dir}")
        return True
    except Exception as e:
        logger.warning(f"{TAG} Could not flatten nested folder in {target_dir}: {e}")
        return False


def find_all_primary_archives(folder_path: str) -> list[str]:
    """
    Return all independent primary archives (or part1 of multi-part sets) in folder_path,
    ordered with main game archives first followed by optional archives (e.g. fg-optional-*.part1.rar).
    Excludes fix archives, secondary multi-part volumes, and Python's base_library.zip.
    """
    archives = []
    if not os.path.exists(folder_path):
        return archives
    for root, _, files in os.walk(folder_path):
        for f in files:
            f_low = f.lower()
            if is_protected_tool(f_low):
                continue
            if f_low == "base_library.zip" or (f_low.startswith("python") and f_low.endswith(".zip")):
                continue
            if f_low.endswith((".rar", ".7z", ".zip")):
                archives.append(os.path.join(root, f))

    if not archives:
        return []

    game_archives = [a for a in archives if not is_fix_name(os.path.basename(a))]
    candidates = game_archives if game_archives else archives

    primary_list = [
        a for a in candidates
        if not _SECONDARY_PART_RE.search(os.path.basename(a))
    ]
    if not primary_list:
        return [candidates[0]]

    def _sort_key(p: str):
        bname = os.path.basename(p).lower()
        is_opt = bname.startswith("fg-optional-")
        is_part1 = bool(_FIRST_PART_RE.search(bname))
        try:
            sz = os.path.getsize(p)
        except OSError:
            sz = 0
        return (1 if is_opt else 0, 0 if is_part1 else 1, -sz, bname)

    primary_list.sort(key=_sort_key)
    return primary_list


def find_primary_archive(folder_path: str) -> Optional[str]:
    """
    Search a folder for the primary archive to extract.
    Excludes fix archives to avoid selecting Fix Repair as main archive.
    If multi-part (.part1.rar, .part01.rar), returns part 1.
    Otherwise returns largest non-fix .rar, .7z, or .zip.
    """
    primaries = find_all_primary_archives(folder_path)
    return primaries[0] if primaries else None


def find_game_executable(folder_path: str, game_title: str = "") -> Optional[str]:
    """Find the best candidate for the main game executable in extracted folder."""
    exe_candidates = []
    for root, _, files in os.walk(folder_path):
        for f in files:
            if f.lower().endswith(".exe"):
                # Filter out excluded helper exes
                f_lower = f.lower()
                if any(ex in f_lower for ex in EXCLUDED_EXE_PATTERNS):
                    continue
                full_path = os.path.join(root, f)
                try:
                    size = os.path.getsize(full_path)
                    # Exclude very small exes (< 1MB) unless no other candidates
                    exe_candidates.append((full_path, f, size))
                except OSError:
                    continue

    if not exe_candidates:
        # Fallback to any exe if no filtered candidates found
        for root, _, files in os.walk(folder_path):
            for f in files:
                if f.lower().endswith(".exe"):
                    return os.path.join(root, f)
        return None

    # Score candidates: title match > OnlineFix launcher > larger size > shallow path
    clean_title = re.sub(r"[^\w\s]", "", game_title).lower().split()

    def score(item):
        path, fname, size = item
        score_val = 0
        fname_lower = fname.lower()
        for word in clean_title:
            if len(word) > 2 and word in fname_lower:
                score_val += 50
        # Online-Fix launchers often launch the game with Steam overlay hook
        if fname_lower in ("onlinefix.exe", "onlinefix64.exe", "launcher.exe", "start.exe", "play.exe"):
            score_val += 40
        elif fname_lower.startswith("onlinefix"):
            score_val += 35
        # Larger executables are typically the game binaries
        score_val += min(50, size // (10 * 1024 * 1024))
        # Prefer shallower paths (closer to game root)
        rel = os.path.relpath(path, folder_path)
        depth = rel.count(os.sep)
        score_val += max(0, 15 - depth * 3)
        return score_val

    exe_candidates.sort(key=score, reverse=True)
    best = exe_candidates[0][0]
    logger.info(f"{TAG} Picked game exe {best} out of {len(exe_candidates)} candidate(s)")
    return best




def find_fitgirl_setup(folder_path: str) -> Optional[str]:
    """
    Locate a FitGirl / Inno Setup installer (setup.exe) inside folder_path when accompanied by .bin repack data files
    (e.g. fg-01.bin, data-01.bin) or when no archive exists in folder_path.
    """
    if not os.path.isdir(folder_path):
        return None
    setup_candidates: list[str] = []
    has_bin = False
    for root, _, files in os.walk(folder_path):
        for f in files:
            low = f.lower()
            if is_protected_tool(low):
                continue
            if low.endswith(".bin"):
                has_bin = True
            if low in ("setup.exe", "setup-fitgirl.exe") or (low.startswith("setup") and low.endswith(".exe")):
                setup_candidates.append(os.path.join(root, f))
    if not setup_candidates:
        return None
    if has_bin or not find_primary_archive(folder_path):
        setup_candidates.sort(key=lambda p: p.count(os.sep))
        return setup_candidates[0]
    return None


def _dir_size_bytes(path: str) -> int:
    total = 0
    if not os.path.isdir(path):
        return 0
    for root, _, files in os.walk(path):
        for f in files:
            if f.lower().endswith((".torrent", ".aria2")):
                continue
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def _get_process_tree_pids(root_pid: int) -> set[int]:
    """Return root_pid plus all descendant PIDs (and any active setup.tmp process) on Windows."""
    pids = {root_pid}
    if sys.platform != "win32":
        return pids
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.windll.kernel32
        TH32CS_SNAPPROCESS = 0x00000002

        class PROCESSENTRY32(ctypes.Structure):
            _fields_ = [
                ("dwSize", wintypes.DWORD),
                ("cntUsage", wintypes.DWORD),
                ("th32ProcessID", wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.c_size_t),
                ("th32ModuleID", wintypes.DWORD),
                ("cntThreads", wintypes.DWORD),
                ("th32ParentProcessID", wintypes.DWORD),
                ("pcPriClassBase", ctypes.c_long),
                ("dwFlags", wintypes.DWORD),
                ("szExeFile", ctypes.c_char * 260),
            ]

        snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        if snap == -1 or snap is None:
            return pids
        entries: list[tuple[int, int, str]] = []
        try:
            pe = PROCESSENTRY32()
            pe.dwSize = ctypes.sizeof(PROCESSENTRY32)
            if kernel32.Process32First(snap, ctypes.byref(pe)):
                while True:
                    name = pe.szExeFile.decode("utf-8", errors="replace").lower()
                    entries.append((int(pe.th32ProcessID), int(pe.th32ParentProcessID), name))
                    if not kernel32.Process32Next(snap, ctypes.byref(pe)):
                        break
        finally:
            kernel32.CloseHandle(snap)

        while True:
            added = {pid for pid, ppid, _ in entries if ppid in pids and pid not in pids}
            if not added:
                break
            pids |= added

        for pid, _, name in entries:
            if name == "setup.tmp":
                pids.add(pid)
    except Exception:   # noqa: BLE001
        pass
    return pids


def mute_process_tree_audio(root_pid: int) -> list[int]:
    """
    Mute all Windows WASAPI audio sessions belonging to root_pid or its child processes
    (e.g. FitGirl's setup.tmp playing BASS.dll music). Returns list of muted PIDs.
    """
    if sys.platform != "win32" or root_pid <= 0:
        return []

    target_pids = _get_process_tree_pids(root_pid)
    muted_pids: list[int] = []
    try:
        import ctypes
        from ctypes import wintypes

        ole32 = ctypes.windll.ole32
        ole32.CoInitializeEx(None, 0)

        class GUID(ctypes.Structure):
            _fields_ = [
                ("Data1", wintypes.DWORD),
                ("Data2", wintypes.WORD),
                ("Data3", wintypes.WORD),
                ("Data4", ctypes.c_ubyte * 8),
            ]

            @classmethod
            def from_str(cls, s: str) -> "GUID":
                g = cls()
                ole32.CLSIDFromString(ctypes.c_wchar_p(s), ctypes.byref(g))
                return g

        def _vcall(ptr, idx: int, restype, *argtypes):
            vtbl = ctypes.cast(ptr, ctypes.POINTER(ctypes.c_void_p)).contents.value
            fn_ptr = ctypes.cast(
                vtbl + idx * ctypes.sizeof(ctypes.c_void_p),
                ctypes.POINTER(ctypes.c_void_p),
            ).contents.value
            proto = ctypes.WINFUNCTYPE(restype, ctypes.c_void_p, *argtypes)
            return proto(fn_ptr)

        def _release(ptr):
            if ptr and ptr.value:
                _vcall(ptr, 2, wintypes.ULONG)(ptr)

        CLSID_MMDeviceEnumerator = GUID.from_str("{BCDE0395-E52F-467C-8E3D-C4579291692E}")
        IID_IMMDeviceEnumerator = GUID.from_str("{A95664D2-9614-4F35-A746-DE8DB63617E6}")
        IID_IAudioSessionManager2 = GUID.from_str("{77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F}")
        IID_IAudioSessionControl2 = GUID.from_str("{bfb7ff88-7239-4fc9-8fa2-07c950be9c6d}")
        IID_ISimpleAudioVolume = GUID.from_str("{87CE5498-68D6-44E5-9215-6DA47EF883D8}")

        pEnum = ctypes.c_void_p()
        hr = ole32.CoCreateInstance(
            ctypes.byref(CLSID_MMDeviceEnumerator),
            None,
            23,
            ctypes.byref(IID_IMMDeviceEnumerator),
            ctypes.byref(pEnum),
        )
        if hr != 0 or not pEnum.value:
            return []

        try:
            pColl = ctypes.c_void_p()
            hr = _vcall(
                pEnum, 3, ctypes.c_long,
                wintypes.UINT, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p),
            )(pEnum, 0, 1, ctypes.byref(pColl))
            if hr != 0 or not pColl.value:
                return []
            try:
                dev_count = wintypes.UINT()
                _vcall(pColl, 3, ctypes.c_long, ctypes.POINTER(wintypes.UINT))(pColl, ctypes.byref(dev_count))
                for i in range(dev_count.value):
                    pDev = ctypes.c_void_p()
                    if _vcall(pColl, 4, ctypes.c_long, wintypes.UINT, ctypes.POINTER(ctypes.c_void_p))(
                        pColl, i, ctypes.byref(pDev)
                    ) != 0 or not pDev.value:
                        continue
                    try:
                        pMgr = ctypes.c_void_p()
                        if _vcall(
                            pDev, 3, ctypes.c_long,
                            ctypes.POINTER(GUID), wintypes.DWORD, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p),
                        )(pDev, ctypes.byref(IID_IAudioSessionManager2), 23, None, ctypes.byref(pMgr)) != 0 or not pMgr.value:
                            continue
                        try:
                            pSessEnum = ctypes.c_void_p()
                            if _vcall(pMgr, 5, ctypes.c_long, ctypes.POINTER(ctypes.c_void_p))(
                                pMgr, ctypes.byref(pSessEnum)
                            ) != 0 or not pSessEnum.value:
                                continue
                            try:
                                sess_count = ctypes.c_int()
                                _vcall(pSessEnum, 3, ctypes.c_long, ctypes.POINTER(ctypes.c_int))(
                                    pSessEnum, ctypes.byref(sess_count)
                                )
                                for j in range(sess_count.value):
                                    pCtrl = ctypes.c_void_p()
                                    if _vcall(
                                        pSessEnum, 4, ctypes.c_long, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p)
                                    )(pSessEnum, j, ctypes.byref(pCtrl)) != 0 or not pCtrl.value:
                                        continue
                                    try:
                                        pCtrl2 = ctypes.c_void_p()
                                        if _vcall(
                                            pCtrl, 0, ctypes.c_long,
                                            ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p),
                                        )(pCtrl, ctypes.byref(IID_IAudioSessionControl2), ctypes.byref(pCtrl2)) == 0 and pCtrl2.value:
                                            try:
                                                pid = wintypes.DWORD()
                                                _vcall(pCtrl2, 14, ctypes.c_long, ctypes.POINTER(wintypes.DWORD))(
                                                    pCtrl2, ctypes.byref(pid)
                                                )
                                                if int(pid.value) in target_pids:
                                                    pVol = ctypes.c_void_p()
                                                    if _vcall(
                                                        pCtrl, 0, ctypes.c_long,
                                                        ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p),
                                                    )(pCtrl, ctypes.byref(IID_ISimpleAudioVolume), ctypes.byref(pVol)) == 0 and pVol.value:
                                                        try:
                                                            _vcall(pVol, 3, ctypes.c_long, ctypes.c_float, ctypes.c_void_p)(
                                                                pVol, 0.0, None
                                                            )
                                                            _vcall(pVol, 5, ctypes.c_long, wintypes.BOOL, ctypes.c_void_p)(
                                                                pVol, 1, None
                                                            )
                                                            if int(pid.value) not in muted_pids:
                                                                muted_pids.append(int(pid.value))
                                                        finally:
                                                            _release(pVol)
                                            finally:
                                                _release(pCtrl2)
                                    finally:
                                        _release(pCtrl)
                            finally:
                                _release(pSessEnum)
                        finally:
                            _release(pMgr)
                    finally:
                        _release(pDev)
            finally:
                _release(pColl)
        finally:
            _release(pEnum)
    except Exception as e:   # noqa: BLE001
        logger.debug(f"{TAG} Audio mute check error: {e}")
    return muted_pids


_SKIP_POST_INSTALL_EXES = frozenset({
    "quicksfv.exe",
    "quicksfv64.exe",
    "dxwebsetup.exe",
    "vc_redist.x64.exe",
    "vc_redist.x86.exe",
    "vcredist_x64.exe",
    "vcredist_x86.exe",
    "hosts.exe",
    "dotnetfx35.exe",
    "dotnetfx35client.exe",
    "dotnetfx40_full_x86_x64.exe",
    "ndp48-web.exe",
    "oalinst.exe",
})


_SKIP_POST_INSTALL_CMDS = frozenset({
    "host.cmd",
    "hosts.cmd",
    "redirect.cmd",
    "redirect.bat",
})


def neutralize_fitgirl_post_install(
    root_pid: int,
    target_dir: str = "",
    handled_items: Optional[set[str]] = None,
) -> list[str]:
    """
    Prevent FitGirl post-install steps (QuickSFV file check, DirectX web installer,
    VC++ redistributables, and fake-site hosts redirect) from blocking or popping up windows:
      1. Scan <target_dir>\\_Redist and %TEMP%\\is-*.tmp to replace host.cmd with '@exit /b 0',
         replace QuickSFV.exe / dxwebsetup.exe / vc_redist*.exe / hosts.exe with Windows' built-in
         GUI no-op stub (systray.exe), and empty fitgirl.md5 before [Run] executes.
      2. Immediately terminate any spawned QuickSFV / dxwebsetup / vc_redist / hosts.exe
         process (and any cmd.exe wrapper running host.cmd) with exit code 0.
    """
    import tempfile

    actions: list[str] = []
    seen = handled_items if handled_items is not None else set()

    noop_stub = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "systray.exe")
    has_noop = os.path.isfile(noop_stub)
    noop_size = os.path.getsize(noop_stub) if has_noop else 0

    scan_dirs: list[str] = []
    if target_dir:
        redist_dir = os.path.join(target_dir, "_Redist")
        if os.path.isdir(redist_dir):
            scan_dirs.append(redist_dir)
    try:
        temp_root = tempfile.gettempdir()
        if os.path.isdir(temp_root):
            for entry in os.listdir(temp_root):
                low_e = entry.lower()
                if low_e.startswith("is-") and low_e.endswith(".tmp"):
                    full_d = os.path.join(temp_root, entry)
                    if os.path.isdir(full_d):
                        scan_dirs.append(full_d)
    except OSError:
        pass

    # 1. Neutralize _Redist & %TEMP%\is-*.tmp binaries, host.cmd & .md5 files before [Run] executes
    for sdir in scan_dirs:
        try:
            for fn in os.listdir(sdir):
                low = fn.lower()
                full_p = os.path.join(sdir, fn)
                key = f"file:{os.path.normcase(full_p)}"
                if low in _SKIP_POST_INSTALL_CMDS:
                    try:
                        if os.path.getsize(full_p) > 16:
                            with open(full_p, "wb") as f:
                                f.write(b"@exit /b 0\r\n")
                            if key not in seen:
                                seen.add(key)
                                actions.append(f"cmd:{fn}")
                    except OSError:
                        pass
                elif low.endswith(".md5"):
                    try:
                        if os.path.getsize(full_p) > 0:
                            with open(full_p, "wb") as f:
                                f.write(b"")
                            if key not in seen:
                                seen.add(key)
                                actions.append(f"md5:{fn}")
                    except OSError:
                        pass
                elif low in _SKIP_POST_INSTALL_EXES and has_noop:
                    try:
                        if os.path.getsize(full_p) != noop_size:
                            shutil.copyfile(noop_stub, full_p)
                            if key not in seen:
                                seen.add(key)
                                actions.append(f"stub:{fn}")
                    except OSError:
                        pass
        except OSError:
            pass

    # 2. Terminate any already-spawned post-install helper processes with exit code 0
    if sys.platform == "win32" and root_pid > 0:
        try:
            import ctypes
            from ctypes import wintypes

            kernel32 = ctypes.windll.kernel32
            TH32CS_SNAPPROCESS = 0x00000002
            PROCESS_TERMINATE = 0x0001

            class PROCESSENTRY32(ctypes.Structure):
                _fields_ = [
                    ("dwSize", wintypes.DWORD),
                    ("cntUsage", wintypes.DWORD),
                    ("th32ProcessID", wintypes.DWORD),
                    ("th32DefaultHeapID", ctypes.c_size_t),
                    ("th32ModuleID", wintypes.DWORD),
                    ("cntThreads", wintypes.DWORD),
                    ("th32ParentProcessID", wintypes.DWORD),
                    ("pcPriClassBase", ctypes.c_long),
                    ("dwFlags", wintypes.DWORD),
                    ("szExeFile", ctypes.c_char * 260),
                ]

            tree_pids = _get_process_tree_pids(root_pid)
            snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
            if snap != -1 and snap is not None:
                entries: list[tuple[int, int, str]] = []
                try:
                    pe = PROCESSENTRY32()
                    pe.dwSize = ctypes.sizeof(PROCESSENTRY32)
                    if kernel32.Process32First(snap, ctypes.byref(pe)):
                        while True:
                            pid = int(pe.th32ProcessID)
                            ppid = int(pe.th32ParentProcessID)
                            name = pe.szExeFile.decode("utf-8", errors="replace").lower()
                            entries.append((pid, ppid, name))
                            if not kernel32.Process32Next(snap, ctypes.byref(pe)):
                                break
                finally:
                    kernel32.CloseHandle(snap)

                pid_to_name = {pid: name for pid, _, name in entries}
                pids_to_kill: list[tuple[int, str]] = []
                for pid, ppid, name in entries:
                    if name in _SKIP_POST_INSTALL_EXES and (
                        pid in tree_pids
                        or ppid in tree_pids
                        or name in ("quicksfv.exe", "quicksfv64.exe", "hosts.exe")
                    ):
                        pids_to_kill.append((pid, name))
                        # If hosts.exe was spawned by a cmd.exe batch wrapper (host.cmd), kill cmd.exe too
                        if name == "hosts.exe" and pid_to_name.get(ppid) == "cmd.exe":
                            pids_to_kill.append((ppid, "cmd.exe(host.cmd)"))

                for kill_pid, kill_name in pids_to_kill:
                    h_proc = kernel32.OpenProcess(PROCESS_TERMINATE, False, kill_pid)
                    if h_proc:
                        try:
                            kernel32.TerminateProcess(h_proc, 0)
                            pkey = f"pid:{kill_pid}:{kill_name}"
                            if pkey not in seen:
                                seen.add(pkey)
                                actions.append(pkey)
                        finally:
                            kernel32.CloseHandle(h_proc)
        except Exception as e:   # noqa: BLE001
            logger.debug(f"{TAG} Post-install process skip check error: {e}")

    return actions


def _mute_installer_audio_loop(root_pid: int, stop_event: threading.Event, target_dir: str = ""):
    """
    Background daemon loop that:
      1. Silences FitGirl setup.exe / setup.tmp music as soon as BASS.dll initializes.
      2. Skips/neutralizes QuickSFV file verification, DirectX / VC++ redistributable installers,
         and fake-site hosts redirects so installation finishes 100% silently.
    """
    started = time.monotonic()
    logged_pids: set[int] = set()
    handled_post_install: set[str] = set()
    while not stop_event.is_set():
        muted = mute_process_tree_audio(root_pid)
        new_pids = [p for p in muted if p not in logged_pids]
        if new_pids:
            logged_pids.update(new_pids)
            logger.info(f"{TAG} Muted installer background music for PID(s): {new_pids}")
        skipped = neutralize_fitgirl_post_install(root_pid, target_dir, handled_post_install)
        if skipped:
            logger.info(f"{TAG} Skipped FitGirl post-install step(s): {skipped}")
        interval = 0.05 if (time.monotonic() - started) < 15.0 else 0.2
        stop_event.wait(interval)


class GameExtractor:
    """Manages archive extraction and post-extract cleanup. Callbacks run on the extractor's own thread."""

    def __init__(
        self,
        source_dir: str,
        target_dir: str,
        password: str = DEFAULT_PASSWORD,
        delete_archive: bool = True,
        on_progress: Optional[Callable[[float, str], None]] = None,
        on_completed: Optional[Callable[[str], None]] = None,
        on_error: Optional[Callable[[str], None]] = None,
    ):
        self.source_dir = source_dir
        self.target_dir = target_dir
        self.password = password or DEFAULT_PASSWORD
        self.delete_archive = delete_archive
        self.on_progress = on_progress
        self.on_completed = on_completed
        self.on_error = on_error

        self._cancelled = False
        self._process: Optional[subprocess.Popen] = None
        self._lock = threading.Lock()

    def start(self, game_title: str = ""):
        """Start extraction in a background thread."""
        threading.Thread(target=self._run_extraction, args=(game_title,), daemon=True, name="7z-extract").start()

    def cancel(self):
        with self._lock:
            self._cancelled = True
            proc = self._process
        if proc and proc.poll() is None:
            try:
                logger.info(f"{TAG} Terminating 7z/installer process tree (pid {proc.pid})")
                if sys.platform == "win32":
                    subprocess.run(
                        ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        creationflags=subprocess.CREATE_NO_WINDOW,
                        timeout=5,
                    )
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except Exception:
                    pass
            except Exception as e:   # noqa: BLE001
                logger.warning(f"{TAG} Could not terminate process (pid {proc.pid}): {e}")

    def _run_extraction(self, game_title: str):
        started = time.monotonic()
        try:
            os.makedirs(self.target_dir, exist_ok=True)

            setup_exe = find_fitgirl_setup(self.source_dir)
            raw_archives = [] if setup_exe else find_all_primary_archives(self.source_dir)
            only_fix_on_installed = (
                bool(raw_archives)
                and all(is_fix_name(os.path.basename(a)) for a in raw_archives)
                and bool(find_game_executable(self.target_dir, game_title))
            )
            archives = [] if only_fix_on_installed else raw_archives
            archive = archives[0] if archives else None
            extracted_primary_set = {os.path.normcase(os.path.abspath(a)) for a in archives}

            if setup_exe:
                logger.info(f"{TAG} Running silent installer {setup_exe} -> {self.target_dir}")
                self._run_silent_installer(setup_exe)
                if self._cancelled:
                    logger.info(f"{TAG} Silent install cancelled by user after {time.monotonic() - started:.1f}s")
                    return
                logger.info(f"{TAG} Silent installer completed in {time.monotonic() - started:.1f}s")
            elif only_fix_on_installed:
                logger.info(f"{TAG} Fix-only archive(s) detected for installed game; applying overlay directly")
            elif not archive:
                logger.info(f"{TAG} No archive in {self.source_dir}: moving plain game files to {self.target_dir}")
                moved = 0
                if os.path.abspath(self.source_dir) != os.path.abspath(self.target_dir):
                    for item in os.listdir(self.source_dir):
                        if item.lower().endswith((".torrent", ".aria2")):
                            continue
                        s = os.path.join(self.source_dir, item)
                        d = os.path.join(self.target_dir, item)
                        if os.path.exists(d):
                            if os.path.isdir(d):
                                shutil.rmtree(d, ignore_errors=True)
                            else:
                                os.remove(d)
                        shutil.move(s, d)
                        moved += 1
                logger.info(f"{TAG} Moved {moved} item(s) in {time.monotonic() - started:.1f}s")
            else:
                is_fg_archive = any(
                    "fitgirl" in os.path.basename(a).lower() or os.path.basename(a).lower().startswith("fg-")
                    for a in archives
                )
                unpack_dest = self.source_dir if is_fg_archive else self.target_dir
                seven_zip = find_7z_binary()
                for arch in archives:
                    logger.info(f"{TAG} Extracting {arch} -> {unpack_dest} "
                                f"(password {'default' if self.password == DEFAULT_PASSWORD else 'custom'})")
                    self._extract_archive_with_fallbacks(seven_zip, arch, unpack_dest, is_fix=False)
                    if self._cancelled:
                        logger.info(f"{TAG} Extraction cancelled by user after {time.monotonic() - started:.1f}s")
                        return
                logger.info(f"{TAG} Archive(s) ({len(archives)}) unpacked in {time.monotonic() - started:.1f}s")

                if is_fg_archive:
                    if os.path.isdir(self.source_dir):
                        for fn in os.listdir(self.source_dir):
                            fn_low = fn.lower()
                            if (
                                fn_low.endswith((".rar", ".7z", ".zip"))
                                and not is_protected_tool(fn_low)
                                and fn_low != "base_library.zip"
                            ):
                                try:
                                    os.remove(os.path.join(self.source_dir, fn))
                                except OSError:
                                    pass
                    unpacked_setup = find_fitgirl_setup(self.source_dir)
                    if unpacked_setup:
                        logger.info(f"{TAG} Running silent installer from unpacked FitGirl archive {unpacked_setup} -> {self.target_dir}")
                        self._run_silent_installer(unpacked_setup)
                        if self._cancelled:
                            return
                        logger.info(f"{TAG} Silent installer completed in {time.monotonic() - started:.1f}s")

            # Apply Fix files (separate archive or internal Fix Repair folder)
            if not self._cancelled:
                self._apply_fix(game_title, skip_archives=extracted_primary_set)

            # Cleanup redundant files (junk, archives, temp folders)
            if not self._cancelled:
                self._cleanup_redundant_files()

            # Flatten redundant nested folder if present (e.g. Games\Name\Name -> Games\Name)
            if not self._cancelled:
                flatten_nested_directory(self.target_dir)

            if not self._cancelled:
                self._finish(game_title)

        except Exception as e:   # noqa: BLE001 - thread boundary: report, never raise
            if self._cancelled:
                logger.info(f"{TAG} Extraction stopped (cancelled): {e}")
                return
            logger.error(f"{TAG} Extraction failed after {time.monotonic() - started:.1f}s: {e}",
                         exc_info=not isinstance(e, RuntimeError))
            if self.on_error:
                self.on_error(str(e))

    def _apply_fix(self, game_title: str, skip_archives: Optional[set[str]] = None):
        """Detect, extract, and copy fix files into game directory, then remove fix folder."""
        game_root = get_game_root_dir(self.target_dir, game_title)
        seven_zip = find_7z_binary()
        skip_norm = skip_archives or set()

        # 1. Process fix archives in source_dir or target_dir (skipping any already unpacked as primary)
        fix_archives = [
            p for p in dict.fromkeys(find_fix_archives(self.source_dir) + find_fix_archives(self.target_dir))
            if os.path.normcase(os.path.abspath(p)) not in skip_norm
        ]
        for fix_arch in fix_archives:
            if self._cancelled:
                return
            staging_dir = os.path.join(self.source_dir, f"_staging_{os.path.splitext(os.path.basename(fix_arch))[0]}")
            try:
                os.makedirs(staging_dir, exist_ok=True)
                logger.info(f"{TAG} Extracting fix archive {fix_arch} -> {staging_dir}")
                self._extract_archive_with_fallbacks(seven_zip, fix_arch, staging_dir, is_fix=True)

                sub_fix_dirs = find_fix_directories(staging_dir)
                if sub_fix_dirs:
                    src_to_copy = sub_fix_dirs[0]
                else:
                    src_to_copy = staging_dir
                    try:
                        st_entries = [os.path.join(staging_dir, e) for e in os.listdir(staging_dir)]
                        st_dirs = [e for e in st_entries if os.path.isdir(e)]
                        st_files = [e for e in st_entries if os.path.isfile(e)]
                        if len(st_dirs) == 1 and not st_files:
                            cand_dir = st_dirs[0]
                            cand_name = os.path.basename(cand_dir)
                            if not os.path.exists(os.path.join(game_root, cand_name)):
                                root_name = os.path.basename(os.path.normpath(game_root)).lower()
                                has_overlap = any(
                                    os.path.exists(os.path.join(game_root, child))
                                    for child in os.listdir(cand_dir)
                                )
                                if cand_name.lower() == root_name or has_overlap:
                                    src_to_copy = cand_dir
                    except OSError:
                        pass
                copied = overlay_directory(src_to_copy, game_root)
                logger.info(f"{TAG} Applied {copied} fix file(s) from archive {os.path.basename(fix_arch)} to {game_root}")
            except Exception as e:
                logger.error(f"{TAG} Failed to extract/apply fix archive {fix_arch}: {e}")
            finally:
                shutil.rmtree(staging_dir, ignore_errors=True)
                if os.path.exists(fix_arch) and self.target_dir in os.path.abspath(fix_arch):
                    try:
                        os.remove(fix_arch)
                    except OSError:
                        pass

        # 2. Process fix directories inside target_dir (e.g. "Fix Repair", "OnlineFix")
        target_fix_dirs = find_fix_directories(self.target_dir)
        for fix_dir in target_fix_dirs:
            if self._cancelled:
                return
            try:
                dest_dir = os.path.dirname(fix_dir)
                copied = overlay_directory(fix_dir, dest_dir)
                shutil.rmtree(fix_dir, ignore_errors=True)
                logger.info(f"{TAG} Applied {copied} fix file(s) from folder {os.path.basename(fix_dir)} into {dest_dir} (folder removed)")
            except Exception as e:
                logger.error(f"{TAG} Failed to apply fix folder {fix_dir}: {e}")

    def _finish(self, game_title: str):
        exe_path = find_game_executable(self.target_dir, game_title)
        if not exe_path:
            logger.warning(f"{TAG} No game exe found in {self.target_dir}")
        if self.on_completed:
            self.on_completed(exe_path or "")

    def _cleanup_archives(self):
        """Backward compatible alias for _cleanup_redundant_files."""
        self._cleanup_redundant_files()

    def _cleanup_redundant_files(self):
        """
        Clean up leftover junk (.url, .nfo, .website, .torrent, .aria2) in target_dir
        and remove top-level downloaded archives/installer files.
        NEVER deletes internal game .zip/.bin files (such as PyInstaller's base_library.zip or EBOOT.BIN)
        and NEVER deletes aria2/7z tools.
        """
        # 1. Target directory cleanup: junk advertising/metadata files & redistributable folders ONLY
        cleaned_target = 0
        redist_dir_names = {"_commonredist", "_redist", "md5", "temp-fitgirl"}
        for root, dirs, files in os.walk(self.target_dir):
            rel_depth = 0 if os.path.normcase(root) == os.path.normcase(self.target_dir) else (
                os.path.relpath(root, self.target_dir).count(os.sep) + 1
            )
            if rel_depth <= 2:
                for d in list(dirs):
                    if d.lower() in redist_dir_names:
                        d_full = os.path.join(root, d)
                        shutil.rmtree(d_full, ignore_errors=True)
                        dirs.remove(d)
                        cleaned_target += 1
            for f in files:
                f_low = f.lower()
                if is_protected_tool(f_low):
                    continue
                if f_low.endswith((".url", ".nfo", ".website", ".torrent", ".aria2")) or f_low == "how to run game!!.txt":
                    try:
                        os.remove(os.path.join(root, f))
                        cleaned_target += 1
                    except OSError as e:
                        logger.debug(f"{TAG} Could not remove junk file {f}: {e}")
        logger.info(f"{TAG} Cleaned {cleaned_target} redundant junk/archive file(s) in {self.target_dir}")

        # 2. Source download temp directory cleanup
        if not self.delete_archive:
            return

        def _is_removable_top_archive_or_setup(fname: str) -> bool:
            f_low = fname.lower()
            if is_protected_tool(f_low):
                return False
            if f_low == "base_library.zip" or (f_low.startswith("python") and f_low.endswith(".zip")):
                return False
            is_fg_bin = f_low.endswith(".bin") and f_low.startswith(("fg-", "setup-", "data-"))
            return (
                f_low.endswith((".rar", ".7z", ".zip", ".torrent", ".aria2", ".md5"))
                or is_fg_bin
                or f_low in ("setup.exe", "verify bin files before installation.bat")
            )

        def _is_fitgirl_installer_subdir(dir_path: str) -> bool:
            if not os.path.isdir(dir_path):
                return False
            try:
                entries = [e.lower() for e in os.listdir(dir_path)]
            except OSError:
                return False
            has_setup = "setup.exe" in entries or "setup-fitgirl.exe" in entries
            has_fg_bin = any(e.endswith(".bin") and e.startswith(("fg-", "setup-", "data-")) for e in entries)
            return has_setup and has_fg_bin

        # Check if source_dir contains any protected tools (aria2, 7z)
        has_protected_tool = False
        if os.path.exists(self.source_dir):
            for root, _, files in os.walk(self.source_dir):
                if any(is_protected_tool(f) for f in files):
                    has_protected_tool = True
                    break

        if has_protected_tool:
            logger.info(f"{TAG} Preserving {self.source_dir} because it contains protected tool(s) (aria2 / 7z)")
            removed, failed = 0, 0
            for f in os.listdir(self.source_dir):
                full_p = os.path.join(self.source_dir, f)
                if os.path.isfile(full_p) and _is_removable_top_archive_or_setup(f):
                    try:
                        os.remove(full_p)
                        removed += 1
                    except OSError:
                        failed += 1
                elif os.path.isdir(full_p) and _is_fitgirl_installer_subdir(full_p):
                    shutil.rmtree(full_p, ignore_errors=True)
                    removed += 1
            logger.info(f"{TAG} Removed {removed} archive file(s) in source dir while preserving aria2/7z tools")
            return

        if os.path.abspath(self.source_dir) != os.path.abspath(self.target_dir):
            try:
                for root, _, files in os.walk(self.source_dir):
                    for f in files:
                        if not is_protected_tool(f):
                            try:
                                os.remove(os.path.join(root, f))
                            except OSError:
                                pass
                if any(is_protected_tool(f) for _, _, files in os.walk(self.source_dir) for f in files):
                    logger.info(f"{TAG} Preserving {self.source_dir} (protected tools detected)")
                else:
                    shutil.rmtree(self.source_dir, ignore_errors=True)
                    logger.info(f"{TAG} Removed temp download directory: {self.source_dir}")
            except OSError as e:
                logger.warning(f"{TAG} Could not remove temp download directory {self.source_dir}: {e}")
        else:
            removed, failed = 0, 0
            if os.path.isdir(self.source_dir):
                for f in os.listdir(self.source_dir):
                    full_p = os.path.join(self.source_dir, f)
                    if os.path.isfile(full_p) and _is_removable_top_archive_or_setup(f):
                        try:
                            os.remove(full_p)
                            removed += 1
                        except OSError:
                            failed += 1
                    elif os.path.isdir(full_p) and _is_fitgirl_installer_subdir(full_p):
                        shutil.rmtree(full_p, ignore_errors=True)
                        removed += 1
            for extra_dir in ("_CommonRedist", "_Redist", "MD5", "temp-fitgirl"):
                extra_path = os.path.join(self.target_dir, extra_dir)
                if os.path.isdir(extra_path):
                    shutil.rmtree(extra_path, ignore_errors=True)
            logger.info(f"{TAG} Removed {removed} archive file(s) in source dir"
                        + (f", {failed} left (in use)" if failed else ""))

    @staticmethod
    def _is_sparse_optional_stub(fpath: str) -> bool:
        """
        Return True only if an 'fg-optional-*.bin' file is an incomplete/unselected BitTorrent
        piece-boundary stub (missing FreeArc header or zero-filled middle), NOT a full optional pack.
        """
        try:
            sz = os.path.getsize(fpath)
            if sz < 1024:
                return True
            with open(fpath, "rb") as fp:
                if fp.read(4) != b"ArC\x01":
                    return True
                if sz >= 4096:
                    fp.seek(sz // 2)
                    if not any(fp.read(64)):
                        return True
            return False
        except OSError:
            return True

    def _run_silent_installer(self, setup_exe: str):
        """Run a FitGirl / Inno Setup installer silently into self.target_dir and report progress."""
        target_abs = os.path.abspath(self.target_dir)
        setup_dir = os.path.dirname(os.path.abspath(setup_exe))
        setup_inside_target = (
            os.path.normcase(setup_dir) != os.path.normcase(target_abs)
            and os.path.normcase(setup_dir).startswith(os.path.normcase(target_abs) + os.sep)
        )

        # If setup_dir is a subfolder of source_dir, move any top-level fg-*.bin files into setup_dir first
        # so setup.exe sees all optional/core .bin files in its own working directory.
        source_abs = os.path.abspath(self.source_dir)
        if os.path.normcase(setup_dir) != os.path.normcase(source_abs) and os.path.isdir(source_abs):
            for entry in os.listdir(source_abs):
                e_low = entry.lower()
                if e_low.endswith(".bin") and e_low.startswith(("fg-", "setup-", "data-")):
                    src_bin = os.path.join(source_abs, entry)
                    dst_bin = os.path.join(setup_dir, entry)
                    if os.path.isfile(src_bin) and not os.path.exists(dst_bin):
                        try:
                            shutil.move(src_bin, dst_bin)
                        except OSError:
                            pass

        # If setup_dir is a subfolder inside target_abs (e.g. O:\Games\GoW3\GoW3 [FitGirl Repack]),
        # clean up any partial files in target_abs left over from a previously cancelled install.
        if setup_inside_target and os.path.isdir(target_abs):
            rel_top = os.path.relpath(setup_dir, target_abs).split(os.sep)[0].lower()
            for entry in os.listdir(target_abs):
                e_low = entry.lower()
                if (
                    e_low == rel_top
                    or e_low.endswith((".torrent", ".bin", ".rar", ".7z", ".zip"))
                    or is_protected_tool(entry)
                ):
                    continue
                ep = os.path.join(target_abs, entry)
                try:
                    if os.path.isdir(ep):
                        shutil.rmtree(ep, ignore_errors=True)
                    else:
                        os.remove(ep)
                except OSError:
                    pass

        # Remove only incomplete/sparse BitTorrent piece-boundary stub files or .aria2 control files,
        # while keeping complete fg-optional-*.bin files so setup.exe installs all downloaded optional packs.
        removed_stubs: list[str] = []
        for scan_root in {setup_dir, source_abs}:
            if not os.path.isdir(scan_root):
                continue
            for root, _, files in os.walk(scan_root):
                for fn in files:
                    fn_low = fn.lower()
                    full_fn = os.path.join(root, fn)
                    if fn_low.endswith(".aria2") or (
                        fn_low.startswith("fg-optional-")
                        and "english" not in fn_low
                        and self._is_sparse_optional_stub(full_fn)
                    ):
                        try:
                            os.remove(full_fn)
                            removed_stubs.append(fn)
                        except OSError:
                            pass
        if removed_stubs:
            logger.info(f"{TAG} Removed {len(removed_stubs)} optional/control stub file(s) before setup: {removed_stubs}")

        neutralize_fitgirl_post_install(0, target_abs)

        cmd = [
            setup_exe,
            "/VERYSILENT",
            "/SUPPRESSMSGBOXES",
            "/NORESTART",
            "/NOCANCEL",
            "/NOICONS",
            "/TASKS=",
            f"/DIR={target_abs}",
        ]
        startupinfo = None
        creationflags = 0
        if sys.platform == "win32":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            creationflags = subprocess.CREATE_NO_WINDOW

        repack_bytes = max(1, _dir_size_bytes(setup_dir))
        if self.on_progress:
            self.on_progress(1.0, "Đang cài đặt ngầm (FitGirl Setup)...")

        if sys.platform != "win32":
            wine = shutil.which("wine")
            if wine:
                cmd = [wine] + cmd
            else:
                logger.warning(f"{TAG} Attempting to run Windows setup.exe on Linux without wine")

        proc = subprocess.Popen(
            cmd,
            cwd=setup_dir,
            env=clean_subprocess_env(),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            startupinfo=startupinfo,
            creationflags=creationflags,
        )
        with self._lock:
            self._process = proc
            cancelled = self._cancelled
        if cancelled:
            proc.terminate()
        logger.info(f"{TAG} Silent installer running (pid {proc.pid}): {' '.join(cmd)}")

        mute_stop = threading.Event()
        if sys.platform == "win32" and getattr(proc, "pid", 0):
            threading.Thread(
                target=_mute_installer_audio_loop,
                args=(proc.pid, mute_stop, target_abs),
                daemon=True,
                name="fg-mute-audio",
            ).start()

        try:
            last_logged = -1
            while proc.poll() is None:
                if self._cancelled:
                    return
                try:
                    proc.wait(timeout=0.5)
                except subprocess.TimeoutExpired:
                    total_target = _dir_size_bytes(self.target_dir)
                    installed_bytes = max(0, total_target - repack_bytes) if setup_inside_target else total_target
                    pct = min(95, max(1, int((installed_bytes * 100) // (repack_bytes * 1.4))))
                    if pct // 25 > last_logged:
                        last_logged = pct // 25
                        logger.info(f"{TAG} Silent install progress ~{pct}%")
                    if self.on_progress:
                        self.on_progress(float(pct), f"Đang cài đặt: {pct}%")
        finally:
            mute_stop.set()

        if self._cancelled:
            return
        if proc.returncode != 0:
            logger.error(f"{TAG} Silent installer exited with code {proc.returncode}")
            raise RuntimeError(f"Bộ cài đặt setup.exe lỗi (mã {proc.returncode}).")
        if self.delete_archive and setup_inside_target and os.path.isdir(setup_dir):
            if not any(is_protected_tool(f) for _, _, files in os.walk(setup_dir) for f in files):
                shutil.rmtree(setup_dir, ignore_errors=True)
                logger.info(f"{TAG} Removed repack installer subfolder: {setup_dir}")
        if self.on_progress:
            self.on_progress(100.0, "Đã cài đặt xong, đang dọn tệp tạm...")

    def _extract_archive_with_fallbacks(
        self,
        seven_zip_bin: Optional[str],
        archive_path: str,
        destination_dir: str,
        is_fix: bool = False,
    ) -> None:
        """Try primary password, then known store passwords ('steamrip.com', 'online-fix.me', empty) on password error."""
        candidates: list[str] = []
        for pwd in (self.password, STEAMRIP_ARCHIVE_PASSWORD, DEFAULT_PASSWORD, ""):
            if pwd is not None and pwd not in candidates:
                candidates.append(pwd)

        last_err: Optional[Exception] = None
        for idx, pwd in enumerate(candidates):
            if self._cancelled:
                return
            try:
                if seven_zip_bin:
                    self._extract_with_7z(seven_zip_bin, archive_path, destination_dir=destination_dir, password=pwd, is_fix=is_fix)
                else:
                    self._extract_fallback(archive_path, destination_dir=destination_dir, password=pwd)
                return
            except Exception as e:   # noqa: BLE001
                last_err = e
                msg_low = str(e).lower()
                is_pwd_err = (not seven_zip_bin) or any(
                    k in msg_low for k in ("mật khẩu", "password", "encrypted", "7z lỗi", "corrupt", "crc")
                )
                if not is_pwd_err or idx + 1 >= len(candidates):
                    raise
                logger.warning(f"{TAG} Archive password attempt #{idx + 1} rejected, trying fallback password #{idx + 2}")
        if last_err:
            raise last_err

    def _extract_with_7z(
        self,
        seven_zip_bin: str,
        archive_path: str,
        destination_dir: Optional[str] = None,
        password: Optional[str] = None,
        is_fix: bool = False,
    ):
        target_dir = destination_dir or self.target_dir
        pwd = password if password is not None else self.password
        cmd = [seven_zip_bin, "x", f"-p{pwd}", f"-o{target_dir}", "-y", "-bsp1", "-bso1", "-bse1",
               archive_path]

        startupinfo = None
        creationflags = 0
        if sys.platform == "win32":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            creationflags = subprocess.CREATE_NO_WINDOW

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            startupinfo=startupinfo,
            creationflags=creationflags,
        )
        with self._lock:
            self._process = proc
            cancelled = self._cancelled
        if cancelled:
            proc.terminate()
        logger.info(f"{TAG} 7z running (pid {proc.pid})")

        # 7z redraws its progress in place with backspaces / \r, so read raw chunks instead of lines.
        progress_re = re.compile(rb"(\d{1,3})%")
        last_pct, last_logged, buf = -1, -1, b""
        while True:
            chunk = proc.stdout.read1(4096)
            if not chunk:
                break
            buf = (buf + chunk)[-8192:]
            for m in progress_re.finditer(chunk):
                pct = min(100, int(m.group(1)))
                if pct == last_pct:
                    continue
                last_pct = pct
                if pct // 25 > last_logged:     # milestones only: 0/25/50/75/100%
                    last_logged = pct // 25
                    logger.info(f"{TAG} Progress {pct}%" + (" (fix)" if is_fix else ""))
                if self.on_progress:
                    msg = "Đang áp dụng bản fix..." if is_fix else f"Đang giải nén: {pct}%"
                    progress_val = 100.0 if is_fix else float(pct)
                    self.on_progress(progress_val, msg)
        proc.wait()

        if self._cancelled:
            return
        if proc.returncode != 0:
            tail: deque[str] = deque(maxlen=8)
            for line in re.split(rb"[\r\n\x08]+", buf):
                text = line.decode("utf-8", errors="replace").strip()
                if text and not progress_re.match(text.encode()):
                    tail.append(text)
            details = " | ".join(tail)
            logger.error(f"{TAG} 7z exited with code {proc.returncode}. Last output: {details}")
            if "wrong password" in details.lower():
                raise RuntimeError("Sai mật khẩu giải nén.")
            raise RuntimeError(f"7z lỗi (mã {proc.returncode}).")

    def _extract_fallback(
        self,
        archive_path: str,
        destination_dir: Optional[str] = None,
        password: Optional[str] = None,
    ):
        """Fallback extraction using py7zr or zipfile."""
        logger.info(f"{TAG} 7z.exe missing: using Python extraction fallback")
        target_dir = destination_dir or self.target_dir
        pwd = password if password is not None else self.password
        if archive_path.lower().endswith(".7z"):
            import py7zr
            with py7zr.SevenZipFile(archive_path, mode="r", password=pwd) as z:
                z.extractall(path=target_dir)
        elif archive_path.lower().endswith(".zip"):
            import zipfile
            with zipfile.ZipFile(archive_path, "r") as z:
                z.extractall(path=target_dir, pwd=pwd.encode("utf-8") if pwd else None)
        else:
            raise RuntimeError("Định dạng RAR cần 7z.exe để giải nén.")

