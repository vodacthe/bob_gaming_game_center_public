"""
Russian -> Vietnamese for the fixed vocabulary online-fix.me uses (title suffixes, dates, update notes, download
button labels). Rule-based on purpose: no network service, deterministic, instant. Unknown Russian text is left as is.
"""

import re

_CYRILLIC = re.compile(r"[А-Яа-яЁё]")

# Genitive month names, as used in dates ("7 сентября 2026, 18:51")
_MONTHS = {
    "января": 1, "февраля": 2, "марта": 3, "апреля": 4, "мая": 5, "июня": 6,
    "июля": 7, "августа": 8, "сентября": 9, "октября": 10, "ноября": 11, "декабря": 12,
}
_MONTH_NAMES = "|".join(_MONTHS)
_DATE_FULL_RE = re.compile(r"\b(\d{1,2})\s+(" + _MONTH_NAMES + r")\s+(\d{4})\b", re.IGNORECASE)   # -> 7/9/2026
_DATE_SHORT_RE = re.compile(r"\b(\d{1,2})\s+(" + _MONTH_NAMES + r")\b", re.IGNORECASE)            # -> 7/9

# Longest / most specific phrases first; matched case-insensitively.
_PHRASES = [
    ("бесплатная игра по сети более невозможна, покупайте игру", "không thể chơi online miễn phí nữa, hãy mua game"),
    ("Внимание, вход на сайт не был произведен", "Đăng nhập không thành công"),
    ("Возможно, Вы ввели неверное имя пользователя или пароль", "Sai tên đăng nhập hoặc mật khẩu"),
    ("Игра обновлена до версии", "Game đã cập nhật lên phiên bản"),
    ("Мод обновлён до версии", "Mod đã cập nhật lên phiên bản"),
    ("Мод обновлен до версии", "Mod đã cập nhật lên phiên bản"),
    ("Добавлено обновление", "Đã thêm bản cập nhật"),
    ("Руководство закрыто", "Đã ngừng hỗ trợ"),
    ("Обновлён фикс", "Đã cập nhật bản fix"),
    ("Обновлен фикс", "Đã cập nhật bản fix"),
    ("Скачать готовый клиент с", "Tải bản client hoàn chỉnh từ"),
    ("Скачать лаунчер с", "Tải launcher từ"),
    ("Скачать фикс с сервера", "Tải bản fix từ máy chủ"),
    ("Скачать торрент", "Tải Torrent"),
    ("Скачать с", "Tải từ"),
    ("Скачать", "Tải"),
    ("Обновлено", "Cập nhật"),
    ("Обновлена", "Đã cập nhật"),
    ("Обновлен", "Đã cập nhật"),
    ("Добавлена", "Đã thêm"),
    ("Добавлен", "Đã thêm"),
    ("Исправлен", "Đã sửa"),
    ("Кооператив", "Co-op"),
    ("Мультиплеер", "Nhiều người chơi"),
    ("Вчера", "Hôm qua"),
    ("Сегодня", "Hôm nay"),
    ("фикс", "fix"),
    ("торрент", "torrent"),
    ("лаунчер", "launcher"),
    ("по сети", "Online"),
]
_PHRASE_RES = [(re.compile(re.escape(ru), re.IGNORECASE), vi) for ru, vi in _PHRASES]

# Site-provided English labels (some pages are already in English)
_EN_LABELS = [
    ("Download ready-made client from", "Tải bản client hoàn chỉnh từ"),
    ("Download fix from server", "Tải bản fix từ máy chủ"),
    ("Download Torrent", "Tải Torrent"),
    ("Download from", "Tải từ"),
]
_EN_LABEL_RES = [(re.compile(r"^" + re.escape(en), re.IGNORECASE), vi) for en, vi in _EN_LABELS]

_TITLE_SUFFIX = re.compile(
    r"(?:[\s\-_–—:/|]+[\(\[]*|[\(\[])(?:по\s+сети|online|онлайн)[\s\)\]]*$",
    re.IGNORECASE,
)


def has_cyrillic(text: str) -> bool:
    return bool(text and _CYRILLIC.search(text))


def to_vietnamese(text: str) -> str:
    """Translate the site's known Russian phrases; everything else is returned unchanged."""
    if not text:
        return text
    if not has_cyrillic(text):
        for pattern, vi in _EN_LABEL_RES:
            if pattern.search(text):
                return pattern.sub(vi, text)
        return text
    out = _DATE_FULL_RE.sub(lambda m: f"{int(m.group(1))}/{_MONTHS[m.group(2).lower()]}/{m.group(3)}", text)
    out = _DATE_SHORT_RE.sub(lambda m: f"{int(m.group(1))}/{_MONTHS[m.group(2).lower()]}", out)
    for pattern, vi in _PHRASE_RES:
        out = pattern.sub(vi, out)
    return out


def title_to_vietnamese(title: str) -> str:
    """Clean game title by stripping trailing multiplayer/online tags (Online, по сети, онлайн)
    and translating any known Russian phrases.
    Example: 'SpeedRunners 2 King of Speed по сети' -> 'SpeedRunners 2 King of Speed'
             'over the hill Online' -> 'over the hill'
             'Permafrost по сети' -> 'Permafrost'
    """
    if not title:
        return title

    clean = title.strip()
    while _TITLE_SUFFIX.search(clean):
        subbed = _TITLE_SUFFIX.sub("", clean).strip().rstrip(".-_:/| ")
        if not subbed:
            break
        clean = subbed

    translated = to_vietnamese(clean)

    while _TITLE_SUFFIX.search(translated):
        subbed = _TITLE_SUFFIX.sub("", translated).strip().rstrip(".-_:/| ")
        if not subbed:
            break
        translated = subbed

    return translated or title.strip()

