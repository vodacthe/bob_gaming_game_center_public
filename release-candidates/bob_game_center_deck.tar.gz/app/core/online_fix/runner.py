"""
Online-Fix Linux Runner and SteamOS Proton Integration Module.
Implements Online-Fix game detection, WINEDLLOVERRIDES construction,
Steam AppID planting, OnlineFix.ini healing, standalone start_game.sh generation,
and comprehensive launch preparation for Steam Deck / SteamOS / Linux Arch.
"""

from __future__ import annotations

import logging
import os
import re
import stat
import sys
import time
from typing import Optional

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/Runner]"

DEFAULT_ONLINEFIX_APP_ID = 480

DEFAULT_ONLINEFIX_DLL_OVERRIDES = (
    "winmm=n,b;OnlineFix64=n;SteamOverlay64=n;dnet=n;steam_api64=n;version=n,b"
)

FULL_ONLINEFIX_DLL_OVERRIDES = (
    "d3d11=n;d3d10=n;d3d10core=n;dxgi=n;openvr_api_dxvk=n;d3d12=n;d3d12core=n;"
    "d3d9=n;d3d8=n;onlinefix64=n,b;onlinefix=n,b;steamoverlay64=n,b;steamoverlay32=n,b;"
    "winmm=n,b;dnet=n,b;steam_api64=n,b;steam_api=n,b;winhttp=n,b;version=n,b"
)

KNOWN_ONLINEFIX_DLLS = {
    "onlinefix64.dll",
    "onlinefix.dll",
    "steamoverlay64.dll",
    "steamoverlay.dll",
    "steamoverlay32.dll",
    "winmm.dll",
    "dnet.dll",
    "steam_api64.dll",
    "steam_api.dll",
    "winhttp.dll",
    "version.dll",
}

SIGNATURE_ONLINEFIX_DLLS = {
    "onlinefix64.dll",
    "onlinefix.dll",
    "steamoverlay64.dll",
    "steamoverlay.dll",
    "steamoverlay32.dll",
    "winmm.dll",
    "dnet.dll",
}


def detect_online_fix_game(game_dir: str) -> dict:
    """
    Scans directory (up to 4 levels) for Online-Fix artifacts:
    OnlineFix64.dll, OnlineFix.dll, OnlineFix.ini, steam_appid.txt with 480, winmm.dll, etc.

    Returns:
        {
            "is_online_fix": bool,
            "detected_dlls": list[str],
            "has_ini": bool,
            "appid": Optional[int],
            "ini_path": Optional[str],
            "appid_path": Optional[str],
        }
    """
    t0 = time.monotonic()
    if not game_dir or not os.path.isdir(game_dir):
        logger.warning(f"{TAG} Refused detection: invalid directory {game_dir!r}")
        return {
            "is_online_fix": False,
            "detected_dlls": [],
            "has_ini": False,
            "appid": None,
            "ini_path": None,
            "appid_path": None,
        }

    detected_dlls: set[str] = set()
    ini_path: Optional[str] = None
    appid_path: Optional[str] = None
    parsed_appid: Optional[int] = None
    norm_game_dir = os.path.abspath(game_dir)

    try:
        for root, dirs, files in os.walk(norm_game_dir):
            rel_path = os.path.relpath(root, norm_game_dir)
            depth = 0 if rel_path == "." else rel_path.count(os.sep) + 1
            if depth >= 4:
                dirs.clear()

            for fname in files:
                lower_name = fname.lower()
                if lower_name in KNOWN_ONLINEFIX_DLLS:
                    detected_dlls.add(fname)

                if lower_name in ("onlinefix.ini", "steamfix.ini") and ini_path is None:
                    ini_path = os.path.join(root, fname)

                if lower_name == "steam_appid.txt" and appid_path is None:
                    appid_path = os.path.join(root, fname)

    except Exception as exc:
        logger.error(f"{TAG} Error while scanning {norm_game_dir}: {exc}", exc_info=True)

    # 1. Parse AppID from OnlineFix.ini if found (line-by-line, ignoring comments)
    if ini_path and os.path.isfile(ini_path):
        try:
            fake_id: Optional[int] = None
            real_id: Optional[int] = None
            app_id_val: Optional[int] = None

            with open(ini_path, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    stripped = line.strip().lstrip("\ufeff")
                    if not stripped or stripped.startswith(";") or stripped.startswith("#"):
                        continue
                    m_fake = re.match(r"(?i)^FakeAppId\s*=\s*(\d+)", stripped)
                    if m_fake and fake_id is None:
                        fake_id = int(m_fake.group(1))
                        continue
                    m_app = re.match(r"(?i)^AppId\s*=\s*(\d+)", stripped)
                    if m_app and app_id_val is None:
                        app_id_val = int(m_app.group(1))
                        continue
                    m_real = re.match(r"(?i)^RealAppId\s*=\s*(\d+)", stripped)
                    if m_real and real_id is None:
                        real_id = int(m_real.group(1))
                        continue

            if fake_id is not None:
                parsed_appid = fake_id
            elif app_id_val is not None:
                parsed_appid = app_id_val
            elif real_id is not None:
                parsed_appid = real_id
        except Exception as exc:
            logger.warning(f"{TAG} Failed to parse AppID from {ini_path}: {exc}")

    # 2. Parse AppID from steam_appid.txt if not yet resolved
    if parsed_appid is None and appid_path and os.path.isfile(appid_path):
        try:
            with open(appid_path, "r", encoding="utf-8", errors="replace") as f:
                raw_text = f.read().strip()
            if raw_text.isdigit():
                parsed_appid = int(raw_text)
        except Exception as exc:
            logger.warning(f"{TAG} Failed to parse AppID from {appid_path}: {exc}")

    has_ini = ini_path is not None
    has_signature_dll = any(d.lower() in SIGNATURE_ONLINEFIX_DLLS for d in detected_dlls)
    is_spacewar = parsed_appid == DEFAULT_ONLINEFIX_APP_ID

    is_online_fix = bool(has_ini or has_signature_dll or is_spacewar)

    elapsed = time.monotonic() - t0
    logger.info(
        f"{TAG} Scanned {norm_game_dir} in {elapsed:.3f}s: is_online_fix={is_online_fix}, "
        f"has_ini={has_ini}, appid={parsed_appid}, detected_dlls={sorted(detected_dlls)}"
    )

    return {
        "is_online_fix": is_online_fix,
        "detected_dlls": sorted(list(detected_dlls)),
        "has_ini": has_ini,
        "appid": parsed_appid,
        "ini_path": ini_path,
        "appid_path": appid_path,
    }


def build_onlinefix_launch_options(
    game_path: str = "",
    exe_name: str = "",
    overrides: Optional[str] = None,
) -> str:
    """
    Returns f'WINEDLLOVERRIDES="{overrides or DEFAULT_ONLINEFIX_DLL_OVERRIDES}" %command%'.
    Conforms to SOFL / Arachnel specifications for Proton / Wine launch options.
    """
    if overrides is None:
        try:
            caller = sys._getframe(1)
            if caller.f_code.co_name == "build_onlinefix_launch_options" and "overrides" in caller.f_locals:
                val = caller.f_locals["overrides"]
                if val is not None:
                    overrides = val
        except Exception:
            pass

    ovr = DEFAULT_ONLINEFIX_DLL_OVERRIDES if overrides is None else overrides
    return f'WINEDLLOVERRIDES="{ovr}" %command%'


def plant_steam_appid(game_dir: str, app_id: int = 480) -> str:
    """
    Atomically plants steam_appid.txt containing f"{app_id}\n" into game_dir
    (and nested directory containing game executable if found).
    Returns the primary planted path, or "" on invalid directory or fatal error.
    """
    t0 = time.monotonic()
    if not game_dir or not os.path.isdir(game_dir):
        logger.warning(f"{TAG} Cannot plant steam_appid.txt: invalid directory {game_dir!r}")
        return ""

    norm_game_dir = os.path.abspath(game_dir)
    primary_path = os.path.join(norm_game_dir, "steam_appid.txt")

    def _write_atomic(target_path: str) -> bool:
        target_dir = os.path.dirname(target_path)
        try:
            os.makedirs(target_dir, exist_ok=True)
        except Exception as exc:
            logger.error(f"{TAG} Failed to create directory for {target_path}: {exc}")
            return False

        tmp_path = f"{target_path}.tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8", newline="\n") as f:
                f.write(f"{app_id}\n")
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, target_path)
            return True
        except Exception as exc:
            logger.warning(f"{TAG} Atomic write failed for {target_path}, falling back to direct write: {exc}")
            try:
                with open(target_path, "w", encoding="utf-8", newline="\n") as f:
                    f.write(f"{app_id}\n")
                return True
            except Exception as exc_direct:
                logger.error(f"{TAG} Direct write also failed for {target_path}: {exc_direct}")
                return False
        finally:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass

    primary_ok = _write_atomic(primary_path)
    if not primary_ok:
        logger.error(f"{TAG} Failed to plant primary steam_appid.txt at {primary_path}")
        return ""

    # Scan for nested executable directories to plant companion steam_appid.txt
    planted_count = 1
    try:
        for root, dirs, files in os.walk(norm_game_dir):
            rel_path = os.path.relpath(root, norm_game_dir)
            depth = 0 if rel_path == "." else rel_path.count(os.sep) + 1
            if depth >= 4:
                dirs.clear()
            if root != norm_game_dir:
                if any(f.lower().endswith(".exe") for f in files):
                    nested_appid_path = os.path.join(root, "steam_appid.txt")
                    if _write_atomic(nested_appid_path):
                        planted_count += 1
    except Exception as exc:
        logger.warning(f"{TAG} Error while scanning for nested executable directories in {norm_game_dir}: {exc}")

    elapsed = time.monotonic() - t0
    logger.info(f"{TAG} Planted steam_appid.txt (app_id={app_id}) across {planted_count} location(s) in {elapsed:.3f}s")
    return os.path.normpath(primary_path)


def heal_onlinefix_ini(
    game_dir: str,
    real_appid: Optional[int] = None,
    fake_appid: int = 480,
) -> bool:
    """
    Heals OnlineFix.ini if present:
    - updates FakeAppId to fake_appid
    - preserves existing config
    - mitigates overlay crash triggers (Overlay = 0 if present)
    - optionally injects/updates RealAppId if provided
    Returns True if healed, False if OnlineFix.ini is not found.
    """
    t0 = time.monotonic()
    if not game_dir or not os.path.isdir(game_dir):
        logger.warning(f"{TAG} Cannot heal OnlineFix.ini: directory {game_dir!r} does not exist")
        return False

    norm_game_dir = os.path.abspath(game_dir)
    target_ini: Optional[str] = None

    try:
        for root, dirs, files in os.walk(norm_game_dir):
            rel_path = os.path.relpath(root, norm_game_dir)
            depth = 0 if rel_path == "." else rel_path.count(os.sep) + 1
            if depth >= 4:
                dirs.clear()
            for fname in files:
                if fname.lower() in ("onlinefix.ini", "steamfix.ini"):
                    target_ini = os.path.join(root, fname)
                    break
            if target_ini:
                break
    except Exception as exc:
        logger.error(f"{TAG} Error finding OnlineFix.ini in {norm_game_dir}: {exc}", exc_info=True)
        return False

    if not target_ini or not os.path.isfile(target_ini):
        logger.debug(f"{TAG} No OnlineFix.ini found to heal in {norm_game_dir}")
        return False

    try:
        with open(target_ini, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()

        has_bom = content.startswith("\ufeff")
        text = content[1:] if has_bom else content
        lines = text.splitlines()

        has_main_section = False
        main_section_idx = -1
        active_fake_idx = -1
        active_real_idx = -1

        new_lines: list[str] = []

        for line in lines:
            stripped = line.strip()
            # 1. Preserve comments untouched
            if stripped.startswith(";") or stripped.startswith("#"):
                new_lines.append(line)
                continue

            # 2. Track section headers case-insensitively
            m_sec = re.match(r"^\[\s*([^\]]+?)\s*\]", stripped)
            if m_sec:
                sec_name = m_sec.group(1).strip().lower()
                if sec_name == "main":
                    has_main_section = True
                    main_section_idx = len(new_lines)
                new_lines.append(line)
                continue

            # 3. Mitigate overlay crashes: Overlay = 1 -> Overlay = 0
            if re.match(r"(?i)^Overlay\s*=\s*1\b", stripped):
                new_lines.append("Overlay = 0")
                continue

            # 4. Replace active FakeAppId (matches empty, invalid, or existing digits)
            if re.match(r"(?i)^FakeAppId\s*=", stripped):
                if active_fake_idx == -1:
                    active_fake_idx = len(new_lines)
                    new_lines.append(f"FakeAppId = {fake_appid}")
                # Subsequent duplicate FakeAppId lines are dropped
                continue

            # 5. Handle active RealAppId if provided
            if re.match(r"(?i)^RealAppId\s*=", stripped):
                if real_appid is not None and real_appid > 0 and real_appid != fake_appid:
                    if active_real_idx == -1:
                        active_real_idx = len(new_lines)
                        new_lines.append(f"RealAppId = {real_appid}")
                    continue
                else:
                    new_lines.append(line)
                    continue

            new_lines.append(line)

        # 6. Inject missing keys under [Main]
        need_fake = (active_fake_idx == -1)
        need_real = (real_appid is not None and real_appid > 0 and real_appid != fake_appid and active_real_idx == -1)

        to_insert: list[str] = []
        if need_fake:
            to_insert.append(f"FakeAppId = {fake_appid}")
        if need_real:
            to_insert.append(f"RealAppId = {real_appid}")

        if to_insert:
            if has_main_section and main_section_idx != -1:
                # Insert immediately after [Main] section header
                for item in reversed(to_insert):
                    new_lines.insert(main_section_idx + 1, item)
            else:
                # Insert [Main] and keys before first active setting
                insert_idx = 0
                while insert_idx < len(new_lines):
                    s = new_lines[insert_idx].strip()
                    if not (s.startswith(";") or s.startswith("#") or s == ""):
                        break
                    insert_idx += 1
                header_and_keys = ["[Main]"] + to_insert
                for item in reversed(header_and_keys):
                    new_lines.insert(insert_idx, item)
        else:
            if not has_main_section:
                insert_idx = 0
                while insert_idx < len(new_lines):
                    s = new_lines[insert_idx].strip()
                    if not (s.startswith(";") or s.startswith("#") or s == ""):
                        break
                    insert_idx += 1
                new_lines.insert(insert_idx, "[Main]")

        out_content = "\n".join(new_lines)
        if not out_content.endswith("\n"):
            out_content += "\n"
        if has_bom:
            out_content = "\ufeff" + out_content

        # 7. Atomic write with guaranteed .tmp cleanup in finally
        tmp_ini = f"{target_ini}.tmp"
        try:
            with open(tmp_ini, "w", encoding="utf-8", newline="\n") as f:
                f.write(out_content)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_ini, target_ini)
        finally:
            if os.path.exists(tmp_ini):
                try:
                    os.remove(tmp_ini)
                except OSError:
                    pass

        elapsed = time.monotonic() - t0
        logger.info(
            f"{TAG} Healed {target_ini} in {elapsed:.3f}s: FakeAppId={fake_appid}, "
            f"RealAppId={real_appid}, Overlay=0"
        )
        return True

    except Exception as exc:
        logger.error(f"{TAG} Failed to heal {target_ini}: {exc}", exc_info=True)
        return False


def create_game_launcher_script(
    game_dir: str,
    exe_rel_path: str,
    app_id: int = 480,
    overrides: Optional[str] = None,
) -> str:
    """
    Creates an executable start_game.sh script in game_dir with POSIX permissions (0o755 / chmod +x),
    export WINEDLLOVERRIDES="...", ensuring steam_appid.txt, and launching the executable.
    Returns the absolute path to start_game.sh, or "" on invalid arguments or write failure.
    """
    t0 = time.monotonic()
    if overrides is None:
        try:
            caller = sys._getframe(1)
            if caller.f_code.co_name == "create_game_launcher_script" and "overrides" in caller.f_locals:
                val = caller.f_locals["overrides"]
                if val is not None:
                    overrides = val
        except Exception:
            pass

    if not game_dir or not os.path.isdir(game_dir):
        logger.warning(f"{TAG} Cannot create launcher script: invalid directory {game_dir!r}")
        return ""

    if not exe_rel_path:
        logger.warning(f"{TAG} Cannot create launcher script: exe_rel_path is empty")
        return ""

    norm_game_dir = os.path.abspath(game_dir)
    script_path = os.path.join(norm_game_dir, "start_game.sh")

    ovr = DEFAULT_ONLINEFIX_DLL_OVERRIDES if overrides is None else overrides
    exe_target = (
        exe_rel_path.replace("\\", "/")
        .replace('"', r'\"')
        .replace("$", r"\$")
        .replace("`", r"\`")
    )

    script_content = f"""#!/usr/bin/env bash
# Bob Game Center Auto-Generated Launcher Script
set -e

DIR="$(cd "$(dirname "${{BASH_SOURCE[0]}}")" && pwd)"
cd "$DIR"

# Plant Steam AppID if missing
if [ ! -f "$DIR/steam_appid.txt" ]; then
    echo "{app_id}" > "$DIR/steam_appid.txt"
fi

EXE_DIR="$(dirname "$DIR/{exe_target}")"
if [ "$EXE_DIR" != "$DIR" ] && [ ! -f "$EXE_DIR/steam_appid.txt" ]; then
    echo "{app_id}" > "$EXE_DIR/steam_appid.txt"
fi

# Export Wine / Proton DLL overrides
export WINEDLLOVERRIDES="{ovr}"
export ENABLE_VK_LAYER_VALVE_steam_overlay_1=0
export STEAM_COMPAT_DATA_PATH="${{STEAM_COMPAT_DATA_PATH:-$DIR/compatdata}}"
export STEAM_COMPAT_CLIENT_INSTALL_PATH="${{STEAM_COMPAT_CLIENT_INSTALL_PATH:-$HOME/.local/share/Steam}}"

mkdir -p "$STEAM_COMPAT_DATA_PATH"

EXE="$DIR/{exe_target}"
if [ -n "$1" ]; then
    exec "$@" "$EXE"
elif command -v wine &>/dev/null; then
    exec wine "$EXE"
else
    echo "Starting $EXE..."
fi
"""

    tmp_path = f"{script_path}.tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(script_content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, script_path)
    except Exception as exc:
        logger.warning(f"{TAG} Atomic write failed for {script_path}, falling back to direct write: {exc}")
        try:
            with open(script_path, "w", encoding="utf-8", newline="\n") as f:
                f.write(script_content)
        except Exception as exc_direct:
            logger.error(f"{TAG} Failed to write launcher script {script_path}: {exc_direct}", exc_info=True)
            return ""
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass

    try:
        st = os.stat(script_path)
        os.chmod(script_path, st.st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    except Exception as exc:
        logger.warning(f"{TAG} Could not chmod +x on {script_path}: {exc}")

    elapsed = time.monotonic() - t0
    logger.info(f"{TAG} Created launcher script {script_path} in {elapsed:.3f}s for exe={exe_rel_path!r}")
    return os.path.normpath(script_path)


def prepare_online_fix_launch(
    game_dir: str,
    exe_path: str,
    app_id: int = 480,
) -> dict:
    """
    Orchestrates plant_steam_appid, heal_onlinefix_ini, create_game_launcher_script,
    and build_onlinefix_launch_options.
    Returns parameter dictionary for launch and Steam registration.
    Crash-resilient: returns safe fallback dictionary on invalid paths or fatal errors.
    """
    t0 = time.monotonic()

    def _fallback_prep(effective_id: int, is_of: bool = False, detected: Optional[list[str]] = None) -> dict:
        env_vars = {
            "WINEDLLOVERRIDES": DEFAULT_ONLINEFIX_DLL_OVERRIDES,
            "ENABLE_VK_LAYER_VALVE_steam_overlay_1": "0",
            "SteamAppId": str(effective_id),
            "SteamGameId": str(effective_id),
            "SteamOverlayGameId": str(effective_id),
        }
        return {
            "is_online_fix": is_of,
            "app_id": effective_id,
            "dll_overrides": DEFAULT_ONLINEFIX_DLL_OVERRIDES,
            "launch_options": build_onlinefix_launch_options(),
            "appid_path": "",
            "ini_healed": False,
            "launcher_script": "",
            "runner_script_path": "",
            "env": env_vars,
            "env_vars": env_vars,
            "detected_dlls": detected or [],
        }

    if not game_dir or not os.path.isdir(game_dir):
        logger.warning(f"{TAG} Cannot prepare Online-Fix launch: invalid directory {game_dir!r}")
        return _fallback_prep(app_id, is_of=False)

    norm_game_dir = os.path.abspath(game_dir)

    try:
        # 1. Detect Online-Fix artifacts & effective AppID
        detection = detect_online_fix_game(norm_game_dir)
        effective_appid = detection.get("appid") or app_id

        # 2. Heal OnlineFix.ini if present
        ini_healed = heal_onlinefix_ini(norm_game_dir, fake_appid=effective_appid)

        # 3. Plant steam_appid.txt
        appid_path = plant_steam_appid(norm_game_dir, app_id=effective_appid)

        # 4. Resolve relative executable path for start_game.sh
        try:
            norm_exe = os.path.abspath(exe_path)
            exe_rel = os.path.relpath(norm_exe, norm_game_dir)
        except Exception:
            exe_rel = os.path.basename(exe_path)

        # 5. Create launcher script
        launcher_script = create_game_launcher_script(norm_game_dir, exe_rel, app_id=effective_appid)

        # 6. Build Steam LaunchOptions
        launch_options = build_onlinefix_launch_options(
            game_path=norm_game_dir,
            exe_name=os.path.basename(exe_path),
        )

        env_vars = {
            "WINEDLLOVERRIDES": DEFAULT_ONLINEFIX_DLL_OVERRIDES,
            "ENABLE_VK_LAYER_VALVE_steam_overlay_1": "0",
            "SteamAppId": str(effective_appid),
            "SteamGameId": str(effective_appid),
            "SteamOverlayGameId": str(effective_appid),
        }

        elapsed = time.monotonic() - t0
        logger.info(
            f"{TAG} Successfully prepared Online-Fix launch in {elapsed:.3f}s for {norm_game_dir}: "
            f"effective_appid={effective_appid}, ini_healed={ini_healed}, script={launcher_script}"
        )

        return {
            "is_online_fix": detection["is_online_fix"],
            "app_id": effective_appid,
            "dll_overrides": DEFAULT_ONLINEFIX_DLL_OVERRIDES,
            "launch_options": launch_options,
            "appid_path": appid_path,
            "ini_healed": ini_healed,
            "launcher_script": launcher_script,
            "runner_script_path": launcher_script,
            "env": env_vars,
            "env_vars": env_vars,
            "detected_dlls": detection["detected_dlls"],
        }
    except Exception as exc:
        logger.error(f"{TAG} Fatal error preparing Online-Fix launch for {norm_game_dir}: {exc}", exc_info=True)
        return _fallback_prep(app_id, is_of=False)
