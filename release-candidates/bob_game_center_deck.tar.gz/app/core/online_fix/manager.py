"""
OnlineFixManager: Central controller coordinating search, download queue,
background aria2c execution, 7z extraction, and Library auto-registration.

Signals are emitted from worker threads; Qt queues them to receivers living on the UI thread.
"""

from dataclasses import replace
import json
import logging
import os
import posixpath
import re
import shutil
import sys
import threading
import time
import uuid
from typing import Dict, List, Optional

from PySide6.QtCore import QObject, Signal

from app.config import get_app_dir, load_config, save_config, update_online_fix_config
from app.core.online_fix.ankergames_client import AnkerGamesClient
from app.core.online_fix.aria2_downloader import Aria2Downloader
from app.core.online_fix.client import OnlineFixClient, OnlineFixError
from app.core.online_fix.extractor import GameExtractor
from app.core.online_fix.fitgirl_client import FitGirlClient
from app.core.online_fix.models import (
    ACTIVE_STATUSES,
    ALL_STORE_SOURCES,
    ANKERGAMES_ARCHIVE_PASSWORD,
    DEFAULT_ARCHIVE_PASSWORD,
    PROVIDER_PRIORITY,
    SOURCE_ANKERGAMES,
    SOURCE_FITGIRL,
    SOURCE_ONLINE_FIX,
    SOURCE_STEAMRIP,
    STEAMRIP_ARCHIVE_PASSWORD,
    DownloadTask,
    OnlineFixGame,
    TaskStatus,
    format_ts_ddmmyyyy,
    normalize_enabled_stores,
)
from app.core.online_fix.steamrip_client import SteamRipClient

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/Manager]"


def get_default_install_root() -> str:
    """Resolve the default games installation directory based on current OS."""
    from app.core.system_actions import get_default_games_directory
    return get_default_games_directory()


def is_valid_install_root(root: Optional[str]) -> bool:
    """Validate whether a path is suitable as a games installation root directory."""
    if not root:
        return False
    path_mod = posixpath if sys.platform != "win32" else os.path
    root_str = str(root).strip()
    if not root_str or not path_mod.isabs(root_str):
        return False

    norm = path_mod.normpath(root_str)
    if sys.platform == "win32":
        drive = os.path.splitdrive(norm)[0]
        if not drive or (drive and not os.path.exists(drive + "\\")):
            return False
        return True
    else:
        # On POSIX:
        # 1. Must start with '/'
        # 2. Must not contain Windows drive colons (e.g. 'D:\Games')
        # 3. Must not be the POSIX root directory '/' or root slash variants ('//')
        if not norm.startswith("/") or ":" in norm or norm in ("/", "") or norm.rstrip("/") == "":
            return False
        return True


DEFAULT_INSTALL_ROOT = get_default_install_root()
UPDATE_GRACE_SECONDS = 3600.0


def _is_test_env() -> bool:
    if getattr(sys, "frozen", False):
        return False
    app_dir = os.path.normcase(os.path.abspath(get_app_dir()))
    repo_dir = os.path.normcase(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
    return app_dir != repo_dir


_FOLDER_SUFFIX = re.compile(
    r"(?:[\s\-_–—:/|]+[\(\[]*|[\(\[])(?:по\s+сети|online|онлайн)[\s\)\]]*$",
    re.IGNORECASE,
)


def _sanitize_folder_name(name: str) -> str:
    """Sanitize game title for folder creation on Windows, stripping trailing 'Online' suffixes."""
    clean = re.sub(r'[\\/*?:"<>|]', "", name).strip().rstrip(".")
    while _FOLDER_SUFFIX.search(clean):
        subbed = _FOLDER_SUFFIX.sub("", clean).strip().rstrip(".-_:/| ")
        if not subbed:
            break
        clean = subbed
    return clean if clean else "Game"


_ROMAN_TOKEN_MAP = {
    "ii": "2", "iii": "3", "iv": "4", "v": "5",
    "vi": "6", "vii": "7", "viii": "8", "ix": "9", "x": "10",
}
_NON_ALNUM_RE = re.compile(r"[^a-z0-9]+")
_TRAILING_EDITION_RE = re.compile(
    r"(?:[\s:\-–—|/]+)"
    r"(?:"
    r"(?:(?:super|digital|ultimate|complete|deluxe|supporter|collector'?s|definitive|enhanced|premium|"
    r"gold|standard|anniversary|goty|game\s+of\s+the\s+year|devout|absolute|master|royal|imperial|"
    r"founder'?s|champion|legendary|special|limited|expanded)\s+)+"
    r"(?:edition|version|bundle|repack|pack(?:\s+bundle)?)"
    r"|repack"
    r"|game\s+of\s+the\s+year(?:\s+edition)?"
    r"|goty(?:\s+edition)?"
    r"|director'?s\s+cut"
    r"|year\s+\d+\s+(?:edition|bundle|pass)"
    r"|all\s+dlcs?"
    r")\s*$",
    re.IGNORECASE,
)


def _token_key(text: str) -> str:
    low = (text or "").lower().replace("&", " and ")
    tokens = [_ROMAN_TOKEN_MAP.get(tok, tok) for tok in _NON_ALNUM_RE.split(low) if tok]
    return "".join(tokens)


def _normalize_title_keys(title: str) -> set[str]:
    """Return canonical alphanumeric keys for matching the same game across all store providers."""
    if not title:
        return set()
    from app.core.online_fix.store_cache import clean_lookup_title

    base = clean_lookup_title(title)
    keys: set[str] = set()
    base_key = _token_key(base)
    if base_key:
        keys.add(base_key)
    stripped = _TRAILING_EDITION_RE.sub("", base).strip().rstrip(".-_:/|–— ")
    if stripped and stripped != base:
        stripped_key = _token_key(stripped)
        if len(stripped_key) >= 2:
            keys.add(stripped_key)
    if not keys:
        raw_key = _token_key(title)
        if raw_key:
            keys.add(raw_key)
    return keys


def games_have_same_title(a: OnlineFixGame, b: OnlineFixGame) -> bool:
    """Return True if two OnlineFixGame items refer to the same game title."""
    keys_a = _normalize_title_keys(a.title)
    keys_b = _normalize_title_keys(b.title)
    return bool(keys_a and keys_b and (keys_a & keys_b))


def _provider_priority_rank(src: str) -> int:
    try:
        return PROVIDER_PRIORITY.index(src)
    except ValueError:
        return len(PROVIDER_PRIORITY)


def _ordered_variants(by_source: Dict[str, OnlineFixGame]) -> List[OnlineFixGame]:
    """Order store variants by newest update day first, breaking same-day ties via PROVIDER_PRIORITY."""
    items = list(by_source.values())
    if len(items) <= 1:
        return items
    return sorted(
        items,
        key=lambda g: (
            -int(g.effective_update_ts() // 86400) if g.effective_update_ts() > 0 else 0,
            _provider_priority_rank(g.source or SOURCE_ONLINE_FIX),
        ),
    )


def _build_merged_game(
    by_source: Dict[str, OnlineFixGame],
    all_matched: List[OnlineFixGame],
    preferred_primary: Optional[OnlineFixGame] = None,
) -> OnlineFixGame:
    variants = _ordered_variants(by_source)
    primary = preferred_primary if preferred_primary is not None else variants[0]

    merged_cats: list[str] = []
    for g in all_matched:
        for cat in (g.categories or ()):
            if cat and cat not in merged_cats:
                merged_cats.append(cat)
    if len(merged_cats) > 1 and "other" in merged_cats:
        merged_cats = [c for c in merged_cats if c != "other"]

    best_poster = primary.poster_url
    if not (best_poster and best_poster != primary.provider_poster_url):
        for v in variants:
            if v.poster_url and v.poster_url != v.provider_poster_url:
                best_poster = v.poster_url
                break
        else:
            if not best_poster:
                for v in variants:
                    if v.poster_url:
                        best_poster = v.poster_url
                        break

    pub_candidates = [float(g.published_ts or 0.0) for g in all_matched if float(g.published_ts or 0.0) > 0]
    upd_candidates = [g.effective_update_ts() for g in all_matched if g.effective_update_ts() > 0]
    merged_pub_ts = (
        float(primary.published_ts or 0.0)
        if preferred_primary is not None and float(primary.published_ts or 0.0) > 0
        else (max(pub_candidates) if pub_candidates else 0.0)
    )
    merged_upd_ts = max(upd_candidates) if upd_candidates else 0.0
    merged_date = primary.date or format_ts_ddmmyyyy(merged_pub_ts)

    return replace(
        primary,
        poster_url=best_poster,
        date=merged_date,
        published_ts=merged_pub_ts,
        updated_ts=merged_upd_ts,
        is_hypervisor=bool(primary.is_hypervisor),
        categories=merged_cats if merged_cats else list(primary.categories or []),
        providers=variants,
    )


def _sort_games_chronologically(games: List[OnlineFixGame]) -> List[OnlineFixGame]:
    """Sort games newest original release/upload (`published_ts`) first; undated items retain stable order at tail."""
    if len(games) <= 1 or not any(float(g.published_ts or 0.0) > 0 for g in games):
        return games
    indexed = list(enumerate(games))
    indexed.sort(
        key=lambda pair: (
            (0, -float(pair[1].published_ts), pair[0])
            if float(pair[1].published_ts or 0.0) > 0
            else (1, 0.0, pair[0])
        )
    )
    return [g for _, g in indexed]


def interleave_games(
    of_games: List[OnlineFixGame],
    fg_games: List[OnlineFixGame] = (),
    sr_games: List[OnlineFixGame] = (),
    ag_games: List[OnlineFixGame] = (),
) -> List[OnlineFixGame]:
    """
    Merge and deduplicate games across Online-Fix, AnkerGames, SteamRIP, and FitGirl,
    selecting the freshest store variant (tie-broken by Online-Fix -> AnkerGames -> SteamRIP -> FitGirl)
    and sorting chronologically by original store release timestamp (`published_ts` descending).
    """
    lists = [
        list(of_games or ()),
        list(ag_games or ()),
        list(fg_games or ()),
        list(sr_games or ()),
    ]
    if not any(lists):
        return []

    merged: List[OnlineFixGame] = []
    used: list[set[int]] = [set() for _ in lists]
    deduped_entries = 0
    multi_provider_count = 0
    max_len = max(len(lst) for lst in lists)

    # Pre-index normalized title keys once in O(N) so merging 500+ pooled games takes <1ms
    item_keys: list[list[set[str]]] = [[_normalize_title_keys(g.title) for g in lst] for lst in lists]
    key_index: list[dict[str, list[int]]] = []
    for s_keys in item_keys:
        idx_map: dict[str, list[int]] = {}
        for pos, kset in enumerate(s_keys):
            for k in kset:
                idx_map.setdefault(k, []).append(pos)
        key_index.append(idx_map)

    for i in range(max_len):
        for s_idx, src_list in enumerate(lists):
            if i >= len(src_list) or i in used[s_idx]:
                continue

            used[s_idx].add(i)
            seed = src_list[i]
            matched_all: List[OnlineFixGame] = [seed]
            by_source: Dict[str, OnlineFixGame] = {seed.source or SOURCE_ONLINE_FIX: seed}
            pending_keys = list(item_keys[s_idx][i])
            seen_keys = set(pending_keys)

            while pending_keys:
                key = pending_keys.pop()
                for cand_s, idx_map in enumerate(key_index):
                    used_set = used[cand_s]
                    for cand_pos in idx_map.get(key, ()):
                        if cand_pos in used_set:
                            continue
                        used_set.add(cand_pos)
                        cand_game = lists[cand_s][cand_pos]
                        matched_all.append(cand_game)
                        cand_src = cand_game.source or SOURCE_ONLINE_FIX
                        if cand_src not in by_source:
                            by_source[cand_src] = cand_game
                        for extra_k in item_keys[cand_s][cand_pos]:
                            if extra_k not in seen_keys:
                                seen_keys.add(extra_k)
                                pending_keys.append(extra_k)

            unified = _build_merged_game(by_source, matched_all)
            merged.append(unified)
            if len(matched_all) > 1:
                deduped_entries += len(matched_all) - 1
            if len(by_source) > 1:
                multi_provider_count += 1
                logger.debug(
                    f"{TAG} Merged multi-provider game {unified.title!r}: "
                    f"sources={list(unified.available_sources())}"
                )

    merged = _sort_games_chronologically(merged)
    if deduped_entries:
        logger.info(
            f"{TAG} Merged {deduped_entries} duplicate store entry(ies) across "
            f"{multi_provider_count} multi-provider game(s) ({len(merged)} unique total)"
        )
    return merged


def attach_store_providers(
    target_games: List[OnlineFixGame],
    of_games: List[OnlineFixGame] = (),
    fg_games: List[OnlineFixGame] = (),
    sr_games: List[OnlineFixGame] = (),
    ag_games: List[OnlineFixGame] = (),
) -> List[OnlineFixGame]:
    """
    For single-store filter views: keep `target_games` source identity while attaching
    matching variants from the other stores onto `game.providers` and sorting chronologically.
    """
    if not target_games:
        return []

    pools = (
        (SOURCE_ONLINE_FIX, list(of_games or ())),
        (SOURCE_ANKERGAMES, list(ag_games or ())),
        (SOURCE_STEAMRIP, list(sr_games or ())),
        (SOURCE_FITGIRL, list(fg_games or ())),
    )
    pool_index: dict[str, dict[str, OnlineFixGame]] = {}
    for src, lst in pools:
        idx: dict[str, OnlineFixGame] = {}
        for g in lst:
            for k in _normalize_title_keys(g.title):
                if k not in idx:
                    idx[k] = g
        pool_index[src] = idx

    out: List[OnlineFixGame] = []
    seen_target_keys: set[str] = set()
    for g in target_games:
        g_keys = _normalize_title_keys(g.title)
        if g_keys and (g_keys & seen_target_keys):
            continue
        seen_target_keys.update(g_keys)

        g_src = g.source or SOURCE_ONLINE_FIX
        by_source: Dict[str, OnlineFixGame] = {g_src: g}
        matched_all: List[OnlineFixGame] = [g]
        for src in PROVIDER_PRIORITY:
            if src == g_src:
                continue
            idx = pool_index.get(src, {})
            for k in g_keys:
                cand = idx.get(k)
                if cand is not None:
                    by_source[src] = cand
                    matched_all.append(cand)
                    break

        out.append(_build_merged_game(by_source, matched_all, preferred_primary=g))
    return _sort_games_chronologically(out)


def resolve_game_providers(
    game: OnlineFixGame,
    of_games: List[OnlineFixGame] = (),
    fg_games: List[OnlineFixGame] = (),
    sr_games: List[OnlineFixGame] = (),
    ag_games: List[OnlineFixGame] = (),
) -> List[OnlineFixGame]:
    """Return all store variants matching `game` ordered freshest-first, then PROVIDER_PRIORITY."""
    by_source: Dict[str, OnlineFixGame] = {}
    for existing in (game.providers or ()):
        src = existing.source or SOURCE_ONLINE_FIX
        if src not in by_source:
            by_source[src] = existing
    g_src = game.source or SOURCE_ONLINE_FIX
    by_source.setdefault(g_src, game)

    g_keys = _normalize_title_keys(game.title)
    if g_keys:
        for src, lst in (
            (SOURCE_ONLINE_FIX, of_games),
            (SOURCE_ANKERGAMES, ag_games),
            (SOURCE_STEAMRIP, sr_games),
            (SOURCE_FITGIRL, fg_games),
        ):
            if src in by_source or not lst:
                continue
            for cand in lst:
                if _normalize_title_keys(cand.title) & g_keys:
                    by_source[src] = cand
                    break

    return _ordered_variants(by_source)


def _max_store_update_ts(game: OnlineFixGame) -> float:
    best = game.effective_update_ts()
    for p in (game.providers or ()):
        ts = p.effective_update_ts()
        if ts > best:
            best = ts
    return best


def is_game_update_available(
    game: OnlineFixGame,
    installed_ts_by_key: Dict[str, float],
    grace_seconds: float = UPDATE_GRACE_SECONDS,
) -> bool:
    """Return True when `game` matches a locally installed title and has a store update newer than local install."""
    if not installed_ts_by_key:
        return False
    g_keys = _normalize_title_keys(game.title)
    if not g_keys:
        return False
    local_ts = 0.0
    for k in g_keys:
        cand_ts = float(installed_ts_by_key.get(k) or 0.0)
        if cand_ts > local_ts:
            local_ts = cand_ts
    if local_ts <= 0.0:
        return False
    store_ts = _max_store_update_ts(game)
    return store_ts > (local_ts + grace_seconds)


def find_installed_game_updates(
    games: List[OnlineFixGame],
    installed_ts_by_key: Dict[str, float],
    grace_seconds: float = UPDATE_GRACE_SECONDS,
) -> List[OnlineFixGame]:
    """Filter `games` down to locally installed titles with newer store updates, sorted newest update first."""
    if not games or not installed_ts_by_key:
        return []
    matched = [g for g in games if is_game_update_available(g, installed_ts_by_key, grace_seconds=grace_seconds)]
    matched.sort(key=_max_store_update_ts, reverse=True)
    return matched


class OnlineFixManager(QObject):
    """
    Singleton-style manager managing download tasks, progress updates,
    pause/resume, persistent queue state, and automatic library registration.
    """
    # Signals for UI binding
    task_added = Signal(DownloadTask)
    task_progress = Signal(str, float, str, str)  # (task_id, percent, speed, eta)
    task_paused = Signal(str)                     # (task_id)
    task_resumed = Signal(str)                    # (task_id)
    task_extracting = Signal(str, float, str)     # (task_id, percent, message)
    task_completed = Signal(str, str)             # (task_id, exe_path)
    task_failed = Signal(str, str)                # (task_id, error_message)
    task_cancelled = Signal(str)                  # (task_id)
    tasks_removed = Signal(list)                  # (list[task_id])

    def __init__(self, parent=None):
        super().__init__(parent)
        self.client = OnlineFixClient()
        self.ankergames_client = AnkerGamesClient()
        self.fitgirl_client = FitGirlClient()
        self.steamrip_client = SteamRipClient()
        self.tasks: Dict[str, DownloadTask] = {}
        self._lock = threading.RLock()
        self._active_downloaders: Dict[str, Aria2Downloader] = {}
        self._active_extractors: Dict[str, GameExtractor] = {}
        self._started_at: Dict[str, float] = {}
        self._last_saved_pct: Dict[str, float] = {}
        self._last_saved_time: Dict[str, float] = {}
        self._load_tasks_from_config()

    def fetch_poster_bytes(self, url: str) -> bytes:
        """Route poster downloads to the right client (supports fitgirl-post:, ankergames, steamrip, and Steam/SGDB CDNs)."""
        low = (url or "").lower()
        if low.startswith("fitgirl-post:") or "fitgirl-repacks.site" in low or "imageban.ru" in low:
            return self.fitgirl_client.fetch_bytes(url)
        if "ankergames.net" in low:
            return self.ankergames_client.fetch_bytes(url)
        if "steamrip.com" in low or any(cdn in low for cdn in ("steamgriddb.com", "steamstatic.com", "akamaihd.net")):
            return self.steamrip_client.fetch_bytes(url)
        return self.client.fetch_bytes(url)

    def get_installed_games_timestamps(self) -> Dict[str, float]:
        """Return map of normalized title key -> local install/update epoch for games currently installed on disk."""
        cfg = self._read_config_dict()
        games_cfg = cfg.get("games", {})
        if not isinstance(games_cfg, dict) or not games_cfg:
            return {}
        removed = {str(x).strip().lower() for x in (cfg.get("removed_games") or []) if x}
        out: Dict[str, float] = {}
        for raw_key, entry in games_cfg.items():
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("name") or raw_key or "").strip()
            if not name or name.lower() in removed:
                continue
            exe_path = str(entry.get("exe_path") or "").strip()
            install_loc = str(entry.get("install_location") or "").strip()
            exists_on_disk = (bool(exe_path) and os.path.isfile(exe_path)) or (
                bool(install_loc) and os.path.isdir(install_loc)
            )
            if not exists_on_disk:
                continue

            ts = float(entry.get("installed_at") or 0.0)
            if ts <= 0.0:
                for p in (exe_path, install_loc):
                    if p and os.path.exists(p):
                        try:
                            ts = max(ts, float(os.path.getmtime(p)))
                        except OSError:
                            pass
            if ts <= 0.0:
                continue
            for tkey in _normalize_title_keys(name):
                prev = out.get(tkey, 0.0)
                if ts > prev:
                    out[tkey] = ts
        return out

    def get_default_download_root(self) -> str:
        """Root folder for downloading games (directly in the user's configured install root)."""
        return self.get_install_root()

    # ------------------------------------------------------------ config persistence

    @staticmethod
    def _test_config_path() -> str:
        return os.path.join(get_app_dir(), "config.json")

    def _read_config_dict(self) -> dict:
        if _is_test_env():
            path = self._test_config_path()
            if not os.path.exists(path):
                return {}
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                return data if isinstance(data, dict) else {}
            except Exception as e:
                logger.warning(f"{TAG} Could not read {path}: {e}")
                return {}
        try:
            return load_config()
        except Exception as e:
            logger.warning(f"{TAG} Could not read config.json: {e}")
            return {}

    def _write_install_root_to_config(self, root: Optional[str]) -> bool:
        target_str = str(root or "").strip()
        target_norm = os.path.normcase(target_str) if target_str else ""

        if _is_test_env():
            path = self._test_config_path()
            data = self._read_config_dict()
            existing_val = data.get("online_fix_install_root")
            existing_str = str(existing_val or "").strip()
            existing_norm = os.path.normcase(existing_str) if existing_str else ""
            if existing_norm and existing_norm == target_norm:
                return False
            if not existing_norm and not target_str:
                return False
            data["online_fix_install_root"] = root
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                return True
            except OSError as e:
                logger.warning(f"{TAG} Could not save install folder {root}: {e}")
                return False

        try:
            cfg = load_config()
            existing_val = cfg.get("online_fix_install_root")
            existing_str = str(existing_val or "").strip()
            existing_norm = os.path.normcase(existing_str) if existing_str else ""
            if existing_norm and existing_norm == target_norm:
                return False
            if not existing_norm and not target_str:
                return False
            return bool(update_online_fix_config(online_fix_install_root=root))
        except Exception as e:
            logger.warning(f"{TAG} Could not persist install folder to config.json: {e}")
            return False

    def _load_tasks_from_config(self):
        """Restore persisted download queue from config.json and recover any interrupted tasks as PAUSED."""
        cfg = self._read_config_dict()
        raw_tasks = cfg.get("online_fix_tasks", [])
        if not isinstance(raw_tasks, list) or not raw_tasks:
            return
        recovered_count = 0
        with self._lock:
            for item in raw_tasks:
                if not isinstance(item, dict):
                    continue
                task = DownloadTask.from_dict(item)
                if not task.task_id or not task.game_title:
                    continue
                if task.status in ACTIVE_STATUSES:
                    task.status = TaskStatus.PAUSED
                    task.download_speed = ""
                    task.eta = "Bị gián đoạn — bấm Tiếp tục để tải tiếp"
                    recovered_count += 1
                    logger.info(
                        f"{TAG} Recovered interrupted task {task.task_id} ({task.game_title!r}) "
                        f"at {task.progress_percent:.1f}% -> PAUSED"
                    )
                self.tasks[task.task_id] = task
                self._last_saved_pct[task.task_id] = task.progress_percent
                self._last_saved_time[task.task_id] = time.monotonic()

        logger.info(
            f"{TAG} Loaded {len(self.tasks)} persisted task(s) from config.json "
            f"(recovered from interruption: {recovered_count})"
        )
        if recovered_count:
            self._save_tasks_to_config()

    def _save_tasks_to_config(self):
        """Persist the current task queue to config.json."""
        with self._lock:
            serialized = [t.to_dict() for t in self.tasks.values()]
        if _is_test_env():
            path = self._test_config_path()
            data = self._read_config_dict()
            data["online_fix_tasks"] = serialized
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            except OSError as e:
                logger.warning(f"{TAG} Could not persist tasks to {path}: {e}")
            return
        try:
            update_online_fix_config(online_fix_tasks=serialized)
        except Exception as e:
            logger.warning(f"{TAG} Could not persist tasks to config.json: {e}")

    is_valid_install_root = staticmethod(is_valid_install_root)

    def get_install_root(self) -> str:
        """Install folder the user chose last time, else DEFAULT_INSTALL_ROOT (also when the saved drive or mount is gone)."""
        path_mod = posixpath if sys.platform != "win32" else os.path
        cfg = self._read_config_dict()
        raw_root = cfg.get("online_fix_install_root")
        root = str(raw_root).strip() if raw_root is not None else ""

        default_root = get_default_install_root()

        if not root and not _is_test_env():
            for game_data in cfg.get("games", {}).values():
                if not isinstance(game_data, dict):
                    continue
                loc = game_data.get("install_location", "")
                if loc and path_mod.isabs(loc):
                    parent = path_mod.dirname(path_mod.normpath(loc))
                    if is_valid_install_root(parent) and os.path.exists(parent):
                        root = parent
                        break

        if not is_valid_install_root(root):
            if root:
                logger.info(f"{TAG} Saved install folder {root} is not available: using {default_root}")
            return default_root
        return path_mod.normpath(root)

    def save_install_root(self, root: str) -> bool:
        """Remember the install folder the user picked (no-op when unchanged). Returns True when saved."""
        path_mod = posixpath if sys.platform != "win32" else os.path
        if not is_valid_install_root(root):
            logger.warning(f"{TAG} Not saving install folder {root!r}: not an absolute path or invalid install root")
            return False

        norm_root = path_mod.normpath(str(root).strip())
        if self._write_install_root_to_config(norm_root):
            logger.info(f"{TAG} Install folder changed to {norm_root} (saved in config.json)")
            return True
        return False

    def get_enabled_stores(self) -> list[str]:
        """Return enabled store source IDs from config.json (defaults to Online-Fix, FitGirl, SteamRIP)."""
        cfg = self._read_config_dict()
        return normalize_enabled_stores(cfg.get("enabled_game_stores"))

    def save_enabled_stores(self, stores: list[str] | tuple[str, ...]) -> list[str]:
        """Validate (requiring >=1 valid store) and persist enabled_game_stores into config.json."""
        chosen = (
            {str(x).strip().lower() for x in stores if x}
            if isinstance(stores, (list, tuple, set))
            else set()
        )
        valid = [s for s in ALL_STORE_SOURCES if s in chosen]
        if not valid:
            fallback = self.get_enabled_stores()
            logger.warning(
                f"{TAG} Refused saving empty/invalid enabled_game_stores={stores!r}; keeping {fallback}"
            )
            return fallback

        raw_cfg = self._read_config_dict()
        if valid == normalize_enabled_stores(raw_cfg.get("enabled_game_stores")) and "enabled_game_stores" in raw_cfg:
            return valid

        if _is_test_env():
            path = self._test_config_path()
            raw_cfg["enabled_game_stores"] = valid
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(raw_cfg, f, indent=2, ensure_ascii=False)
                logger.info(f"{TAG} Saved enabled_game_stores={valid} to {path}")
            except OSError as e:
                logger.warning(f"{TAG} Could not save enabled_game_stores to {path}: {e}")
            return valid

        try:
            update_online_fix_config(enabled_game_stores=valid)
            logger.info(f"{TAG} Saved enabled_game_stores={valid} in config.json")
        except Exception as e:
            logger.warning(f"{TAG} Could not persist enabled_game_stores to config.json: {e}")
        return valid

    def get_task(self, task_id: str) -> Optional[DownloadTask]:
        with self._lock:
            return self.tasks.get(task_id)

    def list_tasks(self) -> List[DownloadTask]:
        with self._lock:
            return list(self.tasks.values())

    def active_count(self) -> int:
        with self._lock:
            return sum(1 for t in self.tasks.values() if t.status in ACTIVE_STATUSES)

    def create_and_start_task(
        self,
        game_title: str,
        source_url: str,
        install_target_root: str,
        delete_archive: bool = True,
        auto_extract: bool = True,
        archive_password: Optional[str] = None,
        referer: str = "",
        poster_url: str = "",
        source: str = SOURCE_ONLINE_FIX,
    ) -> DownloadTask:
        """
        Create and trigger download & extraction workflow for a game.
        """
        task_id = str(uuid.uuid4())[:8]
        safe_name = _sanitize_folder_name(game_title)
        target_install_dir = os.path.join(install_target_root, safe_name)
        temp_download_dir = target_install_dir

        default_pwd = (
            ANKERGAMES_ARCHIVE_PASSWORD if source in (SOURCE_FITGIRL, SOURCE_ANKERGAMES)
            else STEAMRIP_ARCHIVE_PASSWORD if source == SOURCE_STEAMRIP
            else DEFAULT_ARCHIVE_PASSWORD
        )
        task = DownloadTask(
            task_id=task_id,
            game_title=game_title,
            source_url=source_url,
            target_install_dir=target_install_dir,
            download_temp_dir=temp_download_dir,
            status=TaskStatus.PREPARING,
            delete_archive_after_extract=delete_archive,
            auto_extract=auto_extract,
            archive_password=(
                default_pwd if archive_password is None
                else (
                    archive_password
                    if source in (SOURCE_FITGIRL, SOURCE_ANKERGAMES)
                    else (archive_password or default_pwd)
                )
            ),
            referer=referer,
            poster_url=poster_url,
            source=source or SOURCE_ONLINE_FIX,
        )

        with self._lock:
            self.tasks[task_id] = task
            self._started_at[task_id] = time.monotonic()
            self._last_saved_pct[task_id] = 0.0
            self._last_saved_time[task_id] = time.monotonic()
        self._save_tasks_to_config()
        logger.info(f"{TAG} Task {task_id} created for {game_title!r} ({task.source}): target={target_install_dir}, "
                    f"auto_extract={auto_extract}, delete_archive={delete_archive}")
        self.task_added.emit(task)

        threading.Thread(target=self._prepare_and_download, args=(task,), daemon=True,
                         name=f"onlinefix-{task_id}").start()
        return task

    def _is_cancelled(self, task: DownloadTask) -> bool:
        with self._lock:
            return task.status in (TaskStatus.CANCELLED, TaskStatus.PAUSED)

    def _find_reusable_temp_dir(self, task: DownloadTask) -> Optional[str]:
        """Return an existing folder for the same game that already has a complete FitGirl setup.exe + .bin."""
        from app.core.online_fix.extractor import find_fitgirl_setup

        safe_name = _sanitize_folder_name(task.game_title).lower()
        safe_prefix = safe_name + "_"
        with self._lock:
            busy_dirs = {
                os.path.normcase(os.path.abspath(t.download_temp_dir))
                for tid, t in self.tasks.items()
                if tid != task.task_id and t.status in ACTIVE_STATUSES
            }

        candidates: list[str] = []
        if os.path.isdir(task.target_install_dir):
            candidates.append(task.target_install_dir)
        parent_root = os.path.dirname(task.target_install_dir)
        if parent_root and os.path.isdir(parent_root):
            try:
                for entry in os.listdir(parent_root):
                    low = entry.lower()
                    if low == safe_name or low.startswith(safe_prefix):
                        cand = os.path.join(parent_root, entry)
                        if os.path.isdir(cand) and cand not in candidates:
                            candidates.append(cand)
            except OSError:
                pass

        for cand in candidates:
            if os.path.normcase(os.path.abspath(cand)) in busy_dirs:
                continue
            has_aria2 = any(
                fn.lower().endswith(".aria2")
                for _, _, files in os.walk(cand)
                for fn in files
            )
            setup_path = find_fitgirl_setup(cand)
            if has_aria2 or not setup_path:
                continue
            try:
                with open(setup_path, "rb") as sf:
                    if sf.read(2) != b"MZ":
                        continue
                bin_files = [
                    os.path.join(r, fn)
                    for r, _, files in os.walk(cand)
                    for fn in files
                    if fn.lower().endswith(".bin") and not (fn.lower().startswith("fg-optional-") and "english" not in fn.lower())
                ]
                if not bin_files:
                    continue
                valid_bins = True
                for bf in bin_files:
                    with open(bf, "rb") as f:
                        if f.read(4) != b"ArC\x01":
                            valid_bins = False
                            break
                if valid_bins:
                    return cand
            except OSError:
                continue
        return None

    @staticmethod
    def _find_saved_local_torrent(download_dir: str) -> Optional[str]:
        """Return path to an already downloaded .torrent file in download_dir if valid."""
        if not os.path.isdir(download_dir):
            return None
        try:
            for fn in os.listdir(download_dir):
                if fn.lower().endswith(".torrent"):
                    p = os.path.join(download_dir, fn)
                    if os.path.isfile(p) and os.path.getsize(p) > 50:
                        with open(p, "rb") as f:
                            if f.read(1) == b"d":
                                return p
        except OSError:
            pass
        return None

    def _prepare_and_download(self, task: DownloadTask):
        task_id = task.task_id
        try:
            reusable_dir = self._find_reusable_temp_dir(task)
            if reusable_dir:
                logger.info(f"{TAG} Task {task_id}: reusing already downloaded repack in {reusable_dir}")
                os.makedirs(task.download_temp_dir, exist_ok=True)
                if os.path.normcase(os.path.abspath(reusable_dir)) != os.path.normcase(os.path.abspath(task.download_temp_dir)):
                    for item in os.listdir(reusable_dir):
                        dst = os.path.join(task.download_temp_dir, item)
                        if os.path.exists(dst):
                            if os.path.isdir(dst):
                                shutil.rmtree(dst, ignore_errors=True)
                            else:
                                os.remove(dst)
                        shutil.move(os.path.join(reusable_dir, item), dst)
                    shutil.rmtree(reusable_dir, ignore_errors=True)
                files = [
                    os.path.join(r, fn)
                    for r, _, fns in os.walk(task.download_temp_dir)
                    for fn in fns
                ]
                self._on_download_completed(task_id, files)
                return

            saved_torrent = self._find_saved_local_torrent(task.download_temp_dir)
            if saved_torrent and not task.source_url.startswith(("fitgirl-direct:", "steamrip-", "ankergames-")):
                final_source = saved_torrent
                logger.info(f"{TAG} Task {task_id}: reusing local torrent file {saved_torrent}")
            else:
                if task.source == SOURCE_FITGIRL:
                    active_client = self.fitgirl_client
                elif task.source == SOURCE_ANKERGAMES:
                    active_client = self.ankergames_client
                elif task.source == SOURCE_STEAMRIP:
                    active_client = self.steamrip_client
                else:
                    active_client = self.client
                resolved = active_client.resolve_torrent_download(task.source_url, referer=task.referer)
                if self._is_cancelled(task):
                    if task.status == TaskStatus.CANCELLED:
                        self._cleanup_task_files(task)
                    return

                final_source = resolved
                if resolved.startswith("aria2-list:"):
                    os.makedirs(task.download_temp_dir, exist_ok=True)
                    items = json.loads(resolved[len("aria2-list:"):])
                    input_file = os.path.join(task.download_temp_dir, "aria2_urls.txt")
                    pending_count = 0
                    done_count = 0
                    total_size_sum = 0
                    done_size_sum = 0
                    with open(input_file, "w", encoding="utf-8") as f:
                        for item in items:
                            out_name = item.get("out")
                            part_size = int(item.get("size") or 0)
                            if out_name:
                                out_path = os.path.join(task.download_temp_dir, out_name)
                                if (
                                    os.path.isfile(out_path)
                                    and os.path.getsize(out_path) > 1024 * 1024
                                    and not os.path.exists(out_path + ".aria2")
                                ):
                                    actual_sz = os.path.getsize(out_path)
                                    f.write(f"# completed: {out_name}\t{actual_sz}\n")
                                    done_count += 1
                                    done_size_sum += actual_sz
                                    total_size_sum += actual_sz or part_size
                                    continue
                            if part_size > 0:
                                f.write(f"# size: {part_size}\n")
                                total_size_sum += part_size
                            f.write(f"{item['url']}\n")
                            if out_name:
                                f.write(f"  out={out_name}\n")
                            for hdr in item.get("headers") or ():
                                if hdr:
                                    f.write(f"  header={hdr}\n")
                            pending_count += 1
                    if total_size_sum > 0:
                        task.total_bytes = total_size_sum
                    if done_size_sum > 0:
                        task.downloaded_bytes = max(task.downloaded_bytes, done_size_sum)
                    if pending_count == 0 and done_count > 0:
                        try:
                            os.remove(input_file)
                        except OSError:
                            pass
                        files = [
                            os.path.join(r, fn)
                            for r, _, fns in os.walk(task.download_temp_dir)
                            for fn in fns
                            if not fn.lower().endswith((".aria2", ".torrent", ".txt"))
                        ]
                        self._on_download_completed(task_id, files)
                        return
                    final_source = f"list:{input_file}"
                    logger.info(
                        f"{TAG} Task {task_id}: prepared direct CDN list "
                        f"({pending_count} remaining, {done_count} already completed out of {len(items)} part(s))"
                    )
                elif resolved.startswith("http"):
                    # Fetch the .torrent ourselves: the file server wants the Referer / cookies aria2c would not send.
                    os.makedirs(task.download_temp_dir, exist_ok=True)
                    local_torrent = os.path.join(task.download_temp_dir, "game.torrent")
                    resp = active_client.session.get(resolved, timeout=20, headers={"Referer": task.referer or resolved})
                    if resp.status_code != 200 or not resp.content.startswith(b"d"):
                        if task.source_url.startswith("magnet:?"):
                            logger.warning(f"{TAG} Task {task_id}: cached .torrent HTTP {resp.status_code}, falling back to magnet URI")
                            final_source = task.source_url
                        else:
                            logger.warning(f"{TAG} Task {task_id}: .torrent fetch returned HTTP {resp.status_code}, "
                                           f"{len(resp.content)} bytes (not a torrent)")
                            raise OnlineFixError(f"Không tải được tệp .torrent (HTTP {resp.status_code}).")
                    else:
                        with open(local_torrent, "wb") as f:
                            f.write(resp.content)
                        final_source = local_torrent
                        logger.info(f"{TAG} Task {task_id}: .torrent saved ({len(resp.content)} bytes)")

            downloader = Aria2Downloader(
                source=final_source,
                download_dir=task.download_temp_dir,
                on_progress=lambda pct, spd, done, eta: self._on_download_progress(task_id, pct, spd, done, eta),
                on_completed=lambda files: self._on_download_completed(task_id, files),
                on_error=lambda err: self._on_download_error(task_id, err),
            )
            downloader.initial_percent = float(task.progress_percent or 0.0)
            with self._lock:
                if task.status in (TaskStatus.CANCELLED, TaskStatus.PAUSED):
                    logger.info(f"{TAG} Task {task_id} stopped before the download started")
                    is_cancelled = task.status == TaskStatus.CANCELLED
                else:
                    is_cancelled = False
                    task.status = TaskStatus.DOWNLOADING
                    self._active_downloaders[task_id] = downloader
            if is_cancelled:
                self._cleanup_task_files(task)
                return
            if task.status == TaskStatus.PAUSED:
                return
            self._save_tasks_to_config()
            self.task_progress.emit(task_id, float(task.progress_percent or 0.0), "0 KB/s", "--:--")
            downloader.start()
        except OnlineFixError as e:
            self._on_download_error(task_id, str(e))
        except Exception as e:   # noqa: BLE001 - thread boundary: report, never raise
            logger.error(f"{TAG} Task {task_id}: unexpected error while starting the download: {e}", exc_info=True)
            self._on_download_error(task_id, f"Lỗi không mong muốn: {e}")

    def _on_download_progress(self, task_id: str, percent: float, speed: str, downloaded_str: str, eta: str):
        task = self.get_task(task_id)
        if not task or self._is_cancelled(task):
            return
        task.progress_percent = percent
        task.download_speed = speed
        task.eta = eta
        if downloaded_str and "/" in downloaded_str:
            from app.core.online_fix.aria2_downloader import parse_size_to_bytes
            d_part, t_part = downloaded_str.split("/", 1)
            done_b = parse_size_to_bytes(d_part)
            total_b = parse_size_to_bytes(t_part)
            if done_b > 0:
                task.downloaded_bytes = max(task.downloaded_bytes, done_b)
            if total_b > 0:
                task.total_bytes = max(task.total_bytes, total_b)
        now = time.monotonic()
        last_pct = self._last_saved_pct.get(task_id, -10.0)
        last_t = self._last_saved_time.get(task_id, 0.0)
        if abs(percent - last_pct) >= 1.0 or (now - last_t) >= 10.0:
            self._last_saved_pct[task_id] = percent
            self._last_saved_time[task_id] = now
            self._save_tasks_to_config()
        self.task_progress.emit(task_id, percent, speed, eta)

    def _on_download_completed(self, task_id: str, downloaded_files: list[str]):
        try:
            task = self.get_task(task_id)
            if not task or self._is_cancelled(task):
                return
            with self._lock:
                self._active_downloaders.pop(task_id, None)
            logger.info(f"{TAG} Task {task_id} download finished ({len(downloaded_files)} file(s))")

            if not task.auto_extract:
                self._complete(task, "")
                return

            with self._lock:
                task.status = TaskStatus.EXTRACTING
            task.download_speed = "--"
            is_fg = task.source == SOURCE_FITGIRL
            task.eta = "Đang cài đặt..." if is_fg else "Đang giải nén..."
            self._save_tasks_to_config()
            self.task_extracting.emit(task_id, 0.0, "Bắt đầu cài đặt ngầm..." if is_fg else "Bắt đầu giải nén...")

            extractor = GameExtractor(
                source_dir=task.download_temp_dir,
                target_dir=task.target_install_dir,
                password=task.archive_password,
                delete_archive=task.delete_archive_after_extract,
                on_progress=lambda pct, msg: self._on_extract_progress(task_id, pct, msg),
                on_completed=lambda exe_path: self._on_extract_completed(task_id, exe_path),
                on_error=lambda err: self._on_extract_error(task_id, err),
            )
            with self._lock:
                self._active_extractors[task_id] = extractor
            extractor.start(game_title=task.game_title)
        except Exception as e:   # noqa: BLE001
            logger.error(f"{TAG} Task {task_id}: could not start extraction: {e}", exc_info=True)
            self._on_extract_error(task_id, str(e))

    def _fail(self, task_id: str, message: str, log_message: str):
        task = self.get_task(task_id)
        if not task:
            return
        with self._lock:
            if task.status in (TaskStatus.CANCELLED, TaskStatus.PAUSED, TaskStatus.FAILED, TaskStatus.COMPLETED):
                return
            task.status = TaskStatus.FAILED
            task.error_message = message
            self._active_downloaders.pop(task_id, None)
            self._active_extractors.pop(task_id, None)
            elapsed = time.monotonic() - self._started_at.get(task_id, time.monotonic())
        self._save_tasks_to_config()
        logger.error(f"{TAG} Task {task_id} ({task.game_title!r}) failed after {elapsed:.1f}s: {log_message}")
        self.task_failed.emit(task_id, message)

    def _on_download_error(self, task_id: str, error_msg: str):
        self._fail(task_id, error_msg, f"download: {error_msg}")

    def _on_extract_progress(self, task_id: str, percent: float, msg: str):
        task = self.get_task(task_id)
        if not task or self._is_cancelled(task):
            return
        task.progress_percent = percent
        task.eta = msg
        self.task_extracting.emit(task_id, percent, msg)

    def _on_extract_completed(self, task_id: str, exe_path: str):
        task = self.get_task(task_id)
        if not task or self._is_cancelled(task):
            return
        self._complete(task, exe_path)

    def _complete(self, task: DownloadTask, exe_path: str):
        from app.core.online_fix.extractor import has_installed_game_payload

        if task.auto_extract and not has_installed_game_payload(task.target_install_dir):
            self._fail(
                task.task_id,
                "Cài đặt không thành công: thư mục đích trống, không có tệp dữ liệu game.",
                f"post-verify failed: empty target_install_dir={task.target_install_dir}",
            )
            return
        if not task.auto_extract:
            has_any_file = os.path.isdir(task.download_temp_dir) and any(
                fns for _, _, fns in os.walk(task.download_temp_dir)
            )
            if not has_any_file:
                self._fail(
                    task.task_id,
                    "Tải không thành công: không tìm thấy tệp nào trong thư mục tải về.",
                    f"post-verify failed: empty download_temp_dir={task.download_temp_dir}",
                )
                return

        with self._lock:
            task.status = TaskStatus.COMPLETED
            self._active_extractors.pop(task.task_id, None)
            self._active_downloaders.pop(task.task_id, None)
            elapsed = time.monotonic() - self._started_at.get(task.task_id, time.monotonic())
        task.progress_percent = 100.0
        task.download_speed = "Xong"
        task.eta = "Hoàn tất"
        task.extracted_exe_path = exe_path
        self._save_tasks_to_config()
        logger.info(f"{TAG} Task {task.task_id} ({task.game_title!r}) completed in {elapsed:.1f}s. "
                    f"Exe: {exe_path or '(not found)'}")
        self.task_completed.emit(task.task_id, exe_path)

    def _on_extract_error(self, task_id: str, error_msg: str):
        self._fail(task_id, f"Lỗi giải nén: {error_msg}", f"extract: {error_msg}")

    def pause_task(self, task_id: str, reason: str = "user") -> bool:
        """Pause an active download task so it can be resumed later (even across PC restarts)."""
        with self._lock:
            task = self.tasks.get(task_id)
            if not task or task.status not in ACTIVE_STATUSES:
                return False
            task.status = TaskStatus.PAUSED
            task.download_speed = ""
            task.eta = "Đã tạm dừng — bấm Tiếp tục để tải tiếp"
            downloader = self._active_downloaders.pop(task_id, None)
            extractor = self._active_extractors.pop(task_id, None)
        logger.info(f"{TAG} Pausing task {task_id} ({task.game_title!r}, reason={reason}) at {task.progress_percent:.1f}%")
        if downloader is not None:
            try:
                if hasattr(downloader, "pause"):
                    downloader.pause()
                else:
                    downloader.cancel()
            except Exception as e:   # noqa: BLE001
                logger.warning(f"{TAG} Task {task_id}: error while pausing downloader: {e}")
        if extractor is not None:
            try:
                extractor.cancel()
            except Exception as e:   # noqa: BLE001
                logger.warning(f"{TAG} Task {task_id}: error while stopping extractor on pause: {e}")
        self._save_tasks_to_config()
        self.task_paused.emit(task_id)
        return True

    def resume_task(self, task_id: str) -> bool:
        """Resume a paused, interrupted, failed, or cancelled download task from its existing files on disk."""
        with self._lock:
            task = self.tasks.get(task_id)
            if not task or task.status in ACTIVE_STATUSES or task.status == TaskStatus.COMPLETED:
                return False
            task.status = TaskStatus.PREPARING
            task.error_message = ""
            task.download_speed = "0 KB/s"
            task.eta = "Đang tiếp tục..."
            self._started_at[task_id] = time.monotonic()
        self._save_tasks_to_config()
        logger.info(f"{TAG} Resuming task {task_id} ({task.game_title!r}) from {task.progress_percent:.1f}%")
        self.task_resumed.emit(task_id)
        self.task_progress.emit(task_id, float(task.progress_percent or 0.0), "0 KB/s", "--:--")
        threading.Thread(
            target=self._prepare_and_download,
            args=(task,),
            daemon=True,
            name=f"onlinefix-resume-{task_id}",
        ).start()
        return True

    def _cleanup_task_files(self, task: DownloadTask):
        """Delete partially downloaded files and the task directory when a download is cancelled or removed incomplete."""
        from app.core.online_fix.extractor import is_protected_tool

        install_root_norm = os.path.normcase(os.path.abspath(self.get_install_root()))
        with self._lock:
            other_dirs = {
                os.path.normcase(os.path.abspath(d))
                for tid, t in self.tasks.items()
                if tid != task.task_id and t.status != TaskStatus.CANCELLED
                for d in (t.download_temp_dir, t.target_install_dir)
                if d
            }

        candidate_dirs: list[str] = []
        for raw_dir in (task.download_temp_dir, task.target_install_dir):
            if not raw_dir or not os.path.isabs(raw_dir):
                continue
            abs_dir = os.path.abspath(raw_dir)
            norm_dir = os.path.normcase(abs_dir)
            if os.path.dirname(abs_dir) == abs_dir or norm_dir == install_root_norm:
                continue
            if norm_dir in other_dirs:
                continue
            if all(os.path.normcase(c) != norm_dir for c in candidate_dirs):
                candidate_dirs.append(abs_dir)

        def _force_remove_readonly(func, path, _exc_info):
            try:
                os.chmod(path, 0o666)
                func(path)
            except OSError:
                pass

        for target_dir in candidate_dirs:
            if not os.path.exists(target_dir):
                continue
            has_protected = False
            try:
                for _, _, files in os.walk(target_dir):
                    if any(is_protected_tool(f) for f in files):
                        has_protected = True
                        break
            except OSError:
                pass

            if has_protected:
                removed = 0
                for entry in os.listdir(target_dir):
                    if is_protected_tool(entry):
                        continue
                    full_p = os.path.join(target_dir, entry)
                    try:
                        if os.path.isdir(full_p):
                            shutil.rmtree(full_p, onerror=_force_remove_readonly)
                        else:
                            os.chmod(full_p, 0o666)
                            os.remove(full_p)
                        removed += 1
                    except OSError as e:
                        logger.warning(f"{TAG} Task {task.task_id}: could not remove {full_p}: {e}")
                logger.info(f"{TAG} Task {task.task_id}: cleaned {removed} item(s) in {target_dir} (preserved protected tools)")
                continue

            for attempt in range(6):
                if not os.path.exists(target_dir):
                    break
                try:
                    shutil.rmtree(target_dir, onerror=_force_remove_readonly)
                except OSError:
                    pass
                if os.path.exists(target_dir) and attempt < 5:
                    time.sleep(0.15)

            if not os.path.exists(target_dir):
                logger.info(f"{TAG} Task {task.task_id}: deleted cancelled download folder {target_dir}")
            else:
                logger.warning(f"{TAG} Task {task.task_id}: folder {target_dir} could not be completely removed")

    def cancel_task(self, task_id: str):
        """Cancel an ongoing or paused download/extraction and delete its downloaded files + folder."""
        with self._lock:
            task = self.tasks.get(task_id)
            if not task or (task.status not in ACTIVE_STATUSES and task.status != TaskStatus.PAUSED):
                return
            task.status = TaskStatus.CANCELLED
            task.progress_percent = 0.0
            task.downloaded_bytes = 0
            task.download_speed = ""
            task.eta = ""
            downloader = self._active_downloaders.pop(task_id, None)
            extractor = self._active_extractors.pop(task_id, None)
        logger.info(f"{TAG} Cancelling task {task_id} ({task.game_title!r}) and deleting downloaded files")
        for worker in (downloader, extractor):
            if worker is not None:
                try:
                    worker.cancel()
                except Exception as e:   # noqa: BLE001
                    logger.warning(f"{TAG} Task {task_id}: error while stopping {worker.__class__.__name__}: {e}")
        self._cleanup_task_files(task)
        self._save_tasks_to_config()
        self.task_cancelled.emit(task_id)

    def remove_task(self, task_id: str):
        """Remove a paused / finished / failed / cancelled task from the list (deletes incomplete files if not completed)."""
        with self._lock:
            task = self.tasks.get(task_id)
            if not task or task.status in ACTIVE_STATUSES:
                return
            should_cleanup = task.status != TaskStatus.COMPLETED
            del self.tasks[task_id]
            self._started_at.pop(task_id, None)
            self._last_saved_pct.pop(task_id, None)
            self._last_saved_time.pop(task_id, None)
        if should_cleanup:
            self._cleanup_task_files(task)
        self._save_tasks_to_config()
        logger.info(f"{TAG} Task {task_id} removed from the list")
        self.tasks_removed.emit([task_id])

    def clear_completed_tasks(self) -> list[str]:
        """Remove all completed/installed tasks from the download list (keeps installed game files intact)."""
        with self._lock:
            removed_ids = [tid for tid, t in self.tasks.items() if t.status == TaskStatus.COMPLETED]
            if not removed_ids:
                return []
            for tid in removed_ids:
                del self.tasks[tid]
                self._started_at.pop(tid, None)
                self._last_saved_pct.pop(tid, None)
                self._last_saved_time.pop(tid, None)
        self._save_tasks_to_config()
        logger.info(f"{TAG} Cleared {len(removed_ids)} completed task(s) from the list")
        self.tasks_removed.emit(removed_ids)
        return removed_ids

    def shutdown(self):
        """Pause every running aria2c / 7z process and persist queue state on app exit."""
        with self._lock:
            active = [t.task_id for t in self.tasks.values() if t.status in ACTIVE_STATUSES]
        if active:
            logger.info(f"{TAG} Shutting down: pausing {len(active)} active task(s) for later resume")
        for task_id in active:
            self.pause_task(task_id, reason="app shutdown")
        self._save_tasks_to_config()


# Global singleton instance
_manager_instance: Optional[OnlineFixManager] = None
_manager_lock = threading.Lock()


def get_online_fix_manager() -> OnlineFixManager:
    global _manager_instance
    with _manager_lock:
        if _manager_instance is None:
            _manager_instance = OnlineFixManager()
            try:
                from PySide6.QtWidgets import QApplication
                app = QApplication.instance()
                if app is not None:
                    app.aboutToQuit.connect(_manager_instance.shutdown)
            except Exception as e:   # noqa: BLE001
                logger.warning(f"{TAG} Could not hook app shutdown: {e}")
    return _manager_instance
