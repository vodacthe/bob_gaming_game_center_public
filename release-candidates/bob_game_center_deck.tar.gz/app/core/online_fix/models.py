"""
Data models for Online-Fix store, search, download tasks, and extraction.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
import re
import unicodedata

DEFAULT_ARCHIVE_PASSWORD = "online-fix.me"
STEAMRIP_ARCHIVE_PASSWORD = "steamrip.com"
ANKERGAMES_ARCHIVE_PASSWORD = ""

# Game / Task source site
SOURCE_ONLINE_FIX = "online_fix"
SOURCE_ANKERGAMES = "ankergames"
SOURCE_FITGIRL = "fitgirl"
SOURCE_STEAMRIP = "steamrip"
PROVIDER_PRIORITY: tuple[str, ...] = (
    SOURCE_ONLINE_FIX,
    SOURCE_ANKERGAMES,
    SOURCE_STEAMRIP,
    SOURCE_FITGIRL,
)
ALL_STORE_SOURCES: tuple[str, ...] = (
    SOURCE_ONLINE_FIX,
    SOURCE_FITGIRL,
    SOURCE_STEAMRIP,
    SOURCE_ANKERGAMES,
)
DEFAULT_ENABLED_STORES: tuple[str, ...] = (
    SOURCE_ONLINE_FIX,
    SOURCE_FITGIRL,
    SOURCE_STEAMRIP,
)


def normalize_enabled_stores(raw) -> list[str]:
    """Return canonical list of enabled store IDs; defaults to OF/FG/SR and guarantees >=1 store."""
    if raw is None or not isinstance(raw, (list, tuple, set)):
        return list(DEFAULT_ENABLED_STORES)
    chosen = {str(x).strip().lower() for x in raw if x}
    ordered = [s for s in ALL_STORE_SOURCES if s in chosen]
    return ordered if ordered else list(DEFAULT_ENABLED_STORES)

_RU_MONTHS = {
    "января": 1, "февраля": 2, "марта": 3, "апреля": 4,
    "мая": 5, "июня": 6, "июля": 7, "августа": 8,
    "сентября": 9, "октября": 10, "ноября": 11, "декабря": 12,
}
_EN_MONTHS = {
    "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3,
    "apr": 4, "april": 4, "may": 5, "jun": 6, "june": 6,
    "jul": 7, "july": 7, "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
}
_DMY_RE = re.compile(
    r"(?<!\d)(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})(?:\s*,?\s*(\d{1,2}):(\d{2})(?::(\d{2}))?)?(?!\d)"
)
_RU_DATE_RE = re.compile(
    r"(?<!\d)(\d{1,2})\s+([а-яё]+)\s+(\d{4})(?:\s*,?\s*(\d{1,2}):(\d{2}))?",
    re.IGNORECASE,
)
_EN_MDY_RE = re.compile(
    r"\b([A-Za-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})(?:\s*,?\s*(\d{1,2}):(\d{2}))?\b"
)
_EN_DMY_RE = re.compile(
    r"(?<!\d)(\d{1,2})\s+([A-Za-z]{3,9})\.?,?\s+(\d{4})(?:\s*,?\s*(\d{1,2}):(\d{2}))?\b"
)
_REL_DAY_RE = re.compile(
    r"\b(сегодня|вчера|hôm\s+nay|hôm\s+qua|today|yesterday)\b(?:\s*,?\s*(\d{1,2}):(\d{2}))?",
    re.IGNORECASE,
)


def _safe_utc_ts(year: int, month: int, day: int, hour: int = 0, minute: int = 0, second: int = 0) -> float:
    try:
        return datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc).timestamp()
    except ValueError:
        return 0.0


def parse_store_date_ts(text: str) -> float:
    """Parse ISO-8601, DD/MM/YYYY, DD-MM-YYYY, Russian, Vietnamese, or English store date into UTC epoch."""
    raw = (text or "").strip()
    if not raw:
        return 0.0

    if re.match(r"^\d{4}-\d{2}-\d{2}", raw):
        iso_str = raw[:-1] + "+00:00" if raw.endswith(("Z", "z")) else raw
        try:
            dt = datetime.fromisoformat(iso_str)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except ValueError:
            m_ymd = re.match(r"^(\d{4})-(\d{2})-(\d{2})", raw)
            if m_ymd:
                return _safe_utc_ts(int(m_ymd.group(1)), int(m_ymd.group(2)), int(m_ymd.group(3)))

    m_rel = _REL_DAY_RE.search(raw)
    if m_rel:
        word = re.sub(r"\s+", " ", m_rel.group(1).lower())
        hh = int(m_rel.group(2) or 0)
        mm = int(m_rel.group(3) or 0)
        now_utc = datetime.now(timezone.utc)
        base = now_utc - timedelta(days=1) if word in ("вчера", "hôm qua", "yesterday") else now_utc
        return _safe_utc_ts(base.year, base.month, base.day, hh, mm)

    m_dmy = _DMY_RE.search(raw)
    if m_dmy:
        return _safe_utc_ts(
            int(m_dmy.group(3)),
            int(m_dmy.group(2)),
            int(m_dmy.group(1)),
            int(m_dmy.group(4) or 0),
            int(m_dmy.group(5) or 0),
            int(m_dmy.group(6) or 0),
        )

    m_ru = _RU_DATE_RE.search(raw)
    if m_ru:
        mon = _RU_MONTHS.get(m_ru.group(2).lower())
        if mon:
            return _safe_utc_ts(
                int(m_ru.group(3)), mon, int(m_ru.group(1)),
                int(m_ru.group(4) or 0), int(m_ru.group(5) or 0),
            )

    m_en_mdy = _EN_MDY_RE.search(raw)
    if m_en_mdy:
        mon = _EN_MONTHS.get(m_en_mdy.group(1).lower())
        if mon:
            return _safe_utc_ts(
                int(m_en_mdy.group(3)), mon, int(m_en_mdy.group(2)),
                int(m_en_mdy.group(4) or 0), int(m_en_mdy.group(5) or 0),
            )
    m_en_dmy = _EN_DMY_RE.search(raw)
    if m_en_dmy:
        mon = _EN_MONTHS.get(m_en_dmy.group(2).lower())
        if mon:
            return _safe_utc_ts(
                int(m_en_dmy.group(3)), mon, int(m_en_dmy.group(1)),
                int(m_en_dmy.group(4) or 0), int(m_en_dmy.group(5) or 0),
            )

    return 0.0


def extract_update_ts(update_info: str) -> float:
    """Extract an update timestamp from Online-Fix / store update banners when present."""
    raw = (update_info or "").strip()
    if not raw:
        return 0.0
    low = raw.lower()
    if "обновлено" in low or "cập nhật" in low:
        first_clause = re.split(r"(?:\.\s+|·|\||;)", raw, maxsplit=1)[0]
        return parse_store_date_ts(first_clause)
    return 0.0


def format_ts_ddmmyyyy(ts: float) -> str:
    """Format a UTC timestamp as DD/MM/YYYY (empty string if non-positive)."""
    if not ts or ts <= 0:
        return ""
    try:
        return datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime("%d/%m/%Y")
    except (OSError, OverflowError, ValueError):
        return ""


_EXCLUDED_TITLE_RE = re.compile(
    r"\b(?:"
    r"dayz(?:avr)?|"
    r"gameranger|"
    r"radmin\s*vpn|"
    r"(?:logmein\s+)?hamachi|"
    r"zerotier|"
    r"tunngle|"
    r"steam\s+remote\s+play|"
    r"gog\s+galaxy|"
    r"microsoft\s+store|"
    r"epic\s+games\s+store"
    r")\b",
    re.IGNORECASE,
)
_EXCLUDED_URL_SUBSTRINGS: tuple[str, ...] = (
    "dayz",
    "gameranger",
    "/programs/",
    "/guides/",
    "/hypervisor-guide",
)
_HYPERVISOR_MARKER_RE = re.compile(
    r"(?:\bhypervisor\b|[\[(]\s*hv\s*[\])])",
    re.IGNORECASE,
)


def has_hypervisor_marker(text: str) -> bool:
    """Return True when a game title or release header explicitly marks a Hypervisor (HV) bypass build."""
    return bool(_HYPERVISOR_MARKER_RE.search(text or ""))
_SEARCH_ROMAN_MAP = {
    "ii": "2", "iii": "3", "iv": "4", "v": "5",
    "vi": "6", "vii": "7", "viii": "8", "ix": "9", "x": "10",
}
_SEARCH_TOKEN_RE = re.compile(r"[a-z0-9\u0400-\u04ff]+")
_SLUG_PREFIX_RE = re.compile(r"^\d+-")
_SLUG_SUFFIX_RE = re.compile(r"(?:-po-seti|-online|-free-download)?\.html?$", re.IGNORECASE)


def is_excluded_game(title: str, url: str = "") -> bool:
    """Return True if the item is non-game software/guide or an excluded promo (e.g. DayZ, GameRanger, /programs/)."""
    if _EXCLUDED_TITLE_RE.search(title or ""):
        return True
    low_url = (url or "").lower()
    if any(sub in low_url for sub in _EXCLUDED_URL_SUBSTRINGS):
        return True
    return False


def _fold_search_text(text: str) -> str:
    folded = re.sub(r"['’]s\b", "s", (text or "").lower().replace("đ", "d"))
    norm = unicodedata.normalize("NFKD", folded)
    return "".join(ch for ch in norm if not unicodedata.combining(ch))


_CLEAN_SEARCH_SUFFIX_RE = re.compile(
    r"\s*(?:[,–—\-:|/]+\s*(?:v?\d+(?:\.\d+)+[a-z0-9.\-_]*|build\s*\d+|free\s+download|online|по\s+сети).*|\+\s*bonus.*)$",
    re.IGNORECASE,
)


def _tokenize_search(text: str) -> list[str]:
    raw = _SEARCH_TOKEN_RE.findall(_fold_search_text(text))
    collapsed: list[str] = []
    i = 0
    n = len(raw)
    while i < n:
        if len(raw[i]) == 1 and raw[i].isalpha():
            j = i + 1
            while j < n and len(raw[j]) == 1 and raw[j].isalpha():
                j += 1
            if j - i >= 2:
                collapsed.append("".join(raw[i:j]))
                i = j
                continue
        collapsed.append(raw[i])
        i += 1
    return [_SEARCH_ROMAN_MAP.get(t, t) for t in collapsed]


def dotted_acronym_query(query: str) -> str:
    """Return 'R.E.P.O.' for 3..7-letter single-word ASCII queries (e.g. 'REPO') so store title search finds dotted titles."""
    q = (query or "").strip()
    if re.fullmatch(r"[A-Za-z]{3,7}", q):
        return ".".join(q.upper()) + "."
    return ""


def _build_search_candidates(title: str, url: str = "") -> tuple[list[str], set[str]]:
    base_title = _CLEAN_SEARCH_SUFFIX_RE.sub("", title or "").strip() or (title or "")
    base_tokens = _tokenize_search(base_title)
    full_tokens = _tokenize_search(title)
    slug = (url or "").rstrip("/").rsplit("/", 1)[-1]
    slug = _SLUG_SUFFIX_RE.sub("", _SLUG_PREFIX_RE.sub("", slug))
    slug_tokens = _tokenize_search(slug)

    cands: set[str] = set(base_tokens) | set(full_tokens) | set(slug_tokens)
    for seq in (base_tokens, slug_tokens):
        for idx in range(len(seq) - 1):
            if seq[idx].isalpha() and seq[idx + 1].isalpha():
                cands.add(seq[idx] + seq[idx + 1])

    if len(base_tokens) >= 2:
        cands.add("".join(t[0] for t in base_tokens if t))
        alpha_acr = "".join(t[0] for t in base_tokens if t and not t.isdigit())
        if len(alpha_acr) >= 2:
            cands.add(alpha_acr)
    head_part = re.split(r"[:–—\-|/]", base_title, maxsplit=1)[0].strip()
    head_tokens = _tokenize_search(head_part)
    if len(head_tokens) >= 2:
        cands.add("".join(t[0] for t in head_tokens if t))
        head_alpha = "".join(t[0] for t in head_tokens if t and not t.isdigit())
        if len(head_alpha) >= 2:
            cands.add(head_alpha)

    cands.discard("")
    return base_tokens, cands


def matches_search_query(query: str, title: str, url: str = "") -> bool:
    """Return True when `title` (or URL slug) genuinely matches `query` at word/acronym boundaries."""
    q_tokens = _tokenize_search(query)
    if not q_tokens:
        return True
    _, cand_tokens = _build_search_candidates(title, url)
    if not cand_tokens:
        return False

    def _token_matches(qt: str) -> bool:
        if qt.isdigit() or len(qt) <= 4:
            return qt in cand_tokens
        return qt in cand_tokens or any(ct.startswith(qt) for ct in cand_tokens)

    return all(_token_matches(qt) for qt in q_tokens)


def search_relevance_key(query: str, game: "OnlineFixGame") -> tuple[int, float]:
    """Rank search hits: 0=exact title/acronym, 1=starts with query, 2=exact words, 3=prefix/slug; newest release within tier."""
    q_tokens = _tokenize_search(query)
    pub = -game.published_ts if game.published_ts > 0 else 0.0
    if not q_tokens:
        return (0, pub)
    t_tokens, _ = _build_search_candidates(game.title, game.url)
    q_joined = " ".join(q_tokens)
    t_joined = " ".join(t_tokens)
    q_compact = "".join(q_tokens)
    t_compact = "".join(t_tokens)
    acronym = "".join(t[0] for t in t_tokens if t) if len(t_tokens) >= 2 else ""

    if t_joined == q_joined or t_compact == q_compact or (acronym and q_compact == acronym):
        tier = 0
    elif t_joined.startswith(q_joined + " ") or (len(q_compact) >= 3 and t_compact.startswith(q_compact)):
        tier = 1
    elif all(qt in t_tokens for qt in q_tokens):
        tier = 2
    else:
        tier = 3
    return (tier, pub)


def sort_games_for_search(query: str, games: list["OnlineFixGame"]) -> list["OnlineFixGame"]:
    """Sort matched search results by title relevance first, then chronologically by release date."""
    if not query or not games:
        return list(games)
    return sorted(games, key=lambda g: search_relevance_key(query, g))


# DownloadLink.kind
LINK_TORRENT = "torrent"    # uploads.online-fix.me/torrents/... (or a .torrent / magnet): Bob downloads it with aria2c
LINK_WEB = "web"            # Hosters / Drive / Mega / Yandex ...: a web page, opened in the browser


class TaskStatus(str, Enum):
    QUEUED = "queued"
    PREPARING = "preparing"
    DOWNLOADING = "downloading"
    PAUSED = "paused"
    EXTRACTING = "extracting"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


ACTIVE_STATUSES = (TaskStatus.QUEUED, TaskStatus.PREPARING, TaskStatus.DOWNLOADING, TaskStatus.EXTRACTING)


@dataclass
class OnlineFixGame:
    id: str
    title: str
    url: str
    poster_url: str = ""
    date: str = ""
    update_info: str = ""
    game_release: str = ""
    game_modes: str = ""
    archive_password: str = DEFAULT_ARCHIVE_PASSWORD
    download_links: list[dict] = field(default_factory=list)   # {"title", "url", "kind"}
    source: str = SOURCE_ONLINE_FIX
    categories: list[str] = field(default_factory=list)
    provider_poster_url: str = ""
    published_ts: float = 0.0
    updated_ts: float = 0.0
    is_hypervisor: bool = False
    providers: list["OnlineFixGame"] = field(default_factory=list, repr=False, compare=False)

    def available_sources(self) -> list[str]:
        if not self.providers:
            return [self.source or SOURCE_ONLINE_FIX]
        seen: list[str] = []
        for item in self.providers:
            src = item.source or SOURCE_ONLINE_FIX
            if src not in seen:
                seen.append(src)
        return seen or [self.source or SOURCE_ONLINE_FIX]

    def effective_update_ts(self) -> float:
        return max(float(self.updated_ts or 0.0), float(self.published_ts or 0.0))

    def __post_init__(self):
        if not self.provider_poster_url and self.poster_url:
            self.provider_poster_url = self.poster_url
        self.published_ts = float(self.published_ts or 0.0)
        if self.published_ts <= 0.0 and self.date:
            self.published_ts = parse_store_date_ts(self.date)
        self.updated_ts = float(self.updated_ts or 0.0)
        if self.updated_ts <= 0.0 and self.update_info:
            self.updated_ts = extract_update_ts(self.update_info)
        self.is_hypervisor = bool(
            self.is_hypervisor
            or has_hypervisor_marker(self.title)
            or has_hypervisor_marker(self.update_info)
        )

    def to_cache_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "url": self.url,
            "poster_url": self.poster_url,
            "provider_poster_url": self.provider_poster_url or self.poster_url,
            "date": self.date,
            "update_info": self.update_info,
            "game_release": self.game_release,
            "game_modes": self.game_modes,
            "archive_password": self.archive_password,
            "download_links": list(self.download_links or []),
            "source": self.source or SOURCE_ONLINE_FIX,
            "categories": list(self.categories or []),
            "published_ts": float(self.published_ts or 0.0),
            "updated_ts": float(self.updated_ts or 0.0),
            "is_hypervisor": bool(self.is_hypervisor),
        }

    @classmethod
    def from_cache_dict(cls, data: dict) -> "OnlineFixGame":
        src = str(data.get("source") or SOURCE_ONLINE_FIX)
        default_pwd = (
            "" if src in (SOURCE_FITGIRL, SOURCE_ANKERGAMES)
            else STEAMRIP_ARCHIVE_PASSWORD if src == SOURCE_STEAMRIP
            else DEFAULT_ARCHIVE_PASSWORD
        )
        poster = str(data.get("poster_url") or "")
        prov_poster = str(data.get("provider_poster_url") or poster)
        return cls(
            id=str(data.get("id") or ""),
            title=str(data.get("title") or ""),
            url=str(data.get("url") or ""),
            poster_url=poster,
            date=str(data.get("date") or ""),
            update_info=str(data.get("update_info") or ""),
            game_release=str(data.get("game_release") or ""),
            game_modes=str(data.get("game_modes") or ""),
            archive_password=str(data.get("archive_password", default_pwd)),
            download_links=list(data.get("download_links") or []),
            source=src,
            categories=list(data.get("categories") or []),
            provider_poster_url=prov_poster,
            published_ts=float(data.get("published_ts") or 0.0),
            updated_ts=float(data.get("updated_ts") or 0.0),
            is_hypervisor=bool(data.get("is_hypervisor", False)),
        )


@dataclass
class DownloadTask:
    task_id: str
    game_title: str
    source_url: str  # .torrent URL, local .torrent path, or magnet:?
    target_install_dir: str  # Destination folder where game is unpacked
    download_temp_dir: str  # Temp folder where aria2c downloads files
    status: TaskStatus = TaskStatus.QUEUED
    progress_percent: float = 0.0
    download_speed: str = "0 KB/s"
    eta: str = "--:--"
    downloaded_bytes: int = 0
    total_bytes: int = 0
    error_message: str = ""
    extracted_exe_path: str = ""
    delete_archive_after_extract: bool = True
    auto_extract: bool = True
    archive_password: str = DEFAULT_ARCHIVE_PASSWORD
    referer: str = ""   # game page: online-fix's file servers refuse requests without it
    poster_url: str = ""
    source: str = SOURCE_ONLINE_FIX

    def to_dict(self) -> dict:
        status_val = self.status.value if isinstance(self.status, TaskStatus) else str(self.status)
        return {
            "task_id": self.task_id,
            "game_title": self.game_title,
            "source_url": self.source_url,
            "target_install_dir": self.target_install_dir,
            "download_temp_dir": self.download_temp_dir,
            "status": status_val,
            "progress_percent": round(float(self.progress_percent or 0.0), 1),
            "download_speed": self.download_speed,
            "eta": self.eta,
            "downloaded_bytes": int(self.downloaded_bytes or 0),
            "total_bytes": int(self.total_bytes or 0),
            "error_message": self.error_message,
            "extracted_exe_path": self.extracted_exe_path,
            "delete_archive_after_extract": bool(self.delete_archive_after_extract),
            "auto_extract": bool(self.auto_extract),
            "archive_password": self.archive_password,
            "referer": self.referer,
            "poster_url": self.poster_url,
            "source": self.source or SOURCE_ONLINE_FIX,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "DownloadTask":
        raw_status = str(data.get("status", TaskStatus.PAUSED.value)).lower()
        try:
            status = TaskStatus(raw_status)
        except ValueError:
            status = TaskStatus.PAUSED
        target_dir = str(data.get("target_install_dir", ""))
        temp_dir = str(data.get("download_temp_dir", "")) or target_dir
        src = str(data.get("source", SOURCE_ONLINE_FIX) or SOURCE_ONLINE_FIX)
        default_pwd = (
            "" if src in (SOURCE_FITGIRL, SOURCE_ANKERGAMES)
            else STEAMRIP_ARCHIVE_PASSWORD if src == SOURCE_STEAMRIP
            else DEFAULT_ARCHIVE_PASSWORD
        )
        return cls(
            task_id=str(data.get("task_id", "")),
            game_title=str(data.get("game_title", "")),
            source_url=str(data.get("source_url", "")),
            target_install_dir=target_dir,
            download_temp_dir=temp_dir,
            status=status,
            progress_percent=float(data.get("progress_percent", 0.0) or 0.0),
            download_speed=str(data.get("download_speed", "")),
            eta=str(data.get("eta", "--:--")),
            downloaded_bytes=int(data.get("downloaded_bytes", 0) or 0),
            total_bytes=int(data.get("total_bytes", 0) or 0),
            error_message=str(data.get("error_message", "")),
            extracted_exe_path=str(data.get("extracted_exe_path", "")),
            delete_archive_after_extract=bool(data.get("delete_archive_after_extract", True)),
            auto_extract=bool(data.get("auto_extract", True)),
            archive_password=str(data.get("archive_password", default_pwd)),
            referer=str(data.get("referer", "")),
            poster_url=str(data.get("poster_url", "")),
            source=src,
        )
