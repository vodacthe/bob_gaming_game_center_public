"""
Persistent disk caching (Documents\\Bob Gaming\\GameCenter\\cache) and asynchronous multi-threaded
SteamGridDB + Steam Store metadata / category / 2:3 vertical poster enrichment for KHO GAME.

All network and disk I/O in StoreMetadataEnricher runs on background worker threads and delivers
plain Python dicts via queued Qt signals — never touching widgets or QPixmaps off the UI thread.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import logging
import os
import re
import sys
import tempfile
import threading
import time
from typing import Dict, Iterable, List, Optional
from urllib.parse import quote, quote_plus

from PySide6.QtCore import QObject, Signal
import requests

from app.config import CACHE_DIR, STEAMGRIDB_API_KEY, get_app_dir, load_config
from app.core.online_fix.models import (
    SOURCE_ANKERGAMES, SOURCE_FITGIRL,
    SOURCE_ONLINE_FIX,
    SOURCE_STEAMRIP,
    OnlineFixGame,
    is_excluded_game,
    matches_search_query,
)

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/StoreCache]"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

# Canonical ordered categories for KHO GAME shelves & filter chips: (slug, label_vi, svg_icon)
STORE_CATEGORIES: tuple[tuple[str, str, str], ...] = (
    ("coop", "Co-op & Online", "users"),
    ("action", "Hành động", "gamepad"),
    ("rpg", "Nhập vai (RPG)", "shield"),
    ("adventure", "Phiêu lưu", "globe"),
    ("horror", "Kinh dị & Sinh tồn", "alert"),
    ("sports_racing", "Đua xe & Thể thao", "controller"),
    ("strategy_sim", "Chiến thuật & Mô phỏng", "sliders"),
    ("indie", "Indie & Giải trí", "star"),
    ("other", "Thể loại khác", "package"),
)

CATEGORY_LABELS: dict[str, str] = {slug: label for slug, label, _ in STORE_CATEGORIES}
CATEGORY_ICONS: dict[str, str] = {slug: icon for slug, _, icon in STORE_CATEGORIES}

CACHE_SCHEMA_VERSION = 3
CATALOG_CACHE_VERSION = 4
METADATA_HIT_TTL_SEC = 14 * 24 * 3600
METADATA_MISS_TTL_SEC = 24 * 3600
CATALOG_MAX_AGE_SEC = 7 * 24 * 3600

_CLEAN_ONLINE_RE = re.compile(
    r"(?:[\s\-_–—:/|]+[\(\[]*|[\(\[])(?:по\s+сети|online|онлайн|co-?op|multiplayer|free\s+download)[\s\)\]]*$",
    re.IGNORECASE,
)
_CLEAN_VER_DLC_RE = re.compile(
    r"\s*(?:[-–—:|/]+\s*)?(?:v?\d+(?:\.\d+)+[a-z0-9.\-_]*|build\s*\d+)(?:\s*\+.*)?$",
    re.IGNORECASE,
)
_CLEAN_EDITION_RE = re.compile(
    r"\s*[:\-–—|/]\s*(?:(?:super|digital|ultimate|complete|deluxe|supporter|collector'?s|definitive|enhanced|"
    r"gold|standard|anniversary|goty|game\s+of\s+the\s+year|devout|absolute|master\s+collection)\s+"
    r"(?:deluxe\s+)?(?:edition|version|pack(?:\s+bundle)?|bundle)|game\s*\+\s*soundtrack\s+bundle)\s*$",
    re.IGNORECASE,
)
_CLEAN_PARENS_RE = re.compile(r"\s*[\(\[][^)\]]*[\)\]]\s*$")
_ROMAN_TOKEN_MAP = {
    "ii": "2", "iii": "3", "iv": "4", "v": "5",
    "vi": "6", "vii": "7", "viii": "8", "ix": "9", "x": "10",
}
_NON_ALNUM_RE = re.compile(r"[^a-z0-9]+")


def _resolve_test_app_dir() -> str:
    repo_dir = os.path.normcase(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
    candidates = [get_app_dir()]
    try:
        from app.core.online_fix import client as client_mod
        candidates.append(client_mod.get_app_dir())
    except Exception:   # noqa: BLE001
        pass
    for cand in candidates:
        if cand and os.path.normcase(os.path.abspath(cand)) != repo_dir:
            return cand
    test_id = os.environ.get("PYTEST_CURRENT_TEST", "pytest")
    digest = hashlib.md5(test_id.encode("utf-8", errors="ignore")).hexdigest()[:12]
    return os.path.join(tempfile.gettempdir(), "bob_pytest_store_cache", digest)


def _is_test_env() -> bool:
    if "PYTEST_CURRENT_TEST" in os.environ:
        return True
    if getattr(sys, "frozen", False):
        return False
    repo_dir = os.path.normcase(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
    if os.path.normcase(os.path.abspath(get_app_dir())) != repo_dir:
        return True
    try:
        from app.core.online_fix import client as client_mod
        if os.path.normcase(os.path.abspath(client_mod.get_app_dir())) != repo_dir:
            return True
    except Exception:   # noqa: BLE001
        pass
    return False


def get_store_cache_dir() -> str:
    """Return cache directory inside Documents\\Bob Gaming\\GameCenter\\cache (or isolated test dir in pytest)."""
    if _is_test_env():
        return os.path.join(_resolve_test_app_dir(), "cache")
    return CACHE_DIR


def get_poster_disk_cache_dir() -> str:
    return os.path.join(get_store_cache_dir(), "store_posters")


def get_catalog_cache_path() -> str:
    return os.path.join(get_store_cache_dir(), "store_catalog_cache.json")


def get_metadata_cache_path() -> str:
    return os.path.join(get_store_cache_dir(), "store_metadata_cache.json")


def clean_lookup_title(title: str) -> str:
    """Clean store suffixes so SteamGridDB and Steam Store find the canonical game."""
    clean = (title or "").strip()
    for _ in range(4):
        nxt = _CLEAN_PARENS_RE.sub("", _CLEAN_VER_DLC_RE.sub("", _CLEAN_ONLINE_RE.sub("", clean))).strip().rstrip(".-_:/|–— ")
        if not nxt or nxt == clean:
            break
        clean = nxt
    return clean or (title or "").strip()


def _normalized_token_key(text: str) -> str:
    low = (text or "").lower().replace("&", " and ")
    tokens = [
        _ROMAN_TOKEN_MAP.get(tok, tok)
        for tok in _NON_ALNUM_RE.split(low)
        if tok
    ]
    return "".join(tokens)


def _title_match_keys(title: str) -> set[str]:
    base = clean_lookup_title(title)
    keys = {_normalized_token_key(base)}
    stripped_ed = _CLEAN_EDITION_RE.sub("", base).strip().rstrip(".-_:/|–— ")
    if stripped_ed and stripped_ed != base:
        keys.add(_normalized_token_key(stripped_ed))
    keys.discard("")
    return keys


def titles_match_strict(query_title: str, candidate_title: str) -> bool:
    """True only when query and candidate refer to the same game title (never loose prefix/autocomplete matches)."""
    q_keys = _title_match_keys(query_title)
    c_keys = _title_match_keys(candidate_title)
    return bool(q_keys and c_keys and (q_keys & c_keys))


def normalize_game_cache_key(title: str) -> str:
    """Canonical lowercase alphanumeric cache key for cross-store metadata lookup."""
    cleaned = clean_lookup_title(title).lower()
    return _NON_ALNUM_RE.sub("", cleaned) or _NON_ALNUM_RE.sub("", (title or "").lower())


# ------------------------------------------------------------------ category classification

_CATEGORY_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    (
        "coop",
        (
            "co-op", "coop", "multi-player", "multiplayer", "online co-op", "lan co-op",
            "shared/split screen", "split-screen", "pvp", "online pvp", "mmo",
            "massively multiplayer", "ofme", "co-op by", "chơi mạng", "đồng đội",
        ),
    ),
    (
        "horror",
        (
            "horror", "survival horror", "psychological horror", "zombie", "zombies",
            "survival", "lovecraftian", "kinh dị", "sinh tồn",
        ),
    ),
    (
        "rpg",
        (
            "rpg", "jrpg", "arpg", "crpg", "action rpg", "role-playing", "role playing",
            "souls-like", "soulslike", "dungeon crawler", "mmorpg", "nhập vai",
        ),
    ),
    (
        "sports_racing",
        (
            "racing", "driving", "automobile", "motorsport", "drift", "motorbike",
            "sports", "football", "soccer", "basketball", "baseball", "golf", "tennis",
            "wrestling", "skate", "billiards", "fishing", "đua xe", "thể thao",
        ),
    ),
    (
        "strategy_sim",
        (
            "strategy", "rts", "turn-based", "grand strategy", "4x", "tactical",
            "tower defense", "card battler", "deckbuilding", "auto battler",
            "simulation", "simulator", "management", "building", "city builder",
            "colony sim", "farming", "life sim", "tycoon", "sandbox", "automation",
            "chiến thuật", "mô phỏng",
        ),
    ),
    (
        "adventure",
        (
            "adventure", "open world", "exploration", "action-adventure", "metroidvania",
            "platformer", "3d platformer", "2d platformer", "story rich", "visual novel",
            "point & click", "mystery", "detective", "walking simulator", "puzzle",
            "phiêu lưu", "thế giới mở",
        ),
    ),
    (
        "action",
        (
            "action", "shooter", "fps", "tps", "first-person", "third-person shooter",
            "hack and slash", "fighting", "beat 'em up", "spectacle fighter", "stealth",
            "arcade", "roguelike", "roguelite", "bullet hell", "twin stick", "mechs",
            "hành động", "bắn súng", "đối kháng",
        ),
    ),
    (
        "indie",
        (
            "indie", "casual", "party", "family", "relaxing", "cute", "pixel graphics",
            "rhythm", "music", "minigames", "trivia",
        ),
    ),
)


def classify_game_categories(
    game: OnlineFixGame,
    extra_genres: Iterable[str] = (),
    extra_categories: Iterable[str] = (),
) -> List[str]:
    """Classify a game into ordered canonical category slugs using source metadata + Steam/SGDB tags."""
    matched: list[str] = []

    if game.source == SOURCE_ONLINE_FIX:
        matched.append("coop")

    haystack_parts = [
        game.game_modes or "",
        game.update_info or "",
        " | ".join(str(x) for x in extra_genres if x),
        " | ".join(str(x) for x in extra_categories if x),
    ]
    haystack = " | ".join(haystack_parts).lower()

    for slug, keywords in _CATEGORY_RULES:
        if slug in matched:
            continue
        if any(kw in haystack for kw in keywords):
            matched.append(slug)

    if not matched:
        title_low = (game.title or "").lower()
        for slug, keywords in _CATEGORY_RULES:
            if any(kw in title_low for kw in keywords):
                matched.append(slug)

    if not matched:
        matched.append("other")

    return matched


# ------------------------------------------------------------------ atomic JSON & poster disk cache

_disk_lock = threading.RLock()


def _atomic_write_json(path: str, payload: dict) -> bool:
    try:
        folder = os.path.dirname(path)
        os.makedirs(folder, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(prefix=".tmp_", suffix=".json", dir=folder)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp_path, path)
            return True
        finally:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
    except OSError as e:
        logger.warning(f"{TAG} Could not write cache file {path}: {e}")
        return False


def load_catalog_cache() -> dict[str, list[OnlineFixGame]]:
    """Load cached page-1 games per source from store_catalog_cache.json in <2ms."""
    path = get_catalog_cache_path()
    with _disk_lock:
        if not os.path.isfile(path):
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as e:   # noqa: BLE001
            logger.warning(f"{TAG} Corrupted catalog cache {path}, ignoring: {e}")
            return {}

    if not isinstance(raw, dict) or raw.get("version") != CATALOG_CACHE_VERSION:
        return {}
    sources = raw.get("sources")
    if not isinstance(sources, dict):
        return {}

    now = time.time()
    out: dict[str, list[OnlineFixGame]] = {}
    for src in (SOURCE_ONLINE_FIX, SOURCE_ANKERGAMES, SOURCE_FITGIRL, SOURCE_STEAMRIP):
        entry = sources.get(src)
        if not isinstance(entry, dict):
            continue
        saved_at = float(entry.get("saved_at") or 0.0)
        if saved_at <= 0 or (now - saved_at) > CATALOG_MAX_AGE_SEC:
            continue
        items = entry.get("games")
        if not isinstance(items, list):
            continue
        parsed: list[OnlineFixGame] = []
        for it in items:
            if isinstance(it, dict):
                try:
                    g = OnlineFixGame.from_cache_dict(it)
                    if g.title and g.url and not is_excluded_game(g.title, g.url):
                        if not g.categories:
                            g.categories = classify_game_categories(g)
                        parsed.append(g)
                except Exception:   # noqa: BLE001
                    continue
        if parsed:
            out[src] = parsed
    return out


def save_catalog_source_cache(
    source: str,
    games: List[OnlineFixGame],
    target_path: Optional[str] = None,
) -> None:
    """Persist pooled games for a single store source into store_catalog_cache.json safely."""
    if not games:
        return
    path = target_path or get_catalog_cache_path()
    with _disk_lock:
        data: dict = {"version": CATALOG_CACHE_VERSION, "sources": {}}
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                if (
                    isinstance(loaded, dict)
                    and loaded.get("version") == CATALOG_CACHE_VERSION
                    and isinstance(loaded.get("sources"), dict)
                ):
                    data = loaded
            except Exception:   # noqa: BLE001
                pass
        data["sources"][source] = {
            "saved_at": time.time(),
            "games": [g.to_cache_dict() for g in games if not is_excluded_game(g.title, g.url)][:300],
        }
        _atomic_write_json(path, data)


def _poster_cache_file(url: str) -> str:
    digest = hashlib.sha1(url.encode("utf-8", errors="ignore")).hexdigest()
    return os.path.join(get_poster_disk_cache_dir(), f"{digest}.img")


def _poster_thumb_cache_file(url: str) -> str:
    digest = hashlib.sha1(url.encode("utf-8", errors="ignore")).hexdigest()
    return os.path.join(get_poster_disk_cache_dir(), f"{digest}.card_v2.png")


def load_cached_poster_thumb_bytes(url: str) -> Optional[bytes]:
    if not url:
        return None
    fp = _poster_thumb_cache_file(url)
    try:
        if os.path.isfile(fp):
            with open(fp, "rb") as f:
                data = f.read()
            if len(data) > 256:
                return data
    except OSError:
        pass
    return None


def save_cached_poster_thumb_bytes(url: str, data: bytes) -> None:
    if not url or not data or len(data) <= 256:
        return
    fp = _poster_thumb_cache_file(url)
    try:
        folder = os.path.dirname(fp)
        os.makedirs(folder, exist_ok=True)
        tmp = f"{fp}.{threading.get_ident()}.tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, fp)
    except OSError:
        pass


def load_cached_poster_bytes(url: str) -> Optional[bytes]:
    if not url:
        return None
    fp = _poster_cache_file(url)
    try:
        if os.path.isfile(fp):
            with open(fp, "rb") as f:
                data = f.read()
            if len(data) > 256:
                return data
    except OSError:
        pass
    return None


def save_cached_poster_bytes(url: str, data: bytes) -> None:
    if not url or not data or len(data) <= 256:
        return
    fp = _poster_cache_file(url)
    try:
        folder = os.path.dirname(fp)
        os.makedirs(folder, exist_ok=True)
        tmp = f"{fp}.{threading.get_ident()}.tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, fp)
    except OSError:
        pass


# ------------------------------------------------------------------ async multi-threaded metadata enricher

class StoreMetadataEnricher(QObject):
    """
    Background multi-threaded game metadata & 2:3 vertical cover enricher.
    Combines SteamGridDB API (canonical game match + 600x900 2:3 portrait cover)
    with Steam Store API (official genres + multiplayer/co-op categories + 600x900 library cover fallback).
    """

    game_enriched = Signal(str, dict)   # (norm_key, metadata_dict)

    def __init__(self, parent: Optional[QObject] = None, max_workers: int = 4):
        super().__init__(parent)
        self._lock = threading.RLock()
        self._local = threading.local()
        self._cache: Dict[str, dict] = {}
        self._inflight: set[str] = set()
        self._dirty = False
        self._last_flush = 0.0
        self._closed = False
        self._pool = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="store-meta")
        self._load_disk_cache()

    def _session(self) -> requests.Session:
        sess = getattr(self._local, "session", None)
        if sess is None:
            sess = requests.Session()
            sess.headers.update({"User-Agent": USER_AGENT, "Accept": "application/json"})
            self._local.session = sess
        return sess

    def _get_sgdb_api_key(self) -> str:
        try:
            if not _is_test_env():
                cfg = load_config()
                key = str(cfg.get("steamgriddb_api_key") or "").strip()
                if key:
                    return key
        except Exception:   # noqa: BLE001
            pass
        return str(STEAMGRIDB_API_KEY or "").strip()

    def _load_disk_cache(self) -> None:
        path = get_metadata_cache_path()
        with self._lock, _disk_lock:
            if not os.path.isfile(path):
                return
            try:
                with open(path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                if not isinstance(raw, dict) or raw.get("version") != CACHE_SCHEMA_VERSION:
                    logger.info(f"{TAG} Discarding outdated metadata cache schema in {path}")
                    return
                items = raw.get("items")
                if isinstance(items, dict):
                    self._cache = {str(k): v for k, v in items.items() if isinstance(v, dict)}
                    logger.info(f"{TAG} Loaded {len(self._cache)} cached game metadata entries from {path}")
            except Exception as e:   # noqa: BLE001
                logger.warning(f"{TAG} Could not read metadata cache {path}: {e}")

    def flush_to_disk(self, force: bool = False) -> None:
        with self._lock:
            if not self._dirty:
                return
            now = time.monotonic()
            if not force and (now - self._last_flush) < 2.0:
                return
            snapshot = dict(self._cache)
            self._dirty = False
            self._last_flush = now
        with _disk_lock:
            _atomic_write_json(get_metadata_cache_path(), {"version": CACHE_SCHEMA_VERSION, "items": snapshot})

    def shutdown(self) -> None:
        with self._lock:
            self._closed = True
        try:
            self.flush_to_disk(force=True)
        except Exception:   # noqa: BLE001
            pass
        try:
            self._pool.shutdown(wait=False, cancel_futures=True)
        except Exception:   # noqa: BLE001
            pass

    def get_cached(self, title: str) -> Optional[dict]:
        key = normalize_game_cache_key(title)
        if not key:
            return None
        with self._lock:
            entry = self._cache.get(key)
            if not entry:
                return None
            age = time.time() - float(entry.get("updated_at") or 0.0)
            ttl = METADATA_HIT_TTL_SEC if entry.get("hit") else METADATA_MISS_TTL_SEC
            if age > ttl:
                return None
            return dict(entry)

    def apply_cached_to_game(self, game: OnlineFixGame) -> bool:
        """Apply cached SteamGridDB 2:3 cover (or fall back directly to provider cover) and categories in-place."""
        if not game.provider_poster_url and game.poster_url:
            game.provider_poster_url = game.poster_url
        entry = self.get_cached(game.title)
        if entry:
            poster_2x3 = str(entry.get("poster_2x3_url") or "").strip()
            game.poster_url = poster_2x3 or game.provider_poster_url or game.poster_url
            game.categories = classify_game_categories(
                game,
                extra_genres=entry.get("genres") or (),
                extra_categories=entry.get("steam_categories") or (),
            )
            return True
        if not game.categories:
            game.categories = classify_game_categories(game)
        return False

    def enqueue_games(self, games: Iterable[OnlineFixGame], allow_network: Optional[bool] = None) -> int:
        """Apply disk cache immediately and submit uncached games to the background thread pool."""
        if allow_network is None:
            allow_network = not _is_test_env()

        queued = 0
        for g in games:
            hit = self.apply_cached_to_game(g)
            if hit or not allow_network:
                continue
            key = normalize_game_cache_key(g.title)
            if not key:
                continue
            with self._lock:
                if self._closed or key in self._inflight:
                    continue
                self._inflight.add(key)
            try:
                self._pool.submit(self._enrich_worker, key, g.title)
                queued += 1
            except RuntimeError:
                with self._lock:
                    self._inflight.discard(key)
        return queued

    def _enrich_worker(self, norm_key: str, raw_title: str) -> None:
        started = time.monotonic()
        try:
            meta = self._fetch_metadata(raw_title)
            with self._lock:
                self._cache[norm_key] = meta
                self._dirty = True
                self._inflight.discard(norm_key)
                closed = self._closed
            self.flush_to_disk(force=False)
            if not closed:
                try:
                    self.game_enriched.emit(norm_key, meta)
                except RuntimeError:
                    pass
            logger.debug(
                f"{TAG} Enriched {raw_title!r} -> appid={meta.get('steam_appid')}, "
                f"sgdb={meta.get('sgdb_id')}, genres={meta.get('genres')} in {time.monotonic() - started:.2f}s"
            )
        except Exception as e:   # noqa: BLE001 - worker boundary: never crash
            with self._lock:
                self._inflight.discard(norm_key)
            logger.warning(f"{TAG} Metadata enrichment failed for {raw_title!r} after {time.monotonic() - started:.2f}s: {e}")

    def _fetch_metadata(self, raw_title: str) -> dict:
        lookup = clean_lookup_title(raw_title)
        stripped_lookup = _CLEAN_EDITION_RE.sub("", lookup).strip().rstrip(".-_:/|–— ") or lookup
        sess = self._session()
        sgdb_id: Optional[int] = None
        canonical_name = lookup
        poster_2x3_url = ""
        steam_appid: Optional[int] = None
        genres: list[str] = []
        steam_categories: list[str] = []

        # 1. SteamGridDB lookup (strict title match ONLY; if missing, card falls back directly to provider poster)
        api_key = self._get_sgdb_api_key()
        if api_key and lookup:
            for query_variant in dict.fromkeys((lookup, stripped_lookup)):
                if not query_variant:
                    continue
                try:
                    sg_headers = {"Authorization": f"Bearer {api_key}"}
                    ac_url = f"https://www.steamgriddb.com/api/v2/search/autocomplete/{quote(query_variant)}"
                    r_ac = sess.get(ac_url, headers=sg_headers, timeout=8)
                    if r_ac.status_code == 200:
                        ac_data = r_ac.json().get("data") or []
                        matched_cand = next(
                            (c for c in ac_data if titles_match_strict(lookup, str(c.get("name") or ""))),
                            None,
                        )
                        if matched_cand:
                            sgdb_id = matched_cand.get("id")
                            canonical_name = str(matched_cand.get("name") or canonical_name)
                            if sgdb_id:
                                gr_url = (
                                    f"https://www.steamgriddb.com/api/v2/grids/game/{sgdb_id}"
                                    "?dimensions=600x900&types=static"
                                )
                                r_gr = sess.get(gr_url, headers=sg_headers, timeout=8)
                                if r_gr.status_code == 200:
                                    grids = r_gr.json().get("data") or []
                                    for gr in grids:
                                        u = str(gr.get("thumb") or gr.get("url") or "").strip()
                                        if u and not u.lower().endswith((".webm", ".gif")):
                                            poster_2x3_url = u
                                            break
                            break
                    else:
                        logger.warning(f"{TAG} SteamGridDB search HTTP {r_ac.status_code} for {query_variant!r} ({ac_url})")
                        break
                except requests.RequestException as e:
                    logger.warning(f"{TAG} SteamGridDB request failed for {query_variant!r}: {e}")
                    break

        # 2. Steam Store API lookup strictly for genres & multiplayer/co-op categories (never overrides provider poster)
        if stripped_lookup:
            try:
                st_url = f"https://store.steampowered.com/api/storesearch/?term={quote_plus(stripped_lookup)}&l=english&cc=US"
                r_st = sess.get(st_url, timeout=8)
                if r_st.status_code == 200:
                    items = r_st.json().get("items") or []
                    chosen = next(
                        (it for it in items if titles_match_strict(lookup, str(it.get("name") or ""))),
                        None,
                    )
                    if chosen and chosen.get("id"):
                        steam_appid = int(chosen["id"])
                else:
                    logger.warning(f"{TAG} Steam storesearch HTTP {r_st.status_code} for {stripped_lookup!r}")
            except (requests.RequestException, ValueError, KeyError) as e:
                logger.warning(f"{TAG} Steam storesearch failed for {stripped_lookup!r}: {e}")

        if steam_appid:
            try:
                det_url = (
                    f"https://store.steampowered.com/api/appdetails"
                    f"?appids={steam_appid}&filters=genres,categories&l=english"
                )
                r_det = sess.get(det_url, timeout=8)
                if r_det.status_code == 200:
                    app_entry = (r_det.json() or {}).get(str(steam_appid)) or {}
                    if app_entry.get("success") and isinstance(app_entry.get("data"), dict):
                        pdata = app_entry["data"]
                        genres = [
                            str(g.get("description")).strip()
                            for g in (pdata.get("genres") or [])
                            if isinstance(g, dict) and g.get("description")
                        ]
                        steam_categories = [
                            str(c.get("description")).strip()
                            for c in (pdata.get("categories") or [])
                            if isinstance(c, dict) and c.get("description")
                        ]
            except (requests.RequestException, ValueError) as e:
                logger.warning(f"{TAG} Steam appdetails failed for appid={steam_appid}: {e}")

        hit = bool(sgdb_id or steam_appid or poster_2x3_url or genres)
        return {
            "hit": hit,
            "canonical_name": canonical_name,
            "sgdb_id": sgdb_id,
            "steam_appid": steam_appid,
            "poster_2x3_url": poster_2x3_url,
            "genres": genres,
            "steam_categories": steam_categories,
            "updated_at": time.time(),
        }


_enricher_instance: Optional[StoreMetadataEnricher] = None
_enricher_lock = threading.Lock()


def get_store_metadata_enricher() -> StoreMetadataEnricher:
    global _enricher_instance
    with _enricher_lock:
        if _enricher_instance is None:
            _enricher_instance = StoreMetadataEnricher()
            try:
                from PySide6.QtWidgets import QApplication
                app = QApplication.instance()
                if app is not None:
                    app.aboutToQuit.connect(_enricher_instance.shutdown)
            except Exception:   # noqa: BLE001
                pass
    return _enricher_instance


_STEAM_APP_URL_RE = re.compile(r"(?:store\.steampowered\.com/app|steam/apps)/(\d+)", re.IGNORECASE)


def steam_app_url(appid: int) -> str:
    return f"https://store.steampowered.com/app/{int(appid)}/"


def steam_search_url(title: str) -> str:
    cleaned = clean_lookup_title(title)
    query = _CLEAN_EDITION_RE.sub("", cleaned).strip().rstrip(".-_:/|–— ") or cleaned or (title or "").strip()
    return f"https://store.steampowered.com/search/?term={quote_plus(query)}" if query else "https://store.steampowered.com/"


def extract_steam_appid_from_urls(*urls: str) -> Optional[int]:
    for raw in urls:
        if not raw:
            continue
        m = _STEAM_APP_URL_RE.search(str(raw))
        if m:
            try:
                appid = int(m.group(1))
                if appid > 0:
                    return appid
            except ValueError:
                continue
    return None


def candidate_steam_urls_for_game(game: OnlineFixGame) -> tuple[str, ...]:
    urls: list[str] = []
    for u in (game.poster_url, game.provider_poster_url, game.url):
        if u and u not in urls:
            urls.append(u)
    for p in (game.providers or ()):
        for u in (p.poster_url, p.provider_poster_url, p.url):
            if u and u not in urls:
                urls.append(u)
    return tuple(urls)


def peek_cached_steam_store_url(title: str, *candidate_urls: str) -> Optional[str]:
    """Zero-I/O UI-thread check: return direct Steam app URL if already in memory cache or embedded in asset URLs."""
    with _enricher_lock:
        inst = _enricher_instance
    if inst is not None and title:
        entry = inst.get_cached(title)
        if entry and entry.get("steam_appid"):
            try:
                appid = int(entry["steam_appid"])
                if appid > 0:
                    return steam_app_url(appid)
            except (TypeError, ValueError):
                pass
    url_appid = extract_steam_appid_from_urls(*candidate_urls)
    return steam_app_url(url_appid) if url_appid else None


def resolve_steam_store_url(
    title: str,
    *candidate_urls: str,
    allow_network: Optional[bool] = None,
) -> str:
    """Resolve official Steam Store URL off the UI thread, falling back to Steam search URL if no AppID matches."""
    started = time.monotonic()
    enricher = get_store_metadata_enricher()
    entry = enricher.get_cached(title) if title else None
    if entry and entry.get("steam_appid"):
        try:
            cached_id = int(entry["steam_appid"])
            if cached_id > 0:
                url = steam_app_url(cached_id)
                logger.info(
                    f"{TAG} Resolved Steam link for {title!r} -> {url} (cache hit) in {time.monotonic() - started:.3f}s"
                )
                return url
        except (TypeError, ValueError):
            pass

    url_appid = extract_steam_appid_from_urls(*candidate_urls)
    if url_appid:
        url = steam_app_url(url_appid)
        logger.info(
            f"{TAG} Resolved Steam link for {title!r} -> {url} (asset appid={url_appid}) in {time.monotonic() - started:.3f}s"
        )
        return url

    if allow_network is None:
        allow_network = not _is_test_env()

    lookup = clean_lookup_title(title)
    stripped_lookup = _CLEAN_EDITION_RE.sub("", lookup).strip().rstrip(".-_:/|–— ") or lookup
    if allow_network and stripped_lookup:
        st_url = f"https://store.steampowered.com/api/storesearch/?term={quote_plus(stripped_lookup)}&l=english&cc=US"
        req_started = time.monotonic()
        try:
            sess = enricher._session()
            r_st = sess.get(st_url, timeout=8)
            req_dur = time.monotonic() - req_started
            if r_st.status_code == 200:
                items = (r_st.json() or {}).get("items") or []
                chosen = next(
                    (it for it in items if titles_match_strict(lookup, str(it.get("name") or ""))),
                    None,
                )
                if chosen is None:
                    chosen = next(
                        (it for it in items if matches_search_query(stripped_lookup, str(it.get("name") or ""))),
                        None,
                    )
                if chosen and chosen.get("id"):
                    steam_appid = int(chosen["id"])
                    if steam_appid > 0:
                        norm_key = normalize_game_cache_key(title)
                        if norm_key:
                            with enricher._lock:
                                cur = dict(enricher._cache.get(norm_key) or {})
                                cur.update({
                                    "hit": True,
                                    "canonical_name": str(cur.get("canonical_name") or chosen.get("name") or lookup),
                                    "steam_appid": steam_appid,
                                    "updated_at": time.time(),
                                })
                                enricher._cache[norm_key] = cur
                                enricher._dirty = True
                            enricher.flush_to_disk(force=False)
                        url = steam_app_url(steam_appid)
                        logger.info(
                            f"{TAG} Resolved Steam link for {title!r} -> {url} (appid={steam_appid}) "
                            f"in {time.monotonic() - started:.2f}s"
                        )
                        return url
            else:
                logger.warning(
                    f"{TAG} Steam storesearch failed for {title!r}: HTTP {r_st.status_code} ({st_url}) in {req_dur:.2f}s"
                )
        except (requests.RequestException, ValueError, KeyError) as e:
            logger.warning(
                f"{TAG} Steam storesearch failed for {title!r}: {e} ({st_url}) in {time.monotonic() - req_started:.2f}s"
            )

    fallback = steam_search_url(title)
    logger.warning(
        f"{TAG} Direct Steam AppID not found for {title!r} in {time.monotonic() - started:.2f}s; "
        f"falling back to {fallback}"
    )
    return fallback
