"""
Online-Fix.me, AnkerGames, FitGirl Repacks & SteamRIP Integration Package for Bob Gaming Game Center.
"""

from app.core.online_fix.ankergames_client import AnkerGamesClient
from app.core.online_fix.fitgirl_client import FitGirlClient
from app.core.online_fix.models import (
    SOURCE_ANKERGAMES,
    SOURCE_FITGIRL,
    SOURCE_ONLINE_FIX,
    SOURCE_STEAMRIP,
    DownloadTask,
    OnlineFixGame,
    TaskStatus,
)
from app.core.online_fix.runner import (
    DEFAULT_ONLINEFIX_APP_ID,
    DEFAULT_ONLINEFIX_DLL_OVERRIDES,
    FULL_ONLINEFIX_DLL_OVERRIDES,
    KNOWN_ONLINEFIX_DLLS,
    build_onlinefix_launch_options,
    create_game_launcher_script,
    detect_online_fix_game,
    heal_onlinefix_ini,
    plant_steam_appid,
    prepare_online_fix_launch,
)
from app.core.online_fix.steamrip_client import SteamRipClient

__all__ = [
    "OnlineFixGame",
    "DownloadTask",
    "TaskStatus",
    "SOURCE_ONLINE_FIX",
    "SOURCE_ANKERGAMES",
    "SOURCE_STEAMRIP",
    "SOURCE_FITGIRL",
    "AnkerGamesClient",
    "FitGirlClient",
    "SteamRipClient",
    "DEFAULT_ONLINEFIX_APP_ID",
    "DEFAULT_ONLINEFIX_DLL_OVERRIDES",
    "FULL_ONLINEFIX_DLL_OVERRIDES",
    "KNOWN_ONLINEFIX_DLLS",
    "detect_online_fix_game",
    "build_onlinefix_launch_options",
    "plant_steam_appid",
    "heal_onlinefix_ini",
    "create_game_launcher_script",
    "prepare_online_fix_launch",
]

