"""
HTTP Client & Scraper for FitGirl Repacks (https://fitgirl-repacks.site/).
Handles game searching, latest lossless repacks listing, metadata & magnet link extraction.

Every network call is logged with its URL, status and duration. Network / HTTP failures raise OnlineFixError so the
UI can handle errors consistently across both Online-Fix and FitGirl sources.
"""

import html as html_lib
import json
import logging
import os
import re
import threading
import time
import urllib.parse
from typing import List

import bs4
import requests

from app.core.online_fix.client import OnlineFixError, PAGE_TIMEOUT, POSTER_TIMEOUT, USER_AGENT
from app.core.online_fix.models import LINK_TORRENT, LINK_WEB, SOURCE_FITGIRL, OnlineFixGame, dotted_acronym_query, format_ts_ddmmyyyy, has_hypervisor_marker, is_excluded_game, matches_search_query, parse_store_date_ts, sort_games_for_search
from app.core.online_fix.store_cache import classify_game_categories

logger = logging.getLogger(__name__)
TAG = "[FitGirl/Client]"

FITGIRL_BASE_URL = "https://fitgirl-repacks.site"
FITGIRL_LOSSLESS_CAT_ID = 5
FITGIRL_PAGE_SIZE = 10
FITGIRL_BATCH_SIZE = 50
FITGIRL_POSTER_TIMEOUT = 8.0

FITGIRL_CATEGORY_SEARCH_TERMS: dict[str, str] = {
    "coop": "Multiplayer",
    "action": "Action",
    "rpg": "RPG",
    "adventure": "Adventure",
    "horror": "Horror",
    "sports_racing": "Racing",
    "strategy_sim": "Strategy",
    "indie": "Indie",
}

_LEADING_NUM_RE = re.compile(r"^#\d+\s+(?:(?:PC|Updated|HYPERVISOR)\s+)*", re.IGNORECASE)
_TITLE_SPLIT_RE = re.compile(
    r"\s+(?:[–—-]\s+|,\s*(?=v\d|build\b|all\s+dlc|\d+\s+dlc))",
    re.IGNORECASE,
)
_REPACK_SIZE_RE = re.compile(r"Repack Size:\s*([^\r\n<]+)", re.IGNORECASE)
_ORIG_SIZE_RE = re.compile(r"Original Size:\s*([^\r\n<]+)", re.IGNORECASE)
_GENRES_RE = re.compile(r"Genres/Tags:\s*([^\r\n<]+)", re.IGNORECASE)
_POST_ID_RE = re.compile(r"post-(\d+)")
_P_TAG_RE = re.compile(r"</?p\b[^>]*>", re.IGNORECASE)
_LINE_BREAK_TAG_RE = re.compile(r"<br\s*/?>|</?(?:h[1-6]|ul|ol|li|div|p)\b[^>]*>", re.IGNORECASE)
_SELECTIVE_DL_RE = re.compile(r"\s*\[Selective Download\]\s*", re.IGNORECASE)
_NON_ENGLISH_FITGIRL_PACK_RE = re.compile(
    r"(?:^|/)(?:fg-(?:selective|optional))-(?:brazilian|chinese|simplified|traditional|french|german|"
    r"italian|japanese|korean|polish|russian|spanish|mexican|latin|portuguese|arabic|thai|turkish|"
    r"czech|hungarian|ukrainian)(?:[-_\.]|$)",
    re.IGNORECASE,
)


def is_non_english_fitgirl_pack(name_or_url: str) -> bool:
    """Return True if a FitGirl archive/bin filename or URL is a non-English language pack."""
    unquoted = urllib.parse.unquote(name_or_url or "").strip().lower()
    bname = unquoted.rstrip("/").rsplit("/", 1)[-1]
    if "english" in bname:
        return False
    return bool(_NON_ENGLISH_FITGIRL_PACK_RE.search(bname))

_IGNORED_DOMAINS = (
    "internetdownloadmanager.com",
    "jdownloader.org",
    "torrent-stats.info",
    "riotpixels.com",
    "fitgirl-repacks.site/tag/",
    "fitgirl-repacks.site/category/",
    "fitgirl-repacks.site/author/",
)


def _clean_fitgirl_html(raw_html: str) -> str:
    """
    Replace <p> and </p> with <br/> before parsing with html.parser.
    FitGirl posts often open an unclosed <p> at the top of .entry-content and emit a stray </p>
    inside .su-spoiler-content; without this, Python's html.parser pops the tag stack back to the
    top <p> and prematurely closes .entry-content and <article> before 'Download Mirrors (Torrent)'.
    """
    if not raw_html:
        return ""
    return _P_TAG_RE.sub("<br/>", raw_html)


def split_fitgirl_title(raw_title: str) -> tuple[str, str]:
    """Split a FitGirl post title into (clean_game_title, version_or_dlc_note)."""
    clean = html_lib.unescape(" ".join((raw_title or "").split())).strip()
    clean = _LEADING_NUM_RE.sub("", clean).strip()
    if not clean:
        return "", ""
    parts = _TITLE_SPLIT_RE.split(clean, maxsplit=1)
    if len(parts) == 2 and parts[0].strip():
        return parts[0].strip(), parts[1].strip()
    return clean, ""


def _format_iso_date(iso_str: str) -> str:
    """Convert WP ISO date '2026-09-15T02:20:11' into '15/09/2026'."""
    if not iso_str or len(iso_str) < 10:
        return ""
    part = iso_str[:10]
    pieces = part.split("-")
    if len(pieces) == 3 and all(p.isdigit() for p in pieces):
        return f"{pieces[2]}/{pieces[1]}/{pieces[0]}"
    return part


class FitGirlClient:
    """Scraper and WP API client for fitgirl-repacks.site. Safe to call from several threads."""

    def __init__(self):
        self._local = threading.local()

    @property
    def session(self) -> requests.Session:
        """Per-thread requests session."""
        s = getattr(self._local, "session", None)
        if s is None:
            s = requests.Session()
            s.headers.update({
                "User-Agent": USER_AGENT,
                "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
                "Referer": FITGIRL_BASE_URL + "/",
            })
            self._local.session = s
        return s

    # ------------------------------------------------------------ http

    def _get(self, url: str, what: str, timeout: float = PAGE_TIMEOUT, referer: str = "") -> requests.Response:
        started = time.monotonic()
        headers = {"Referer": referer} if referer else None
        try:
            resp = self.session.get(url, timeout=timeout, headers=headers)
        except requests.Timeout:
            logger.warning(f"{TAG} {what}: timeout after {timeout}s ({url})")
            raise OnlineFixError("fitgirl-repacks.site không phản hồi (quá thời gian chờ). Thử lại sau.")
        except requests.RequestException as e:
            logger.warning(f"{TAG} {what}: network error {e.__class__.__name__}: {e} ({url})")
            raise OnlineFixError("Không kết nối được tới fitgirl-repacks.site. Kiểm tra mạng hoặc bật 'Mở chặn mạng'.")
        elapsed = time.monotonic() - started
        if resp.status_code != 200:
            logger.warning(f"{TAG} {what}: HTTP {resp.status_code} in {elapsed:.2f}s ({url})")
            raise OnlineFixError(f"fitgirl-repacks.site trả về lỗi HTTP {resp.status_code}.")
        logger.debug(f"{TAG} {what}: HTTP 200, {len(resp.content)} bytes in {elapsed:.2f}s ({url})")
        return resp

    def fetch_bytes(self, url: str, timeout: float = FITGIRL_POSTER_TIMEOUT) -> bytes:
        """Download poster image bytes. Supports 'fitgirl-post:<page_url>' lazy poster resolution."""
        if url.startswith("fitgirl-post:"):
            page_url = url[len("fitgirl-post:"):]
            details = self.get_game_details(page_url)
            if not details.poster_url or details.poster_url.startswith("fitgirl-post:"):
                raise OnlineFixError("Không tìm thấy ảnh bìa trên trang FitGirl.")
            url = details.poster_url
        return self._get(url, "fetch", timeout=timeout).content

    # ------------------------------------------------------------ listing

    def search_games(self, query: str, page: int = 1) -> List[OnlineFixGame]:
        """Search for games on fitgirl-repacks.site (lossless repacks). Raises OnlineFixError."""
        if not query or len(query.strip()) < 2:
            return self.get_latest_games(page=page)

        q = query.strip()
        encoded_q = urllib.parse.quote(q)
        api_url = (
            f"{FITGIRL_BASE_URL}/wp-json/wp/v2/posts"
            f"?categories={FITGIRL_LOSSLESS_CAT_ID}&search={encoded_q}"
            f"&search_columns=post_title&page={page}&per_page={FITGIRL_PAGE_SIZE}"
            f"&_fields=id,date,modified,link,title,content"
        )
        started = time.monotonic()
        try:
            resp = self._get(api_url, f"search {q!r} p{page}")
            text = resp.text.strip()
            raw_games = self._parse_wp_json_posts(text) if text.startswith("[") else self._parse_game_list(text)
            games = [g for g in raw_games if matches_search_query(q, g.title, g.url)]
        except OnlineFixError as err:
            if "HTTP 400" in str(err) and page > 1:
                logger.info(f"{TAG} Search {q!r} page {page}: 0 games (past last page) in {time.monotonic() - started:.2f}s")
                return []
            raise

        if page == 1 and not games:
            dotted = dotted_acronym_query(q)
            if dotted:
                try:
                    d_url = (
                        f"{FITGIRL_BASE_URL}/wp-json/wp/v2/posts"
                        f"?categories={FITGIRL_LOSSLESS_CAT_ID}&search={urllib.parse.quote(dotted)}"
                        f"&search_columns=post_title&page=1&per_page={FITGIRL_PAGE_SIZE}"
                        f"&_fields=id,date,modified,link,title,content"
                    )
                    d_text = self._get(d_url, f"search-dotted {dotted!r} p1").text.strip()
                    d_raw = self._parse_wp_json_posts(d_text) if d_text.startswith("[") else self._parse_game_list(d_text)
                    games = [g for g in d_raw if matches_search_query(q, g.title, g.url)]
                except OnlineFixError:
                    pass

        games = sort_games_for_search(q, games)
        logger.info(f"{TAG} Search {q!r} page {page}: {len(games)} games in {time.monotonic() - started:.2f}s")
        return games

    def get_latest_games(self, page: int = 1) -> List[OnlineFixGame]:
        """Fetch latest Lossless Repack games on fitgirl-repacks.site. Raises OnlineFixError."""
        url = (
            f"{FITGIRL_BASE_URL}/category/lossless-repack/page/{page}/"
            if page > 1
            else f"{FITGIRL_BASE_URL}/category/lossless-repack/"
        )
        started = time.monotonic()
        try:
            html = self._get(url, f"latest p{page}").text
        except OnlineFixError as err:
            if "HTTP 404" in str(err) and page > 1:
                logger.info(f"{TAG} Latest games page {page}: 0 games (404 end) in {time.monotonic() - started:.2f}s")
                return []
            raise
        games = self._parse_game_list(html)
        logger.info(f"{TAG} Latest games page {page}: {len(games)} games in {time.monotonic() - started:.2f}s")
        return games

    def get_latest_games_batch(self, batch_page: int = 1, per_page: int = FITGIRL_BATCH_SIZE) -> List[OnlineFixGame]:
        """Fetch up to 50 lossless repacks (= 5 pages) in a single WP REST API request (HTML fallback)."""
        started = time.monotonic()
        limit = max(1, min(int(per_page or FITGIRL_BATCH_SIZE), 100))
        api_url = (
            f"{FITGIRL_BASE_URL}/wp-json/wp/v2/posts"
            f"?categories={FITGIRL_LOSSLESS_CAT_ID}&page={batch_page}&per_page={limit}"
            f"&_fields=id,date,modified,link,title,content"
        )
        try:
            text = self._get(api_url, f"latest-batch p{batch_page} (n={limit})").text.lstrip()
            if text.startswith("["):
                games = self._parse_wp_json_posts(text)
                logger.info(
                    f"{TAG} Latest batch {batch_page} (per_page={limit}): {len(games)} games in {time.monotonic() - started:.2f}s"
                )
                return games
        except OnlineFixError as err:
            if any(code in str(err) for code in ("HTTP 400", "HTTP 404")) and batch_page > 1:
                logger.info(f"{TAG} Latest batch {batch_page}: 0 games (past last page) in {time.monotonic() - started:.2f}s")
                return []
            logger.warning(f"{TAG} WP batch {batch_page} failed ({err}), falling back to HTML page")
        return self.get_latest_games(page=batch_page)

    def get_category_games(self, category_slug: str, page: int = 1, per_page: int = 30) -> List[OnlineFixGame]:
        """Fetch FitGirl lossless repacks matching a canonical store category via WP REST API."""
        term = FITGIRL_CATEGORY_SEARCH_TERMS.get(category_slug)
        if not term:
            return []
        started = time.monotonic()
        limit = max(1, min(int(per_page or 30), 100))
        api_url = (
            f"{FITGIRL_BASE_URL}/wp-json/wp/v2/posts"
            f"?categories={FITGIRL_LOSSLESS_CAT_ID}&search={urllib.parse.quote(term)}"
            f"&page={page}&per_page={limit}&_fields=id,date,modified,link,title,content"
        )
        try:
            text = self._get(api_url, f"category {category_slug!r} p{page}").text.lstrip()
            games = self._parse_wp_json_posts(text) if text.startswith("[") else []
        except OnlineFixError as err:
            if any(code in str(err) for code in ("HTTP 400", "HTTP 404")) and page > 1:
                logger.info(f"{TAG} Category {category_slug!r} page {page}: 0 games (past last page) in {time.monotonic() - started:.2f}s")
                return []
            logger.warning(f"{TAG} Category {category_slug!r} p{page} failed in {time.monotonic() - started:.2f}s: {err}")
            return []
        logger.info(
            f"{TAG} Category {category_slug!r} page {page}: {len(games)} games in {time.monotonic() - started:.2f}s"
        )
        return games

    def _parse_wp_json_posts(self, raw_json: str) -> List[OnlineFixGame]:
        """Parse WP REST API JSON array of posts into OnlineFixGame items."""
        try:
            items = json.loads(raw_json)
        except ValueError as e:
            logger.warning(f"{TAG} Could not parse WP JSON response: {e}")
            return []
        if not isinstance(items, list):
            return []

        games: List[OnlineFixGame] = []
        seen: set[str] = set()
        for item in items:
            try:
                game_url = str(item.get("link") or "").strip()
                if not game_url or game_url in seen:
                    continue
                raw_title_html = (item.get("title") or {}).get("rendered") or ""
                raw_title = bs4.BeautifulSoup(raw_title_html, "html.parser").get_text(" ").strip()
                title, version_note = split_fitgirl_title(raw_title)
                if not title or is_excluded_game(title, game_url):
                    continue

                content_html = (item.get("content") or {}).get("rendered") or ""
                content_soup = bs4.BeautifulSoup(_clean_fitgirl_html(content_html), "html.parser")
                poster_url = self._extract_poster(content_soup)
                update_info, game_modes = self._extract_metadata(content_soup, version_note)
                download_links = self._extract_download_links(content_soup)
                is_hv = self._extract_is_hypervisor(content_soup, raw_title)

                seen.add(game_url)
                g_wp = OnlineFixGame(
                    id=str(item.get("id") or os.path.basename(game_url.rstrip("/"))),
                    title=title,
                    url=game_url,
                    poster_url=poster_url,
                    date=_format_iso_date(str(item.get("date") or "")), published_ts=parse_store_date_ts(str(item.get("date") or "")), updated_ts=parse_store_date_ts(str(item.get("modified") or "")),
                    update_info=update_info,
                    game_modes=game_modes,
                    archive_password="",
                    download_links=download_links,
                    source=SOURCE_FITGIRL,
                    is_hypervisor=is_hv,
                )
                g_wp.categories = classify_game_categories(g_wp)
                games.append(g_wp)
            except Exception as e:   # noqa: BLE001
                logger.debug(f"{TAG} Skipped WP JSON item: {e}")
        hv_count = sum(1 for g in games if g.is_hypervisor)
        if hv_count:
            logger.info(f"{TAG} Detected {hv_count} Hypervisor (HV) repack(s) in WP batch ({len(games)} total)")
        return games

    def _parse_game_list(self, html: str) -> List[OnlineFixGame]:
        """Parse game articles from FitGirl category or search HTML."""
        soup = bs4.BeautifulSoup(_clean_fitgirl_html(html), "html.parser")
        games: List[OnlineFixGame] = []
        seen: set[str] = set()

        articles = soup.find_all("article")
        skipped = 0
        for art in articles:
            try:
                classes = [c.lower() for c in (art.get("class") or [])]
                if any(c in classes for c in ("category-updates-digest", "category-upcoming-repacks", "type-page")):
                    continue
                if classes and any(c.startswith("category-") for c in classes):
                    if "category-lossless-repack" not in classes:
                        continue

                title_tag = (
                    art.find("h1", class_="entry-title")
                    or art.find("h2", class_="entry-title")
                    or art.find("h1")
                    or art.find("h2")
                )
                link_tag = title_tag.find("a") if title_tag else art.find("a", rel="bookmark")
                game_url = (link_tag.get("href") or "").strip() if link_tag else ""
                if not game_url or not game_url.startswith("http") or game_url in seen:
                    continue

                raw_title = (link_tag.get_text(" ") if link_tag else (title_tag.get_text(" ") if title_tag else "")).strip()
                title, version_note = split_fitgirl_title(raw_title)
                if not title or is_excluded_game(title, game_url):
                    continue

                content_node = art.select_one(".entry-content") or art.select_one(".entry-summary") or art
                poster_url = self._extract_poster(content_node)
                if not poster_url:
                    poster_url = f"fitgirl-post:{game_url}"

                time_tag = art.find("time", class_="entry-date") or art.find("time")
                date_str = time_tag.get_text(strip=True) if time_tag else ""

                update_info, game_modes = self._extract_metadata(content_node, version_note)
                download_links = self._extract_download_links(content_node)
                is_hv = self._extract_is_hypervisor(content_node, raw_title)

                post_id = ""
                art_id = str(art.get("id") or "")
                m_id = _POST_ID_RE.search(art_id)
                if m_id:
                    post_id = m_id.group(1)
                else:
                    post_id = os.path.basename(game_url.rstrip("/")) or title

                seen.add(game_url)
                g_html = OnlineFixGame(
                    id=post_id,
                    title=title,
                    url=game_url,
                    poster_url=poster_url,
                    date=date_str or format_ts_ddmmyyyy(parse_store_date_ts(str(time_tag.get("datetime") or "") if time_tag else "")), published_ts=parse_store_date_ts(str(time_tag.get("datetime") or date_str) if time_tag else date_str),
                    update_info=update_info,
                    game_modes=game_modes,
                    archive_password="",
                    download_links=download_links,
                    source=SOURCE_FITGIRL,
                    is_hypervisor=is_hv,
                )
                g_html.categories = classify_game_categories(g_html)
                games.append(g_html)
            except Exception as e:   # noqa: BLE001
                skipped += 1
                logger.debug(f"{TAG} Skipped parsing FitGirl article: {e}")

        if skipped:
            logger.warning(f"{TAG} {skipped} article(s) could not be parsed")
        hv_count = sum(1 for g in games if g.is_hypervisor)
        if hv_count:
            logger.info(f"{TAG} Detected {hv_count} Hypervisor (HV) repack(s) in HTML list ({len(games)} total)")
        return games

    # ------------------------------------------------------------ details

    def get_game_details(self, game_url: str) -> OnlineFixGame:
        """Fetch detailed information and download links for a FitGirl repack. Raises OnlineFixError."""
        started = time.monotonic()
        html = self._get(game_url, "details").text
        game = self._parse_game_details(html, game_url)
        kinds = {}
        for link in game.download_links:
            kinds[link["kind"]] = kinds.get(link["kind"], 0) + 1
        logger.info(f"{TAG} Details {game.title!r}: links {kinds or 'none'}, {time.monotonic() - started:.2f}s")
        return game

    def _parse_game_details(self, html: str, game_url: str) -> OnlineFixGame:
        soup = bs4.BeautifulSoup(_clean_fitgirl_html(html), "html.parser")
        art = soup.find("article") or soup

        title_tag = (
            art.find("h1", class_="entry-title")
            or art.find("h2", class_="entry-title")
            or soup.find("h1")
        )
        raw_title = title_tag.get_text(" ").strip() if title_tag else ""
        title, version_note = split_fitgirl_title(raw_title)

        content_node = art.select_one(".entry-content") or art
        poster_url = self._extract_poster(content_node)

        time_tag = art.find("time", class_="entry-date") or art.find("time")
        date_str = time_tag.get_text(strip=True) if time_tag else ""

        update_info, game_modes = self._extract_metadata(content_node, version_note)
        download_links = self._extract_download_links(content_node)
        if not any(d["kind"] == LINK_TORRENT for d in download_links) and content_node is not soup:
            download_links = self._extract_download_links(soup)
        is_hv = self._extract_is_hypervisor(content_node, raw_title)

        post_id = os.path.basename(game_url.rstrip("/")) or "fitgirl"
        art_id = str(art.get("id") or "") if hasattr(art, "get") else ""
        m_id = _POST_ID_RE.search(art_id)
        if m_id:
            post_id = m_id.group(1)

        return OnlineFixGame(
            id=post_id,
            title=title or raw_title or "FitGirl Repack",
            url=game_url,
            poster_url=poster_url,
            date=date_str,
            update_info=update_info,
            game_modes=game_modes,
            archive_password="",
            download_links=download_links,
            source=SOURCE_FITGIRL,
            is_hypervisor=is_hv,
        )

    # ------------------------------------------------------------ helpers

    @staticmethod
    def _extract_is_hypervisor(content_node: bs4.Tag, raw_title: str = "") -> bool:
        """
        Return True when the active FitGirl repack uses a Hypervisor (HV) bypass.
        Checks the post header `<h3>` badge (`#7284 HYPERVISOR` / `#6652 Updated HYPERVISOR`)
        and active non-spoiler magnet links while ignoring archived HV builds inside `.su-spoiler`.
        """
        if has_hypervisor_marker(raw_title):
            return True
        if content_node is None:
            return False
        h3 = content_node.find("h3")
        if h3 is not None and not h3.find_parent("div", class_="su-spoiler"):
            for sp in h3.find_all("span"):
                if sp.find_parent("strong") is not None:
                    continue
                sp_txt = " ".join(sp.get_text(" ").split()).strip()
                if sp_txt.upper() == "HV" or has_hypervisor_marker(sp_txt):
                    return True
            strong = h3.find("strong")
            if strong is None and has_hypervisor_marker(h3.get_text(" ")):
                return True
        for a in content_node.find_all("a", href=True):
            href = (a.get("href") or "").strip()
            if not href.lower().startswith("magnet:?"):
                continue
            if a.find_parent("div", class_="su-spoiler"):
                continue
            if has_hypervisor_marker(urllib.parse.unquote_plus(href)):
                return True
        return False

    @staticmethod
    def _extract_poster(content_node: bs4.Tag) -> str:
        img = content_node.select_one("img.alignleft") or content_node.find("img")
        if not img:
            return ""
        src = (img.get("data-src") or img.get("src") or "").strip()
        if not src or "torrent-stats.info" in src or "cropped-icon" in src:
            for candidate in content_node.find_all("img"):
                c_src = (candidate.get("data-src") or candidate.get("src") or "").strip()
                if c_src and "torrent-stats.info" not in c_src and "cropped-icon" not in c_src:
                    src = c_src
                    break
            else:
                return ""
        if src.startswith("//"):
            return "https:" + src
        if src.startswith("/"):
            return FITGIRL_BASE_URL + src
        return src

    @staticmethod
    def _extract_metadata(content_node: bs4.Tag, version_note: str) -> tuple[str, str]:
        raw_html = _LINE_BREAK_TAG_RE.sub("\n", str(content_node))
        text = bs4.BeautifulSoup(raw_html, "html.parser").get_text(" ")
        repack_m = _REPACK_SIZE_RE.search(text)
        orig_m = _ORIG_SIZE_RE.search(text)
        genres_m = _GENRES_RE.search(text)

        repack_size = " ".join(repack_m.group(1).split()) if repack_m else ""
        repack_size = _SELECTIVE_DL_RE.sub("", repack_size).strip()
        orig_size = " ".join(orig_m.group(1).split()) if orig_m else ""
        genres = " ".join(genres_m.group(1).split()).replace(" ,", ",") if genres_m else ""

        update_parts = []
        if version_note:
            update_parts.append(version_note)
        if repack_size:
            update_parts.append(f"Repack: {repack_size}")
        update_info = " · ".join(update_parts)

        mode_parts = []
        if genres:
            mode_parts.append(f"Thể loại: {genres}")
        if orig_size:
            mode_parts.append(f"Dung lượng gốc: {orig_size}")
        if repack_size:
            mode_parts.append(f"Dung lượng tải: {repack_size}")
        game_modes = " · ".join(mode_parts)
        return update_info, game_modes

    @staticmethod
    def _extract_download_links(content_node: bs4.Tag) -> List[dict]:
        """Extract magnet/torrent links, FileKeeper direct CDN links, and web mirror links from a FitGirl post body."""
        links: List[dict] = []
        seen: set[str] = set()
        fk_parts: List[str] = []

        # 1. Magnet and direct .torrent links anywhere in the post content (plus FileKeeper direct parts in spoilers)
        for a in content_node.find_all("a"):
            href = (a.get("href") or "").strip()
            if not href:
                continue
            low_href = href.lower()
            if a.find_parent("div", class_="su-spoiler"):
                if "filekeeper.net/" in low_href and href.startswith("http"):
                    if href not in fk_parts:
                        fk_parts.append(href)
                continue
            if href in seen:
                continue
            if low_href.startswith("magnet:?"):
                seen.add(href)
                mirror_name = FitGirlClient._detect_mirror_name(a)
                label = f"Tải Torrent (Magnet - {mirror_name})" if mirror_name else "Tải Torrent (Magnet)"
                links.append({"title": label, "url": href, "kind": LINK_TORRENT})
            elif low_href.endswith(".torrent"):
                seen.add(href)
                mirror_name = FitGirlClient._detect_mirror_name(a)
                label = f"Tải tệp .torrent ({mirror_name})" if mirror_name else "Tải tệp .torrent"
                links.append({"title": label, "url": href, "kind": LINK_TORRENT})

        if fk_parts:
            filtered_fk = [u for u in fk_parts if not is_non_english_fitgirl_pack(u)]
            if filtered_fk:
                fk_parts = filtered_fk
            links.append({
                "title": f"Tải Siêu Tốc Direct CDN (FileKeeper · {len(fk_parts)} phần)",
                "url": "fitgirl-direct:" + "|".join(fk_parts),
                "kind": LINK_TORRENT,
            })

        # 2. Direct hosters & torrent mirror pages inside Download Mirrors lists
        for h3 in content_node.find_all(["h3", "h4"]):
            heading = h3.get_text(" ").strip().lower()
            if "download mirrors" not in heading:
                continue
            ul = h3.find_next_sibling("ul")
            if not ul:
                continue
            for a in ul.find_all("a"):
                if a.find_parent("div", class_="su-spoiler"):
                    continue
                href = (a.get("href") or "").strip()
                if not href or href in seen or not href.startswith("http"):
                    continue
                if any(dom in href.lower() for dom in _IGNORED_DOMAINS):
                    continue
                label = " ".join(a.get_text(" ").split()).strip()
                if not label or label.lower() in ("idm", "jdownloader"):
                    continue
                if label.lower().startswith("filehoster:"):
                    label = label.split(":", 1)[1].strip() or label
                elif label.lower() == ".torrent file only":
                    label = "Tệp .torrent ( trình duyệt )"
                seen.add(href)
                links.append({"title": label, "url": href, "kind": LINK_WEB})

        return links

    @staticmethod
    def _detect_mirror_name(a_tag: bs4.Tag) -> str:
        """Find the torrent index name (e.g. 1337x, RuTor, Tapochek) inside the same <li>."""
        li = a_tag.find_parent("li")
        if not li:
            return ""
        for other in li.find_all("a"):
            if other is a_tag:
                break
            txt = " ".join(other.get_text(" ").split()).strip()
            if txt and txt.lower() not in ("magnet", ".torrent file only"):
                return txt
        return ""

    # ------------------------------------------------------------ torrent & direct CDN resolution

    def _resolve_filekeeper_part(self, part_url: str) -> dict:
        """Resolve a single FileKeeper.net page URL into a direct CDN URL + filename (+ size if present)."""
        from app.core.online_fix.aria2_downloader import parse_size_to_bytes

        resp = self._get(part_url, "filekeeper-page", referer=FITGIRL_BASE_URL + "/")
        soup = bs4.BeautifulSoup(resp.text, "html.parser")
        cd = soup.find(id="download-countdown")
        code = (cd.get("data-code") if cd else "") or part_url.rstrip("/").split("/")[-2]
        rand = (cd.get("data-rand") if cd else "") or ""
        method = (cd.get("data-method") if cd else "") or "Free download"
        filename = urllib.parse.unquote(part_url.rstrip("/").split("/")[-1])

        size_bytes = 0
        m_sz = re.search(
            r"<p[^>]*font-semibold[^>]*>\s*([\d\.]+\s*(?:B|KB|MB|GB|TB|KiB|MiB|GiB|TiB))\s*</p>",
            resp.text,
            re.IGNORECASE,
        )
        if m_sz:
            size_bytes = parse_size_to_bytes(m_sz.group(1))

        started = time.monotonic()
        try:
            r2 = self.session.post(
                part_url,
                data={
                    "op": "download2",
                    "id": code,
                    "rand": rand,
                    "referer": "",
                    "method_free": method,
                    "down_direct": "1",
                },
                headers={"Referer": part_url},
                allow_redirects=False,
                timeout=PAGE_TIMEOUT,
            )
        except requests.RequestException as e:
            logger.warning(f"{TAG} FileKeeper POST failed for {part_url}: {e}")
            raise OnlineFixError(f"Không lấy được link tải trực tiếp từ FileKeeper ({e.__class__.__name__}).")

        cdn_url = (r2.headers.get("Location") or "").strip()
        elapsed = time.monotonic() - started
        if not cdn_url or not cdn_url.startswith("http"):
            logger.warning(f"{TAG} FileKeeper POST returned HTTP {r2.status_code} without Location in {elapsed:.2f}s ({part_url})")
            raise OnlineFixError("FileKeeper không trả về liên kết tải trực tiếp. Hãy chọn nguồn Torrent.")
        logger.debug(f"{TAG} FileKeeper resolved {filename!r} -> CDN in {elapsed:.2f}s")
        result = {"url": cdn_url, "out": filename}
        if size_bytes > 0:
            result["size"] = size_bytes
        return result

    def _try_fetch_torrent_from_infohash(self, magnet_url: str) -> str:
        """
        Try resolving a magnet:? infohash into an HTTP .torrent URL via public torrent caches
        so aria2c skips the slow magnet [METADATA] phase completely.
        """
        m = re.search(r"xt=urn:btih:([0-9a-fA-F]{40})", magnet_url)
        if not m:
            return ""
        ih = m.group(1).upper()
        for cache_url in (
            f"https://itorrents.org/torrent/{ih}.torrent",
            f"https://btcache.me/torrent/{ih}",
        ):
            started = time.monotonic()
            try:
                resp = self.session.get(cache_url, timeout=6, headers={"Referer": ""})
                elapsed = time.monotonic() - started
                if resp.status_code == 200 and len(resp.content) > 200 and resp.content.startswith(b"d"):
                    logger.info(f"{TAG} Cached .torrent found for infohash {ih[:10]}… ({len(resp.content)} bytes in {elapsed:.2f}s)")
                    return cache_url
            except requests.RequestException as e:
                logger.debug(f"{TAG} Torrent cache {cache_url} unavailable: {e}")
        return ""

    def resolve_torrent_download(self, raw_url: str, referer: str = "") -> str:
        """Resolve a FitGirl torrent link, magnet URI, or fitgirl-direct: CDN bundle."""
        url = raw_url.strip()
        if url.startswith("fitgirl-direct:"):
            import concurrent.futures
            part_urls = [p.strip() for p in url[len("fitgirl-direct:"):].split("|") if p.strip()]
            if not part_urls:
                raise OnlineFixError("Danh sách phần tải trực tiếp trống.")
            started = time.monotonic()
            logger.info(f"{TAG} Resolving {len(part_urls)} FileKeeper direct CDN part(s)...")
            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                resolved_items = list(pool.map(self._resolve_filekeeper_part, part_urls))
            logger.info(f"{TAG} Resolved {len(resolved_items)} direct CDN part(s) in {time.monotonic() - started:.2f}s")
            return "aria2-list:" + json.dumps(resolved_items)

        if url.startswith("magnet:?"):
            cached_torrent = self._try_fetch_torrent_from_infohash(url)
            if cached_torrent:
                return cached_torrent
            logger.info(f"{TAG} Resolved torrent source directly (magnet): {url[:120]}")
            return url

        if url.lower().endswith(".torrent"):
            logger.info(f"{TAG} Resolved torrent source directly (.torrent): {url[:120]}")
            return url

        resp = self._get(url, "resolve", referer=referer or FITGIRL_BASE_URL + "/")
        soup = bs4.BeautifulSoup(resp.text, "html.parser")
        magnet = next(
            (a.get("href") for a in soup.find_all("a") if (a.get("href") or "").startswith("magnet:?")),
            None,
        )
        if magnet:
            cached_torrent = self._try_fetch_torrent_from_infohash(magnet)
            if cached_torrent:
                return cached_torrent
            logger.info(f"{TAG} Resolved magnet from page: {magnet[:120]}")
            return magnet
        torrent = next(
            (a.get("href") for a in soup.find_all("a") if (a.get("href") or "").lower().endswith(".torrent")),
            None,
        )
        if torrent:
            resolved = urllib.parse.urljoin(resp.url, torrent)
            logger.info(f"{TAG} Resolved .torrent from page: {resolved[:120]}")
            return resolved

        logger.warning(f"{TAG} Resolve {raw_url[:120]}: no magnet or .torrent found")
        raise OnlineFixError("Không tìm thấy liên kết magnet hoặc .torrent trên trang này.")

