"""Find game / lobby / OTP codes in chat messages, so the overlay can copy them for you.

Deliberately conservative: a wrong guess overwrites the clipboard, so ordinary caps-lock chatter ("HAHA", "NICE",
"THANKS", "OK") must not match. Two ways a code is recognised:

1. A line that is nothing but one token, in capitals / digits:
     ABCKDK-KWKDWKW-AWDKWDKW-9992M   dashed groups: a digit somewhere, a hard-to-pronounce group, or 3+ groups
     JDJWKWJR / JWKD                 letters only: needs a run of 4+ consonants (random letters, not a word)
     89D2 / 9992M                    letters + digits (4 or more characters)
     483920 / 123-456                6-8 digits (OTP)
2. A word that announces a code (code / mã / otp / pass / key / lobby / room / phòng / pin) followed by the
   token, in any case: "lobby code: ab12cd", "mã: 483920", "pass 9X2K".
"""

from __future__ import annotations

import re

_VOWELS = set("AEIOUY")
_TRIM = " \t\r\n`'\"*_.,;:!?()<>"
_TOKEN = re.compile(r"[A-Z0-9]+(?:-[A-Z0-9]+)*")
_KEYWORD = re.compile(
    r"(?<![\w])(?:code|mã|otp|pass(?:word)?|mật khẩu|key|lobby|room|phòng|pin)(?![\w])"
    r"(?:\s+(?:là|la|is))?\s*[:：=\-]?\s*([A-Za-z0-9][A-Za-z0-9-]{2,47})(?![\w-])", re.I)
_SPACE = re.compile(r"\s")
_MIN_ANNOUNCED = 4
_MAX_LEN = 48


def _consonant_run(token: str) -> int:
    """Longest stretch of letters that are not vowels (digits and dashes break it)."""
    best = run = 0
    for ch in token:
        if ch.isalpha() and ch not in _VOWELS:
            run += 1
            best = max(best, run)
        else:
            run = 0
    return best


def _has_digit(token: str) -> bool:
    return any(c.isdigit() for c in token)


def _dashed_is_code(token: str) -> bool:
    groups = token.split("-")
    if len(groups) < 2 or any(len(g) < 2 for g in groups) or sum(len(g) for g in groups) < 6:
        return False
    if all(g.isdigit() for g in groups):            # 123-456 is an OTP; dates and phone numbers are not
        return len(groups) == 2 and all(len(g) == 3 for g in groups)
    return _has_digit(token) or len(groups) >= 3 or any(_consonant_run(g) >= 4 for g in groups)


def is_code(token: str) -> bool:
    """Whether a whole line, already stripped, looks like a code."""
    if not token or len(token) > _MAX_LEN or not _TOKEN.fullmatch(token):
        return False
    if "-" in token:
        return _dashed_is_code(token)
    n = len(token)
    if token.isdigit():
        return 6 <= n <= 8
    if len(set(token)) < 3 or n < 4:                # MMMM, HAHA, AAAA
        return False
    if _has_digit(token):
        return True
    return _consonant_run(token) >= 4


def find_code(text: str) -> str | None:
    """The first code in a message, or None."""
    if not text:
        return None
    for line in text.splitlines():
        token = line.strip(_TRIM)
        if token and not _SPACE.search(token) and is_code(token):
            return token
    pos = 0
    while (m := _KEYWORD.search(text, pos)) is not None:
        token = m.group(1).strip("-")
        if len(token) >= _MIN_ANNOUNCED and (_has_digit(token) or token.isupper() or "-" in token):
            return token
        pos = m.start(1)        # the rejected token may itself be a keyword: "lobby code: ab12cd"
    return None
