"""Plain data types shared by the Steam chat bridge and the overlay UI."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


DM_GROUP = "dm"   # the "group id" of a private chat: the room is (DM_GROUP, <friend account id>)
EMBED_YOUTUBE = "youtube"
EMBED_STORE = "store"
EMBED_OG = "og"


class BridgeState(str, Enum):
    STOPPED = "stopped"                    # bridge not started
    STEAM_NOT_RUNNING = "steam_not_running"
    DEBUG_DISABLED = "debug_disabled"      # Steam runs but remote debugging is off (marker file missing)
    RESTART_REQUIRED = "restart_required"  # marker file exists, Steam was started before it was created
    PORT_CONFLICT = "port_conflict"        # something else answers on the debug port
    CONNECTING = "connecting"
    NOT_READY = "not_ready"                # attached, but the friends/chat UI has not loaded yet
    NO_ROOM = "no_room"                    # no room selected, or the selected room is not in the chat list
    CONNECTED = "connected"
    ERROR = "error"


@dataclass(frozen=True)
class BridgeStatus:
    state: BridgeState
    detail: str = ""

    @property
    def connected(self) -> bool:
        return self.state is BridgeState.CONNECTED


@dataclass(frozen=True)
class ChatRoomInfo:
    group_id: str
    chat_id: str
    name: str
    is_default: bool = False
    voice: bool = False


@dataclass(frozen=True)
class ChatGroupInfo:
    group_id: str
    name: str
    rooms: tuple[ChatRoomInfo, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class ChatMember:
    """A member of the selected chat group, as offered by the @-mention suggestions."""
    account_id: int
    name: str                # persona name: what Steam writes after "@" in a mention
    nickname: str = ""       # the user's own nickname for this friend (searchable, never sent)
    is_self: bool = False
    online: bool = False     # signed in to Steam (online / away / busy ...): /ready and /team count these


@dataclass(frozen=True)
class ChatEmbed:
    """Rich media card attached to a chat message (YouTube video, Steam Store app, or OpenGraph link)."""
    kind: str                # EMBED_YOUTUBE | EMBED_STORE | EMBED_OG
    item_id: str             # 11-char YouTube video id, numeric Steam AppID, or canonical https:// URL
    url: str                 # canonical https:// URL
    title: str = ""          # inline title (e.g. from [og title="..."])
    subtitle: str = ""       # inline description (e.g. from [og desc="..."])
    thumb_url: str = ""      # inline preview image URL (e.g. from [og img="..."])


@dataclass(frozen=True)
class ChatMessage:
    group_id: str
    chat_id: str
    account_id: int
    sender: str
    text: str                # plain text (BBCode already converted)
    timestamp: int           # Steam RTime32 (unix seconds)
    ordinal: int = 0
    is_self: bool = False
    history: bool = False    # loaded from the room's backlog on (re)connect, not received live
    local: bool = False      # local echo of a message sent from the overlay
    images: tuple[str, ...] = ()         # attached image URLs (shown as thumbnails)
    embeds: tuple[ChatEmbed, ...] = ()   # rich preview cards (YouTube / Steam Store)
    mentions: tuple[str, ...] = ()       # "@Name" texts of the [mention] tags, as they appear in `text`
    mentioned: bool = False              # mentions us (or @all / @online): highlighted in the overlay
    personal: bool = False               # mentions us by name (not just @all / @online)

    @property
    def key(self) -> tuple[int, int, int]:
        return (self.timestamp, self.ordinal, self.account_id)
