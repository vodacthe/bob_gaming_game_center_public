"""Minimal synchronous Chrome DevTools Protocol client (one target, one websocket).

`call()` is thread-safe; responses are matched by id on a reader thread, events go to `on_event`.
Everything is loopback-only and bypasses the Windows/system proxy on purpose (Network Unblock may
install a PAC, and `websockets` honours proxy environment variables by default).
"""

from __future__ import annotations

import itertools
import json
import logging
import threading
import urllib.request
from typing import Callable

logger = logging.getLogger(__name__)

DEFAULT_PORT = 8080
_NO_PROXY_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


class CdpError(Exception):
    """Protocol error, JS exception or lost connection."""


class CdpUnavailable(CdpError):
    """Nothing (usable) listens on the debug port."""


def list_targets(port: int = DEFAULT_PORT, timeout: float = 2.0) -> list[dict]:
    """GET http://127.0.0.1:<port>/json. Raises CdpUnavailable when nothing answers or it is not CDP."""
    try:
        with _NO_PROXY_OPENER.open(f"http://127.0.0.1:{port}/json", timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
    except (OSError, ValueError) as e:
        raise CdpUnavailable(str(e)) from e
    if not isinstance(data, list):
        raise CdpUnavailable("unexpected /json payload")
    return [t for t in data if isinstance(t, dict)]


def find_target(targets: list[dict], title: str) -> dict | None:
    for t in targets:
        if t.get("title") == title and t.get("webSocketDebuggerUrl"):
            return t
    return None


class _Pending:
    __slots__ = ("event", "response")

    def __init__(self):
        self.event = threading.Event()
        self.response: dict | None = None


class CdpSession:
    """One websocket to one CDP target."""

    def __init__(self, ws_url: str, on_event: Callable[[str, dict], None] | None = None,
                 on_close: Callable[[], None] | None = None, connect_timeout: float = 5.0):
        from websockets.sync.client import connect

        self._on_event = on_event
        self._on_close = on_close
        self._ids = itertools.count(1)
        self._pending: dict[int, _Pending] = {}
        self._lock = threading.Lock()
        self._closed = threading.Event()
        try:
            self._ws = connect(ws_url, max_size=None, open_timeout=connect_timeout, proxy=None,
                               compression=None)
        except Exception as e:
            raise CdpUnavailable(f"websocket connect failed: {e}") from e
        self._reader = threading.Thread(target=self._read_loop, name="SteamChat-CDP", daemon=True)
        self._reader.start()

    @property
    def closed(self) -> bool:
        return self._closed.is_set()

    def call(self, method: str, params: dict | None = None, timeout: float = 10.0) -> dict:
        if self.closed:
            raise CdpError("session closed")
        msg_id = next(self._ids)
        pending = _Pending()
        with self._lock:
            self._pending[msg_id] = pending
        try:
            self._ws.send(json.dumps({"id": msg_id, "method": method, "params": params or {}}))
        except Exception as e:
            with self._lock:
                self._pending.pop(msg_id, None)
            self.close()
            raise CdpError(f"send failed: {e}") from e
        if not pending.event.wait(timeout):
            with self._lock:
                self._pending.pop(msg_id, None)
            raise CdpError(f"{method} timed out after {timeout:.0f}s")
        response = pending.response
        if response is None:
            raise CdpError("connection lost")
        if "error" in response:
            raise CdpError(f"{method}: {response['error'].get('message', response['error'])}")
        return response.get("result", {})

    def evaluate(self, expression: str, timeout: float = 10.0, await_promise: bool = True):
        """Runtime.evaluate with returnByValue; raises CdpError on a JS exception."""
        result = self.call("Runtime.evaluate", {
            "expression": expression,
            "returnByValue": True,
            "awaitPromise": await_promise,
        }, timeout=timeout)
        if "exceptionDetails" in result:
            details = result["exceptionDetails"]
            text = (details.get("exception") or {}).get("description") or details.get("text") or "JS exception"
            raise CdpError(text.splitlines()[0][:300])
        return (result.get("result") or {}).get("value")

    def close(self) -> None:
        if self._closed.is_set():
            return
        self._closed.set()
        try:
            self._ws.close()
        except Exception:
            pass
        self._fail_pending()

    def _fail_pending(self) -> None:
        with self._lock:
            pending, self._pending = self._pending, {}
        for p in pending.values():
            p.event.set()

    def _read_loop(self) -> None:
        try:
            for raw in self._ws:
                try:
                    msg = json.loads(raw)
                except ValueError:
                    continue
                msg_id = msg.get("id")
                if msg_id is not None:
                    with self._lock:
                        pending = self._pending.pop(msg_id, None)
                    if pending is not None:
                        pending.response = msg
                        pending.event.set()
                elif self._on_event is not None and "method" in msg:
                    try:
                        self._on_event(msg["method"], msg.get("params") or {})
                    except Exception:
                        logger.exception("[SteamChat] CDP event handler failed")
        except Exception as e:
            if not self._closed.is_set():
                logger.info(f"[SteamChat] CDP connection closed: {e}")
        finally:
            self._closed.set()
            self._fail_pending()
            if self._on_close is not None:
                try:
                    self._on_close()
                except Exception:
                    logger.exception("[SteamChat] CDP close handler failed")
