"""Game helpers behind the overlay's own commands (Qt-free, so everything here is easy to test).

* `/timer 5m [-say] Boss`  local countdown timers (an alert when one ends; `-say` also tells the room)
* `/afk [10p] [message]`   away mode: answers people who tag you, lists what you missed (`/back` ends it)
* `/alert <word>`          keywords that count like a mention (highlight, sound)
* `/join <name>`           join a friend's game like the right-click "Join Game" (`steam://joinlobby/...`)
* `/invite <name|all>`      invite a friend (or every online member of the room) to your lobby / game
* `/chat <name>`           open the private chat with a friend in the overlay (history included, like a group room)
* `/ready [text]`          ready check: "rồi", "vô", "ok", "vào", ... from the others are counted
* `/team N [names]`        random teams from the online members (or from the names given)
* `/pick a b c`            random choice
"""

from __future__ import annotations

import random
import re
import time
import unicodedata
from collections.abc import Sequence
from dataclasses import dataclass, field
from urllib.parse import quote

TIMER = "/timer"
AFK = "/afk"
BACK = "/back"
ALERT = "/alert"
JOIN = "/join"
INVITE = "/invite"
CHAT = "/chat"
READY = "/ready"
TEAM = "/team"
PICK = "/pick"

MAX_TIMERS = 10
MAX_TIMER_SECONDS = 24 * 3600
MAX_AFK_SECONDS = 12 * 3600
MAX_LABEL = 60
MAX_KEYWORDS = 20
MAX_KEYWORD_LEN = 40
READY_SECONDS = 120.0
STEAMID64_BASE = 76561197960265728

TIMER_USAGE = ("Dùng: /timer <thời gian> [-say] [tên], vd /timer 5m Boss · /timer 90s · /timer 1:30 -say Hồi sinh · "
                "/timer stop (số không có đơn vị là phút)")
TEAM_USAGE = "Dùng: /team <số đội 2-8> [tên người chơi...], không ghi tên thì chia các thành viên đang online"
PICK_USAGE = "Dùng: /pick <lựa chọn 1> <lựa chọn 2> ... (có dấu phẩy thì tách theo dấu phẩy)"


def fold(text: str) -> str:
    """Lower-case without accents (đ -> d): "Vào Rồi" and "vao roi" compare equal."""
    text = unicodedata.normalize("NFD", text.replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in text if unicodedata.category(c) != "Mn").casefold()


# ---- durations -------------------------------------------------------------------------------------------
_CLOCK = re.compile(r"^(\d+):(\d{1,2})(?::(\d{1,2}))?$")
_PARTS = re.compile(r"(\d+)([a-z]*)")
_UNITS = {"h": 3600, "g": 3600, "gio": 3600, "hr": 3600, "m": 60, "p": 60, "min": 60, "ph": 60, "phut": 60,
          "s": 1, "sec": 1, "giay": 1}


def parse_duration(token: str) -> int | None:
    """Seconds for `90s`, `5m` / `5p`, `1h30m`, `1m30s`, `5:00`, `1:02:03`; a bare number is minutes."""
    token = fold(token.strip())
    if not token:
        return None
    clock = _CLOCK.match(token)
    if clock:
        a, b, c = clock.group(1), clock.group(2), clock.group(3)
        return int(a) * 3600 + int(b) * 60 + int(c) if c is not None else int(a) * 60 + int(b)
    parts = _PARTS.findall(token)
    if not parts or "".join(n + u for n, u in parts) != token:
        return None
    if len(parts) == 1 and parts[0][1] == "":
        return int(parts[0][0]) * 60
    total = 0
    for number, unit in parts:
        if unit not in _UNITS:
            return None
        total += int(number) * _UNITS[unit]
    return total


def format_duration(seconds: float) -> str:
    seconds = max(0, int(round(seconds)))
    h, rest = divmod(seconds, 3600)
    m, s = divmod(rest, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


# ---- command parsing -------------------------------------------------------------------------------------
@dataclass(frozen=True)
class TimerCommand:
    kind: str = "list"          # "start" | "list" | "stop"
    seconds: int = 0
    label: str = ""
    say: bool = False
    target: str = ""            # stop: "all" or a timer number
    error: str = ""


@dataclass(frozen=True)
class AfkCommand:
    stop: bool = False
    seconds: int | None = None      # None = until /back
    message: str = ""
    error: str = ""


@dataclass(frozen=True)
class AlertCommand:
    kind: str = "list"          # "list" | "clear" | "toggle"
    word: str = ""


@dataclass(frozen=True)
class JoinCommand:
    name: str = ""


@dataclass(frozen=True)
class ReadyCommand:
    stop: bool = False
    text: str = ""


@dataclass(frozen=True)
class TeamCommand:
    count: int = 0
    names: tuple[str, ...] = ()
    error: str = ""


@dataclass(frozen=True)
class PickCommand:
    options: tuple[str, ...] = ()
    error: str = ""


def _split(text: str, command: str) -> tuple[bool, str]:
    """(is `text` this command, what follows it)."""
    head, _sep, rest = text.strip().partition(" ")
    if head.lower() != command:
        return False, ""
    return True, rest.strip()


_STOP_WORDS = ("stop", "off", "huy", "cancel", "tat", "xong")


def parse_timer(text: str) -> TimerCommand | None:
    ok, rest = _split(text, TIMER)
    if not ok:
        return None
    if not rest:
        return TimerCommand("list")
    first, _sep, after = rest.partition(" ")
    if fold(first) in _STOP_WORDS or fold(first) in ("xoa", "clear"):
        return TimerCommand("stop", target=(after.strip() or "all").lower())
    seconds = parse_duration(first)
    if seconds is None:
        return TimerCommand(error=TIMER_USAGE)
    if not 1 <= seconds <= MAX_TIMER_SECONDS:
        return TimerCommand(error="Thời gian hẹn phải từ 1 giây đến 24 giờ")
    after = after.strip()
    say = False
    if after.lower().startswith("-say"):
        say, after = True, after[4:].strip()
    return TimerCommand("start", seconds, after[:MAX_LABEL] or "Hết giờ", say)


def parse_afk(text: str) -> AfkCommand | None:
    ok, rest = _split(text, AFK)
    if ok:
        if fold(rest) in _STOP_WORDS or fold(rest) == "back":
            return AfkCommand(stop=True)
        first, _sep, after = rest.partition(" ")
        seconds = parse_duration(first) if first and first[0].isdigit() else None
        message = after.strip() if seconds is not None else rest
        if seconds is not None and not 1 <= seconds <= MAX_AFK_SECONDS:
            return AfkCommand(error="Thời gian AFK phải từ 1 giây đến 12 giờ")
        return AfkCommand(seconds=seconds, message=message[:MAX_LABEL * 2])
    ok, rest = _split(text, BACK)
    return AfkCommand(stop=True) if ok and not rest else None


def parse_alert(text: str) -> AlertCommand | None:
    ok, rest = _split(text, ALERT)
    if not ok:
        return None
    if not rest:
        return AlertCommand("list")
    if fold(rest) in ("clear", "xoa", "off"):
        return AlertCommand("clear")
    return AlertCommand("toggle", rest[:MAX_KEYWORD_LEN])


def parse_join(text: str) -> JoinCommand | None:
    ok, rest = _split(text, JOIN)
    return JoinCommand(rest) if ok else None


def parse_ready(text: str) -> ReadyCommand | None:
    ok, rest = _split(text, READY)
    if not ok:
        return None
    if fold(rest) in _STOP_WORDS:
        return ReadyCommand(stop=True)
    return ReadyCommand(text=rest[:80])


def _names(text: str) -> tuple[str, ...]:
    pieces = text.split(",") if "," in text else text.split()
    return tuple(p.strip() for p in pieces if p.strip())


def parse_team(text: str) -> TeamCommand | None:
    ok, rest = _split(text, TEAM)
    if not ok:
        return None
    first, _sep, after = rest.partition(" ")
    if not first.isdigit() or not 2 <= int(first) <= 8:
        return TeamCommand(error=TEAM_USAGE)
    return TeamCommand(int(first), _names(after))


def parse_pick(text: str) -> PickCommand | None:
    ok, rest = _split(text, PICK)
    if not ok:
        return None
    options = _names(rest)
    return PickCommand(options) if len(options) >= 2 else PickCommand(error=PICK_USAGE)


# ---- random ------------------------------------------------------------------------------------------------
rng = random.SystemRandom()


def split_teams(names: Sequence[str], count: int) -> list[list[str]]:
    """`names` shuffled and dealt into `count` teams of (nearly) equal size."""
    shuffled = list(names)
    rng.shuffle(shuffled)
    return [shuffled[i::count] for i in range(count)]


def teams_text(teams: Sequence[Sequence[str]]) -> str:
    return "🎲 Chia đội: " + " | ".join(f"Đội {i}: {', '.join(t)}" for i, t in enumerate(teams, 1))


def pick_text(options: Sequence[str]) -> str:
    choice = rng.choice(list(options))
    return f"🎲 Chọn ngẫu nhiên: {choice} (trong: {', '.join(options)})"


# ---- keyword alerts --------------------------------------------------------------------------------------
def normalize_keywords(words) -> list[str]:
    """Trimmed, de-duplicated (accent / case-insensitive), at most MAX_KEYWORDS."""
    out: list[str] = []
    seen: set[str] = set()
    for w in words or []:
        w = str(w).strip()[:MAX_KEYWORD_LEN]
        if w and fold(w) not in seen:
            seen.add(fold(w))
            out.append(w)
    return out[:MAX_KEYWORDS]


def find_keywords(text: str, keywords: Sequence[str]) -> tuple[str, ...]:
    """Keywords that appear in `text` as whole words, ignoring case and accents ("vao game" matches "vào game").

    Each is returned as it is written in the text when it appears there literally (so it can be highlighted).
    """
    if not keywords or not text:
        return ()
    folded = fold(text)
    found = []
    for word in keywords:
        key = fold(word)
        if key and re.search(rf"(?<![a-z0-9]){re.escape(key)}(?![a-z0-9])", folded):
            literal = re.search(re.escape(word), text, re.I)
            found.append(literal.group(0) if literal else word)
    return tuple(dict.fromkeys(found))


# ---- ready check -----------------------------------------------------------------------------------------
_READY_CORE = {"r", "rdy", "ready", "ok", "oke", "okay", "oki", "okie", "k", "roi", "vo", "vao", "sang", "xong",
               "yes", "yep", "go", "gogo", "co", "u", "uh", "duoc", "dc", "dzo", "zo"}
_READY_FILL = {"san", "nha", "nhe", "ne", "nhen", "day", "a", "ah", "da", "oi", "luon", "lien", "r", "ss", "that",
               "minh", "tui", "toi", "em", "anh", "ban"}
_READY_EMOJI = set("👍✅🆗☑✔👌🙆")


def is_ready_reply(text: str) -> bool:
    """A short "I am ready" answer: rồi / vô / ok / vào / sẵn sàng / ready / 👍 (accents, case and filler words
    like "nha", "rồi nè", "vô đây" do not matter). Anything with another word ("không vào") is not one."""
    text = (text or "").strip()
    if not text or len(text) > 40:
        return False
    tokens = re.findall(r"[a-z0-9]+", fold(text))
    if not tokens:
        return any(c in _READY_EMOJI for c in text)
    if len(tokens) > 4 or any(t not in _READY_CORE | _READY_FILL for t in tokens):
        return False
    return any(t in _READY_CORE for t in tokens) or tokens[:2] == ["san", "sang"]


@dataclass
class ReadyCheck:
    """One running ready check: who answered, against the online members of the room."""

    note: str = ""
    deadline: float = field(default_factory=lambda: time.monotonic() + READY_SECONDS)
    ready: dict[int, str] = field(default_factory=dict)      # account id -> name

    def mark(self, account_id: int, name: str) -> bool:
        """True when this answer is new."""
        if account_id in self.ready:
            return False
        self.ready[account_id] = name
        return True

    @staticmethod
    def expected(members) -> dict[int, str]:
        """The online members other than us: whoever the check waits for."""
        return {m.account_id: m.name for m in members if m.online and not m.is_self}

    def waiting(self, members) -> list[str]:
        return [name for acct, name in self.expected(members).items() if acct not in self.ready]

    def complete(self, members) -> bool:
        expected = self.expected(members)
        return bool(expected) and all(a in self.ready for a in expected)

    def summary(self, members) -> str:
        expected = self.expected(members)
        total = len(expected) or len(self.ready)
        text = f"Sẵn sàng {len(self.ready)}/{total}: {', '.join(self.ready.values()) or '—'}"
        waiting = self.waiting(members)
        return text + (f" · chờ: {', '.join(waiting)}" if waiting else "")


# ---- friends: /join and /invite ---------------------------------------------------------------------------
@dataclass(frozen=True)
class FriendInfo:
    """An online Steam friend, with what the friends list knows about the game they are in."""

    account_id: int
    name: str
    nickname: str = ""
    display: str = ""           # what Steam's friends list shows (name plus our nickname)
    app_id: int = 0
    game: str = ""
    ingame: bool = False
    joinable: bool = False      # Steam's `is_in_joinable_game`: the right-click menu offers "Join Game"
    lobby_id: str = ""          # their lobby ("" when not in a valid lobby)
    connect: str = ""
    away: bool = False
    online: bool = True         # /chat also lists offline friends (a private message can wait for them)

    @property
    def steam_id64(self) -> int:
        return STEAMID64_BASE + self.account_id

    @property
    def label(self) -> str:
        return self.game or (f"app {self.app_id}" if self.app_id else "")

    def names(self) -> list[str]:
        return [n for n in dict.fromkeys((self.name, self.nickname, self.display)) if n]

    def join_url(self) -> str | None:
        """The link Steam's "Join Game" opens: their lobby, else their game with its connect string."""
        if not (self.joinable and self.ingame and self.app_id > 0 and self.account_id > 0):
            return None
        if self.lobby_id.isdigit() and int(self.lobby_id) > 0:
            return f"steam://joinlobby/{self.app_id}/{self.lobby_id}/{self.steam_id64}"
        url = f"steam://rungame/{self.app_id}/{self.steam_id64}"
        return url + f"/{quote(self.connect, safe='')}" if self.connect else url


def friends_from_payload(data) -> list[FriendInfo]:
    out = []
    for d in data or []:
        if not isinstance(d, dict):
            continue
        try:
            friend = FriendInfo(int(d.get("accountId") or 0), str(d.get("name") or "").strip(),
                                str(d.get("nickname") or "").strip(), str(d.get("display") or "").strip(),
                                int(d.get("appId") or 0), str(d.get("game") or "").strip(), bool(d.get("ingame")),
                                bool(d.get("joinable")), str(d.get("lobbyId") or "").strip(),
                                str(d.get("connect") or "").strip(), bool(d.get("away")),
                                bool(d.get("online", True)))
        except (TypeError, ValueError):
            continue
        if friend.account_id > 0 and friend.names():
            out.append(friend)
    return out


def resolve_friend(friends: Sequence[FriendInfo], query: str) -> tuple[FriendInfo | None, list[FriendInfo]]:
    """The friend `query` stands for (name, nickname or display name; exact, else prefix, else part of it, ignoring
    case and accents). Returns (friend or None, the candidates when several match)."""
    q = fold(query.strip())
    if not q:
        return None, []
    for stage in (lambda n: n == q, lambda n: n.startswith(q), lambda n: q in n):
        hits = [f for f in friends if any(stage(fold(n)) for n in f.names())]
        if len(hits) == 1:
            return hits[0], []
        if hits:
            return None, hits
    return None, []


def resolve_friend_and_message(friends: Sequence[FriendInfo], text: str) -> tuple[FriendInfo | None, list[FriendInfo], str]:
    """`/chat <friend> [message]`: names have spaces, so the longest leading words that name exactly one friend win
    (an exact name first, then a unique prefix / part of a name); the words after them are the message.
    Returns (friend or None, the candidates when the name is ambiguous, message)."""
    words = text.split()
    if not words:
        return None, [], ""
    for k in range(len(words), 0, -1):                     # exact name: "Bob Boobs gà" -> "Bob Boobs" + "gà"
        q = fold(" ".join(words[:k]))
        hits = [f for f in friends if any(fold(n) == q for n in f.names())]
        if len(hits) == 1:
            return hits[0], [], " ".join(words[k:])
    for k in range(len(words), 0, -1):                     # then the longest prefix that resolves on its own
        friend, several = resolve_friend(friends, " ".join(words[:k]))
        if friend is not None:
            return friend, [], " ".join(words[k:])
        if several:
            return None, several, ""
    return None, [], ""


@dataclass(frozen=True)
class ChatCommand:
    target: str = ""            # a friend's name / nickname, optionally followed by a message to send


CHAT_USAGE = "Dùng: /chat <tên bạn bè> [tin nhắn] để mở chat riêng (và gửi luôn tin nhắn); quay lại nhóm: /group hoặc /room"


def parse_chat(text: str) -> ChatCommand | None:
    ok, rest = _split(text, CHAT)
    return ChatCommand(rest) if ok else None


@dataclass(frozen=True)
class InviteCommand:
    target: str = ""            # a friend's name, or "all"


INVITE_USAGE = "Dùng: /invite <tên bạn bè> hoặc /invite all (mời mọi thành viên đang online của nhóm chat)"
MAX_INVITES = 30


def parse_invite(text: str) -> InviteCommand | None:
    ok, rest = _split(text, INVITE)
    return InviteCommand(rest) if ok else None


@dataclass
class InvitePlan:
    ids: list[int] = field(default_factory=list)
    names: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)        # why somebody was left out
    error: str = ""


def plan_invite(target: str, friends: Sequence[FriendInfo], members, my_lobby: str = "") -> InvitePlan:
    """Who a `/invite <target>` goes to. `friends` are the online friends, `members` the room's ChatMembers."""
    target = target.strip()
    if not target:
        return InvitePlan(error=INVITE_USAGE)
    by_id = {f.account_id: f for f in friends}
    if fold(target) == "all":
        plan = InvitePlan()
        outsiders = 0
        for m in members:
            if m.is_self or not m.online:
                continue
            friend = by_id.get(m.account_id)
            if friend is None:
                outsiders += 1
            elif my_lobby and friend.lobby_id == my_lobby:
                plan.skipped.append(f"{friend.name} đã ở trong lobby")
            else:
                plan.ids.append(friend.account_id)
                plan.names.append(friend.name)
        if outsiders:
            plan.skipped.append(f"{outsiders} người không phải bạn bè")
        if not plan.ids:
            plan.error = "Không có thành viên online nào để mời" + (f" ({'; '.join(plan.skipped)})" if plan.skipped else "")
        elif len(plan.ids) > MAX_INVITES:
            plan.skipped.append(f"chỉ mời {MAX_INVITES} người đầu")
            plan.ids, plan.names = plan.ids[:MAX_INVITES], plan.names[:MAX_INVITES]
        return plan
    friend, several = resolve_friend(friends, target)
    if friend is None:
        if several:
            return InvitePlan(error=f"Nhiều bạn khớp \"{target}\": " + ", ".join(f.name for f in several[:6]))
        return InvitePlan(error=f"Không thấy bạn bè online nào tên \"{target}\"")
    if my_lobby and friend.lobby_id == my_lobby:
        return InvitePlan(error=f"{friend.name} đã ở trong lobby của bạn rồi")
    return InvitePlan([friend.account_id], [friend.name])
