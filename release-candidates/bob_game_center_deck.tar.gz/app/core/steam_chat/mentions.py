"""@-mentions for the chat input: suggestions while typing, and the BBCode Steam expects when sending.

Steam's own chat box turns `@name` into `[mention=ACCOUNTID]@name[/mention]` when a message is sent
(ChatRoomGroupView.ProcessMentions); `room.SendChatMessage` sends text as-is, so the overlay does the same.
Matching follows Steam: the whole persona name (spaces included) after the "@", case-insensitive, and
`name#<account id in base 36>` to tell apart two members with the same name. `@all` and `@online`
(sent as `[mention=here]`) address the whole group and need the "mention all" permission.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from app.core.steam_chat.models import ChatMember

ALL = "all"
ONLINE = "online"
_META_TARGET = {ALL: "all", ONLINE: "here"}
MAX_QUERY = 32          # an "@" further back than this is not a mention being typed
MAX_SUGGESTIONS = 6


@dataclass(frozen=True)
class MentionCandidate:
    insert: str             # text that goes after "@" ("Name", "Name#1x2y" when ambiguous, "all", "online")
    label: str              # shown in the suggestion list
    detail: str = ""        # nickname, or what a group-wide mention does
    account_id: int = 0     # 0 for @all / @online


def _base36(n: int) -> str:
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    out = ""
    while n:
        n, r = divmod(n, 36)
        out = digits[r] + out
    return out or "0"


def _ambiguous_names(members: Sequence[ChatMember]) -> set[str]:
    seen: set[str] = set()
    dup: set[str] = set()
    for m in members:
        key = m.name.strip().lower()
        (dup if key in seen else seen).add(key)
    return dup


def _boundary(ch: str) -> bool:
    return not (ch.isalnum() or ch == "_")


def active_query(text: str, cursor: int) -> tuple[int, str] | None:
    """(index of the "@", what follows it up to the cursor) when the cursor sits in a mention being typed."""
    before = text[:cursor]
    at = before.rfind("@")
    if at < 0 or (at > 0 and not _boundary(before[at - 1])):      # "a@b" is an e-mail, not a mention
        return None
    query = before[at + 1:]
    if len(query) > MAX_QUERY or "\n" in query:
        return None
    return at, query


def suggest(members: Sequence[ChatMember], query: str, can_all: bool = False, limit: int = MAX_SUGGESTIONS) -> list[MentionCandidate]:
    """Members (never ourselves) whose name or nickname matches `query`, best matches first."""
    q = query.lower()
    ambiguous = _ambiguous_names(members)
    scored = []
    for m in members:
        if m.is_self or not m.name.strip():
            continue
        name, nick = m.name.lower(), m.nickname.lower()
        if not q:
            score = 0
        elif name.startswith(q):
            score = 0
        elif nick.startswith(q):
            score = 1
        elif any(w.startswith(q) for w in name.split()):
            score = 2
        elif q in name or q in nick:
            score = 3
        else:
            continue
        insert = f"{m.name}#{_base36(m.account_id)}" if name.strip() in ambiguous else m.name
        scored.append((score, name, MentionCandidate(insert, m.name, m.nickname, m.account_id)))
    scored.sort(key=lambda s: (s[0], s[1]))
    out = [c for _score, _name, c in scored]
    if can_all:
        metas = []
        if ALL.startswith(q):
            metas.append(MentionCandidate(ALL, "@all", "Nhắc tất cả mọi người"))
        if ONLINE.startswith(q):
            metas.append(MentionCandidate(ONLINE, "@online", "Nhắc người đang online"))
        out = metas + out
    return out[:max(0, limit)]


def apply_mentions(text: str, members: Sequence[ChatMember], can_all: bool = False) -> str:
    """`text` with every `@name` of a known member written as Steam's `[mention=ID]@name[/mention]`."""
    if "@" not in text:
        return text
    ambiguous = _ambiguous_names(members)
    keys: list[tuple[str, str, str]] = []           # (lowercase text after "@", mention target, name shown)
    for m in members:
        name = m.name.strip()
        if not name:
            continue
        keys.append((f"{name}#{_base36(m.account_id)}".lower(), str(m.account_id), name))
        if name.lower() not in ambiguous:           # a bare ambiguous name stays plain text
            keys.append((name.lower(), str(m.account_id), name))
    if can_all:
        keys += [(word, target, word) for word, target in _META_TARGET.items()]
    keys.sort(key=lambda k: -len(k[0]))             # longest first: "Bob Boomer" before "Bob"
    low = text.lower()
    out: list[str] = []
    i = 0
    while i < len(text):
        if text[i] == "@" and (i == 0 or _boundary(text[i - 1])):
            for key, target, shown in keys:
                end = i + 1 + len(key)
                if low.startswith(key, i + 1) and (end >= len(text) or _boundary(text[end])):
                    escaped = shown.replace("[", "\\[").replace("]", "\\]")
                    out.append(f"[mention={target}]@{escaped}[/mention]")
                    i = end
                    break
            else:
                out.append("@")
                i += 1
            continue
        out.append(text[i])
        i += 1
    return "".join(out)


def replace_query(text: str, at: int, cursor: int, candidate: MentionCandidate) -> tuple[str, int]:
    """Put the chosen member in place of "@query": returns the new text and where the cursor goes."""
    rest = text[cursor:]
    inserted = f"@{candidate.insert}"
    if not rest.startswith(" "):
        inserted += " "
    new = text[:at] + inserted + rest
    return new, at + len(inserted) + (1 if rest.startswith(" ") else 0)
