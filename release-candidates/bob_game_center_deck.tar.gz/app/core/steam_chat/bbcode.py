"""Convert the BBCode Steam chat stores in messages into plain text and rich media descriptors."""

from __future__ import annotations

import html
import re
from urllib.parse import parse_qsl, quote, urlsplit

from app.core.steam_chat.models import EMBED_OG, EMBED_STORE, EMBED_YOUTUBE, ChatEmbed

_MAX_LEN = 600
_MAX_IMAGES = 4
_MAX_EMBEDS = 3

# [tag=arg]inner[/tag] pairs whose inner text is what a reader should see
_KEEP_INNER = ("url", "b", "i", "u", "s", "code", "quote", "spoiler", "h1", "h2", "h3", "pre", "noparse")

_EMOTICON = re.compile(r"\[emoticon\](.*?)\[/emoticon\]", re.I | re.S)
# [mention=ACCOUNTID]@Name[/mention]; "all" / "here" (= @online) are the group-wide mentions
_MENTION = re.compile(r"\[mention=(\w+)\](.*?)\[/mention\]", re.I | re.S)
GROUP_MENTIONS = ("all", "here")
_STICKER = re.compile(r"\[sticker\b[^\]]*\](?:.*?\[/sticker\])?", re.I | re.S)
_IMG = re.compile(r"\[img\b[^\]]*\](?:.*?\[/img\])?", re.I | re.S)
# Steam chat uploads: [img src=https://... width=.. height=..][/img]; also the classic [img]url[/img]
_IMG_SRC = re.compile(r"\[img\b[^\]]*?\bsrc=(\"?)(https?://[^\"\s\]]+)\1[^\]]*\]", re.I)
_IMG_INNER = re.compile(r"\[img\]\s*(https?://[^\s\[]+?)\s*\[/img\]", re.I)
# [sticker type="Wink" limit="0"][/sticker] -> 150x150 PNG on Steam's CDN; names may contain spaces ("Your Face")
_STICKER_TYPE = re.compile(r"\[sticker\b[^\]]*?\btype=(?:\"([^\"\]]+)\"|([\w-]+))[^\]]*\]", re.I)
STICKER_URL = "https://community.fastly.steamstatic.com/economy/sticker/"
# chat box slash commands Steam's own client expands before sending
_SLASH_STICKER = re.compile(r"^/sticker\s+([\w-]+(?: [\w-]+)*)\s*$", re.I)
_GIPHY = re.compile(r"\[giphy\b[^\]]*\](?:.*?\[/giphy\])?", re.I | re.S)
_INVITE = re.compile(r"\[(?:lobbyinvite|gameinvite|tradeoffer|inviteurl)\b[^\]]*\](?:.*?\[/\w+\])?", re.I | re.S)
_RANDOM = re.compile(r"\[random\b[^\]]*\](.*?)\[/random\]", re.I | re.S)
_FLIP = re.compile(r"\[flip\b[^\]]*\](.*?)\[/flip\]", re.I | re.S)

_VERBATIM_SPAN = re.compile(r"\[(?:code|noparse|pre)\b[^\]]*\].*?\[/(?:code|noparse|pre)\]", re.I | re.S)
_ATTR_BODY = r'(?:"(?:\\.|[^"])*"|\'(?:\\.|[^\'])*\'|\\.|[^\]])*'
_YOUTUBE_TAG = re.compile(rf"\[(?P<tag>youtube|video)\b(?P<attrs>{_ATTR_BODY})\](?:(?P<inner>.*?)\[/(?P=tag)\])?", re.I | re.S)
_PREVIEW_YT_TAG = re.compile(
    rf"\[previewyoutube\b(?P<attrs>{_ATTR_BODY})\](?:(?P<inner>.*?)\[/previewyoutube\])?", re.I | re.S
)
_STORE_TAG = re.compile(
    rf"\[(?P<tag>storelink|store|steamstore|app)\b(?P<attrs>{_ATTR_BODY})\](?:(?P<inner>.*?)\[/(?P=tag)\])?", re.I | re.S
)
_DYNAMICLINK_TAG = re.compile(rf"\[dynamiclink\b(?P<attrs>{_ATTR_BODY})\](?:(?P<inner>.*?)\[/dynamiclink\])?", re.I | re.S)
_OG_TAG = re.compile(rf"\[og\b(?P<attrs>{_ATTR_BODY})\](?:(?P<inner>.*?)\[/og\])?", re.I | re.S)
_URL_TAG = re.compile(rf"\[url(?P<attrs>[ =]{_ATTR_BODY})\](?P<inner>.*?)\[/url\]", re.I | re.S)
_BARE_URL = re.compile(r"https?://[^\s\"\[\]<>]+", re.I)

_YT_ID_TOKEN = re.compile(r"^[A-Za-z0-9_-]{11}$")
_YT_V_ATTR = re.compile(r"\bv=(\"?)(?P<id>[A-Za-z0-9_-]{11})\1")
_PREVIEW_YT_ID = re.compile(r"=\s*\"?(?P<id>[A-Za-z0-9_-]{11})(?:;[^\"\]\s]*)?\"?")
_APPID_ATTR = re.compile(r"(?:\bappid=|^=\s*)(\"?)(?P<id>\d{1,10})\1", re.I)
_HREF_ATTR = re.compile(r"(?:\bhref=|\burl=|^=\s*)(?:\"((?:\\.|[^\"])*)\"|'((?:\\.|[^'])*)'|([^\s\"\]]+))", re.I)
_KV_ATTR_RE = re.compile(r"\b(?P<key>[A-Za-z_][\w-]*)\s*=\s*(?:\"((?:\\.|[^\"])*)\"|'((?:\\.|[^'])*)'|([^\s\"\]]+))")
_STORE_URL_RE = re.compile(
    r"^https?://(?:store\.steampowered\.com/(?:agecheck/)?app/|s\.team/a/)(\d{1,10})(?:[/?#]|$)", re.I
)
_YT_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com",
    "gaming.youtube.com", "youtube-nocookie.com", "www.youtube-nocookie.com",
}

# only Steam's own tags are stripped, so text like "[AFK]" typed by a friend survives
_STEAM_TAGS = ("b", "i", "u", "s", "strike", "code", "quote", "spoiler", "url", "h1", "h2", "h3", "pre", "noparse",
               "list", "olist", r"\*", "table", "tr", "th", "td", "hr", "img", "sticker", "emoticon", "mention",
               "giphy", "lobbyinvite", "gameinvite", "tradeoffer", "inviteurl", "random", "flip", "taunt",
               "looking_to_play", "storelink", "store", "steamstore", "app", "youtube", "previewyoutube", "video",
               "dynamiclink", "og", "sharedfile", "publishedfile", "publishedfileid", "workshop", "tweet",
               "roomeffect", "broadcastinvite", "voicechannelinvite")
_ANY_TAG = re.compile(rf"\[/?(?:{'|'.join(_STEAM_TAGS)})(?:[ =]{_ATTR_BODY})?\]", re.I)
_WS = re.compile(r"[ \t\r\f\v]+")


def _clean_url_tail(url: str) -> str:
    url = url.strip()
    while url and url[-1] in ".,;:!?'\"":
        url = url[:-1]
    while url.endswith(")") and url.count(")") > url.count("("):
        url = url[:-1]
    return url


def _unwrap_linkfilter(url: str) -> str:
    try:
        parts = urlsplit(url)
        host = parts.netloc.lower()
        if (host == "steamcommunity.com" or host.endswith(".steamcommunity.com")) and parts.path.lower().startswith("/linkfilter"):
            for k, v in parse_qsl(parts.query):
                if k.lower() in ("u", "url") and v.lower().startswith(("https://", "http://")):
                    return v.strip()
    except ValueError:
        pass
    return url


def extract_youtube_id(url: str) -> str | None:
    """Return the 11-character YouTube video ID from a YouTube URL, or None."""
    if not url:
        return None
    target = _unwrap_linkfilter(_clean_url_tail(url))
    if not target.lower().startswith(("https://", "http://")):
        return None
    try:
        parts = urlsplit(target)
    except ValueError:
        return None
    host = parts.netloc.lower()
    if ":" in host:
        host = host.split(":", 1)[0]
    segs = [s for s in parts.path.split("/") if s]
    cand = ""
    if host in ("youtu.be", "www.youtu.be"):
        cand = segs[0] if segs else ""
    elif host in _YT_HOSTS:
        if parts.path.lower() == "/watch":
            for k, v in parse_qsl(parts.query):
                if k == "v" and _YT_ID_TOKEN.match(v):
                    return v
        elif len(segs) >= 2 and segs[0].lower() in ("shorts", "live", "embed", "v"):
            cand = segs[1]
    return cand if _YT_ID_TOKEN.match(cand) else None


def extract_store_appid(url: str) -> str | None:
    """Return numeric Steam AppID from a store.steampowered.com/app/<id> or s.team/a/<id> URL, or None."""
    if not url:
        return None
    target = _unwrap_linkfilter(_clean_url_tail(url))
    m = _STORE_URL_RE.match(target)
    return m.group(1) if m else None


def _unescape_attr(val: str) -> str:
    return val.replace('\\"', '"').replace("\\'", "'").replace("\\[", "[").replace("\\]", "]").replace("\\\\", "\\")


def _attr_url(attrs: str) -> str:
    m = _HREF_ATTR.search((attrs or "").strip())
    raw = (m.group(1) or m.group(2) or m.group(3) or "").strip() if m else ""
    return _unescape_attr(raw)


def _parse_kv_attrs(attrs: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for m in _KV_ATTR_RE.finditer(attrs or ""):
        key = m.group("key").lower()
        val = m.group(2) if m.group(2) is not None else (m.group(3) if m.group(3) is not None else (m.group(4) or ""))
        out[key] = _unescape_attr(val).strip()
    return out


def _clean_attr_text(raw: str, max_len: int = 200) -> str:
    if not raw:
        return ""
    text = _WS.sub(" ", html.unescape(raw)).strip()
    return (text[: max_len - 1].rstrip() + "…") if len(text) > max_len else text


def _embed_from_url(url: str) -> ChatEmbed | None:
    cleaned = _clean_url_tail(url)
    unwrapped = _unwrap_linkfilter(cleaned)
    vid = extract_youtube_id(unwrapped)
    if vid:
        canonical = unwrapped if unwrapped.lower().startswith(("https://", "http://")) else f"https://www.youtube.com/watch?v={vid}"
        return ChatEmbed(EMBED_YOUTUBE, vid, canonical)
    appid = extract_store_appid(unwrapped)
    if appid:
        return ChatEmbed(EMBED_STORE, appid, f"https://store.steampowered.com/app/{appid}/")
    return None


def _youtube_embed_from_match(m: re.Match) -> ChatEmbed | None:
    attrs = m.group("attrs") or ""
    inner = (m.group("inner") or "").strip()
    attr_u = _attr_url(attrs)
    for candidate in (attr_u, inner):
        if candidate:
            emb = _embed_from_url(candidate)
            if emb and emb.kind == EMBED_YOUTUBE:
                return emb
    vm = _YT_V_ATTR.search(attrs)
    if vm:
        vid = vm.group("id")
        url = attr_u if attr_u.lower().startswith(("https://", "http://")) else f"https://www.youtube.com/watch?v={vid}"
        return ChatEmbed(EMBED_YOUTUBE, vid, url)
    return None


def _store_embed_from_match(m: re.Match) -> ChatEmbed | None:
    attrs = (m.group("attrs") or "").strip()
    inner = (m.group("inner") or "").strip()
    am = _APPID_ATTR.search(attrs)
    if am:
        appid = am.group("id")
        return ChatEmbed(EMBED_STORE, appid, f"https://store.steampowered.com/app/{appid}/")
    for candidate in (_attr_url(attrs), inner):
        appid = extract_store_appid(candidate)
        if appid:
            return ChatEmbed(EMBED_STORE, appid, f"https://store.steampowered.com/app/{appid}/")
    if inner.isdigit() and 1 <= len(inner) <= 10:
        return ChatEmbed(EMBED_STORE, inner, f"https://store.steampowered.com/app/{inner}/")
    return None


def _og_embed_from_match(m: re.Match) -> ChatEmbed | None:
    kv = _parse_kv_attrs(m.group("attrs") or "")
    inner = (m.group("inner") or "").strip()
    raw_url = kv.get("url") or kv.get("href") or _attr_url(m.group("attrs") or "") or inner
    url = _unwrap_linkfilter(_clean_url_tail(raw_url))
    if not url.lower().startswith(("https://", "http://")):
        return None
    special = _embed_from_url(url)
    if special is not None:
        return special
    img = _clean_url_tail(kv.get("img") or kv.get("image") or "")
    if not img.lower().startswith(("https://", "http://")):
        img = ""
    title = _clean_attr_text(kv.get("title") or "", max_len=140)
    desc = _clean_attr_text(kv.get("desc") or kv.get("description") or "", max_len=200)
    if not title:
        host = urlsplit(url).netloc.lower().removeprefix("www.")
        title = host or url
    return ChatEmbed(EMBED_OG, url, url, title=title, subtitle=desc, thumb_url=img)


def _blank_span(text: str, pattern: re.Pattern) -> str:
    return pattern.sub(lambda m: " " * len(m.group(0)), text)


def extract_embeds(raw: str) -> tuple[ChatEmbed, ...]:
    """Extract rich YouTube and Steam Store embeds in appearance order, deduplicated."""
    if not raw:
        return ()
    scan = str(raw)
    for skip in (_VERBATIM_SPAN, _IMG, _STICKER, _GIPHY):
        scan = _blank_span(scan, skip)

    found: list[tuple[int, ChatEmbed]] = []
    consumed: list[tuple[int, int]] = []

    def record(match: re.Match, emb: ChatEmbed | None) -> None:
        consumed.append((match.start(), match.end()))
        if emb is not None:
            found.append((match.start(), emb))

    for m in _YOUTUBE_TAG.finditer(scan):
        record(m, _youtube_embed_from_match(m))
    for m in _PREVIEW_YT_TAG.finditer(scan):
        pm = _PREVIEW_YT_ID.search(m.group("attrs") or "")
        vid = pm.group("id") if pm else extract_youtube_id(m.group("inner") or "")
        record(m, ChatEmbed(EMBED_YOUTUBE, vid, f"https://www.youtube.com/watch?v={vid}") if vid else None)
    for m in _STORE_TAG.finditer(scan):
        record(m, _store_embed_from_match(m))
    for m in _DYNAMICLINK_TAG.finditer(scan):
        href = _attr_url(m.group("attrs") or "") or (m.group("inner") or "").strip()
        record(m, _embed_from_url(href))
    for m in _OG_TAG.finditer(scan):
        record(m, _og_embed_from_match(m))
    for m in _URL_TAG.finditer(scan):
        href = _attr_url(m.group("attrs") or "")
        record(m, _embed_from_url(href))

    masked = list(scan)
    for s, e in consumed:
        masked[s:e] = [" "] * (e - s)
    bare_scan = "".join(masked)
    for m in _BARE_URL.finditer(bare_scan):
        emb = _embed_from_url(m.group(0))
        if emb is not None:
            found.append((m.start(), emb))

    found.sort(key=lambda item: item[0])
    out: list[ChatEmbed] = []
    seen: set[tuple[str, str]] = set()
    for _pos, emb in found:
        key = (emb.kind, emb.item_id)
        if key not in seen:
            seen.add(key)
            out.append(emb)
            if len(out) >= _MAX_EMBEDS:
                break
    return tuple(out)


def _keep_inner(text: str) -> str:
    for tag in _KEEP_INNER:
        text = re.sub(rf"\[{tag}(?:[ =][^\]]*)?\](.*?)\[/{tag}\]", r"\1", text, flags=re.I | re.S)
    return text


_IMG_THUMB = re.compile(r"\bthumbnail_src=(\"?)(https?://[^\"\s\]]+)\1", re.I)
_PAGE_HOSTS = ("giphy.com", "www.giphy.com", "tenor.com", "www.tenor.com")   # src is a web page, not a picture


def _img_url(tag: str, src: str) -> str:
    """The picture to show for one [img] tag. A /giphy GIF's src is the giphy.com *page*; its thumbnail_src is the
    actual .gif, so that one is used instead."""
    host = urlsplit(src).netloc.lower()
    if host in _PAGE_HOSTS:
        thumb = _IMG_THUMB.search(tag)
        if thumb:
            return thumb.group(2)
    return src


def extract_image_urls(raw: str) -> tuple[str, ...]:
    """http(s) URLs of the images and stickers in a message, in order, without duplicates."""
    if not raw:
        return ()
    found = sorted([(m.start(), _img_url(m.group(0), m.group(2))) for m in _IMG_SRC.finditer(raw)]
                   + [(m.start(), m.group(1)) for m in _IMG_INNER.finditer(raw)]
                   + [(m.start(), STICKER_URL + quote((m.group(1) or m.group(2)).strip()))
                      for m in _STICKER_TYPE.finditer(raw)])
    urls: list[str] = []
    for _pos, url in found:
        if url not in urls:
            urls.append(url)
    return tuple(urls[:_MAX_IMAGES])


def _mention_text(inner: str) -> str:
    return inner if inner.startswith("@") else f"@{inner}"


def extract_mentions(raw: str) -> tuple[tuple[str, str], ...]:
    """(target, "@Name") for each [mention] tag; target is an account id or "all" / "here".

    The shown name is normalised like the plain text of the message, so it can be found in it.
    """
    if not raw:
        return ()
    found = []
    for m in _MENTION.finditer(str(raw)):
        shown = _WS.sub(" ", _mention_text(m.group(2)).replace("\\[", "[").replace("\\]", "]")).strip()
        if shown not in ("", "@"):
            found.append((m.group(1).lower(), shown))
    return tuple(found)


def from_chat_input(text: str) -> str:
    """BBCode equivalent of chat box text, for display only: `/sticker AK47` becomes the sticker tag.

    Never send the result: Steam's server expands `/sticker` itself and rejects client-made sticker BBCode.
    """
    m = _SLASH_STICKER.match(text.strip())
    if m:
        return f'[sticker type="{m.group(1)}" limit="0"][/sticker]'
    return text


def render_message(raw: str) -> tuple[str, tuple[str, ...]]:
    """(plain text, picture URLs) for the overlay; pictures replace their "(hình ảnh)" placeholders."""
    images = extract_image_urls(raw)
    return to_plain_text(raw, image_placeholder=not images), images


def render_rich_message(raw: str) -> tuple[str, tuple[str, ...], tuple[ChatEmbed, ...]]:
    """(plain text, picture URLs, rich embeds) for the overlay; embed URLs are stripped when cards render."""
    images = extract_image_urls(raw)
    embeds = extract_embeds(raw)
    return to_plain_text(raw, image_placeholder=not images, strip_embed_urls=bool(embeds)), images, embeds


def _is_raw_url_label(label: str) -> bool:
    s = (label or "").strip()
    return not s or s.lower().startswith(("https://", "http://", "www."))


def _rewrite_embed_tags(text: str, strip_embed_urls: bool) -> str:
    saved: list[str] = []

    def stash(m: re.Match) -> str:
        saved.append(m.group(0))
        return f"\x00V{len(saved) - 1}\x00"

    text = _VERBATIM_SPAN.sub(stash, text)

    def repl_yt(m: re.Match) -> str:
        emb = _youtube_embed_from_match(m)
        inner = (m.group("inner") or "").strip()
        if emb is None:
            return inner or _attr_url(m.group("attrs") or "")
        if strip_embed_urls:
            return "" if _is_raw_url_label(inner) else inner
        return inner or emb.url

    def repl_preview_yt(m: re.Match) -> str:
        pm = _PREVIEW_YT_ID.search(m.group("attrs") or "")
        vid = pm.group("id") if pm else extract_youtube_id(m.group("inner") or "")
        if not vid:
            return (m.group("inner") or "").strip()
        return "" if strip_embed_urls else f"https://www.youtube.com/watch?v={vid}"

    def repl_store(m: re.Match) -> str:
        emb = _store_embed_from_match(m)
        inner = (m.group("inner") or "").strip()
        if emb is None:
            return inner or _attr_url(m.group("attrs") or "")
        if strip_embed_urls:
            return "" if (_is_raw_url_label(inner) or inner.isdigit()) else inner
        return inner or emb.url

    def repl_dyn(m: re.Match) -> str:
        href = _attr_url(m.group("attrs") or "")
        inner = (m.group("inner") or "").strip()
        emb = _embed_from_url(href or inner)
        if emb is not None and strip_embed_urls:
            return "" if _is_raw_url_label(inner) else inner
        return inner or href

    def repl_og(m: re.Match) -> str:
        emb = _og_embed_from_match(m)
        inner = (m.group("inner") or "").strip()
        if emb is None:
            return inner or _attr_url(m.group("attrs") or "")
        if strip_embed_urls:
            return "" if _is_raw_url_label(inner) else inner
        return inner or emb.url

    def repl_url(m: re.Match) -> str:
        href = _attr_url(m.group("attrs") or "")
        inner = m.group("inner") or ""
        if strip_embed_urls and _embed_from_url(href) is not None:
            return "" if _is_raw_url_label(inner) else inner
        return m.group(0)

    def repl_bare(m: re.Match) -> str:
        raw_u = m.group(0)
        cleaned = _clean_url_tail(raw_u)
        if _embed_from_url(cleaned) is not None:
            return raw_u[len(cleaned):]
        return raw_u

    text = _YOUTUBE_TAG.sub(repl_yt, text)
    text = _PREVIEW_YT_TAG.sub(repl_preview_yt, text)
    text = _STORE_TAG.sub(repl_store, text)
    text = _DYNAMICLINK_TAG.sub(repl_dyn, text)
    text = _OG_TAG.sub(repl_og, text)
    if strip_embed_urls:
        text = _URL_TAG.sub(repl_url, text)
        text = _BARE_URL.sub(repl_bare, text)

    for idx, orig in enumerate(saved):
        text = text.replace(f"\x00V{idx}\x00", orig)
    return text


def to_plain_text(raw: str, image_placeholder: bool = True, strip_embed_urls: bool = False) -> str:
    """Best-effort BBCode -> plain text. Unknown tags are dropped, their inner text kept.

    `image_placeholder=False` drops images and stickers entirely (the overlay shows them as pictures instead).
    `strip_embed_urls=True` drops YouTube / Steam Store URLs that are rendered as rich embed cards.
    """
    if not raw:
        return ""
    text = str(raw)
    text = _EMOTICON.sub(lambda m: f":{m.group(1).strip(':')}:", text)
    text = _MENTION.sub(lambda m: _mention_text(m.group(2)), text)
    # placeholders use parentheses: anything in [...] is stripped as a tag below
    text = _STICKER.sub("(sticker)" if image_placeholder else "", text)
    text = _IMG.sub("(hình ảnh)" if image_placeholder else "", text)
    text = _GIPHY.sub("(GIF)", text)
    text = _INVITE.sub("(lời mời)", text)
    text = _RANDOM.sub(lambda m: f"🎲 {m.group(1)}", text)
    text = _FLIP.sub(lambda m: f"🪙 {m.group(1)}", text)
    text = _rewrite_embed_tags(text, strip_embed_urls=strip_embed_urls)
    text = _keep_inner(text)
    text = _ANY_TAG.sub("", text)
    text = text.replace("\\[", "[").replace("\\]", "]")
    lines = [_WS.sub(" ", line).strip() for line in text.split("\n")]
    text = "\n".join(line for line in lines if line)
    if len(text) > _MAX_LEN:
        text = text[: _MAX_LEN - 1] + "…"
    return text
