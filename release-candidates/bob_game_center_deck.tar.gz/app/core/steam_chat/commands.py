"""Chat box slash commands: the suggestion list shown while typing "/", and the overlay's own commands.

Steam's chat box sends every slash command as typed (`room.SendChatMessage("/spoiler text")`) and the server
expands it, exactly like `/sticker X`; so those are sent unchanged. Four commands only the overlay knows:

* `/count N [0.5s] [text]`  types "N", ..., "1" and then "GO !!!" (or `text`) into the room, one per second
* `/room <name>`            switches to another channel of the current group
* `/group <name>`           switches to another chat group (its default channel)
* `/quiet [on|off]`         shows only the messages that mention you

and the game helpers of gametools.py (/timer /afk /back /alert /join /ready /team /pick).
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass

from app.core.steam_chat.gametools import AFK, ALERT, BACK, CHAT, INVITE, JOIN, PICK, READY, TEAM, TIMER

COUNT = "/count"
ME = "/me"
ROOM = "/room"
GROUP = "/group"
QUIET = "/quiet"
COUNT_GO = "GO !!!"     # sent one interval after the last number unless the user gives another text
COUNT_NO_FINAL = "-"    # `/count 3 -`: numbers only
MAX_COUNT = 10          # numbers sent by one /count (Steam rate-limits chat spam)
COUNT_INTERVAL = 1.0
MIN_INTERVAL, MAX_INTERVAL = 0.5, 5.0
MAX_FINAL_LEN = 100
COUNT_STOP_WORDS = ("stop", "cancel", "huy", "hủy", "dung", "dừng")
COUNT_USAGE = (f"Dùng: /count <1-{MAX_COUNT}> [0.5s] [chữ cuối] (vd /count 3 → 3 2 1 GO !!!; "
               f"/count 5 0.5s Nhảy! ; /count 3 - chỉ gửi số), /count stop để huỷ")
MAX_SUGGESTIONS = 8

# (name, what it does) - Steam's own list first (same order as its chat box), then the overlay's additions
COMMANDS: tuple[tuple[str, str], ...] = (
    ("/me", "Hiển thị tin nhắn dưới dạng hành động"),
    ("/code", "Định dạng thành khối code"),
    ("/pre", "Chữ đơn cách, giữ nguyên khoảng trắng"),
    ("/giphy", "Gửi GIF ngẫu nhiên theo từ khoá"),
    ("/spoiler", "Ẩn nội dung cho đến khi rê chuột vào"),
    ("/quote", "Định dạng thành trích dẫn"),
    ("/random", "Chọn số ngẫu nhiên (/random 1000 hoặc /random 500-1000)"),
    ("/flip", "Tung đồng xu"),
    ("/store", "Gửi link game trên Steam Store"),
    ("/sticker", "Gửi sticker (/sticker <tên>)"),
    (COUNT, "Đếm ngược mỗi giây (/count 3 gửi 3 2 1 GO)"),
    (ROOM, "Đổi sang kênh khác trong nhóm (/room <tên>)"),
    (GROUP, "Đổi sang nhóm chat khác (/group <tên>)"),
    (QUIET, "Chỉ hiện tin khi bị tag (bật / tắt)"),
    (TIMER, "Hẹn giờ (/timer 5m Boss, -say: báo lên kênh)"),
    (READY, "Hỏi cả nhóm đã sẵn sàng chưa (rồi / vô / ok)"),
    (JOIN, "Vào game của bạn bè như chuột phải → Join Game"),
    (INVITE, "Mời bạn vào lobby / game của bạn (/invite <tên|all>)"),
    (CHAT, "Mở chat riêng với bạn bè kèm lịch sử (/chat <tên> [tin nhắn])"),
    (AFK, "Đặt AFK, tự trả lời khi bị tag (/afk 10p ăn cơm)"),
    (BACK, "Hết AFK, xem ai đã tag bạn"),
    (ALERT, "Từ khoá cảnh báo như bị tag (/alert lobby)"),
    (TEAM, "Chia đội ngẫu nhiên (/team 2)"),
    (PICK, "Chọn ngẫu nhiên (/pick a b c)"),
)


@dataclass(frozen=True)
class CommandCandidate:
    """Same shape as mentions.MentionCandidate, so the input bar's suggestion popup draws both."""

    insert: str             # name without the "/" (or the whole argument for /room and /group)
    label: str              # "/spoiler"
    detail: str = ""
    account_id: int = 0     # always 0: drawn in the neutral colour


@dataclass(frozen=True)
class CountCommand:
    start: int = 0          # count down from this number; 0 = cancel the running countdown
    interval: float = COUNT_INTERVAL
    final: str = COUNT_GO   # sent after the last number; "" = nothing
    error: str = ""         # set when the arguments are wrong (shown to the user instead of sending anything)


@dataclass(frozen=True)
class SwitchCommand:
    kind: str               # ROOM or GROUP
    name: str = ""          # what the user typed after the command ("" = list the choices)


@dataclass(frozen=True)
class QuietCommand:
    enable: bool | None = None      # None = toggle


def active_query(text: str, cursor: int) -> str | None:
    """What follows the leading "/" when the cursor ends the command word, else None."""
    if not text.startswith("/") or cursor < 1:
        return None
    word_end = next((i for i, c in enumerate(text) if c.isspace()), len(text))
    return text[1:cursor] if cursor == word_end else None


def suggest(query: str) -> list[CommandCandidate]:
    """Commands starting with `query`. Nothing when the command is already typed in full (Enter then sends it)."""
    q = query.lower()
    found = [CommandCandidate(name[1:], name, detail) for name, detail in COMMANDS if name[1:].startswith(q)]
    if len(found) == 1 and found[0].insert == q:
        return []
    return found


def replace_command(text: str, cursor: int, candidate: CommandCandidate) -> tuple[str, int]:
    """Put the chosen command in place of the word being typed: new text and where the cursor goes."""
    rest = text[cursor:]
    inserted = f"/{candidate.insert}"
    if not rest.startswith(" "):
        inserted += " "
    return inserted + rest, len(inserted) + (1 if rest.startswith(" ") else 0)


# ---- /room and /group arguments ---------------------------------------------------------------------
_ARG = re.compile(r"^(/room|/group|/join|/invite|/chat)\s+(.*)$", re.I | re.S)


def active_argument(text: str, cursor: int) -> tuple[str, int, str] | None:
    """(command, index where the argument starts, argument typed so far) for `/room ...` / `/group ...` / `/join ...`."""
    m = _ARG.match(text)
    if m is None or cursor != len(text):
        return None
    return m.group(1).lower(), m.start(2), m.group(2)


def suggest_names(options: Sequence[tuple[str, str]], query: str, limit: int = MAX_SUGGESTIONS,
                  marker: str = "# ") -> list[CommandCandidate]:
    """(name, detail) options matching `query` (name prefix first, then anywhere in it). A lone exact match
    returns nothing, so Enter sends the command instead of picking it again."""
    q = query.strip().lower()
    scored = []
    for name, detail in options:
        low = name.lower()
        if low.startswith(q):
            scored.append((0, low, name, detail))
        elif q in low:
            scored.append((1, low, name, detail))
    scored.sort(key=lambda s: (s[0], s[1]))
    if len(scored) == 1 and scored[0][1] == q:
        return []
    return [CommandCandidate(name, f"{marker}{name}", detail) for _s, _l, name, detail in scored[:limit]]


def replace_argument(text: str, start: int, candidate: CommandCandidate) -> tuple[str, int]:
    new = text[:start] + candidate.insert
    return new, len(new)


def resolve_name(options: Sequence[tuple[str, str]], name: str) -> tuple[str | None, list[str]]:
    """The one option `name` stands for: exact, else unique prefix, else unique substring (case-insensitive).
    Returns (matched name or None, the candidates when several match)."""
    q = name.strip().lower()
    if not q:
        return None, []
    names = [n for n, _d in options]
    for stage in (lambda n: n.lower() == q, lambda n: n.lower().startswith(q), lambda n: q in n.lower()):
        hits = [n for n in names if stage(n)]
        if len(hits) == 1:
            return hits[0], []
        if hits:
            return None, hits
    return None, []


# ---- overlay-only commands --------------------------------------------------------------------------
_COUNT = re.compile(r"^/count(?:\s+(\S+)(?:\s+(.*))?)?\s*$", re.I | re.S)
_INTERVAL = re.compile(r"^(\d+(?:[.,]\d+)?)s(?:\s+(.*))?$", re.I | re.S)


def parse_count(text: str) -> CountCommand | None:
    """The overlay's `/count N [interval] [final text]` (None when `text` is not that command)."""
    m = _COUNT.match(text.strip())
    if m is None:
        return None
    arg, rest = m.group(1), (m.group(2) or "").strip()
    if arg is None or not arg.isdigit():
        if arg is not None and arg.lower() in COUNT_STOP_WORDS and not rest:
            return CountCommand()
        return CountCommand(error=COUNT_USAGE)
    n = int(arg)
    if not 1 <= n <= MAX_COUNT:
        return CountCommand(error=f"/count chỉ nhận số từ 1 đến {MAX_COUNT}")
    interval = COUNT_INTERVAL
    timing = _INTERVAL.match(rest)
    if timing is not None:
        interval = float(timing.group(1).replace(",", "."))
        rest = (timing.group(2) or "").strip()
        if not MIN_INTERVAL <= interval <= MAX_INTERVAL:
            return CountCommand(error=f"Khoảng cách giữa các số phải từ {MIN_INTERVAL:g}s đến {MAX_INTERVAL:g}s")
    final = COUNT_GO if not rest else "" if rest == COUNT_NO_FINAL else rest[:MAX_FINAL_LEN]
    return CountCommand(start=n, interval=interval, final=final)


def parse_switch(text: str) -> SwitchCommand | None:
    parts = text.strip().split(None, 1)
    if parts and parts[0].lower() in (ROOM, GROUP):
        return SwitchCommand(parts[0].lower(), parts[1].strip() if len(parts) > 1 else "")
    return None


def parse_quiet(text: str) -> QuietCommand | None:
    parts = text.strip().lower().split()
    if not parts or parts[0] != QUIET or len(parts) > 2:
        return None
    if len(parts) == 1:
        return QuietCommand()
    if parts[1] in ("on", "bat", "bật"):
        return QuietCommand(True)
    if parts[1] in ("off", "tat", "tắt"):
        return QuietCommand(False)
    return None


def split_action(text: str) -> tuple[bool, str]:
    """(True, what was done) for a `/me ...` message: Steam shows those as "* Name does something"."""
    head, _sep, rest = text.partition(" ")
    if head.lower() == ME and rest.strip():
        return True, rest.strip()
    return False, text
