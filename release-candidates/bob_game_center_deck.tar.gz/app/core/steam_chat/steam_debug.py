"""Steam client remote-debugging switch (`<Steam>/.cef-enable-remote-debugging`) and connection probing."""

from __future__ import annotations

import logging
import os
import subprocess
import sys

from app.core import steam_manager
from app.core.steam_chat.cdp import DEFAULT_PORT, CdpUnavailable, find_target, list_targets
from app.core.steam_chat.models import BridgeState

logger = logging.getLogger(__name__)

MARKER_NAME = ".cef-enable-remote-debugging"
TARGET_TITLE = "SharedJSContext"
_STEAM_UI_HOST = "steamloopback.host"


def marker_path(steam_path: str | None = None) -> str | None:
    steam_path = steam_path or steam_manager.find_steam_path()
    return os.path.join(steam_path, MARKER_NAME) if steam_path else None


def is_debug_marker_present(steam_path: str | None = None) -> bool:
    path = marker_path(steam_path)
    return bool(path and os.path.isfile(path))


def set_debug_marker(enabled: bool, steam_path: str | None = None) -> bool:
    """Create/remove the marker file. Takes effect on the next Steam start. Returns True on success."""
    path = marker_path(steam_path)
    if not path:
        logger.warning("[SteamChat] Steam installation not found; cannot toggle remote debugging")
        return False
    try:
        if enabled:
            if not os.path.isfile(path):
                with open(path, "w", encoding="utf-8"):
                    pass
                logger.info(f"[SteamChat] Created {path}")
        elif os.path.isfile(path):
            os.remove(path)
            logger.info(f"[SteamChat] Removed {path}")
        return True
    except OSError as e:
        logger.error(f"[SteamChat] Could not {'create' if enabled else 'remove'} {path}: {e}")
        return False


def find_steam_target(port: int = DEFAULT_PORT) -> dict | None:
    """The SharedJSContext target, or None when the port answers but is not the Steam client."""
    target = find_target(list_targets(port), TARGET_TITLE)
    if target and _STEAM_UI_HOST in str(target.get("url", "")):
        return target
    return None


def probe(port: int = DEFAULT_PORT) -> tuple[BridgeState, dict | None]:
    """Classify why we can or cannot attach. Returns (state, target-or-None); CONNECTING means attachable."""
    try:
        target = find_steam_target(port)
    except CdpUnavailable:
        target = None
        reachable = False
    else:
        reachable = True
    if target is not None:
        return BridgeState.CONNECTING, target
    if not steam_manager.is_steam_running():
        return BridgeState.STEAM_NOT_RUNNING, None
    if reachable:
        return BridgeState.PORT_CONFLICT, None
    if is_debug_marker_present():
        return BridgeState.RESTART_REQUIRED, None
    return BridgeState.DEBUG_DISABLED, None


def restart_steam(timeout: int = 20) -> bool:
    """Shut Steam down gracefully and start it again (picks up the marker file). Blocking."""
    steam_path = steam_manager.find_steam_path()
    if not steam_path:
        return False
    if not steam_manager.close_steam(timeout=timeout, steam_path=steam_path):
        logger.warning("[SteamChat] Steam did not exit in time; not restarting")
        return False
    steam_cmd = steam_manager.get_steam_executable(steam_path)
    if not steam_cmd:
        logger.error("[SteamChat] Steam executable not found; cannot restart")
        return False
    cmd = (
        ["flatpak", "run", "com.valvesoftware.Steam"]
        if steam_cmd == "flatpak"
        else [steam_cmd]
    )
    try:
        from app.core.online_fix.extractor import clean_subprocess_env
        creationflags = (
            getattr(subprocess, "DETACHED_PROCESS", 0)
            if sys.platform == "win32"
            else 0
        )
        subprocess.Popen(
            cmd,
            cwd=steam_path if os.path.isdir(steam_path) else None,
            env=clean_subprocess_env(),
            close_fds=True,
            creationflags=creationflags,
        )
        logger.info("[SteamChat] Steam restarted")
        return True
    except OSError as e:
        logger.error(f"[SteamChat] Could not start Steam ({steam_cmd}): {e}")
        return False
