"""SteamChatBridge: keeps one Steam chat room hooked through CDP, survives Steam restarts.

Threading: one worker thread owns the connection lifecycle (probe -> attach -> inject -> subscribe ->
health checks -> reconnect). Live messages arrive on the CDP reader thread. All callbacks are invoked
from those background threads; the UI layer must marshal them to its own thread.
"""

from __future__ import annotations

import collections
import json
import logging
import secrets
import threading
import time
from typing import Callable

from app.core.steam_chat import steam_debug
from app.core.steam_chat.bbcode import GROUP_MENTIONS, extract_mentions, from_chat_input, render_rich_message
from app.core.steam_chat.bridge_js import (
    BINDING_NAME,
    build_install_script,
    call_expr,
    token_check_expr,
)
from app.core.steam_chat.cdp import DEFAULT_PORT, CdpError, CdpSession
from app.core.steam_chat.gametools import FriendInfo, friends_from_payload
from app.core.steam_chat.models import (
    BridgeState,
    BridgeStatus,
    ChatGroupInfo,
    ChatMember,
    ChatMessage,
    ChatRoomInfo,
    DM_GROUP,
)

logger = logging.getLogger(__name__)

PROBE_INTERVAL = 5.0       # while Steam / debugging is unavailable
HEALTH_INTERVAL = 3.0      # injected bridge + room object still valid?
READY_INTERVAL = 2.0       # waiting for the friends UI to load
RECONNECT_DELAYS = (1.0, 2.0, 5.0, 10.0)
SELF_ECHO_WINDOW = 20.0    # drop a server echo of a message we sent from the overlay within this window
MAX_SEND_LEN = 2000

_SEND_ERRORS = {
    "no_room": "Kênh chat không còn tồn tại",
    "no_permission": "Bạn không có quyền chat trong nhóm này",
    "send_failed": "Steam không gửi được tin nhắn",
    "send_timeout": "Steam chưa xác nhận tin nhắn (vẫn đang thử gửi lại)",
    "not_connected": "Chưa kết nối Steam",
}


def send_error_text(code: str) -> str:
    return _SEND_ERRORS.get(code, code or "Lỗi không xác định")


def _message_from_payload(data: dict, self_id: int = 0) -> ChatMessage | None:
    if not isinstance(data, dict) or data.get("type") != "message":
        return None
    try:
        account_id = int(data.get("accountId") or 0)
        # live events can carry Steam's internal form ("/sticker AK47") instead of the stored BBCode
        raw = from_chat_input(str(data.get("text") or ""))
        text, images, embeds = render_rich_message(raw)
        if not text and not images and not embeds:
            return None
        found = extract_mentions(raw)
        is_self = bool(data.get("isSelf"))
        return ChatMessage(
            group_id=str(data.get("groupId") or ""),
            chat_id=str(data.get("chatId") or ""),
            account_id=account_id,
            sender=str(data.get("sender") or "").strip() or f"#{account_id}",
            text=text,
            timestamp=int(data.get("timestamp") or 0),
            ordinal=int(data.get("ordinal") or 0),
            is_self=is_self,
            history=bool(data.get("history")),
            images=images,
            embeds=embeds,
            mentions=tuple(dict.fromkeys(shown for _target, shown in found)),
            mentioned=not is_self and any(
                target in GROUP_MENTIONS or (self_id and target == str(self_id)) for target, _shown in found),
            personal=not is_self and any(self_id and target == str(self_id) for target, _shown in found),
        )
    except (TypeError, ValueError):
        return None


def _groups_from_payload(data) -> list[ChatGroupInfo]:
    groups = []
    for g in data or []:
        if not isinstance(g, dict):
            continue
        gid = str(g.get("groupId") or "")
        rooms = tuple(
            ChatRoomInfo(group_id=gid, chat_id=str(r.get("chatId") or ""), name=str(r.get("name") or ""),
                         is_default=bool(r.get("isDefault")), voice=bool(r.get("voice")))
            for r in (g.get("rooms") or []) if isinstance(r, dict) and r.get("chatId")
        )
        if gid:
            groups.append(ChatGroupInfo(group_id=gid, name=str(g.get("name") or gid), rooms=rooms))
    return groups


def _members_from_payload(data) -> tuple[list[ChatMember], bool]:
    """(members, may mention @all / @online) from the JS `members()` result."""
    if not isinstance(data, dict):
        return [], False
    members = []
    for m in data.get("members") or []:
        if not isinstance(m, dict) or not str(m.get("name") or "").strip():
            continue
        try:
            members.append(ChatMember(account_id=int(m.get("accountId") or 0), name=str(m["name"]).strip(),
                                      nickname=str(m.get("nickname") or "").strip(), is_self=bool(m.get("isSelf")),
                                      online=bool(m.get("online"))))
        except (TypeError, ValueError):
            continue
    return members, bool(data.get("canAll"))


def _emoticons_from_payload(data) -> list[tuple[str, int]]:
    """(name, times used) for each emoticon of the JS `emoticons()` result."""
    out = []
    for e in data or []:
        if isinstance(e, dict) and str(e.get("name") or "").strip():
            try:
                out.append((str(e["name"]).strip(), int(e.get("uses") or 0)))
            except (TypeError, ValueError):
                continue
    return out


class SteamChatBridge:
    def __init__(
        self,
        on_message: Callable[[ChatMessage], None] | None = None,
        on_status: Callable[[BridgeStatus], None] | None = None,
        on_history: Callable[[list[ChatMessage]], None] | None = None,
        on_send_result: Callable[[str, bool, str], None] | None = None,
        on_older: Callable[[list[ChatMessage], bool, tuple[int, int] | None], None] | None = None,
        on_members: Callable[[list[ChatMember], bool], None] | None = None,
        on_emoticons: Callable[[list[tuple[str, int]]], None] | None = None,
        port: int = DEFAULT_PORT,
        history_lines: int = 15,
        probe: Callable[[int], tuple[BridgeState, dict | None]] = steam_debug.probe,
        session_factory: Callable[..., CdpSession] = CdpSession,
    ):
        self._on_message = on_message
        self._on_status = on_status
        self._on_history = on_history
        self._on_send_result = on_send_result
        self._on_older = on_older
        self._on_members = on_members
        self._on_emoticons = on_emoticons
        self._port = port
        self._history_lines = history_lines
        self._probe = probe
        self._session_factory = session_factory

        self._lock = threading.RLock()
        self._lifecycle = threading.Lock()   # serialises start/stop (stop may run on a helper thread)
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._session: CdpSession | None = None
        self._token = secrets.token_hex(8)
        self._room: tuple[str, str] = ("", "")
        self._subscribed: tuple[str, str] | None = None
        self._send_queue: collections.deque[str] = collections.deque()
        self._recent_sent: collections.deque[tuple[str, float]] = collections.deque(maxlen=20)
        self._older_request: tuple[int, int, int] | None = None     # (timestamp, ordinal, count)
        self._members_wanted = False
        self._emoticons_wanted = False
        self._status = BridgeStatus(BridgeState.STOPPED)
        self.self_name = ""
        self.self_account_id = 0

    # ---- public API (any thread) ------------------------------------------------------------
    @property
    def status(self) -> BridgeStatus:
        return self._status

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        with self._lifecycle:
            if self.running:
                return
            self._stop.clear()
            self._wake.clear()
            self._thread = threading.Thread(target=self._run, name="SteamChat-Bridge", daemon=True)
            self._thread.start()

    def stop(self, timeout: float = 3.0) -> None:
        with self._lifecycle:
            thread = self._thread
            self._stop.set()
            self._wake.set()
            session = self._session
            if session is not None and not session.closed:
                try:
                    session.evaluate("window.__bobChatBridge && window.__bobChatBridge.dispose()", timeout=1.5)
                except CdpError:
                    pass
                session.close()
            if thread is not None and thread is not threading.current_thread():
                thread.join(timeout)
            with self._lock:
                self._thread = None
                self._send_queue.clear()
            self._set_status(BridgeState.STOPPED)

    def set_room(self, group_id: str, chat_id: str) -> None:
        with self._lock:
            self._room = (str(group_id or ""), str(chat_id or ""))
        self._wake.set()

    def set_history_lines(self, n: int) -> None:
        self._history_lines = max(0, int(n))

    def send(self, text: str) -> bool:
        """Queue a message for the selected room. False when it cannot be sent right now."""
        text = (text or "").strip()
        if not text or not self._status.connected:
            return False
        with self._lock:
            self._send_queue.append(text[:MAX_SEND_LEN])
        self._wake.set()
        return True

    def request_older(self, timestamp: int, ordinal: int, count: int = 30) -> bool:
        """Ask for up to `count` messages older than (timestamp, ordinal) -> on_older(messages, more, oldest).

        `oldest` is the (timestamp, ordinal) to continue from, None when nothing came back.

        timestamp 0 means "the newest ones". False when not connected (nothing will be reported).
        """
        if not self._status.connected:
            return False
        with self._lock:
            self._older_request = (int(timestamp), int(ordinal), max(1, int(count)))
        self._wake.set()
        return True

    def request_members(self) -> bool:
        """Ask for the room's members (for @-mentions) -> on_members(members, can_mention_all)."""
        if not self._status.connected:
            return False
        self._members_wanted = True
        self._wake.set()
        return True

    def request_emoticons(self) -> bool:
        """Ask for the account's emoticons (for `:name:` suggestions) -> on_emoticons([(name, uses)])."""
        if not self._status.connected:
            return False
        self._emoticons_wanted = True
        self._wake.set()
        return True

    def _attached(self) -> CdpSession:
        session = self._session
        if session is None or session.closed:
            raise CdpError("not connected to Steam")
        self._ensure_installed(session)
        return session

    def list_friends(self, timeout: float = 8.0) -> list[FriendInfo]:
        """Online friends and the game each is in (for /join and /invite). Blocking; raises CdpError when not attached."""
        return friends_from_payload(self._attached().evaluate(call_expr("friendList"), timeout=timeout))

    def list_all_friends(self, timeout: float = 8.0) -> list[FriendInfo]:
        """Every friend, offline ones too, with `online` set (for /chat). Blocking; raises CdpError when not attached."""
        return friends_from_payload(self._attached().evaluate(call_expr("friendList", True), timeout=timeout))

    def invite_state(self, timeout: float = 8.0) -> dict:
        """What we can invite people to: {"kind": "lobby" | "game" | "", "appId", "game", ...}. Blocking."""
        result = self._attached().evaluate(call_expr("inviteState"), timeout=timeout)
        return result if isinstance(result, dict) else {"kind": ""}

    def send_invites(self, account_ids: list[int], timeout: float = 15.0) -> dict:
        """Invite these friends to our lobby / game, like the friends list does. Blocking."""
        result = self._attached().evaluate(call_expr("invite", [int(i) for i in account_ids]), timeout=timeout)
        return result if isinstance(result, dict) else {"ok": False, "error": "no_result"}

    def list_groups(self, timeout: float = 8.0) -> list[ChatGroupInfo]:
        """The user's chat groups and their rooms. Blocking; raises CdpError when not attached."""
        session = self._session
        if session is None or session.closed:
            raise CdpError("not connected to Steam")
        self._ensure_installed(session)
        return _groups_from_payload(session.evaluate(call_expr("listGroups"), timeout=timeout))

    # ---- worker ------------------------------------------------------------------------------
    def _set_status(self, state: BridgeState, detail: str = "") -> None:
        status = BridgeStatus(state, detail)
        if status == self._status:
            return
        self._status = status
        logger.info(f"[SteamChat] Status: {state.value}{(' - ' + detail) if detail else ''}")
        if self._on_status is not None:
            try:
                self._on_status(status)
            except Exception:
                logger.exception("[SteamChat] on_status failed")

    def _run(self) -> None:
        attempt = 0
        while not self._stop.is_set():
            try:
                state, target = self._probe(self._port)
            except Exception as e:
                logger.exception("[SteamChat] Probe failed")
                state, target = BridgeState.ERROR, None
                self._set_status(state, str(e))
            if target is None:
                if state is not BridgeState.ERROR:
                    self._set_status(state)
                self._wait(PROBE_INTERVAL)
                continue
            self._set_status(BridgeState.CONNECTING)
            try:
                self._session_loop(target)
                attempt = 0
            except CdpError as e:
                if not self._stop.is_set():
                    logger.warning(f"[SteamChat] Connection error: {e}")
                    self._set_status(BridgeState.ERROR, str(e))
            except Exception as e:
                logger.exception("[SteamChat] Unexpected bridge error")
                self._set_status(BridgeState.ERROR, str(e))
            finally:
                self._close_session()
            if not self._stop.is_set():
                self._wait(RECONNECT_DELAYS[min(attempt, len(RECONNECT_DELAYS) - 1)])
                attempt += 1

    def _wait(self, seconds: float) -> None:
        self._wake.wait(seconds)
        self._wake.clear()

    def _close_session(self) -> None:
        session, self._session = self._session, None
        self._subscribed = None
        if session is not None:
            session.close()

    def _session_loop(self, target: dict) -> None:
        session = self._session_factory(target["webSocketDebuggerUrl"], on_event=self._on_event,
                                        on_close=self._wake.set)
        self._session = session
        session.call("Runtime.addBinding", {"name": BINDING_NAME})
        self._ensure_installed(session)
        last_health = time.monotonic()
        while not self._stop.is_set() and not session.closed:
            if not session.evaluate(call_expr("ready")):
                self._subscribed = None
                self._set_status(BridgeState.NOT_READY)
                self._wait(READY_INTERVAL)
                continue
            with self._lock:
                wanted = self._room
            if wanted != self._subscribed:
                self._subscribe(session, wanted)
            self._drain_sends(session)
            self._drain_older(session)
            self._drain_members(session)
            self._drain_emoticons(session)
            if time.monotonic() - last_health >= HEALTH_INTERVAL:
                last_health = time.monotonic()
                self._health_check(session)
            self._wait(HEALTH_INTERVAL)

    def _ensure_installed(self, session: CdpSession) -> None:
        if not session.evaluate(token_check_expr(self._token), await_promise=False):
            result = session.evaluate(build_install_script(self._token), await_promise=False) or {}
            logger.info(f"[SteamChat] JS bridge injected (v{result.get('version')})")
            self._subscribed = None

    def _health_check(self, session: CdpSession) -> None:
        if not session.evaluate(token_check_expr(self._token), await_promise=False):
            logger.info("[SteamChat] Steam UI reloaded; re-injecting bridge")
            self._ensure_installed(session)
            return
        if self._subscribed and session.evaluate(call_expr("alive")) == "stale":
            logger.info("[SteamChat] Chat room object was rebuilt; re-subscribing")
            self._subscribed = None
            self._wake.set()

    def _subscribe(self, session: CdpSession, room: tuple[str, str]) -> None:
        group_id, chat_id = room
        self._subscribed = room
        if not group_id or not chat_id:
            session.evaluate(call_expr("unsubscribe"))
            self._set_status(BridgeState.NO_ROOM, "Chưa chọn kênh chat")
            return
        result = session.evaluate(call_expr("subscribe", group_id, chat_id)) or {}
        if not result.get("ok"):
            self._set_status(BridgeState.NO_ROOM, "Không mở được chat riêng với bạn này (không còn trong danh sách bạn bè?)"
                             if group_id == DM_GROUP else "Không tìm thấy kênh chat đã chọn trong Steam")
            return
        self.self_name = str(result.get("selfName") or "")
        self.self_account_id = int(result.get("selfId") or 0)
        self._set_status(BridgeState.CONNECTED, f"{result.get('groupName', '')} / {result.get('roomName', '')}")
        self._members_wanted = True
        self._emoticons_wanted = True
        if self._on_history is not None and self._history_lines > 0:
            try:
                raw = session.evaluate(call_expr("history", group_id, chat_id, self._history_lines), timeout=8.0)
            except CdpError as e:
                logger.warning(f"[SteamChat] Could not load history: {e}")
                raw = []
            messages = [m for m in (_message_from_payload(d, self.self_account_id) for d in raw or [])
                        if m is not None]
            try:
                self._on_history(messages)
            except Exception:
                logger.exception("[SteamChat] on_history failed")

    def _drain_sends(self, session: CdpSession) -> None:
        while True:
            with self._lock:
                if not self._send_queue:
                    return
                text = self._send_queue.popleft()
                group_id, chat_id = self._room
            self._recent_sent.append((text, time.monotonic()))
            try:
                result = session.evaluate(call_expr("send", group_id, chat_id, text), timeout=20.0) or {}
                ok, error = bool(result.get("ok")), str(result.get("error") or "")
            except CdpError as e:
                ok, error = False, str(e)
            if not ok:
                logger.warning(f"[SteamChat] Send failed: {error}")
            if self._on_send_result is not None:
                try:
                    self._on_send_result(text, ok, error)
                except Exception:
                    logger.exception("[SteamChat] on_send_result failed")

    def _drain_older(self, session: CdpSession) -> None:
        with self._lock:
            request, self._older_request = self._older_request, None
            group_id, chat_id = self._room
        if request is None or self._on_older is None:
            return
        try:
            raw = session.evaluate(call_expr("older", group_id, chat_id, *request), timeout=12.0) or {}
        except CdpError as e:
            logger.warning(f"[SteamChat] Could not load older messages: {e}")
            raw = {}
        items = [d for d in raw.get("messages") or [] if isinstance(d, dict)]
        messages = [m for m in (_message_from_payload(d, self.self_account_id) for d in items) if m is not None]
        oldest = None
        if items:       # the raw first item: lines the overlay skips (empty text) must not be fetched again
            try:
                oldest = (int(items[0].get("timestamp") or 0), int(items[0].get("ordinal") or 0))
            except (TypeError, ValueError):
                oldest = None
        try:
            self._on_older(messages, bool(raw.get("more")) and oldest is not None, oldest)
        except Exception:
            logger.exception("[SteamChat] on_older failed")

    def _drain_members(self, session: CdpSession) -> None:
        if not self._members_wanted or self._on_members is None:
            return
        self._members_wanted = False
        with self._lock:
            group_id, chat_id = self._room
        try:
            members, can_all = _members_from_payload(session.evaluate(call_expr("members", group_id, chat_id), timeout=8.0))
        except CdpError as e:
            logger.warning(f"[SteamChat] Could not load members: {e}")
            return
        try:
            self._on_members(members, can_all)
        except Exception:
            logger.exception("[SteamChat] on_members failed")

    def _drain_emoticons(self, session: CdpSession) -> None:
        if not self._emoticons_wanted or self._on_emoticons is None:
            return
        self._emoticons_wanted = False
        try:
            emoticons = _emoticons_from_payload(session.evaluate(call_expr("emoticons"), timeout=8.0))
        except CdpError as e:
            logger.warning(f"[SteamChat] Could not load emoticons: {e}")
            return
        try:
            self._on_emoticons(emoticons)
        except Exception:
            logger.exception("[SteamChat] on_emoticons failed")

    def _is_own_echo(self, msg: ChatMessage) -> bool:
        if not msg.is_self:
            return False
        now = time.monotonic()
        for i, (text, ts) in enumerate(self._recent_sent):
            sent_t, sent_im, sent_em = render_rich_message(from_chat_input(text))
            sent_sig = (sent_t, sent_im, tuple((e.kind, e.item_id) for e in sent_em))
            msg_sig = (msg.text, msg.images, tuple((e.kind, e.item_id) for e in msg.embeds))
            og_echo = (not sent_em and not sent_im and not msg.text and len(msg.embeds) == 1
                       and sent_t.strip().rstrip("/") == msg.embeds[0].url.rstrip("/"))
            if now - ts <= SELF_ECHO_WINDOW and (sent_sig == msg_sig or og_echo):
                del self._recent_sent[i]
                return True
        return False

    def _on_event(self, method: str, params: dict) -> None:
        if method != "Runtime.bindingCalled" or params.get("name") != BINDING_NAME:
            return
        try:
            data = json.loads(params.get("payload") or "{}")
        except ValueError:
            return
        msg = _message_from_payload(data, self.self_account_id)
        if msg is None:
            return
        with self._lock:
            group_id, chat_id = self._room
        if (msg.group_id, msg.chat_id) != (group_id, chat_id) or self._is_own_echo(msg):
            return
        if self._on_message is not None:
            self._on_message(msg)
