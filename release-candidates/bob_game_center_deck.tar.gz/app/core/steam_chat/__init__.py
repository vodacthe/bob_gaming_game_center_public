"""Steam group chat bridge: reads/sends messages of one Steam chat room through the running Steam client.

Qt-free. The Steam client's UI is a CEF (Chromium) app; with remote debugging enabled
(`<Steam>/.cef-enable-remote-debugging`) it exposes the Chrome DevTools Protocol on 127.0.0.1:8080.
We attach to the `SharedJSContext` target, inject a small JS bridge (bridge_js.py) that hooks the
friends UI chat store, and receive pushed messages through `Runtime.addBinding`.
"""
