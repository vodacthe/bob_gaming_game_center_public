"""JavaScript injected into the Steam client's SharedJSContext.

It talks to the friends UI chat store (verified against the Steam client of 2026-10):
  g_FriendsUIApp.ChatStore.GetChatRoomGroup(groupId: string) -> group
  group.GetChatRoom(chatId: string)                         -> room
  room.RegisterOnNewChatMsgAdded(cb) -> {Unregister}; cb(groupId, chatId, accountId, rtTime, ordinal, text)
  room.SendChatMessage(text)                                -> Promise (errors land in room.m_MessageSendQueue)
  g_FriendsUIApp.FriendStore.GetPlayer(accountId).display_name
  group.memberList.member_list_unsorted -> players (accountid, persona.m_strPlayerName, nickname); group.BCanIMentionAll()
  ChatStore.EmoticonStore.m_rgEmoticons -> [{name, use_count, last_used}] (the emoticons this account owns)
  ChatStore.GetFriendChat(accountId) -> private chat with a friend. Same surface as a room (chat_messages,
  LoadChatLogs, LoadMoreHistory, m_bMoreAvailable, SendChatMessage), except live messages: there is no
  RegisterOnNewChatMsgAdded, the empty instance hook OnNewChatMsgAdded(accountId, rtTime, ordinal, text) is wrapped.
  The bridge addresses a private chat as the room ("dm", "<friend account id>").

The callback fires for live messages from other members and for echoes of our own messages typed on
other devices; it does not fire for messages this client sends itself (those are local echoes).
Every exported function returns JSON-serialisable values; live messages are pushed through the
CDP binding named BINDING.
"""

from __future__ import annotations

import json

BRIDGE_VERSION = 8
BINDING_NAME = "__bobSteamChatEmit"

_TEMPLATE = r"""
(() => {
  const TOKEN = __TOKEN__;
  const EMIT = __BINDING__;
  const old = window.__bobChatBridge;
  if (old && old.token === TOKEN) return {installed: false, version: old.version};
  if (old && typeof old.dispose === 'function') { try { old.dispose(); } catch (e) {} }

  const app = () => window.g_FriendsUIApp;
  const store = () => { const a = app(); return a ? (a.ChatStore || a.m_ChatStore) : null; };
  const friends = () => { const a = app(); return a ? (a.FriendStore || a.m_FriendStore) : null; };
  const selfId = () => { try { return friends().self.accountid; } catch (e) { return 0; } };
  const DM = 'dm';
  const isDm = (gid) => String(gid) === DM;
  const friendEntry = (acct) => {
    const fs = friends();
    for (const f of (fs && fs.all_friends) || []) if (Number(f.accountid) === Number(acct)) return f;
    return null;
  };
  const group = (gid) => { const s = store(); return s && !isDm(gid) ? s.GetChatRoomGroup(String(gid)) : null; };
  const room = (gid, cid) => {
    if (isDm(gid)) {   // a private chat: only with somebody who is on the friends list
      const f = friendEntry(cid);
      const s = store();
      if (!f || f.efriendrelationship !== 3 || !s || typeof s.GetFriendChat !== 'function') return null;
      try { return s.GetFriendChat(Number(cid)) || null; } catch (e) { return null; }
    }
    const g = group(gid);
    return g ? g.GetChatRoom(String(cid)) : null;
  };
  const acked = (m) => !!(m.m_bServerAcknowledged || (m.BHasServerAcknowledged && m.BHasServerAcknowledged()));
  // real chat lines held by the room (no server notices, deleted or unconfirmed local echoes)
  const loaded = (r) => (r.chat_messages || r.m_rgChatMessages || [])
    .filter((m) => !m.eServerMsgType && !m.eDeleteState && !(m.BIsLocalEcho && m.BIsLocalEcho() && !acked(m)));
  const emit = (obj) => { try { window[EMIT](JSON.stringify(obj)); } catch (e) {} };

  const playerName = (acct) => {
    try {
      const p = friends().GetPlayer(acct);
      const name = p && (p.display_name || (p.persona && p.persona.m_strPlayerName));
      if (name) return String(name);
    } catch (e) {}
    return '';
  };

  const toMsg = (gid, cid, acct, ts, ord, text, history) => ({
    type: 'message', groupId: String(gid), chatId: String(cid), accountId: Number(acct) || 0,
    sender: playerName(acct), text: text == null ? '' : String(text), timestamp: Number(ts) || 0,
    ordinal: Number(ord) || 0, isSelf: Number(acct) === selfId(), history: !!history,
  });

  const withTimeout = (promise, ms) => Promise.race([promise, new Promise((r) => setTimeout(r, ms))]);

  const B = {
    token: TOKEN,
    version: __VERSION__,
    sub: null,

    ready() {
      const s = store();
      return !!(s && s.m_mapChatGroups && (s.chat_group_list_ready || s.m_bReceivedChatGroupList));
    },

    listGroups() {
      const s = store();
      if (!s || !s.m_mapChatGroups) return [];
      const out = [];
      for (const g of s.m_mapChatGroups.values()) {
        const rooms = [];
        if (g.m_mapRooms) {
          for (const r of g.m_mapRooms.values()) {
            rooms.push({
              chatId: String(r.GetRoomID()), name: String(r.name || ''),
              isDefault: !!(r.BIsDefaultRoom && r.BIsDefaultRoom()),
              voice: !!(r.GetVoiceAllowed && r.GetVoiceAllowed()),
              order: r.GetSortOrder ? r.GetSortOrder() : 0,
            });
          }
        }
        rooms.sort((a, b) => (b.isDefault - a.isDefault) || (a.order - b.order));
        out.push({groupId: String(g.GetGroupID()), name: String(g.name || ''), rooms});
      }
      out.sort((a, b) => a.name.localeCompare(b.name));
      return out;
    },

    // Members the @-mention suggestions can offer. A virtualized member list (huge groups) is not complete.
    members(gid, cid) {
      if (isDm(gid)) {   // two people: the friend and us
        const f = friendEntry(cid);
        if (!f || f.efriendrelationship !== 3 || !f.persona) return {ok: false, members: [], canAll: false};
        let online = false;
        try { online = !!f.persona.is_online; } catch (e) {}
        return {ok: true, canAll: false, members: [
          {accountId: Number(f.accountid) || 0, name: String(f.persona.m_strPlayerName || f.display_name || ''),
           nickname: String(f.nickname || ''), isSelf: false, online},
          {accountId: selfId(), name: playerName(selfId()), nickname: '', isSelf: true, online: true},
        ].filter((m) => m.name)};
      }
      const g = group(gid);
      if (!g) return {ok: false, members: [], canAll: false};
      const ml = g.memberList;
      const list = (ml && (ml.member_list_unsorted || ml.member_list)) || [];
      const me = selfId();
      const members = [];
      for (const m of list) {
        const name = (m.persona && m.persona.m_strPlayerName) || m.display_name || '';
        if (!name) continue;
        let online = false;
        try { online = !!(m.persona && m.persona.is_online); } catch (e) {}
        members.push({accountId: Number(m.accountid) || 0, name: String(name), nickname: String(m.nickname || ''),
                      isSelf: Number(m.accountid) === me, online});
      }
      let canAll = false;
      try { canAll = !!(g.BCanIMentionAll && g.BCanIMentionAll()); } catch (e) {}
      return {ok: true, members, canAll};
    },

    // Online friends with the game they are in. `joinable` is Steam's own `is_in_joinable_game`, the condition of the
    // right-click "Join Game" entry; the lobby id only counts when the friend is in a valid lobby.
    friendList(all) {
      const fs = friends();
      const out = [];
      for (const f of (fs && fs.all_friends) || []) {
        const p = f.persona;
        if (!p || f.efriendrelationship !== 3 || (!all && !p.is_online)) continue;
        const ingame = !!p.is_ingame;
        let game = '', connect = '';
        try { game = ingame ? String(p.GetCurrentGameName() || '') : ''; } catch (e) {}
        try { connect = String(p.connect_string || ''); } catch (e) {}
        out.push({
          accountId: Number(f.accountid) || 0, name: String(p.m_strPlayerName || ''), nickname: String(f.m_strNickname || ''),
          display: String(f.display_name || ''), ingame, appId: Number(p.m_unGamePlayedAppID) || 0, game,
          joinable: ingame && !!p.is_in_joinable_game, lobbyId: p.is_in_valid_lobby ? String(p.m_game_lobby_id) : '',
          connect, away: !!p.is_awayOrSnooze, online: !!p.is_online,
        });
      }
      return out;
    },

    // What the right-click "Invite to Game / Lobby" entry would send: our lobby, else our game's connect string.
    inviteState() {
      const fs = friends();
      const me = fs && fs.self && fs.self.persona;
      if (!me || !me.is_ingame) return {kind: ''};
      const appId = Number(me.m_unGamePlayedAppID) || 0;
      let game = '', connect = '';
      try { game = String(me.GetCurrentGameName() || ''); } catch (e) {}
      try { connect = String(me.connect_string || ''); } catch (e) {}
      const lobby = String(me.m_game_lobby_id || '');
      if (appId && lobby && lobby !== '0') return {kind: 'lobby', appId, game, lobbyId: lobby};
      if (appId && connect) return {kind: 'game', appId, game, connect};
      return {kind: '', appId, game};
    },

    // Sends the invite the Steam client sends from the friends list (FriendStore.InviteToLobby / InviteToGame).
    invite(ids) {
      const fs = friends();
      const st = this.inviteState();
      if (!st.kind) return {ok: false, error: 'not_in_game'};
      const byId = new Map();
      for (const f of (fs && fs.all_friends) || []) byId.set(Number(f.accountid), f);
      const sent = [], skipped = [];
      for (const id of ids || []) {
        const f = byId.get(Number(id));
        if (!f || f.efriendrelationship !== 3) { skipped.push(Number(id)); continue; }
        try {
          if (st.kind === 'lobby') fs.InviteToLobby(f, st.appId, st.lobbyId);
          else fs.InviteToGame(f, st.appId, st.connect);
          sent.push(Number(id));
        } catch (e) { skipped.push(Number(id)); }
      }
      return {ok: true, kind: st.kind, game: st.game, sent, skipped};
    },

    // Emoticons the account owns, for the `:name:` suggestions: [{name, uses}] most used first.
    emoticons() {
      const es = store() && store().EmoticonStore;
      const list = (es && (es.m_rgEmoticons || es.emoticon_list)) || [];
      const out = [];
      for (const e of list) {
        if (e && e.name) out.push({name: String(e.name), uses: Number(e.use_count) || 0});
      }
      out.sort((a, b) => b.uses - a.uses);
      return out;
    },

    subscribeDm(cid) {
      const r = room(DM, cid);
      if (!r) return {ok: false, reason: 'no_room'};
      const hadOwn = Object.prototype.hasOwnProperty.call(r, 'OnNewChatMsgAdded');
      const original = r.OnNewChatMsgAdded;
      const wrapper = function (acct, ts, ord, text) {
        try { emit(toMsg(DM, cid, acct, ts, ord, text, false)); } catch (e) {}
        return typeof original === 'function' ? original.apply(this, arguments) : undefined;
      };
      r.OnNewChatMsgAdded = wrapper;
      const handle = {Unregister() {
        if (r.OnNewChatMsgAdded !== wrapper) return;   // somebody wrapped it again after us: leave it alone
        if (hadOwn) r.OnNewChatMsgAdded = original; else delete r.OnNewChatMsgAdded;
      }};
      this.sub = {gid: DM, cid: String(cid), room: r, handle, active: false};
      const f = friendEntry(cid);
      const name = f ? String(f.display_name || (f.persona && f.persona.m_strPlayerName) || '') : '';
      return {ok: true, groupName: 'Chat riêng', roomName: name, selfId: selfId(), selfName: playerName(selfId())};
    },

    subscribe(gid, cid) {
      this.unsubscribe();
      if (isDm(gid)) return this.subscribeDm(cid);
      const g = group(gid);
      const r = room(gid, cid);
      if (!g || !r) return {ok: false, reason: 'no_room'};
      const handle = r.RegisterOnNewChatMsgAdded((g2, c2, acct, ts, ord, text) => {
        emit(toMsg(g2, c2, acct, ts, ord, text, false));
      });
      let active = false;
      try { store().IncRefActiveChatRoomGroup(String(gid), true); active = true; } catch (e) {}
      this.sub = {gid: String(gid), cid: String(cid), room: r, handle, active};
      return {ok: true, groupName: String(g.name || ''), roomName: String(r.name || ''),
              selfId: selfId(), selfName: playerName(selfId())};
    },

    unsubscribe() {
      const s = this.sub;
      this.sub = null;
      if (!s) return;
      try { if (s.handle) s.handle.Unregister(); } catch (e) {}
      if (s.active) { try { store().DecRefActiveChatRoomGroup(s.gid, true); } catch (e) {} }
    },

    // 'none' | 'ok' | 'stale' (Steam rebuilt the room object, e.g. after a reconnect)
    alive() {
      const s = this.sub;
      if (!s) return 'none';
      return room(s.gid, s.cid) === s.room ? 'ok' : 'stale';
    },

    async history(gid, cid, n) {
      const r = room(gid, cid);
      if (!r) return [];
      if (!loaded(r).length && !r.m_bReceivedChatLogs && typeof r.LoadChatLogs === 'function') {
        try { await withTimeout(r.LoadChatLogs(), 5000); } catch (e) {}
      }
      return (await this.older(gid, cid, 0, 0, n)).messages;
    },

    // Messages older than (ts, ord) - all when ts is 0 - newest last. Asks Steam for an older chunk
    // (like scrolling up in the Steam chat window) when fewer than n are loaded.
    async older(gid, cid, ts, ord, n) {
      const r = room(gid, cid);
      if (!r) return {messages: [], more: false};
      n = Math.max(0, n | 0);
      const isOlder = (m) => !ts || m.rtTimestamp < ts || (m.rtTimestamp === ts && m.unOrdinal < ord);
      let msgs = loaded(r).filter(isOlder);
      let more = true;
      if (msgs.length < n && typeof r.LoadMoreHistory === 'function') {
        const before = loaded(r).length;
        try { await withTimeout(r.LoadMoreHistory(), 8000); } catch (e) {}
        msgs = loaded(r).filter(isOlder);
        more = !!r.m_bMoreAvailable && loaded(r).length > before;
      }
      return {
        more: more || msgs.length > n,
        messages: msgs.slice(-n).map((m) => toMsg(gid, cid, m.unAccountID, m.rtTimestamp, m.unOrdinal,
                                                  m.strMessage != null ? m.strMessage : m.strMessageInternal, true)),
      };
    },

    async send(gid, cid, text) {
      const g = group(gid);
      const r = room(gid, cid);
      if (!r || (!g && !isDm(gid))) return {ok: false, error: 'no_room'};
      if (g && g.BCanChat && !g.BCanChat()) return {ok: false, error: 'no_permission'};
      if (isDm(gid) && r.is_blocked_friend) return {ok: false, error: 'no_permission'};
      const body = String(text);
      // SendChatMessage never throws: a failed item stays in the send queue, a sent one is removed. A
      // rejected message is retried with growing delays for a long time, so do not wait for all of it.
      let done = false;
      await withTimeout(r.SendChatMessage(body).then(() => { done = true; }), 12000);
      const q = r.m_MessageSendQueue;
      const items = ((q && q.m_queue) || []).filter((it) => it && it.message === body);
      if (items.some((it) => it.eError)) return {ok: false, error: 'send_failed'};
      return done || !items.length ? {ok: true} : {ok: false, error: 'send_timeout'};
    },

    dispose() { this.unsubscribe(); },
  };

  window.__bobChatBridge = B;
  return {installed: true, version: B.version};
})()
"""


def build_install_script(token: str) -> str:
    return (_TEMPLATE
            .replace("__TOKEN__", json.dumps(token))
            .replace("__BINDING__", json.dumps(BINDING_NAME))
            .replace("__VERSION__", str(BRIDGE_VERSION)))


def call_expr(fn: str, *args) -> str:
    """Expression calling window.__bobChatBridge.<fn>(...args); args are JSON-encoded (no injection)."""
    encoded = ", ".join(json.dumps(a) for a in args)
    return f"window.__bobChatBridge.{fn}({encoded})"


def token_check_expr(token: str) -> str:
    return f"!!(window.__bobChatBridge && window.__bobChatBridge.token === {json.dumps(token)})"
