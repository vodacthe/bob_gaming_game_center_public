"""`:name:` emoticon suggestions for the chat input (Steam's own chat box offers them after two letters)."""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass

MIN_QUERY = 2
MAX_QUERY = 32
MAX_SUGGESTIONS = 8
_TYPING = re.compile(r"(?:^|(?<=[\s(]))(:)([A-Za-z0-9_-]{%d,%d})$" % (MIN_QUERY, MAX_QUERY))


@dataclass(frozen=True)
class EmoticonCandidate:
    """Same shape as mentions.MentionCandidate, so the input bar's suggestion popup draws both."""

    insert: str             # emoticon name without the colons
    label: str              # ":name:"
    detail: str = ""
    account_id: int = 0
    emoticon: str = ""      # name, so the popup can draw the picture


def active_query(text: str, cursor: int) -> tuple[int, str] | None:
    """(index of the ":", letters typed after it) while an emoticon name is being typed at the cursor."""
    m = _TYPING.search(text[:cursor])
    if m is None:
        return None
    return m.start(1), m.group(2)


def suggest(emoticons: Sequence[tuple[str, int]], query: str, limit: int = MAX_SUGGESTIONS) -> list[EmoticonCandidate]:
    """(name, times used) pairs whose name starts with / contains `query`; most used first within each group."""
    q = query.lower()
    scored = []
    for name, uses in emoticons:
        low = name.lower()
        if low.startswith(q):
            scored.append((0, -uses, low, name))
        elif q in low:
            scored.append((1, -uses, low, name))
    scored.sort()
    return [EmoticonCandidate(name, f":{name}:", emoticon=name) for _a, _b, _c, name in scored[:limit]]


def replace_query(text: str, at: int, cursor: int, candidate: EmoticonCandidate) -> tuple[str, int]:
    """Put the chosen emoticon in place of ":query": returns the new text and where the cursor goes."""
    rest = text[cursor:]
    inserted = f":{candidate.insert}:"
    if not rest.startswith(" "):
        inserted += " "
    return text[:at] + inserted + rest, at + len(inserted) + (1 if rest.startswith(" ") else 0)
