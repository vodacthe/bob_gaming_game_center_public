"""
Background scanner, store promo inspector, and auto-claimer for Steam 100%-off
("Forever to Keep") promotions. Finds paid games and paid DLCs temporarily discounted
100% to 0 (excluding Free-to-Play, Demos, and Free Weekends) and claims them using
the running Steam Desktop CEF session.
"""

from __future__ import annotations

import html
import logging
import re
import threading
import time
from dataclasses import dataclass
from typing import Optional

import requests
from PySide6.QtCore import QObject, Signal, Slot

from app.core.steam_chat import cdp, steam_debug

logger = logging.getLogger(__name__)
TAG = "[Steam/FreeKeep]"

SCAN_INTERVAL_MS = 60 * 60 * 1000  # 1 hour
STARTUP_SCAN_DELAY_MS = 15_000

SEARCH_URL = "https://store.steampowered.com/search/results/"
APPDETAILS_URL = "https://store.steampowered.com/api/appdetails"
USERDATA_URL = "https://store.steampowered.com/dynamicstore/userdata/"
ADD_FREE_LICENSE_URL = "https://store.steampowered.com/freelicense/addfreelicense/{subid}"
APP_PAGE_URL = "https://store.steampowered.com/app/{appid}/"
STORE_ABOUT_URL = "https://store.steampowered.com/about/"

_HTTP_TIMEOUT = 15
_MAX_SEARCH_ITEMS = 150
_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

_ROW_RE = re.compile(r"<a\b[^>]*\bsearch_result_row\b[^>]*>.*?</a>", re.DOTALL | re.IGNORECASE)
_APPID_ATTR_RE = re.compile(r'data-ds-appid="([^"]+)"', re.IGNORECASE)
_TITLE_RE = re.compile(r'<span\s+class="title"[^>]*>(.*?)</span>', re.DOTALL | re.IGNORECASE)
_DISCOUNT_100_RE = re.compile(r"-\s*100\s*%")
_FORM_SUBID_RE = re.compile(
    r'<form[^>]+action="[^"]*/freelicense/addfreelicense/[^"]*"[^>]*>.*?'
    r'name="subid"\s+value="(\d+)"',
    re.DOTALL | re.IGNORECASE,
)
_JS_SUBID_RE = re.compile(r"AddFreeLicense\(\s*(\d+)", re.IGNORECASE)

_claimed_lock = threading.Lock()
_claimed_cache: set[tuple[str, int]] = set()


@dataclass(frozen=True)
class ClaimedItem:
    appid: int
    subid: int
    title: str
    item_type: str


def _make_public_session() -> requests.Session:
    sess = requests.Session()
    sess.headers.update({"User-Agent": _USER_AGENT})
    for name, val in (
        ("birthtime", "0"),
        ("wants_mature_content", "1"),
        ("mature_content", "1"),
        ("lastagecheckage", "1-0-1990"),
    ):
        sess.cookies.set(name, val, domain="store.steampowered.com", path="/")
    return sess


def _http_get(session: requests.Session, url: str, params: dict | None = None) -> requests.Response | None:
    t0 = time.monotonic()
    try:
        resp = session.get(url, params=params, timeout=_HTTP_TIMEOUT)
    except requests.RequestException as exc:
        elapsed = time.monotonic() - t0
        logger.warning(f"{TAG} GET {url} failed ({exc.__class__.__name__}: {exc}) in {elapsed:.2f}s")
        return None
    elapsed = time.monotonic() - t0
    if not resp.ok:
        logger.warning(f"{TAG} GET {resp.url} failed with HTTP {resp.status_code} in {elapsed:.2f}s")
        return None
    return resp


def _cookie_value(jar: requests.cookies.RequestsCookieJar, name: str) -> str:
    preferred = ""
    fallback = ""
    for cookie in jar:
        if cookie.name != name or not cookie.value:
            continue
        dom = (cookie.domain or "").lstrip(".").lower()
        if dom == "store.steampowered.com":
            preferred = cookie.value
            break
        if dom.endswith("steampowered.com") and not fallback:
            fallback = cookie.value
    return preferred or fallback


def parse_search_results_html(results_html: str) -> list[tuple[int, str]]:
    """Extract (appid, title) pairs strictly discounted -100% from Steam search HTML."""
    found: list[tuple[int, str]] = []
    seen: set[int] = set()
    for match in _ROW_RE.finditer(results_html or ""):
        row = match.group(0)
        if not _DISCOUNT_100_RE.search(row):
            continue
        appid_match = _APPID_ATTR_RE.search(row)
        if not appid_match:
            continue
        title_match = _TITLE_RE.search(row)
        raw_title = html.unescape(title_match.group(1)).strip() if title_match else ""
        for token in appid_match.group(1).split(","):
            token = token.strip()
            if token.isdigit():
                aid = int(token)
                if aid > 0 and aid not in seen:
                    seen.add(aid)
                    found.append((aid, raw_title))
    return found


def _fetch_promo_candidates_with_status(session: requests.Session) -> tuple[list[tuple[int, str]], bool]:
    """Query Steam Store search for -100% items. Returns (candidates, network_ok)."""
    candidates: list[tuple[int, str]] = []
    seen: set[int] = set()
    start = 0
    page_size = 50
    any_page_ok = False

    while start < _MAX_SEARCH_ITEMS:
        resp = _http_get(
            session,
            SEARCH_URL,
            params={
                "query": "",
                "start": start,
                "count": page_size,
                "maxprice": "free",
                "specials": 1,
                "ndl": 1,
                "infinite": 1,
            },
        )
        if resp is None:
            break
        try:
            payload = resp.json()
        except ValueError:
            logger.warning(f"{TAG} Invalid JSON from {SEARCH_URL}")
            break
        if not isinstance(payload, dict):
            break

        any_page_ok = True
        for aid, title in parse_search_results_html(str(payload.get("results_html") or "")):
            if aid not in seen:
                seen.add(aid)
                candidates.append((aid, title))

        total_count = int(payload.get("total_count") or 0)
        start += page_size
        if start >= total_count:
            break

    return candidates, any_page_ok


def fetch_promo_candidates(session: requests.Session) -> list[tuple[int, str]]:
    """Query Steam Store search for items currently discounted 100% to free."""
    candidates, _ = _fetch_promo_candidates_with_status(session)
    return candidates


def is_paid_100_percent_promo(entry: dict) -> bool:
    """Return True only for paid games/DLCs running a 100%-off Free-to-Keep promotion."""
    if not isinstance(entry, dict):
        return False
    item_type = str(entry.get("type") or "").strip().lower()
    if item_type not in ("game", "dlc"):
        return False
    if bool((entry.get("release_date") or {}).get("coming_soon")):
        return False

    po = entry.get("price_overview")
    if isinstance(po, dict):
        if int(po.get("discount_percent") or 0) == 100 and int(po.get("initial") or 0) > 0:
            return True

    has_paid_sub = False
    has_100_free_sub = False
    for group in entry.get("package_groups") or []:
        if not isinstance(group, dict):
            continue
        for sub in group.get("subs") or []:
            if not isinstance(sub, dict):
                continue
            price = int(sub.get("price_in_cents_with_discount") or 0)
            is_free_lic = bool(sub.get("is_free_license"))
            savings_txt = str(sub.get("percent_savings_text") or "")
            if not is_free_lic and price > 0:
                has_paid_sub = True
            if is_free_lic and price == 0 and _DISCOUNT_100_RE.search(savings_txt):
                has_100_free_sub = True
    return has_paid_sub and has_100_free_sub


def extract_free_promo_subid(
    entry: dict,
    session: requests.Session | None = None,
    appid: int = 0,
) -> int | None:
    """Locate the promotional 0-price package subid from appdetails or the store page."""
    ranked: list[tuple[int, int]] = []
    for group in (entry or {}).get("package_groups") or []:
        if not isinstance(group, dict):
            continue
        for sub in group.get("subs") or []:
            if not isinstance(sub, dict):
                continue
            pkg_id = int(sub.get("packageid") or 0)
            price = int(sub.get("price_in_cents_with_discount") or 0)
            if pkg_id > 0 and bool(sub.get("is_free_license")) and price == 0:
                savings = str(sub.get("percent_savings_text") or "")
                opt_text = str(sub.get("option_text") or "").lower()
                prio = 2 if (_DISCOUNT_100_RE.search(savings) or "promotional" in opt_text) else 1
                ranked.append((prio, pkg_id))

    if ranked:
        ranked.sort(key=lambda item: item[0], reverse=True)
        return ranked[0][1]

    if session is not None and appid > 0:
        resp = _http_get(session, APP_PAGE_URL.format(appid=appid))
        if resp is not None:
            for pattern in (_FORM_SUBID_RE, _JS_SUBID_RE):
                m = pattern.search(resp.text)
                if m:
                    return int(m.group(1))
    return None


def load_steam_store_session(port: int = cdp.DEFAULT_PORT) -> tuple[requests.Session, str, str] | None:
    """Build an authenticated store.steampowered.com Session from the running Steam CEF client."""
    state, target = steam_debug.probe(port=port)
    if target is None:
        logger.warning(f"{TAG} Steam CEF bridge unavailable ({state.value}); cannot claim promos yet")
        return None

    ws_url = str(target.get("webSocketDebuggerUrl") or "")
    try:
        cdp_sess = cdp.CdpSession(ws_url)
        try:
            raw_cookies = (cdp_sess.call("Network.getAllCookies") or {}).get("cookies") or []
        finally:
            cdp_sess.close()
    except cdp.CdpError as exc:
        logger.warning(f"{TAG} Failed to read Steam CEF cookies: {exc}")
        return None

    session = _make_public_session()
    loaded_count = 0
    for cookie in raw_cookies:
        if not isinstance(cookie, dict):
            continue
        domain = str(cookie.get("domain") or "").strip()
        clean_dom = domain.lstrip(".").lower()
        name = str(cookie.get("name") or "").strip()
        value = str(cookie.get("value") or "")
        if clean_dom in ("store.steampowered.com", "steampowered.com") and name and value:
            session.cookies.set(name, value, domain=clean_dom, path=str(cookie.get("path") or "/"))
            loaded_count += 1

    steam_login = _cookie_value(session.cookies, "steamLoginSecure")
    if not steam_login:
        logger.warning(f"{TAG} Steam Desktop is not signed in to Steam Store (steamLoginSecure missing)")
        return None

    prefix = steam_login.split("%7C", 1)[0].split("|", 1)[0].strip()
    steamid = prefix if prefix.isdigit() else "active"

    session_id = _cookie_value(session.cookies, "sessionid")
    if not session_id:
        _http_get(session, STORE_ABOUT_URL)
        session_id = _cookie_value(session.cookies, "sessionid")
    if not session_id:
        logger.warning(f"{TAG} Could not obtain store.steampowered.com sessionid cookie")
        return None

    logger.debug(f"{TAG} Loaded {loaded_count} Steam Store cookie(s) via CEF")
    return session, session_id, steamid


def fetch_owned_store_ids(session: requests.Session) -> tuple[set[int], set[int]] | None:
    """Fetch (owned_appids, owned_packageids) from dynamicstore/userdata."""
    resp = _http_get(session, USERDATA_URL, params={"_": int(time.time())})
    if resp is None:
        return None
    try:
        data = resp.json()
    except ValueError:
        logger.warning(f"{TAG} Invalid JSON from {USERDATA_URL}")
        return None
    if not isinstance(data, dict):
        return None

    owned_apps = {int(x) for x in (data.get("rgOwnedApps") or []) if str(x).isdigit()}
    owned_pkgs = {int(x) for x in (data.get("rgOwnedPackages") or []) if str(x).isdigit()}
    if not owned_pkgs and not owned_apps:
        logger.warning(f"{TAG} Steam Store session expired or unauthenticated (userdata empty)")
        return None
    return owned_apps, owned_pkgs


def claim_free_license(
    session: requests.Session,
    session_id: str,
    appid: int,
    subid: int,
    title: str,
    item_type: str,
) -> str:
    """POST freelicense/addfreelicense/{subid}. Returns claimed | already_owned | missing_base | rate_limited | error."""
    url = ADD_FREE_LICENSE_URL.format(subid=subid)
    t0 = time.monotonic()
    try:
        resp = session.post(
            url,
            data={"ajax": "true", "sessionid": session_id},
            headers={
                "Origin": "https://store.steampowered.com",
                "Referer": APP_PAGE_URL.format(appid=appid),
                "X-Requested-With": "XMLHttpRequest",
            },
            timeout=_HTTP_TIMEOUT,
            allow_redirects=False,
        )
    except requests.RequestException as exc:
        elapsed = time.monotonic() - t0
        logger.warning(f"{TAG} POST {url} failed ({exc.__class__.__name__}: {exc}) in {elapsed:.2f}s")
        return "error"

    elapsed = time.monotonic() - t0
    try:
        body = resp.json()
    except ValueError:
        body = None

    detail = body.get("purchaseresultdetail") if isinstance(body, dict) else None
    if detail == 9:
        return "already_owned"
    if detail == 24:
        return "missing_base"
    if detail == 53:
        logger.warning(f"{TAG} POST {url} rate-limited by Steam (HTTP {resp.status_code}, detail=53) in {elapsed:.2f}s")
        return "rate_limited"

    if resp.status_code == 200 and (
        isinstance(body, list)
        or (isinstance(body, dict) and detail in (None, 0) and not body.get("error"))
    ):
        logger.info(f"{TAG} Claimed {title!r} (appid={appid}, subid={subid}, type={item_type}) in {elapsed:.2f}s")
        return "claimed"

    logger.warning(f"{TAG} POST {url} failed (HTTP {resp.status_code}, detail={detail}) in {elapsed:.2f}s")
    return "error"


def ensure_steam_debug_marker() -> bool:
    """Ensure <Steam>/.cef-enable-remote-debugging exists. Returns True only when newly created."""
    if steam_debug.marker_path() and not steam_debug.is_debug_marker_present():
        if steam_debug.set_debug_marker(True):
            logger.info(f"{TAG} Enabled Steam CEF remote-debugging marker (takes effect on next Steam start)")
            return True
    return False


def _fetch_appdetails_entry(session: requests.Session, appid: int) -> dict | None:
    resp = _http_get(session, APPDETAILS_URL, params={"appids": str(appid), "l": "english"})
    if resp is None:
        return None
    try:
        app_payload = resp.json()
    except ValueError:
        logger.warning(f"{TAG} Invalid JSON from {APPDETAILS_URL} for appid={appid}")
        return None
    app_wrap = (app_payload or {}).get(str(appid)) or {}
    entry = app_wrap.get("data") if app_wrap.get("success") else None
    return entry if isinstance(entry, dict) else None


def run_free_keep_scan(port: int = cdp.DEFAULT_PORT) -> dict:
    """Scan Steam Store for 100%-off paid games/DLCs and auto-claim eligible ones."""
    t0 = time.monotonic()
    logger.info(f"{TAG} Starting Steam 100%-off free-to-keep scan")
    created_marker = ensure_steam_debug_marker()

    pub_session = _make_public_session()
    candidates = fetch_promo_candidates(pub_session)
    if not candidates:
        elapsed = time.monotonic() - t0
        logger.info(f"{TAG} Scan finished in {elapsed:.2f}s: 0 promo(s) found")
        return {
            "claimed": [],
            "candidates": 0,
            "already_owned": 0,
            "skipped": 0,
            "created_marker": created_marker,
        }

    auth = load_steam_store_session(port=port)
    if auth is None:
        elapsed = time.monotonic() - t0
        logger.info(f"{TAG} Scan deferred in {elapsed:.2f}s: {len(candidates)} candidate(s) awaiting Steam session")
        return {
            "claimed": [],
            "candidates": len(candidates),
            "already_owned": 0,
            "skipped": len(candidates),
            "created_marker": created_marker,
        }

    session, session_id, steamid = auth
    owned = fetch_owned_store_ids(session)
    if owned is None:
        elapsed = time.monotonic() - t0
        logger.info(f"{TAG} Scan aborted in {elapsed:.2f}s: could not read Steam account ownership")
        return {
            "claimed": [],
            "candidates": len(candidates),
            "already_owned": 0,
            "skipped": len(candidates),
            "created_marker": created_marker,
        }

    owned_apps, owned_pkgs = owned
    claimed: list[dict] = []
    already_owned = 0
    skipped = 0

    for appid, fallback_title in candidates:
        with _claimed_lock:
            cached = (steamid, appid) in _claimed_cache
        if appid in owned_apps or cached:
            already_owned += 1
            logger.debug(f"{TAG} Skipping already owned appid={appid} ({fallback_title!r})")
            continue

        entry = _fetch_appdetails_entry(session, appid)
        if entry is None:
            skipped += 1
            continue
        if not is_paid_100_percent_promo(entry):
            skipped += 1
            logger.debug(f"{TAG} Rejected appid={appid} ({fallback_title!r}): not a paid 100%-off game/DLC")
            continue

        title = str(entry.get("name") or fallback_title or f"App {appid}").strip()
        item_type = str(entry.get("type") or "game").strip().lower()

        if item_type == "dlc":
            base_appid_raw = (entry.get("fullgame") or {}).get("appid")
            base_appid = int(base_appid_raw) if str(base_appid_raw or "").isdigit() else 0
            if not base_appid or base_appid not in owned_apps:
                skipped += 1
                logger.debug(f"{TAG} Skipping DLC {title!r} (appid={appid}): base game {base_appid} not owned")
                continue

        subid = extract_free_promo_subid(entry, session=session, appid=appid)
        if not subid:
            skipped += 1
            logger.warning(f"{TAG} Could not locate free promo subid for {title!r} (appid={appid})")
            continue

        if subid in owned_pkgs:
            already_owned += 1
            with _claimed_lock:
                _claimed_cache.add((steamid, appid))
            logger.debug(f"{TAG} Package subid={subid} already owned for {title!r}")
            continue

        outcome = claim_free_license(session, session_id, appid, subid, title, item_type)
        if outcome == "claimed":
            owned_apps.add(appid)
            owned_pkgs.add(subid)
            with _claimed_lock:
                _claimed_cache.add((steamid, appid))
            item = ClaimedItem(appid=appid, subid=subid, title=title, item_type=item_type)
            claimed.append({
                "appid": item.appid,
                "subid": item.subid,
                "title": item.title,
                "item_type": item.item_type,
            })
        elif outcome == "already_owned":
            already_owned += 1
            with _claimed_lock:
                _claimed_cache.add((steamid, appid))
        elif outcome == "rate_limited":
            skipped += 1
            break
        else:
            skipped += 1

    elapsed = time.monotonic() - t0
    logger.info(
        f"{TAG} Scan finished in {elapsed:.2f}s: {len(candidates)} promo(s) found, "
        f"{len(claimed)} claimed, {already_owned} already owned, {skipped} skipped"
    )
    return {
        "claimed": claimed,
        "candidates": len(candidates),
        "already_owned": already_owned,
        "skipped": skipped,
        "created_marker": created_marker,
    }


def fetch_active_free_promos(port: int = cdp.DEFAULT_PORT, auto_claim: bool = True) -> dict:
    """Return full display metadata for all paid games & DLCs currently discounted 100% on Steam."""
    t0 = time.monotonic()
    logger.info(f"{TAG} Listing active 100%-off Steam promos (auto_claim={auto_claim})")
    created_marker = ensure_steam_debug_marker()

    pub_session = _make_public_session()
    candidates, network_ok = _fetch_promo_candidates_with_status(pub_session)
    checked_at = time.strftime("%H:%M:%S")

    auth = load_steam_store_session(port=port)
    steam_connected = False
    owned_apps: set[int] = set()
    owned_pkgs: set[int] = set()
    session = pub_session
    session_id = ""
    steamid = ""

    if auth is not None:
        auth_sess, auth_sid, auth_steamid = auth
        owned = fetch_owned_store_ids(auth_sess)
        if owned is not None:
            session = auth_sess
            session_id = auth_sid
            steamid = auth_steamid
            owned_apps, owned_pkgs = owned
            steam_connected = True

    if not network_ok:
        elapsed = time.monotonic() - t0
        logger.warning(f"{TAG} Active promo listing failed due to Steam Store network error in {elapsed:.2f}s")
        return {
            "items": [],
            "claimed": [],
            "steam_connected": steam_connected,
            "created_marker": created_marker,
            "checked_at": checked_at,
            "network_error": True,
        }

    items: list[dict] = []
    claimed: list[dict] = []
    rate_limited = False

    for appid, fallback_title in candidates:
        entry = _fetch_appdetails_entry(session, appid)
        if entry is None or not is_paid_100_percent_promo(entry):
            logger.debug(f"{TAG} Excluded appid={appid} ({fallback_title!r}) from active promo list")
            continue

        title = str(entry.get("name") or fallback_title or f"App {appid}").strip()
        item_type = str(entry.get("type") or "game").strip().lower()
        po = entry.get("price_overview") if isinstance(entry.get("price_overview"), dict) else {}
        original_price = str(po.get("initial_formatted") or "").strip()
        header_image = str(entry.get("header_image") or "").strip()
        fullgame = entry.get("fullgame") if isinstance(entry.get("fullgame"), dict) else {}
        base_appid_raw = fullgame.get("appid")
        base_appid = int(base_appid_raw) if str(base_appid_raw or "").isdigit() else 0
        base_game_name = str(fullgame.get("name") or "").strip()
        subid = extract_free_promo_subid(entry, session=session, appid=appid) or 0

        with _claimed_lock:
            cached = bool(steamid) and (steamid, appid) in _claimed_cache

        is_owned = steam_connected and (
            appid in owned_apps or (subid > 0 and subid in owned_pkgs) or cached
        )
        status = "owned" if is_owned else "available"

        if not is_owned and steam_connected:
            if item_type == "dlc" and (not base_appid or base_appid not in owned_apps):
                status = "missing_base"
            elif auto_claim and subid > 0 and not rate_limited:
                outcome = claim_free_license(session, session_id, appid, subid, title, item_type)
                if outcome == "claimed":
                    status = "claimed"
                    owned_apps.add(appid)
                    owned_pkgs.add(subid)
                    with _claimed_lock:
                        _claimed_cache.add((steamid, appid))
                    claimed.append({
                        "appid": appid,
                        "subid": subid,
                        "title": title,
                        "item_type": item_type,
                    })
                elif outcome == "already_owned":
                    status = "owned"
                    with _claimed_lock:
                        _claimed_cache.add((steamid, appid))
                elif outcome == "missing_base":
                    status = "missing_base"
                elif outcome == "rate_limited":
                    rate_limited = True

        items.append({
            "appid": appid,
            "subid": subid,
            "title": title,
            "item_type": item_type,
            "original_price": original_price,
            "header_image": header_image,
            "store_url": APP_PAGE_URL.format(appid=appid),
            "base_appid": base_appid,
            "base_game_name": base_game_name,
            "status": status,
        })

    elapsed = time.monotonic() - t0
    logger.info(
        f"{TAG} Listed {len(items)} active 100%-off promo(s) in {elapsed:.2f}s "
        f"(claimed={len(claimed)}, steam_connected={steam_connected})"
    )
    return {
        "items": items,
        "claimed": claimed,
        "steam_connected": steam_connected,
        "created_marker": created_marker,
        "checked_at": checked_at,
        "network_error": False,
    }


def claim_single_promo(
    appid: int,
    subid: int = 0,
    title: str = "",
    item_type: str = "game",
    port: int = cdp.DEFAULT_PORT,
) -> dict:
    """Manually claim a single 100%-off Steam game/DLC into the active Steam Desktop account."""
    logger.info(f"{TAG} Manual claim requested for {title or appid!r} (appid={appid}, subid={subid})")
    ensure_steam_debug_marker()
    auth = load_steam_store_session(port=port)
    if auth is None:
        return {
            "ok": False,
            "outcome": "no_steam",
            "message": (
                "Chưa kết nối được phiên Steam Desktop. Hãy mở Steam, đăng nhập tài khoản "
                "(khởi động lại Steam nếu mới bật lần đầu) rồi thử lại."
            ),
        }

    session, session_id, steamid = auth
    resolved_subid = int(subid or 0)
    if resolved_subid <= 0:
        entry = _fetch_appdetails_entry(session, appid)
        if entry is not None:
            resolved_subid = extract_free_promo_subid(entry, session=session, appid=appid) or 0
            if not title:
                title = str(entry.get("name") or f"App {appid}").strip()
            item_type = str(entry.get("type") or item_type or "game").strip().lower()

    if resolved_subid <= 0:
        logger.warning(f"{TAG} Manual claim failed: no free promo subid found for appid={appid}")
        return {
            "ok": False,
            "outcome": "no_subid",
            "message": "Không tìm thấy gói khuyến mãi 0đ hợp lệ trên Steam. Hãy bấm 'Mở Steam' để kiểm tra trực tiếp.",
        }

    outcome = claim_free_license(session, session_id, appid, resolved_subid, title or f"App {appid}", item_type)
    if outcome in ("claimed", "already_owned"):
        with _claimed_lock:
            _claimed_cache.add((steamid, appid))
        msg = (
            f'Đã thêm "{title or appid}" vào tài khoản Steam vĩnh viễn.'
            if outcome == "claimed"
            else f'"{title or appid}" đã có sẵn trong tài khoản Steam của bạn.'
        )
        return {"ok": True, "outcome": outcome, "subid": resolved_subid, "message": msg}
    if outcome == "missing_base":
        return {
            "ok": False,
            "outcome": "missing_base",
            "message": "Tài khoản Steam chưa sở hữu game gốc của DLC này.",
        }
    if outcome == "rate_limited":
        return {
            "ok": False,
            "outcome": "rate_limited",
            "message": "Steam đang giới hạn tốc độ nhận miễn phí. Vui lòng thử lại sau ít phút.",
        }
    return {
        "ok": False,
        "outcome": "error",
        "message": "Không thể nhận tự động qua Steam. Bạn có thể bấm 'Mở Steam' để nhận trực tiếp.",
    }


def fetch_banner_bytes(url: str) -> bytes:
    """Download a Steam header capsule image off the UI thread."""
    if not url:
        return b""
    t0 = time.monotonic()
    try:
        resp = requests.get(url, headers={"User-Agent": _USER_AGENT}, timeout=10)
    except requests.RequestException as exc:
        logger.warning(f"{TAG} Banner GET {url} failed ({exc.__class__.__name__}: {exc}) in {time.monotonic() - t0:.2f}s")
        return b""
    if not resp.ok:
        logger.warning(f"{TAG} Banner GET {url} failed with HTTP {resp.status_code} in {time.monotonic() - t0:.2f}s")
        return b""
    return resp.content


class SteamFreeKeepWorker(QObject):
    """Background worker executing run_free_keep_scan() off the GUI thread."""

    finished = Signal(dict)

    def __init__(self, port: int = cdp.DEFAULT_PORT, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.port = port

    @Slot()
    def run(self) -> None:
        try:
            result = run_free_keep_scan(port=self.port)
        except Exception as exc:
            logger.exception(f"{TAG} Unexpected error during Steam free-to-keep scan")
            result = {
                "claimed": [],
                "candidates": 0,
                "already_owned": 0,
                "skipped": 0,
                "created_marker": False,
                "error": str(exc),
            }
        self.finished.emit(result)
