"""
Steam integration manager for Bob Gaming Game Center.
Handles Steam path detection, user profiles, process state, shortcut management,
and executable discovery heuristics.
"""

import logging
import os
import shutil
import subprocess
import sys
import time

from app.core.steam_vdf import (
    calculate_shortcut_appid,
    load_shortcuts_vdf,
    save_shortcuts_vdf,
)

logger = logging.getLogger(__name__)
TAG = "[Steam/Manager]"

# Excluded executable substrings/names that are definitely not main game binaries
EXCLUDE_EXE_NAMES = {
    "unins000.exe", "uninstall.exe", "uninstaller.exe",
    "crashreporter.exe", "crash_reporter.exe", "crashhandler.exe",
    "unitycrashhandler64.exe", "unitycrashhandler32.exe",
    "dxsetup.exe", "vcredist_x64.exe", "vcredist_x86.exe",
    "setup.exe", "installer.exe", "updater.exe", "update.exe",
    "patcher.exe", "launcher_updater.exe",
    "easyanticheat.exe", "easyanticheat_setup.exe", "start_protected_game.exe",
    "battleye.exe", "beservice.exe", "beservice_x64.exe",
    "directx.exe", "dotnetfx.exe",
}

EXCLUDE_EXE_PATTERNS = [
    "redist", "unins", "crash", "reporter", "diagnostics",
    "benchmark", "dedicatedserver", "server.exe", "eac_",
]


def is_steam_game_mode() -> bool:
    """Return True if running in SteamOS Game Mode (gamescope session)."""
    return (
        os.environ.get("SteamGamepadUI") == "1"
        or os.environ.get("SteamTenfoot") == "1"
        or os.environ.get("XDG_CURRENT_DESKTOP") == "gamescope"
        or bool(os.environ.get("GAMESCOPE_WAYLAND_DISPLAY"))
    )


def should_avoid_steam_restart() -> bool:
    """
    Return True when shutting down or restarting Steam would deadlock or freeze
    the active session (SteamOS Game Mode, Steam Deck wrapper, or running as a Steam child app).
    """
    return (
        is_steam_game_mode()
        or os.environ.get("SteamDeck") == "1"
        or os.environ.get("BOB_WRAPPER_MANAGED") == "1"
        or bool(os.environ.get("SteamGameId"))
        or bool(os.environ.get("SteamAppId"))
    )


def find_proton_executable(steam_path: str | None = None, uint_appid: int = 0) -> str | None:
    """
    Locate the best available Steam Proton `proton` runner on Linux / SteamOS.
    Honors per-shortcut CompatToolMapping from config.vdf when available, falling back
    to Proton - Experimental, GE-Proton, Proton Hotfix, and versioned Proton builds.
    """
    if sys.platform == "win32":
        return None

    sp = steam_path or find_steam_path()
    preferred_tool = ""
    if sp and uint_appid > 0:
        try:
            from app.core.steam_compat import get_proton_compatibility
            mapping = get_proton_compatibility(sp, uint_appid)
            if mapping and mapping.get("name"):
                preferred_tool = str(mapping["name"]).strip().lower()
        except Exception as exc:
            logger.debug(f"{TAG} Could not read CompatToolMapping for AppID {uint_appid}: {exc}")

    home = os.path.expanduser("~")
    raw_roots: list[str] = []
    if sp:
        raw_roots.extend([
            os.path.join(sp, "compatibilitytools.d"),
            os.path.join(sp, "steamapps", "common"),
        ])
    if not steam_path:
        raw_roots.extend([
            os.path.join(home, ".steam", "root", "compatibilitytools.d"),
            os.path.join(home, ".local", "share", "Steam", "compatibilitytools.d"),
            os.path.join(home, ".steam", "root", "steamapps", "common"),
            os.path.join(home, ".local", "share", "Steam", "steamapps", "common"),
            "/home/deck/.local/share/Steam/compatibilitytools.d",
            "/home/deck/.local/share/Steam/steamapps/common",
            "/usr/share/steam/compatibilitytools.d",
            "/usr/share/steam/steamapps/common",
        ])

    seen_roots: set[str] = set()
    candidates: list[tuple[int, str, str]] = []
    for root in raw_roots:
        if not root or not os.path.isdir(root):
            continue
        real_root = os.path.realpath(root)
        if real_root in seen_roots:
            continue
        seen_roots.add(real_root)
        try:
            entries = os.listdir(real_root)
        except OSError:
            continue

        for entry in entries:
            low = entry.lower()
            if "proton" not in low:
                continue
            cand = os.path.join(real_root, entry, "proton")
            if not (os.path.isfile(cand) and os.access(cand, os.X_OK)):
                continue

            score = 200
            if "experimental" in low:
                score = 500
            elif low.startswith("ge-proton") or "proton-ge" in low:
                score = 400
            elif "hotfix" in low:
                score = 350

            if preferred_tool:
                norm_entry = low.replace(" - ", "_").replace(" ", "_").replace("-", "_")
                norm_pref = preferred_tool.replace("-", "_")
                if (
                    low == preferred_tool
                    or norm_entry == norm_pref
                    or (preferred_tool == "proton_experimental" and "experimental" in low)
                    or (preferred_tool == "proton_hotfix" and "hotfix" in low)
                    or (norm_pref.startswith("proton_") and norm_pref.split("_", 1)[1] in norm_entry)
                ):
                    score += 1000

            candidates.append((score, low, cand))

    if not candidates:
        return None
    candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
    best_proton = candidates[0][2]
    logger.debug(f"{TAG} Selected Proton runner: {best_proton} (preferred={preferred_tool or 'auto'})")
    return best_proton


def find_steam_path() -> str | None:
    """
    Locate Steam installation directory on Linux / SteamOS or Windows.
    Resolves symlinks to canonical directory.
    """
    # 1. Linux / SteamOS resolution
    if sys.platform != "win32":
        env_root = os.environ.get("STEAM_DIR") or os.environ.get("STEAM_ROOT")
        if env_root and os.path.isdir(env_root):
            return os.path.realpath(env_root)

        home = os.path.expanduser("~")
        candidates = [
            os.path.join(home, ".local", "share", "Steam"),  # Standard XDG / SteamOS
            "/home/deck/.local/share/Steam",                   # Fixed Steam Deck user path
            os.path.join(home, ".steam", "steam"),            # Canonical symlink
            os.path.join(home, ".steam", "root"),             # Valve legacy symlink
            os.path.join(home, ".var", "app", "com.valvesoftware.Steam", ".local", "share", "Steam"), # Flatpak
        ]
        for candidate in candidates:
            if os.path.isdir(candidate):
                real = os.path.realpath(candidate)
                if os.path.isdir(real) and (
                    os.path.isdir(os.path.join(real, "userdata"))
                    or os.path.isdir(os.path.join(real, "config"))
                    or os.path.isfile(os.path.join(real, "steam.sh"))
                ):
                    return real
        for candidate in candidates:
            if os.path.isdir(candidate):
                return os.path.realpath(candidate)
        return None

    # 2. Windows resolution (Registry HKCU / HKLM and common drives)
    try:
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as key:
                val, _ = winreg.QueryValueEx(key, "SteamPath")
                if val and os.path.isdir(str(val)):
                    return os.path.normpath(str(val))
        except (FileNotFoundError, OSError):
            pass

        for hive_path in [
            r"SOFTWARE\WOW6432Node\Valve\Steam",
            r"SOFTWARE\Valve\Steam",
        ]:
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, hive_path) as key:
                    val, _ = winreg.QueryValueEx(key, "InstallPath")
                    if val and os.path.isdir(str(val)):
                        return os.path.normpath(str(val))
            except (FileNotFoundError, OSError):
                pass
    except ImportError:
        pass

    drives = ["C", "D", "E", "P", "G", "F"]
    candidates = [
        r":\Program Files (x86)\Steam",
        r":\Program Files\Steam",
        r":\Steam",
    ]
    for drive in drives:
        for pattern in candidates:
            path = f"{drive}{pattern}"
            if os.path.isdir(path) and (
                os.path.exists(os.path.join(path, "steam.exe"))
                or os.path.isdir(os.path.join(path, "userdata"))
            ):
                return os.path.normpath(path)

    return None


def get_steam_executable(steam_path: str | None = None) -> str | None:
    """Return path or command to invoke the Steam client binary."""
    if sys.platform == "win32":
        sp = steam_path or find_steam_path()
        if sp:
            exe = os.path.join(sp, "steam.exe")
            if os.path.isfile(exe):
                return exe
        if not steam_path:
            return shutil.which("steam.exe")
        return None

    # Linux / SteamOS
    sp = steam_path or find_steam_path()
    if sp:
        sh = os.path.join(sp, "steam.sh")
        if os.path.isfile(sh) and os.access(sh, os.X_OK):
            return sh
    which_steam = shutil.which("steam")
    if which_steam:
        return which_steam
    if shutil.which("flatpak"):
        return "flatpak"
    if not steam_path:
        return "steam"
    return None


def get_primary_steam_user_id(steam_path: str | None = None) -> str | None:
    """
    Discover the active / most recent Steam AccountID (32-bit uint string).
    Checks loginusers.vdf -> localconfig.vdf mtime -> first userdata directory.
    """
    sp = steam_path or find_steam_path()
    if not sp:
        return None

    # 1. Parse config/loginusers.vdf
    loginusers_file = os.path.join(sp, "config", "loginusers.vdf")
    if os.path.isfile(loginusers_file):
        try:
            with open(loginusers_file, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()

            import re
            user_blocks = re.findall(r'"(\d{15,20})"\s*\{([^}]+)\}', content)
            best_id: str | None = None
            best_ts = -1
            for sid64, block in user_blocks:
                is_recent = re.search(r'"MostRecent"\s*"1"', block, re.IGNORECASE)
                ts_match = re.search(r'"Timestamp"\s*"(\d+)"', block, re.IGNORECASE)
                ts = int(ts_match.group(1)) if ts_match else 0
                if is_recent:
                    best_id = str(int(sid64) & 0xFFFFFFFF)
                    break
                if ts > best_ts:
                    best_ts = ts
                    best_id = str(int(sid64) & 0xFFFFFFFF)
            if best_id:
                return best_id
        except Exception as e:
            logger.debug(f"{TAG} Error parsing loginusers.vdf: {e}")

    # 2. Fallback: Most recently modified userdata/<id>/config/localconfig.vdf
    userdata_dir = os.path.join(sp, "userdata")
    if not os.path.isdir(userdata_dir):
        return None

    raw_ids = []
    try:
        for entry in os.listdir(userdata_dir):
            full_path = os.path.join(userdata_dir, entry)
            if os.path.isdir(full_path) and entry.isdigit() and entry != "0":
                raw_ids.append(entry)
    except OSError:
        return None

    if not raw_ids:
        return None
    if len(raw_ids) == 1:
        return raw_ids[0]

    def _user_mtime(uid: str) -> float:
        cfg = os.path.join(userdata_dir, uid, "config", "localconfig.vdf")
        if os.path.isfile(cfg):
            return os.path.getmtime(cfg)
        return os.path.getmtime(os.path.join(userdata_dir, uid))

    raw_ids.sort(key=_user_mtime, reverse=True)
    return raw_ids[0]


def get_steam_user_ids(steam_path: str | None = None) -> list[str]:
    """Find all valid user IDs in <SteamPath>/userdata/, sorted with primary user first."""
    if not steam_path:
        steam_path = find_steam_path()
    if not steam_path:
        return []

    userdata_dir = os.path.join(steam_path, "userdata")
    if not os.path.isdir(userdata_dir):
        return []

    raw_ids = []
    try:
        for entry in os.listdir(userdata_dir):
            full_path = os.path.join(userdata_dir, entry)
            if os.path.isdir(full_path) and entry.isdigit() and entry != "0":
                raw_ids.append(entry)
    except OSError as e:
        logger.error(f"{TAG} Error scanning Steam userdata directory: {e}")

    if not raw_ids:
        return []

    primary = get_primary_steam_user_id(steam_path)
    if primary and primary in raw_ids:
        raw_ids.remove(primary)
        return [primary] + sorted(raw_ids)
    return sorted(raw_ids)


def is_steam_running() -> bool:
    """Check if Steam (steam.exe on Windows, steam on Linux) is currently running."""
    valid_names = {"steam.exe"} if sys.platform == "win32" else {"steam"}
    try:
        import psutil
        for proc in psutil.process_iter(["name"]):
            try:
                name = proc.info.get("name")
                if name and name.lower() in valid_names:
                    return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return False
    except ImportError:
        if sys.platform == "win32":
            try:
                output = subprocess.check_output(
                    ["tasklist", "/FI", "IMAGENAME eq steam.exe"],
                    text=True,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                return "steam.exe" in output.lower()
            except Exception:
                return False
        else:
            try:
                res = subprocess.run(["pgrep", "-x", "steam"], stdout=subprocess.DEVNULL)
                return res.returncode == 0
            except Exception:
                return False


def close_steam(timeout: int = 8, steam_path: str | None = None) -> bool:
    """Gracefully request Steam shutdown, with fallback signals on timeout."""
    if is_steam_game_mode() or os.environ.get("SteamGameId") or os.environ.get("SteamAppId"):
        logger.warning(
            f"{TAG} Refused close_steam: running inside Steam Game Mode or as a Steam child app "
            f"(game_mode={is_steam_game_mode()}, SteamGameId={os.environ.get('SteamGameId')!r})"
        )
        return False

    if not is_steam_running():
        return True

    if not steam_path:
        steam_path = find_steam_path()

    # 1. Graceful shutdown request
    if sys.platform == "win32":
        if steam_path:
            steam_exe = os.path.join(steam_path, "steam.exe")
            if os.path.exists(steam_exe):
                try:
                    subprocess.Popen(
                        [steam_exe, "-shutdown"],
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    )
                except Exception as e:
                    logger.warning(f"{TAG} Failed to invoke steam -shutdown: {e}")
    else:
        steam_cmd = get_steam_executable(steam_path)
        try:
            if steam_cmd == "flatpak":
                subprocess.Popen(["flatpak", "run", "com.valvesoftware.Steam", "-shutdown"])
            elif steam_cmd:
                subprocess.Popen([steam_cmd, "-shutdown"])
        except Exception as e:
            logger.warning(f"{TAG} Failed to invoke linux steam -shutdown: {e}")

    # Wait for exit
    start = time.time()
    while time.time() - start < timeout:
        if not is_steam_running():
            return True
        time.sleep(0.5)

    # 2. Forced exit if still running
    if sys.platform == "win32":
        try:
            subprocess.run(
                ["taskkill", "/IM", "steam.exe"],
                capture_output=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception as e:
            logger.warning(f"{TAG} taskkill steam.exe failed: {e}")
    else:
        try:
            subprocess.run(["pkill", "-TERM", "-x", "steam"], capture_output=True)
            time.sleep(1.0)
            if is_steam_running():
                subprocess.run(["pkill", "-KILL", "-x", "steam"], capture_output=True)
        except Exception as e:
            logger.warning(f"{TAG} pkill steam failed: {e}")

    time.sleep(0.5)
    return not is_steam_running()


def find_game_executable(install_dir: str, game_name: str = "") -> str | None:
    """
    Heuristically find the primary executable for a game inside its installation folder.

    Ranking algorithm:
    1. Direct name match in root directory or bin/ pc/ Win64/ subdirectories.
    2. File size and path depth (prefers root or bin folder, penalizes deep subfolders).
    3. Excludes installers, uninstallers, crash handlers, redists, and tools.
    """
    if not install_dir or not os.path.isdir(install_dir):
        return None

    candidates: list[tuple[float, str]] = []
    norm_game_name = "".join(c.lower() for c in game_name if c.isalnum())

    try:
        for root, dirs, files in os.walk(install_dir):
            rel_path = os.path.relpath(root, install_dir)
            depth = 0 if rel_path == "." else len(rel_path.split(os.sep))
            # Don't scan deeper than 3 subdirectories
            if depth > 3:
                dirs.clear()
                continue

            for file in files:
                if not file.lower().endswith(".exe"):
                    continue

                lower_file = file.lower()
                # Check explicit exclude set
                if lower_file in EXCLUDE_EXE_NAMES:
                    continue

                # Check pattern exclusions
                if any(pat in lower_file for pat in EXCLUDE_EXE_PATTERNS):
                    continue

                full_path = os.path.normpath(os.path.join(root, file))
                try:
                    file_size = os.path.getsize(full_path)
                except OSError:
                    file_size = 0

                # Score the executable
                score = 0.0
                file_base = os.path.splitext(file)[0]
                norm_file_name = "".join(c.lower() for c in file_base if c.isalnum())

                # Exact or substring match with game name
                if norm_game_name and norm_game_name == norm_file_name:
                    score += 1000.0
                elif norm_game_name and norm_game_name in norm_file_name:
                    score += 500.0
                elif norm_game_name and norm_file_name in norm_game_name and len(norm_file_name) >= 4:
                    score += 300.0

                # Folder bonus
                lower_rel = rel_path.lower()
                if rel_path == ".":
                    score += 100.0
                elif "bin" in lower_rel or "win64" in lower_rel or "pc" in lower_rel:
                    score += 80.0

                # Size score: prefer larger files (actual game engines/binaries usually > 5MB)
                size_mb = file_size / (1024 * 1024)
                if size_mb >= 10.0:
                    score += min(size_mb, 200.0)
                elif size_mb < 1.0:
                    score -= 50.0  # tiny exe is likely a stub or tool

                candidates.append((score, full_path))

    except OSError as e:
        logger.error(f"Error searching executable in {install_dir}: {e}")

    if not candidates:
        return None

    # Sort descending by score
    candidates.sort(key=lambda x: x[0], reverse=True)
    best_score, best_path = candidates[0]
    logger.info(f"Auto-detected exe for '{game_name}': {best_path} (score={best_score:.1f})")
    return best_path


def get_grid_dir(steam_path: str, user_id: str) -> str:
    """
    Get and ensure the grid artwork folder path for a specific user ID.
    """
    grid_dir = os.path.join(steam_path, "userdata", user_id, "config", "grid")
    os.makedirs(grid_dir, exist_ok=True)
    return grid_dir


def check_shortcut_artworks(steam_path: str, user_id: str, uint_appid: int) -> dict[str, bool]:
    """
    Check if artworks exist for a shortcut AppID in the user's grid folder.

    Returns:
        {"poster": bool, "grid": bool, "hero": bool, "logo": bool, "icon": bool}
    """
    grid_dir = get_grid_dir(steam_path, user_id)
    sid = str(uint_appid)

    # 1. Poster: {appid}p.png or {appid}p.jpg
    poster = any(os.path.exists(os.path.join(grid_dir, f"{sid}p{ext}")) for ext in [".png", ".jpg", ".jpeg"])

    # 2. Grid (horizontal): {appid}.png or {appid}.jpg
    grid = any(os.path.exists(os.path.join(grid_dir, f"{sid}{ext}")) for ext in [".png", ".jpg", ".jpeg"])

    # 3. Hero: {appid}_hero.png or {appid}_hero.jpg
    hero = any(os.path.exists(os.path.join(grid_dir, f"{sid}_hero{ext}")) for ext in [".png", ".jpg", ".jpeg"])

    # 4. Logo: {appid}_logo.png
    logo = any(os.path.exists(os.path.join(grid_dir, f"{sid}_logo{ext}")) for ext in [".png", ".jpg", ".jpeg"])

    # 5. Icon: {appid}_icon.png or {appid}_icon.ico
    icon = any(os.path.exists(os.path.join(grid_dir, f"{sid}_icon{ext}")) for ext in [".png", ".ico", ".jpg"])

    return {
        "poster": poster,
        "grid": grid,
        "hero": hero,
        "logo": logo,
        "icon": icon,
    }


def get_all_steam_shortcuts(steam_path: str | None = None) -> list[dict]:
    """
    Get all non-Steam shortcuts across all user profiles.

    Returns list of dicts with shortcut metadata and artwork completeness status.
    """
    if not steam_path:
        steam_path = find_steam_path()
    if not steam_path:
        return []

    user_ids = get_steam_user_ids(steam_path)
    all_shortcuts = []
    seen_keys = set()

    for uid in user_ids:
        vdf_path = os.path.join(steam_path, "userdata", uid, "config", "shortcuts.vdf")
        if not os.path.exists(vdf_path):
            continue

        data = load_shortcuts_vdf(vdf_path)
        shortcuts_map = data.get("shortcuts", {})

        for idx, entry in shortcuts_map.items():
            if not isinstance(entry, dict):
                continue

            appname = entry.get("appname", "")
            exe = entry.get("exe", "")
            signed_appid = entry.get("appid", 0)
            uint_appid = signed_appid & 0xFFFFFFFF

            key = (appname.lower(), uint_appid)
            if key in seen_keys:
                continue
            seen_keys.add(key)

            art_status = check_shortcut_artworks(steam_path, uid, uint_appid)

            all_shortcuts.append({
                "appname": appname,
                "exe": exe,
                "StartDir": entry.get("StartDir", ""),
                "appid": signed_appid,
                "uint_appid": uint_appid,
                "user_id": uid,
                "artworks": art_status,
                "source": "steam_shortcut",
            })

    all_shortcuts.sort(key=lambda s: s["appname"].lower())
    return all_shortcuts


def add_non_steam_game(
    game_name: str,
    exe_path: str,
    start_dir: str | None = None,
    launch_options: str = "",
    tags: list[str] | None = None,
    steam_path: str | None = None,
    target_user_ids: list[str] | None = None,
) -> dict:
    """
    Add or update a non-Steam game shortcut across specified Steam profiles.

    Returns:
        {
            "success": bool,
            "appid": int (uint),
            "signed_appid": int,
            "affected_users": list[str],
            "message": str
        }
    """
    if not steam_path:
        steam_path = find_steam_path()
    if not steam_path:
        return {"success": False, "message": "Steam installation directory not found."}

    user_ids = target_user_ids or get_steam_user_ids(steam_path)
    if not user_ids:
        return {"success": False, "message": "No Steam user accounts found in userdata."}

    clean_exe = exe_path.strip('"')
    if not start_dir:
        start_dir = os.path.dirname(clean_exe)

    # Format paths with Steam conventions (quoted exe and trailing backslash for StartDir)
    formatted_exe = f'"{clean_exe}"'
    formatted_start_dir = start_dir if start_dir.endswith(os.sep) else f"{start_dir}{os.sep}"

    signed_appid, uint_appid, str_appid = calculate_shortcut_appid(clean_exe, game_name)

    affected_users = []
    for uid in user_ids:
        config_dir = os.path.join(steam_path, "userdata", uid, "config")
        os.makedirs(config_dir, exist_ok=True)
        vdf_path = os.path.join(config_dir, "shortcuts.vdf")

        shortcuts_doc = load_shortcuts_vdf(vdf_path)
        shortcuts = shortcuts_doc.setdefault("shortcuts", {})

        # Check if already exists by matching appname or exe
        target_idx = None
        for idx_str, entry in shortcuts.items():
            if not isinstance(entry, dict):
                continue
            if (
                entry.get("appname", "").lower() == game_name.lower()
                or entry.get("exe", "").strip('"').lower() == clean_exe.lower()
            ):
                target_idx = idx_str
                # Keep existing appid if found
                signed_appid = entry.get("appid", signed_appid)
                uint_appid = signed_appid & 0xFFFFFFFF
                break

        if target_idx is None:
            # Find next numerical index
            num_keys = [int(k) for k in shortcuts.keys() if k.isdigit()]
            next_num = max(num_keys) + 1 if num_keys else 0
            target_idx = str(next_num)

        # Construct tags sub-map
        tags_dict = {}
        if tags:
            for t_idx, tag_name in enumerate(tags):
                tags_dict[str(t_idx)] = str(tag_name)

        # Build shortcut entry conforming to Steam standards
        shortcut_entry = {
            "appid": signed_appid,
            "appname": game_name,
            "exe": formatted_exe,
            "StartDir": formatted_start_dir,
            "icon": "",
            "ShortcutPath": "",
            "LaunchOptions": launch_options,
            "IsHidden": 0,
            "AllowDesktopConfig": 1,
            "AllowOverlay": 1,
            "OpenVR": 0,
            "Devkit": 0,
            "DevkitGameID": "",
            "DevkitOverrideAppID": 0,
            "LastPlayTime": 0,
            "FlatpakAppID": "",
            "tags": tags_dict,
        }

        shortcuts[target_idx] = shortcut_entry
        if save_shortcuts_vdf(vdf_path, shortcuts_doc, backup=True):
            affected_users.append(uid)

    if affected_users:
        steam_ts = mark_steam_reload_needed(game_name, clean_exe) if is_steam_running() else None
        if steam_ts is None:
            clear_steam_reload_flag(game_name, clean_exe)

        # Automatically configure Proton compatibility for added game
        try:
            from app.core.steam_compat import set_proton_compatibility
            set_proton_compatibility(steam_path, uint_appid, "proton_experimental", "250")
        except Exception as compat_err:
            logger.warning(f"{TAG} Failed to set default proton compatibility: {compat_err}")

        return {
            "success": True,
            "appid": uint_appid,
            "signed_appid": signed_appid,
            "affected_users": affected_users,
            "steam_start_ts": steam_ts,
            "message": f"Added '{game_name}' to Steam for {len(affected_users)} account(s).",
        }
    else:
        return {"success": False, "message": "Failed to save shortcuts.vdf for any user."}



def _shortcut_matches_game(entry: dict, game_name: str, clean_exe: str) -> bool:
    """Return True if a shortcuts.vdf entry matches game_name or clean_exe."""
    entry_name = str(entry.get("appname", "")).strip()
    entry_exe = str(entry.get("exe", "")).strip().strip('"')
    if game_name and entry_name.lower() == game_name.strip().lower():
        return True
    if clean_exe and entry_exe:
        try:
            norm_a = os.path.normcase(os.path.normpath(entry_exe))
            norm_b = os.path.normcase(os.path.normpath(clean_exe))
            if norm_a == norm_b:
                return True
        except (ValueError, OSError):
            pass
    return False


def find_matching_steam_shortcuts(
    game_name: str,
    exe_path: str = "",
    steam_path: str | None = None,
    target_user_ids: list[str] | None = None,
) -> list[dict]:
    """Find all Non-Steam shortcuts matching game_name or exe_path across Steam profiles."""
    if not game_name and not exe_path:
        return []
    if not steam_path:
        steam_path = find_steam_path()
    if not steam_path:
        return []

    clean_exe = (exe_path or "").strip().strip('"')
    user_ids = target_user_ids or get_steam_user_ids(steam_path)
    matches: list[dict] = []

    for uid in user_ids:
        vdf_path = os.path.join(steam_path, "userdata", uid, "config", "shortcuts.vdf")
        if not os.path.isfile(vdf_path):
            continue
        shortcuts = load_shortcuts_vdf(vdf_path).get("shortcuts", {})
        for idx_str, entry in shortcuts.items():
            if not isinstance(entry, dict):
                continue
            if _shortcut_matches_game(entry, game_name, clean_exe):
                signed_appid = int(entry.get("appid", 0) or 0)
                matches.append({
                    "user_id": uid,
                    "idx": str(idx_str),
                    "appname": str(entry.get("appname", "")),
                    "exe": str(entry.get("exe", "")),
                    "signed_appid": signed_appid,
                    "uint_appid": signed_appid & 0xFFFFFFFF,
                })
    return matches


def has_non_steam_shortcut(
    game_name: str,
    exe_path: str = "",
    steam_path: str | None = None,
    target_user_ids: list[str] | None = None,
) -> bool:
    """Return True if at least one Non-Steam shortcut matches this game."""
    return bool(find_matching_steam_shortcuts(
        game_name=game_name,
        exe_path=exe_path,
        steam_path=steam_path,
        target_user_ids=target_user_ids,
    ))


def remove_non_steam_game(
    game_name: str,
    exe_path: str = "",
    steam_path: str | None = None,
    target_user_ids: list[str] | None = None,
) -> dict:
    """
    Remove matching Non-Steam game shortcut(s) from shortcuts.vdf across Steam profiles,
    re-indexing remaining entries cleanly ("0", "1", ...) and deleting associated grid artworks.
    """
    if not game_name and not exe_path:
        return {
            "success": False,
            "removed_count": 0,
            "removed_artworks": 0,
            "affected_users": [],
            "message": "Missing game name and executable path.",
        }

    if not steam_path:
        steam_path = find_steam_path()
    if not steam_path:
        return {
            "success": True,
            "removed_count": 0,
            "removed_artworks": 0,
            "affected_users": [],
            "message": "Steam installation directory not found.",
        }

    clean_exe = (exe_path or "").strip().strip('"')
    user_ids = target_user_ids or get_steam_user_ids(steam_path)
    removed_count = 0
    removed_artworks = 0
    affected_users: list[str] = []
    save_errors: list[str] = []

    for uid in user_ids:
        config_dir = os.path.join(steam_path, "userdata", uid, "config")
        vdf_path = os.path.join(config_dir, "shortcuts.vdf")
        if not os.path.isfile(vdf_path):
            continue

        shortcuts_doc = load_shortcuts_vdf(vdf_path)
        shortcuts = shortcuts_doc.get("shortcuts", {})
        if not isinstance(shortcuts, dict) or not shortcuts:
            continue

        ordered_items = sorted(
            shortcuts.items(),
            key=lambda kv: (0, int(kv[0])) if str(kv[0]).isdigit() else (1, str(kv[0])),
        )
        kept_entries: list[dict] = []
        matched_appids: set[int] = set()
        user_removed = 0

        for _idx_str, entry in ordered_items:
            if not isinstance(entry, dict):
                continue
            if _shortcut_matches_game(entry, game_name, clean_exe):
                user_removed += 1
                signed_appid = int(entry.get("appid", 0) or 0)
                if signed_appid:
                    matched_appids.add(signed_appid & 0xFFFFFFFF)
                entry_exe = str(entry.get("exe", "")).strip().strip('"') or clean_exe
                entry_name = str(entry.get("appname", "")).strip() or game_name
                if entry_exe and entry_name:
                    _, calc_uint, _ = calculate_shortcut_appid(entry_exe, entry_name)
                    matched_appids.add(calc_uint)
            else:
                kept_entries.append(entry)

        if user_removed == 0:
            continue

        shortcuts_doc["shortcuts"] = {str(i): entry for i, entry in enumerate(kept_entries)}
        if not save_shortcuts_vdf(vdf_path, shortcuts_doc, backup=True):
            save_errors.append(uid)
            continue

        removed_count += user_removed
        affected_users.append(uid)

        grid_dir = os.path.join(config_dir, "grid")
        if os.path.isdir(grid_dir) and matched_appids:
            for aid in matched_appids:
                sid = str(aid)
                for suffix in ("", "p", "_hero", "_logo", "_icon"):
                    for ext in (".png", ".jpg", ".jpeg", ".ico", ".webp"):
                        art_path = os.path.join(grid_dir, f"{sid}{suffix}{ext}")
                        if os.path.isfile(art_path):
                            try:
                                os.remove(art_path)
                                removed_artworks += 1
                            except OSError as exc:
                                logger.warning(f"Could not delete Steam grid artwork {art_path}: {exc}")

    if save_errors and not affected_users:
        return {
            "success": False,
            "removed_count": 0,
            "removed_artworks": removed_artworks,
            "affected_users": [],
            "message": f"Failed to update shortcuts.vdf for profile(s): {', '.join(save_errors)}",
        }

    return {
        "success": True,
        "removed_count": removed_count,
        "removed_artworks": removed_artworks,
        "affected_users": affected_users,
        "message": (
            f"Removed {removed_count} Non-Steam shortcut(s) and {removed_artworks} artwork(s) "
            f"across {len(affected_users)} account(s)."
        ),
    }


def launch_steam_silent(steam_path: str | None = None) -> bool:
    """Launch Steam silently in the background (-silent)."""
    if not steam_path:
        steam_path = find_steam_path()
    if not steam_path:
        return False
    steam_cmd = get_steam_executable(steam_path)
    if not steam_cmd:
        return False
    try:
        from app.core.online_fix.extractor import clean_subprocess_env
        cmd = (
            ["flatpak", "run", "com.valvesoftware.Steam", "-silent"]
            if steam_cmd == "flatpak"
            else [steam_cmd, "-silent"]
        )
        subprocess.Popen(
            cmd,
            cwd=steam_path if os.path.isdir(steam_path) else None,
            env=clean_subprocess_env(),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return True
    except Exception as exc:
        logger.warning(f"Failed to relaunch Steam silently ({steam_cmd}): {exc}")
        return False


_PENDING_STEAM_RELOAD: dict[str, float] = {}


def _reload_keys(game_name: str, exe_path: str = "") -> list[str]:
    keys: list[str] = []
    if game_name and game_name.strip():
        keys.append(f"name:{game_name.strip().lower()}")
    clean_exe = (exe_path or "").strip().strip('"')
    if clean_exe:
        try:
            keys.append(f"exe:{os.path.normcase(os.path.normpath(clean_exe))}")
        except (ValueError, OSError):
            pass
    return keys


def get_running_steam_start_time() -> float | None:
    """Return earliest process start timestamp of running Steam, or None if not running."""
    valid_names = {"steam.exe"} if sys.platform == "win32" else {"steam"}
    try:
        import psutil
        times: list[float] = []
        for proc in psutil.process_iter(["name", "create_time"]):
            try:
                name = proc.info.get("name")
                if name and name.lower() in valid_names:
                    ct = proc.info.get("create_time")
                    if ct is not None:
                        times.append(float(ct))
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        if times:
            return min(times)
        return None
    except ImportError:
        if sys.platform != "win32" and is_steam_running():
            try:
                out = subprocess.check_output(["pgrep", "-x", "steam"], text=True)
                pids = [int(p) for p in out.split() if p.isdigit()]
                times = [os.path.getmtime(f"/proc/{pid}") for pid in pids if os.path.isdir(f"/proc/{pid}")]
                return min(times) if times else time.time()
            except Exception:
                return -1.0
        return -1.0 if is_steam_running() else None


def mark_steam_reload_needed(
    game_name: str,
    exe_path: str = "",
    steam_ts: float | None = None,
) -> float | None:
    """Record that shortcuts.vdf was modified while the current Steam session was running."""
    ts = steam_ts if steam_ts is not None else get_running_steam_start_time()
    if ts is None:
        return None
    for k in _reload_keys(game_name, exe_path):
        _PENDING_STEAM_RELOAD[k] = float(ts)
    return float(ts)


def clear_steam_reload_flag(game_name: str, exe_path: str = "") -> None:
    """Clear pending Steam reload markers for a game."""
    for k in _reload_keys(game_name, exe_path):
        _PENDING_STEAM_RELOAD.pop(k, None)


def needs_steam_reload_for_shortcut(
    game_name: str,
    exe_path: str = "",
    persisted_pending_ts: float | None = None,
) -> bool:
    """
    Return True if Steam is currently running on the exact same session that was open
    when the shortcut was written to shortcuts.vdf (meaning Steam hasn't loaded it yet).
    """
    curr_ts = get_running_steam_start_time()
    if curr_ts is None:
        return False

    recorded_ts: float | None = None
    for k in _reload_keys(game_name, exe_path):
        if k in _PENDING_STEAM_RELOAD:
            recorded_ts = _PENDING_STEAM_RELOAD[k]
            break
    if recorded_ts is None and persisted_pending_ts is not None:
        try:
            recorded_ts = float(persisted_pending_ts)
        except (TypeError, ValueError):
            recorded_ts = None

    if recorded_ts is None:
        return False
    if curr_ts < 0 or recorded_ts < 0:
        return True
    return abs(curr_ts - recorded_ts) < 5.0
