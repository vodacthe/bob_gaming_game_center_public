"""
Sync manager for Bob Gaming Game Center.
Orchestrates sync operations between local saves and any CloudProvider.
"""

import os
import time
import logging

from PySide6.QtCore import QObject, Signal

from app.config import (
    SYNC_STATUS_NOT_CONFIGURED, SYNC_STATUS_NOT_SYNCED,
    SYNC_STATUS_SYNCING, SYNC_STATUS_SYNCED, SYNC_STATUS_ERROR,
    BOBIGNORE_FILENAME, save_config,
)
from app.core.cloud_provider import CloudProvider
from app.core.sync_state import SyncStateManager
from app.core.exclude_filter import ExcludeFilter

logger = logging.getLogger(__name__)


def determine_sync_action(
    local_time: float | None,
    remote_time: float | None,
    last_sync: float,
) -> str:
    """
    Pure logic function to decide synchronization action based on timestamps.

    Returns:
        "none": Up to date, no action needed
        "upload": Local is newer than last sync, upload to cloud
        "download": Remote is newer than last sync, download to local
        "conflict": Both local and remote changed since last sync
    """
    if local_time is None and remote_time is None:
        return "none"

    if remote_time is None:
        return "upload"

    if local_time is None:
        return "download"

    # Threshold for timestamp comparison (1.5 seconds)
    threshold = 1.5

    local_changed = (local_time - last_sync) > threshold
    remote_changed = (remote_time - last_sync) > threshold

    if local_changed and remote_changed:
        if abs(local_time - remote_time) < threshold:
            return "none"
        return "conflict"
    elif local_changed:
        return "upload"
    elif remote_changed:
        return "download"
    else:
        return "none"


class SyncManager(QObject):
    """Orchestrates sync between local saves and cloud provider."""

    # Signals for UI updates
    sync_started = Signal(str)        # game_name
    sync_progress = Signal(str, int, int, float, int, int)  # game_name, current, total, speed, bytes_done, total_bytes
    sync_completed = Signal(str, bool, str)  # game_name, success, message
    sync_error = Signal(str, str)     # game_name, error_message

    def __init__(self, cloud_provider: CloudProvider, config: dict, parent=None):
        super().__init__(parent)
        self.cloud = cloud_provider
        self.config = config
        self.state_manager = SyncStateManager()

    def get_exclude_filter(self, game_name: str, save_dir: str | None = None) -> ExcludeFilter:
        """Get ExcludeFilter for a game based on config patterns and optional save_dir ignore files."""
        patterns = self.config.get("games", {}).get(game_name, {}).get("exclude_patterns", [])
        if not save_dir:
            save_dir = self.config.get("games", {}).get(game_name, {}).get("save_path", "")
        return ExcludeFilter(patterns, save_dir=save_dir)

    def upload_bobignore(self, game_name: str, local_save_path: str | None = None):
        """Upload .bobignore to the cloud game root folder (alongside save_location_<platform>.txt)."""
        try:
            content = None
            if not local_save_path:
                local_save_path = self.config.get("games", {}).get(game_name, {}).get("save_path", "")

            # Check if .bobignore file exists locally in save_path
            if local_save_path:
                local_file = os.path.join(local_save_path, BOBIGNORE_FILENAME)
                if os.path.isfile(local_file):
                    try:
                        with open(local_file, "r", encoding="utf-8", errors="ignore") as f:
                            content = f.read()
                    except Exception as e:
                        logger.warning(f"Failed to read local {BOBIGNORE_FILENAME} for {game_name}: {e}")

            # If no local file but patterns exist in config, construct content
            if content is None:
                patterns = self.config.get("games", {}).get(game_name, {}).get("exclude_patterns", [])
                if patterns:
                    content = (
                        "# Bob Gaming Game Center - Excluded files from cloud sync\n"
                        "# Files matching patterns below will NOT be uploaded or overwritten.\n\n"
                        + "\n".join(patterns) + "\n"
                    )

            if content:
                self.cloud.upload_bobignore(game_name, content)
                logger.info(f"[{game_name}] Uploaded {BOBIGNORE_FILENAME} to cloud game root folder")
        except Exception as e:
            logger.warning(f"[{game_name}] Failed to upload {BOBIGNORE_FILENAME}: {e}")

    def setup_game_sync(self, game_name: str, local_save_path: str) -> bool:
        """
        Set up sync for a game: create cloud folder, upload saves, save config.

        Args:
            game_name: Name of the game
            local_save_path: Local path to the save files

        Returns:
            True on success
        """
        self.sync_started.emit(game_name)

        try:
            # Update status
            self._update_game_config(game_name, {
                "status": SYNC_STATUS_SYNCING
            })

            self.cloud.create_game_folder(game_name)
            
            # Initial setup implies uploading everything.
            # We can use delta logic by passing empty last_state.
            exclude_filter = self.get_exclude_filter(game_name, local_save_path)
            local_state = self.state_manager.scan_local_directory(local_save_path, exclude_filter=exclude_filter)
            files_to_upload = list(local_state.keys())

            def on_progress(current, total, speed=0.0, bytes_done=0, total_bytes=0, *args, **kwargs):
                self.sync_progress.emit(game_name, current, total, speed, bytes_done, total_bytes)

            remote_saves = self.cloud.get_saves_path(game_name)
            if files_to_upload:
                total_bytes = sum(local_state.get(p, {}).get("size", 0) for p in files_to_upload)
                self.sync_progress.emit(game_name, 0, len(files_to_upload), 0.0, 0, total_bytes)
                self.cloud.upload_delta(local_save_path, remote_saves, files_to_upload, progress_callback=on_progress)

            # Upload save_location.txt
            self.cloud.upload_save_location(game_name, local_save_path)

            # Upload .bobignore to cloud game root folder (alongside save_location_<platform>.txt)
            self.upload_bobignore(game_name, local_save_path)

            # Update state
            self.state_manager.update_game_state(game_name, local_state)

            # Update config with precise timestamps
            self._update_game_config(game_name, {
                "save_path": local_save_path,
                "status": SYNC_STATUS_SYNCED,
                "on_cloud": True,
                "last_sync": time.time(),
                "last_local_time": self.get_local_modified_time(game_name),
                "last_remote_time": self.cloud.get_remote_modified_time(game_name)
            })

            self.sync_completed.emit(game_name, True, "Sync setup completed successfully!")
            logger.info(f"Sync setup completed for {game_name}")
            return True

        except Exception as e:
            error_msg = f"Failed to setup sync: {str(e)}"
            logger.error(f"{game_name}: {error_msg}")
            self._update_game_config(game_name, {
                "save_path": local_save_path,
                "status": SYNC_STATUS_ERROR,
            })
            self.sync_error.emit(game_name, error_msg)
            self.sync_completed.emit(game_name, False, error_msg)
            return False

    def sync_game(self, game_name: str) -> bool:
        """
        Delta-upload modified local saves to the cloud.

        Args:
            game_name: Name of the game

        Returns:
            True on success
        """
        game_config = self.config.get("games", {}).get(game_name, {})
        save_path = game_config.get("save_path")

        if not save_path:
            self.sync_error.emit(game_name, "No save path configured")
            return False

        self.sync_started.emit(game_name)

        try:
            self._update_game_config(game_name, {"status": SYNC_STATUS_SYNCING})

            exclude_filter = self.get_exclude_filter(game_name, save_path)
            local_state = self.state_manager.scan_local_directory(save_path, exclude_filter=exclude_filter)
            last_state = self.state_manager.get_game_state(game_name)
            last_state = {p: m for p, m in last_state.items() if not exclude_filter.is_excluded(p)}

            files_to_upload = []
            for path, meta in local_state.items():
                if path not in last_state:
                    files_to_upload.append(path)
                elif meta["mtime"] != last_state[path]["mtime"] or meta["size"] != last_state[path]["size"]:
                    files_to_upload.append(path)

            missing_locally = []
            for path in last_state.keys():
                if path not in local_state and not exclude_filter.is_excluded(path):
                    missing_locally.append(path)

            def on_progress(current, total, speed=0.0, bytes_done=0, total_bytes=0, *args, **kwargs):
                self.sync_progress.emit(game_name, current, total, speed, bytes_done, total_bytes)

            remote_saves = self.cloud.get_saves_path(game_name)
            
            # Delete missing files on remote
            if missing_locally:
                self.cloud.delete_remote_files(remote_saves, missing_locally)
            
            # Delta upload
            if files_to_upload:
                total_bytes = sum(local_state.get(p, {}).get("size", 0) for p in files_to_upload)
                self.sync_progress.emit(game_name, 0, len(files_to_upload), 0.0, 0, total_bytes)
                self.cloud.upload_delta(save_path, remote_saves, files_to_upload, progress_callback=on_progress)
            else:
                logger.info(f"[{game_name}] No files changed locally, skipping upload.")

            self.cloud.upload_save_location(game_name, save_path)
            self.upload_bobignore(game_name, save_path)
            
            # Update state
            self.state_manager.update_game_state(game_name, local_state)

            self._update_game_config(game_name, {
                "status": SYNC_STATUS_SYNCED,
                "on_cloud": True,
                "last_sync": time.time(),
                "last_local_time": self.get_local_modified_time(game_name),
                "last_remote_time": self.cloud.get_remote_modified_time(game_name)
            })

            self.sync_completed.emit(game_name, True, "Saves uploaded successfully!")
            return True

        except Exception as e:
            error_msg = str(e)
            logger.error(f"Sync failed for {game_name}: {error_msg}")
            self._update_game_config(game_name, {"status": SYNC_STATUS_ERROR})
            self.sync_error.emit(game_name, error_msg)
            self.sync_completed.emit(game_name, False, error_msg)
            return False

    def download_game_saves(self, game_name: str, local_save_path: str | None = None) -> bool:
        """
        Delta-download saves from cloud to local.

        Args:
            game_name: Name of the game
            local_save_path: Local path to download to. If None, read from cloud save_location.txt

        Returns:
            True on success
        """
        self.sync_started.emit(game_name)

        try:
            # If no path provided, try to get from cloud
            if not local_save_path:
                local_save_path = self.cloud.get_save_location(game_name)
                if not local_save_path:
                    self.sync_error.emit(game_name, "No save location found on cloud")
                    return False

            self._update_game_config(game_name, {
                "save_path": local_save_path,
                "status": SYNC_STATUS_SYNCING,
            })

            exclude_filter = self.get_exclude_filter(game_name, local_save_path)
            remote_saves = self.cloud.get_saves_path(game_name)
            remote_state = self.cloud.list_directory_recursive(remote_saves)
            last_state = self.state_manager.get_game_state(game_name)
            last_state = {p: m for p, m in last_state.items() if not exclude_filter.is_excluded(p)}

            files_to_download = []
            for path, meta in remote_state.items():
                if exclude_filter.is_excluded(path):
                    continue
                if path not in last_state:
                    files_to_download.append(path)
                elif meta["mtime"] > last_state[path]["mtime"] or meta["size"] != last_state[path]["size"]:
                    files_to_download.append(path)

            missing_remotely = []
            for path in last_state.keys():
                if exclude_filter.is_excluded(path):
                    continue
                if path not in remote_state:
                    missing_remotely.append(path)

            # Delete files locally that were deleted remotely (except excluded files)
            for rel_path in missing_remotely:
                if exclude_filter.is_excluded(rel_path):
                    continue
                local_file = os.path.join(local_save_path, rel_path)
                if os.path.exists(local_file):
                    try:
                        os.remove(local_file)
                        logger.info(f"Deleted local file (removed from cloud): {rel_path}")
                    except OSError as e:
                        logger.error(f"Failed to delete local file {rel_path}: {e}")

            def on_progress(current, total, speed=0.0, bytes_done=0, total_bytes=0, *args, **kwargs):
                self.sync_progress.emit(game_name, current, total, speed, bytes_done, total_bytes)

            if files_to_download:
                file_sizes = {p: remote_state.get(p, {}).get("size", 0) for p in files_to_download}
                total_bytes = sum(file_sizes.values())
                self.sync_progress.emit(game_name, 0, len(files_to_download), 0.0, 0, total_bytes)
                self.cloud.download_delta(remote_saves, local_save_path, files_to_download, progress_callback=on_progress, file_sizes=file_sizes)
            # Download .bobignore from cloud game root folder (alongside save_location_<platform>.txt)
            try:
                bobignore_content = self.cloud.get_bobignore(game_name)
                if isinstance(bobignore_content, str):
                    bobignore_file = os.path.join(local_save_path, BOBIGNORE_FILENAME)
                    with open(bobignore_file, "w", encoding="utf-8") as f:
                        f.write(bobignore_content)
                    fresh_filter = ExcludeFilter((), save_dir=local_save_path)
                    if fresh_filter.patterns:
                        self._update_game_config(game_name, {
                            "exclude_patterns": fresh_filter.patterns
                        })
                        exclude_filter = fresh_filter
                    logger.info(f"[{game_name}] Downloaded {BOBIGNORE_FILENAME} from cloud game root folder")
                else:
                    # Fallback check if .bobignore was already present locally
                    bobignore_file = os.path.join(local_save_path, BOBIGNORE_FILENAME)
                    if os.path.isfile(bobignore_file):
                        fresh_filter = ExcludeFilter((), save_dir=local_save_path)
                        if fresh_filter.patterns:
                            self._update_game_config(game_name, {
                                "exclude_patterns": fresh_filter.patterns
                            })
                            exclude_filter = fresh_filter
            except Exception as e:
                logger.warning(f"[{game_name}] Failed to download {BOBIGNORE_FILENAME}: {e}")

            # Re-scan local state after download to update sync state accurately
            new_local_state = self.state_manager.scan_local_directory(local_save_path, exclude_filter=exclude_filter)
            self.state_manager.update_game_state(game_name, new_local_state)

            self._update_game_config(game_name, {
                "save_path": local_save_path,
                "status": SYNC_STATUS_SYNCED,
                "on_cloud": True,
                "last_sync": time.time(),
                "last_local_time": self.get_local_modified_time(game_name),
                "last_remote_time": self.cloud.get_remote_modified_time(game_name)
            })

            self.sync_completed.emit(game_name, True, f"Saves downloaded to {local_save_path}")
            return True

        except Exception as e:
            error_msg = str(e)
            logger.error(f"Download failed for {game_name}: {error_msg}")
            self._update_game_config(game_name, {"status": SYNC_STATUS_ERROR})
            self.sync_error.emit(game_name, error_msg)
            self.sync_completed.emit(game_name, False, error_msg)
            return False

    def check_cloud_games(self) -> list[dict]:
        """
        Check which games exist on the cloud and their local status.

        Returns:
            List of dicts: {name, on_cloud, on_local, save_path, status}
        """
        result = []
        try:
            cloud_games = self.cloud.list_synced_games()
            local_games = self.config.get("games", {})

            # Games on cloud
            for name in cloud_games:
                local_info = local_games.get(name, {})
                result.append({
                    "name": name,
                    "on_cloud": True,
                    "on_local": bool(local_info.get("save_path")),
                    "save_path": local_info.get("save_path", ""),
                    "status": local_info.get("status", SYNC_STATUS_NOT_CONFIGURED),
                })

            # Games configured locally but not on cloud
            for name, info in local_games.items():
                if name not in cloud_games:
                    result.append({
                        "name": name,
                        "on_cloud": False,
                        "on_local": True,
                        "save_path": info.get("save_path", ""),
                        "status": info.get("status", SYNC_STATUS_NOT_SYNCED),
                    })

        except Exception as e:
            logger.error(f"Failed to check cloud games: {e}")

        return result

    def auto_detect_and_sync(self) -> list[str]:
        """
        Detect games on cloud that aren't configured locally.

        Returns:
            List of game names that can be auto-configured
        """
        auto_games = []
        try:
            cloud_games = self.cloud.list_synced_games()
            local_games = self.config.get("games", {})

            for name in cloud_games:
                if name not in local_games or not local_games[name].get("save_path"):
                    # Try to get save location from cloud
                    save_loc = self.cloud.get_save_location(name)
                    if save_loc:
                        auto_games.append(name)
                        self._update_game_config(name, {
                            "save_path": save_loc,
                            "status": SYNC_STATUS_NOT_SYNCED,
                            "cloud_save_path": save_loc,
                        })

        except Exception as e:
            logger.error(f"Auto-detect failed: {e}")

        return auto_games

    def get_remote_modified_time(self, game_name: str) -> float | None:
        """Get the remote modification time of a game's saves folder (UNIX timestamp)."""
        return self.cloud.get_remote_modified_time(game_name)

    def get_local_modified_time(self, game_name: str) -> float | None:
        """Get the latest modification time among non-excluded files in the local save directory."""
        game_config = self.config.get("games", {}).get(game_name, {})
        save_path = game_config.get("save_path")
        if not save_path or not os.path.exists(save_path):
            return None

        exclude_filter = self.get_exclude_filter(game_name, save_path)
        latest = 0.0
        try:
            for root, dirs, files in os.walk(save_path):
                rel_root = os.path.relpath(root, save_path).replace("\\", "/")
                if rel_root == ".":
                    rel_root = ""

                dirs[:] = [
                    d for d in dirs
                    if not exclude_filter.is_excluded(f"{rel_root}/{d}" if rel_root else d, is_dir=True)
                ]

                for f in files:
                    rel_path = os.path.relpath(os.path.join(root, f), save_path).replace("\\", "/")
                    if exclude_filter.is_excluded(rel_path, is_dir=False):
                        continue
                    file_path = os.path.join(root, f)
                    try:
                        mtime = os.path.getmtime(file_path)
                        if mtime > latest:
                            latest = mtime
                    except OSError:
                        pass
            return latest if latest > 0 else None
        except Exception as e:
            logger.error(f"Failed to get local modified time for {game_name}: {e}")
            return None

    def _update_game_config(self, game_name: str, updates: dict):
        """Update game configuration."""
        if "games" not in self.config:
            self.config["games"] = {}
        if game_name not in self.config["games"]:
            self.config["games"][game_name] = {}
        self.config["games"][game_name].update(updates)
        if updates.get("status") == SYNC_STATUS_SYNCED:
            self.config["games"][game_name].pop("unsynced", None)
        save_config(self.config)

    def unsync_game(self, game_name: str, delete_from_cloud: bool = False) -> bool:
        """
        Unsync a game: remove from sync tracking, clear state, and optionally delete from cloud.
        """
        try:
            # 1. Optionally delete from cloud
            if delete_from_cloud and self.cloud:
                try:
                    self.cloud.delete_game_folder(game_name)
                    logger.info(f"Deleted remote game folder for {game_name}")
                except Exception as e:
                    logger.error(f"Failed to delete cloud folder for {game_name}: {e}")

            # 2. Clear local sync state
            self.state_manager.remove_game_state(game_name)

            # 3. Update game config
            if "games" in self.config and game_name in self.config["games"]:
                game_cfg = self.config["games"][game_name]
                game_cfg["status"] = SYNC_STATUS_NOT_SYNCED
                game_cfg["unsynced"] = True
                if delete_from_cloud:
                    game_cfg["on_cloud"] = False
                else:
                    game_cfg["on_cloud"] = True
                game_cfg.pop("last_sync", None)
                game_cfg.pop("last_local_time", None)
                game_cfg.pop("last_remote_time", None)
                save_config(self.config)

            self.sync_completed.emit(game_name, True, f"Un-synced {game_name}")
            logger.info(f"Successfully un-synced {game_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to unsync {game_name}: {e}")
            return False

