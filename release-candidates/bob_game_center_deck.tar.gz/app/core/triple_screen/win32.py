"""Win32 helpers for Triple Screen mode: monitor geometry, process inspection, and borderless window spanning.

Every public function is a safe no-op (or returns a neutral empty value) off Windows or when an OS call fails.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass

logger = logging.getLogger(__name__)
TAG = "[TripleScreen/Win32]"

_IS_WIN = sys.platform == "win32"

GWL_STYLE = -16
GWL_EXSTYLE = -20

WS_POPUP = 0x80000000
WS_VISIBLE = 0x10000000
WS_CAPTION = 0x00C00000
WS_THICKFRAME = 0x00040000
WS_MINIMIZEBOX = 0x00020000
WS_MAXIMIZEBOX = 0x00010000
WS_BORDER = 0x00800000
WS_DLGFRAME = 0x00400000
BORDER_STYLE_MASK = WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_BORDER | WS_DLGFRAME

WS_EX_DLGMODALFRAME = 0x00000001
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_WINDOWEDGE = 0x00000100
WS_EX_CLIENTEDGE = 0x00000200
WS_EX_STATICEDGE = 0x00020000
EXTENDED_BORDER_MASK = WS_EX_DLGMODALFRAME | WS_EX_WINDOWEDGE | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE

SWP_NOZORDER = 0x0004
SWP_FRAMECHANGED = 0x0020
SWP_SHOWWINDOW = 0x0040
SWP_NOSENDCHANGING = 0x0400

WM_EXITSIZEMOVE = 0x0232

GW_OWNER = 4
MONITORINFOF_PRIMARY = 0x00000001
DESKTOP_ALL_ACCESS = 0x01FF
TH32CS_SNAPPROCESS = 0x00000002
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
TOKEN_DUPLICATE = 0x0002
TOKEN_DE_ELEVATE_ACCESS = 0x018B  # TOKEN_ASSIGN_PRIMARY | TOKEN_DUPLICATE | TOKEN_QUERY | TOKEN_ADJUST_DEFAULT | TOKEN_ADJUST_SESSIONID
SECURITY_IMPERSONATION = 2
TOKEN_PRIMARY = 1
CREATE_UNICODE_ENVIRONMENT = 0x00000400

_user32 = None
_kernel32 = None
_advapi32 = None
_shell32 = None

if _IS_WIN:
    import ctypes
    from ctypes import wintypes

    _user32 = ctypes.WinDLL("user32", use_last_error=True)
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    _shell32 = ctypes.WinDLL("shell32", use_last_error=True)

    _DPI_CONTEXT_PMV2 = ctypes.c_void_p(-4)
    _INVALID_HANDLE = ctypes.c_void_p(-1).value

    class _MONITORINFOEXW(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD),
            ("rcMonitor", wintypes.RECT),
            ("rcWork", wintypes.RECT),
            ("dwFlags", wintypes.DWORD),
            ("szDevice", wintypes.WCHAR * 32),
        ]

    class _PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.c_size_t),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", wintypes.LONG),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", wintypes.WCHAR * 260),
        ]

    class _STARTUPINFOW(ctypes.Structure):
        _fields_ = [
            ("cb", wintypes.DWORD),
            ("lpReserved", wintypes.LPWSTR),
            ("lpDesktop", wintypes.LPWSTR),
            ("lpTitle", wintypes.LPWSTR),
            ("dwX", wintypes.DWORD),
            ("dwY", wintypes.DWORD),
            ("dwXSize", wintypes.DWORD),
            ("dwYSize", wintypes.DWORD),
            ("dwXCountChars", wintypes.DWORD),
            ("dwYCountChars", wintypes.DWORD),
            ("dwFillAttribute", wintypes.DWORD),
            ("dwFlags", wintypes.DWORD),
            ("wShowWindow", wintypes.WORD),
            ("cbReserved2", wintypes.WORD),
            ("lpReserved2", ctypes.POINTER(ctypes.c_byte)),
            ("hStdInput", wintypes.HANDLE),
            ("hStdOutput", wintypes.HANDLE),
            ("hStdError", wintypes.HANDLE),
        ]

    class _PROCESS_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("hProcess", wintypes.HANDLE),
            ("hThread", wintypes.HANDLE),
            ("dwProcessId", wintypes.DWORD),
            ("dwThreadId", wintypes.DWORD),
        ]

    _MONITORENUMPROC = ctypes.WINFUNCTYPE(
        wintypes.BOOL, wintypes.HMONITOR, wintypes.HDC, ctypes.POINTER(wintypes.RECT), wintypes.LPARAM
    )
    _WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    if hasattr(_user32, "SetThreadDpiAwarenessContext"):
        _user32.SetThreadDpiAwarenessContext.argtypes = [wintypes.HANDLE]
        _user32.SetThreadDpiAwarenessContext.restype = wintypes.HANDLE

    _user32.OpenDesktopW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    _user32.OpenDesktopW.restype = wintypes.HANDLE
    _user32.OpenInputDesktop.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    _user32.OpenInputDesktop.restype = wintypes.HANDLE
    _user32.SetThreadDesktop.argtypes = [wintypes.HANDLE]
    _user32.SetThreadDesktop.restype = wintypes.BOOL
    _user32.CloseDesktop.argtypes = [wintypes.HANDLE]
    _user32.CloseDesktop.restype = wintypes.BOOL

    _user32.EnumDisplayMonitors.argtypes = [wintypes.HDC, ctypes.POINTER(wintypes.RECT), _MONITORENUMPROC, wintypes.LPARAM]
    _user32.EnumDisplayMonitors.restype = wintypes.BOOL
    _user32.GetMonitorInfoW.argtypes = [wintypes.HMONITOR, ctypes.POINTER(_MONITORINFOEXW)]
    _user32.GetMonitorInfoW.restype = wintypes.BOOL

    _user32.EnumWindows.argtypes = [_WNDENUMPROC, wintypes.LPARAM]
    _user32.EnumWindows.restype = wintypes.BOOL
    _user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    _user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    _user32.IsWindowVisible.argtypes = [wintypes.HWND]
    _user32.IsWindowVisible.restype = wintypes.BOOL
    _user32.IsIconic.argtypes = [wintypes.HWND]
    _user32.IsIconic.restype = wintypes.BOOL
    _user32.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]
    _user32.GetWindow.restype = wintypes.HWND
    _user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    _user32.GetClassNameW.restype = ctypes.c_int
    _user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    _user32.GetWindowTextW.restype = ctypes.c_int
    _user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    _user32.GetWindowRect.restype = wintypes.BOOL
    _user32.SetWindowPos.argtypes = [
        wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint
    ]
    _user32.SetWindowPos.restype = wintypes.BOOL
    _user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    _user32.SetForegroundWindow.restype = wintypes.BOOL
    _user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    _user32.PostMessageW.restype = wintypes.BOOL

    _get_wlp = getattr(_user32, "GetWindowLongPtrW", None) or _user32.GetWindowLongW
    _get_wlp.argtypes = [wintypes.HWND, ctypes.c_int]
    _get_wlp.restype = ctypes.c_ssize_t

    _set_wlp = getattr(_user32, "SetWindowLongPtrW", None) or _user32.SetWindowLongW
    _set_wlp.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
    _set_wlp.restype = ctypes.c_ssize_t

    _kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    _kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    _kernel32.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(_PROCESSENTRY32W)]
    _kernel32.Process32FirstW.restype = wintypes.BOOL
    _kernel32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(_PROCESSENTRY32W)]
    _kernel32.Process32NextW.restype = wintypes.BOOL
    _kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    _kernel32.CloseHandle.restype = wintypes.BOOL
    _kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    _kernel32.OpenProcess.restype = wintypes.HANDLE
    _kernel32.QueryFullProcessImageNameW.argtypes = [
        wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)
    ]
    _kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL

    _user32.GetShellWindow.argtypes = []
    _user32.GetShellWindow.restype = wintypes.HWND

    _shell32.IsUserAnAdmin.argtypes = []
    _shell32.IsUserAnAdmin.restype = wintypes.BOOL

    _advapi32.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    _advapi32.OpenProcessToken.restype = wintypes.BOOL
    _advapi32.DuplicateTokenEx.argtypes = [
        wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.POINTER(wintypes.HANDLE)
    ]
    _advapi32.DuplicateTokenEx.restype = wintypes.BOOL
    _advapi32.CreateProcessWithTokenW.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        wintypes.LPCWSTR,
        wintypes.LPWSTR,
        wintypes.DWORD,
        ctypes.c_void_p,
        wintypes.LPCWSTR,
        ctypes.POINTER(_STARTUPINFOW),
        ctypes.POINTER(_PROCESS_INFORMATION),
    ]
    _advapi32.CreateProcessWithTokenW.restype = wintypes.BOOL


@dataclass(frozen=True)
class MonitorInfo:
    device: str
    x: int
    y: int
    width: int
    height: int
    is_primary: bool = False


@dataclass(frozen=True)
class SpanBounds:
    x: int
    y: int
    width: int
    height: int


@dataclass(frozen=True)
class RunningProcess:
    pid: int
    exe_name: str
    parent_pid: int = 0


def _to_u32(value: int) -> int:
    return int(value) & 0xFFFFFFFF


def _to_signed_32(u32_value: int) -> int:
    val = int(u32_value) & 0xFFFFFFFF
    return val - 0x100000000 if (val & 0x80000000) else val


def set_thread_per_monitor_dpi():
    """Enable Per-Monitor Aware v2 for the calling thread; returns previous context or None."""
    if not _IS_WIN or _user32 is None or not hasattr(_user32, "SetThreadDpiAwarenessContext"):
        return None
    try:
        return _user32.SetThreadDpiAwarenessContext(_DPI_CONTEXT_PMV2)
    except Exception:
        logger.debug(f"{TAG} SetThreadDpiAwarenessContext failed", exc_info=True)
        return None


@contextmanager
def with_per_monitor_dpi():
    """Temporarily switch calling thread to Per-Monitor DPI v2 and restore previous context on exit."""
    prev = set_thread_per_monitor_dpi()
    try:
        yield
    finally:
        if _IS_WIN and _user32 is not None and prev and hasattr(_user32, "SetThreadDpiAwarenessContext"):
            try:
                _user32.SetThreadDpiAwarenessContext(prev)
            except Exception:
                pass


def ensure_default_desktop() -> None:
    """Attach worker thread to interactive default/input desktop; close handle if unused."""
    if not _IS_WIN or _user32 is None:
        return
    try:
        h_desk = _user32.OpenDesktopW("default", 0, False, DESKTOP_ALL_ACCESS)
        if not h_desk:
            h_desk = _user32.OpenInputDesktop(0, False, DESKTOP_ALL_ACCESS)
        if h_desk:
            if not _user32.SetThreadDesktop(h_desk):
                _user32.CloseDesktop(h_desk)
    except Exception:
        logger.debug(f"{TAG} ensure_default_desktop failed", exc_info=True)


def enumerate_monitors() -> list[MonitorInfo]:
    """Return physical coordinates of all attached monitors sorted left-to-right."""
    if not _IS_WIN or _user32 is None:
        return []
    monitors: list[MonitorInfo] = []
    try:
        with with_per_monitor_dpi():
            def _callback(h_mon, _hdc, _lprc, _lparam):
                try:
                    info = _MONITORINFOEXW()
                    info.cbSize = ctypes.sizeof(_MONITORINFOEXW)
                    if _user32.GetMonitorInfoW(h_mon, ctypes.byref(info)):
                        rc = info.rcMonitor
                        w = int(rc.right - rc.left)
                        h = int(rc.bottom - rc.top)
                        if w > 0 and h > 0:
                            monitors.append(
                                MonitorInfo(
                                    device=str(info.szDevice or f"DISPLAY_{len(monitors) + 1}"),
                                    x=int(rc.left),
                                    y=int(rc.top),
                                    width=w,
                                    height=h,
                                    is_primary=bool(info.dwFlags & MONITORINFOF_PRIMARY),
                                )
                            )
                except Exception:
                    logger.debug(f"{TAG} Monitor callback error", exc_info=True)
                return True

            proc = _MONITORENUMPROC(_callback)
            _user32.EnumDisplayMonitors(None, None, proc, 0)
    except Exception:
        logger.exception(f"{TAG} enumerate_monitors failed")
    monitors.sort(key=lambda m: (m.x, m.y, m.device))
    return monitors


def auto_select_horizontal_monitors(monitors: list[MonitorInfo]) -> list[str]:
    """Pick the horizontal monitor row aligned with primary (or largest row) by vertical position."""
    if not monitors:
        return []
    if len(monitors) == 1:
        return [monitors[0].device]

    def _row_for(anchor: MonitorInfo) -> list[MonitorInfo]:
        tol = max(200, anchor.height // 4)
        return [m for m in monitors if abs(m.y - anchor.y) <= tol]

    primary = next((m for m in monitors if m.is_primary), monitors[0])
    primary_row = _row_for(primary)
    if len(primary_row) >= 2:
        return [m.device for m in sorted(primary_row, key=lambda m: (m.x, m.y, m.device))]

    best_row = max((_row_for(anchor) for anchor in monitors), key=len)
    if len(best_row) >= 2:
        return [m.device for m in sorted(best_row, key=lambda m: (m.x, m.y, m.device))]

    return [m.device for m in sorted(monitors, key=lambda m: (m.x, m.y, m.device))]


def compute_span_bounds(
    monitors: list[MonitorInfo],
    selected_devices: list[str] | tuple[str, ...] = (),
) -> tuple[SpanBounds, list[MonitorInfo]]:
    """Compute target virtual-screen span bounds across selected (or auto horizontal) monitors."""
    if not monitors:
        return SpanBounds(0, 0, 0, 0), []

    wanted = {d for d in (selected_devices or ()) if d}
    chosen = [m for m in monitors if m.device in wanted] if wanted else []
    if not chosen:
        auto_devs = set(auto_select_horizontal_monitors(monitors))
        chosen = [m for m in monitors if m.device in auto_devs]
    if not chosen:
        chosen = list(monitors)

    chosen.sort(key=lambda m: (m.x, m.y, m.device))
    target_x = min(m.x for m in chosen)
    target_width = max(m.x + m.width for m in chosen) - target_x
    primary_in_chosen = next((m for m in chosen if m.is_primary), None)
    target_y = primary_in_chosen.y if primary_in_chosen is not None else min(m.y for m in chosen)
    target_height = max(m.height for m in chosen)
    return SpanBounds(target_x, target_y, target_width, target_height), chosen


def list_running_processes() -> list[RunningProcess]:
    """Return all currently running Windows processes (pid, lowercase exe name, parent pid)."""
    if not _IS_WIN or _kernel32 is None:
        return []
    procs: list[RunningProcess] = []
    h_snap = _kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if not h_snap or h_snap == _INVALID_HANDLE:
        return procs
    try:
        entry = _PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(_PROCESSENTRY32W)
        if _kernel32.Process32FirstW(h_snap, ctypes.byref(entry)):
            while True:
                exe = str(entry.szExeFile or "").lower()
                if exe:
                    procs.append(
                        RunningProcess(
                            pid=int(entry.th32ProcessID),
                            exe_name=exe,
                            parent_pid=int(entry.th32ParentProcessID),
                        )
                    )
                if not _kernel32.Process32NextW(h_snap, ctypes.byref(entry)):
                    break
    except Exception:
        logger.debug(f"{TAG} list_running_processes failed", exc_info=True)
    finally:
        _kernel32.CloseHandle(h_snap)
    return procs


def query_process_image_path(pid: int) -> str:
    """Resolve full executable path for a running PID, or '' if unavailable."""
    if not _IS_WIN or _kernel32 is None or pid <= 0:
        return ""
    h_proc = _kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
    if not h_proc:
        return ""
    try:
        size = wintypes.DWORD(1024)
        buf = ctypes.create_unicode_buffer(1024)
        if _kernel32.QueryFullProcessImageNameW(h_proc, 0, buf, ctypes.byref(size)):
            return str(buf.value or "")
    except Exception:
        pass
    finally:
        _kernel32.CloseHandle(h_proc)
    return ""


def _get_window_long(hwnd: int, index: int) -> int:
    if not _IS_WIN or _user32 is None:
        return 0
    fn = getattr(_user32, "GetWindowLongPtrW", None) or getattr(_user32, "GetWindowLongW", None)
    if fn is None:
        return 0
    return int(fn(hwnd, index))


def _set_window_long(hwnd: int, index: int, value: int) -> int:
    if not _IS_WIN or _user32 is None:
        return 0
    fn = getattr(_user32, "SetWindowLongPtrW", None) or getattr(_user32, "SetWindowLongW", None)
    if fn is None:
        return 0
    return int(fn(hwnd, index, _to_signed_32(value)))


def _get_class_name(hwnd: int) -> str:
    buf = ctypes.create_unicode_buffer(256)
    _user32.GetClassNameW(hwnd, buf, 256)
    return str(buf.value or "")


def _get_window_text(hwnd: int) -> str:
    buf = ctypes.create_unicode_buffer(256)
    _user32.GetWindowTextW(hwnd, buf, 256)
    return str(buf.value or "")


def get_window_rect(hwnd: int) -> SpanBounds | None:
    """Return physical bounding rectangle of hwnd, or None on failure."""
    if not _IS_WIN or _user32 is None or not hwnd:
        return None
    try:
        with with_per_monitor_dpi():
            rc = wintypes.RECT()
            if not _user32.GetWindowRect(hwnd, ctypes.byref(rc)):
                return None
            return SpanBounds(
                x=int(rc.left),
                y=int(rc.top),
                width=int(rc.right - rc.left),
                height=int(rc.bottom - rc.top),
            )
    except Exception:
        return None


def window_has_borders(hwnd: int) -> bool:
    """Return True if the window currently carries caption, frame, or border style bits."""
    if not _IS_WIN or _user32 is None or not hwnd:
        return False
    try:
        style_u32 = _to_u32(_get_window_long(hwnd, GWL_STYLE))
        return bool(style_u32 & BORDER_STYLE_MASK)
    except Exception:
        return False


def find_game_window(pid: int, title_hints: tuple[str, ...] = ()) -> int:
    """Locate the main visible non-minimized game HWND owned by pid, or 0."""
    if not _IS_WIN or _user32 is None or pid <= 0:
        return 0

    hints = tuple(str(h).strip().lower() for h in (title_hints or ()) if len(str(h).strip()) >= 3)
    priority_hwnd = 0
    fallback_hwnd = 0
    best_area = 0

    try:
        with with_per_monitor_dpi():
            def _enum_cb(hwnd, _lparam):
                nonlocal priority_hwnd, fallback_hwnd, best_area
                try:
                    win_pid = wintypes.DWORD(0)
                    _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(win_pid))
                    if int(win_pid.value) != pid:
                        return True
                    if not _user32.IsWindowVisible(hwnd) or _user32.IsIconic(hwnd):
                        return True
                    if _user32.GetWindow(hwnd, GW_OWNER):
                        return True
                    ex_u32 = _to_u32(_get_window_long(hwnd, GWL_EXSTYLE))
                    if ex_u32 & WS_EX_TOOLWINDOW:
                        return True

                    rc = wintypes.RECT()
                    if not _user32.GetWindowRect(hwnd, ctypes.byref(rc)):
                        return True
                    w = int(rc.right - rc.left)
                    h = int(rc.bottom - rc.top)

                    cls_low = _get_class_name(hwnd).lower()
                    title_low = _get_window_text(hwnd).lower()
                    if cls_low == "#32770" or "application load error" in title_low:
                        return True

                    is_priority = (
                        "prism3d" in cls_low
                        or "euro truck" in title_low
                        or "american truck" in title_low
                        or any(hint in title_low for hint in hints)
                    )
                    if is_priority and w > 0 and h > 0:
                        priority_hwnd = int(hwnd)
                        return False

                    if w >= 640 and h >= 360:
                        area = w * h
                        if area > best_area:
                            best_area = area
                            fallback_hwnd = int(hwnd)
                except Exception:
                    pass
                return True

            proc = _WNDENUMPROC(_enum_cb)
            _user32.EnumWindows(proc, 0)
    except Exception:
        logger.debug(f"{TAG} find_game_window failed for pid={pid}", exc_info=True)

    return priority_hwnd or fallback_hwnd


def apply_borderless_span(hwnd: int, bounds: SpanBounds, bring_to_front: bool = True) -> bool:
    """Strip window borders/caption and stretch hwnd across bounds."""
    if not _IS_WIN or _user32 is None or not hwnd:
        return False
    if bounds.width <= 0 or bounds.height <= 0:
        return False
    try:
        with with_per_monitor_dpi():
            style_u32 = _to_u32(_get_window_long(hwnd, GWL_STYLE))
            new_style = (style_u32 & ~BORDER_STYLE_MASK) | WS_POPUP | WS_VISIBLE
            _set_window_long(hwnd, GWL_STYLE, new_style)

            ex_u32 = _to_u32(_get_window_long(hwnd, GWL_EXSTYLE))
            new_ex = ex_u32 & ~EXTENDED_BORDER_MASK
            _set_window_long(hwnd, GWL_EXSTYLE, new_ex)

            ok = bool(
                _user32.SetWindowPos(
                    hwnd,
                    None,
                    int(bounds.x),
                    int(bounds.y),
                    int(bounds.width),
                    int(bounds.height),
                    SWP_NOZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW | SWP_NOSENDCHANGING,
                )
            )
            if ok:
                # Notify engines (e.g. Torque3D / BeamNG.drive) to resize DX backbuffer to new client area
                _user32.PostMessageW(hwnd, WM_EXITSIZEMOVE, 0, 0)
            if bring_to_front:
                _user32.SetForegroundWindow(hwnd)
            return ok
    except Exception:
        logger.exception(f"{TAG} apply_borderless_span failed for hwnd=0x{int(hwnd):X}")
        return False


def _clean_launch_env() -> dict[str, str]:
    try:
        from app.core.online_fix.extractor import clean_subprocess_env

        return clean_subprocess_env()
    except Exception:
        return os.environ.copy()


def _is_elevated() -> bool:
    if not _IS_WIN or _shell32 is None:
        return False
    try:
        return bool(_shell32.IsUserAnAdmin())
    except Exception:
        return False


def _spawn_via_desktop_shell(clean_exe: str, cwd: str, env: dict[str, str]) -> bool:
    """Spawn clean_exe using Explorer's non-elevated desktop token so it behaves like double-click in Explorer."""
    if not _IS_WIN or _user32 is None or _kernel32 is None or _advapi32 is None:
        return False
    shell_hwnd = _user32.GetShellWindow()
    if not shell_hwnd:
        return False

    shell_pid = wintypes.DWORD(0)
    _user32.GetWindowThreadProcessId(shell_hwnd, ctypes.byref(shell_pid))
    if not shell_pid.value:
        return False

    h_proc = None
    h_token = None
    h_dup = None
    pi = _PROCESS_INFORMATION()
    try:
        h_proc = _kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(shell_pid.value))
        if not h_proc:
            return False

        token_h = wintypes.HANDLE()
        if not _advapi32.OpenProcessToken(h_proc, TOKEN_DUPLICATE, ctypes.byref(token_h)):
            return False
        h_token = token_h.value
        if not h_token:
            return False

        dup_h = wintypes.HANDLE()
        if not _advapi32.DuplicateTokenEx(
            h_token,
            TOKEN_DE_ELEVATE_ACCESS,
            None,
            SECURITY_IMPERSONATION,
            TOKEN_PRIMARY,
            ctypes.byref(dup_h),
        ):
            return False
        h_dup = dup_h.value
        if not h_dup:
            return False

        cmd_buf = ctypes.create_unicode_buffer(f'"{clean_exe}"')
        env_block = "\0".join(f"{k}={v}" for k, v in env.items() if "=" not in k) + "\0\0"
        env_buf = ctypes.create_unicode_buffer(env_block)
        si = _STARTUPINFOW()
        si.cb = ctypes.sizeof(_STARTUPINFOW)

        ok = bool(
            _advapi32.CreateProcessWithTokenW(
                h_dup,
                0,
                clean_exe,
                cmd_buf,
                CREATE_UNICODE_ENVIRONMENT,
                ctypes.cast(env_buf, ctypes.c_void_p),
                cwd,
                ctypes.byref(si),
                ctypes.byref(pi),
            )
        )
        if not ok:
            err_code = ctypes.get_last_error()
            logger.warning(f"{TAG} CreateProcessWithTokenW failed for {clean_exe} (winerr={err_code}); using Popen")
            return False
        return True
    except Exception:
        logger.debug(f"{TAG} _spawn_via_desktop_shell failed", exc_info=True)
        return False
    finally:
        if pi.hThread:
            _kernel32.CloseHandle(pi.hThread)
        if pi.hProcess:
            _kernel32.CloseHandle(pi.hProcess)
        if h_dup:
            _kernel32.CloseHandle(h_dup)
        if h_token:
            _kernel32.CloseHandle(h_token)
        if h_proc:
            _kernel32.CloseHandle(h_proc)


def launch_executable_direct(exe_path: str) -> tuple[bool, str]:
    """Start an .exe directly in its own directory without modifying game files or querying Steam/crack state."""
    t0 = time.monotonic()
    clean_exe = os.path.normpath(str(exe_path or "").strip().strip('"'))
    if not clean_exe or clean_exe == "." or not os.path.isfile(clean_exe):
        logger.warning(f"{TAG} Refused direct launch: executable missing ({clean_exe!r})")
        return False, f"Không tìm thấy file thực thi (.exe):\n{clean_exe or '(trống)'}"

    cwd = os.path.dirname(clean_exe)
    env = _clean_launch_env()

    if _IS_WIN and _is_elevated():
        if _spawn_via_desktop_shell(clean_exe, cwd, env):
            elapsed = time.monotonic() - t0
            logger.info(f"{TAG} Started executable directly via desktop shell token: {clean_exe} in {elapsed:.2f}s")
            return True, ""

    try:
        subprocess.Popen([clean_exe], cwd=cwd or None, env=env)
        elapsed = time.monotonic() - t0
        logger.info(f"{TAG} Started executable directly: {clean_exe} in {elapsed:.2f}s")
        return True, ""
    except OSError as exc:
        elapsed = time.monotonic() - t0
        logger.error(f"{TAG} Failed starting executable {clean_exe} after {elapsed:.2f}s: {exc}", exc_info=True)
        return False, f"Không thể khởi chạy file:\n{clean_exe}\n\nChi tiết: {exc}"
