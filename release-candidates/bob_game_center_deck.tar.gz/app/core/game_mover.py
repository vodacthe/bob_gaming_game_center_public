"""
Safe installed-game folder mover for Bob Gaming Game Center.
Moves a game's installation folder to another folder/drive (instant atomic rename on the same
filesystem, or verified chunked staged copy + cleanup across drives/SD card), and updates all
related references:
  - Steam Non-Steam shortcuts in shortcuts.vdf (preserving AppID, artworks & Proton Prefix)
  - Online-Fix Linux runner (start_game.sh)
  - Online-Fix task history (config.json & live OnlineFixManager)
  - Upscaler extra game folders (upscaler.json)
  - Triple-Screen custom/discovered exe paths (config.json)
"""

from __future__ import annotations

from collections.abc import Callable
import logging
import os
import shutil
import stat
import sys
import time
from typing import Sequence

from PySide6.QtCore import QObject, Signal, Slot

from app.config import load_config, save_config
from app.core.game_uninstaller import (
    _is_same_or_parent,
    _norm_case_abs,
    _rmtree_force_writable,
    find_running_process_in_dir,
    is_safe_delete_dir,
)
from app.core.steam_manager import (
    find_game_executable,
    find_steam_path,
    is_steam_running,
    update_non_steam_game_paths,
)

logger = logging.getLogger(__name__)
TAG = "[Library/Move]"

_COPY_CHUNK_BYTES = 1024 * 1024  # 1 MiB
_FREE_SPACE_BUFFER_BYTES = 64 * 1024 * 1024  # 64 MiB safety margin when > 64 MiB


class MoveCancelledError(Exception):
    """Raised when the user cancels a cross-device game folder copy."""


def remap_path_prefix(path: str, old_dir: str, new_dir: str) -> str:
    """Remap `path` into `new_dir` if it equals or resides inside `old_dir`, else return `path` unchanged."""
    clean = (path or "").strip().strip('"')
    if not clean or not old_dir or not new_dir:
        return clean
    norm_old = os.path.normpath(os.path.abspath(old_dir))
    norm_new = os.path.normpath(os.path.abspath(new_dir))
    norm_val = os.path.normpath(os.path.abspath(clean))
    if not _is_same_or_parent(_norm_case_abs(norm_old), _norm_case_abs(norm_val)):
        return clean
    rel = os.path.relpath(norm_val, norm_old)
    return norm_new if rel == "." else os.path.normpath(os.path.join(norm_new, rel))


def _measure_tree(root_dir: str) -> tuple[int, int]:
    """Return (file_count, total_bytes) for all regular files/symlinks inside root_dir."""
    file_count = 0
    total_bytes = 0
    for cur_root, _dirs, files in os.walk(root_dir, followlinks=False):
        for fname in files:
            fpath = os.path.join(cur_root, fname)
            file_count += 1
            if not os.path.islink(fpath):
                try:
                    total_bytes += os.path.getsize(fpath)
                except OSError:
                    pass
    return file_count, total_bytes


def validate_move_operation(
    source_dir: str,
    dest_parent_dir: str,
    *,
    other_game_exes: Sequence[str] = (),
    extra_protected_dirs: Sequence[str] = (),
) -> tuple[bool, str, str, int]:
    """
    Validate that moving `source_dir` into `dest_parent_dir/<folder_name>` is safe and feasible.
    Returns `(ok, error_message, dest_dir, total_bytes)`.
    """
    clean_src = (source_dir or "").strip().strip('"')
    clean_dst_parent = (dest_parent_dir or "").strip().strip('"')
    if not clean_src or not os.path.isdir(clean_src):
        return False, "Thư mục cài đặt nguồn của trò chơi không tồn tại.", "", 0
    if not clean_dst_parent or not os.path.isdir(clean_dst_parent):
        return False, "Thư mục đích không tồn tại.", "", 0

    safe_ok, safe_reason = is_safe_delete_dir(
        clean_src,
        other_game_exes=other_game_exes,
        extra_protected_dirs=extra_protected_dirs,
    )
    if not safe_ok:
        return False, safe_reason, "", 0

    norm_src = os.path.normpath(os.path.abspath(clean_src))
    norm_dst_parent = os.path.normpath(os.path.abspath(clean_dst_parent))
    src_case = _norm_case_abs(norm_src)
    dst_parent_case = _norm_case_abs(norm_dst_parent)

    if _is_same_or_parent(src_case, dst_parent_case):
        return False, "Không thể di chuyển thư mục trò chơi vào chính bên trong nó.", "", 0

    folder_name = os.path.basename(norm_src)
    dest_dir = os.path.normpath(os.path.join(norm_dst_parent, folder_name))
    dest_case = _norm_case_abs(dest_dir)

    if dest_case == src_case:
        return False, "Thư mục đích trùng với vị trí hiện tại của trò chơi.", dest_dir, 0

    if os.path.lexists(dest_dir):
        if os.path.isdir(dest_dir):
            try:
                if any(os.scandir(dest_dir)):
                    return False, f"Thư mục đích đã tồn tại và không trống:\n{dest_dir}", dest_dir, 0
            except OSError as exc:
                return False, f"Không thể kiểm tra thư mục đích ({dest_dir}): {exc}", dest_dir, 0
        else:
            return False, f"Đường dẫn đích đã tồn tại dưới dạng tệp:\n{dest_dir}", dest_dir, 0

    _file_count, total_bytes = _measure_tree(norm_src)

    try:
        src_dev = os.stat(norm_src).st_dev
        dst_dev = os.stat(norm_dst_parent).st_dev
        same_fs = src_dev == dst_dev
    except OSError:
        same_fs = False

    if not same_fs:
        try:
            free_bytes = shutil.disk_usage(norm_dst_parent).free
            required = total_bytes + (_FREE_SPACE_BUFFER_BYTES if total_bytes > _FREE_SPACE_BUFFER_BYTES else 0)
            if free_bytes < required:
                need_gb = total_bytes / (1024 ** 3)
                free_gb = free_bytes / (1024 ** 3)
                return (
                    False,
                    f"Ổ đĩa đích không đủ dung lượng trống (cần ~{need_gb:.2f} GB, còn trống {free_gb:.2f} GB).",
                    dest_dir,
                    total_bytes,
                )
        except OSError as exc:
            logger.warning(f"{TAG} Could not check free disk space on {norm_dst_parent}: {exc}")

    return True, "", dest_dir, total_bytes


def _copy_tree_chunked(
    source_dir: str,
    staging_dir: str,
    total_bytes: int,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    is_cancelled: Optional[Callable[[], bool]] = None,
) -> tuple[int, int]:
    """Copy `source_dir` into `staging_dir` in 1 MiB chunks with cancellation and 25% milestone logs."""
    copied_files = 0
    copied_bytes = 0
    last_milestone = -1
    denom = max(1, total_bytes)

    os.makedirs(staging_dir, exist_ok=True)
    try:
        shutil.copystat(source_dir, staging_dir, follow_symlinks=False)
    except OSError:
        pass

    for cur_root, dirs, files in os.walk(source_dir, followlinks=False):
        if is_cancelled and is_cancelled():
            raise MoveCancelledError("Đã hủy di chuyển trò chơi theo yêu cầu.")

        rel_root = os.path.relpath(cur_root, source_dir)
        dst_root = staging_dir if rel_root == "." else os.path.join(staging_dir, rel_root)
        os.makedirs(dst_root, exist_ok=True)

        for dname in list(dirs):
            src_sub = os.path.join(cur_root, dname)
            dst_sub = os.path.join(dst_root, dname)
            if os.path.islink(src_sub):
                dirs.remove(dname)
                os.symlink(os.readlink(src_sub), dst_sub)
            else:
                os.makedirs(dst_sub, exist_ok=True)
                try:
                    shutil.copystat(src_sub, dst_sub, follow_symlinks=False)
                except OSError:
                    pass

        for fname in files:
            if is_cancelled and is_cancelled():
                raise MoveCancelledError("Đã hủy di chuyển trò chơi theo yêu cầu.")

            src_file = os.path.join(cur_root, fname)
            dst_file = os.path.join(dst_root, fname)
            if os.path.islink(src_file):
                os.symlink(os.readlink(src_file), dst_file)
                copied_files += 1
                continue

            with open(src_file, "rb") as fsrc, open(dst_file, "wb") as fdst:
                while True:
                    if is_cancelled and is_cancelled():
                        raise MoveCancelledError("Đã hủy di chuyển trò chơi theo yêu cầu.")
                    buf = fsrc.read(_COPY_CHUNK_BYTES)
                    if not buf:
                        break
                    fdst.write(buf)
                    copied_bytes += len(buf)
                    pct = min(98, int((copied_bytes / denom) * 95))
                    if progress_cb:
                        progress_cb(pct, 100, f"Đang sao chép dữ liệu trò chơi... ({pct}%)")
                    milestone = (pct // 25) * 25
                    if milestone >= 25 and milestone > last_milestone:
                        last_milestone = milestone
                        logger.info(f"{TAG} Copy progress {milestone}% ({copied_bytes}/{total_bytes} bytes)")

            try:
                shutil.copystat(src_file, dst_file, follow_symlinks=False)
            except OSError:
                try:
                    os.chmod(dst_file, stat.S_IMODE(os.stat(src_file).st_mode))
                except OSError:
                    pass
            copied_files += 1

    # Sync directory metadata (permissions/timestamps) bottom-up after copying files
    for cur_root, dirs, _files in os.walk(source_dir, topdown=False, followlinks=False):
        rel_root = os.path.relpath(cur_root, source_dir)
        dst_root = staging_dir if rel_root == "." else os.path.join(staging_dir, rel_root)
        for dname in dirs:
            src_sub = os.path.join(cur_root, dname)
            dst_sub = os.path.join(dst_root, dname)
            if not os.path.islink(src_sub) and os.path.isdir(dst_sub):
                try:
                    shutil.copystat(src_sub, dst_sub, follow_symlinks=False)
                except OSError:
                    pass

    return copied_files, copied_bytes


def _update_online_fix_tasks_paths(old_dir: str, new_dir: str) -> int:
    """Remap target_install_dir and download_temp_dir in OnlineFixManager & persisted config.json."""
    updated = 0
    try:
        from app.core.online_fix import manager as of_mgr_mod

        inst = getattr(of_mgr_mod, "_manager_instance", None)
        if inst is not None:
            with inst._lock:
                for task in inst.tasks.values():
                    new_target = remap_path_prefix(task.target_install_dir, old_dir, new_dir)
                    new_temp = remap_path_prefix(task.download_temp_dir, old_dir, new_dir)
                    if new_target != task.target_install_dir or new_temp != task.download_temp_dir:
                        task.target_install_dir = new_target
                        task.download_temp_dir = new_temp
                        updated += 1
            if updated > 0:
                inst._save_tasks_to_config()
                return updated
    except Exception as exc:
        logger.debug(f"{TAG} Live OnlineFixManager task update skipped: {exc}")

    cfg = load_config()
    raw_tasks = cfg.get("online_fix_tasks")
    if isinstance(raw_tasks, list):
        changed = False
        for item in raw_tasks:
            if not isinstance(item, dict):
                continue
            for key in ("target_install_dir", "download_temp_dir"):
                val = str(item.get(key) or "").strip()
                if val:
                    remapped = remap_path_prefix(val, old_dir, new_dir)
                    if remapped != val:
                        item[key] = remapped
                        changed = True
                        updated += 1
        if changed:
            save_config(cfg)
    return updated


def _update_upscaler_extra_games(old_dir: str, new_dir: str) -> bool:
    """Replace `old_dir` with `new_dir` inside Upscaler extra_games settings if present."""
    from app.core.upscaler.settings import SettingsStore

    store = SettingsStore()
    old_case = _norm_case_abs(old_dir)
    new_norm = os.path.normpath(os.path.abspath(new_dir))
    changed = False
    new_list: list[str] = []
    for folder in store.data.extra_games:
        if _norm_case_abs(folder) == old_case:
            new_list.append(new_norm)
            changed = True
        else:
            new_list.append(folder)
    if changed:
        store.data.extra_games = new_list
        store.save()
        logger.info(f"{TAG} Updated Upscaler extra_games path: {old_dir!r} -> {new_norm!r}")
    return changed


def _update_triple_screen_paths(old_dir: str, new_dir: str) -> int:
    """Update Triple-Screen saved exe_path entries matching `old_dir` in config.json."""
    cfg = load_config()
    ts = cfg.get("triple_screen")
    if not isinstance(ts, dict) or not isinstance(ts.get("games"), list):
        return 0
    changed = 0
    for item in ts["games"]:
        if not isinstance(item, dict):
            continue
        exe_val = str(item.get("exe_path") or "").strip().strip('"')
        if exe_val:
            remapped = remap_path_prefix(exe_val, old_dir, new_dir)
            if remapped != exe_val:
                item["exe_path"] = remapped
                changed += 1
    if changed > 0:
        save_config(cfg)
        logger.info(f"{TAG} Updated {changed} Triple-Screen exe path(s) for {old_dir!r} -> {new_dir!r}")
    return changed


def move_game_installation(
    game_name: str,
    source_dir: str,
    dest_parent_dir: str,
    exe_path: str = "",
    save_path: str = "",
    steam_path: str | None = None,
    other_game_exes: Sequence[str] = (),
    extra_protected_dirs: Sequence[str] = (),
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    is_cancelled: Optional[Callable[[], bool]] = None,
) -> dict:
    """
    Move an installed game folder from `source_dir` into `dest_parent_dir/<folder_name>`
    and update Steam shortcuts + all internal Bob Gaming references.
    """
    t0 = time.monotonic()
    logger.info(
        f"{TAG} Starting move for {game_name!r} "
        f"(source={source_dir!r}, dest_parent={dest_parent_dir!r})"
    )

    if not game_name:
        msg = "Thiếu tên trò chơi cần di chuyển."
        logger.warning(f"{TAG} Refused move: {msg}")
        return {"success": False, "game_name": game_name, "error": msg}

    norm_src = os.path.normpath(os.path.abspath((source_dir or "").strip().strip('"')))
    running_proc = find_running_process_in_dir(norm_src)
    if running_proc:
        msg = f"Trò chơi đang chạy ({running_proc}). Vui lòng đóng game trước khi di chuyển thư mục."
        logger.warning(f"{TAG} Refused move for {game_name!r}: process {running_proc!r} is running")
        return {"success": False, "game_name": game_name, "error": msg}

    # Check if an active OnlineFix download/extract task is using source_dir
    try:
        from app.core.online_fix import manager as of_mgr_mod
        from app.core.online_fix.models import ACTIVE_STATUSES

        inst = getattr(of_mgr_mod, "_manager_instance", None)
        if inst is not None:
            src_case = _norm_case_abs(norm_src)
            with inst._lock:
                for task in inst.tasks.values():
                    if task.status in ACTIVE_STATUSES and task.target_install_dir:
                        if _norm_case_abs(task.target_install_dir) == src_case:
                            msg = "Trò chơi đang có tác vụ tải hoặc giải nén chạy. Vui lòng đợi hoàn tất rồi di chuyển."
                            logger.warning(f"{TAG} Refused move for {game_name!r}: active task {task.task_id}")
                            return {"success": False, "game_name": game_name, "error": msg}
    except Exception:
        pass

    ok, err_msg, dest_dir, total_bytes = validate_move_operation(
        norm_src,
        dest_parent_dir,
        other_game_exes=other_game_exes,
        extra_protected_dirs=extra_protected_dirs,
    )
    if not ok:
        logger.warning(f"{TAG} Refused move for {game_name!r}: {err_msg}")
        return {"success": False, "game_name": game_name, "error": err_msg}

    norm_dst_parent = os.path.dirname(dest_dir)
    src_file_count, src_total_bytes = _measure_tree(norm_src)

    try:
        same_fs = os.stat(norm_src).st_dev == os.stat(norm_dst_parent).st_dev
    except OSError:
        same_fs = False

    if same_fs:
        if progress_cb:
            progress_cb(30, 100, "Đang di chuyển thư mục trên cùng ổ đĩa...")
        try:
            # Remove pre-existing empty placeholder directory at dest_dir if present
            if os.path.isdir(dest_dir):
                os.rmdir(dest_dir)
            os.rename(norm_src, dest_dir)
            logger.info(f"{TAG} Instant rename succeeded for {game_name!r}: {norm_src!r} -> {dest_dir!r}")
        except OSError as exc:
            logger.info(f"{TAG} Same-FS rename failed ({exc}); falling back to verified staged copy")
            same_fs = False

    if not same_fs:
        staging_dir = os.path.join(
            norm_dst_parent,
            f".bob_move_{os.path.basename(dest_dir)}_{os.getpid()}",
        )
        if os.path.exists(staging_dir):
            _rmtree_force_writable(staging_dir)

        try:
            if progress_cb:
                progress_cb(2, 100, "Đang sao chép dữ liệu trò chơi sang vị trí mới...")
            copied_files, copied_bytes = _copy_tree_chunked(
                norm_src,
                staging_dir,
                total_bytes=src_total_bytes,
                progress_cb=progress_cb,
                is_cancelled=is_cancelled,
            )

            dst_files, dst_bytes = _measure_tree(staging_dir)
            if dst_files != src_file_count or dst_bytes != src_total_bytes:
                raise OSError(
                    f"Xác minh dữ liệu sau khi sao chép không khớp "
                    f"(nguồn: {src_file_count} tệp / {src_total_bytes} B, đích: {dst_files} tệp / {dst_bytes} B)."
                )

            if os.path.isdir(dest_dir):
                os.rmdir(dest_dir)
            os.rename(staging_dir, dest_dir)
        except MoveCancelledError as exc:
            logger.info(f"{TAG} Move cancelled for {game_name!r}; cleaning up staging folder {staging_dir!r}")
            if os.path.exists(staging_dir):
                _rmtree_force_writable(staging_dir)
            return {"success": False, "game_name": game_name, "cancelled": True, "error": str(exc)}
        except OSError as exc:
            logger.error(f"{TAG} Move failed for {game_name!r} while copying to {dest_dir!r}: {exc}", exc_info=True)
            if os.path.exists(staging_dir):
                _rmtree_force_writable(staging_dir)
            return {
                "success": False,
                "game_name": game_name,
                "error": f"Không thể sao chép trò chơi sang thư mục mới:\n{dest_dir}\n\nChi tiết: {exc}",
            }

        # Destination verified & atomically moved into place -> safely delete source folder
        if progress_cb:
            progress_cb(96, 100, "Đang dọn dẹp thư mục cũ...")
        try:
            _rmtree_force_writable(norm_src)
        except OSError as exc:
            logger.warning(f"{TAG} Copied to {dest_dir!r} cleanly, but source cleanup failed ({norm_src!r}): {exc}")

    if progress_cb:
        progress_cb(98, 100, "Đang cập nhật đường dẫn Steam và cấu hình...")

    clean_old_exe = (exe_path or "").strip().strip('"')
    new_exe = remap_path_prefix(clean_old_exe, norm_src, dest_dir) if clean_old_exe else ""
    if not new_exe or not os.path.isfile(new_exe):
        detected_exe = find_game_executable(dest_dir, game_name)
        if detected_exe:
            new_exe = detected_exe

    clean_old_save = (save_path or "").strip().strip('"')
    new_save = remap_path_prefix(clean_old_save, norm_src, dest_dir) if clean_old_save else ""
    save_path_moved = bool(
        clean_old_save and new_save and _norm_case_abs(new_save) != _norm_case_abs(clean_old_save)
    )

    warnings: list[str] = []

    # 1. Update Steam Non-Steam shortcuts (preserving AppID, artworks & Proton Prefix)
    steam_updated_count = 0
    steam_was_running = False
    steam_start_ts = None
    try:
        resolved_steam = steam_path or find_steam_path()
        if resolved_steam:
            steam_was_running = is_steam_running()
            sc_res = update_non_steam_game_paths(
                game_name=game_name,
                old_dir=norm_src,
                new_dir=dest_dir,
                old_exe=clean_old_exe,
                new_exe=new_exe,
                steam_path=resolved_steam,
            )
            steam_updated_count = int(sc_res.get("updated_count", 0))
            steam_start_ts = sc_res.get("steam_start_ts")
            if not sc_res.get("success"):
                warnings.append(str(sc_res.get("message") or "Không thể cập nhật shortcut trong Steam."))
    except Exception as exc:
        logger.warning(f"{TAG} Failed updating Steam shortcut paths for {game_name!r}: {exc}")
        warnings.append(f"Không thể cập nhật phím tắt Steam ({exc}).")

    # 2. Regenerate Linux Online-Fix start_game.sh if present / applicable
    try:
        start_sh = os.path.join(dest_dir, "start_game.sh")
        from app.core.online_fix.runner import detect_online_fix_game, prepare_online_fix_launch

        det = detect_online_fix_game(dest_dir)
        if os.path.isfile(start_sh) or (sys.platform != "win32" and det.get("is_online_fix")):
            app_id = det.get("appid") or 480
            prepare_online_fix_launch(dest_dir, new_exe, app_id=app_id)
            logger.info(f"{TAG} Updated Online-Fix launcher inside {dest_dir!r}")
    except Exception as exc:
        logger.warning(f"{TAG} Could not refresh start_game.sh for {game_name!r}: {exc}")
        warnings.append(f"Không thể cập nhật start_game.sh ({exc}).")

    # 3. Update Online-Fix task history
    tasks_updated = 0
    try:
        tasks_updated = _update_online_fix_tasks_paths(norm_src, dest_dir)
    except Exception as exc:
        logger.warning(f"{TAG} Could not update Online-Fix task paths for {game_name!r}: {exc}")
        warnings.append(f"Không thể cập nhật lịch sử tải ({exc}).")

    # 4. Update Upscaler extra_games
    upscaler_updated = False
    try:
        upscaler_updated = _update_upscaler_extra_games(norm_src, dest_dir)
    except Exception as exc:
        logger.warning(f"{TAG} Could not update Upscaler paths for {game_name!r}: {exc}")

    # 5. Update Triple-Screen config entries
    triple_updated = 0
    try:
        triple_updated = _update_triple_screen_paths(norm_src, dest_dir)
    except Exception as exc:
        logger.warning(f"{TAG} Could not update Triple-Screen paths for {game_name!r}: {exc}")

    if progress_cb:
        progress_cb(100, 100, "Di chuyển trò chơi hoàn tất.")

    elapsed = time.monotonic() - t0
    logger.info(
        f"{TAG} Completed move for {game_name!r} in {elapsed:.2f}s "
        f"({norm_src!r} -> {dest_dir!r}, steam_shortcuts={steam_updated_count}, "
        f"save_moved={save_path_moved}, tasks={tasks_updated}, upscaler={upscaler_updated}, triple={triple_updated})"
    )
    return {
        "success": True,
        "game_name": game_name,
        "old_dir": norm_src,
        "new_dir": dest_dir,
        "old_exe": clean_old_exe,
        "new_exe": new_exe,
        "old_save_path": clean_old_save,
        "new_save_path": new_save,
        "save_path_moved": save_path_moved,
        "steam_updated_count": steam_updated_count,
        "steam_was_running": steam_was_running,
        "steam_start_ts": steam_start_ts,
        "upscaler_updated": upscaler_updated,
        "tasks_updated": tasks_updated,
        "triple_updated": triple_updated,
        "warnings": warnings,
        "elapsed": elapsed,
    }


class GameMoveWorker(QObject):
    """Background QThread worker for moving an installed game without freezing the UI."""

    progress = Signal(int, int, str)
    finished = Signal(dict)

    def __init__(
        self,
        game_name: str,
        source_dir: str,
        dest_parent_dir: str,
        exe_path: str = "",
        save_path: str = "",
        steam_path: str | None = None,
        other_game_exes: Sequence[str] = (),
        extra_protected_dirs: Sequence[str] = (),
        parent: QObject | None = None,
    ):
        super().__init__(parent)
        self.game_name = game_name
        self.source_dir = source_dir
        self.dest_parent_dir = dest_parent_dir
        self.exe_path = exe_path
        self.save_path = save_path
        self.steam_path = steam_path
        self.other_game_exes = list(other_game_exes)
        self.extra_protected_dirs = list(extra_protected_dirs)
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    @Slot()
    def run(self) -> None:
        try:
            result = move_game_installation(
                game_name=self.game_name,
                source_dir=self.source_dir,
                dest_parent_dir=self.dest_parent_dir,
                exe_path=self.exe_path,
                save_path=self.save_path,
                steam_path=self.steam_path,
                other_game_exes=self.other_game_exes,
                extra_protected_dirs=self.extra_protected_dirs,
                progress_cb=lambda c, t, m: self.progress.emit(c, t, m),
                is_cancelled=lambda: self._cancelled,
            )
            self.finished.emit(result)
        except Exception as exc:
            logger.exception(f"{TAG} Unexpected error in GameMoveWorker for {self.game_name!r}")
            self.finished.emit({
                "success": False,
                "game_name": self.game_name,
                "error": f"Lỗi không mong muốn khi di chuyển trò chơi: {exc}",
            })
