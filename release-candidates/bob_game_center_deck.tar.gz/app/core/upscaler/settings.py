"""Upscaler preferences and the user's extra game folders (<CONFIG_DIR>/upscaler.json)."""

from __future__ import annotations

import json
import logging
import os
import threading
from dataclasses import dataclass, field, fields

from app.core.upscaler.paths import settings_path

logger = logging.getLogger(__name__)
TAG = "[Upscaler/Settings]"


COLUMN_COUNT = 6                   # game table columns (see app.ui.upscaler_screen)
MIN_COLUMN_WIDTH, MAX_COLUMN_WIDTH = 40, 1600


def clean_column_widths(widths) -> list:
    """The saved widths if they are usable (right count, whole numbers in range), else [] (= defaults)."""
    if not isinstance(widths, (list, tuple)) or len(widths) != COLUMN_COUNT:
        return []
    out = []
    for w in widths:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            return []
        out.append(min(max(int(w), MIN_COLUMN_WIDTH), MAX_COLUMN_WIDTH))
    return out


@dataclass
class UpscalerSettings:
    extra_games: list = field(default_factory=list)      # folders the user added by hand
    helixsr_disclaimer_ok: bool = False                  # accepted the "network belongs to NVIDIA" notice
    helixsr_dlss_path: str = ""                          # optional nvngx_dlss.dll handed to the HelixSR setup
    column_widths: list = field(default_factory=list)    # game table column widths in px ([] = defaults)

    def normalized(self) -> "UpscalerSettings":
        self.column_widths = clean_column_widths(self.column_widths)
        seen, out = set(), []
        for p in self.extra_games:
            if isinstance(p, str) and p.strip():
                p = os.path.normpath(p.strip())
                if p.lower() not in seen:
                    seen.add(p.lower())
                    out.append(p)
        self.extra_games = out
        return self


class SettingsStore:
    """Thread-safe load/save with atomic replace. Unknown keys are ignored, wrong types defaulted."""

    def __init__(self, path: str | None = None):
        self.path = path or settings_path()
        self._lock = threading.RLock()
        self.data = UpscalerSettings()
        self.load()

    def load(self) -> UpscalerSettings:
        with self._lock:
            data = UpscalerSettings()
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                if isinstance(raw, dict):
                    for fld in fields(UpscalerSettings):
                        if fld.name in raw and type(raw[fld.name]) is type(getattr(data, fld.name)):
                            setattr(data, fld.name, raw[fld.name])
            except FileNotFoundError:
                pass
            except (OSError, ValueError) as e:
                logger.warning(f"{TAG} could not read {self.path} ({e}); using defaults")
            self.data = data.normalized()
            return self.data

    def save(self) -> bool:
        with self._lock:
            self.data.normalized()
            try:
                os.makedirs(os.path.dirname(self.path), exist_ok=True)
                tmp = self.path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.data.__dict__, f, indent=2, ensure_ascii=False)
                os.replace(tmp, self.path)
                return True
            except OSError as e:
                logger.error(f"{TAG} failed to save {self.path}: {e}")
                return False

    def add_game(self, folder: str) -> bool:
        with self._lock:
            self.data.extra_games.append(folder)
            self.data.normalized()
            logger.info(f"{TAG} game folder added: {folder} ({len(self.data.extra_games)} added by hand)")
            return self.save()

    def remove_game(self, folder: str) -> bool:
        with self._lock:
            key = os.path.normpath(folder).lower()
            self.data.extra_games = [p for p in self.data.extra_games if os.path.normpath(p).lower() != key]
            logger.info(f"{TAG} game folder removed: {folder} ({len(self.data.extra_games)} added by hand)")
            return self.save()
