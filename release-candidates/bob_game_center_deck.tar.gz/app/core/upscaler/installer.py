"""Install / remove an upscaler for one game.

Modes
  fsr_update   replace the game's FSR 3.1 DLL(s) with AMD's newer ones (OptiScaler package)
  optiscaler   OptiScaler as a proxy DLL (its package already bundles fakenvapi for AMD / Intel GPUs)
  helixsr_f    HelixSR's FSR 3.1 drop-in: the game's FSR DLL becomes <name>.original.dll, HelixSR takes its name
  helixsr_o    HelixSR's own OptiScaler route: OptiScaler (shipped inside the HelixSR package) + a HelixSR folder next to the exe

All file changes go through `Manifest` (write-ahead), so `uninstall` / `recover` restore the folder exactly.
HelixSR's own files are only copied unmodified from its package; nothing in them is edited.
"""

from __future__ import annotations

import ctypes
import logging
import os
import sys
import threading
import time
from dataclasses import dataclass
from typing import Callable

from app.core.upscaler import ini_file
from app.core.upscaler.detector import PROXY_NAMES, GameScan, fsr_targets
from app.core.upscaler.gpu import GpuInfo
from app.core.upscaler.manifest import STATE_APPLIED, Manifest, ManifestError

logger = logging.getLogger(__name__)
TAG = "[Upscaler/Install]"

MODE_FSR_UPDATE, MODE_OPTISCALER = "fsr_update", "optiscaler"
MODE_HELIXSR_F, MODE_HELIXSR_O = "helixsr_f", "helixsr_o"
MODES = (MODE_FSR_UPDATE, MODE_OPTISCALER, MODE_HELIXSR_F, MODE_HELIXSR_O)
HELIXSR_DIR_NAME = "HelixSR"                 # next to the exe, as HelixSR's own setup names it
HELIXSR_DLL = "amd_fidelityfx_dx12.dll"      # in the package root; once built it carries the network (tag below)
HELIXSR_AMD_DIR = "amd-fsr"                  # AMD's FSR / frame-generation DLLs that ship with HelixSR
HELIXSR_OPTISCALER_DIR = "optiscaler"        # the OptiScaler 0.9.4 HelixSR ships (official, unmodified) + fakenvapi
HELIXSR_OWN = "helixsr.dll"                  # HelixSR folder: FfxDx12Path, and a second copy for FfxDx12SRPath. OptiScaler
HELIXSR_OWN_SR = "helixsr_upscaler.dll"      # hooks the upscaler module, so the two must be different files
AMD_FSR_COPY = "amd_fidelityfx_upscaler_dx12.amd.dll"   # AMD's FSR listed after HelixSR in OptiScaler's menu
AMD_FG = "amd_fidelityfx_framegeneration_dx12.dll"
_NETWORK_TAG = b"HXSRNET1"                   # first 8 of the last 32 bytes of a built HelixSR DLL

OPTISCALER_MAIN_DLL = "optiscaler.dll"
OPTISCALER_INI = "optiscaler.ini"
_PAYLOAD_SKIP_SUFFIX = (".bat", ".sh", ".md", ".txt", ".7z", ".zip")
_PAYLOAD_SKIP_DIRS = {"licenses", "license"}


class InstallError(Exception):
    """A user-facing reason the operation was refused or failed (Vietnamese UI shows it as-is, so keep it short)."""


@dataclass
class InstallStatus:
    mode: str | None = None       # None: nothing of Bob's installed
    pending: bool = False         # an interrupted install is waiting to be rolled back
    packages: dict | None = None


# ---------------------------------------------------------------- helpers

_locks_guard = threading.Lock()
_folder_locks: dict[str, threading.RLock] = {}


def folder_lock(exe_dir: str) -> threading.RLock:
    """One lock per game folder: install / uninstall / recover of the same game never run at the same time
    (re-entrant: `install` calls `uninstall`)."""
    key = os.path.normcase(os.path.normpath(exe_dir))
    with _locks_guard:
        return _folder_locks.setdefault(key, threading.RLock())


def find_file(root: str, name: str) -> str | None:
    """Case-insensitive search below `root`; the shallowest match wins."""
    best: tuple[int, str] | None = None
    for dirpath, _dirs, files in os.walk(root):
        for f in files:
            if f.lower() == name.lower():
                depth = dirpath[len(root):].count(os.sep)
                if best is None or depth < best[0]:
                    best = (depth, os.path.join(dirpath, f))
    return best[1] if best else None


def _rel(*parts: str) -> str:
    return "/".join(p.replace("\\", "/").strip("/") for p in parts if p)


def pick_proxy_name(exe_dir: str) -> str:
    """First proxy DLL name OptiScaler can load as that is not already taken in the exe folder."""
    try:
        existing = {f.lower() for f in os.listdir(exe_dir)}
    except OSError as e:
        logger.error(f"{TAG} cannot list {exe_dir}: {e}")
        raise InstallError(f"Không đọc được thư mục game: {e}") from e
    for name in PROXY_NAMES:
        if name not in existing:
            if name != PROXY_NAMES[0]:
                logger.info(f"{TAG} {PROXY_NAMES[0]} is taken in {exe_dir}; OptiScaler will use {name}")
            return name
    logger.warning(f"{TAG} every proxy DLL name is taken in {exe_dir}")
    raise InstallError("Mọi tên proxy DLL (dxgi, winmm, version, ...) đã bị mod khác dùng.")


def _running_exes(exe_dir: str) -> list[str]:
    """Names of the .exe files in `exe_dir` that currently have a running process (Windows only)."""
    if sys.platform != "win32":
        return []
    try:
        names = {f.lower() for f in os.listdir(exe_dir) if f.lower().endswith(".exe")}
    except OSError:
        return []
    if not names:
        return []
    from ctypes import wintypes

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD),
                    ("th32DefaultHeapID", ctypes.c_size_t), ("th32ModuleID", wintypes.DWORD),
                    ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD),
                    ("pcPriClassBase", wintypes.LONG), ("dwFlags", wintypes.DWORD),
                    ("szExeFile", wintypes.WCHAR * 260)]

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    k32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    k32.Process32FirstW.argtypes = k32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
    k32.CloseHandle.argtypes = [wintypes.HANDLE]
    snap = k32.CreateToolhelp32Snapshot(0x2, 0)   # TH32CS_SNAPPROCESS
    if snap in (None, wintypes.HANDLE(-1).value):
        return []
    found = set()
    try:
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(entry)
        ok = k32.Process32FirstW(snap, ctypes.byref(entry))
        while ok:
            if entry.szExeFile.lower() in names:
                found.add(entry.szExeFile)
            ok = k32.Process32NextW(snap, ctypes.byref(entry))
    finally:
        k32.CloseHandle(snap)
    return sorted(found)


def running_exes(exe_dir: str) -> list[str]:
    """Names of the .exe files in `exe_dir` that currently have a running process (Windows only).

    A failure to ask Windows is logged and reported as "nothing running": the file operations that follow fail
    cleanly (and roll back) if a DLL is locked, so this check must never take the app down.
    """
    try:
        found = _running_exes(exe_dir)
    except Exception as e:   # noqa: BLE001 - ctypes / OS errors
        logger.warning(f"{TAG} could not check for running game processes in {exe_dir}: {e!r}")
        return []
    if found:
        logger.info(f"{TAG} game process(es) running from {exe_dir}: {found}")
    return found


# ---------------------------------------------------------------- status / recovery

def get_status(exe_dir: str) -> InstallStatus:
    try:
        m = Manifest.load(exe_dir)
    except ManifestError:
        return InstallStatus(mode=None, pending=True)   # unreadable journal: treat as interrupted
    if m is None:
        return InstallStatus()
    return InstallStatus(mode=m.mode or None, pending=m.state != STATE_APPLIED, packages=dict(m.packages))


def recover(exe_dir: str) -> bool:
    """Roll back an interrupted install. True if something was repaired."""
    with folder_lock(exe_dir):
        try:
            m = Manifest.load(exe_dir)
        except ManifestError:
            return False
        if m is None or m.state == STATE_APPLIED:
            return False
        logger.warning(f"{TAG} found an interrupted {m.mode or 'install'} in {exe_dir}; rolling it back")
        try:
            problems = m.rollback()
        except Exception as e:   # noqa: BLE001 - recovery runs while the list loads; it must not abort it
            logger.error(f"{TAG} recovery of {exe_dir} crashed: {e!r}", exc_info=True)
            return False
        if problems:
            logger.warning(f"{TAG} could not fully recover {exe_dir}: {problems}")
        else:
            logger.info(f"{TAG} {exe_dir} recovered")
        return not problems


def uninstall(exe_dir: str, is_running: Callable[[str], list[str]] = running_exes) -> None:
    with folder_lock(exe_dir):
        try:
            m = Manifest.load(exe_dir)
        except ManifestError as e:
            raise InstallError(f"Không đọc được nhật ký cài đặt ({e}). Hãy kiểm tra thư mục {os.path.join(exe_dir, 'BobUpscaler')}.") from e
        if m is None:
            logger.debug(f"{TAG} nothing to uninstall in {exe_dir}")
            return
        busy = is_running(exe_dir)
        if busy:
            logger.warning(f"{TAG} uninstall refused in {exe_dir}: game running ({busy})")
            raise InstallError(f"Hãy đóng game trước ({', '.join(busy)} đang chạy).")
        started = time.monotonic()
        logger.info(f"{TAG} uninstalling {m.mode or 'install'} from {exe_dir}")
        try:
            problems = m.rollback()
        except OSError as e:
            logger.error(f"{TAG} uninstall of {exe_dir} failed: {e!r}", exc_info=True)
            raise InstallError(f"Gỡ thất bại: {e}") from e
        if problems:
            logger.error(f"{TAG} uninstall of {exe_dir} incomplete: {problems}")
            raise InstallError("Không khôi phục hết được: " + "; ".join(problems))
        logger.info(f"{TAG} uninstalled from {exe_dir} in {time.monotonic() - started:.2f}s")


# ---------------------------------------------------------------- install

def has_embedded_network(path: str) -> bool:
    """True when HelixSR's DLL carries the network (its setup appends it; the tag sits in the last 32 bytes)."""
    try:
        with open(path, "rb") as f:
            f.seek(-32, os.SEEK_END)
            return f.read(8) == _NETWORK_TAG
    except OSError:
        return False


def helixsr_ready(helix_dir: str | None) -> bool:
    return bool(helix_dir) and has_embedded_network(os.path.join(helix_dir, HELIXSR_DLL))


def _fsr_targets(scan: GameScan) -> list[str]:
    """The FSR 3.1 DLL(s) to replace: the upscaler DLL, or amd_fidelityfx_dx12.dll in games that have no upscaler DLL."""
    targets = fsr_targets(scan)
    if not targets:
        raise InstallError("Game không có FSR 3.1 (amd_fidelityfx_*_dx12.dll).")
    return targets


def _install_optiscaler_files(m: Manifest, scan: GameScan, optiscaler_dir: str,
                              ini_edits: dict[str, str]) -> list[str]:
    """Copy the OptiScaler payload next to the exe. Returns the relative paths it created."""
    if not os.path.isdir(optiscaler_dir):
        raise InstallError("Chưa tải OptiScaler.")
    proxy = pick_proxy_name(scan.exe_dir)
    logger.info(f"{TAG} installing OptiScaler from {optiscaler_dir} as {proxy} (ini edits: {ini_edits or 'none'})")
    main_dll = find_file(optiscaler_dir, OPTISCALER_MAIN_DLL)
    if not main_dll:
        raise InstallError("Gói OptiScaler không có OptiScaler.dll (gói tải về bị lỗi?).")
    base = os.path.dirname(main_dll)
    ini_text = ini_file.read_ini(os.path.join(base, OPTISCALER_INI))
    for key, value in ini_edits.items():
        section = ini_text.find_key_section(key) or ("Libraries" if key.startswith("FfxDx12") else "Upscalers")
        ini_text.set(section, key, value)

    created = []
    for dirpath, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d.lower() not in _PAYLOAD_SKIP_DIRS and not d.startswith(".")]
        for f in files:
            low = f.lower()
            if low.endswith(_PAYLOAD_SKIP_SUFFIX) or low.startswith(".bob") or low == OPTISCALER_INI:
                continue
            rel_dir = os.path.relpath(dirpath, base).replace("\\", "/")
            name = proxy if low == OPTISCALER_MAIN_DLL else f
            rel = _rel("" if rel_dir == "." else rel_dir, name)
            m.add_file(rel, os.path.join(dirpath, f))
            created.append(rel)
    m.add_text("OptiScaler.ini", ini_text.dumps())
    logger.info(f"{TAG} OptiScaler payload: {len(created)} files + OptiScaler.ini")
    return created


def _install_helixsr_optiscaler(m: Manifest, scan: GameScan, helixsr_dir: str, helix_dll: str) -> None:
    """HelixSR's own "o" route: OptiScaler next to the exe, its FSR 3.1 backend pointed at a HelixSR folder."""
    if not (scan.fsr31 or scan.dlss or scan.xess or scan.fsr2):
        raise InstallError("Game không có DLSS / XeSS / FSR để OptiScaler chuyển hướng.")
    amd = os.path.join(helixsr_dir, HELIXSR_AMD_DIR)
    amd_fsr, amd_fg = os.path.join(amd, "amd_fidelityfx_upscaler_dx12.dll"), os.path.join(amd, AMD_FG)
    if not (os.path.isfile(amd_fsr) and os.path.isfile(amd_fg)):
        raise InstallError("Gói HelixSR thiếu thư mục amd-fsr (bị lỗi?).")
    folder = HELIXSR_DIR_NAME
    m.make_dir(folder)
    m.add_file(_rel(folder, HELIXSR_OWN), helix_dll)
    m.add_file(_rel(folder, HELIXSR_OWN_SR), helix_dll)
    m.add_file(_rel(folder, AMD_FSR_COPY), amd_fsr)
    m.add_file(_rel(folder, AMD_FG), amd_fg)

    def ab(name: str) -> str:
        return os.path.join(scan.exe_dir, folder, name)

    _install_optiscaler_files(m, scan, os.path.join(helixsr_dir, HELIXSR_OPTISCALER_DIR), {
        "Dx12Upscaler": "fsr31",
        "FfxDx12Path": ab(HELIXSR_OWN),
        "FfxDx12SRPath": ab(HELIXSR_OWN_SR),
        "FfxDx12FGPath": ab(AMD_FG),
    })


def install(scan: GameScan, mode: str, *, optiscaler_dir: str | None = None,
            helixsr_dir: str | None = None, gpu: GpuInfo | None = None, packages: dict | None = None,
            optiscaler_upscaler: str | None = None, is_running: Callable[[str], list[str]] = running_exes) -> Manifest:
    """Install `mode` for the game, replacing whatever Bob installed there before.

    Raises InstallError only (every other failure is logged, rolled back and reported as one). Thread-safe per game.
    """
    exe_dir = scan.exe_dir
    with folder_lock(exe_dir):
        started = time.monotonic()
        logger.info(f"{TAG} installing {mode} into {exe_dir} (gpu={gpu.name if gpu else '?'}, packages={packages or {}})")
        try:
            m = _install_locked(scan, mode, optiscaler_dir, helixsr_dir, gpu, packages, optiscaler_upscaler, is_running)
        except InstallError as e:
            logger.warning(f"{TAG} {mode} into {exe_dir} refused / failed: {e}")
            raise
        logger.info(f"{TAG} {mode} installed into {exe_dir} in {time.monotonic() - started:.2f}s ({len(m.ops)} operations)")
        return m


def _install_locked(scan, mode, optiscaler_dir, helixsr_dir, gpu, packages, optiscaler_upscaler, is_running) -> Manifest:
    if mode not in MODES:
        raise InstallError(f"Chế độ không hợp lệ: {mode}")
    exe_dir = scan.exe_dir
    if scan.helixsr_foreign:
        raise InstallError("Game này đã được cài bằng setup của HelixSR. Hãy gỡ bằng uninstaller của HelixSR trước.")
    busy = is_running(exe_dir)
    if busy:
        raise InstallError(f"Hãy đóng game trước ({', '.join(busy)} đang chạy).")

    existing = get_status(exe_dir)
    if existing.mode or existing.pending:
        logger.info(f"{TAG} replacing the previous {existing.mode or 'interrupted install'} in {exe_dir}")
        uninstall(exe_dir, is_running)
    if scan.has_optiscaler:
        raise InstallError("Game đã có OptiScaler cài tay. Hãy gỡ nó trước để Bob quản lý.")

    m = Manifest(exe_dir, mode=mode, packages=dict(packages or {}))
    try:
        m.save()
        if mode == MODE_FSR_UPDATE:
            if not optiscaler_dir:
                raise InstallError("Chưa tải OptiScaler (nguồn DLL FSR của AMD).")
            for target in _fsr_targets(scan):
                src = find_file(optiscaler_dir, os.path.basename(target))
                if not src:
                    raise InstallError(f"Gói OptiScaler không có {os.path.basename(target)}.")
                logger.info(f"{TAG} replacing {target} with AMD's {src}")
                m.add_file(_rel(os.path.relpath(target, exe_dir)), src)
        elif mode == MODE_OPTISCALER:
            _install_optiscaler_files(m, scan, optiscaler_dir or "",
                                      {"Dx12Upscaler": optiscaler_upscaler} if optiscaler_upscaler else {})
        elif mode in (MODE_HELIXSR_F, MODE_HELIXSR_O):
            if gpu is not None and not gpu.helixsr_supported:
                raise InstallError("HelixSR cần GPU AMD RDNA 1 trở lên.")
            if not helixsr_ready(helixsr_dir):
                raise InstallError("HelixSR chưa được build (DLL chưa chứa mạng). Hãy chạy bước Build trước.")
            helix_dll = os.path.join(helixsr_dir, HELIXSR_DLL)
            if mode == MODE_HELIXSR_F:
                for target in _fsr_targets(scan):
                    rel = _rel(os.path.relpath(target, exe_dir))
                    logger.info(f"{TAG} HelixSR replaces {target} (original kept as {rel[:-4]}.original.dll)")
                    m.add_file(rel, helix_dll, backup_rel=rel[:-4] + ".original.dll")
            else:
                _install_helixsr_optiscaler(m, scan, helixsr_dir, helix_dll)
        m.mark_applied()
        return m
    except Exception as e:   # noqa: BLE001 - whatever went wrong, the game folder must be put back and the UI told
        if not isinstance(e, InstallError):
            logger.error(f"{TAG} unexpected failure installing {mode} into {exe_dir}: {e!r}", exc_info=True)
        problems = m.rollback()
        if problems:
            logger.error(f"{TAG} rollback after failed install left problems: {problems}")
        if isinstance(e, InstallError):
            raise
        raise InstallError(f"Cài đặt thất bại, đã hoàn tác: {e}") from e
