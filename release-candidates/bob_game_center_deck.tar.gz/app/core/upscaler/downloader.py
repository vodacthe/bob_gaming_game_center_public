"""Download + verify + unpack the pinned third-party packages (OptiScaler, HelixSR).

Every package is pinned to an exact release asset and a SHA-256 (taken from the release's own digest). A mismatch
deletes the download and raises; nothing is extracted before the hash matches.

Thread-safe: `install_package` takes a per-package lock, so two threads asking for the same package download it once.
Every failure surfaces as `DownloadError` (never a bare OSError / requests error), and each step is logged.
"""

from __future__ import annotations

import hashlib
import logging
import os
import shutil
import threading
import time
import zipfile
from dataclasses import dataclass
from typing import Callable

import requests

from app.core.upscaler.paths import UpscalerPaths, default_paths

logger = logging.getLogger(__name__)
TAG = "[Upscaler/Download]"

_TIMEOUT = (10, 60)
_CHUNK = 256 * 1024


class DownloadError(Exception):
    pass


class DownloadCancelled(DownloadError):
    pass


@dataclass(frozen=True)
class Package:
    key: str          # folder name under packages/
    version: str
    url: str
    sha256: str
    size: int
    filename: str
    label: str


OPTISCALER = Package(
    "optiscaler", "0.9.4",
    "https://github.com/optiscaler/OptiScaler/releases/download/v0.9.4/Optiscaler_0.9.4-final.20260718._MM.7z",
    "575cb4df866116093df75af607e37fd70e10f5163e0f23fd5c804142e80ef0ad", 55016448,
    "Optiscaler_0.9.4-final.20260718._MM.7z", "OptiScaler 0.9.4")
HELIXSR = Package(
    "helixsr", "1.8.1",
    "https://github.com/lonewolf0622/HelixSR/releases/download/v1.8.1/HelixSR-1.8.1.zip",
    "5b2d06db22d59aaa8c931fc06d3a8e354e65dde1bef9fce90086542f02d4a627", 56650779,
    "HelixSR-1.8.1.zip", "HelixSR 1.8.1")

PACKAGES = {p.key: p for p in (OPTISCALER, HELIXSR)}
_READY_MARK = ".bob-ready"   # written after a complete extraction; a folder without it is a crashed attempt

_locks_guard = threading.Lock()
_locks: dict[str, threading.Lock] = {}


def _package_lock(pkg: Package) -> threading.Lock:
    with _locks_guard:
        return _locks.setdefault(pkg.key, threading.Lock())


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def package_dir(pkg: Package, paths: UpscalerPaths | None = None) -> str:
    return (paths or default_paths()).package_dir(pkg.key, pkg.version)


def is_installed(pkg: Package, paths: UpscalerPaths | None = None) -> bool:
    return os.path.isfile(os.path.join(package_dir(pkg, paths), _READY_MARK))


def _remove_quietly(path: str) -> None:
    try:
        os.remove(path)
    except FileNotFoundError:
        pass
    except OSError as e:
        logger.warning(f"{TAG} could not delete {path}: {e}")


def download(pkg: Package, paths: UpscalerPaths | None = None,
             progress: Callable[[int, int], None] | None = None,
             is_cancelled: Callable[[], bool] | None = None) -> str:
    """Fetch the archive into downloads/ (reusing a previous download that still verifies). Returns its path."""
    paths = paths or default_paths()
    try:
        os.makedirs(paths.downloads, exist_ok=True)
    except OSError as e:
        logger.error(f"{TAG} cannot create {paths.downloads}: {e}")
        raise DownloadError(f"{pkg.label}: không tạo được thư mục tải về ({e})") from e
    final = os.path.join(paths.downloads, pkg.filename)
    if os.path.isfile(final):
        try:
            cached_ok = sha256_file(final) == pkg.sha256
        except OSError as e:
            logger.warning(f"{TAG} cannot read cached {final}: {e}")
            cached_ok = False
        if cached_ok:
            logger.info(f"{TAG} {pkg.label}: reusing the verified download {final}")
            return final
        logger.warning(f"{TAG} {pkg.label}: cached file failed verification, downloading again")
        _remove_quietly(final)
    part = final + ".part"
    started = time.monotonic()
    logger.info(f"{TAG} {pkg.label}: downloading {pkg.url} (~{pkg.size / 1048576:.1f} MiB)")
    try:
        h = hashlib.sha256()
        with requests.get(pkg.url, stream=True, timeout=_TIMEOUT,
                          headers={"User-Agent": "BobGamingGameCenter"}) as resp:
            resp.raise_for_status()
            total = int(resp.headers.get("Content-Length") or pkg.size)
            done, next_mark = 0, 25
            with open(part, "wb") as f:
                for chunk in resp.iter_content(chunk_size=_CHUNK):
                    if is_cancelled and is_cancelled():
                        logger.info(f"{TAG} {pkg.label}: cancelled at {done} / {total} bytes")
                        raise DownloadCancelled("cancelled")
                    f.write(chunk)
                    h.update(chunk)
                    done += len(chunk)
                    if progress:
                        progress(done, total)
                    if total and done * 100 // total >= next_mark:
                        logger.info(f"{TAG} {pkg.label}: {next_mark}% ({done / 1048576:.1f} MiB)")
                        next_mark += 25
        if h.hexdigest() != pkg.sha256:
            logger.error(f"{TAG} {pkg.label}: SHA-256 mismatch (got {h.hexdigest()}, expected {pkg.sha256})")
            raise DownloadError(f"{pkg.label}: SHA-256 mismatch (the download is corrupt or was tampered with)")
        os.replace(part, final)
        logger.info(f"{TAG} {pkg.label}: downloaded and verified in {time.monotonic() - started:.1f}s -> {final}")
        return final
    except requests.RequestException as e:
        logger.error(f"{TAG} {pkg.label}: download failed: {e}")
        raise DownloadError(f"{pkg.label}: download failed ({e})") from e
    except OSError as e:
        logger.error(f"{TAG} {pkg.label}: could not write the download: {e}")
        raise DownloadError(f"{pkg.label}: không ghi được file tải về ({e})") from e
    finally:
        if os.path.exists(part):
            _remove_quietly(part)


def _safe_target(dest: str, name: str) -> str:
    target = os.path.normpath(os.path.join(dest, name))
    root = os.path.normpath(dest)
    if target != root and not target.startswith(root + os.sep):
        logger.error(f"{TAG} refusing archive entry that escapes the destination: {name!r}")
        raise DownloadError(f"unsafe path in archive: {name!r}")
    return target


def _extract_zip(archive: str, dest: str) -> None:
    with zipfile.ZipFile(archive) as z:
        infos = z.infolist()
        for info in infos:
            _safe_target(dest, info.filename)
        logger.info(f"{TAG} unpacking {len(infos)} zip entries")
        z.extractall(dest)


def _windows_tar() -> str:
    """The platform tar executable (libarchive on Windows or system tar)."""
    from app.core.binary_finder import find_tar
    exe = find_tar()
    if not exe:
        logger.error(f"{TAG} tar binary not found")
        raise DownloadError("Hệ thống thiếu công cụ tar nên không giải nén được file .7z.")
    return exe


def _extract_7z(archive: str, dest: str) -> None:
    """Extract .7z archive using 7z or libarchive tar."""
    from app.core.binary_finder import find_7z, find_tar
    from app.utils.helpers import run_hidden

    z7 = find_7z()
    if z7:
        logger.info(f"{TAG} unpacking 7z archive with {z7}")
        res = run_hidden([z7, "x", f"-o{dest}", "-y", archive], timeout=300)
        if res.returncode != 0:
            logger.error(f"{TAG} 7z x failed ({res.returncode}): {(res.stderr or '').strip()[:300]}")
            raise DownloadError(f"7z giải nén lỗi: {(res.stderr or '').strip()[:200]}")
        return

    tar = find_tar()
    if not tar:
        logger.error(f"{TAG} Neither 7z nor tar found to extract .7z archive")
        raise DownloadError("Không tìm thấy công cụ giải nén (7z hoặc tar) trên hệ thống để giải nén file .7z.")

    listing = run_hidden([tar, "-tf", archive], timeout=120)
    if listing.returncode != 0:
        logger.error(f"{TAG} tar -tf failed ({listing.returncode}): {(listing.stderr or '').strip()[:300]}")
        raise DownloadError(f"tar không đọc được archive: {(listing.stderr or '').strip()[:200]}")
    names = [n.strip() for n in listing.stdout.splitlines() if n.strip()]
    for name in names:
        _safe_target(dest, name.rstrip("/"))
    logger.info(f"{TAG} unpacking {len(names)} 7z entries with {tar}")
    res = run_hidden([tar, "-xf", archive, "-C", dest], timeout=300)
    if res.returncode != 0:
        logger.error(f"{TAG} tar -xf failed ({res.returncode}): {(res.stderr or '').strip()[:300]}")
        raise DownloadError(f"tar giải nén lỗi: {(res.stderr or '').strip()[:200]}")


def extract(archive: str, dest: str) -> None:
    """Unpack into a fresh `dest`; refuses entries that would land outside it."""
    started = time.monotonic()
    logger.info(f"{TAG} extracting {archive} -> {dest}")
    try:
        os.makedirs(dest, exist_ok=True)
        if archive.lower().endswith(".7z"):
            _extract_7z(archive, dest)
        else:
            _extract_zip(archive, dest)
    except DownloadError:
        raise
    except Exception as e:   # noqa: BLE001 - BadZipFile, OSError, a hung tar all mean "unusable archive"
        logger.error(f"{TAG} could not unpack {os.path.basename(archive)}: {e!r}")
        raise DownloadError(f"could not unpack {os.path.basename(archive)}: {e}") from e
    logger.info(f"{TAG} extracted in {time.monotonic() - started:.1f}s")


def install_package(pkg: Package, paths: UpscalerPaths | None = None,
                    progress: Callable[[int, int], None] | None = None,
                    is_cancelled: Callable[[], bool] | None = None) -> str:
    """Download (if needed) and unpack a package; returns its folder. Idempotent and safe to call from several threads."""
    paths = paths or default_paths()
    dest = package_dir(pkg, paths)
    with _package_lock(pkg):
        if is_installed(pkg, paths):
            logger.debug(f"{TAG} {pkg.label}: already installed at {dest}")
            return dest
        logger.info(f"{TAG} {pkg.label}: installing into {dest}")
        archive = download(pkg, paths, progress, is_cancelled)
        shutil.rmtree(dest, ignore_errors=True)
        try:
            extract(archive, dest)
            with open(os.path.join(dest, _READY_MARK), "w", encoding="utf-8") as f:
                f.write(pkg.sha256)
        except Exception as e:
            logger.error(f"{TAG} {pkg.label}: install failed, removing the partial folder: {e!r}")
            shutil.rmtree(dest, ignore_errors=True)
            if isinstance(e, OSError):
                raise DownloadError(f"{pkg.label}: không cài được gói ({e})") from e
            raise
        logger.info(f"{TAG} {pkg.label}: ready at {dest}")
        return dest
