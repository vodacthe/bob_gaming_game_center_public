"""Upscaler manager: OptiScaler / FSR DLL swaps and the optional HelixSR backend, per game.

Nothing from OptiScaler or HelixSR is bundled: every package is downloaded (pinned + SHA-256 checked)
at run time. HelixSR's own setup is run as shipped and never modified.
"""
