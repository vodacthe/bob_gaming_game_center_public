"""Per-game write-ahead journal: <exe_dir>\\BobUpscaler\\manifest.json.

Every file operation is recorded BEFORE it happens (`pending`) and marked `done` afterwards, so a kill between
the two (Bob is ended with TerminateProcess on restart, a game can crash the machine, ...) leaves enough to put the
folder back exactly as it was. `rollback()` is idempotent and handles a half-finished last step.

Operations (paths are relative to the exe folder, '/'-separated):
  create   a file Bob adds (it did not exist)                -> undo: delete it
  replace  a file Bob replaces; the original is moved to
           `backup` (BobUpscaler/backup/... or X.original.dll) -> undo: delete the new file, move the original back
  mkdir    a folder Bob adds                                  -> undo: remove it when empty
"""

from __future__ import annotations

import json
import logging
import os
import shutil
from dataclasses import dataclass, field

from app.core.upscaler.paths import GAME_DIR_NAME

logger = logging.getLogger(__name__)
TAG = "[Upscaler/Journal]"

VERSION = 1
PENDING, DONE = "pending", "done"
STATE_PENDING, STATE_APPLIED = "pending", "applied"   # whole-install state


class ManifestError(Exception):
    pass


def _abs(root: str, rel: str) -> str:
    target = os.path.normpath(os.path.join(root, rel))
    if target != os.path.normpath(root) and not target.startswith(os.path.normpath(root) + os.sep):
        raise ManifestError(f"path escapes the game folder: {rel!r}")
    return target


@dataclass
class Manifest:
    root: str                               # the exe folder everything is relative to
    mode: str = ""
    packages: dict = field(default_factory=dict)   # {"optiscaler": "0.9.4", ...} what was installed from
    state: str = STATE_PENDING
    ops: list = field(default_factory=list)

    @property
    def dir(self) -> str:
        return os.path.join(self.root, GAME_DIR_NAME)

    @property
    def path(self) -> str:
        return os.path.join(self.dir, "manifest.json")

    # ---- persistence

    def save(self) -> None:
        try:
            os.makedirs(self.dir, exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"v": VERSION, "mode": self.mode, "packages": self.packages, "state": self.state,
                           "ops": self.ops}, f, indent=1, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
        except OSError as e:
            logger.error(f"{TAG} cannot write {self.path}: {e}")
            raise

    @classmethod
    def load(cls, root: str) -> "Manifest | None":
        m = cls(root)
        try:
            with open(m.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except FileNotFoundError:
            return None
        except (OSError, ValueError) as e:
            logger.warning(f"{TAG} manifest unreadable in {root}: {e}")
            raise ManifestError(f"manifest unreadable: {e}") from e
        if not isinstance(raw, dict) or raw.get("v") != VERSION or not isinstance(raw.get("ops"), list):
            logger.warning(f"{TAG} manifest in {root} has an unknown format")
            raise ManifestError("manifest has an unknown format")
        m.mode = str(raw.get("mode", ""))
        m.packages = raw.get("packages") if isinstance(raw.get("packages"), dict) else {}
        m.state = raw.get("state", STATE_PENDING)
        m.ops = [o for o in raw["ops"] if isinstance(o, dict) and o.get("op") in ("create", "replace", "mkdir")]
        return m

    # ---- journaled operations

    def _begin(self, op: dict) -> dict:
        op["state"] = PENDING
        self.ops.append(op)
        self.save()
        logger.debug(f"{TAG} {op['op']} {op.get('path')} (journaled, pending)")
        return op

    def _done(self, op: dict) -> None:
        op["state"] = DONE
        self.save()
        logger.debug(f"{TAG} {op['op']} {op.get('path')} done")

    def make_dir(self, rel: str) -> None:
        target = _abs(self.root, rel)
        if os.path.isdir(target):
            return
        op = self._begin({"op": "mkdir", "path": rel})
        os.makedirs(target, exist_ok=True)
        self._done(op)

    def add_file(self, rel: str, source: str, backup_rel: str | None = None) -> None:
        """Put `source` at `rel`. An existing file is preserved at `backup_rel` (default: BobUpscaler/backup/<rel>)."""
        target = _abs(self.root, rel)
        parent = os.path.dirname(rel)
        if parent and not os.path.isdir(os.path.dirname(target)):
            self._make_parents(parent)
        if os.path.exists(target):
            backup_rel = backup_rel or f"{GAME_DIR_NAME}/backup/{rel}"
            backup = _abs(self.root, backup_rel)
            if os.path.exists(backup):
                raise ManifestError(f"backup already exists: {backup_rel}")
            op = self._begin({"op": "replace", "path": rel, "backup": backup_rel})
            os.makedirs(os.path.dirname(backup), exist_ok=True)
            os.replace(target, backup)
        else:
            op = self._begin({"op": "create", "path": rel})
        tmp = target + ".bobtmp"
        shutil.copy2(source, tmp)
        os.replace(tmp, target)
        self._done(op)

    def add_text(self, rel: str, text: str) -> None:
        """Same as add_file for generated content (ini files)."""
        tmp_src = _abs(self.root, f"{GAME_DIR_NAME}/_staging")
        os.makedirs(os.path.dirname(tmp_src), exist_ok=True)
        with open(tmp_src, "w", encoding="utf-8", newline="") as f:
            f.write(text)
        try:
            self.add_file(rel, tmp_src)
        finally:
            try:
                os.remove(tmp_src)
            except OSError:
                pass

    def _make_parents(self, rel_dir: str) -> None:
        parts = rel_dir.replace("\\", "/").split("/")
        for i in range(1, len(parts) + 1):
            self.make_dir("/".join(parts[:i]))

    def mark_applied(self) -> None:
        self.state = STATE_APPLIED
        self.save()
        logger.info(f"{TAG} {self.root}: {self.mode} applied ({len(self.ops)} operations journaled)")

    # ---- undo

    def rollback(self) -> list[str]:
        """Undo every recorded op in reverse order and delete the BobUpscaler folder. Returns problems (empty = clean)."""
        problems: list[str] = []
        logger.info(f"{TAG} rolling back {self.mode or 'install'} in {self.root} ({len(self.ops)} operations, state={self.state})")
        for op in reversed(self.ops):
            try:
                self._undo(op)
            except (OSError, ManifestError) as e:
                logger.error(f"{TAG} cannot undo {op.get('op')} {op.get('path')}: {e}")
                problems.append(f"{op.get('path')}: {e}")
        if not problems:
            shutil.rmtree(self.dir, ignore_errors=True)
            logger.info(f"{TAG} rollback of {self.root} complete, the folder is as it was")
        else:
            self.ops = [o for o in self.ops if o.get("_failed")]
            self.save()
            logger.warning(f"{TAG} rollback of {self.root} incomplete: {problems}")
        return problems

    def _undo(self, op: dict) -> None:
        kind, rel = op["op"], op.get("path", "")
        target = _abs(self.root, rel)
        logger.debug(f"{TAG} undo {kind} {rel} (op state {op.get('state')})")
        try:
            if kind == "create":
                if os.path.isfile(target):
                    os.remove(target)
                tmp = target + ".bobtmp"
                if os.path.isfile(tmp):
                    os.remove(tmp)
            elif kind == "replace":
                backup = _abs(self.root, op["backup"])
                if os.path.exists(backup):                  # the original was moved away: put it back
                    if os.path.isfile(target):
                        os.remove(target)
                    os.replace(backup, target)
                tmp = target + ".bobtmp"
                if os.path.isfile(tmp):
                    os.remove(tmp)
            elif kind == "mkdir":
                try:
                    os.rmdir(target)
                except OSError:
                    pass                                    # not empty (the game's own files): leave it
        except OSError:
            op["_failed"] = True
            raise
