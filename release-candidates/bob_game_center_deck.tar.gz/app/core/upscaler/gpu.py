"""GPU discovery (DXGI via ctypes, WMI fallback) and the vendor / generation classification the Upscaler needs.

HelixSR needs wave32, i.e. AMD RDNA 1 or newer. Vega, Polaris and older AMD parts are reported as unsupported.
"""

from __future__ import annotations

import ctypes
import json
import logging
import re
import sys
from ctypes import wintypes
from dataclasses import dataclass

logger = logging.getLogger(__name__)
TAG = "[Upscaler/GPU]"

VENDOR_AMD, VENDOR_NVIDIA, VENDOR_INTEL = 0x1002, 0x10DE, 0x8086
VENDOR_MICROSOFT = 0x1414   # "Microsoft Basic Render Driver" (WARP)

GEN_RDNA = "rdna"        # RDNA 1+, has wave32
GEN_LEGACY = "legacy"    # Vega / Polaris / GCN: no wave32
GEN_UNKNOWN = "unknown"


@dataclass(frozen=True)
class GpuInfo:
    name: str
    vendor_id: int
    device_id: int = 0
    vram_mb: int = 0

    @property
    def vendor(self) -> str:
        return {VENDOR_AMD: "AMD", VENDOR_NVIDIA: "NVIDIA", VENDOR_INTEL: "Intel"}.get(self.vendor_id, "Other")

    @property
    def is_software(self) -> bool:
        return self.vendor_id == VENDOR_MICROSOFT or "basic render" in self.name.lower()

    @property
    def amd_generation(self) -> str:
        return classify_amd(self.name) if self.vendor_id == VENDOR_AMD else GEN_UNKNOWN

    @property
    def helixsr_supported(self) -> bool:
        return self.amd_generation == GEN_RDNA


def classify_amd(name: str) -> str:
    """RDNA 1+ (wave32) vs older / unknown, from the marketing name (device IDs are too numerous to list)."""
    n = name.lower()
    if "bc-250" in n or "bc250" in n:
        return GEN_RDNA                      # gfx1013, the card HelixSR was developed on
    if "vega" in n or "radeon vii" in n:
        return GEN_LEGACY
    m = re.search(r"\b(?:rx|pro w|pro v)\s*(\d{3,4})\b", n)
    if m:
        return GEN_RDNA if int(m.group(1)) >= 5000 else GEN_LEGACY   # RX 4xx/5xx = Polaris
    # RDNA iGPUs carry the CU-count name: Radeon 680M / 760M / 780M / 890M / 8060S
    if re.search(r"radeon.*\b(?:\d{3}m|80\d0s)\b", n):
        return GEN_RDNA
    return GEN_UNKNOWN                       # plain "Radeon(TM) Graphics" could be Vega or RDNA2


# ---------------------------------------------------------------- DXGI

class _LUID(ctypes.Structure):
    _fields_ = [("LowPart", wintypes.DWORD), ("HighPart", wintypes.LONG)]


class _AdapterDesc1(ctypes.Structure):
    _fields_ = [
        ("Description", wintypes.WCHAR * 128),
        ("VendorId", wintypes.UINT), ("DeviceId", wintypes.UINT),
        ("SubSysId", wintypes.UINT), ("Revision", wintypes.UINT),
        ("DedicatedVideoMemory", ctypes.c_size_t), ("DedicatedSystemMemory", ctypes.c_size_t),
        ("SharedSystemMemory", ctypes.c_size_t),
        ("AdapterLuid", _LUID), ("Flags", wintypes.UINT),
    ]


class _GUID(ctypes.Structure):
    _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD), ("Data3", wintypes.WORD),
                ("Data4", ctypes.c_ubyte * 8)]


_IID_FACTORY1 = _GUID(0x770AAE78, 0xF26F, 0x4DBA, (ctypes.c_ubyte * 8)(0xA8, 0x29, 0x25, 0x3C, 0x83, 0xD1, 0xB3, 0x87))
_DXGI_ERROR_NOT_FOUND = 0x887A0002
_DXGI_ADAPTER_FLAG_SOFTWARE = 2


def _vcall(obj: ctypes.c_void_p, index: int, restype, *argtypes):
    """Call COM method `index` of the interface pointer `obj` (first arg is `this`)."""
    vtbl = ctypes.cast(ctypes.cast(obj, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
    return ctypes.WINFUNCTYPE(restype, ctypes.c_void_p, *argtypes)(vtbl[index])


def _dxgi_adapters() -> list[GpuInfo]:
    dxgi = ctypes.WinDLL("dxgi")
    factory = ctypes.c_void_p()
    hr = dxgi.CreateDXGIFactory1(ctypes.byref(_IID_FACTORY1), ctypes.byref(factory))
    if hr != 0 or not factory:
        raise OSError(f"CreateDXGIFactory1 failed: 0x{hr & 0xFFFFFFFF:08X}")
    out: list[GpuInfo] = []
    try:
        i = 0
        while True:
            adapter = ctypes.c_void_p()
            hr = _vcall(factory, 12, ctypes.c_long, wintypes.UINT, ctypes.POINTER(ctypes.c_void_p))(
                factory, i, ctypes.byref(adapter))
            if (hr & 0xFFFFFFFF) == _DXGI_ERROR_NOT_FOUND or hr != 0:
                break
            try:
                desc = _AdapterDesc1()
                if _vcall(adapter, 10, ctypes.c_long, ctypes.POINTER(_AdapterDesc1))(adapter, ctypes.byref(desc)) == 0 \
                        and not desc.Flags & _DXGI_ADAPTER_FLAG_SOFTWARE:
                    out.append(GpuInfo(desc.Description.strip(), int(desc.VendorId), int(desc.DeviceId),
                                       int(desc.DedicatedVideoMemory) // (1024 * 1024)))
            finally:
                _vcall(adapter, 2, ctypes.c_ulong)(adapter)
            i += 1
    finally:
        _vcall(factory, 2, ctypes.c_ulong)(factory)
    return out


# ---------------------------------------------------------------- WMI fallback

_PS = ("Get-CimInstance Win32_VideoController | Select-Object Name,PNPDeviceID,AdapterRAM | "
       "ConvertTo-Json -Compress")


def parse_wmi_json(text: str) -> list[GpuInfo]:
    try:
        data = json.loads(text)
    except ValueError:
        return []
    if isinstance(data, dict):
        data = [data]
    out = []
    for row in data if isinstance(data, list) else []:
        if not isinstance(row, dict) or not row.get("Name"):
            continue
        pnp = str(row.get("PNPDeviceID") or "")
        ven = re.search(r"VEN_([0-9A-F]{4})", pnp, re.I)
        dev = re.search(r"DEV_([0-9A-F]{4})", pnp, re.I)
        ram = row.get("AdapterRAM")
        out.append(GpuInfo(str(row["Name"]).strip(), int(ven.group(1), 16) if ven else 0,
                           int(dev.group(1), 16) if dev else 0,
                           int(ram) // (1024 * 1024) if isinstance(ram, int) and ram > 0 else 0))
    return out


def _wmi_adapters() -> list[GpuInfo]:
    from app.utils.helpers import run_hidden
    res = run_hidden(["powershell", "-NoProfile", "-NonInteractive", "-Command", _PS], timeout=20)
    if res.returncode != 0:
        logger.warning(f"{TAG} WMI query exited with {res.returncode}: {(res.stderr or '').strip()[:200]}")
    return parse_wmi_json(res.stdout or "")


def list_gpus() -> list[GpuInfo]:
    """Hardware adapters, discrete first (most dedicated memory). Empty if nothing could be read."""
    gpus: list[GpuInfo] = []
    if sys.platform == "win32":
        try:
            gpus = _dxgi_adapters()
        except Exception as e:   # noqa: BLE001 - any COM / loader failure falls back to WMI
            logger.warning(f"{TAG} DXGI adapter listing failed ({e!r}); trying WMI")
        if not gpus:
            try:
                gpus = _wmi_adapters()
                logger.info(f"{TAG} adapters from WMI: {[g.name for g in gpus]}")
            except Exception as e:   # noqa: BLE001
                logger.warning(f"{TAG} WMI adapter listing failed: {e!r}")
    unique: dict[tuple, GpuInfo] = {}   # virtual displays (Parsec, ...) re-expose the same GPU as extra adapters
    for g in gpus:
        if not g.is_software:
            unique.setdefault((g.vendor_id, g.device_id, g.name), g)
    result = sorted(unique.values(), key=lambda g: g.vram_mb, reverse=True)
    for g in result:
        logger.info(f"{TAG} adapter: {g.name} (vendor {g.vendor}, device 0x{g.device_id:04X}, {g.vram_mb} MiB, "
                    f"generation {g.amd_generation}, HelixSR {'ok' if g.helixsr_supported else 'not supported'})")
    if not result:
        logger.warning(f"{TAG} no GPU adapter could be read")
    return result


def primary_gpu() -> GpuInfo | None:
    gpus = list_gpus()
    return gpus[0] if gpus else None
