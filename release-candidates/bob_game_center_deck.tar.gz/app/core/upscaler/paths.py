"""Where the Upscaler tool keeps its data.

Heavy data (downloaded packages) goes to %LOCALAPPDATA%, never to CONFIG_DIR: that folder lives in Documents
(often OneDrive) and the DLLs HelixSR builds contain NVIDIA's network, which must not be synced anywhere.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

SETTINGS_FILENAME = "upscaler.json"
GAME_DIR_NAME = "BobUpscaler"   # per-game folder (next to the exe): manifest.json + backup/


def data_root() -> str:
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    return os.path.join(base, "BobGaming", "Upscaler")


@dataclass(frozen=True)
class UpscalerPaths:
    root: str

    @property
    def downloads(self) -> str:
        return os.path.join(self.root, "downloads")

    @property
    def packages(self) -> str:
        return os.path.join(self.root, "packages")

    def package_dir(self, name: str, version: str) -> str:
        return os.path.join(self.packages, name, version)


def default_paths() -> UpscalerPaths:
    return UpscalerPaths(data_root())


def settings_path() -> str:
    import app.config as config   # read at call time so tests can redirect CONFIG_DIR
    return os.path.join(config.CONFIG_DIR, SETTINGS_FILENAME)
