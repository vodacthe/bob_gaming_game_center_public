"""Line-based INI editing that keeps comments, blank lines, ordering and line endings.

`configparser` would drop OptiScaler.ini's comments (which document every option), so edits are surgical:
an existing `Key=value` line is rewritten in place; a missing key is appended to its section; a missing
section is appended to the file.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)
TAG = "[Upscaler/Ini]"


class IniText:
    def __init__(self, text: str = ""):
        self.eol = "\r\n" if "\r\n" in text else "\n"
        self.lines = text.splitlines()
        self.trailing_newline = text.endswith(("\n", "\r")) or not text

    @staticmethod
    def _section_name(line: str) -> str | None:
        s = line.strip()
        if s.startswith("[") and "]" in s:
            return s[1:s.index("]")].strip().lower()
        return None

    @staticmethod
    def _key_of(line: str) -> str | None:
        s = line.strip()
        if not s or s[0] in ";#[" or "=" not in s:
            return None
        return s.split("=", 1)[0].strip().lower()

    def _section_range(self, section: str) -> tuple[int, int] | None:
        """(first line after the header, index of the next header or len) of `section`."""
        start = None
        for i, line in enumerate(self.lines):
            name = self._section_name(line)
            if name is None:
                continue
            if start is not None:
                return start, i
            if name == section.lower():
                start = i + 1
        return (start, len(self.lines)) if start is not None else None

    def find_key_section(self, key: str) -> str | None:
        """Section (original case) that already holds `key`, so a setting lands where the shipped file keeps it."""
        current = None
        for line in self.lines:
            name = self._section_name(line)
            if name is not None:
                current = line.strip()[1:line.strip().index("]")].strip()
            elif current is not None and self._key_of(line) == key.lower():
                return current
        return None

    def get(self, section: str, key: str) -> str | None:
        rng = self._section_range(section)
        if rng is None:
            return None
        for i in range(*rng):
            if self._key_of(self.lines[i]) == key.lower():
                return self.lines[i].split("=", 1)[1].strip()
        return None

    def set(self, section: str, key: str, value) -> None:
        value = str(value)
        logger.debug(f"{TAG} set [{section}] {key}={value}")
        rng = self._section_range(section)
        if rng is None:
            if self.lines and self.lines[-1].strip():
                self.lines.append("")
            self.lines += [f"[{section}]", f"{key}={value}"]
            return
        start, end = rng
        for i in range(start, end):
            if self._key_of(self.lines[i]) == key.lower():
                name = self.lines[i].split("=", 1)[0].rstrip()
                self.lines[i] = f"{name}={value}"
                return
        insert_at = end
        while insert_at > start and not self.lines[insert_at - 1].strip():
            insert_at -= 1                      # keep the blank line(s) that separate this section from the next
        self.lines.insert(insert_at, f"{key}={value}")

    def dumps(self) -> str:
        text = self.eol.join(self.lines)
        return text + self.eol if self.trailing_newline and self.lines else text


def read_ini(path: str) -> IniText:
    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            return IniText(f.read())
    except FileNotFoundError:
        logger.debug(f"{TAG} {path} does not exist yet; starting from an empty file")
        return IniText("")
    except OSError as e:
        logger.error(f"{TAG} cannot read {path}: {e}")
        raise
