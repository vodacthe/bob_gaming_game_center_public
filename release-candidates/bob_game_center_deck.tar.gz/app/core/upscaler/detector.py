"""Inspect a game folder: which upscaler DLLs it ships, where its exe lives, and what would conflict with a mod."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field

from app.core.upscaler.paths import GAME_DIR_NAME

logger = logging.getLogger(__name__)
TAG = "[Upscaler/Scan]"

MAX_DEPTH = 5
_SKIP_DIRS = {"_commonredist", "redist", "directx", "vcredist", "__pycache__", GAME_DIR_NAME.lower()}

FSR31_DLLS = ("amd_fidelityfx_upscaler_dx12.dll", "amd_fidelityfx_dx12.dll")
FSR2_DLLS = ("ffx_fsr2_api_dx12_x64.dll", "ffx_fsr2_api_x64.dll")
DLSS_DLLS = ("nvngx_dlss.dll",)
XESS_DLLS = ("libxess.dll", "libxess_dx11.dll")
# proxy DLL names OptiScaler can load under, in preference order (matches OptiScaler's own list)
PROXY_NAMES = ("dxgi.dll", "winmm.dll", "version.dll", "dbghelp.dll", "wininet.dll", "winhttp.dll")


@dataclass
class GameScan:
    folder: str
    exe_dir: str = ""                                     # folder to install into (where the main exe lives)
    fsr31: list = field(default_factory=list)             # absolute paths
    fsr2: list = field(default_factory=list)
    dlss: list = field(default_factory=list)
    xess: list = field(default_factory=list)
    foreign_proxies: list = field(default_factory=list)   # proxy DLLs next to the exe that are not ours (ReShade, ...)
    has_optiscaler: bool = False                          # OptiScaler.ini next to the exe that Bob did not install
    helixsr_foreign: bool = False                         # installed by HelixSR's own setup (no Bob manifest)
    original_dlls: list = field(default_factory=list)     # *.original.dll backups left by someone else

    @property
    def technologies(self) -> list[str]:
        out = []
        if self.fsr31:
            out.append("FSR 3.1")
        if self.fsr2:
            out.append("FSR 2")
        if self.dlss:
            out.append("DLSS")
        if self.xess:
            out.append("XeSS")
        return out


def fsr_targets(scan: "GameScan") -> list[str]:
    """FSR 3.1 DLL(s) a replacement should hit: the upscaler DLL(s), or amd_fidelityfx_dx12.dll when there is none."""
    upscalers = [p for p in scan.fsr31 if os.path.basename(p).lower() == FSR31_DLLS[0]]
    return upscalers or list(scan.fsr31)


def _walk(folder: str):
    base_depth = folder.rstrip("\\/").count(os.sep)
    for dirpath, dirnames, filenames in os.walk(folder):
        if dirpath.count(os.sep) - base_depth >= MAX_DEPTH:
            dirnames[:] = []
        else:
            dirnames[:] = [d for d in dirnames if d.lower() not in _SKIP_DIRS]
        yield dirpath, filenames


def _looks_like_game_exe(name: str) -> bool:
    low = name.lower()
    return low.endswith(".exe") and not any(
        s in low for s in ("unins", "crashhandler", "crashreport", "launcher", "setup", "redist", "vc_", "dxsetup", "easyanticheat", "eac")
    )


def scan_game(folder: str) -> GameScan:
    scan = GameScan(folder=os.path.normpath(folder))
    best_exe: tuple[int, str] | None = None     # (size, dir): the biggest exe is nearly always the game
    for dirpath, filenames in _walk(folder):
        lower = {f.lower(): f for f in filenames}
        for name in lower:
            full = os.path.join(dirpath, lower[name])
            if name in FSR31_DLLS:
                scan.fsr31.append(full)
            elif name in FSR2_DLLS:
                scan.fsr2.append(full)
            elif name in DLSS_DLLS:
                scan.dlss.append(full)
            elif name in XESS_DLLS:
                scan.xess.append(full)
            elif name.endswith(".original.dll"):
                scan.original_dlls.append(full)
        for name in lower:
            if _looks_like_game_exe(name):
                try:
                    size = os.path.getsize(os.path.join(dirpath, lower[name]))
                except OSError:
                    continue
                if best_exe is None or size > best_exe[0]:
                    best_exe = (size, dirpath)
    scan.exe_dir = best_exe[1] if best_exe else scan.folder

    try:
        in_exe_dir = {f.lower() for f in os.listdir(scan.exe_dir)}
        subdirs = {d.lower() for d in in_exe_dir if os.path.isdir(os.path.join(scan.exe_dir, d))}
    except OSError:
        in_exe_dir, subdirs = set(), set()
    has_manifest = os.path.isfile(os.path.join(scan.exe_dir, GAME_DIR_NAME, "manifest.json"))
    scan.has_optiscaler = "optiscaler.ini" in in_exe_dir and not has_manifest   # ours is tracked via the manifest
    scan.helixsr_foreign = (not has_manifest) and ("helixsr" in subdirs or "helixsr.ini" in in_exe_dir)
    if not has_manifest and any(os.path.isfile(os.path.join(os.path.dirname(p), "helixsr-install.json")) for p in scan.fsr31):
        scan.helixsr_foreign = True               # HelixSR's own "FSR DLL" route leaves this marker beside the DLL
    if not has_manifest:
        scan.foreign_proxies = [n for n in PROXY_NAMES if n in in_exe_dir and not (n == "dxgi.dll" and scan.has_optiscaler)]
    logger.debug(f"{TAG} {scan.folder}: exe dir {scan.exe_dir}, technologies {scan.technologies or 'none'}, "
                 f"optiscaler(manual)={scan.has_optiscaler}, helixsr(own setup)={scan.helixsr_foreign}, "
                 f"foreign proxies={scan.foreign_proxies or 'none'}")
    if scan.helixsr_foreign or scan.has_optiscaler or scan.foreign_proxies:
        logger.info(f"{TAG} {scan.folder}: already modded ({'HelixSR setup' if scan.helixsr_foreign else ''}"
                    f"{' OptiScaler' if scan.has_optiscaler else ''}{' ' + ','.join(scan.foreign_proxies) if scan.foreign_proxies else ''})")
    return scan
