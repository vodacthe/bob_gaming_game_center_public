"""HelixSR backend: package layout, build state, running its official setup / uninstaller, and `helixsr.ini`.

HelixSR's source is not published and its licence forbids copying or modifying the setup scripts, so Bob only RUNS the
official scripts unmodified (in their own console, where the user agrees to NVIDIA's DLL download) and then uses the
files they leave in the package. `helixsr.ini` is the one thing the licence explicitly lets users change.

The zip unpacks into a single `HelixSR-<version>\\` folder, so every function here takes that *root* (`resolve_root`).
"""

from __future__ import annotations

import logging
import os
import re
import subprocess
import sys

from app.core.upscaler import ini_file
from app.core.upscaler.installer import HELIXSR_DIR_NAME, MODE_HELIXSR_F, MODE_HELIXSR_O, InstallError, helixsr_ready
from app.core.upscaler.manifest import Manifest, ManifestError

logger = logging.getLogger(__name__)
TAG = "[Upscaler/HelixSR]"

STATE_MISSING, STATE_DOWNLOADED, STATE_BUILT = "missing", "downloaded", "built"
SETUP_BAT, UNINSTALL_BAT = "helixsr-setup.bat", "helixsr-uninstall.bat"
SHARPENERS = ("off", "nvidia", "rcas")
SECTION = "Sharpening"
LOG_NAMES = ("helixsr.log", "OptiScaler.log", "helixsr_loader.log")
_UNSAFE_ARG = re.compile(r'["&|<>^%!]')   # a .bat is started through cmd.exe: keep such characters out of its arguments


def resolve_root(package_dir: str | None) -> str | None:
    """The folder that holds helixsr-setup.bat: the package dir itself or its single `HelixSR-x.y.z` subfolder."""
    if not package_dir or not os.path.isdir(package_dir):
        return None
    if os.path.isfile(os.path.join(package_dir, SETUP_BAT)):
        return package_dir
    try:
        for name in sorted(os.listdir(package_dir)):
            sub = os.path.join(package_dir, name)
            if os.path.isfile(os.path.join(sub, SETUP_BAT)):
                return sub
    except OSError:
        pass
    return None


def build_state(package_dir: str | None) -> str:
    root = resolve_root(package_dir)
    if root is None:
        return STATE_MISSING
    return STATE_BUILT if helixsr_ready(root) else STATE_DOWNLOADED


def _check_arg(value: str, what: str) -> None:
    if _UNSAFE_ARG.search(value):
        logger.warning(f"{TAG} refusing {what} with shell metacharacters: {value!r}")
        raise InstallError(f"{what} chứa ký tự không hợp lệ cho script .bat: {value}")


def setup_command(root: str, dlss_path: str = "") -> list[str]:
    """The official Windows setup: `helixsr-setup.bat [-Dlss <nvngx_dlss.dll>]` (PowerShell-style switches)."""
    cmd = [os.path.join(root, SETUP_BAT)]
    if dlss_path:
        _check_arg(dlss_path, "Đường dẫn DLSS")
        cmd += ["-Dlss", dlss_path]
    return cmd


def uninstall_command(root: str, game_folder: str) -> list[str]:
    _check_arg(game_folder, "Đường dẫn game")
    return [os.path.join(root, UNINSTALL_BAT), game_folder]


def _run_in_console(cmd: list[str], cwd: str) -> subprocess.Popen:
    flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0) if sys.platform == "win32" else 0
    try:
        proc = subprocess.Popen(cmd, cwd=cwd, creationflags=flags)
    except (OSError, ValueError) as e:
        logger.error(f"{TAG} could not start {cmd} in {cwd}: {e!r}")
        raise InstallError(f"Không chạy được script của HelixSR: {e}") from e
    logger.info(f"{TAG} started {cmd} in its own console (pid {proc.pid}, cwd {cwd})")
    return proc


def start_build(package_dir: str | None, dlss_path: str = "") -> subprocess.Popen:
    """Start the official setup in its own console. `build_state` turns BUILT once the network is in the DLL."""
    root = resolve_root(package_dir)
    if root is None:
        logger.warning(f"{TAG} build requested but the HelixSR package is not downloaded")
        raise InstallError("Chưa tải HelixSR.")
    if dlss_path and not os.path.isfile(dlss_path):
        logger.warning(f"{TAG} the chosen DLSS DLL does not exist: {dlss_path}")
        raise InstallError("Không thấy file nvngx_dlss.dll đã chọn.")
    logger.info(f"{TAG} starting the official setup in {root} (DLSS DLL: {dlss_path or 'the setup downloads it'})")
    return _run_in_console(setup_command(root, dlss_path), root)


def stop_process_tree(proc: subprocess.Popen) -> None:
    """End the setup console once the network is built.

    After the build the setup asks, game by game, whether to install (Enter = yes). Bob installs per game itself, so
    nothing after the build is wanted; nothing has been installed at that point, so stopping here is clean.
    """
    from app.utils.helpers import run_hidden
    try:
        if sys.platform == "win32":
            res = run_hidden(["taskkill", "/PID", str(proc.pid), "/T", "/F"], timeout=15)
            logger.info(f"{TAG} ended the setup console (pid {proc.pid}, taskkill exit {res.returncode})")
        else:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
            logger.info(f"{TAG} ended the setup console (pid {proc.pid})")
    except (OSError, subprocess.SubprocessError) as e:
        logger.warning(f"{TAG} could not end the setup console (pid {proc.pid}): {e!r}")


def start_official_uninstall(package_dir: str | None, game_folder: str) -> subprocess.Popen:
    """Remove an install made by HelixSR's own setup, using HelixSR's own uninstaller."""
    root = resolve_root(package_dir)
    if root is None or not os.path.isfile(os.path.join(root, UNINSTALL_BAT)):
        logger.warning(f"{TAG} official uninstaller not found (package root: {root})")
        raise InstallError("Không thấy helixsr-uninstall.bat trong gói HelixSR.")
    logger.info(f"{TAG} running HelixSR's own uninstaller for {game_folder}")
    return _run_in_console(uninstall_command(root, game_folder), root)


def find_dlss_dll(game_folders: list[str]) -> str | None:
    """A game's nvngx_dlss.dll the user may hand to the setup (`-Dlss`); the setup itself checks the version."""
    from app.core.upscaler.detector import scan_game
    for folder in game_folders:
        scan = scan_game(folder)
        if scan.dlss:
            logger.info(f"{TAG} found a DLSS DLL the setup can use: {scan.dlss[0]}")
            return scan.dlss[0]
    return None


# ---------------------------------------------------------------- helixsr.ini

def _ini_targets(m: Manifest) -> list[str]:
    if m.mode == MODE_HELIXSR_O:
        return [f"{HELIXSR_DIR_NAME}/helixsr.ini"]
    if m.mode == MODE_HELIXSR_F:
        dirs = {os.path.dirname(o["path"]) for o in m.ops
                if o.get("op") in ("create", "replace") and os.path.basename(o["path"]).lower().startswith("amd_fidelityfx")
                and not o["path"].lower().endswith(".original.dll")}
        return sorted(f"{d}/helixsr.ini" if d else "helixsr.ini" for d in dirs)
    return []


def _load_helix_manifest(exe_dir: str) -> Manifest:
    try:
        m = Manifest.load(exe_dir)
    except ManifestError as e:
        raise InstallError(str(e)) from e
    if m is None or m.mode not in (MODE_HELIXSR_F, MODE_HELIXSR_O):
        raise InstallError("Game chưa cài HelixSR bằng Bob.")
    return m


def get_sharpening(exe_dir: str) -> dict:
    """{'sharpener': 'off'|'nvidia'|'rcas', 'sharpness': float, 'use_game_slider': bool} (defaults if no ini yet)."""
    out = {"sharpener": "off", "sharpness": 0.5, "use_game_slider": False}
    try:
        m = _load_helix_manifest(exe_dir)
    except InstallError:
        return out
    for rel in _ini_targets(m):
        ini = ini_file.read_ini(os.path.join(exe_dir, rel))
        s = (ini.get(SECTION, "Sharpener") or "").lower()
        if s in SHARPENERS:
            out["sharpener"] = s
        try:
            out["sharpness"] = min(max(float(ini.get(SECTION, "Sharpness") or out["sharpness"]), 0.0), 1.0)
        except ValueError:
            pass
        out["use_game_slider"] = (ini.get(SECTION, "UseGameSlider") or "").lower() == "true"
        break
    return out


def set_sharpening(exe_dir: str, sharpener: str, sharpness: float, use_game_slider: bool = False) -> None:
    if sharpener not in SHARPENERS:
        raise InstallError(f"Sharpener không hợp lệ: {sharpener}")
    m = _load_helix_manifest(exe_dir)
    value = f"{min(max(float(sharpness), 0.0), 1.0):.2f}"
    logger.info(f"{TAG} sharpening for {exe_dir}: {sharpener} {value} (use game slider: {use_game_slider})")
    for rel in _ini_targets(m):
        path = os.path.join(exe_dir, rel)
        ini = ini_file.read_ini(path)
        ini.set(SECTION, "Sharpener", sharpener)
        ini.set(SECTION, "Sharpness", value)
        ini.set(SECTION, "UseGameSlider", "true" if use_game_slider else "false")
        text = ini.dumps()
        if any(o.get("path") == rel for o in m.ops):      # already journaled: just rewrite it
            tmp = path + ".bobtmp"
            with open(tmp, "w", encoding="utf-8", newline="") as f:
                f.write(text)
            os.replace(tmp, path)
        else:
            m.add_text(rel, text)


def existing_logs(exe_dir: str) -> list[str]:
    found = []
    for base in (exe_dir, os.path.join(exe_dir, HELIXSR_DIR_NAME)):
        for name in LOG_NAMES:
            p = os.path.join(base, name)
            if os.path.isfile(p):
                found.append(p)
    return found

