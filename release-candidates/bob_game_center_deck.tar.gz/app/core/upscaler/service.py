"""Glue between the UI and the core modules: game list, the modes each game offers, apply / remove."""

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field

from app.core.upscaler import detector, downloader, helixsr, installer, platforms
from app.core.upscaler.gpu import GpuInfo
from app.core.upscaler.installer import InstallError, InstallStatus
from app.core.upscaler.paths import UpscalerPaths, default_paths
from app.core.upscaler.settings import UpscalerSettings

logger = logging.getLogger(__name__)
TAG = "[Upscaler/Service]"

MODE_LABELS = {
    installer.MODE_FSR_UPDATE: "Cập nhật FSR (DLL mới của AMD)",
    installer.MODE_OPTISCALER: "OptiScaler",
    installer.MODE_HELIXSR_F: "HelixSR — thay DLL FSR 3.1",
    installer.MODE_HELIXSR_O: "HelixSR qua OptiScaler",
}


@dataclass
class GameEntry:
    name: str
    folder: str
    source: str                                   # "library" (Bob's Library) | "steam" (Steam scan) | "manual" (added here)
    platform: str = platforms.OTHER               # platforms.* key
    scan: detector.GameScan = None
    status: InstallStatus = field(default_factory=InstallStatus)

    @property
    def exe_dir(self) -> str:
        return self.scan.exe_dir

    @property
    def technologies(self) -> list[str]:
        return self.scan.technologies

    @property
    def foreign_note(self) -> str:
        if self.scan.helixsr_foreign:
            return "Cài bằng setup HelixSR"
        if self.scan.has_optiscaler:
            return "OptiScaler cài tay"
        return ""


def _inspect(name: str, folder: str, source: str, platform: str | None = None) -> GameEntry:
    scan = detector.scan_game(folder)
    platform = platform or platforms.platform_of({"install_location": folder})
    return GameEntry(name, folder, source, platform, scan, installer.get_status(scan.exe_dir))


def game_folder(game: dict) -> str | None:
    """Install folder of a Library game dict (install_location, else the folder of its exe), if it exists on disk."""
    loc = str(game.get("install_location") or "").strip().strip('"')
    if loc and os.path.isdir(loc):
        return os.path.normpath(loc)
    exe = str(game.get("exe_path") or "").strip().strip('"')
    if exe and os.path.isdir(os.path.dirname(exe)):
        return os.path.normpath(os.path.dirname(exe))
    return None


def list_games(library_games: list[dict], settings: UpscalerSettings, steam_games: list[dict] = ()) -> list[GameEntry]:
    """Bob's Library games (their saved install paths), the games of the Steam libraries, and folders added here by
    hand, de-duplicated by folder (the Library's entry wins). Interrupted installs are rolled back first.

    One unreadable game folder is logged and skipped; it never fails the whole list.
    """
    started = time.monotonic()
    entries: list[GameEntry] = []
    seen: set[str] = set()
    skipped = 0

    def add(name: str, folder: str, source: str, platform: str) -> None:
        nonlocal skipped
        key = os.path.normcase(folder)
        if not name or key in seen:
            return
        seen.add(key)
        try:
            entries.append(_inspect(str(name), folder, source, platform))
        except Exception as e:   # noqa: BLE001 - a permission / path problem in one game must not hide the others
            skipped += 1
            logger.warning(f"{TAG} skipping {name!r} ({folder}): {e!r}")

    for g in sorted(library_games, key=lambda g: str(g.get("name", "")).lower()):
        folder = game_folder(g)
        if folder:
            add(g.get("name"), folder, "library", platforms.platform_of(g))
    for g in sorted(steam_games, key=lambda g: str(g.get("name", "")).lower()):
        folder = game_folder(g)
        if folder:
            add(g.get("name"), folder, "steam", platforms.STEAM)
    for folder in settings.extra_games:
        if os.path.isdir(folder):
            folder = os.path.normpath(folder)
            add(os.path.basename(folder) or folder, folder, "manual", platforms.platform_of({"install_location": folder}))
        else:
            logger.warning(f"{TAG} folder added by hand no longer exists: {folder}")
    recovered = 0
    for e in entries:
        if e.status.pending and installer.recover(e.exe_dir):
            e.status = installer.get_status(e.exe_dir)
            recovered += 1
    by_source = {s: sum(1 for e in entries if e.source == s) for s in ("library", "steam", "manual")}
    logger.info(f"{TAG} {len(entries)} games listed in {time.monotonic() - started:.2f}s "
                f"(library {by_source['library']}, steam {by_source['steam']}, added by hand {by_source['manual']}; "
                f"{sum(1 for e in entries if e.status.mode)} with an upscaler installed, {recovered} recovered, {skipped} skipped)")
    return entries


def current_label(entry: GameEntry) -> str:
    if entry.foreign_note:
        return entry.foreign_note
    if entry.status.pending:
        return "Đang chờ hoàn tác"
    return MODE_LABELS.get(entry.status.mode, "—") if entry.status.mode else "Chưa cài"


def platform_counts(entries: list[GameEntry]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for e in entries:
        counts[e.platform] = counts.get(e.platform, 0) + 1
    return counts


def filter_entries(entries: list[GameEntry], platform: str | None = None, query: str = "") -> list[GameEntry]:
    """Entries of one platform (None = all) whose name contains `query` (case / accent insensitive)."""
    needle = platforms.search_key(query)
    return [e for e in entries
            if (not platform or e.platform == platform) and (not needle or needle in platforms.search_key(e.name))]


SORT_COLUMNS = ("name", "platform", "tech", "current", "mode")


def sort_entries(entries: list[GameEntry], column: str, descending: bool = False, mode_label=None) -> list[GameEntry]:
    """Stable sort by a table column; ties fall back to the name. Empty values always go last."""
    def name_key(e: GameEntry):
        return platforms.search_key(e.name)

    def key(e: GameEntry):
        if column == "platform":
            return (platforms.platform_rank(e.platform), name_key(e))
        if column == "tech":
            text = ", ".join(e.technologies)
            return (not text, text.casefold(), name_key(e))
        if column == "current":
            return (current_label(e).casefold(), name_key(e))
        if column == "mode" and mode_label is not None:
            text = mode_label(e) or ""
            return (not text, text.casefold(), name_key(e))
        return (name_key(e),)

    ordered = sorted(entries, key=key)
    if not descending:
        return ordered
    # descending, but empty technology / mode values stay at the bottom
    if column in ("tech", "mode"):
        empties = [e for e in ordered if key(e)[0] is True]
        return list(reversed([e for e in ordered if key(e)[0] is False])) + empties
    return list(reversed(ordered))


def component_states(paths: UpscalerPaths | None = None) -> dict[str, str]:
    """{package key: 'missing' | 'downloaded' | 'built' (HelixSR only)}"""
    paths = paths or default_paths()
    out = {}
    for key, pkg in downloader.PACKAGES.items():
        if not downloader.is_installed(pkg, paths):
            out[key] = helixsr.STATE_MISSING
        elif key == "helixsr":
            out[key] = helixsr.build_state(downloader.package_dir(pkg, paths))
        else:
            out[key] = helixsr.STATE_DOWNLOADED
    return out


def available_modes(entry: GameEntry, gpu: GpuInfo | None, states: dict[str, str]) -> list[tuple[str, str, str]]:
    """[(mode, label, disabled_reason)] — an empty reason means usable now. Unusable modes are listed with why."""
    if entry.scan.helixsr_foreign or entry.scan.has_optiscaler:
        return []
    out = []

    def add(mode: str, reason: str = "") -> None:
        out.append((mode, MODE_LABELS[mode], reason))

    has_opti = states.get("optiscaler") != helixsr.STATE_MISSING
    helix_ok = bool(gpu and gpu.helixsr_supported)
    helix_built = states.get("helixsr") == helixsr.STATE_BUILT

    add(installer.MODE_FSR_UPDATE,
        "Game không có FSR 3.1" if not entry.scan.fsr31 else "" if has_opti else "Chưa tải OptiScaler")
    add(installer.MODE_OPTISCALER, "" if has_opti else "Chưa tải OptiScaler")

    def helix_reason(extra: str = "") -> str:
        if not helix_ok:
            return "Cần GPU AMD RDNA 1 trở lên"
        if not helix_built:
            return "HelixSR chưa được build"
        return extra

    add(installer.MODE_HELIXSR_F, helix_reason("Game không có FSR 3.1" if not entry.scan.fsr31 else ""))
    no_target = not (entry.scan.fsr31 or entry.scan.dlss or entry.scan.xess or entry.scan.fsr2)
    add(installer.MODE_HELIXSR_O, helix_reason("Game không có DLSS / XeSS / FSR" if no_target else ""))
    return out


def apply_mode(entry: GameEntry, mode: str, gpu: GpuInfo | None, paths: UpscalerPaths | None = None,
               optiscaler_upscaler: str | None = None) -> None:
    started = time.monotonic()
    logger.info(f"{TAG} apply {mode} to {entry.name!r} ({entry.folder}) on {threading.current_thread().name}")
    paths = paths or default_paths()
    dirs, versions = {}, {}
    for key, pkg in downloader.PACKAGES.items():
        if downloader.is_installed(pkg, paths):
            dirs[key], versions[key] = downloader.package_dir(pkg, paths), pkg.version
    needs_opti = mode in (installer.MODE_FSR_UPDATE, installer.MODE_OPTISCALER)   # HelixSR ships its own OptiScaler
    needs_helix = mode in (installer.MODE_HELIXSR_F, installer.MODE_HELIXSR_O)
    try:
        if needs_opti and "optiscaler" not in dirs:
            raise InstallError("Chưa tải OptiScaler.")
        if needs_helix and helixsr.build_state(dirs.get("helixsr")) != helixsr.STATE_BUILT:
            raise InstallError("HelixSR chưa được build.")
        helix_root = helixsr.resolve_root(dirs.get("helixsr"))
        used = {k: v for k, v in versions.items() if (k == "helixsr" and needs_helix) or (k == "optiscaler" and needs_opti)}
        # re-scan: the folder may have changed since the list was built
        scan = detector.scan_game(entry.folder)
        installer.install(scan, mode, optiscaler_dir=dirs.get("optiscaler"),
                          helixsr_dir=helix_root, gpu=gpu, packages=used, optiscaler_upscaler=optiscaler_upscaler)
    except InstallError as e:
        logger.warning(f"{TAG} apply {mode} to {entry.name!r} failed: {e}")
        raise
    except Exception as e:   # noqa: BLE001 - reported to the UI as a normal error, never an uncaught thread exception
        logger.error(f"{TAG} apply {mode} to {entry.name!r} crashed: {e!r}", exc_info=True)
        raise InstallError(f"Lỗi không mong muốn khi cài: {e}") from e
    logger.info(f"{TAG} applied {mode} to {entry.name!r} in {time.monotonic() - started:.2f}s")


def remove_mode(entry: GameEntry) -> None:
    started = time.monotonic()
    logger.info(f"{TAG} remove from {entry.name!r} ({entry.folder}) on {threading.current_thread().name}")
    try:
        installer.uninstall(entry.exe_dir)
    except InstallError as e:
        logger.warning(f"{TAG} remove from {entry.name!r} failed: {e}")
        raise
    except Exception as e:   # noqa: BLE001
        logger.error(f"{TAG} remove from {entry.name!r} crashed: {e!r}", exc_info=True)
        raise InstallError(f"Lỗi không mong muốn khi gỡ: {e}") from e
    logger.info(f"{TAG} removed from {entry.name!r} in {time.monotonic() - started:.2f}s")
