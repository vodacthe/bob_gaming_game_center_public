"""Which store / launcher a game belongs to (the Upscaler groups its game list by this)."""

from __future__ import annotations

import unicodedata

STEAM, NONSTEAM, EPIC, GOG = "steam", "nonsteam", "epic", "gog"
EA, UBISOFT, BATTLENET, XBOX, ROCKSTAR, OTHER = "ea", "ubisoft", "battlenet", "xbox", "rockstar", "other"

# display order of the groups; a group with no games is not shown
PLATFORMS = (
    (STEAM, "Steam"), (NONSTEAM, "Non-Steam"), (EPIC, "Epic"), (GOG, "GOG"), (EA, "EA"), (UBISOFT, "Ubisoft"),
    (BATTLENET, "Battle.net"), (XBOX, "Xbox / Microsoft Store"), (ROCKSTAR, "Rockstar"), (OTHER, "Khác"),
)
LABELS = dict(PLATFORMS)
_ORDER = {key: i for i, (key, _label) in enumerate(PLATFORMS)}

# (platform, path fragments, publisher fragments); paths are lower-cased with backslashes
_RULES = (
    (STEAM, ("\\steamapps\\",), ()),
    (EPIC, ("\\epic games\\",), ()),
    (GOG, ("\\gog galaxy\\games\\", "\\gog games\\"), ()),
    (EA, ("\\ea games\\", "\\electronic arts\\", "\\origin games\\", "\\ea app\\"), ("electronic arts",)),
    (UBISOFT, ("\\ubisoft",), ("ubisoft",)),
    (BATTLENET, ("battle.net", "\\blizzard"), ("blizzard",)),
    (XBOX, ("\\xboxgames\\", "\\windowsapps\\", "\\modifiablewindowsapps\\"), ()),
    (ROCKSTAR, ("\\rockstar games\\",), ("rockstar",)),
)


def platform_of(game: dict) -> str:
    """Platform key of a game dict (Library / scanner format: source, install_location, exe_path, publisher)."""
    source = str(game.get("source") or "").lower()
    if source == "steam_shortcut" or game.get("is_non_steam"):
        return NONSTEAM
    direct = {"steam": STEAM, "epic": EPIC, "gog": GOG}.get(source)
    if direct:
        return direct
    where = " ".join(str(game.get(k) or "") for k in ("install_location", "exe_path")).lower().replace("/", "\\")
    publisher = str(game.get("publisher") or "").lower()
    for key, paths, publishers in _RULES:
        if any(p in where for p in paths) or any(p in publisher for p in publishers):
            return key
    return OTHER


def platform_rank(key: str) -> int:
    return _ORDER.get(key, len(_ORDER))


def search_key(text: str) -> str:
    """Case- and accent-insensitive form for the name search ("Pokémon" matches "pokemon", "đ" -> "d")."""
    text = str(text).replace("đ", "d").replace("Đ", "D")
    decomposed = unicodedata.normalize("NFKD", text)
    return "".join(c for c in decomposed if not unicodedata.combining(c)).casefold().strip()
