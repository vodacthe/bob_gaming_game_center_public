"""
Desktop integration and Steam Game Mode registration for Bob Game Center on SteamOS / Arch Linux.
Handles FreeDesktop .desktop generation, Steam shortcuts.vdf registration, duplicate prevention,
atomic fsync durability, and local artwork deployment.
"""

from __future__ import annotations

import argparse
import logging
import os
import shutil
import stat
import subprocess
import time
from typing import Optional

from app.core.steam_compat import remove_proton_compatibility
from app.core.steam_manager import (
    find_steam_path,
    get_grid_dir,
    get_steam_user_ids,
    is_steam_running,
    mark_steam_reload_needed,
)
from app.core.steam_vdf import (
    calculate_shortcut_appid,
    load_shortcuts_vdf,
    save_shortcuts_vdf,
)

TAG = "[Desktop/Integration]"
logger = logging.getLogger(__name__)

DESKTOP_ENTRY_FILENAME = "bob_game_center.desktop"
DEFAULT_APP_NAME = "Bob Game Center"
STARTUP_WM_CLASS = "Bob Gaming Game Center"
DEFAULT_GENERIC_NAME = "Game Downloader & Save Sync"
DEFAULT_COMMENT = "Game Manager and Launcher for Steam Deck & Arch Linux"
DEFAULT_CATEGORIES = "Game;Utility;"


def get_default_applications_dir() -> str:
    """Return standard XDG applications directory (~/.local/share/applications)."""
    xdg_data = os.environ.get("XDG_DATA_HOME")
    if xdg_data:
        return os.path.join(xdg_data, "applications")
    return os.path.expanduser("~/.local/share/applications")


def get_default_desktop_dir() -> str:
    """Return user's Desktop directory (~/Desktop)."""
    return os.path.expanduser("~/Desktop")


def deploy_app_icon(icon_source: str, target_root: Optional[str] = None) -> str:
    """
    Deploy app icon to standard FreeDesktop hicolor icon directory.
    Returns the path to the deployed icon or the original path.
    """
    if not icon_source or not os.path.isfile(icon_source):
        return icon_source or ""

    base_dir = target_root or os.path.expanduser("~/.local/share/icons/hicolor")
    ext = os.path.splitext(icon_source)[1].lower()

    if ext == ".svg":
        dest_dir = os.path.join(base_dir, "scalable", "apps")
    else:
        dest_dir = os.path.join(base_dir, "256x256", "apps")

    try:
        os.makedirs(dest_dir, exist_ok=True)
        dest_path = os.path.join(dest_dir, f"bob_game_center{ext}")
        shutil.copy2(icon_source, dest_path)
        return dest_path
    except Exception as exc:
        logger.warning(f"{TAG} Could not deploy icon to {dest_dir}: {exc}")
        return icon_source


def create_desktop_entry(
    app_dir: str,
    script_path: Optional[str] = None,
    icon_path: Optional[str] = None,
    target_dir: Optional[str] = None,
    app_name: str = DEFAULT_APP_NAME,
    dry_run: bool = False,
) -> dict:
    """
    Generate FreeDesktop .desktop file in target directory with atomic fsync durability.

    Returns:
        {"success": bool, "entry_path": str, "elapsed": float, "message": str}
    """
    t0 = time.perf_counter()
    logger.info(f"{TAG} Creating desktop entry for {app_name!r} (app_dir: {app_dir})")

    if not app_dir or not os.path.exists(app_dir):
        msg = f"App directory does not exist: {app_dir}"
        logger.warning(f"{TAG} Refused: {msg}")
        return {"success": False, "entry_path": "", "elapsed": 0.0, "message": msg}

    dest_dir = target_dir or get_default_applications_dir()
    clean_target_dir = os.path.abspath(os.path.expanduser(dest_dir))
    entry_path = os.path.join(clean_target_dir, DESKTOP_ENTRY_FILENAME)

    # Determine executable script
    if script_path:
        resolved_script = script_path
    else:
        deck_script = os.path.join(app_dir, "scripts", "deck", "bob_game_center.sh")
        root_script = os.path.join(app_dir, "bob_game_center.sh")
        resolved_script = deck_script if os.path.exists(deck_script) else root_script

    clean_script = os.path.abspath(os.path.expanduser(resolved_script)).replace("\\", "/")

    # Ensure executable permission on launcher script if present
    if os.path.isfile(clean_script):
        try:
            curr_mode = os.stat(clean_script).st_mode
            os.chmod(clean_script, curr_mode | 0o755)
        except OSError as e:
            logger.warning(f"{TAG} Could not set executable permission on script: {e}")

    # Determine icon path
    if icon_path:
        resolved_icon = icon_path
    else:
        icon_candidates = [
            os.path.join(app_dir, "assets", "icon.png"),
            os.path.join(app_dir, "assets", "logo.png"),
            os.path.join(app_dir, "resources", "icon.png"),
        ]
        resolved_icon = next((c for c in icon_candidates if os.path.exists(c)), icon_candidates[0])

    clean_icon = os.path.abspath(os.path.expanduser(resolved_icon)).replace("\\", "/")

    content = (
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Version=1.5\n"
        f"Name={app_name}\n"
        f"GenericName={DEFAULT_GENERIC_NAME}\n"
        f"Comment={DEFAULT_COMMENT}\n"
        f'Exec="{clean_script}"\n'
        f"Icon={clean_icon}\n"
        "Terminal=false\n"
        f"Categories={DEFAULT_CATEGORIES}\n"
        "StartupNotify=true\n"
        f"StartupWMClass={STARTUP_WM_CLASS}\n"
        "Keywords=game;sync;steam;deck;online-fix;\n"
        "MimeType=x-scheme-handler/bobgame;\n"
    )

    if dry_run:
        dt = time.perf_counter() - t0
        logger.info(f"{TAG} [DryRun] Desktop entry content generated for {entry_path} in {dt:.3f}s")
        return {"success": True, "entry_path": entry_path, "elapsed": dt, "message": "Dry run simulated successfully."}

    temp_file = os.path.join(clean_target_dir, f".{DESKTOP_ENTRY_FILENAME}.tmp.{os.getpid()}")
    try:
        os.makedirs(clean_target_dir, exist_ok=True)
        with open(temp_file, "w", encoding="utf-8", newline="\n") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())

        # Set 0o755 permission required by KDE Plasma desktop launchers
        try:
            os.chmod(temp_file, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
        except OSError:
            pass

        os.replace(temp_file, entry_path)

        try:
            os.chmod(entry_path, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
        except OSError:
            pass

        # Trigger desktop database refresh if available
        update_db = shutil.which("update-desktop-database")
        if update_db:
            try:
                subprocess.run([update_db, clean_target_dir], capture_output=True, check=False)
            except Exception:
                pass

        dt = time.perf_counter() - t0
        logger.info(f"{TAG} Successfully generated desktop entry at {entry_path} in {dt:.3f}s")
        return {"success": True, "entry_path": entry_path, "elapsed": dt, "message": "Desktop entry created."}

    except (PermissionError, OSError) as exc:
        dt = time.perf_counter() - t0
        logger.error(f"{TAG} Failed to write desktop entry to {entry_path}: {exc}", exc_info=True)
        if os.path.exists(temp_file):
            try:
                os.remove(temp_file)
            except OSError:
                pass
        return {"success": False, "entry_path": entry_path, "elapsed": dt, "message": f"Write failed: {exc}"}


def remove_desktop_entry(target_dir: Optional[str] = None) -> bool:
    """Remove bob_game_center.desktop from specified directory or standard locations."""
    dirs_to_clean = [target_dir] if target_dir else [get_default_applications_dir(), get_default_desktop_dir()]
    removed_any = False

    for d in dirs_to_clean:
        if not d:
            continue
        clean_d = os.path.abspath(os.path.expanduser(d))
        target_file = os.path.join(clean_d, DESKTOP_ENTRY_FILENAME)
        if os.path.isfile(target_file):
            try:
                os.remove(target_file)
                logger.info(f"{TAG} Removed desktop entry: {target_file}")
                removed_any = True
            except OSError as exc:
                logger.warning(f"{TAG} Failed to remove {target_file}: {exc}")

    return removed_any


def deploy_steam_grid_artwork(
    steam_path: str,
    uint_appid: int,
    app_dir: str,
    user_ids: Optional[list[str]] = None,
) -> int:
    """
    Deploy local artwork assets into Steam grid directories for the given AppID.
    Returns the count of successfully deployed files.
    """
    uids = user_ids or get_steam_user_ids(steam_path)
    if not uids:
        return 0

    sid = str(uint_appid)
    assets_dir = os.path.join(app_dir, "assets")
    icon_src = os.path.join(assets_dir, "icon.png")
    bg_src = os.path.join(assets_dir, "bg.png")
    logo_src = os.path.join(assets_dir, "logo.png")

    deployed_count = 0
    for uid in uids:
        grid_dir = get_grid_dir(steam_path, uid)
        mappings = [
            (icon_src, f"{sid}_icon.png"),
            (bg_src, f"{sid}_hero.png"),
            (logo_src, f"{sid}_logo.png"),
            (bg_src, f"{sid}.png"),
            (icon_src, f"{sid}p.png"),
        ]
        for src, target_name in mappings:
            if os.path.isfile(src):
                dest_path = os.path.join(grid_dir, target_name)
                try:
                    os.makedirs(grid_dir, exist_ok=True)
                    shutil.copy2(src, dest_path)
                    deployed_count += 1
                except OSError as exc:
                    logger.warning(f"{TAG} Failed to copy artwork to {dest_path}: {exc}")

    return deployed_count


def _is_matching_bob_shortcut(
    entry: dict,
    clean_script: str,
    signed_appid: int,
    app_name: str = DEFAULT_APP_NAME,
) -> bool:
    """Check if an entry in shortcuts.vdf matches Bob Game Center."""
    if not isinstance(entry, dict):
        return False
    entry_appname = str(entry.get("appname", "")).strip().lower()
    entry_exe = str(entry.get("exe", "")).strip('"').strip().lower()
    entry_appid = entry.get("appid")
    clean_script_lower = clean_script.lower().replace("\\", "/") if clean_script else ""

    return (
        entry_appname in (app_name.lower(), "bob game center", "bob gaming game center")
        or (clean_script_lower and entry_exe == clean_script_lower)
        or entry_exe.endswith("bob_game_center.sh")
        or (entry_appid is not None and entry_appid == signed_appid)
    )


def register_bob_game_center_in_steam(
    app_dir: str,
    script_path: Optional[str] = None,
    icon_path: Optional[str] = None,
    steam_path: Optional[str] = None,
    target_user_ids: Optional[list[str]] = None,
    app_name: str = DEFAULT_APP_NAME,
    dry_run: bool = False,
) -> dict:
    """
    Registers Bob Game Center into Steam shortcuts.vdf for Game Mode.
    Prevents duplicate entries across all user accounts, preserves native Linux execution (no Proton),
    and applies atomic fsync serialization with backup.

    Returns:
        {"success": bool, "appid": int, "affected_users": list[str], "elapsed": float, "message": str}
    """
    t0 = time.perf_counter()
    logger.info(f"{TAG} Registering {app_name!r} in Steam shortcuts (app_dir: {app_dir})")

    resolved_steam = steam_path or find_steam_path()
    if not resolved_steam:
        msg = "Steam installation directory not found."
        logger.warning(f"{TAG} Refused: {msg}")
        return {"success": False, "appid": 0, "affected_users": [], "elapsed": 0.0, "message": msg}

    user_ids = target_user_ids or get_steam_user_ids(resolved_steam)
    if not user_ids:
        msg = "No Steam user accounts found."
        logger.warning(f"{TAG} Refused: {msg}")
        return {"success": False, "appid": 0, "affected_users": [], "elapsed": 0.0, "message": msg}

    clean_app_dir = os.path.abspath(os.path.expanduser(app_dir))
    if script_path:
        resolved_script = script_path
    else:
        deck_script = os.path.join(clean_app_dir, "scripts", "deck", "bob_game_center.sh")
        root_script = os.path.join(clean_app_dir, "bob_game_center.sh")
        resolved_script = deck_script if os.path.exists(deck_script) else root_script

    clean_script = os.path.abspath(os.path.expanduser(resolved_script)).replace("\\", "/")
    start_dir = clean_app_dir if clean_app_dir.endswith(os.sep) else f"{clean_app_dir}{os.sep}"

    # Calculate AppID
    signed_id, uint_id, _str_id = calculate_shortcut_appid(clean_script, app_name)

    if dry_run:
        dt = time.perf_counter() - t0
        logger.info(f"{TAG} [DryRun] Steam shortcut calculation complete for {app_name!r} (AppID: {uint_id}) in {dt:.3f}s")
        return {
            "success": True,
            "appid": uint_id,
            "affected_users": list(user_ids),
            "elapsed": dt,
            "message": "Dry run simulated.",
        }

    # Resolve icon path
    clean_icon = ""
    if icon_path and os.path.isfile(icon_path):
        clean_icon = os.path.abspath(icon_path).replace("\\", "/")
    else:
        candidate_icon = os.path.join(clean_app_dir, "assets", "icon.png")
        if os.path.isfile(candidate_icon):
            clean_icon = candidate_icon.replace("\\", "/")

    affected_users: list[str] = []

    for uid in user_ids:
        config_dir = os.path.join(resolved_steam, "userdata", uid, "config")
        try:
            os.makedirs(config_dir, exist_ok=True)
        except (PermissionError, OSError) as pe:
            logger.error(f"{TAG} Cannot create config directory {config_dir}: {pe}")
            continue

        vdf_path = os.path.join(config_dir, "shortcuts.vdf")
        shortcuts_doc = load_shortcuts_vdf(vdf_path)
        shortcuts = shortcuts_doc.setdefault("shortcuts", {})

        # Duplicate Prevention
        matching_keys = [
            k for k, v in shortcuts.items()
            if _is_matching_bob_shortcut(v, clean_script, signed_id, app_name)
        ]

        if matching_keys:
            target_idx = matching_keys[0]
            for dup_k in matching_keys[1:]:
                del shortcuts[dup_k]
            logger.info(f"{TAG} Updating existing Bob Game Center entry (index {target_idx}) for user {uid}")
        else:
            num_keys = [int(k) for k in shortcuts.keys() if k.isdigit()]
            target_idx = str(max(num_keys) + 1 if num_keys else 0)
            logger.info(f"{TAG} Adding new Bob Game Center entry at index {target_idx} for user {uid}")

        formatted_exe = f'"{clean_script}"'
        shortcut_entry = {
            "appid": signed_id,
            "appname": app_name,
            "exe": formatted_exe,
            "StartDir": start_dir,
            "icon": clean_icon,
            "ShortcutPath": "",
            "LaunchOptions": "",
            "IsHidden": 0,
            "AllowDesktopConfig": 1,
            "AllowOverlay": 1,
            "OpenVR": 0,
            "Devkit": 0,
            "DevkitGameID": "",
            "DevkitOverrideAppID": 0,
            "LastPlayTime": 0,
            "FlatpakAppID": "",
            "tags": {
                "0": "Utilities",
                "1": "Bob Game Center",
            },
        }

        shortcuts[target_idx] = shortcut_entry

        # Ensure contiguous sequential keys if duplicates were pruned
        if len(matching_keys) > 1:
            reindexed = {}
            for new_i, (_old_k, val) in enumerate(
                sorted(shortcuts.items(), key=lambda p: int(p[0]) if p[0].isdigit() else 999999)
            ):
                reindexed[str(new_i)] = val
            shortcuts_doc["shortcuts"] = reindexed

        if save_shortcuts_vdf(vdf_path, shortcuts_doc, backup=True):
            affected_users.append(uid)

    dt = time.perf_counter() - t0
    if affected_users:
        # Guarantee native Linux execution: remove any Proton compatibility tool mapping
        try:
            remove_proton_compatibility(resolved_steam, uint_id)
        except Exception as compat_err:
            logger.warning(f"{TAG} Could not clean Proton compatibility: {compat_err}")

        # Deploy local banner and logo grid artworks
        deploy_steam_grid_artwork(resolved_steam, uint_id, clean_app_dir, affected_users)

        # Notify if Steam is currently running
        if is_steam_running():
            mark_steam_reload_needed(app_name, clean_script)
            logger.info(f"{TAG} Steam is running. Shortcuts will appear upon Steam restart.")

        logger.info(
            f"{TAG} Successfully registered {app_name!r} (AppID: {uint_id}) "
            f"across {len(affected_users)} account(s) in {dt:.3f}s"
        )
        return {
            "success": True,
            "appid": uint_id,
            "affected_users": affected_users,
            "elapsed": dt,
            "message": f"Registered across {len(affected_users)} account(s).",
        }
    else:
        logger.error(f"{TAG} Failed to save shortcuts.vdf for any user profile in {dt:.3f}s")
        return {
            "success": False,
            "appid": uint_id,
            "affected_users": [],
            "elapsed": dt,
            "message": "Failed to write shortcuts.vdf to userdata.",
        }


def unregister_bob_game_center_from_steam(
    steam_path: Optional[str] = None,
    user_ids: Optional[list[str]] = None,
    app_name: str = DEFAULT_APP_NAME,
) -> bool:
    """Remove Bob Game Center shortcut from all user profiles in shortcuts.vdf."""
    sp = steam_path or find_steam_path()
    if not sp:
        return False

    uids = user_ids or get_steam_user_ids(sp)
    if not uids:
        return False

    any_removed = False
    for uid in uids:
        vdf_path = os.path.join(sp, "userdata", uid, "config", "shortcuts.vdf")
        if not os.path.isfile(vdf_path):
            continue

        doc = load_shortcuts_vdf(vdf_path)
        shortcuts = doc.get("shortcuts", {})
        to_del = [
            k for k, v in shortcuts.items()
            if isinstance(v, dict) and (
                str(v.get("appname", "")).strip().lower() in (app_name.lower(), "bob game center", "bob gaming game center")
                or str(v.get("exe", "")).strip('"').lower().endswith("bob_game_center.sh")
            )
        ]
        if to_del:
            for k in to_del:
                del shortcuts[k]
            reindexed = {str(i): v for i, (_k, v) in enumerate(shortcuts.items())}
            doc["shortcuts"] = reindexed
            if save_shortcuts_vdf(vdf_path, doc, backup=True):
                any_removed = True
                logger.info(f"{TAG} Unregistered Bob Game Center shortcut for user {uid}")

    return any_removed


def setup_deck_integration(
    app_dir: Optional[str] = None,
    script_path: Optional[str] = None,
    icon_path: Optional[str] = None,
    steam_path: Optional[str] = None,
    desktop_dir: Optional[str] = None,
    app_name: str = DEFAULT_APP_NAME,
    dry_run: bool = False,
) -> dict:
    """
    Combined setup for both Desktop Entry and Steam Game Mode shortcut.
    """
    t0 = time.perf_counter()
    from app.config import get_app_dir
    resolved_app_dir = app_dir or get_app_dir()

    desktop_res = create_desktop_entry(
        app_dir=resolved_app_dir,
        script_path=script_path,
        icon_path=icon_path,
        target_dir=desktop_dir,
        app_name=app_name,
        dry_run=dry_run,
    )

    steam_res = register_bob_game_center_in_steam(
        app_dir=resolved_app_dir,
        script_path=script_path,
        icon_path=icon_path,
        steam_path=steam_path,
        app_name=app_name,
        dry_run=dry_run,
    )

    dt = time.perf_counter() - t0
    success = bool(desktop_res.get("success") and steam_res.get("success"))
    msg = f"Desktop: {desktop_res.get('message')}; Steam: {steam_res.get('message')}"
    return {
        "success": success,
        "desktop": desktop_res,
        "steam": steam_res,
        "elapsed": dt,
        "message": msg,
    }


def install_desktop_entry(
    app_dir: str,
    create_desktop_shortcut: bool = False,
) -> bool:
    """
    High-level integration function fulfilling PROJECT.md Interface Contract:
    Deploys .desktop file to ~/.local/share/applications/ and optionally ~/Desktop.
    """
    clean_app_dir = os.path.abspath(os.path.expanduser(app_dir))
    script_path = os.path.join(clean_app_dir, "scripts", "deck", "bob_game_center.sh")
    if not os.path.exists(script_path):
        script_path = os.path.join(clean_app_dir, "bob_game_center.sh")
    icon_path = os.path.join(clean_app_dir, "assets", "icon.png")

    deploy_app_icon(icon_path)

    apps_dir = get_default_applications_dir()
    res = create_desktop_entry(
        app_dir=clean_app_dir,
        script_path=script_path,
        icon_path=icon_path,
        target_dir=apps_dir,
    )

    if create_desktop_shortcut:
        desktop_dir = get_default_desktop_dir()
        create_desktop_entry(
            app_dir=clean_app_dir,
            script_path=script_path,
            icon_path=icon_path,
            target_dir=desktop_dir,
        )

    return bool(res.get("success", False))


def run_deck_setup_cli(argv: list[str]) -> int:
    """CLI handler for --setup-deck."""
    parser = argparse.ArgumentParser(description="Bob Game Center - Setup Steam Deck Integration")
    parser.add_argument("--setup-deck", action="store_true", help="Run desktop setup")
    parser.add_argument("--app-dir", default=None, help="Application directory")
    parser.add_argument("--steam-path", default=None, help="Steam installation directory")
    parser.add_argument("--desktop-dir", default=None, help="Desktop applications directory")
    parser.add_argument("--dry-run", action="store_true", help="Simulate without writing")

    parsed, _ = parser.parse_known_args(argv)
    res = setup_deck_integration(
        app_dir=parsed.app_dir,
        steam_path=parsed.steam_path,
        desktop_dir=parsed.desktop_dir,
        dry_run=parsed.dry_run,
    )
    if res.get("success"):
        print(f"[Desktop/Integration] Success: {res.get('message')}")
        return 0
    else:
        print(f"[Desktop/Integration] Failed: {res.get('message')}")
        return 1
