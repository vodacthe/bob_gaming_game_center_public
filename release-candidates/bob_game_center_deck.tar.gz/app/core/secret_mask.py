"""Mask embedded API secrets so they are not plain text inside the source or the .exe.

This is obfuscation, not protection: the passphrase ships inside the app, so anyone willing to reverse the exe can
still recover the values. It only keeps them out of `strings`/grep and out of the git diff. Generate blobs with
`python tools/encode_secret.py <plain text>`.
"""

import base64
import hashlib
import logging
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

logger = logging.getLogger(__name__)

_PASSPHRASE = "fuckyouAI"


def _aes() -> AESGCM:
    return AESGCM(hashlib.sha256(_PASSPHRASE.encode("utf-8")).digest())


def encrypt(plain: str) -> str:
    nonce = os.urandom(12)
    blob = nonce + _aes().encrypt(nonce, plain.encode("utf-8"), None)
    return base64.urlsafe_b64encode(blob).decode("ascii")


def decrypt(token: str) -> str:
    """Return the original text, or "" when the blob is damaged (callers already treat "" as 'not configured')."""
    try:
        blob = base64.urlsafe_b64decode(token.encode("ascii"))
        return _aes().decrypt(blob[:12], blob[12:], None).decode("utf-8")
    except Exception as e:
        logger.error(f"[SecretMask] Cannot decrypt embedded secret: {e}")
        return ""
