"""
Process Monitor for Bob Gaming Game Center.
Tracks game .exe processes and detects when a game is launched or closed,
enabling automatic save uploads immediately upon game exit.
"""

import os
import sys
import logging
from typing import Set, Dict

from PySide6.QtCore import QObject, Signal, QTimer

logger = logging.getLogger(__name__)

# Windows native process enumeration via ctypes
if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    TH32CS_SNAPPROCESS = 0x00000002

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ('dwSize', wintypes.DWORD),
            ('cntUsage', wintypes.DWORD),
            ('th32ProcessID', wintypes.DWORD),
            ('th32DefaultHeapID', ctypes.c_size_t),
            ('th32ModuleID', wintypes.DWORD),
            ('cntThreads', wintypes.DWORD),
            ('th32ParentProcessID', wintypes.DWORD),
            ('pcPriClassBase', wintypes.LONG),
            ('dwFlags', wintypes.DWORD),
            ('szExeFile', wintypes.WCHAR * 260)
        ]

    def _get_running_process_names_windows() -> Set[str]:
        """Return lowercase names of all running executable processes on Windows."""
        names = set()
        kernel32 = ctypes.windll.kernel32
        h_snapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        if h_snapshot == -1 or not h_snapshot:
            return names

        try:
            entry = PROCESSENTRY32W()
            entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
            if kernel32.Process32FirstW(h_snapshot, ctypes.byref(entry)):
                names.add(entry.szExeFile.lower())
                while kernel32.Process32NextW(h_snapshot, ctypes.byref(entry)):
                    names.add(entry.szExeFile.lower())
        except Exception as e:
            logger.debug(f"[ProcessMonitor] Error enumerating processes: {e}")
        finally:
            kernel32.CloseHandle(h_snapshot)

        return names
else:
    def _get_running_process_names_windows() -> Set[str]:
        return set()


def get_running_process_names() -> Set[str]:
    """Get lowercase set of all currently running executable names."""
    try:
        import psutil
        names = set()
        for p in psutil.process_iter(['name']):
            try:
                name = p.info.get('name')
                if name:
                    names.add(name.lower())
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return names
    except ImportError:
        return _get_running_process_names_windows()


class ProcessMonitor(QObject):
    """
    Monitors running processes and notifies when monitored games start and exit.
    """
    game_started = Signal(str)            # game_name
    game_exited = Signal(str, str)         # game_name, exe_path

    def __init__(self, config_getter, parent=None):
        super().__init__(parent)
        self.config_getter = config_getter
        self._running_games: Set[str] = set()

        self._timer = QTimer(self)
        self._timer.setInterval(2500)  # Check every 2.5 seconds
        self._timer.timeout.connect(self.check_processes)

    def start(self):
        """Start monitoring processes."""
        self._timer.start()
        logger.info("[ProcessMonitor] Started game process monitoring (2.5s interval)")

    def stop(self):
        """Stop monitoring processes."""
        self._timer.stop()
        self._running_games.clear()
        logger.info("[ProcessMonitor] Stopped game process monitoring")

    def has_running_game(self) -> bool:
        """Return True when at least one monitored library game is currently running."""
        return bool(self._running_games)

    def check_processes(self):
        """Check all monitored game processes against running processes."""
        config = self.config_getter()
        games = config.get("games", {})

        # Collect games with configured exe_path
        monitored_games: Dict[str, str] = {}  # game_name -> exe_filename (lowercase)
        game_exe_paths: Dict[str, str] = {}    # game_name -> full exe_path

        for name, data in games.items():
            exe_path = data.get("exe_path", "").strip()
            if exe_path:
                exe_name = os.path.basename(exe_path).lower()
                if exe_name:
                    monitored_games[name] = exe_name
                    game_exe_paths[name] = exe_path

        if not monitored_games and not self._running_games:
            return

        running_procs = get_running_process_names()

        for game_name, exe_name in monitored_games.items():
            is_running = exe_name in running_procs
            was_running = game_name in self._running_games

            if is_running and not was_running:
                self._running_games.add(game_name)
                logger.info(f"[ProcessMonitor] Detected game start: {game_name} ({exe_name})")
                self.game_started.emit(game_name)

            elif not is_running and was_running:
                self._running_games.remove(game_name)
                exe_path = game_exe_paths.get(game_name, "")
                logger.info(f"[ProcessMonitor] Detected game exit: {game_name} ({exe_name}) — triggering exit signal")
                self.game_exited.emit(game_name, exe_path)

        # Clean up any games that were removed or unconfigured while running
        for game_name in list(self._running_games):
            if game_name not in monitored_games:
                self._running_games.remove(game_name)
