"""Cross-platform automatic save-location detector for Windows and Steam Deck / SteamOS.

Resolves game save directories using a 5-tier pipeline:
- Tier 0: Peer-OS cloud path translation (`Windows <-> SteamOS Proton`).
- Tier 1: Online-Fix, Steam Emulator (Goldberg/GSE, RUNE, CODEX, FLT, EMPRESS) & Steam userdata.
- Tier 2: Pre-compiled bundled + OTA Save Locations Database (from Ludusavi / PCGamingWiki manifest).
- Tier 3: Engine metadata heuristics (Unity app.info, Unreal Saved/SaveGames, Ren'Py, RPG Maker, portable).
- Tier 4: Existing local save folder heuristics under Documents / Saved Games / AppData / Proton pfx.
"""

from __future__ import annotations

import getpass
import gzip
import json
import logging
import os
import re
import sys
import tempfile
import threading
import time
from dataclasses import dataclass
from typing import Any, Iterable, Optional

import app.config as cfg
from app.core.steam_compat import parse_simple_vdf_text
from app.core.steam_manager import (
    find_matching_steam_shortcuts,
    find_steam_path,
    get_primary_steam_user_id,
    get_steam_user_ids,
)
from app.core.steam_vdf import calculate_shortcut_appid
from app.core.viethoa.catalog import (
    clean_catalog_lookup_title,
    extract_title_tokens,
    normalize_catalog_cache_key,
    normalized_token_key,
    title_match_keys,
)

logger = logging.getLogger(__name__)
TAG = "[CloudSave/Detector]"

SAVE_DB_FILENAME = "save_locations_db.json.gz"
REMOTE_MANIFEST_URL = "https://raw.githubusercontent.com/mtkennerly/ludusavi-manifest/master/data/manifest.yaml"
REMOTE_SYNC_TTL_SECONDS = 7 * 24 * 3600
_REMOTE_HTTP_TIMEOUT = 25

_IGNORED_SAVE_FILES = {"desktop.ini", "thumbs.db", ".ds_store"}

_CONFIG_ONLY_PATH_MARKERS = (
    "/saved/config/",
    "/config/windows/",
    "/config/linux/",
    "graphicsconfig.xml",
    "gameusersettings.ini",
    "engine.ini",
    "input.ini",
    "scalability.ini",
)

_CONFIG_ONLY_FILENAMES = {
    "graphicsconfig.xml",
    "gameusersettings.ini",
    "engine.ini",
    "settings.ini",
    "options.ini",
    "input.ini",
    "config.ini",
    "prefs.ini",
    "preferences.ini",
    "globalsettingswin.sjson",
    "options.ron",
}

_BARE_TEMPLATES = {
    "",
    "<base>",
    "<home>",
    "<root>",
    "<winappdata>",
    "<winlocalappdata>",
    "<winlocalappdatalow>",
    "<windocuments>",
    "<winpublic>",
    "<winprogramdata>",
    "<windir>",
    "<xdgdata>",
    "<xdgconfig>",
    "<home>/documents",
    "<home>/saved games",
    "<home>/appdata",
    "<home>/appdata/local",
    "<home>/appdata/locallow",
    "<home>/appdata/roaming",
    "<windocuments>/my games",
    "<winpublic>/documents",
}

_UNREAL_ENGINE_SKIP_DIRS = {
    "engine",
    "binaries",
    "content",
    "saved",
    "intermediate",
    "deriveddatacache",
    "_commonredist",
    "redist",
}

_SOURCE_LABELS = {
    "cloud_peer": "Đồng bộ từ thiết bị khác",
    "emulator": "Bản lưu Online-Fix / Steam Emulator",
    "database": "Cơ sở dữ liệu chuẩn",
    "engine": "Nhận diện theo engine game",
    "heuristic": "Thư mục lưu cục bộ",
}

_SOURCE_BASE_SCORES = {
    "cloud_peer": 120.0,
    "emulator": 110.0,
    "database": 100.0,
    "engine": 80.0,
    "heuristic": 60.0,
}

_EDITION_NOISE_TOKENS = {
    "edition",
    "version",
    "pack",
    "bundle",
    "complete",
    "goty",
    "deluxe",
    "definitive",
    "enhanced",
    "gold",
    "standard",
    "anniversary",
    "special",
    "legendary",
    "ultimate",
    "remastered",
    "remaster",
    "remake",
    "cut",
    "directors",
    "year",
    "game",
    "soundtrack",
    "collection",
    "hd",
    "vr",
    "the",
    "a",
    "an",
    "of",
    "and",
}

_STOP_WORDS = {"the", "a", "an", "of", "and"}


@dataclass
class SaveCandidate:
    """Represents a detected candidate save directory for a game."""

    path: str
    exists: bool
    has_files: bool
    latest_mtime: float
    file_count: int
    total_bytes: int
    source: str
    label: str
    score: float


def _unquote_yaml_scalar(s: str) -> str:
    s = s.strip()
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        if "\\" in s:
            try:
                val = json.loads(s)
                if isinstance(val, str):
                    return val
            except Exception:
                return s[1:-1].replace('\\"', '"').replace("\\\\", "\\")
        return s[1:-1]
    if len(s) >= 2 and s[0] == "'" and s[-1] == "'":
        return s[1:-1].replace("''", "'")
    return s


def _split_yaml_mapping_key(line: str) -> str:
    s = line.strip()
    if s.endswith(": {}"):
        s = s[:-4].rstrip()
    elif s.endswith(":"):
        s = s[:-1]
    else:
        s = s.rsplit(":", 1)[0]
    return _unquote_yaml_scalar(s)


def _strip_file_or_glob_tail(path_tpl: str) -> str:
    """Convert a Ludusavi file or glob template into its enclosing save directory template."""
    norm = path_tpl.strip().replace("\\", "/")
    while "//" in norm:
        norm = norm.replace("//", "/")
    norm = norm.rstrip("/")
    if not norm:
        return ""

    # Strip `/**/...` recursive wildcard suffix if present
    parts = norm.split("/")
    for idx, seg in enumerate(parts):
        if seg == "**":
            parts = parts[:idx]
            break
    if not parts:
        return ""

    last = parts[-1]
    # Glob wildcards in filename segment (`*.sav`, `Profile*.sav`, `slot?.bin`)
    if any(ch in last for ch in "*?["):
        parts = parts[:-1]
    elif "." in last and not last.startswith(".") and not (last.startswith("<") and last.endswith(">")):
        low = last.lower()
        # Preserve macOS/Unity bundle or publisher folder names like `com.playloft.app` or `unity.Team.Game`
        if not low.startswith(("com.", "org.", "net.", "io.", "unity.")):
            stem, ext = last.rsplit(".", 1)
            if stem and 1 <= len(ext) <= 8 and ext.isalnum() and any(c.isalpha() for c in ext):
                parts = parts[:-1]

    # Collapse any remaining trailing wildcard segments
    while parts and any(ch in parts[-1] for ch in "*?["):
        parts.pop()

    if not parts:
        return ""
    res = "/".join(parts)
    if res.lower() in _BARE_TEMPLATES:
        return ""
    return res


def _is_untagged_config_only_path(raw_tpl: str) -> bool:
    low = raw_tpl.strip().replace("\\", "/").lower()
    if any(marker in low for marker in _CONFIG_ONLY_PATH_MARKERS):
        if "save" not in low.split("/config/", 1)[-1]:
            return True
    tail = low.rsplit("/", 1)[-1]
    return tail in _CONFIG_ONLY_FILENAMES


def parse_ludusavi_manifest_yaml(stream: Iterable[str]) -> dict[str, Any]:
    """Parse Ludusavi manifest.yaml into a compact save-location database dict.

    Retains Steam AppIDs, installDir basenames, aliases, and save directory templates
    for Windows/Proton and Linux/SteamOS while filtering out config-only, macOS-only,
    and Microsoft-Store-only entries.
    """
    games: dict[str, dict[str, Any]] = {}
    aliases: dict[str, str] = {}

    cur_title: str | None = None
    cur_entry: dict[str, Any] | None = None
    cur_sec: str | None = None
    cur_sub_id: str | None = None
    cur_file: dict[str, Any] | None = None
    cur_file_sub: str | None = None
    cur_when_clause: dict[str, str] | None = None

    def _flush_entry() -> None:
        nonlocal cur_title, cur_entry
        if not cur_title or not cur_entry:
            return
        alias_target = cur_entry.get("alias")
        if alias_target:
            aliases[cur_title] = alias_target
            return

        seen_paths: dict[str, str] = {}
        ordered_paths: list[list[str]] = []

        for fitem in cur_entry["files"]:
            tags: set[str] = fitem["tags"]
            if tags and "save" not in tags:
                continue
            raw_path = fitem["path"]
            if not tags and _is_untagged_config_only_path(raw_path):
                continue

            clauses: list[dict[str, str]] = fitem["when"]
            wants_win = False
            wants_linux = False
            if not clauses:
                wants_win = True
                wants_linux = True
            else:
                for clause in clauses:
                    os_val = clause.get("os", "")
                    store_val = clause.get("store", "")
                    if store_val == "microsoft":
                        continue
                    if not os_val or os_val in ("windows", "dos"):
                        wants_win = True
                    if not os_val or os_val == "linux":
                        wants_linux = True

            if not (wants_win or wants_linux):
                continue

            dir_tpl = _strip_file_or_glob_tail(raw_path)
            if not dir_tpl:
                continue

            if wants_win and wants_linux:
                os_flag = ""
            elif wants_win:
                os_flag = "w"
            else:
                os_flag = "l"

            prev = seen_paths.get(dir_tpl)
            if prev is None:
                seen_paths[dir_tpl] = os_flag
            elif prev != os_flag and prev != "":
                seen_paths[dir_tpl] = ""

        for tpl, flag in seen_paths.items():
            ordered_paths.append([tpl, flag] if flag else [tpl])

        if not ordered_paths:
            return

        out_entry: dict[str, Any] = {"p": ordered_paths}
        if cur_entry["appid"]:
            out_entry["a"] = cur_entry["appid"]
        extra_ids = [x for x in cur_entry["extra_appids"] if x != cur_entry["appid"]]
        if extra_ids:
            out_entry["x"] = extra_ids[:6]
        if cur_entry["dirs"]:
            out_entry["d"] = cur_entry["dirs"][:3]
        games[cur_title] = out_entry

    for raw_line in stream:
        line = raw_line.rstrip("\r\n")
        if not line or line == "---" or line.lstrip().startswith("#"):
            continue

        # Indent 0: Game entry header
        if not line.startswith(" "):
            _flush_entry()
            cur_title = _split_yaml_mapping_key(line)
            cur_entry = {"files": [], "appid": 0, "extra_appids": [], "dirs": [], "alias": ""}
            cur_sec = None
            cur_sub_id = None
            cur_file = None
            cur_file_sub = None
            cur_when_clause = None
            continue

        if cur_entry is None:
            continue

        # Indent 2: Section header or `alias:`
        if line.startswith("  ") and not line.startswith("   "):
            stripped = line[2:]
            cur_sub_id = None
            cur_file = None
            cur_file_sub = None
            cur_when_clause = None
            if stripped.startswith("alias:"):
                cur_entry["alias"] = _unquote_yaml_scalar(stripped[6:])
                cur_sec = None
            elif stripped.endswith(":") or stripped.endswith(": {}"):
                cur_sec = stripped.split(":", 1)[0].strip()
            else:
                cur_sec = None
            continue

        if cur_sec == "steam" and line.startswith("    id:"):
            val = line.split(":", 1)[1].strip()
            if val.isdigit() and int(val) > 0:
                cur_entry["appid"] = int(val)
        elif cur_sec == "id":
            if line.startswith("    ") and not line.startswith("     "):
                cur_sub_id = line.strip().split(":", 1)[0].strip()
                if cur_sub_id == "steam" and ":" in line:
                    val = line.split(":", 1)[1].strip()
                    if val.isdigit() and int(val) > 0 and not cur_entry["appid"]:
                        cur_entry["appid"] = int(val)
            elif cur_sub_id == "steamExtra" and line.startswith("      - "):
                val = line.strip()[2:].strip()
                if val.isdigit() and int(val) > 0:
                    cur_entry["extra_appids"].append(int(val))
        elif cur_sec == "installDir" and line.startswith("    ") and not line.startswith("     "):
            dname = _split_yaml_mapping_key(line)
            if dname:
                cur_entry["dirs"].append(dname)
        elif cur_sec == "files":
            if line.startswith("    ") and not line.startswith("     "):
                fpath = _split_yaml_mapping_key(line)
                cur_file = {"path": fpath, "tags": set(), "when": []}
                cur_entry["files"].append(cur_file)
                cur_file_sub = None
                cur_when_clause = None
            elif cur_file is not None:
                if line.startswith("      ") and not line.startswith("       "):
                    cur_file_sub = line.strip().rstrip(":")
                    cur_when_clause = None
                elif cur_file_sub == "tags" and line.startswith("        - "):
                    cur_file["tags"].add(line.strip()[2:].strip().lower())
                elif cur_file_sub == "when":
                    if line.startswith("        - "):
                        cur_when_clause = {}
                        cur_file["when"].append(cur_when_clause)
                        rest = line[10:].strip()
                        if ":" in rest:
                            k, v = rest.split(":", 1)
                            cur_when_clause[k.strip().lower()] = _unquote_yaml_scalar(v).lower()
                    elif line.startswith("          ") and cur_when_clause is not None and ":" in line:
                        k, v = line.strip().split(":", 1)
                        cur_when_clause[k.strip().lower()] = _unquote_yaml_scalar(v).lower()

    _flush_entry()
    kept_aliases = {k: v for k, v in aliases.items() if v in games}
    return {
        "v": 1,
        "updated_at": int(time.time()),
        "games": games,
        "aliases": kept_aliases,
    }


def get_bundled_save_db_path() -> str:
    """Return path to bundled pre-compiled save_locations_db.json.gz."""
    app_dir = cfg.get_app_dir()
    candidates = [
        os.path.join(app_dir, "app", "data", SAVE_DB_FILENAME),
        os.path.join(app_dir, "data", SAVE_DB_FILENAME),
    ]
    module_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    candidates.append(os.path.join(module_root, "app", "data", SAVE_DB_FILENAME))
    for path in candidates:
        if os.path.isfile(path):
            return path
    return candidates[0]


def get_save_db_cache_dir() -> str:
    """Return directory for OTA save DB cache inside CACHE_DIR (never CONFIG_DIR root)."""
    override = os.environ.get("BOBGAMING_SAVEDB_CACHE_DIR")
    if override:
        os.makedirs(override, exist_ok=True)
        return override
    base_cache = getattr(cfg, "CACHE_DIR", None) or os.path.join(cfg.CONFIG_DIR, "cache")
    target = os.path.join(base_cache, "save_detector")
    os.makedirs(target, exist_ok=True)
    return target


def get_save_db_cache_path() -> str:
    """Return absolute path to cached save_locations_db.json.gz."""
    return os.path.join(get_save_db_cache_dir(), SAVE_DB_FILENAME)


class SaveLocationsDB:
    """Thread-safe indexed database mapping games/AppIDs to canonical save directory templates."""

    def __init__(self, raw_data: dict[str, Any] | None = None, source_path: str | None = None):
        self._lock = threading.RLock()
        self.version: int = 1
        self.updated_at: int = 0
        self.source_path: str | None = source_path
        self.games: dict[str, dict[str, Any]] = {}
        self.aliases: dict[str, str] = {}

        self._appid_index: dict[int, tuple[str, dict[str, Any]]] = {}
        self._canonical_key_index: dict[str, tuple[str, dict[str, Any]]] = {}
        self._alias_key_index: dict[str, tuple[str, dict[str, Any]]] = {}
        self._dir_key_index: dict[str, tuple[str, dict[str, Any]]] = {}
        self._token_key_index: dict[str, tuple[str, dict[str, Any]]] = {}
        self._subset_specs: list[tuple[str, dict[str, Any], set[str], set[str]]] = []

        if raw_data is not None:
            self._load_from_dict(raw_data)

    def __len__(self) -> int:
        with self._lock:
            return len(self.games)

    def _load_from_dict(self, data: dict[str, Any]) -> int:
        with self._lock:
            games = data.get("games") or {}
            aliases = data.get("aliases") or {}
            if not isinstance(games, dict):
                return 0

            new_games: dict[str, dict[str, Any]] = {}
            new_appid: dict[int, tuple[str, dict[str, Any]]] = {}
            new_canon: dict[str, tuple[str, dict[str, Any]]] = {}
            new_alias: dict[str, tuple[str, dict[str, Any]]] = {}
            new_dir: dict[str, tuple[str, dict[str, Any]]] = {}
            new_token: dict[str, tuple[str, dict[str, Any]]] = {}
            new_subset: list[tuple[str, dict[str, Any], set[str], set[str]]] = []

            for title, raw_entry in games.items():
                if not isinstance(title, str) or not isinstance(raw_entry, dict):
                    continue
                paths = raw_entry.get("p") or []
                if not isinstance(paths, list) or not paths:
                    continue
                norm_paths: list[list[str]] = []
                for p in paths:
                    if isinstance(p, str) and p:
                        norm_paths.append([p])
                    elif isinstance(p, (list, tuple)) and p and isinstance(p[0], str) and p[0]:
                        norm_paths.append([str(x) for x in p])
                if not norm_paths:
                    continue
                entry_copy = dict(raw_entry)
                entry_copy["p"] = norm_paths
                new_games[title] = entry_copy
                pair = (title, entry_copy)

                aid = raw_entry.get("a")
                if isinstance(aid, int) and aid > 0 and aid != 480:
                    new_appid.setdefault(aid, pair)
                for xid in raw_entry.get("x") or ():
                    if isinstance(xid, int) and xid > 0 and xid != 480:
                        new_appid.setdefault(xid, pair)

                ck = normalize_catalog_cache_key(title)
                if ck:
                    new_canon.setdefault(ck, pair)

                for tkey in title_match_keys(title):
                    if tkey:
                        new_token.setdefault(tkey, pair)

                for dname in raw_entry.get("d") or ():
                    if isinstance(dname, str) and dname:
                        dk = normalize_catalog_cache_key(dname)
                        if dk:
                            new_dir.setdefault(dk, pair)

                toks = extract_title_tokens(clean_catalog_lookup_title(title))
                if toks:
                    eff = {t for t in toks if t not in _STOP_WORDS} or toks
                    nums = {t for t in toks if t.isdigit()}
                    new_subset.append((title, raw_entry, eff, nums))

            if isinstance(aliases, dict):
                for al, target in aliases.items():
                    if isinstance(al, str) and isinstance(target, str) and target in new_games:
                        ak = normalize_catalog_cache_key(al)
                        if ak:
                            new_alias.setdefault(ak, (target, new_games[target]))
                        for tkey in title_match_keys(al):
                            if tkey:
                                new_token.setdefault(tkey, (target, new_games[target]))

            self.version = int(data.get("v") or 1)
            self.updated_at = int(data.get("updated_at") or 0)
            self.games = new_games
            self.aliases = dict(aliases) if isinstance(aliases, dict) else {}
            self._appid_index = new_appid
            self._canonical_key_index = new_canon
            self._alias_key_index = new_alias
            self._dir_key_index = new_dir
            self._token_key_index = new_token
            self._subset_specs = new_subset
            return len(new_games)

    def find_match(
        self,
        title: str,
        appids: Iterable[int] = (),
        install_dirname: str = "",
    ) -> tuple[str, str, dict[str, Any]] | None:
        """Match a game to a DB entry. Returns (tier, canonical_title, entry_dict) or None."""
        with self._lock:
            # Tier 1: Steam AppID
            for aid in appids:
                if isinstance(aid, int) and aid > 0 and aid != 480 and aid in self._appid_index:
                    ctitle, entry = self._appid_index[aid]
                    return "tier1_appid", ctitle, entry

            clean_title = clean_catalog_lookup_title(title) if title else ""
            if clean_title:
                ck = normalize_catalog_cache_key(clean_title)
                if ck and ck in self._canonical_key_index:
                    ctitle, entry = self._canonical_key_index[ck]
                    return "tier2_canonical", ctitle, entry
                if ck and ck in self._alias_key_index:
                    ctitle, entry = self._alias_key_index[ck]
                    return "tier3_alias", ctitle, entry

                for tkey in title_match_keys(clean_title):
                    if tkey in self._token_key_index:
                        ctitle, entry = self._token_key_index[tkey]
                        return "tier3_token", ctitle, entry

            # Tier 3b: installDir folder basename match (fallback if title differs)
            if install_dirname:
                dk = normalize_catalog_cache_key(install_dirname)
                if dk and len(dk) >= 4 and dk in self._dir_key_index:
                    ctitle, entry = self._dir_key_index[dk]
                    return "tier3_installdir", ctitle, entry

            # Tier 4: Strict edition-noise token subset with numeric symmetry
            if clean_title:
                q_tokens = extract_title_tokens(clean_title)
                if q_tokens:
                    eff_q = {t for t in q_tokens if t not in _STOP_WORDS} or q_tokens
                    q_nums = {t for t in q_tokens if t.isdigit()}
                    for ctitle, entry, cand_tokens, cand_nums in self._subset_specs:
                        if not (eff_q & cand_tokens):
                            continue
                        if bool(q_nums) != bool(cand_nums):
                            continue
                        if q_nums and cand_nums and not (q_nums & cand_nums):
                            continue
                        if eff_q.issubset(cand_tokens):
                            if not ((cand_tokens - eff_q) - _EDITION_NOISE_TOKENS):
                                return "tier4_subset", ctitle, entry
                        elif cand_tokens.issubset(eff_q) and len(cand_tokens) >= 2:
                            if not ((eff_q - cand_tokens) - _EDITION_NOISE_TOKENS):
                                return "tier4_subset", ctitle, entry

            return None


_db_instance: SaveLocationsDB | None = None
_db_lock = threading.RLock()


def _read_gzip_json(path: str) -> dict[str, Any] | None:
    try:
        with gzip.open(path, "rt", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("games"), dict):
            return data
    except Exception as exc:
        logger.warning(f"{TAG} Failed reading save DB from '{path}': {exc}")
    return None


def load_save_db(
    cache_path: str | None = None,
    bundled_path: str | None = None,
) -> SaveLocationsDB:
    """Load SaveLocationsDB from cache if fresh/valid, falling back to bundled DB."""
    started = time.monotonic()
    c_path = cache_path or get_save_db_cache_path()
    b_path = bundled_path or get_bundled_save_db_path()

    bundled_data = _read_gzip_json(b_path) if os.path.isfile(b_path) else None
    cached_data = _read_gzip_json(c_path) if os.path.isfile(c_path) else None

    if cached_data is not None:
        cached_ver = int(cached_data.get("v") or 1)
        bundled_ver = int(bundled_data.get("v") or 1) if bundled_data else 0
        cached_ts = int(cached_data.get("updated_at") or 0)
        bundled_ts = int(bundled_data.get("updated_at") or 0) if bundled_data else 0
        if bundled_data is None or (cached_ver, cached_ts) >= (bundled_ver, bundled_ts):
            db = SaveLocationsDB(raw_data=cached_data, source_path=c_path)
            logger.info(f"{TAG} Loaded {len(db)} games from cache DB '{c_path}' in {time.monotonic() - started:.3f}s")
            return db
        logger.info(f"{TAG} Bundled DB supersedes older cache DB '{c_path}'")

    if bundled_data is not None:
        db = SaveLocationsDB(raw_data=bundled_data, source_path=b_path)
        logger.info(f"{TAG} Loaded {len(db)} games from bundled DB '{b_path}' in {time.monotonic() - started:.3f}s")
        return db

    logger.warning(f"{TAG} No valid bundled or cached save DB found; using empty DB")
    return SaveLocationsDB(raw_data={"v": 1, "games": {}, "aliases": {}}, source_path=None)


def get_save_db(
    reload: bool = False,
    cache_path: str | None = None,
    bundled_path: str | None = None,
) -> SaveLocationsDB:
    """Return process-wide SaveLocationsDB singleton."""
    global _db_instance
    with _db_lock:
        if _db_instance is None or reload:
            _db_instance = load_save_db(cache_path=cache_path, bundled_path=bundled_path)
        return _db_instance


def set_save_db(db: SaveLocationsDB | None) -> None:
    """Inject or clear SaveLocationsDB singleton (for unit tests)."""
    global _db_instance
    with _db_lock:
        _db_instance = db


def _atomic_write_gzip_json(path: str, payload: dict[str, Any]) -> bool:
    folder = os.path.dirname(os.path.abspath(path))
    os.makedirs(folder, exist_ok=True)
    # Guard against accidental write to CONFIG_DIR root
    if os.path.normcase(os.path.realpath(folder)) == os.path.normcase(os.path.realpath(cfg.CONFIG_DIR)):
        logger.error(f"{TAG} Refused writing save DB directly inside CONFIG_DIR: {path}")
        return False
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp_savedb_", suffix=".json.gz", dir=folder)
    try:
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        with os.fdopen(fd, "wb") as f:
            f.write(gzip.compress(raw, compresslevel=9))
        os.replace(tmp_path, path)
        return True
    except Exception as exc:
        logger.warning(f"{TAG} Failed atomic gzip write to '{path}': {exc}")
        return False
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass


def fetch_and_sync_remote_save_db(
    force: bool = False,
    url: str = REMOTE_MANIFEST_URL,
    cache_path: str | None = None,
) -> bool:
    """Download and compile remote Ludusavi manifest.yaml into CACHE_DIR if stale (> 7 days)."""
    import requests
    from app.version import APP_VERSION

    c_path = cache_path or get_save_db_cache_path()
    if not force and os.path.isfile(c_path):
        try:
            age = time.time() - os.path.getmtime(c_path)
            if 0 <= age < REMOTE_SYNC_TTL_SECONDS:
                logger.debug(f"{TAG} Save DB cache is fresh (age={age / 3600:.1f}h); skipping OTA fetch")
                return False
        except OSError:
            pass

    started = time.monotonic()
    try:
        resp = requests.get(
            url,
            timeout=_REMOTE_HTTP_TIMEOUT,
            stream=True,
            headers={"User-Agent": f"BobGamingGameCenter/{APP_VERSION}"},
        )
        dur = time.monotonic() - started
        if resp.status_code != 200:
            logger.warning(
                f"{TAG} Remote manifest fetch failed: url={url} status={resp.status_code} duration={dur:.2f}s"
            )
            return False
        resp.encoding = "utf-8"
        payload = parse_ludusavi_manifest_yaml(resp.iter_lines(decode_unicode=True))
    except Exception as exc:
        dur = time.monotonic() - started
        logger.warning(f"{TAG} Remote manifest network/parse error: url={url} status=ERR duration={dur:.2f}s ({exc})")
        return False

    if len(payload.get("games") or {}) < 1000:
        logger.warning(f"{TAG} Rejected remote manifest payload with too few entries ({len(payload.get('games') or {})})")
        return False

    if _atomic_write_gzip_json(c_path, payload):
        db = SaveLocationsDB(raw_data=payload, source_path=c_path)
        set_save_db(db)
        logger.info(
            f"{TAG} Updated OTA save DB from '{url}': {len(db)} games in {time.monotonic() - started:.2f}s"
        )
        return True
    return False


# ------------------------------------------------------------------ AppID & Prefix Resolution


def _scan_dir_for_appids(search_dir: str) -> list[int]:
    """Extract Steam AppIDs from emulator/crack configs and steam_appid.txt inside search_dir."""
    if not search_dir or not os.path.isdir(search_dir):
        return []
    found_real: list[int] = []
    found_fallback: list[int] = []

    def _add(val: int, is_fake_spacewar: bool = False) -> None:
        if val <= 0:
            return
        target = found_fallback if (val == 480 or is_fake_spacewar) else found_real
        if val not in target:
            target.append(val)

    norm_dir = os.path.abspath(search_dir)
    ini_names = {"onlinefix.ini", "steamfix.ini", "steam_emu.ini", "codex.ini", "rune.ini", "tenoke.ini", "flt.ini", "valve.ini"}

    try:
        for root, dirs, files in os.walk(norm_dir):
            rel = os.path.relpath(root, norm_dir)
            depth = 0 if rel == "." else rel.count(os.sep) + 1
            if depth >= 3:
                dirs.clear()
            for fname in files:
                low = fname.lower()
                fpath = os.path.join(root, fname)
                if low == "steam_appid.txt":
                    try:
                        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                            txt = f.read().strip()
                        if txt.isdigit():
                            _add(int(txt))
                    except OSError:
                        pass
                elif low in ini_names:
                    try:
                        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                            for line in f:
                                s = line.strip().lstrip("\ufeff")
                                if not s or s.startswith((";", "#")):
                                    continue
                                m_real = re.match(r"(?i)^RealAppId\s*=\s*(\d+)", s)
                                if m_real:
                                    _add(int(m_real.group(1)), False)
                                    continue
                                m_app = re.match(r"(?i)^(?:AppId|ApplicationId|GameID)\s*=\s*(\d+)", s)
                                if m_app:
                                    _add(int(m_app.group(1)), False)
                                    continue
                                m_fake = re.match(r"(?i)^FakeAppId\s*=\s*(\d+)", s)
                                if m_fake:
                                    _add(int(m_fake.group(1)), True)
                    except OSError:
                        pass
    except OSError:
        pass

    return found_real + [x for x in found_fallback if x not in found_real]


def discover_game_appids(
    game_name: str,
    install_location: str = "",
    exe_path: str = "",
    explicit_appid: Any = None,
) -> list[int]:
    """Return ordered list of positive integer Steam AppIDs associated with a game."""
    appids: list[int] = []

    def _push(val: Any) -> None:
        try:
            ival = int(str(val).strip())
            if ival > 0 and ival not in appids:
                appids.append(ival)
        except (TypeError, ValueError):
            pass

    if explicit_appid:
        _push(explicit_appid)

    dirs_to_scan: list[str] = []
    if install_location and os.path.isdir(install_location):
        dirs_to_scan.append(install_location)
    if exe_path:
        ed = os.path.dirname(exe_path)
        if ed and os.path.isdir(ed) and ed not in dirs_to_scan:
            dirs_to_scan.append(ed)

    for d in dirs_to_scan:
        for aid in _scan_dir_for_appids(d):
            _push(aid)

    # Query VietHoa catalog if available for AppID enrichment
    try:
        from app.core.viethoa.catalog import get_viethoa_catalog

        cat = get_viethoa_catalog()
        vm = cat.find_match(game_name)
        if vm and getattr(vm[1], "steam_appid", None):
            _push(vm[1].steam_appid)
    except Exception:
        pass

    return appids


def list_steam_library_dirs(steam_path: str | None = None) -> list[str]:
    """Return all Steam library folders (main path, libraryfolders.vdf entries, SteamOS SD cards)."""
    sp = steam_path or find_steam_path()
    libs: list[str] = []
    seen: set[str] = set()

    def _add(p: str) -> None:
        if not p or not os.path.isdir(p):
            return
        real = os.path.realpath(p)
        key = os.path.normcase(real)
        if key not in seen:
            seen.add(key)
            libs.append(real)

    if sp:
        _add(sp)
        for vdf_rel in (
            os.path.join("steamapps", "libraryfolders.vdf"),
            os.path.join("config", "libraryfolders.vdf"),
        ):
            vdf_path = os.path.join(sp, vdf_rel)
            if os.path.isfile(vdf_path):
                try:
                    with open(vdf_path, "r", encoding="utf-8", errors="replace") as f:
                        parsed = parse_simple_vdf_text(f.read())
                    lf = parsed.get("libraryfolders") or parsed.get("LibraryFolders") or parsed
                    if isinstance(lf, dict):
                        for entry in lf.values():
                            if isinstance(entry, dict) and entry.get("path"):
                                _add(str(entry["path"]))
                            elif isinstance(entry, str) and os.path.isdir(entry):
                                _add(entry)
                except Exception as exc:
                    logger.debug(f"{TAG} Failed parsing {vdf_path}: {exc}")

    if sys.platform != "win32":
        for candidate in ("/run/media/mmcblk0p1",):
            if os.path.isdir(os.path.join(candidate, "steamapps")):
                _add(candidate)
        deck_media = "/run/media/deck"
        if os.path.isdir(deck_media):
            try:
                for entry in os.listdir(deck_media):
                    full = os.path.join(deck_media, entry)
                    if os.path.isdir(os.path.join(full, "steamapps")):
                        _add(full)
            except OSError:
                pass

    return libs


def _normalize_pfx_dir(compat_dir: str) -> str | None:
    """Return the Wine prefix root containing drive_c, or None if not created yet."""
    if not compat_dir or not os.path.isdir(compat_dir):
        return None
    pfx = os.path.join(compat_dir, "pfx")
    if os.path.isdir(os.path.join(pfx, "drive_c")):
        return pfx
    if os.path.isdir(os.path.join(compat_dir, "drive_c")):
        return compat_dir
    return None


def resolve_proton_prefixes(
    game_name: str,
    exe_path: str = "",
    install_location: str = "",
    appids: Iterable[int] = (),
    steam_path: str | None = None,
) -> tuple[list[str], str | None, list[str]]:
    """Resolve Proton/Wine prefixes on Linux / SteamOS.

    Returns (specific_prefixes, planned_prefix, fallback_existing_prefixes).
    On Windows returns ([], None, []).
    """
    if sys.platform == "win32":
        return [], None, []

    sp = steam_path or find_steam_path()
    libs = list_steam_library_dirs(sp)
    specific: list[str] = []
    seen: set[str] = set()
    planned_prefix: str | None = None

    def _add_specific(cand_pfx: str) -> None:
        if not cand_pfx:
            return
        norm = os.path.normpath(cand_pfx)
        key = os.path.normcase(os.path.realpath(norm) if os.path.exists(norm) else norm)
        if key not in seen:
            seen.add(key)
            specific.append(norm)

    # 1. Game-local compatdata (created by Bob Game Center start_game.sh or direct runner)
    clean_dir = install_location or (os.path.dirname(exe_path) if exe_path else "")
    if clean_dir and os.path.isdir(clean_dir):
        local_compat = os.path.join(clean_dir, "compatdata")
        existing_local = _normalize_pfx_dir(local_compat)
        if existing_local:
            _add_specific(existing_local)

    # 2. Non-Steam shortcut uint_appid from Steam shortcuts.vdf
    matched_uint_ids: list[int] = []
    if sp:
        try:
            for m in find_matching_steam_shortcuts(game_name, exe_path, steam_path=sp):
                uid = int(m.get("uint_appid") or 0)
                if uid > 0 and uid not in matched_uint_ids:
                    matched_uint_ids.append(uid)
        except Exception as exc:
            logger.debug(f"{TAG} Shortcut lookup error for {game_name!r}: {exc}")

    # 3. Deterministic shortcut AppID calculation from exe_path / start_game.sh
    calc_uint_ids: list[int] = []
    clean_exe = (exe_path or "").strip().strip('"')
    if clean_exe:
        try:
            _, uid, _ = calculate_shortcut_appid(clean_exe, game_name)
            if uid > 0:
                calc_uint_ids.append(uid)
        except Exception:
            pass
    if clean_dir and os.path.isdir(clean_dir):
        start_sh = os.path.join(clean_dir, "start_game.sh")
        if os.path.isfile(start_sh):
            try:
                _, uid, _ = calculate_shortcut_appid(start_sh, game_name)
                if uid > 0 and uid not in calc_uint_ids:
                    calc_uint_ids.append(uid)
            except Exception:
                pass

    ordered_ids: list[int] = []
    for uid in matched_uint_ids + calc_uint_ids + [int(a) for a in appids if isinstance(a, int) and a > 0 and a != 480]:
        if uid not in ordered_ids:
            ordered_ids.append(uid)

    for lib in libs:
        for uid in ordered_ids:
            compat_dir = os.path.join(lib, "steamapps", "compatdata", str(uid))
            existing = _normalize_pfx_dir(compat_dir)
            if existing:
                _add_specific(existing)

    # Choose planned prefix (existing first, else deterministic Steam compatdata path)
    if specific:
        planned_prefix = specific[0]
    elif sp and ordered_ids:
        planned_prefix = os.path.join(sp, "steamapps", "compatdata", str(ordered_ids[0]), "pfx")
    elif clean_dir and os.path.isdir(clean_dir):
        planned_prefix = os.path.join(clean_dir, "compatdata", "pfx")

    # 4. Fallback existing prefixes across Steam libraries, Heroic, and ~/.wine
    fallback: list[str] = []
    for lib in libs:
        compat_root = os.path.join(lib, "steamapps", "compatdata")
        if not os.path.isdir(compat_root):
            continue
        try:
            for entry in os.listdir(compat_root):
                if entry == "0":
                    continue
                existing = _normalize_pfx_dir(os.path.join(compat_root, entry))
                if existing:
                    key = os.path.normcase(os.path.realpath(existing))
                    if key not in seen:
                        seen.add(key)
                        fallback.append(existing)
        except OSError:
            pass

    home = os.path.expanduser("~")
    for heroic_root in (
        os.path.join(home, "Games", "Heroic", "Prefixes"),
        os.path.join(home, ".wine"),
    ):
        if not os.path.isdir(heroic_root):
            continue
        if os.path.isdir(os.path.join(heroic_root, "drive_c")):
            key = os.path.normcase(os.path.realpath(heroic_root))
            if key not in seen:
                seen.add(key)
                fallback.append(heroic_root)
            continue
        try:
            for sub in os.listdir(heroic_root):
                existing = _normalize_pfx_dir(os.path.join(heroic_root, sub))
                if existing:
                    key = os.path.normcase(os.path.realpath(existing))
                    if key not in seen:
                        seen.add(key)
                        fallback.append(existing)
        except OSError:
            pass

    return specific, planned_prefix, fallback


# ------------------------------------------------------------------ Path Validation & Cross-OS Translation


def is_path_valid_for_current_os(path: str) -> bool:
    """Return False for empty strings, 'Steam Cloud', or paths belonging to a foreign OS."""
    s = (path or "").strip()
    if not s or s == "Steam Cloud":
        return False
    if sys.platform == "win32":
        # Reject POSIX absolute paths such as /home/deck/...
        if s.startswith("/") and not s.startswith("//"):
            return False
        return True
    # Linux / SteamOS: reject Windows drive paths (e.g. C:\Users\...) and UNC paths
    if re.match(r"^[A-Za-z]:[\\/]", s):
        if os.name == "nt":
            # Windows-hosted tests mocking sys.platform='linux' use tmp_path under a Windows drive
            s_norm = os.path.normpath(s).replace("\\", "/").lower()
            if any(m in s_norm for m in ("/pfx/", "/compatdata/", "/drive_c/", "/.local/", "/.config/")):
                return True
            if any(w in s_norm for w in ("/appdata/", "/my games/", "/saved games/")):
                return False
            env_home = (os.environ.get("HOME") or "").strip()
            if env_home:
                home_norm = os.path.normpath(env_home).replace("\\", "/").lower()
                if s_norm == home_norm or s_norm.startswith(home_norm + "/"):
                    return True
        return False
    if s.startswith("\\\\"):
        return False
    return True


def _extract_windows_user_relative_path(raw_path: str) -> tuple[str, str] | None:
    """Classify a Windows or Wine drive_c save path into (bucket, relative_subpath).

    Buckets: 'roaming', 'local', 'locallow', 'documents', 'saved_games', 'public', 'programdata'.
    """
    norm = raw_path.strip().replace("\\", "/")
    # Strip Proton/Wine prefix before drive_c
    m_pfx = re.search(r"/drive_c/(.+)$", norm, re.IGNORECASE)
    if m_pfx:
        inner = m_pfx.group(1)
    else:
        m_drv = re.match(r"^[A-Za-z]:/(.+)$", norm)
        if not m_drv:
            return None
        inner = m_drv.group(1)

    low = inner.lower()
    m_appdata = re.match(r"^users/[^/]+/appdata/(roaming|local|locallow)/(.+)$", low)
    if m_appdata:
        bucket = m_appdata.group(1)
        rel = inner.split("/", 4)[4].strip("/")
        if rel:
            return bucket, rel

    m_onedrive_docs = re.match(r"^users/[^/]+/onedrive/documents/(.+)$", low)
    if m_onedrive_docs:
        rel = inner.split("/", 4)[4].strip("/")
        if rel:
            return "documents", rel

    m_docs = re.match(r"^users/[^/]+/(?:documents|my documents)/(.+)$", low)
    if m_docs:
        rel = inner.split("/", 3)[3].strip("/")
        if rel:
            return "documents", rel

    m_saved = re.match(r"^users/[^/]+/saved games/(.+)$", low)
    if m_saved:
        rel = inner.split("/", 3)[3].strip("/")
        if rel:
            return "saved_games", rel

    m_pub = re.match(r"^users/public/(?:documents/)?(.+)$", low)
    if m_pub:
        prefix_parts = 3 if low.startswith("users/public/documents/") else 2
        rel = inner.split("/", prefix_parts)[prefix_parts].strip("/")
        if rel:
            return "public", rel

    m_pd = re.match(r"^programdata/(.+)$", low)
    if m_pd:
        rel = inner.split("/", 1)[1].strip("/")
        if rel:
            return "programdata", rel

    return None


def _windows_roots_for_bucket(bucket: str) -> list[str]:
    home = os.path.expanduser("~")
    docs = cfg.get_documents_dir()
    home_docs = os.path.join(home, "Documents")
    if bucket == "roaming":
        return [os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")]
    if bucket == "local":
        return [os.environ.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local")]
    if bucket == "locallow":
        return [os.path.join(home, "AppData", "LocalLow")]
    if bucket == "documents":
        out = [docs]
        if os.path.normcase(os.path.abspath(home_docs)) != os.path.normcase(os.path.abspath(docs)):
            out.append(home_docs)
        return out
    if bucket == "saved_games":
        return [os.path.join(home, "Saved Games")]
    if bucket == "public":
        pub = os.environ.get("PUBLIC") or r"C:\Users\Public"
        return [os.path.join(pub, "Documents"), pub]
    if bucket == "programdata":
        return [os.environ.get("PROGRAMDATA") or r"C:\ProgramData"]
    return []


def _proton_user_dirs(pfx_dir: str) -> list[str]:
    users_dir = os.path.join(pfx_dir, "drive_c", "users")
    out: list[str] = [os.path.join(users_dir, "steamuser")]
    if os.path.isdir(users_dir):
        try:
            for name in os.listdir(users_dir):
                low = name.lower()
                if low in ("steamuser", "public", "default", "default user", "all users"):
                    continue
                full = os.path.join(users_dir, name)
                if os.path.isdir(full):
                    out.append(full)
        except OSError:
            pass
    return out


def _proton_paths_for_bucket(pfx_dir: str, bucket: str, rel: str) -> list[str]:
    rel_os = rel.replace("/", os.sep)
    out: list[str] = []
    if bucket in ("roaming", "local", "locallow"):
        sub = {"roaming": "Roaming", "local": "Local", "locallow": "LocalLow"}[bucket]
        for udir in _proton_user_dirs(pfx_dir):
            out.append(os.path.join(udir, "AppData", sub, rel_os))
    elif bucket == "documents":
        for udir in _proton_user_dirs(pfx_dir):
            out.append(os.path.join(udir, "Documents", rel_os))
    elif bucket == "saved_games":
        for udir in _proton_user_dirs(pfx_dir):
            out.append(os.path.join(udir, "Saved Games", rel_os))
    elif bucket == "public":
        out.append(os.path.join(pfx_dir, "drive_c", "users", "Public", "Documents", rel_os))
        out.append(os.path.join(pfx_dir, "drive_c", "users", "Public", rel_os))
    elif bucket == "programdata":
        out.append(os.path.join(pfx_dir, "drive_c", "ProgramData", rel_os))
    return out


def translate_peer_save_path(
    foreign_path: str,
    game_name: str,
    exe_path: str = "",
    install_location: str = "",
    steam_appid: Any = None,
    steam_path: str | None = None,
) -> list[str]:
    """Translate a peer OS save path (Windows <-> SteamOS Proton) into local candidates."""
    raw = (foreign_path or "").strip()
    if not raw or raw == "Steam Cloud":
        return []

    if is_path_valid_for_current_os(raw):
        return [os.path.normpath(raw)]

    results: list[str] = []
    seen: set[str] = set()

    def _add(p: str) -> None:
        if not p:
            return
        norm = os.path.normpath(p)
        key = os.path.normcase(norm)
        if key not in seen and is_safe_save_dir(norm, install_location):
            seen.add(key)
            results.append(norm)

    classified = _extract_windows_user_relative_path(raw)
    if classified is not None:
        bucket, rel = classified
        if sys.platform == "win32":
            for root in _windows_roots_for_bucket(bucket):
                cand = os.path.join(root, rel.replace("/", os.sep))
                _add(cand)
        else:
            appids = discover_game_appids(game_name, install_location, exe_path, steam_appid)
            specific, planned, fallback = resolve_proton_prefixes(
                game_name, exe_path, install_location, appids=appids, steam_path=steam_path
            )
            # 1. Existing matches inside specific or fallback prefixes
            for pfx in specific + fallback:
                for cand in _proton_paths_for_bucket(pfx, bucket, rel):
                    if os.path.isdir(cand):
                        _add(cand)
            # 2. Planned path in specific/planned prefix (supports auto-makedirs on Cloud download)
            for pfx in specific or ([planned] if planned else []):
                for cand in _proton_paths_for_bucket(pfx, bucket, rel)[:1]:
                    _add(cand)

    # Portable game-folder-relative save path translation (e.g. `<other_dir>/Saves` -> `<install_location>/Saves`)
    if install_location and os.path.isdir(install_location):
        norm_raw = raw.replace("\\", "/").rstrip("/")
        parts = [p for p in norm_raw.split("/") if p]
        for marker in ("saves", "savedata", "savegames", "save"):
            low_parts = [p.lower() for p in parts]
            if marker in low_parts:
                idx = low_parts.index(marker)
                # Prefer up to 3 trailing segments (e.g. Saved/SaveGames or b1/Saved/SaveGames)
                start = max(1, idx - 2)
                for s in range(idx, start - 1, -1):
                    cand = os.path.join(install_location, *parts[s:])
                    if os.path.isdir(cand) or s == idx:
                        _add(cand)

    return results


# ------------------------------------------------------------------ Safety Guard & Disk Inspection


def is_safe_save_dir(path: str, install_location: str = "") -> bool:
    """Return False if path points to an OS/system/user root or the game's root install folder."""
    if not path or not isinstance(path, str):
        return False
    norm = os.path.normpath(os.path.abspath(path))
    norm_case = os.path.normcase(norm)

    # Drive or filesystem root
    drive, tail = os.path.splitdrive(norm)
    if tail in ("", os.sep, "/"):
        return False

    home = os.path.normcase(os.path.abspath(os.path.expanduser("~")))
    docs = os.path.normcase(os.path.abspath(cfg.get_documents_dir()))
    home_docs = os.path.normcase(os.path.join(home, "documents"))
    config_root = os.path.normcase(os.path.abspath(cfg.CONFIG_DIR))

    blocked_exact = {
        home,
        docs,
        home_docs,
        os.path.join(home_docs, "my games"),
        os.path.join(docs, "my games"),
        os.path.join(home, "desktop"),
        os.path.join(home, "downloads"),
        os.path.join(home, "saved games"),
        os.path.join(home, "appdata"),
        os.path.join(home, "appdata", "local"),
        os.path.join(home, "appdata", "roaming"),
        os.path.join(home, "appdata", "locallow"),
        os.path.join(home, ".config"),
        os.path.join(home, ".local"),
        os.path.join(home, ".local", "share"),
        config_root,
    }
    for env_key in ("APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "PUBLIC", "WINDIR", "PROGRAMFILES", "PROGRAMFILES(X86)"):
        val = os.environ.get(env_key)
        if val:
            ev = os.path.normcase(os.path.abspath(val))
            blocked_exact.add(ev)
            if env_key == "PUBLIC":
                blocked_exact.add(os.path.join(ev, "documents"))

    if norm_case in blocked_exact:
        return False

    # Never select CONFIG_DIR subtree or OS Windows/ProgramFiles roots
    try:
        if os.path.commonpath([norm_case, config_root]) == config_root:
            return False
    except ValueError:
        pass

    # Block Proton prefix roots (`.../pfx`, `.../pfx/drive_c`, `.../pfx/drive_c/users/steamuser`)
    slash_low = norm.replace("\\", "/").lower().rstrip("/")
    if re.search(
        r"/(?:pfx|drive_c|drive_c/users|drive_c/users/[^/]+|steamapps|compatdata|onlinefix|gse saves|goldberg steamemu saves)$",
        slash_low,
    ):
        return False
    if re.search(
        r"/drive_c/users/[^/]+/(?:documents|my documents|saved games|appdata|appdata/local|appdata/roaming|appdata/locallow|documents/my games)$",
        slash_low,
    ) or re.search(r"/drive_c/(?:programdata|windows|program files[^/]*)$", slash_low):
        return False

    # Never select the game's own root install_location (or a parent of it)
    if install_location:
        inst_abs = os.path.normcase(os.path.abspath(install_location))
        if norm_case == inst_abs:
            return False
        try:
            if os.path.commonpath([norm_case, inst_abs]) == norm_case:
                return False
        except ValueError:
            pass

    return True


def _inspect_dir(path: str, max_depth: int = 4, max_entries: int = 500) -> tuple[bool, bool, float, int, int]:
    """Inspect a candidate save directory up to bounded depth.

    Returns (exists, has_files, latest_mtime, file_count, total_bytes).
    """
    if not path or not os.path.isdir(path):
        return False, False, 0.0, 0, 0

    latest_mtime = 0.0
    file_count = 0
    total_bytes = 0
    walked = 0

    try:
        for root, dirs, files in os.walk(path):
            rel = os.path.relpath(root, path)
            depth = 0 if rel == "." else rel.count(os.sep) + 1
            if depth >= max_depth:
                dirs.clear()

            for fn in files:
                if fn.lower() in _IGNORED_SAVE_FILES:
                    continue
                fpath = os.path.join(root, fn)
                try:
                    st = os.stat(fpath)
                except OSError:
                    continue
                file_count += 1
                total_bytes += int(st.st_size)
                if st.st_mtime > latest_mtime:
                    latest_mtime = float(st.st_mtime)
                walked += 1
                if walked >= max_entries:
                    dirs.clear()
                    break
            if walked >= max_entries:
                break
    except OSError:
        return True, False, 0.0, 0, 0

    return True, file_count > 0, latest_mtime, file_count, total_bytes


# ------------------------------------------------------------------ Tier Generators


def _expand_store_user_id_paths(
    raw_template: str,
    roots_map: dict[str, list[str]],
    steam_path: str | None,
    allow_planned: bool,
) -> list[tuple[str, bool]]:
    """Expand a Ludusavi directory template into concrete filesystem paths.

    Returns list of (path, allow_if_missing).
    """
    # Collect ordered placeholder substitutions -> cartesian product (kept tiny)
    tokens_order = [
        "<winAppData>",
        "<winLocalAppData>",
        "<winLocalAppDataLow>",
        "<winDocuments>",
        "<winPublic>",
        "<winProgramData>",
        "<winDir>",
        "<home>",
        "<base>",
        "<root>",
        "<xdgData>",
        "<xdgConfig>",
        "<osUserName>",
    ]
    variants: list[str] = [raw_template]
    for tok in tokens_order:
        if not any(tok in v for v in variants):
            continue
        repls = roots_map.get(tok, [])
        if not repls:
            return []
        next_vars: list[str] = []
        for v in variants:
            if tok not in v:
                next_vars.append(v)
            else:
                for r in repls:
                    next_vars.append(v.replace(tok, r.replace("\\", "/").rstrip("/")))
        variants = next_vars

    out: list[tuple[str, bool]] = []
    user_ids = get_steam_user_ids(steam_path) if steam_path else []
    primary_uid = get_primary_steam_user_id(steam_path) if steam_path else None

    for v in variants:
        if "<storeUserId>" not in v and "*" not in v and "?" not in v:
            out.append((os.path.normpath(v), allow_planned))
            continue

        # Expand <storeUserId>
        if "<storeUserId>" in v:
            before, after = v.split("<storeUserId>", 1)
            parent = os.path.normpath(before.rstrip("/"))
            after_rel = after.strip("/").replace("/", os.sep)
            found_subdirs: list[str] = []
            if parent and os.path.isdir(parent):
                try:
                    for sub in sorted(os.listdir(parent)):
                        if sub == "0":
                            continue
                        sub_full = os.path.join(parent, sub, after_rel) if after_rel else os.path.join(parent, sub)
                        if os.path.isdir(sub_full):
                            found_subdirs.append(sub_full)
                except OSError:
                    pass
            if found_subdirs:
                for p in found_subdirs:
                    out.append((p, False))
                continue

            if allow_planned:
                if "<root>" in raw_template and primary_uid:
                    planned = os.path.join(parent, primary_uid, after_rel) if after_rel else os.path.join(parent, primary_uid)
                    out.append((planned, True))
                elif user_ids and "/userdata/" in v.lower():
                    planned = os.path.join(parent, user_ids[0], after_rel) if after_rel else os.path.join(parent, user_ids[0])
                    out.append((planned, True))
                elif not after_rel and parent:
                    # Drop trailing /<storeUserId> for unlaunched non-userdata paths so no placeholder remains
                    out.append((parent, True))
            continue

        # Handle interior wildcard like `App_*/Saves`: expand existing matches on disk only
        if "*" in v or "?" in v:
            import glob

            for match in sorted(glob.glob(v)):
                if os.path.isdir(match):
                    out.append((os.path.normpath(match), False))

    return out


def _tier1_emulator_and_steam_candidates(
    game_name: str,
    appids: list[int],
    install_location: str,
    specific_prefixes: list[str],
    planned_prefix: str | None,
    fallback_prefixes: list[str],
    steam_path: str | None,
    allow_planned: bool,
) -> list[tuple[str, bool]]:
    """Detect Online-Fix, Goldberg/GSE, RUNE, CODEX, FLT, EMPRESS, and Steam userdata save paths."""
    if not appids:
        return []

    is_online_fix = False
    if install_location and os.path.isdir(install_location):
        try:
            from app.core.online_fix.runner import detect_online_fix_game

            is_online_fix = bool(detect_online_fix_game(install_location).get("is_online_fix"))
        except Exception:
            pass

    results: list[tuple[str, bool]] = []
    real_appids = [a for a in appids if a != 480]
    emu_appids = real_appids or appids

    if sys.platform == "win32":
        home = os.path.expanduser("~")
        roaming = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        public = os.environ.get("PUBLIC") or r"C:\Users\Public"
        pub_docs = os.path.join(public, "Documents")
        docs = cfg.get_documents_dir()

        for aid in emu_appids:
            sid = str(aid)
            # Online-Fix (uses Public\Documents\OnlineFix\<appid>\Saves or <appid>)
            of_saves = os.path.join(pub_docs, "OnlineFix", sid, "Saves")
            of_root = os.path.join(pub_docs, "OnlineFix", sid)
            if os.path.isdir(of_saves):
                results.append((of_saves, False))
            elif os.path.isdir(of_root):
                results.append((of_root, False))
            elif allow_planned and is_online_fix and aid != 480:
                results.append((of_saves, True))

            for cand in (
                os.path.join(docs, "OnlineFix", sid, "Saves"),
                os.path.join(roaming, "Steam", "CODEX", sid, "remote"),
                os.path.join(roaming, "FLT", sid, "remote"),
                os.path.join(pub_docs, "EMPRESS", sid, "remote"),
                os.path.join(roaming, "EMPRESS", sid, "remote"),
                os.path.join(roaming, "SmartSteamEmu", sid, "remote"),
            ):
                if os.path.isdir(cand):
                    results.append((cand, False))

            for remote_dir, root_dir in (
                (os.path.join(roaming, "GSE Saves", sid, "remote"), os.path.join(roaming, "GSE Saves", sid)),
                (
                    os.path.join(roaming, "Goldberg SteamEmu Saves", sid, "remote"),
                    os.path.join(roaming, "Goldberg SteamEmu Saves", sid),
                ),
                (os.path.join(pub_docs, "Steam", "RUNE", sid, "remote"), os.path.join(pub_docs, "Steam", "RUNE", sid)),
                (os.path.join(pub_docs, "Steam", "CODEX", sid, "remote"), os.path.join(pub_docs, "Steam", "CODEX", sid)),
            ):
                if os.path.isdir(remote_dir):
                    results.append((remote_dir, False))
                elif os.path.isdir(root_dir):
                    results.append((root_dir, False))

        if steam_path:
            for uid in get_steam_user_ids(steam_path):
                for aid in real_appids:
                    for cand in (
                        os.path.join(steam_path, "userdata", uid, str(aid), "remote"),
                        os.path.join(steam_path, "userdata", uid, str(aid)),
                    ):
                        if os.path.isdir(cand):
                            results.append((cand, False))
                            break
    else:
        # SteamOS / Linux: Proton prefixes + native GSE Saves + Steam userdata
        home = os.path.expanduser("~")
        xdg_data = os.environ.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share")
        for aid in emu_appids:
            sid = str(aid)
            for remote_dir, root_dir in (
                (os.path.join(xdg_data, "GSE Saves", sid, "remote"), os.path.join(xdg_data, "GSE Saves", sid)),
                (
                    os.path.join(xdg_data, "Goldberg SteamEmu Saves", sid, "remote"),
                    os.path.join(xdg_data, "Goldberg SteamEmu Saves", sid),
                ),
            ):
                if os.path.isdir(remote_dir):
                    results.append((remote_dir, False))
                elif os.path.isdir(root_dir):
                    results.append((root_dir, False))

            search_pfx = specific_prefixes + [p for p in fallback_prefixes if p not in specific_prefixes]
            for pfx in search_pfx:
                pub_docs = os.path.join(pfx, "drive_c", "users", "Public", "Documents")
                of_saves = os.path.join(pub_docs, "OnlineFix", sid, "Saves")
                of_root = os.path.join(pub_docs, "OnlineFix", sid)
                if os.path.isdir(of_saves):
                    results.append((of_saves, False))
                elif os.path.isdir(of_root):
                    results.append((of_root, False))

                for udir in _proton_user_dirs(pfx):
                    roam = os.path.join(udir, "AppData", "Roaming")
                    for cand in (
                        os.path.join(pub_docs, "Steam", "CODEX", sid, "remote"),
                        os.path.join(roam, "Steam", "CODEX", sid, "remote"),
                        os.path.join(roam, "FLT", sid, "remote"),
                        os.path.join(pub_docs, "EMPRESS", sid, "remote"),
                        os.path.join(roam, "EMPRESS", sid, "remote"),
                    ):
                        if os.path.isdir(cand):
                            results.append((cand, False))
                    for remote_dir, root_dir in (
                        (os.path.join(roam, "GSE Saves", sid, "remote"), os.path.join(roam, "GSE Saves", sid)),
                        (
                            os.path.join(roam, "Goldberg SteamEmu Saves", sid, "remote"),
                            os.path.join(roam, "Goldberg SteamEmu Saves", sid),
                        ),
                        (os.path.join(pub_docs, "Steam", "RUNE", sid, "remote"), os.path.join(pub_docs, "Steam", "RUNE", sid)),
                    ):
                        if os.path.isdir(remote_dir):
                            results.append((remote_dir, False))
                        elif os.path.isdir(root_dir):
                            results.append((root_dir, False))

            if allow_planned and is_online_fix and aid != 480 and planned_prefix:
                planned_of = os.path.join(planned_prefix, "drive_c", "users", "Public", "Documents", "OnlineFix", sid, "Saves")
                results.append((planned_of, True))

        if steam_path:
            for uid in get_steam_user_ids(steam_path):
                for aid in real_appids:
                    for cand in (
                        os.path.join(steam_path, "userdata", uid, str(aid), "remote"),
                        os.path.join(steam_path, "userdata", uid, str(aid)),
                    ):
                        if os.path.isdir(cand):
                            results.append((cand, False))
                            break

    return results


def _tier2_database_candidates(
    db_entry: dict[str, Any],
    install_location: str,
    exe_path: str,
    specific_prefixes: list[str],
    planned_prefix: str | None,
    fallback_prefixes: list[str],
    steam_path: str | None,
    allow_planned: bool,
) -> list[tuple[str, bool]]:
    """Expand DB path templates for Windows or SteamOS/Linux."""
    base_dirs: list[str] = []
    if install_location and os.path.isdir(install_location):
        base_dirs.append(install_location)
    elif exe_path:
        ed = os.path.dirname(exe_path)
        if ed and os.path.isdir(ed):
            base_dirs.append(ed)

    templates = db_entry.get("p") or []
    results: list[tuple[str, bool]] = []

    if sys.platform == "win32":
        home = os.path.expanduser("~")
        docs = cfg.get_documents_dir()
        home_docs = os.path.join(home, "Documents")
        doc_roots = [docs]
        if os.path.normcase(os.path.abspath(home_docs)) != os.path.normcase(os.path.abspath(docs)):
            doc_roots.append(home_docs)
        roots_map: dict[str, list[str]] = {
            "<winAppData>": [os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")],
            "<winLocalAppData>": [os.environ.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local")],
            "<winLocalAppDataLow>": [os.path.join(home, "AppData", "LocalLow")],
            "<winDocuments>": doc_roots,
            "<winPublic>": [os.environ.get("PUBLIC") or r"C:\Users\Public"],
            "<winProgramData>": [os.environ.get("PROGRAMDATA") or r"C:\ProgramData"],
            "<winDir>": [os.environ.get("WINDIR") or r"C:\Windows"],
            "<home>": [home],
            "<base>": base_dirs,
            "<root>": [steam_path] if steam_path else [],
            "<osUserName>": [getpass.getuser()],
        }
        for item in templates:
            raw_tpl = item if isinstance(item, str) else item[0]
            flag = "" if isinstance(item, str) else (item[1] if len(item) > 1 else "")
            if flag == "l":
                continue
            for p, can_plan in _expand_store_user_id_paths(raw_tpl, roots_map, steam_path, allow_planned):
                results.append((p, can_plan))
        return results

    # SteamOS / Linux
    home = os.path.expanduser("~")
    xdg_data = os.environ.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share")
    xdg_cfg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")

    # Deduplicated Wine/Proton prefixes with specific first, then planned, then fallback existing
    ordered_prefixes: list[tuple[str, bool]] = []
    seen_pfx: set[str] = set()
    for pfx in specific_prefixes:
        k = os.path.normcase(pfx)
        if k not in seen_pfx:
            seen_pfx.add(k)
            ordered_prefixes.append((pfx, True))
    if planned_prefix and os.path.normcase(planned_prefix) not in seen_pfx:
        seen_pfx.add(os.path.normcase(planned_prefix))
        ordered_prefixes.append((planned_prefix, True))
    for pfx in fallback_prefixes:
        k = os.path.normcase(pfx)
        if k not in seen_pfx:
            seen_pfx.add(k)
            ordered_prefixes.append((pfx, False))

    for item in templates:
        raw_tpl = item if isinstance(item, str) else item[0]
        flag = "" if isinstance(item, str) else (item[1] if len(item) > 1 else "")
        low_tpl = raw_tpl.lower()

        is_win_home_subpath = any(
            m in low_tpl for m in ("/appdata/", "/saved games", "/my games", "/documents/")
        )

        # Native Linux path expansion
        if flag in ("", "l") and not is_win_home_subpath:
            native_roots = {
                "<home>": [home],
                "<xdgData>": [xdg_data],
                "<xdgConfig>": [xdg_cfg],
                "<base>": base_dirs,
                "<root>": [steam_path] if steam_path else [],
                "<osUserName>": [getpass.getuser()],
            }
            for p, can_plan in _expand_store_user_id_paths(raw_tpl, native_roots, steam_path, allow_planned):
                results.append((p, can_plan))

        # Windows/Proton template expansion across prefixes
        if flag in ("", "w"):
            for pfx, is_target_pfx in ordered_prefixes:
                udirs = _proton_user_dirs(pfx) if os.path.isdir(pfx) else [os.path.join(pfx, "drive_c", "users", "steamuser")]
                win_roots = {
                    "<winAppData>": [os.path.join(u, "AppData", "Roaming") for u in udirs],
                    "<winLocalAppData>": [os.path.join(u, "AppData", "Local") for u in udirs],
                    "<winLocalAppDataLow>": [os.path.join(u, "AppData", "LocalLow") for u in udirs],
                    "<winDocuments>": [os.path.join(u, "Documents") for u in udirs],
                    "<winPublic>": [os.path.join(pfx, "drive_c", "users", "Public")],
                    "<winProgramData>": [os.path.join(pfx, "drive_c", "ProgramData")],
                    "<winDir>": [os.path.join(pfx, "drive_c", "windows")],
                    "<home>": udirs if is_win_home_subpath or flag == "w" else [],
                    "<base>": base_dirs if pfx == ordered_prefixes[0][0] else [],
                    "<root>": [steam_path] if (steam_path and pfx == ordered_prefixes[0][0]) else [],
                    "<osUserName>": ["steamuser"],
                }
                can_plan_here = bool(allow_planned and is_target_pfx)
                for p, can_plan in _expand_store_user_id_paths(raw_tpl, win_roots, steam_path, can_plan_here):
                    results.append((p, can_plan and is_target_pfx))

    return results


def _tier3_engine_candidates(
    install_location: str,
    exe_path: str,
    specific_prefixes: list[str],
    planned_prefix: str | None,
    fallback_prefixes: list[str],
    allow_planned: bool,
) -> list[tuple[str, bool]]:
    """Detect save paths via engine signatures (Unity, Unreal Engine, Ren'Py, RPG Maker, portable)."""
    game_dir = install_location if (install_location and os.path.isdir(install_location)) else ""
    if not game_dir and exe_path:
        ed = os.path.dirname(exe_path)
        if ed and os.path.isdir(ed):
            game_dir = ed
    if not game_dir:
        return []

    results: list[tuple[str, bool]] = []

    def _emit_app_subpath(bucket: str, rel: str, allow_missing: bool) -> None:
        if sys.platform == "win32":
            for root in _windows_roots_for_bucket(bucket):
                results.append((os.path.join(root, rel.replace("/", os.sep)), allow_missing))
        else:
            for pfx in specific_prefixes + fallback_prefixes:
                for p in _proton_paths_for_bucket(pfx, bucket, rel):
                    if os.path.isdir(p):
                        results.append((p, False))
            target_pfx = specific_prefixes[0] if specific_prefixes else planned_prefix
            if allow_missing and target_pfx:
                for p in _proton_paths_for_bucket(target_pfx, bucket, rel)[:1]:
                    results.append((p, True))

    try:
        top_entries = os.listdir(game_dir)
    except OSError:
        top_entries = []

    # 1. Unity (`*_Data/app.info` -> Company\nProduct)
    for entry in top_entries:
        if entry.lower().endswith("_data") and os.path.isdir(os.path.join(game_dir, entry)):
            app_info = os.path.join(game_dir, entry, "app.info")
            if os.path.isfile(app_info):
                try:
                    with open(app_info, "r", encoding="utf-8", errors="replace") as f:
                        lines = [ln.strip() for ln in f.read().splitlines() if ln.strip()]
                    if len(lines) >= 2:
                        company, product = lines[0], lines[1]
                        rel_unity = f"{company}/{product}"
                        _emit_app_subpath("locallow", rel_unity, allow_planned)
                        if sys.platform != "win32":
                            xdg_cfg = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
                            native_u = os.path.join(xdg_cfg, "unity3d", company, product)
                            if os.path.isdir(native_u):
                                results.append((native_u, False))
                except OSError:
                    pass

    # 2. Unreal Engine (`<Proj>/Content/Paks` or `*/Binaries/Win64/*-Shipping.exe`)
    unreal_projects: list[str] = []
    for entry in top_entries:
        if entry.lower() in _UNREAL_ENGINE_SKIP_DIRS:
            continue
        sub = os.path.join(game_dir, entry)
        if not os.path.isdir(sub):
            continue
        if os.path.isdir(os.path.join(sub, "Content", "Paks")) or os.path.isdir(os.path.join(sub, "Saved", "SaveGames")):
            unreal_projects.append(entry)
    if not unreal_projects and exe_path:
        m_ue = re.search(r"[/\\]([^/\\]+)[/\\]Binaries[/\\]Win(?:64|32)[/\\]", exe_path, re.IGNORECASE)
        if m_ue and m_ue.group(1).lower() not in _UNREAL_ENGINE_SKIP_DIRS:
            unreal_projects.append(m_ue.group(1))
    for proj in unreal_projects:
        _emit_app_subpath("local", f"{proj}/Saved/SaveGames", allow_planned)
        portable_ue = os.path.join(game_dir, proj, "Saved", "SaveGames")
        if os.path.isdir(portable_ue):
            results.append((portable_ue, False))

    # 3. Ren'Py
    if os.path.isdir(os.path.join(game_dir, "renpy")):
        renpy_saves = os.path.join(game_dir, "game", "saves")
        if os.path.isdir(renpy_saves) or allow_planned:
            results.append((renpy_saves, allow_planned))

    # 4. RPG Maker (MV/MZ `www/save` or XP/VX/Ace `save`)
    if os.path.isfile(os.path.join(game_dir, "www", "js", "rpg_core.js")) or os.path.isdir(os.path.join(game_dir, "www")):
        rpg_www_save = os.path.join(game_dir, "www", "save")
        if os.path.isdir(rpg_www_save) or allow_planned:
            results.append((rpg_www_save, allow_planned))

    # 5. Existing portable save directories inside game_dir
    for pname in ("Saves", "SaveData", "SaveGames", "saves", "save", "Profile", "userdata"):
        cand = os.path.join(game_dir, pname)
        if os.path.isdir(cand):
            results.append((cand, False))

    return results


def _tier4_existing_name_heuristics(
    game_name: str,
    specific_prefixes: list[str],
    fallback_prefixes: list[str],
) -> list[tuple[str, bool]]:
    """Search depth 1-2 under standard user save roots for folders matching game_name."""
    clean = clean_catalog_lookup_title(game_name)
    q_keys = title_match_keys(clean)
    if not q_keys or max((len(k) for k in q_keys), default=0) < 4:
        return []

    search_roots: list[str] = []
    if sys.platform == "win32":
        home = os.path.expanduser("~")
        docs = cfg.get_documents_dir()
        search_roots.extend([
            os.path.join(home, "Saved Games"),
            os.path.join(docs, "My Games"),
            docs,
            os.path.join(home, "Documents", "My Games"),
            os.path.join(home, "Documents"),
            os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming"),
            os.environ.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local"),
            os.path.join(home, "AppData", "LocalLow"),
        ])
    else:
        home = os.path.expanduser("~")
        search_roots.extend([
            os.environ.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share"),
            os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config"),
        ])
        for pfx in specific_prefixes + fallback_prefixes[:15]:
            for udir in _proton_user_dirs(pfx):
                search_roots.extend([
                    os.path.join(udir, "Saved Games"),
                    os.path.join(udir, "Documents", "My Games"),
                    os.path.join(udir, "Documents"),
                    os.path.join(udir, "AppData", "Roaming"),
                    os.path.join(udir, "AppData", "Local"),
                    os.path.join(udir, "AppData", "LocalLow"),
                ])

    hits: list[tuple[str, bool]] = []
    seen_roots: set[str] = set()
    for sroot in search_roots:
        if not sroot or not os.path.isdir(sroot):
            continue
        real_root = os.path.realpath(sroot)
        rk = os.path.normcase(real_root)
        if rk in seen_roots:
            continue
        seen_roots.add(rk)
        try:
            level1 = os.listdir(real_root)
        except OSError:
            continue

        for d1 in level1:
            p1 = os.path.join(real_root, d1)
            if not os.path.isdir(p1):
                continue
            d1_keys = title_match_keys(d1)
            if d1_keys & q_keys:
                hits.append((p1, False))
                continue
            # Check depth 2 (`Publisher/Game` e.g. `FromSoftware/EldenRing`)
            try:
                level2 = os.listdir(p1)
            except OSError:
                continue
            for d2 in level2:
                p2 = os.path.join(p1, d2)
                if not os.path.isdir(p2):
                    continue
                if title_match_keys(d2) & q_keys:
                    hits.append((p2, False))
                    break

    return hits


# ------------------------------------------------------------------ Public API


def detect_save_candidates(
    game_name: str,
    exe_path: str = "",
    install_location: str = "",
    steam_appid: Any = None,
    peer_cloud_paths: Iterable[str] | None = None,
    allow_planned: bool = True,
    steam_path: str | None = None,
) -> list[SaveCandidate]:
    """Detect and rank candidate save directories for a game on Windows or SteamOS/Linux."""
    t0 = time.monotonic()
    clean_name = (game_name or "").strip()
    if not clean_name and exe_path:
        clean_name = os.path.splitext(os.path.basename(exe_path))[0]

    sp = steam_path or find_steam_path()
    eff_install = install_location or (os.path.dirname(exe_path) if exe_path else "")

    appids = discover_game_appids(clean_name, eff_install, exe_path, explicit_appid=steam_appid)
    install_dirname = os.path.basename(eff_install.rstrip("\\/")) if eff_install else ""

    db = get_save_db()
    db_match = db.find_match(clean_name, appids=appids, install_dirname=install_dirname)
    if db_match and db_match[2].get("a"):
        db_aid = int(db_match[2]["a"])
        if db_aid not in appids:
            appids.append(db_aid)

    specific_prefixes, planned_prefix, fallback_prefixes = resolve_proton_prefixes(
        clean_name, exe_path=exe_path, install_location=eff_install, appids=appids, steam_path=sp
    )

    raw_by_tier: list[tuple[str, list[tuple[str, bool]]]] = []

    # Tier 0: Peer-OS Cloud path translation
    peer_cands: list[tuple[str, bool]] = []
    for pp in peer_cloud_paths or ():
        for translated in translate_peer_save_path(
            pp,
            clean_name,
            exe_path=exe_path,
            install_location=eff_install,
            steam_appid=appids[0] if appids else steam_appid,
            steam_path=sp,
        ):
            peer_cands.append((translated, allow_planned))
    if peer_cands:
        raw_by_tier.append(("cloud_peer", peer_cands))

    # Tier 1: Online-Fix / Steam Emulators / Steam userdata
    emu_cands = _tier1_emulator_and_steam_candidates(
        clean_name, appids, eff_install, specific_prefixes, planned_prefix, fallback_prefixes, sp, allow_planned
    )
    if emu_cands:
        raw_by_tier.append(("emulator", emu_cands))

    # Tier 2: Bundled / OTA Save Locations Database
    if db_match:
        db_cands = _tier2_database_candidates(
            db_match[2], eff_install, exe_path, specific_prefixes, planned_prefix, fallback_prefixes, sp, allow_planned
        )
        if db_cands:
            raw_by_tier.append(("database", db_cands))

    # Tier 3: Engine metadata heuristics
    eng_cands = _tier3_engine_candidates(
        eff_install, exe_path, specific_prefixes, planned_prefix, fallback_prefixes, allow_planned
    )
    if eng_cands:
        raw_by_tier.append(("engine", eng_cands))

    # Tier 4: Existing local folder name heuristics
    heur_cands = _tier4_existing_name_heuristics(clean_name, specific_prefixes, fallback_prefixes)
    if heur_cands:
        raw_by_tier.append(("heuristic", heur_cands))

    best_by_path: dict[str, SaveCandidate] = {}

    for source, pairs in raw_by_tier:
        base_score = _SOURCE_BASE_SCORES.get(source, 50.0)
        label = _SOURCE_LABELS.get(source, source)
        for cand_path, allow_missing in pairs:
            if not cand_path or not is_path_valid_for_current_os(cand_path):
                continue
            norm = os.path.normpath(cand_path)
            if not is_safe_save_dir(norm, eff_install):
                logger.debug(f"{TAG} Rejected unsafe candidate for {clean_name!r}: {norm}")
                continue

            exists, has_files, latest_mtime, file_count, total_bytes = _inspect_dir(norm)
            if not exists and not (allow_planned and allow_missing):
                continue

            key = os.path.normcase(os.path.realpath(norm) if exists else norm)
            score = base_score
            if exists and has_files:
                score += 500.0
            elif exists:
                score += 200.0
            if specific_prefixes and any(key.startswith(os.path.normcase(os.path.realpath(p))) for p in specific_prefixes if os.path.isdir(p)):
                score += 15.0

            prev = best_by_path.get(key)
            if prev is None or score > prev.score:
                best_by_path[key] = SaveCandidate(
                    path=norm,
                    exists=exists,
                    has_files=has_files,
                    latest_mtime=latest_mtime,
                    file_count=file_count,
                    total_bytes=total_bytes,
                    source=source,
                    label=label,
                    score=score,
                )

    candidates = list(best_by_path.values())
    # Drop parent/child duplicates only when both don't have distinct files; prefer folders with newer files
    candidates.sort(
        key=lambda c: (
            2 if (c.exists and c.has_files) else (1 if c.exists else 0),
            c.latest_mtime if (c.exists and c.has_files) else 0.0,
            c.score,
            -len(c.path),
        ),
        reverse=True,
    )

    elapsed = time.monotonic() - t0
    logger.debug(
        f"{TAG} Detected {len(candidates)} candidate(s) for {clean_name!r} in {elapsed:.3f}s "
        f"(db={'hit:' + db_match[0] if db_match else 'miss'}, appids={appids})"
    )
    return candidates


def detect_best_save_path(
    game_name: str,
    exe_path: str = "",
    install_location: str = "",
    steam_appid: Any = None,
    peer_cloud_paths: Iterable[str] | None = None,
    allow_planned: bool = True,
    steam_path: str | None = None,
) -> Optional[SaveCandidate]:
    """Return the highest-ranked SaveCandidate for a game (newest save files first)."""
    candidates = detect_save_candidates(
        game_name=game_name,
        exe_path=exe_path,
        install_location=install_location,
        steam_appid=steam_appid,
        peer_cloud_paths=peer_cloud_paths,
        allow_planned=allow_planned,
        steam_path=steam_path,
    )
    return candidates[0] if candidates else None
