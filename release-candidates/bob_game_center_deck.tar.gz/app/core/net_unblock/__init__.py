"""
Network Unblock — bypass ISP blocking (DNS poisoning / SNI filtering) for selected sites.

Layers (all driverless, Qt-free):
  0. Diagnose  – read-only per-host classification (OK / DNS_POISON / SNI_RST / IP_BLACKHOLE ...)
  1. DoH + hosts – resolve through DNS-over-HTTPS, validate IPs by real TLS handshake, write a
                   marker-delimited block into the Windows hosts file
  2. Split proxy – local HTTP-CONNECT proxy + PAC that fragments the TLS ClientHello inside the SNI

Importing this package must stay cheap and side-effect free.
"""
