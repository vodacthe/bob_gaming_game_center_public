"""
Hosts-file management: a single marker-delimited block, everything else is left byte-for-byte untouched.

  # BEGIN BobGaming (managed ...)
  151.101.65.140 reddit.com
  # END BobGaming

* Works on raw bytes: BOM, line endings and a missing trailing newline of the user's file are preserved.
* Lines the user wrote themselves for the same host are never duplicated: they are reported as
  manual-ok / manual-stale and only commented out (prefix "#BG-took-over# ") on an explicit take-over.
* `plan()` is a dry run; `apply()` takes a backup, writes in place (keeps the file ACL) and verifies.
* Guards: public IPv4 only, host deny-list (Microsoft/AV domains), at most 2 IPs per host, 200 lines.
"""

from __future__ import annotations

import hashlib
import logging
import os
import stat
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable

from app.core.net_unblock.doh import usable_ip
from app.core.net_unblock.paths import assert_safe_for_tests, real_hosts_path, same_path, running_under_test
from app.core.net_unblock.presets import is_denied

logger = logging.getLogger(__name__)

BEGIN = b"# BEGIN BobGaming"
END = b"# END BobGaming"
TOOK_OVER = b"#BG-took-over# "
MAX_BLOCK_HOSTS = 200
MAX_IPS_PER_HOST = 2
MAX_FILE_BYTES = 1_000_000
BACKUPS_KEEP = 5


class HostsError(Exception):
    pass


class HostsChanged(HostsError):
    """The file changed between plan() and apply()."""


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass
class HostsView:
    raw: bytes
    bom: bytes
    eol: bytes
    has_trailing_eol: bool
    block_span: tuple[int, int] | None          # [start, end) of the managed block (END line + its EOL included)
    damaged: bool                                # BEGIN without END (or END without BEGIN)
    managed: dict = field(default_factory=dict)  # host -> [ip, ...] currently in our block
    manual: dict = field(default_factory=dict)   # host -> [(ip, line_start, line_end, multi_name)] outside the block
    took_over: int = 0


@dataclass
class HostsPlan:
    base_sha: str
    new_bytes: bytes
    wanted: dict                                 # host -> [ip, ...] that end up in the block
    skipped: dict = field(default_factory=dict)  # host -> reason (manual-ok, manual-stale, denied, ...)
    took_over: list = field(default_factory=list)
    added_eol: bool = False

    @property
    def changed(self) -> bool:
        return sha256(self.new_bytes) != self.base_sha


@dataclass
class ApplyResult:
    before_sha: str
    after_sha: str
    backup: str
    added_eol: bool
    took_over: list = field(default_factory=list)


def _detect_eol(raw: bytes) -> bytes:
    crlf = raw.count(b"\r\n")
    lf = raw.count(b"\n") - crlf
    return b"\r\n" if crlf >= lf else b"\n"


def _iter_lines(raw: bytes):
    """Yield (start, end_without_eol, end_with_eol) for every line of `raw`."""
    pos = 0
    n = len(raw)
    while pos < n:
        nl = raw.find(b"\n", pos)
        if nl == -1:
            yield pos, n, n
            return
        end = nl - 1 if nl > pos and raw[nl - 1:nl] == b"\r" else nl
        yield pos, end, nl + 1
        pos = nl + 1


class HostsManager:
    def __init__(self, path: str | None, backup_dir: str,
                 flush: Callable[[], bool] | None = None, sleep: Callable[[float], None] = time.sleep):
        self.path = path or real_hosts_path()
        if running_under_test() and same_path(self.path, real_hosts_path()):
            assert_safe_for_tests("the real hosts file")
        self.backup_dir = backup_dir
        self._flush = flush
        self._sleep = sleep

    # ---- reading ----------------------------------------------------------------------------
    def read_bytes(self) -> bytes:
        try:
            with open(self.path, "rb") as f:
                return f.read()
        except FileNotFoundError:
            return b""

    def view(self, raw: bytes | None = None) -> HostsView:
        raw = self.read_bytes() if raw is None else raw
        bom = b"\xef\xbb\xbf" if raw.startswith(b"\xef\xbb\xbf") else b""
        eol = _detect_eol(raw) if raw else b"\r\n"
        view = HostsView(raw=raw, bom=bom, eol=eol, has_trailing_eol=raw.endswith(b"\n"),
                         block_span=None, damaged=False)

        begin_at = end_at = None
        for start, end, nxt in _iter_lines(raw):
            text = raw[start:end].strip()
            if text.startswith(BEGIN) and begin_at is None:
                begin_at = start
            elif text == END and begin_at is not None and end_at is None:
                end_at = nxt
        if begin_at is not None and end_at is not None:
            view.block_span = (begin_at, end_at)
        elif begin_at is not None or any(raw[s:e].strip() == END for s, e, _ in _iter_lines(raw)):
            view.damaged = True

        for start, end, nxt in _iter_lines(raw):
            line = raw[start:end]
            stripped = line.strip()
            if view.block_span and view.block_span[0] <= start < view.block_span[1]:
                if stripped and not stripped.startswith(b"#"):
                    parts = stripped.split()
                    if len(parts) >= 2:
                        for name in parts[1:]:
                            view.managed.setdefault(name.decode("ascii", "ignore").lower(), []).append(
                                parts[0].decode("ascii", "ignore"))
                continue
            if stripped.startswith(TOOK_OVER.strip()):
                view.took_over += 1
                continue
            if not stripped or stripped.startswith(b"#"):
                continue
            body = stripped.split(b"#", 1)[0].split()
            if len(body) < 2:
                continue
            ip = body[0].decode("ascii", "ignore")
            multi = len(body) > 2
            for name in body[1:]:
                host = name.decode("ascii", "ignore").lower()
                view.manual.setdefault(host, []).append((ip, start, nxt, multi))
        return view

    # ---- planning ---------------------------------------------------------------------------
    def plan(self, wanted: dict[str, list[str]], *, manual_status: dict[str, str] | None = None,
             takeover: set[str] | None = None, stamp: str | None = None,
             prior_added_eol: bool = False) -> HostsPlan:
        """Dry run: compute the new file bytes for `wanted` (host -> candidate IPs). Never writes.

        manual_status maps hosts that already have a user-written line to "ok" or "stale".
        prior_added_eol: a previous apply already appended the EOL that precedes our block, so the
        returned plan keeps reporting it (sticky) and removal can strip it again.
        """
        raw = self.read_bytes()
        view = self.view(raw)
        if view.damaged:
            raise HostsError("hosts file has a damaged BobGaming block (BEGIN without END); refusing to edit")
        manual_status = manual_status or {}
        takeover = takeover or set()

        final: dict[str, list[str]] = {}
        skipped: dict[str, str] = {}
        took: list[str] = []
        for host, ips in wanted.items():
            host = host.lower()
            if is_denied(host):
                skipped[host] = "denied (protected domain)"
                continue
            good = [ip for ip in ips if usable_ip(ip)][:MAX_IPS_PER_HOST]
            if not good:
                skipped[host] = "no valid public IPv4 address"
                continue
            if host in view.manual:
                status = manual_status.get(host, "ok")
                lines = view.manual[host]
                if status == "ok":
                    skipped[host] = "manual-ok"
                    continue
                if host not in takeover:
                    skipped[host] = "manual-stale"
                    continue
                if any(multi for _ip, _s, _e, multi in lines):
                    skipped[host] = "manual-stale (shared line, left untouched)"
                    continue
                took.append(host)
            final[host] = good
        if len(final) > MAX_BLOCK_HOSTS:
            raise HostsError(f"too many hosts for the hosts file ({len(final)} > {MAX_BLOCK_HOSTS})")

        # 1) comment out taken-over manual lines (reverse order keeps earlier offsets valid)
        data = raw
        for host in took:
            current = self.view(data)
            for _ip, start, _nxt, _multi in sorted(current.manual.get(host, []), key=lambda t: t[1], reverse=True):
                data = data[:start] + TOOK_OVER + data[start:]
        # 2) drop the old block (if any)
        view = self.view(data)
        added_eol = False
        if view.block_span:
            s, e = view.block_span
            data = data[:s] + data[e:]
            added_eol = prior_added_eol
        # 3) append the new block
        if final:
            eol = view.eol
            if data and not data.endswith(b"\n"):
                data += eol
                added_eol = True
            stamp = stamp or datetime.now().strftime("%Y-%m-%d %H:%M")
            lines = [BEGIN + b" (managed by Bob Gaming Game Center - remove with its Restore button)",
                     b"# updated " + stamp.encode("ascii")]
            for host in sorted(final):
                for ip in final[host]:
                    lines.append(f"{ip} {host}".encode("ascii"))
            lines.append(END)
            data += eol.join(lines) + eol
        else:
            data = self._untake(data)
            if added_eol and data.endswith(view.eol):
                data = data[:-len(view.eol)]
                added_eol = False
        if len(data) > MAX_FILE_BYTES:
            raise HostsError("hosts file would exceed 1 MB; refusing")
        return HostsPlan(base_sha=sha256(raw), new_bytes=data, wanted=final, skipped=skipped,
                         took_over=took, added_eol=added_eol)

    def plan_removal(self, strip_added_eol: bool = False) -> HostsPlan:
        """Plan that removes our block and restores taken-over lines."""
        raw = self.read_bytes()
        view = self.view(raw)
        if view.damaged:
            raise HostsError("hosts file has a damaged BobGaming block; refusing to edit")
        data = raw
        if view.block_span:
            s, e = view.block_span
            data = data[:s] + data[e:]
        data = self._untake(data)
        if strip_added_eol and view.block_span:
            eol = view.eol
            if data.endswith(eol):
                data = data[:-len(eol)]
        return HostsPlan(base_sha=sha256(raw), new_bytes=data, wanted={})

    @staticmethod
    def _untake(data: bytes) -> bytes:
        if TOOK_OVER not in data:
            return data
        out = []
        for start, _end, nxt in _iter_lines(data):
            line = data[start:nxt]
            lead = len(line) - len(line.lstrip())
            if line[lead:].startswith(TOOK_OVER):
                line = line[:lead] + line[lead + len(TOOK_OVER):]
            out.append(line)
        return b"".join(out)

    # ---- applying ---------------------------------------------------------------------------
    def backup(self) -> str:
        """Copy the current hosts file to <backup_dir>/hosts.bobgaming.bak-<ts> (deduplicated, 5 kept)."""
        raw = self.read_bytes()
        os.makedirs(self.backup_dir, exist_ok=True)
        existing = sorted(n for n in os.listdir(self.backup_dir) if n.startswith("hosts.bobgaming.bak-"))
        if existing:
            last = os.path.join(self.backup_dir, existing[-1])
            try:
                with open(last, "rb") as f:
                    if sha256(f.read()) == sha256(raw):
                        return last
            except OSError:
                pass
        name = "hosts.bobgaming.bak-" + datetime.now().strftime("%Y%m%d-%H%M%S")
        path = os.path.join(self.backup_dir, name)
        with open(path, "wb") as f:
            f.write(raw)
        for old in existing[: max(0, len(existing) + 1 - BACKUPS_KEEP)]:
            try:
                os.remove(os.path.join(self.backup_dir, old))
            except OSError:
                pass
        return path

    def apply(self, plan: HostsPlan, *, backup: bool = True) -> ApplyResult:
        current = self.read_bytes()
        if sha256(current) != plan.base_sha:
            raise HostsChanged("hosts file changed since the plan was made")
        backup_path = self.backup() if backup else ""
        if plan.new_bytes != current:
            self._write_in_place(plan.new_bytes)
            written = self.read_bytes()
            if written != plan.new_bytes:
                raise HostsError("hosts file did not contain the expected bytes after writing")
        if self._flush is not None:
            try:
                self._flush()
            except Exception as e:
                logger.warning(f"[NetUnblock] DNS cache flush failed: {e}")
        return ApplyResult(before_sha=plan.base_sha, after_sha=sha256(plan.new_bytes), backup=backup_path,
                           added_eol=plan.added_eol, took_over=list(plan.took_over))

    def restore_raw(self, data: bytes) -> None:
        """Write exactly `data` (e.g. a verified backup) with the same safe in-place writer, then flush DNS."""
        self._write_in_place(data)
        if self._flush is not None:
            try:
                self._flush()
            except Exception as e:
                logger.warning(f"[NetUnblock] DNS cache flush failed: {e}")

    def _write_in_place(self, data: bytes) -> None:
        """r+b rewrite (keeps ACL/ownership); clears and restores the read-only attribute; retries AV locks."""
        mode = os.stat(self.path).st_mode if os.path.exists(self.path) else None
        readonly = mode is not None and not mode & stat.S_IWRITE
        if readonly:
            os.chmod(self.path, mode | stat.S_IWRITE)
        last_error: Exception | None = None
        try:
            for attempt in range(3):
                try:
                    with open(self.path, "r+b" if mode is not None else "wb") as f:
                        f.seek(0)
                        f.write(data)
                        f.truncate()
                        f.flush()
                        os.fsync(f.fileno())
                    return
                except PermissionError as e:       # antivirus scanners hold the file briefly
                    last_error = e
                    self._sleep(0.25 * (attempt + 1))
            raise HostsError(f"cannot write the hosts file (permission denied / locked): {last_error}")
        finally:
            if readonly:
                try:
                    os.chmod(self.path, stat.S_IREAD)
                except OSError:
                    pass

    def remove_block(self, strip_added_eol: bool = False) -> ApplyResult | None:
        """Remove our block (and restore taken-over lines). Returns None when there was nothing to do."""
        plan = self.plan_removal(strip_added_eol=strip_added_eol)
        if plan.new_bytes == self.read_bytes():
            return None
        return self.apply(plan)
