"""
NetUnblockManager — orchestrates the three layers and is the only object the UI / main window talks to.

    Diagnose (read-only)  ->  per host the MINIMUM fix:
        DNS_POISON      hosts block with TLS-validated IPs (+ getaddrinfo self-test, auto-rollback)
        SNI_RST         local split proxy + PAC (self-tested through CONNECT before the PAC is installed)
        OK              untouched
        IP_BLACKHOLE    reported (needs a VPN / WARP)

Every system change is journaled first (journal.py) so a killed process can be repaired on the next start.
Blocking methods take a progress callback `(done, total, message)` and a `threading.Event` for cancel and must run
off the GUI thread. One RLock serialises every mutation.
"""

from __future__ import annotations

import logging
import os
import secrets
import threading
import time
from typing import Callable

from app.core.net_unblock import sysproxy
from app.core.net_unblock.diagnose import check_online, diagnose_hosts
from app.core.net_unblock.doh import DohResolver, system_resolve, usable_ip
from app.core.net_unblock.dpi_engine import ANTICHEAT_PROCESSES, DpiEngine
from app.core.net_unblock.hosts_manager import HostsError, HostsManager, HostsView, sha256
from app.core.net_unblock.journal import Journal, JournalStore, recover_on_start
from app.core.net_unblock.models import (
    DiagnosisResult, EngineState, EngineStatus, HostRow, HostStatus, Strategy, Target, Verdict,
)
from app.core.net_unblock.paths import NetPaths, assert_safe_for_tests, default_paths
from app.core.net_unblock.presets import GROUPS, is_denied
from app.core.net_unblock.proxy import SplitProxy, StrategyCache
from app.core.net_unblock.scanner import scan_host
from app.core.net_unblock.settings import NetSettings, SettingsStore
from app.core.net_unblock.tls import CONTROL_SNI, tls_probe

logger = logging.getLogger(__name__)

Progress = Callable[[int, int, str], None]

MAX_FAILURES = 3            # an applied host is dropped after this many failed re-scans
SELFTEST_HOSTS = 3          # hosts fetched through the proxy before the PAC is installed
MODE_HOSTS, MODE_PROXY, MODE_BOTH, MODE_DPI = "hosts", "proxy", "both", "dpi"
_APPLIED_STATUS = {MODE_HOSTS: HostStatus.APPLIED_HOSTS, MODE_PROXY: HostStatus.APPLIED_PROXY,
                   MODE_BOTH: HostStatus.APPLIED_BOTH, MODE_DPI: HostStatus.APPLIED_DPI}

__all__ = ["NetUnblockManager", "recover_on_start", "restore_all"]


class NetUnblockManager:
    def __init__(self, paths: NetPaths | None = None, system=None, resolver=None, probe=None,
                 resolve_system=None, settings_store: SettingsStore | None = None, clock=time.time,
                 online: Callable[[], bool] = check_online, proxy_factory=SplitProxy, dpi_factory=DpiEngine):
        if paths is None:
            assert_safe_for_tests("NetUnblockManager default paths")
            paths = default_paths()
        self.paths = paths
        self._system = system
        self._resolver = resolver
        self._probe = probe or tls_probe
        self._resolve_system = resolve_system or system_resolve
        self._store = settings_store or SettingsStore(paths.settings)
        self._clock = clock
        self._online = online
        self._proxy_factory = proxy_factory
        self._dpi_factory = dpi_factory
        self._lock = threading.RLock()
        self._proxy: SplitProxy | None = None
        self._dpi: DpiEngine | None = None
        self._journal_obj: Journal | None = None
        self._warnings: list[str] = []
        self._hosts = HostsManager(paths.hosts, os.path.join(paths.state_dir, "backups"),
                                   flush=lambda: self.system.flush_dns())

    # ---- collaborators (created lazily so importing / constructing stays side-effect free) -----------
    @property
    def system(self):
        if self._system is None:
            from app.core.net_unblock.system import SystemOps
            self._system = SystemOps()
        return self._system

    @property
    def resolver(self):
        if self._resolver is None:
            self._resolver = DohResolver()
        return self._resolver

    @property
    def journal(self) -> Journal:
        if self._journal_obj is None:
            self._journal_obj = Journal(JournalStore(self.paths.journal))
        return self._journal_obj

    @property
    def settings(self) -> NetSettings:
        return self._store.data

    def save_settings(self) -> bool:
        return self._store.save()

    def delete_settings(self) -> None:
        """Forget every preference and learned state (factory reset). Call restore_all() first."""
        self._store.delete()

    def is_admin(self) -> bool:
        try:
            return bool(self.system.is_admin())
        except Exception:
            return False

    # ---- status -------------------------------------------------------------------------------------
    def status(self) -> EngineStatus:
        """Cheap snapshot (no I/O, no lock) — safe to call from a GUI timer."""
        s = self.settings
        proxy = self._proxy
        alive = proxy is not None and proxy.is_alive()
        hosts_n = sum(1 for a in s.applied.values() if a.get("mode") in (MODE_HOSTS, MODE_BOTH))
        proxy_hosts = [h for h, a in s.applied.items() if a.get("mode") in (MODE_PROXY, MODE_BOTH)]
        admin = self.is_admin()
        all_sites = bool(s.all_sites_active)
        needs_proxy = bool(proxy_hosts) or all_sites
        dpi = self._dpi
        dpi_on = dpi is not None and dpi.is_alive()
        if not s.applied and not all_sites and not s.dpi_active:
            state = EngineState.OFF if admin else EngineState.NOT_ADMIN
        elif s.dpi_active and not dpi_on:
            state = EngineState.DEGRADED
        elif needs_proxy and (not alive or proxy.degraded):
            state = EngineState.DEGRADED
        elif needs_proxy or dpi_on:
            state = EngineState.ACTIVE
        else:
            state = EngineState.HOSTS_ONLY
        return EngineStatus(state=state, hosts_applied=hosts_n, proxy_port=proxy.port if alive else None,
                            proxy_hosts=len(proxy.domains) if alive else 0, warnings=list(self._warnings),
                            last_refresh=s.last_refresh or None, is_admin=admin, all_sites=all_sites,
                            dpi=dpi_on, dpi_preset=dpi.preset.id if dpi_on else "")

    def view_changes(self) -> str:
        """Plain-text list of what Network Unblock currently has applied on this PC."""
        lines: list[str] = []
        try:
            view = self._hosts.view()
        except OSError as e:
            return f"(cannot read the hosts file: {e})"
        if view.damaged:
            lines.append("Hosts file: damaged BobGaming block (BEGIN without END)")
        elif view.managed:
            entries = [f"{ip} {host}" for host, ips in sorted(view.managed.items()) for ip in ips]
            lines.append(f"Hosts file: block with {len(entries)} entries")
            lines += [f"  {e}" for e in entries]
        else:
            lines.append("Hosts file: no block")
        if view.took_over:
            lines.append(f"Hosts file: {view.took_over} of your own lines are commented out (restored by Restore)")
        pac = sysproxy.current_pac(self.system)
        lines.append(f"Windows proxy script: {pac}" if sysproxy.is_ours(pac) else "Windows proxy script: not set by us")
        proxy = self._proxy
        if proxy is not None and proxy.is_alive():
            scope = "all sites" if proxy.universal else f"{len(proxy.domains)} hosts"
            lines.append(f"Local proxy: 127.0.0.1:{proxy.port} ({scope})")
        else:
            lines.append("Local proxy: not running")
        dpi = self._dpi
        if dpi is not None and dpi.is_alive():
            lines.append(f"Packet engine: running (preset {dpi.preset.id})")
        else:
            lines.append("Packet engine: not running")
        return "\n".join(lines)

    # ---- targets ------------------------------------------------------------------------------------
    def targets(self) -> list[Target]:
        s, seen, out = self.settings, set(), []
        for gid in s.selected_groups():
            for host in GROUPS[gid].hosts:
                if host not in seen and not is_denied(host):
                    seen.add(host)
                    out.append(Target(host, gid))
        for host in s.clean_custom_domains():
            if host not in seen and not is_denied(host):
                seen.add(host)
                out.append(Target(host, "custom"))
        return out

    def refresh_due(self) -> bool:
        s = self.settings
        return bool(s.enabled and s.applied and self._clock() - s.last_refresh > s.refresh_hours * 3600)

    # ---- diagnose (read-only) -----------------------------------------------------------------------
    def _diagnose(self, progress, cancel) -> list[DiagnosisResult]:
        return diagnose_hosts(self.targets(), resolver=self.resolver, probe=self._probe,
                              resolve_system=self._resolve_system, online=self._online,
                              progress=progress, cancel=cancel)

    def _view_or_none(self) -> HostsView | None:
        try:
            return self._hosts.view()
        except OSError:
            return None

    @staticmethod
    def _text(entry: dict) -> str:
        """'151.101.65.140 + split:REC_FRAG' style description of an applied entry."""
        parts = list(entry.get("ips", []))[:2]
        if entry.get("mode") in (MODE_PROXY, MODE_BOTH):
            parts.append(f"split:{Strategy(int(entry.get('strategy', 0))).name}")
        if entry.get("dpi"):
            parts.append("packet engine")
        return " + ".join(parts)

    def _row(self, d: DiagnosisResult, status: HostStatus, chosen: str = "", rtt: float = 0.0,
             note: str | None = None) -> HostRow:
        return HostRow(host=d.host, group=d.group, verdict=d.verdict, status=status, local_ips=list(d.local_ips),
                       chosen=chosen, rtt_ms=rtt, note=d.evidence if note is None else note)

    def _diagnose_row(self, d: DiagnosisResult, view: HostsView | None) -> HostRow:
        applied = self.settings.applied.get(d.host)
        if d.verdict == Verdict.OFFLINE:
            return self._row(d, HostStatus.OFFLINE)
        if applied and (d.verdict == Verdict.OK or (d.needs_proxy and applied.get("mode") != MODE_HOSTS)):
            return self._row(d, _APPLIED_STATUS.get(applied.get("mode"), HostStatus.APPLIED_HOSTS),
                             self._text(applied))
        if d.verdict == Verdict.OK:
            manual = view is not None and d.host in view.manual
            return self._row(d, HostStatus.MANUAL_OK if manual else HostStatus.NOTHING_BLOCKED)
        if d.fixable:
            return self._row(d, HostStatus.NEEDS_FIX,
                             f"split:{d.strategy.name}" if d.needs_proxy else (d.doh_ips[0] if d.doh_ips else ""))
        if d.verdict == Verdict.UNREACHABLE:
            return self._row(d, HostStatus.FAILED)
        return self._row(d, HostStatus.NOT_FIXABLE)

    def diagnose(self, progress: Progress | None = None, cancel: threading.Event | None = None) -> list[HostRow]:
        with self._lock:
            self._warnings.clear()
            results = self._diagnose(progress, cancel)
            view = self._view_or_none()
            return [self._diagnose_row(d, view) for d in results]

    # ---- apply --------------------------------------------------------------------------------------
    def _warn(self, message: str) -> None:
        if message not in self._warnings:
            self._warnings.append(message)
            logger.warning(f"[NetUnblock] {message}")

    def apply_auto(self, progress: Progress | None = None, cancel: threading.Event | None = None) -> list[HostRow]:
        with self._lock:
            self._warnings.clear()
            results = self._diagnose(progress, cancel)
            if cancel is not None and cancel.is_set():
                view = self._view_or_none()
                return [self._diagnose_row(d, view) for d in results]
            if not self.is_admin():
                self._warn("Administrator rights are required to apply changes; showing diagnosis only.")
                view = self._view_or_none()
                return [self._diagnose_row(d, view) for d in results]
            return self._apply(results, progress, cancel)

    def refresh(self, progress: Progress | None = None, cancel: threading.Event | None = None) -> list[HostRow]:
        """Re-validate what is applied: healthy entries are kept, failing ones are re-scanned or dropped."""
        s = self.settings
        if not s.applied and not s.all_sites_active and not s.dpi_active:
            return self.diagnose(progress, cancel)
        return self.apply_auto(progress, cancel)

    def _owner(self) -> None:
        pid = os.getpid()
        self.journal.set_owner(pid, self.system.process_token(pid))

    def _scan_all(self, results, applied, progress, cancel):
        """Find validated IPs for every host that needs a hosts entry. Returns (wanted, scanned_meta, failures)."""
        wanted: dict[str, list[str]] = {}
        meta: dict[str, dict] = {}
        notes: dict[str, str] = {}
        group_ips: dict[str, list[str]] = {}
        todo = [d for d in results if self._needs_scan(d, applied.get(d.host))]
        for i, d in enumerate(todo, 1):
            if cancel is not None and cancel.is_set():
                break
            if progress:
                progress(i, len(todo), f"Scanning addresses for {d.host}…")
            current = [ip for ip in d.local_ips if usable_ip(ip)]
            found = scan_host(d.host, resolver=self.resolver, probe=self._probe, strategy=d.strategy,
                              hint_ips=group_ips.get(d.group, []), current_ips=current, cancel=cancel)
            if found.good:
                ips = [g.ip for g in found.good]
                wanted[d.host] = ips
                meta[d.host] = {"rtt": found.good[0].rtt_ms, "strategy": int(d.strategy)}
                group_ips.setdefault(d.group, [])
                group_ips[d.group] += [ip for ip in ips if ip not in group_ips[d.group]]
            else:
                notes[d.host] = found.reason or "no working address found"
        return wanted, meta, notes

    @staticmethod
    def _needs_scan(d: DiagnosisResult, applied: dict | None) -> bool:
        if d.needs_hosts:
            return True
        ours = bool(applied) and applied.get("mode") in (MODE_HOSTS, MODE_BOTH)
        return ours and d.verdict in (Verdict.IP_BLACKHOLE, Verdict.UNREACHABLE)

    @staticmethod
    def _keeps_hosts(d: DiagnosisResult, applied: dict | None) -> bool:
        """The hosts entry we wrote earlier is still what the system resolves and the path behind it works."""
        if not applied or applied.get("mode") not in (MODE_HOSTS, MODE_BOTH) or not d.local_ips:
            return False
        return set(d.local_ips) <= set(applied.get("ips", [])) and d.verdict in (Verdict.OK, Verdict.SNI_RST)

    def _apply(self, results: list[DiagnosisResult], progress, cancel) -> list[HostRow]:
        s = self.settings
        now = self._clock()
        applied_before = dict(s.applied)
        view = self._hosts.view()
        if view.damaged:
            raise HostsError("the hosts file has a damaged BobGaming block; refusing to edit it")

        # 1) what stays, what must be (re)scanned
        wanted: dict[str, list[str]] = {}
        meta: dict[str, dict] = {}
        for d in results:
            a = applied_before.get(d.host)
            if self._keeps_hosts(d, a):
                wanted[d.host] = list(a["ips"])
                meta[d.host] = {"rtt": 0.0, "strategy": int(a.get("strategy", 0)), "fails": 0}
        scanned, scan_meta, scan_notes = self._scan_all(results, applied_before, progress, cancel)
        wanted.update(scanned)
        meta.update(scan_meta)
        for d in results:                                   # failed re-scan of something we applied: tolerate a few
            a = applied_before.get(d.host)
            if d.host in scan_notes and a and a.get("mode") in (MODE_HOSTS, MODE_BOTH):
                fails = int(a.get("fails", 0)) + 1
                if fails < MAX_FAILURES:
                    wanted[d.host] = list(a["ips"])
                    meta[d.host] = {"rtt": 0.0, "strategy": int(a.get("strategy", 0)), "fails": fails}

        # 2) hosts block
        manual_status = {d.host: self._manual_status(view, d) for d in results
                         if d.host in scanned and d.host in view.manual}
        plan = self._hosts.plan(wanted, manual_status=manual_status,
                                takeover=set(scanned) if s.takeover else set(),
                                prior_added_eol=bool(self.journal.hosts.get("added_eol")))
        hosts_ok = True
        if plan.changed:
            hosts_ok = self._write_hosts(plan, progress)
        effective = plan.wanted if hosts_ok else {}

        # 3) packet engine, or else proxy + PAC
        proxy_hosts = {d.host: d for d in results if d.needs_proxy}
        hints = {h: effective.get(h) or [ip for ip in d.local_ips + d.doh_ips if usable_ip(ip)][:3]
                 for h, d in proxy_hosts.items()}
        proxy_msg = ""
        proxy_ok = False
        dpi_ok = False
        if s.dpi_engine:
            dpi_ok, proxy_msg = self._ensure_dpi(progress)
        else:
            self._stop_dpi("packet engine disabled")
        universal = bool(s.all_sites) and not dpi_ok
        if dpi_ok:
            self._teardown_proxy("the packet engine is active")
        elif proxy_hosts or universal:
            proxy_ok, proxy_msg = self._ensure_proxy(list(proxy_hosts), hints, progress, universal=universal)
        else:
            self._teardown_proxy("no host needs the proxy")

        # 4) remember + report
        new_applied: dict[str, dict] = {}
        rows: list[HostRow] = []
        for d in results:
            host = d.host
            in_hosts = host in effective
            in_proxy = proxy_ok and host in proxy_hosts
            was_dpi = bool(applied_before.get(host, {}).get("dpi")) and d.verdict == Verdict.OK
            in_dpi = dpi_ok and (host in proxy_hosts or was_dpi)
            if in_hosts or in_proxy or in_dpi:
                mode = (MODE_BOTH if in_hosts and in_proxy else MODE_HOSTS if in_hosts
                        else MODE_PROXY if in_proxy else MODE_DPI)
                ips = effective.get(host) or hints.get(host, [])
                m = meta.get(host, {})
                new_applied[host] = {"mode": mode, "ips": ips, "ts": now, "fails": m.get("fails", 0),
                                     "strategy": int(d.strategy) if in_proxy else m.get("strategy", 0)}
                if in_dpi:
                    new_applied[host]["dpi"] = True
                status = HostStatus.APPLIED_DPI if in_dpi else _APPLIED_STATUS[mode]
                rows.append(self._row(d, status, self._text(new_applied[host]), m.get("rtt", 0.0), note=d.evidence))
            else:
                rows.append(self._unapplied_row(d, view, plan, scan_notes, proxy_hosts, proxy_msg, hosts_ok))
        s.applied = new_applied
        s.all_sites_active = bool(universal and proxy_ok)
        s.dpi_active = dpi_ok
        s.last_refresh = now
        self.save_settings()
        return rows


    def _manual_status(self, view: HostsView, d: DiagnosisResult) -> str:
        """'ok' when one of the user's own IPs for this host really serves it (it then stays untouched)."""
        for ip, _start, _end, _multi in view.manual.get(d.host, []):
            if usable_ip(ip) and self._probe(ip, d.host, d.strategy).ok:
                return "ok"
        return "stale"

    def _unapplied_row(self, d, view, plan, scan_notes, proxy_hosts, proxy_msg, hosts_ok) -> HostRow:
        host = d.host
        skip = plan.skipped.get(host, "")
        if d.verdict == Verdict.OFFLINE:
            return self._row(d, HostStatus.OFFLINE)
        if skip == "manual-ok" or (d.verdict == Verdict.OK and view is not None and host in view.manual):
            return self._row(d, HostStatus.MANUAL_OK, note="Your own hosts entry works; left untouched")
        if skip.startswith("manual-stale"):
            return self._row(d, HostStatus.MANUAL_STALE,
                             note="Your own hosts entry no longer works. Enable 'Replace my own stale hosts "
                                  "entries' to let Network Unblock fix it.")
        if d.verdict == Verdict.OK:
            return self._row(d, HostStatus.NOTHING_BLOCKED)
        if host in proxy_hosts:
            return self._row(d, HostStatus.FAILED, note=f"The local proxy self-test failed: {proxy_msg}")
        if not hosts_ok and d.needs_hosts:
            return self._row(d, HostStatus.FAILED, note="The hosts entry was rolled back after the self-test failed")
        if host in scan_notes:
            return self._row(d, HostStatus.NOT_FIXABLE, note=scan_notes[host])
        if d.verdict == Verdict.UNREACHABLE:
            return self._row(d, HostStatus.FAILED)
        return self._row(d, HostStatus.NOT_FIXABLE)

    # ---- hosts layer --------------------------------------------------------------------------------
    def _write_hosts(self, plan, progress) -> bool:
        """Journal -> write -> read back -> getaddrinfo self-test. Rolls the block back when the OS ignores it."""
        if progress:
            progress(1, 1, "Updating the hosts file…")
        self._owner()
        previous = self.journal.hosts
        took = sorted(set(previous.get("took_over", [])) | set(plan.took_over))
        backup = self._hosts.backup()
        self.journal.hosts_pending(sha256(self._hosts.read_bytes()), sha256(plan.new_bytes), backup,
                                   plan.added_eol, took)
        self._hosts.apply(plan, backup=False)
        self.journal.hosts_applied()
        bad = self._selftest_hosts(plan.wanted)
        if not bad:
            if not plan.wanted:
                self.journal.hosts_none()
                self.journal.clear_if_clean()
            return True
        self._warn(f"Windows did not use the hosts entry for {', '.join(bad)}; the change was rolled back. "
                   "Another DNS layer (VPN, security software or a DNS client policy) may override it.")
        self._remove_hosts_block()
        return False

    def _selftest_hosts(self, wanted: dict[str, list[str]]) -> list[str]:
        bad = []
        for host, ips in wanted.items():
            got, _err = self._resolve_system(host)
            if not got or not set(got) <= set(ips):
                bad.append(host)
        return bad

    def _remove_hosts_block(self) -> bool:
        self.journal.hosts_reverting()
        self._hosts.remove_block(strip_added_eol=bool(self.journal.hosts.get("added_eol")))
        self.journal.hosts_none()
        self.journal.clear_if_clean()
        return True

    # ---- proxy layer --------------------------------------------------------------------------------
    def _ensure_proxy(self, domains: list[str], hints: dict, progress, universal: bool = False) -> tuple[bool, str]:
        reason = sysproxy.foreign_config(self.system)
        if reason:
            self._warn(f"Proxy layer skipped: {reason}. Only the hosts file was used.")
            return False, reason
        s = self.settings
        if progress:
            progress(1, 1, "Starting the local proxy…")
        if self._proxy is not None and self._proxy.is_alive() and self._proxy.universal != universal:
            self._teardown_proxy("proxy mode changed")
        if self._proxy is not None and self._proxy.is_alive():
            self._proxy.update(domains, hints)
        else:
            s.pac_token = s.pac_token or secrets.token_hex(8)
            cache = StrategyCache(s.learned)
            self._proxy = self._proxy_factory(domains, resolver=self.resolver, cache=cache, ips_hint=hints,
                                              token=s.pac_token, universal=universal)
            try:
                s.proxy_port = self._proxy.start(s.proxy_port)
            except OSError as e:
                self._proxy = None
                self._warn(f"Could not start the local proxy: {e}")
                return False, str(e)
        proxy = self._proxy
        results = [proxy.selftest(host) for host in (domains[:SELFTEST_HOSTS] or [CONTROL_SNI])]
        if not any(ok for ok, _detail in results):
            detail = results[0][1] if results else "no host to test"
            self._teardown_proxy("self-test failed")
            self._warn(f"The local proxy self-test failed ({detail}); the proxy layer was not enabled.")
            return False, detail
        return self._install_pac(proxy), ""

    def _install_pac(self, proxy: SplitProxy) -> bool:
        url = sysproxy.pac_url(proxy.port, self.settings.pac_token)
        if sysproxy.current_pac(self.system) == url and self.journal.pac.get("state") == "applied":
            return True
        pre = sysproxy.snapshot(self.system)
        if sysproxy.is_ours(sysproxy.current_pac(self.system)):                 # leftover of a dead run
            pre[sysproxy.PAC_VALUE] = None
        self._owner()
        self.journal.pac_pending(url, pre)
        sysproxy.set_pac(self.system, url)
        if sysproxy.current_pac(self.system) != url:
            self._warn("Windows did not accept the proxy script setting; the proxy layer was not enabled.")
            self._teardown_proxy("PAC was not stored")
            return False
        self.journal.pac_applied()
        return True

    def _restore_pac(self) -> bool:
        pac = self.journal.pac
        if pac.get("state") == "none":
            return False
        self.journal.pac_reverting()
        restored = sysproxy.restore(self.system, pac.get("pre"), pac.get("url"))
        self.journal.pac_none()
        self.journal.clear_if_clean()
        return restored

    def _teardown_proxy(self, why: str) -> None:
        """Undo the PAC first (browsers go DIRECT), then stop the listener. Never raises."""
        try:
            self._restore_pac()
        except Exception as e:
            logger.warning(f"[NetUnblock] Could not restore the proxy script setting: {e}")
        proxy, self._proxy = self._proxy, None
        if proxy is not None:
            try:
                proxy.stop()
                logger.info(f"[NetUnblock] Local proxy stopped ({why})")
            except Exception as e:
                logger.warning(f"[NetUnblock] Could not stop the proxy cleanly: {e}")

    # ---- packet engine ------------------------------------------------------------------------------
    def _anticheat_running(self) -> str:
        """Name of a running anti-cheat process ('' if none or the list cannot be read)."""
        try:
            hits = ANTICHEAT_PROCESSES & set(self.system.running_process_names())
        except Exception as e:
            logger.debug(f"[NetUnblock] process list unavailable: {e}")
            return ""
        return sorted(hits)[0] if hits else ""

    def _dpi_selftest(self) -> tuple[bool, str]:
        """A real TLS handshake + GET to a neutral host while the engine runs: it must not break connectivity."""
        try:
            ips = [ip for ip in self.resolver.resolve(CONTROL_SNI).ips if usable_ip(ip)][:2]
        except Exception as e:
            logger.debug(f"[NetUnblock] packet engine self-test could not resolve: {e}")
            return True, ""
        if not ips:
            return True, ""
        results = [self._probe(ip, CONTROL_SNI, Strategy.NONE) for ip in ips]
        if any(r.ok for r in results):
            return True, ""
        return False, results[0].detail or results[0].kind.value

    def _ensure_dpi(self, progress=None) -> tuple[bool, str]:
        s = self.settings
        engine = self._dpi
        if engine is not None and engine.is_alive() and engine.preset.id == s.dpi_preset:
            return True, ""
        self._stop_dpi("restarting")
        blocker = self._anticheat_running()
        if blocker:
            self._warn(f"The packet engine was not started because anti-cheat software is running ({blocker}). "
                       "Close the game first.")
            return False, blocker
        if progress:
            progress(1, 1, "Starting the packet engine…")
        target_domains = None
        if not s.all_sites_active:
            target_domains = {h.lower() for h, a in s.applied.items() if a.get("dpi") or a.get("mode") == "dpi"}
            if not target_domains:
                target_domains = {t.host.lower() for t in self.targets()}
        try:
            engine = self._dpi_factory(s.dpi_preset, staging_dir=os.path.join(self.paths.state_dir, "windivert"),
                                       target_domains=target_domains)
        except TypeError:
            engine = self._dpi_factory(s.dpi_preset, staging_dir=os.path.join(self.paths.state_dir, "windivert"))
        try:
            engine.start()
        except Exception as e:
            self._warn(f"The packet engine could not start: {e}")
            return False, str(e)
        self._dpi = engine
        ok, detail = self._dpi_selftest()
        if not ok:
            self._stop_dpi("self-test failed")
            self._warn(f"The packet engine broke the connection self-test ({detail}) and was stopped.")
            return False, detail
        return True, ""

    def _stop_dpi(self, why: str) -> None:
        engine, self._dpi = self._dpi, None
        if engine is not None:
            try:
                engine.stop()
                logger.info(f"[NetUnblock] Packet engine stopped ({why})")
            except Exception as e:
                logger.warning(f"[NetUnblock] Could not stop the packet engine cleanly: {e}")

    def _fallback_from_dpi(self, why: str) -> None:
        """The engine is gone (anti-cheat, driver error): serve the hosts it covered through the proxy layer."""
        s = self.settings
        self._stop_dpi(why)
        s.dpi_active = False
        for entry in s.applied.values():
            if entry.pop("dpi", None):
                entry["mode"] = MODE_BOTH if entry.get("mode") == MODE_HOSTS else MODE_PROXY
        proxy_hosts = [h for h, a in s.applied.items() if a.get("mode") in (MODE_PROXY, MODE_BOTH)]
        universal = bool(s.all_sites)
        if proxy_hosts or universal:
            ok, _msg = self._ensure_proxy(proxy_hosts, self._hints(proxy_hosts), None, universal=universal)
            s.all_sites_active = bool(universal and ok)
        self.save_settings()

    def _health_dpi(self) -> bool:
        blocker = self._anticheat_running()
        if blocker:
            self._warn(f"The packet engine was stopped because anti-cheat software started ({blocker}).")
            self._fallback_from_dpi("anti-cheat detected")
            return False
        ok, _msg = self._ensure_dpi()
        if not ok:
            self._fallback_from_dpi("engine failed")
        return ok

    # ---- lifecycle ----------------------------------------------------------------------------------
    def shutdown(self, reason: str = "exit") -> None:
        """Stop the packet engine and the proxy, undo the PAC (they cannot outlive the process). Hosts are kept."""
        try:
            with self._lock:
                self._stop_dpi(reason)
                self._teardown_proxy(reason)
        except Exception as e:
            logger.warning(f"[NetUnblock] shutdown failed: {e}")

    def restore_all(self) -> list[str]:
        """Remove every change: proxy + PAC, hosts block (and took-over lines), journal, applied state."""
        messages: list[str] = []
        with self._lock:
            had_proxy = self._proxy is not None
            had_dpi = self._dpi is not None
            pac_before = sysproxy.is_ours(sysproxy.current_pac(self.system))
            self._stop_dpi("restore")
            self._teardown_proxy("restore")
            if had_dpi:
                messages.append("Packet engine stopped")
            if had_proxy:
                messages.append("Local proxy stopped")
            if pac_before and not sysproxy.is_ours(sysproxy.current_pac(self.system)):
                messages.append("Windows proxy script setting restored")
            try:
                view = self._hosts.view()
                if view.managed or view.took_over:
                    self.journal.hosts_reverting()
                result = self._hosts.remove_block(strip_added_eol=bool(self.journal.hosts.get("added_eol")))
                if result:
                    messages.append("Hosts block removed and your own lines restored")
            except (HostsError, OSError) as e:
                messages.append(f"Could not edit the hosts file ({e}); run as Administrator and try again")
            finally:
                try:
                    self.journal.reset()
                except Exception:
                    pass
                s = self.settings
                s.applied = {}
                s.learned = {}
                s.enabled = False
                s.auto_apply = False
                s.all_sites = False
                s.all_sites_active = False
                s.dpi_engine = False
                s.dpi_active = False
                self.save_settings()
                self._warnings.clear()
        if not messages:
            messages.append("Nothing was applied")
        return messages

    def health_check(self) -> bool:
        """Keep the packet engine (or else the proxy/PAC) running while the hosts rely on it."""
        with self._lock:
            s = self.settings
            if s.dpi_active:
                return self._health_dpi()
            hosts = [h for h, a in s.applied.items() if a.get("mode") in (MODE_PROXY, MODE_BOTH)]
            if not hosts and not s.all_sites_active:
                return True
            if self._proxy is not None and self._proxy.is_alive():
                return not self._proxy.degraded
            ok, _msg = self._ensure_proxy(hosts, self._hints(hosts), None, universal=s.all_sites_active)
            return ok

    def _hints(self, hosts: list[str]) -> dict:
        applied = self.settings.applied
        return {h: list(applied.get(h, {}).get("ips", [])) for h in hosts}

    def startup(self) -> None:
        """Called from a daemon thread at app start (enabled + auto_apply): repair, restart proxy, refresh if due."""
        try:
            with self._lock:
                s = self.settings
                if not (s.enabled and s.auto_apply and (s.applied or s.all_sites_active or s.dpi_active)
                        and self.is_admin()):
                    return
                view = self._hosts.view()
                missing = [h for h, a in s.applied.items()
                           if a.get("mode") in (MODE_HOSTS, MODE_BOTH) and h not in view.managed]
                if missing:
                    logger.info(f"[NetUnblock] Hosts block is missing {len(missing)} entries; re-applying")
                    self.apply_auto()
                    return
                if s.dpi_active:
                    self._health_dpi()
                proxy_hosts = [h for h, a in s.applied.items() if a.get("mode") in (MODE_PROXY, MODE_BOTH)]
                if (proxy_hosts or s.all_sites_active) and not s.dpi_active:
                    self._ensure_proxy(proxy_hosts, self._hints(proxy_hosts), None, universal=s.all_sites_active)
                if self.refresh_due():
                    self.refresh()
        except Exception:
            logger.exception("[NetUnblock] startup failed")


def restore_all(manager: NetUnblockManager | None = None) -> list[str]:
    """Module-level helper (factory reset): undo everything with a default manager."""
    return (manager or NetUnblockManager()).restore_all()
