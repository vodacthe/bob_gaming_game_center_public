"""
Layer 0 — read-only per-host diagnosis. Writes nothing, needs no admin rights.

For every host we compare what the OS resolver says with what DoH says, then run real TLS probes to
decide which kind of blocking (if any) is in the way:

  OK            reachable as-is                                  -> nothing to do
  DNS_POISON    system DNS lies (loopback/private/NXDOMAIN/decoy) -> hosts block with validated IPs
  SNI_RST       the ClientHello with the real SNI is reset/dropped -> local split proxy (strategy found)
  IP_BLACKHOLE  the IPs themselves are unreachable                 -> nothing local can help (VPN/WARP)
  UNREACHABLE   does not resolve / wrong certificates everywhere
  OFFLINE       no connectivity at all

Nothing here is ISP specific: behaviour differs per ISP and changes over time, so it is detected at runtime.
"""

from __future__ import annotations

import logging
import socket
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable

from app.core.net_unblock.doh import DohResolver, system_resolve, usable_ip
from app.core.net_unblock.models import (
    ESCALATION, DiagnosisResult, ProbeKind, ProbeResult, Strategy, Target, Verdict,
)
from app.core.net_unblock.tls import CONTROL_SNI, tls_probe

logger = logging.getLogger(__name__)

Progress = Callable[[int, int, str], None]

_ONLINE_PROBES = (("1.1.1.1", 443), ("8.8.8.8", 443), ("9.9.9.9", 443))


def check_online(timeout: float = 2.0) -> bool:
    """True if we can open a TCP connection to at least one well-known anycast resolver."""
    for ip, port in _ONLINE_PROBES:
        try:
            socket.create_connection((ip, port), timeout=timeout).close()
            return True
        except OSError:
            continue
    return False


def _path_check(probe, ip: str, host: str) -> tuple[str, Strategy, ProbeResult]:
    """Classify the network path to `ip` for `host`.

    Returns (path, strategy, result) with path in:
      ok            TLS+HTTP fine with the plain ClientHello
      sni           plain hello is reset/dropped, but `strategy` (a split) works
      sni_unfixable plain hello is reset/dropped and no split strategy helps
      blackhole     every TLS hello to this IP is reset/dropped (even for another name)
      dead          TCP cannot connect
      bad           connects, but certificate/answer is wrong for this host
    """
    r = probe(ip, host)
    if r.ok:
        return "ok", Strategy.NONE, r
    if r.kind in (ProbeKind.RST, ProbeKind.TIMEOUT):
        control = probe(ip, host, Strategy.NONE, sni=CONTROL_SNI, request=False)
        if control.kind in (ProbeKind.OK, ProbeKind.CERT, ProbeKind.BLOCKPAGE):
            for strategy in ESCALATION:          # path is alive for other names -> name-based filtering
                r2 = probe(ip, host, strategy)
                if r2.ok:
                    return "sni", strategy, r2
            return "sni_unfixable", Strategy.NONE, r
        return "blackhole", Strategy.NONE, r
    if r.kind == ProbeKind.CONNECT:
        return "dead", Strategy.NONE, r
    return "bad", Strategy.NONE, r


def _evaluate(probe, ips: list[str], host: str, max_ips: int = 2):
    """Check up to `max_ips` addresses; stop at the first definitive answer."""
    last = ("dead", Strategy.NONE, ProbeResult(ProbeKind.CONNECT, detail="no candidate"), "")
    for ip in ips[:max_ips]:
        path, strategy, result = _path_check(probe, ip, host)
        last = (path, strategy, result, ip)
        if path in ("ok", "sni", "sni_unfixable", "blackhole"):
            break
    return last


def _diagnose_one(target: Target, resolver: DohResolver, probe, resolve_system) -> DiagnosisResult:
    host = target.host
    local_ips, lerr = resolve_system(host)
    doh = resolver.resolve(host)
    d_ips = list(doh.ips)
    l_global = [ip for ip in local_ips if usable_ip(ip)]
    l_bad = [ip for ip in local_ips if not usable_ip(ip)]
    res = DiagnosisResult(host=host, group=target.group, verdict=Verdict.OK,
                          local_ips=list(local_ips), doh_ips=d_ips)

    dns_poison = False
    notes: list[str] = []
    if l_bad:
        dns_poison = True
        notes.append(f"system DNS answered {l_bad[0]}, which is not a public address")
    elif not local_ips and d_ips:
        dns_poison = True
        notes.append(f"system DNS failed ({lerr or 'no answer'}) but DNS-over-HTTPS resolves it")

    if not d_ips and not l_global:
        res.verdict = Verdict.UNREACHABLE
        if doh.nxdomain:
            res.evidence = "host does not exist (NXDOMAIN at every resolver)"
        elif dns_poison:
            res.evidence = "DNS is poisoned and DNS-over-HTTPS is unreachable, so the real IP is unknown"
        else:
            res.evidence = "could not resolve the host"
        return res

    def finish(verdict: Verdict, *, poison: bool, sni: bool = False, strategy: Strategy = Strategy.NONE,
               extra: str = "") -> DiagnosisResult:
        res.verdict, res.dns_poison, res.sni_rst, res.strategy = verdict, poison, sni, strategy
        res.evidence = "; ".join(n for n in (*notes, extra) if n)
        return res

    def from_doh() -> DiagnosisResult | None:
        """Re-evaluate using the DoH addresses (system answer was unusable)."""
        path, strategy, result, ip = _evaluate(probe, d_ips, host)
        if path == "ok":
            return finish(Verdict.DNS_POISON, poison=True, extra=f"{ip} works")
        if path == "sni":
            return finish(Verdict.SNI_RST, poison=True, sni=True, strategy=strategy,
                          extra=f"{ip}: plain hello reset; split strategy {strategy.name} works")
        if path == "sni_unfixable":
            return finish(Verdict.SNI_RST, poison=True, sni=True,
                          extra=f"{ip}: hello is reset and no split helps (needs a VPN)")
        if path in ("blackhole", "dead"):
            return finish(Verdict.IP_BLACKHOLE, poison=True, extra=f"{ip}: {result.detail}")
        return finish(Verdict.UNREACHABLE, poison=True, extra=f"{ip}: {result.detail}")

    if dns_poison:
        if not d_ips:
            res.verdict = Verdict.UNREACHABLE
            res.evidence = "; ".join([*notes, "DoH returned no address"])
            return res
        return from_doh()

    # system DNS looks sane -> test its answer directly
    path, strategy, result, ip = _evaluate(probe, l_global, host, max_ips=1)
    if path == "ok":
        return finish(Verdict.OK, poison=False)
    if path == "sni":
        return finish(Verdict.SNI_RST, poison=False, sni=True, strategy=strategy,
                      extra=f"{ip}: plain hello reset; split strategy {strategy.name} works")
    if path == "sni_unfixable":
        return finish(Verdict.SNI_RST, poison=False, sni=True,
                      extra=f"{ip}: hello is reset and no split helps (needs a VPN)")
    # blackhole / dead / bad: maybe the system answer was a decoy and DoH knows a better IP
    if d_ips and l_global[0] not in d_ips:
        notes.append(f"system answer {l_global[0]} unusable ({result.detail}); trying DoH addresses")
        alt = from_doh()
        if alt is not None and alt.verdict in (Verdict.DNS_POISON, Verdict.SNI_RST):
            return alt
    if path == "bad":
        return finish(Verdict.UNREACHABLE, poison=False, extra=f"{ip}: {result.detail}")
    return finish(Verdict.IP_BLACKHOLE, poison=False, extra=f"{ip}: {result.detail}")


def diagnose_hosts(targets: list[Target], *, resolver: DohResolver, probe=tls_probe,
                   resolve_system=system_resolve, online: Callable[[], bool] = check_online,
                   progress: Progress | None = None, cancel: threading.Event | None = None,
                   workers: int = 8) -> list[DiagnosisResult]:
    """Diagnose every target (read-only). Order of the result matches `targets` (cancelled ones are dropped)."""
    total = len(targets)
    if not targets:
        return []
    if not online():
        return [DiagnosisResult(t.host, t.group, Verdict.OFFLINE, evidence="no internet connectivity")
                for t in targets]

    results: dict[int, DiagnosisResult] = {}
    done = 0

    def work(index: int, target: Target):
        if cancel is not None and cancel.is_set():
            return index, None
        try:
            return index, _diagnose_one(target, resolver, probe, resolve_system)
        except Exception as e:                       # one bad host must not kill the run
            logger.exception(f"[NetUnblock] Diagnose failed for {target.host}")
            return index, DiagnosisResult(target.host, target.group, Verdict.UNREACHABLE,
                                          evidence=f"internal error: {e}")

    with ThreadPoolExecutor(max_workers=max(1, min(workers, total)), thread_name_prefix="diag") as pool:
        futures = [pool.submit(work, i, t) for i, t in enumerate(targets)]
        for fut in as_completed(futures):
            index, result = fut.result()
            done += 1
            if result is not None:
                results[index] = result
                if progress:
                    progress(done, total, f"{result.host}: {result.verdict.value}")
    return [results[i] for i in sorted(results)]
