"""
Thin ctypes binding over the official WinDivert 2.2.2 user-mode DLL (LGPL-3.0, see assets/windivert/LICENSE).

The DLL and the signed driver (WinDivert64.sys) ship in assets/windivert. Both are copied to an admin-owned state
folder and their SHA-256 is checked against the pinned values below immediately before the DLL is loaded, so a
tampered copy never reaches the kernel. This module only does packet I/O; every decision lives in dpi_engine.py.
"""

from __future__ import annotations

import ctypes
import hashlib
import logging
import os
import shutil
import sys
from ctypes import wintypes

logger = logging.getLogger(__name__)

VERSION = "2.2.2"
DLL_NAME, SYS_NAME = "WinDivert.dll", "WinDivert64.sys"
PINNED_SHA256 = {
    DLL_NAME: "c1e060ee19444a259b2162f8af0f3fe8c4428a1c6f694dce20de194ac8d7d9a2",
    SYS_NAME: "8da085332782708d8767bcace5327a6ec7283c17cfb85e40b03cd2323a90ddc2",
}
MAX_PACKET = 65535
_FILTER_OBJECT_MAX = 8192
_LAYER_NETWORK = 0
_SHUTDOWN_RECV = 1
_ERROR_NO_DATA = 232
_ERROR_OPERATION_ABORTED = 995
_OUTBOUND_BIT = 1 << 17
_INVALID_HANDLE = ctypes.c_void_p(-1).value

_OPEN_ERRORS = {
    2: "the WinDivert driver file is missing",
    5: "Administrator rights are required to load the packet driver",
    87: "the packet filter was rejected",
    577: "Windows refused the driver signature (Secure Boot / HVCI / security software)",
    654: "the packet driver is incompatible with this Windows version",
    1275: "Windows or a security product blocked the packet driver",
    1058: "the packet driver service is disabled",
    1060: "the packet driver service is missing",
}


class WinDivertError(OSError):
    """Raised for a missing/tampered binary, a refused driver load or a failed packet operation."""


def sha256_file(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 16), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_binaries(folder: str) -> None:
    for name, expected in PINNED_SHA256.items():
        path = os.path.join(folder, name)
        try:
            actual = sha256_file(path)
        except OSError as e:
            raise WinDivertError(f"{name} is missing ({e})") from e
        if actual != expected:
            raise WinDivertError(f"{name} does not match the pinned SHA-256; refusing to load it")


def source_folder() -> str:
    """assets/windivert next to the sources, or inside the PyInstaller bundle."""
    base = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))))
    return os.path.join(base, "assets", "windivert")


def stage_binaries(source: str, target: str) -> str:
    """Copy DLL + driver to `target` (admin-owned state folder) and verify them there. Returns the DLL path."""
    verify_binaries(source)
    os.makedirs(target, exist_ok=True)
    for name in PINNED_SHA256:
        dst = os.path.join(target, name)
        if not os.path.exists(dst) or sha256_file(dst) != PINNED_SHA256[name]:
            shutil.copy2(os.path.join(source, name), dst)
    verify_binaries(target)
    return os.path.join(target, DLL_NAME)


class _Address(ctypes.Structure):
    _fields_ = [("timestamp", ctypes.c_int64), ("flags", ctypes.c_uint32), ("reserved2", ctypes.c_uint32),
                ("data", ctypes.c_uint8 * 64)]


def _load(dll_path: str):
    if not sys.platform.startswith("win"):
        raise WinDivertError("WinDivert only exists on Windows")
    if ctypes.sizeof(ctypes.c_void_p) != 8:
        raise WinDivertError("the packet engine needs 64-bit Windows and 64-bit Python")
    verify_binaries(os.path.dirname(dll_path))
    dll = ctypes.WinDLL(dll_path, use_last_error=True)
    dll.WinDivertOpen.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int16, ctypes.c_uint64]
    dll.WinDivertOpen.restype = ctypes.c_void_p
    dll.WinDivertRecv.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.UINT, ctypes.POINTER(wintypes.UINT),
                                  ctypes.POINTER(_Address)]
    dll.WinDivertRecv.restype = wintypes.BOOL
    dll.WinDivertSend.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.UINT, ctypes.POINTER(wintypes.UINT),
                                  ctypes.POINTER(_Address)]
    dll.WinDivertSend.restype = wintypes.BOOL
    dll.WinDivertShutdown.argtypes = [ctypes.c_void_p, ctypes.c_int]
    dll.WinDivertShutdown.restype = wintypes.BOOL
    dll.WinDivertClose.argtypes = [ctypes.c_void_p]
    dll.WinDivertClose.restype = wintypes.BOOL
    dll.WinDivertHelperCompileFilter.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, wintypes.UINT,
                                                 ctypes.POINTER(ctypes.c_char_p), ctypes.POINTER(wintypes.UINT)]
    dll.WinDivertHelperCompileFilter.restype = wintypes.BOOL
    if hasattr(dll, "WinDivertSetParam"):
        dll.WinDivertSetParam.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint64]
        dll.WinDivertSetParam.restype = wintypes.BOOL
    return dll


def check_filter(dll_path: str, expression: str) -> str:
    """'' when WinDivert accepts the filter, else its error text. Needs no driver and no admin rights."""
    dll = _load(dll_path)
    message, position, compiled = ctypes.c_char_p(), wintypes.UINT(), ctypes.create_string_buffer(_FILTER_OBJECT_MAX)
    if dll.WinDivertHelperCompileFilter(expression.encode("ascii"), _LAYER_NETWORK, compiled, _FILTER_OBJECT_MAX,
                                        ctypes.byref(message), ctypes.byref(position)):
        return ""
    return f"{(message.value or b'').decode('ascii', 'replace')} at {position.value}"


class Divert:
    """One open WinDivert handle: recv() -> (bytes, outbound, address) or None once shut down; send()."""

    def __init__(self, dll_path: str, expression: str, priority: int = 0):
        self._dll = _load(dll_path)
        handle = self._dll.WinDivertOpen(expression.encode("ascii"), _LAYER_NETWORK, priority, 0)
        if handle in (None, _INVALID_HANDLE):
            code = ctypes.get_last_error()
            raise WinDivertError(f"{_OPEN_ERRORS.get(code, 'WinDivertOpen failed')} (error {code})")
        self._handle = ctypes.c_void_p(handle)
        self._buffer = ctypes.create_string_buffer(MAX_PACKET)
        self._closed = False

        # Increase queue time to 8000ms (default is 1000ms), queue length to 8192, queue size to 16MB.
        # This prevents packet loss when Python is momentarily busy or garbage-collecting.
        if hasattr(self._dll, "WinDivertSetParam"):
            try:
                self._dll.WinDivertSetParam(self._handle, 0, 8192)                     # WINDIVERT_PARAM_QUEUE_LENGTH
                self._dll.WinDivertSetParam(self._handle, 1, 8000)                     # WINDIVERT_PARAM_QUEUE_TIME
                self._dll.WinDivertSetParam(self._handle, 2, 16 * 1024 * 1024)        # WINDIVERT_PARAM_QUEUE_SIZE
            except Exception as e:
                logger.debug(f"[NetUnblock] Could not set WinDivert queue parameters: {e}")

    def recv(self):
        address, length = _Address(), wintypes.UINT()
        while not self._closed:
            if not self._dll.WinDivertRecv(self._handle, self._buffer, MAX_PACKET, ctypes.byref(length),
                                           ctypes.byref(address)):
                code = ctypes.get_last_error()
                if self._closed or code in (_ERROR_NO_DATA, _ERROR_OPERATION_ABORTED):
                    return None
                # Transient non-fatal errors should not crash the packet loop
                if code in (121, 997, 1234):  # ERROR_SEM_TIMEOUT, ERROR_IO_PENDING, ERROR_PORT_UNREACHABLE
                    continue
                raise WinDivertError(f"WinDivertRecv failed (error {code})")
            return self._buffer.raw[:length.value], bool(address.flags & _OUTBOUND_BIT), address
        return None

    def send(self, packet: bytes, address) -> None:
        if self._closed or not self._handle:
            return
        sent = wintypes.UINT()
        if not self._dll.WinDivertSend(self._handle, packet, len(packet), ctypes.byref(sent), ctypes.byref(address)):
            logger.debug(f"[NetUnblock] WinDivertSend failed (error {ctypes.get_last_error()})")

    def shutdown(self) -> None:
        """Make a blocked recv() return None (safe to call from another thread)."""
        self._closed = True
        if self._handle:
            try:
                self._dll.WinDivertShutdown(self._handle, _SHUTDOWN_RECV)
            except Exception:
                pass

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._handle:
            h = self._handle
            self._handle = None
            try:
                self._dll.WinDivertClose(h)
            except Exception:
                pass
