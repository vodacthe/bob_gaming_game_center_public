"""
Layer 2 — local split-ClientHello proxy + PAC.

A tiny HTTP-CONNECT proxy listening on 127.0.0.1 only. For hosts whose TLS ClientHello is reset by SNI filtering it
re-sends the hello fragmented (see tls.split_hello), escalating through strategies until the server answers. The
browser never sees the retries. The Windows proxy settings point at a PAC served by the same listener; the PAC
routes ONLY the managed hosts here ("PROXY 127.0.0.1:P; DIRECT", so a dead proxy falls back to DIRECT).

Design choices (see SESSION.MD):
* blocking sockets, one thread per tunnel (bounded by a semaphore) and a select() relay — not asyncio, because
  deterministic fragment boundaries matter;
* loopback peers only, CONNECT only to port 443; in managed mode only to hosts in the managed set (exact match);
* upstream addresses come from validated hints / DoH, never from the (possibly poisoned) system resolver.

Universal ("all sites") mode: the PAC sends every public HTTPS host here and any public host name is accepted. The
proxy is adaptive: addresses come from the system resolver first (public IPv4 only — loopback/private answers are
ignored, which also keeps the proxy from being used to reach the LAN) and from DoH when that gives nothing or
nothing connects; the hello is sent untouched first and split only when the site resets it (the winner is cached).
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import select
import socket
import ssl
import threading
import time
from typing import Callable, Iterable

from app.core.net_unblock.doh import system_resolve, usable_ip
from app.core.net_unblock.models import ESCALATION, Strategy
from app.core.net_unblock.presets import DENY_SUFFIXES
from app.core.net_unblock.tls import client_context, send_fragments, split_hello

logger = logging.getLogger(__name__)

LOOPBACK = "127.0.0.1"
MAX_TUNNELS = 128
UNIVERSAL_MAX_TUNNELS = 512
MAX_HEAD_BYTES = 8192
MAX_RECORD_BYTES = 5 + 16384 + 2048
CACHE_TTL_S = 7 * 24 * 3600
MAX_CACHE_ENTRIES = 2000
FAIL_BACKOFF_S = 30.0       # an unmanaged host that failed every attempt is refused instantly for this long
_CHUNK = 65536
_HOST_RE = re.compile(r"^(?=.{1,253}$)([a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?\.)+[a-z0-9-]{2,63}$")


# ---- strategy cache -------------------------------------------------------------------------------

def local_net_id() -> str:
    """Short id of the local /24 (UDP connect sends no packet) so learned strategies do not leak across networks."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 53))
            prefix = ".".join(s.getsockname()[0].split(".")[:3])
    except OSError:
        prefix = "offline"
    return hashlib.sha1(prefix.encode()).hexdigest()[:8]


class StrategyCache:
    """host|network -> winning Strategy, persisted in a plain dict (NetSettings.learned). Dropped on first failure."""

    def __init__(self, store: dict | None = None, net_id: Callable[[], str] = local_net_id,
                 clock: Callable[[], float] = time.time, ttl: float = CACHE_TTL_S):
        self.store = store if store is not None else {}
        self._net_id, self._clock, self._ttl = net_id, clock, ttl
        self._lock = threading.Lock()

    def _key(self, host: str) -> str:
        return f"{host}|{self._net_id()}"

    def get(self, host: str) -> Strategy | None:
        key = self._key(host)
        with self._lock:
            entry = self.store.get(key)
            if not isinstance(entry, dict):
                return None
            try:
                fresh = self._clock() - float(entry.get("ts", 0)) < self._ttl
                strategy = Strategy(int(entry["strategy"]))
            except (KeyError, TypeError, ValueError):
                fresh, strategy = False, None
            if not fresh or strategy in (None, Strategy.NONE):
                self.store.pop(key, None)
                return None
            return strategy

    def put(self, host: str, strategy: Strategy) -> None:
        with self._lock:
            self.store[self._key(host)] = {"strategy": int(strategy), "ts": self._clock()}
            if len(self.store) > MAX_CACHE_ENTRIES:
                def age(key):
                    entry = self.store[key]
                    return entry.get("ts", 0) if isinstance(entry, dict) else 0
                for key in sorted(self.store, key=age)[:MAX_CACHE_ENTRIES // 10]:
                    del self.store[key]

    def drop(self, host: str) -> None:
        with self._lock:
            self.store.pop(self._key(host), None)


# ---- PAC ------------------------------------------------------------------------------------------

def build_pac(domains: Iterable[str], port: int, universal: bool = False) -> str:
    """PAC that sends https:// requests to the local proxy, everything else DIRECT.

    Managed mode: exactly the given hosts. Universal mode: every public host except plain/local names, IP literals
    in private ranges and the deny-listed vendors (Microsoft, security software, ...), which stay DIRECT.
    """
    if universal:
        deny = json.dumps(sorted(DENY_SUFFIXES))
        return (
            "function FindProxyForURL(url, host) {\n"
            "  if (url.substring(0, 6) !== \"https:\") return \"DIRECT\";\n"
            "  host = host.toLowerCase();\n"
            "  if (host.indexOf(\".\") < 0 || host.indexOf(\":\") >= 0) return \"DIRECT\";\n"
            "  if (/\\.(lan|home|localdomain|home\\.arpa)$/.test(host)) return \"DIRECT\";\n"
            f"  var D = {deny};\n"
            "  for (var i = 0; i < D.length; i++)\n"
            "    if (host === D[i] || host.slice(-D[i].length - 1) === \".\" + D[i]) return \"DIRECT\";\n"
            "  var m = /^(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+)$/.exec(host);\n"
            "  if (m) {\n"
            "    var a = +m[1], b = +m[2];\n"
            "    if (a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||\n"
            "        (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)) return \"DIRECT\";\n"
            "  }\n"
            f"  return \"PROXY {LOOPBACK}:{int(port)}; DIRECT\";\n"
            "}\n"
        )
    hosts = {str(d).strip().lower().rstrip(".") for d in domains}
    table = json.dumps({h: 1 for h in sorted(hosts) if h.replace(".", "").replace("-", "").isalnum()})
    return (
        "function FindProxyForURL(url, host) {\n"
        f"  var H = {table};\n"
        "  if (url.substring(0, 6) !== \"https:\") return \"DIRECT\";\n"
        "  if (Object.prototype.hasOwnProperty.call(H, host.toLowerCase()))\n"
        f"    return \"PROXY {LOOPBACK}:{int(port)}; DIRECT\";\n"
        "  return \"DIRECT\";\n"
        "}\n"
    )


def public_target(host: str) -> bool:
    """A CONNECT target the universal proxy may open: a public IPv4 literal or a dotted public-looking host name."""
    if usable_ip(host):
        return True
    return bool(_HOST_RE.match(host)) and not host.rpartition(".")[2].isdigit()


# ---- helpers --------------------------------------------------------------------------------------

def _close(sock) -> None:
    try:
        sock.close()
    except OSError:
        pass


def _recv_head(sock: socket.socket, timeout: float) -> tuple[bytes, bytes] | None:
    """Read an HTTP request head. Returns (head, leftover_after_head) or None."""
    sock.settimeout(timeout)
    buf = b""
    while b"\r\n\r\n" not in buf:
        if len(buf) > MAX_HEAD_BYTES:
            return None
        try:
            chunk = sock.recv(4096)
        except OSError:
            return None
        if not chunk:
            return None
        buf += chunk
    head, _, rest = buf.partition(b"\r\n\r\n")
    return head, rest


def _respond(sock: socket.socket, status: str, body: bytes = b"", content_type: str = "text/plain",
             extra: str = "") -> None:
    head = (f"HTTP/1.1 {status}\r\nContent-Type: {content_type}\r\nContent-Length: {len(body)}\r\n"
            f"Cache-Control: no-store\r\nConnection: close\r\n{extra}\r\n").encode("ascii")
    try:
        sock.sendall(head + body)
        sock.shutdown(socket.SHUT_WR)       # lingering close: drain briefly so unread input cannot turn into an RST
        sock.settimeout(0.3)
        for _ in range(4):
            if not sock.recv(4096):
                break
    except OSError:
        pass


def _read_first_flight(sock: socket.socket, initial: bytes, timeout: float) -> bytes | None:
    """First client bytes after CONNECT. For a TLS record, wait until the whole record has arrived."""
    sock.settimeout(timeout)
    data = initial
    try:
        if not data:
            data = sock.recv(_CHUNK)
            if not data:
                return None
        if data[0] != 0x16:
            return data                        # not TLS: tunnel it untouched
        while len(data) < 5:
            more = sock.recv(_CHUNK)
            if not more:
                return None
            data += more
        total = 5 + int.from_bytes(data[3:5], "big")
        if total > MAX_RECORD_BYTES:
            return None
        while len(data) < total:
            more = sock.recv(_CHUNK)
            if not more:
                return None
            data += more
        return data
    except OSError:
        return None


def _relay(a: socket.socket, b: socket.socket, idle: float, stop: threading.Event) -> None:
    """Pipe bytes both ways until both sides closed, the idle timeout hit or stop was set."""
    open_socks = {a: b, b: a}
    last = time.monotonic()
    while open_socks and not stop.is_set():
        wait = min(1.0, max(0.05, idle - (time.monotonic() - last)))
        try:
            ready, _, broken = select.select(list(open_socks), [], list(open_socks), wait)
        except (OSError, ValueError):
            return
        if broken:
            return
        if not ready:
            if time.monotonic() - last >= idle:
                return
            continue
        for src in ready:
            dst = open_socks.get(src)
            if dst is None:
                continue
            try:
                data = src.recv(_CHUNK)
            except OSError:
                return
            if not data:
                del open_socks[src]
                try:
                    dst.shutdown(socket.SHUT_WR)
                except OSError:
                    return
                continue
            try:
                dst.sendall(data)
            except OSError:
                return
            last = time.monotonic()


# ---- the proxy ------------------------------------------------------------------------------------

class SplitProxy:
    def __init__(self, domains: Iterable[str], resolver=None, cache: StrategyCache | None = None,
                 ips_hint: dict | None = None, token: str = "", *, upstream_port: int = 443,
                 connect_timeout: float = 4.0, first_byte_timeout: float = 3.0, idle_timeout: float = 300.0,
                 head_timeout: float = 5.0, fragment_gap: float = 0.004, universal: bool = False,
                 system_resolver=system_resolve):
        self.domains: frozenset[str] = frozenset(d.lower().rstrip(".") for d in domains)
        self.resolver = resolver
        self.cache = cache if cache is not None else StrategyCache()
        self.ips_hint = {k.lower(): list(v) for k, v in (ips_hint or {}).items()}
        self.token = token
        self.upstream_port = upstream_port
        self.connect_timeout = connect_timeout
        self.first_byte_timeout = first_byte_timeout
        self.idle_timeout = idle_timeout
        self.head_timeout = head_timeout
        self.fragment_gap = fragment_gap
        self.universal = universal
        self._system_resolver = system_resolver

        self.port: int | None = None
        self.degraded = False
        self.last_error = ""
        self.tunnels_ok = 0
        self.tunnels_failed = 0
        self.last_strategy: dict[str, Strategy] = {}

        self._listener: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._slots = threading.BoundedSemaphore(UNIVERSAL_MAX_TUNNELS if universal else MAX_TUNNELS)
        self._lock = threading.Lock()
        self._conns: set[socket.socket] = set()
        self._failed_until: dict[str, float] = {}

    # ---- lifecycle --------------------------------------------------------------------------
    def start(self, preferred_port: int = 0) -> int:
        if self.is_alive():
            return self.port
        listener = None
        for candidate in ([preferred_port] if preferred_port else []) + [0]:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            try:
                sock.bind((LOOPBACK, candidate))
                sock.listen(64)
            except OSError as e:
                _close(sock)
                logger.warning(f"[NetUnblock] Cannot listen on {LOOPBACK}:{candidate}: {e}")
                continue
            listener = sock
            break
        if listener is None:
            raise OSError("could not open a local proxy port")
        self._stop.clear()
        self._listener = listener
        self.port = listener.getsockname()[1]
        self._thread = threading.Thread(target=self._accept_loop, name="net-unblock-proxy", daemon=True)
        self._thread.start()
        logger.info(f"[NetUnblock] Split proxy listening on {LOOPBACK}:{self.port} ({len(self.domains)} hosts)")
        return self.port

    def stop(self) -> None:
        self._stop.set()
        listener, self._listener = self._listener, None
        if listener is not None:
            _close(listener)
        with self._lock:
            conns, self._conns = list(self._conns), set()
        for conn in conns:
            _close(conn)
        thread, self._thread = self._thread, None
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=2.0)
        self.port = None

    def is_alive(self) -> bool:
        return self._listener is not None and self._thread is not None and self._thread.is_alive()

    def update(self, domains: Iterable[str], ips_hint: dict | None = None) -> None:
        """Replace the managed host set / validated IP hints while running."""
        self.domains = frozenset(d.lower().rstrip(".") for d in domains)
        if ips_hint is not None:
            self.ips_hint = {k.lower(): list(v) for k, v in ips_hint.items()}

    def pac(self) -> str:
        return build_pac(self.domains, self.port or 0, self.universal)

    # ---- accept loop ------------------------------------------------------------------------
    def _track(self, sock) -> None:
        with self._lock:
            self._conns.add(sock)

    def _untrack(self, sock) -> None:
        with self._lock:
            self._conns.discard(sock)
        _close(sock)

    def _accept_loop(self) -> None:
        listener = self._listener
        while not self._stop.is_set() and listener is not None:
            try:
                client, addr = listener.accept()
            except OSError:
                return
            if addr[0] != LOOPBACK or not self._slots.acquire(blocking=False):
                _close(client)
                continue
            self._track(client)
            threading.Thread(target=self._handle, args=(client,), name="net-unblock-tunnel", daemon=True).start()

    def _handle(self, client: socket.socket) -> None:
        try:
            parsed = _recv_head(client, self.head_timeout)
            if parsed is None:
                return
            head, rest = parsed
            line = head.split(b"\r\n", 1)[0].decode("latin-1")
            parts = line.split()
            if len(parts) < 2:
                return _respond(client, "400 Bad Request")
            method, target = parts[0].upper(), parts[1]
            if method == "GET":
                return self._serve_pac(client, target)
            if method == "CONNECT":
                return self._serve_connect(client, target, rest)
            _respond(client, "405 Method Not Allowed")
        except Exception:
            logger.exception("[NetUnblock] proxy handler crashed")
        finally:
            self._untrack(client)
            self._slots.release()

    def _serve_pac(self, client: socket.socket, path: str) -> None:
        path = path.split("?", 1)[0]
        if path not in (f"/bg-{self.token}.pac", "/proxy.pac"):
            return _respond(client, "404 Not Found")
        _respond(client, "200 OK", self.pac().encode("ascii"), "application/x-ns-proxy-autoconfig")

    # ---- CONNECT ----------------------------------------------------------------------------
    def _allowed(self, host: str) -> bool:
        return host in self.domains or (self.universal and public_target(host))

    def _serve_connect(self, client: socket.socket, target: str, rest: bytes) -> None:
        host, _, port = target.rpartition(":")
        host = host.strip("[]").lower().rstrip(".")
        if port != "443" or not self._allowed(host):
            return _respond(client, "403 Forbidden")
        try:
            client.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
        except OSError:
            return
        hello = _read_first_flight(client, rest, self.head_timeout * 2)
        if hello is None:
            return
        managed = host in self.domains
        opened = self._open_upstream(host, hello)
        if opened is None:
            self.tunnels_failed += 1
            if managed:                                  # a random failing site must not flag the whole engine
                self.degraded = True
            return
        upstream, first_reply = opened
        self._track(upstream)
        try:
            self.tunnels_ok += 1
            if managed:
                self.degraded = False
            if first_reply:
                client.sendall(first_reply)
            _relay(client, upstream, self.idle_timeout, self._stop)
        except OSError:
            pass
        finally:
            self._untrack(upstream)

    def _doh_ips(self, host: str) -> list[str]:
        if self.resolver is None:
            return []
        try:
            return list(self.resolver.resolve(host).ips)
        except Exception as e:
            logger.debug(f"[NetUnblock] DoH lookup for {host} failed: {e}")
            return []

    def _system_ips(self, host: str) -> list[str]:
        try:
            ips, _err = self._system_resolver(host)
        except Exception as e:
            logger.debug(f"[NetUnblock] system lookup for {host} failed: {e}")
            return []
        return [ip for ip in ips if usable_ip(ip)]

    def _ip_stages(self, host: str):
        """Yield candidate address lists, cheapest first; later stages only hold addresses not yet offered."""
        hinted = list(self.ips_hint.get(host, []))
        if host in self.domains or not self.universal:
            makers = [lambda: hinted + self._doh_ips(host)]
        elif usable_ip(host):
            makers = [lambda: [host]]
        else:
            makers = [lambda: hinted + self._system_ips(host), lambda: self._doh_ips(host)]
        seen: set[str] = set()
        for make in makers:
            fresh = [ip for ip in dict.fromkeys(make()) if ip not in seen]
            seen.update(fresh)
            if fresh:
                yield fresh

    def _connect_alive(self, ips: list[str], dead: set[str]):
        for ip in ips:
            if ip in dead:
                continue
            try:
                return ip, socket.create_connection((ip, self.upstream_port), timeout=self.connect_timeout)
            except OSError:
                dead.add(ip)
        return None, None

    def _open_upstream(self, host: str, hello: bytes):
        """Connect upstream and deliver the first client flight. Returns (socket, first_reply_bytes) or None."""
        managed = host in self.domains or not self.universal
        if not managed and time.monotonic() < self._failed_until.get(host, 0.0):
            self.last_error = f"{host} failed moments ago"
            return None
        dead: set[str] = set()
        offered = False
        for ips in self._ip_stages(host):
            offered = True
            opened = self._try_addresses(host, hello, ips, dead, managed)
            if opened is not None:
                self._failed_until.pop(host, None)
                return opened
            if self._stop.is_set():
                return None
        if not offered:
            self.last_error = f"no upstream address for {host}"
            return None
        if not managed:
            if len(self._failed_until) > 1000:
                self._failed_until.clear()
            self._failed_until[host] = time.monotonic() + FAIL_BACKOFF_S
        return None

    def _try_addresses(self, host: str, hello: bytes, ips: list[str], dead: set[str], managed: bool):
        if hello[0] != 0x16:                           # plain tunnel, nothing to split
            _ip, up = self._connect_alive(ips, dead)
            if up is None:
                self.last_error = f"cannot connect to any address of {host}"
                return None
            try:
                up.sendall(hello)
            except OSError:
                _close(up)
                return None
            return up, b""

        cached = self.cache.get(host)
        rest = [s for s in ESCALATION if s != cached]
        # managed hosts are known to be filtered: never start with the untouched hello; unknown hosts always do
        order = ([cached] if cached else []) + ([] if managed else [Strategy.NONE]) + rest
        for strategy in order:
            if self._stop.is_set():
                return None
            _ip, up = self._connect_alive(ips, dead)
            if up is None:
                self.last_error = f"cannot connect to any address of {host}"
                return None                              # not a strategy failure: keep the learned strategy
            try:
                send_fragments(up, split_hello(hello, strategy), gap=self.fragment_gap)
                up.settimeout(self.first_byte_timeout)
                reply = up.recv(_CHUNK)
            except OSError:
                reply = b""
            if reply and not managed and reply[0] == 0x15:      # alert instead of ServerHello: wrong server
                reply = b""
            if reply:
                if strategy != Strategy.NONE:
                    if strategy != cached:
                        logger.info(f"[NetUnblock] {host}: split strategy {strategy.name} works")
                    self.cache.put(host, strategy)
                elif cached:
                    self.cache.drop(host)                # the untouched hello works again
                self.last_strategy[host] = strategy
                return up, reply
            _close(up)
            if strategy == cached:
                self.cache.drop(host)                    # a stale learned strategy is dropped on first failure
        self.last_error = f"every split strategy failed for {host}"
        return None

    # ---- self test --------------------------------------------------------------------------
    def selftest(self, host: str, *, path: str = "/", timeout: float = 8.0,
                 context: ssl.SSLContext | None = None) -> tuple[bool, str]:
        """Fetch https://host/ THROUGH this proxy (CONNECT + verified TLS). Returns (ok, detail)."""
        if not self.is_alive():
            return False, "proxy is not running"
        contexts = [context] if context is not None else [client_context(v) for v in (0, 1, 2)]
        detail = "no attempt"
        for ctx in contexts:
            try:
                with socket.create_connection((LOOPBACK, self.port), timeout=timeout) as sock:
                    sock.settimeout(timeout)
                    sock.sendall(f"CONNECT {host}:443 HTTP/1.1\r\nHost: {host}:443\r\n\r\n".encode("ascii"))
                    head = _recv_head(sock, timeout)
                    if head is None or b" 200" not in head[0].split(b"\r\n", 1)[0]:
                        return False, "proxy refused the CONNECT"
                    with ctx.wrap_socket(sock, server_hostname=host) as tls:
                        tls.sendall(f"GET {path} HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n"
                                    f"User-Agent: BobGaming-selftest\r\nAccept-Encoding: identity\r\n\r\n".encode("ascii"))
                        status_line = tls.recv(512).split(b"\r\n", 1)[0].decode("latin-1")
                        if status_line.startswith("HTTP/"):
                            return True, status_line
                        return False, f"unexpected answer: {status_line[:60]!r}"
            except ssl.SSLCertVerificationError as e:
                detail = f"certificate: {e.verify_message}"
                continue                                   # try the next trust store
            except (OSError, ssl.SSLError) as e:
                return False, f"{e.__class__.__name__}: {e}"
        return False, detail
