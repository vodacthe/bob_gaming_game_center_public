"""User preferences + learned state for Network Unblock (~/.bobgaming/net_unblock.json)."""

from __future__ import annotations

import json
import logging
import os
import threading
from dataclasses import dataclass, field

from app.core.net_unblock.presets import GROUPS, MAX_CUSTOM_DOMAINS, normalize_host

logger = logging.getLogger(__name__)

CONSENT_VERSION = 1


def _default_groups() -> dict[str, bool]:
    return {gid: g.default_enabled for gid, g in GROUPS.items()}


@dataclass
class NetSettings:
    enabled: bool = False                 # master switch: re-apply on app start
    consent_version: int = 0              # CONSENT_VERSION once the user accepted the notice
    adult_confirmed: bool = False         # explicit 18+ confirmation for the adult group
    groups: dict = field(default_factory=_default_groups)
    custom_domains: list = field(default_factory=list)
    auto_apply: bool = True               # apply automatically when the app starts
    takeover: bool = False                # replace the user's own stale hosts lines
    all_sites: bool = False               # route every HTTPS site of the browsers through the adaptive proxy
    all_sites_active: bool = False        # all_sites was actually applied (proxy + PAC running)
    dpi_engine: bool = False              # use the packet engine (WinDivert driver) instead of the local proxy
    dpi_preset: str = "balanced"         # key of dpi_engine.PRESETS
    dpi_active: bool = False              # the packet engine was actually started
    refresh_hours: int = 6
    proxy_port: int = 0                   # last listener port (reused so the PAC URL stays stable)
    pac_token: str = ""                   # random id used in the PAC URL
    last_refresh: float = 0.0
    # host -> {"mode": "hosts"|"proxy"|"both", "ips": [...], "strategy": int, "ts": float}
    applied: dict = field(default_factory=dict)
    # strategy cache: key -> {"strategy": int, "ts": float}
    learned: dict = field(default_factory=dict)

    # ---- derived ----------------------------------------------------------------------------
    def selected_groups(self) -> list[str]:
        out = []
        for gid in GROUPS:
            if not self.groups.get(gid, GROUPS[gid].default_enabled):
                continue
            if GROUPS[gid].adult and not self.adult_confirmed:
                continue
            out.append(gid)
        return out

    def clean_custom_domains(self) -> list[str]:
        seen, out = set(), []
        for raw in self.custom_domains:
            host = normalize_host(raw)
            if host and host not in seen:
                seen.add(host)
                out.append(host)
        return out[:MAX_CUSTOM_DOMAINS]


class SettingsStore:
    """Thread-safe load/save with atomic replace. Unknown keys are ignored, missing keys defaulted."""

    def __init__(self, path: str):
        self.path = path
        self._lock = threading.RLock()
        self.data = NetSettings()
        self.load()

    def load(self) -> NetSettings:
        with self._lock:
            data = NetSettings()
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                if isinstance(raw, dict):
                    for key, value in raw.items():
                        if hasattr(data, key) and type(value) is type(getattr(data, key)):
                            setattr(data, key, value)
                    merged = _default_groups()
                    merged.update({k: bool(v) for k, v in (data.groups or {}).items() if k in GROUPS})
                    data.groups = merged
            except FileNotFoundError:
                pass
            except (OSError, ValueError) as e:
                logger.warning(f"[NetUnblock] Could not read settings ({e}); using defaults")
            self.data = data
            return data

    def save(self) -> bool:
        with self._lock:
            try:
                os.makedirs(os.path.dirname(self.path), exist_ok=True)
                tmp = self.path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.data.__dict__, f, indent=2, ensure_ascii=False)
                os.replace(tmp, self.path)
                return True
            except OSError as e:
                logger.error(f"[NetUnblock] Failed to save settings: {e}")
                return False

    def delete(self) -> None:
        with self._lock:
            for p in (self.path, self.path + ".tmp"):
                try:
                    os.remove(p)
                except OSError:
                    pass
            self.data = NetSettings()
