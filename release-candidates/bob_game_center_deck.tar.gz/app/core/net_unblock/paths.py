"""Filesystem locations used by Network Unblock, plus the "never touch the real system in tests" guard."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass

ALLOW_REAL_ENV = "BOBGAMING_ALLOW_REAL_SYSTEM"


@dataclass(frozen=True)
class NetPaths:
    hosts: str       # the Windows hosts file
    state_dir: str   # journal + hosts backups (admin-writable, outside the user profile)
    settings: str    # user preferences JSON

    @property
    def journal(self) -> str:
        return os.path.join(self.state_dir, "journal.json")


def real_hosts_path() -> str:
    root = os.environ.get("SystemRoot") or os.environ.get("windir") or r"C:\Windows"
    return os.path.join(root, "System32", "drivers", "etc", "hosts")


def default_paths() -> NetPaths:
    from app.config import CONFIG_DIR
    program_data = os.environ.get("ProgramData") or os.environ.get("ALLUSERSPROFILE") or r"C:\ProgramData"
    return NetPaths(
        hosts=real_hosts_path(),
        state_dir=os.path.join(program_data, "BobGaming", "net_unblock"),
        settings=os.path.join(CONFIG_DIR, "net_unblock.json"),
    )


def running_under_test() -> bool:
    if getattr(sys, "frozen", False):
        return False
    if "pytest" in sys.modules or "PYTEST_CURRENT_TEST" in os.environ:
        return True
    main_mod = sys.modules.get("__main__")
    if main_mod:
        main_file = getattr(main_mod, "__file__", "") or ""
        if "unittest" in main_file or "pytest" in main_file:
            return True
    return False


def assert_safe_for_tests(what: str) -> None:
    """Refuse to touch real system state (hosts/registry/ProgramData) while pytest is running."""
    if running_under_test() and os.environ.get(ALLOW_REAL_ENV) != "1":
        raise RuntimeError(
            f"Refusing to touch real system state ({what}) under pytest; "
            f"inject temporary paths / a fake SystemOps (or set {ALLOW_REAL_ENV}=1)."
        )


def same_path(a: str, b: str) -> bool:
    return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))
