"""
Write-ahead journal + next-start recovery.

`main.py::_kill_previous_instance()` ends the old process with TerminateProcess (no cleanup runs), so every system
change is journaled BEFORE it is made (`pending` + what to restore), and marked `applied` only after it was read back.
`recover_on_start()` repairs whatever a dead owner left behind. The journal lives in an admin-writable folder
(%ProgramData%\\BobGaming\\net_unblock) so an unprivileged process cannot steer an elevated one.

Policy: the hosts block is the actual fix and survives app exit; the PAC value dies with the process and is
restored here when its owner is gone.
"""

from __future__ import annotations

import copy
import json
import logging
import os
import time

from app.core.net_unblock import sysproxy
from app.core.net_unblock.hosts_manager import HostsError, HostsManager, sha256
from app.core.net_unblock.paths import NetPaths, default_paths

logger = logging.getLogger(__name__)

VERSION = 1
PENDING, APPLIED, REVERTING, NONE = "pending", "applied", "reverting", "none"
RECOVERY_BUDGET_S = 5.0


def empty() -> dict:
    return {"v": VERSION, "owner": None, "pac": {"state": NONE}, "hosts": {"state": NONE}}


class JournalStore:
    """Atomic JSON file with a `.prev` generation (tmp -> fsync -> replace)."""

    def __init__(self, path: str):
        self.path = path
        self.prev = path + ".prev"

    @staticmethod
    def _read(path: str):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return None
        if isinstance(data, dict) and data.get("v") == VERSION and isinstance(data.get("hosts"), dict) \
                and isinstance(data.get("pac"), dict):
            return data
        return None

    def load(self) -> dict:
        """Current journal; falls back to the previous generation when the current one is missing/corrupt."""
        return self._read(self.path) or self._read(self.prev) or empty()

    def save(self, data: dict) -> None:
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=1)
            f.flush()
            os.fsync(f.fileno())
        if os.path.exists(self.path):
            os.replace(self.path, self.prev)
        os.replace(tmp, self.path)

    def delete(self) -> None:
        for path in (self.path, self.prev, self.path + ".tmp"):
            try:
                os.remove(path)
            except OSError:
                pass


class Journal:
    """In-memory journal bound to a store; every transition is persisted immediately (write-ahead)."""

    def __init__(self, store: JournalStore):
        self.store = store
        self.data = store.load()

    # ---- generic ----------------------------------------------------------------------------
    def _save(self) -> None:
        self.store.save(self.data)

    @property
    def hosts(self) -> dict:
        return self.data["hosts"]

    @property
    def pac(self) -> dict:
        return self.data["pac"]

    def is_clean(self) -> bool:
        return self.hosts.get("state") == NONE and self.pac.get("state") == NONE

    def set_owner(self, pid: int, ctime) -> None:
        self.data["owner"] = {"pid": int(pid), "ctime": ctime}
        self._save()

    def clear_if_clean(self) -> None:
        if self.is_clean():
            self.store.delete()
            self.data = empty()

    def reset(self) -> None:
        self.store.delete()
        self.data = empty()

    # ---- hosts ------------------------------------------------------------------------------
    def hosts_pending(self, pre_sha: str, post_sha: str, backup: str, added_eol: bool, took_over: list) -> None:
        """Write-ahead record: both shas are known before the file is touched, so recovery can tell which one it sees."""
        self.data["hosts"] = {"state": PENDING, "pre_sha": pre_sha, "post_sha": post_sha, "backup": backup,
                              "added_eol": bool(added_eol), "took_over": list(took_over)}
        self._save()

    def hosts_applied(self) -> None:
        self.hosts["state"] = APPLIED
        self._save()

    def hosts_reverting(self) -> None:
        self.hosts["state"] = REVERTING
        self._save()

    def hosts_none(self) -> None:
        self.data["hosts"] = {"state": NONE}
        self._save()

    # ---- PAC --------------------------------------------------------------------------------
    def pac_pending(self, url: str, pre: dict) -> None:
        self.data["pac"] = {"state": PENDING, "url": url, "pre": copy.deepcopy(pre)}
        self._save()

    def pac_applied(self) -> None:
        self.pac["state"] = APPLIED
        self._save()

    def pac_reverting(self) -> None:
        self.pac["state"] = REVERTING
        self._save()

    def pac_none(self) -> None:
        self.data["pac"] = {"state": NONE}
        self._save()


# ---- recovery ---------------------------------------------------------------------------------

def owner_alive(owner, system) -> bool:
    """True if the process that wrote the journal is still running (pid AND creation time must match)."""
    if not owner:
        return False
    token = system.process_token(int(owner.get("pid", 0)))
    return token is not None and token == owner.get("ctime")


def _recover_pac(journal: Journal, system, notes: list[str]) -> None:
    pac = journal.pac
    if pac.get("state") == NONE:
        return
    restored = sysproxy.restore(system, pac.get("pre"), pac.get("url"))
    notes.append("Restored the Windows proxy script setting left by a previous run" if restored
                 else "Windows proxy script setting was already clean")
    journal.pac_none()


def _recover_hosts(journal: Journal, hosts: HostsManager, notes: list[str]) -> None:
    state = journal.hosts.get("state")
    if state in (None, NONE):
        return
    current = hosts.read_bytes()
    now = sha256(current)
    pre, post = journal.hosts.get("pre_sha"), journal.hosts.get("post_sha")

    if state == APPLIED:
        return                                          # a valid block is the fix: keep it
    if state == PENDING:
        if now == pre:
            notes.append("Hosts file was not modified by the interrupted run")
            journal.hosts_none()
        elif post and now == post:
            notes.append("Hosts block from the interrupted run is complete; keeping it")
            journal.hosts_applied()
        else:
            _restore_hosts_backup(journal, hosts, current, pre, notes)
        return
    if state == REVERTING:
        try:
            result = hosts.remove_block(strip_added_eol=bool(journal.hosts.get("added_eol")))
            notes.append("Finished removing the hosts block" if result else "Hosts block was already removed")
            journal.hosts_none()
        except HostsError as e:
            notes.append(f"Could not finish removing the hosts block: {e}")


def _restore_hosts_backup(journal: Journal, hosts: HostsManager, current: bytes, pre: str, notes: list[str]) -> None:
    backup = journal.hosts.get("backup") or ""
    try:
        with open(backup, "rb") as f:
            saved = f.read()
    except OSError:
        saved = None
    if saved is not None and sha256(saved) == pre:
        hosts.restore_raw(saved)
        notes.append("Hosts file was damaged by an interrupted run; restored it from the backup")
        journal.hosts_none()
        return
    view = hosts.view(current)
    if view.damaged or view.block_span:
        notes.append("Hosts file differs from the journal and no matching backup exists; left untouched")
    journal.hosts_none()


def recover_on_start(paths: NetPaths | None = None, system=None, *, hosts: HostsManager | None = None,
                     budget_s: float = RECOVERY_BUDGET_S, clock=time.monotonic) -> list[str]:
    """Repair what a dead previous instance left behind. Never raises; returns human-readable notes."""
    notes: list[str] = []
    try:
        paths = paths or default_paths()
        if system is None:
            from app.core.net_unblock.system import SystemOps
            system = SystemOps()
        if not system.is_admin():
            return notes
        store = JournalStore(paths.journal)
        if not (os.path.exists(store.path) or os.path.exists(store.prev)):
            return notes
        journal = Journal(store)
        if journal.is_clean():
            journal.reset()
            return notes
        if owner_alive(journal.data.get("owner"), system):
            return notes                                 # another live instance owns these changes
        deadline = clock() + budget_s
        hosts = hosts or HostsManager(paths.hosts, os.path.join(paths.state_dir, "backups"), flush=system.flush_dns)
        for step in (lambda: _recover_pac(journal, system, notes),
                     lambda: _recover_hosts(journal, hosts, notes)):
            if clock() > deadline:
                notes.append("Recovery time budget exceeded; the rest will be retried next start")
                break
            step()
        journal.clear_if_clean()
        for note in notes:
            logger.info(f"[NetUnblock] Recovery: {note}")
    except Exception as e:
        logger.warning(f"[NetUnblock] Recovery failed: {e}")
    return notes
