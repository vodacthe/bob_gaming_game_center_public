"""
Windows proxy-settings helper: PAC-only routing through the WinINET "Use setup script" value.

Only `AutoConfigURL` is ever written. `ProxyEnable` / `ProxyServer` / `ProxyOverride` are read-only here, so a
stale `ProxyServer` left by some other tool is never touched. Restore is exact (type + data) and happens only
while the current value is still ours.
"""

from __future__ import annotations

import logging
import re

logger = logging.getLogger(__name__)

INTERNET_SETTINGS_KEY = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
POLICY_KEY = r"Software\Policies\Microsoft\Internet Explorer\Control Panel"
SNAPSHOT_VALUES = ("ProxyEnable", "ProxyServer", "ProxyOverride", "AutoConfigURL")
PAC_VALUE = "AutoConfigURL"
REG_SZ = 1          # winreg.REG_SZ (winreg itself is only imported by system.py)

_OURS = re.compile(r"^http://127\.0\.0\.1:\d+/bg-[0-9a-f]{8,}\.pac$")


def pac_url(port: int, token: str) -> str:
    return f"http://127.0.0.1:{int(port)}/bg-{token}.pac"


def is_ours(url) -> bool:
    return isinstance(url, str) and bool(_OURS.match(url.strip()))


def snapshot(system) -> dict:
    """Exact (value, type) of every proxy value, or None when it does not exist."""
    return {name: system.reg_get(INTERNET_SETTINGS_KEY, name) for name in SNAPSHOT_VALUES}


def _value(entry):
    return entry[0] if entry else None


def _policy_enabled(system, name: str) -> bool:
    for getter in (system.reg_get_machine, system.reg_get):
        entry = getter(POLICY_KEY, name)
        if entry and entry[0] == 1:
            return True
    return False


def foreign_config(system, snap: dict | None = None) -> str | None:
    """Reason why we must not install our PAC (someone else owns the proxy settings), else None."""
    snap = snap if snap is not None else snapshot(system)
    pac = _value(snap.get(PAC_VALUE))
    if isinstance(pac, str) and pac.strip() and not is_ours(pac):
        return f"another automatic proxy script is already configured ({pac.strip()})"
    if _value(snap.get("ProxyEnable")) == 1:
        return "a manual proxy server is enabled in Windows settings"
    if _policy_enabled(system, "Proxy") or _policy_enabled(system, "AutoConfig"):
        return "proxy settings are managed by a Windows policy"
    return None


def set_pac(system, url: str) -> None:
    """Write ONLY AutoConfigURL, then tell browsers to re-read the settings."""
    system.reg_set(INTERNET_SETTINGS_KEY, PAC_VALUE, url, REG_SZ)
    system.notify_proxy_changed()


def current_pac(system):
    return _value(system.reg_get(INTERNET_SETTINGS_KEY, PAC_VALUE))


def restore(system, snap: dict | None, ours_url: str | None = None) -> bool:
    """Put AutoConfigURL back to its snapshot (delete if it did not exist).

    Does nothing (returns False) when the current value is no longer ours: another tool took over
    and we must not undo its change. Returns True when something was restored.
    """
    current = current_pac(system)
    mine = current == ours_url if ours_url else is_ours(current)
    if not mine:
        return False
    previous = (snap or {}).get(PAC_VALUE)
    if previous is None:
        system.reg_delete(INTERNET_SETTINGS_KEY, PAC_VALUE)
    else:
        system.reg_set(INTERNET_SETTINGS_KEY, PAC_VALUE, previous[0], previous[1])
    system.notify_proxy_changed()
    return True
