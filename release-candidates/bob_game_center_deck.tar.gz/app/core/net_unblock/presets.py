"""Site groups (presets) and host-name validation."""

from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass

_LABEL_RE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$")

# Host suffixes we must never write into the hosts file (Defender flags tampering with these as
# SettingsModifier:Win32/HostsFileHijack) nor proxy.
DENY_SUFFIXES = (
    "microsoft.com", "windows.com", "windowsupdate.com", "live.com", "office.com", "office365.com",
    "xbox.com", "xboxlive.com", "bing.com", "msn.com", "azure.com", "skype.com", "msftconnecttest.com",
    "msftncsi.com", "localhost", "local", "internal",
    # security vendors
    "kaspersky.com", "avast.com", "avg.com", "avira.com", "bitdefender.com", "mcafee.com",
    "norton.com", "symantec.com", "eset.com", "malwarebytes.com", "trendmicro.com", "sophos.com",
)

MAX_CUSTOM_DOMAINS = 50


@dataclass(frozen=True)
class Group:
    id: str
    label: str
    description: str
    hosts: tuple[str, ...]
    default_enabled: bool = False
    adult: bool = False


GROUPS: dict[str, Group] = {
    "steam": Group(
        id="steam",
        label="Steam",
        description="Cửa hàng, cộng đồng, đăng nhập và CDN",
        default_enabled=True,
        hosts=(
            "store.steampowered.com", "steampowered.com", "api.steampowered.com",
            "login.steampowered.com", "checkout.steampowered.com", "help.steampowered.com",
            "steamcommunity.com", "www.steamcommunity.com",
            "cdn.akamai.steamstatic.com", "community.akamai.steamstatic.com",
            "shared.akamai.steamstatic.com", "store.akamai.steamstatic.com",
            "avatars.akamai.steamstatic.com", "clan.akamai.steamstatic.com",
            "steamcdn-a.akamaihd.net", "steamcommunity-a.akamaihd.net", "steamuserimages-a.akamaihd.net",
        ),
    ),
    "reddit": Group(
        id="reddit",
        label="Reddit",
        description="reddit.com, redd.it và máy chủ media",
        default_enabled=True,
        hosts=(
            "reddit.com", "www.reddit.com", "old.reddit.com", "new.reddit.com", "sh.reddit.com",
            "gql.reddit.com", "gateway.reddit.com", "oauth.reddit.com",
            "redd.it", "v.redd.it", "i.redd.it", "preview.redd.it", "external-preview.redd.it",
            "packaged-media.redd.it", "styles.redditmedia.com", "redditmedia.com",
            "redditstatic.com", "www.redditstatic.com",
        ),
    ),
    "adult": Group(
        id="adult",
        label="Adult sites (18+)",
        description="Trang web người lớn. Mặc định tắt",
        default_enabled=False,
        adult=True,
        hosts=(
            "pornhub.com", "www.pornhub.com", "xvideos.com", "www.xvideos.com",
            "xnxx.com", "www.xnxx.com", "xhamster.com", "www.xhamster.com",
            "redtube.com", "www.redtube.com", "youporn.com", "www.youporn.com",
            "spankbang.com", "www.spankbang.com",
        ),
    ),
    "medium": Group(
        id="medium",
        label="Medium",
        description="medium.com và máy chủ ảnh CDN",
        default_enabled=False,
        hosts=(
            "medium.com", "www.medium.com", "miro.medium.com", "cdn-images-1.medium.com", "glyph.medium.com",
        ),
    ),
}


def is_denied(host: str) -> bool:
    host = host.lower().rstrip(".")
    return any(host == s or host.endswith("." + s) for s in DENY_SUFFIXES)


def normalize_host(value: str) -> str | None:
    """Return a clean ASCII host name, or None if the input is not an acceptable domain."""
    if not isinstance(value, str):
        return None
    s = value.strip().lower()
    if not s:
        return None
    for scheme in ("https://", "http://"):
        if s.startswith(scheme):
            s = s[len(scheme):]
    s = s.split("/", 1)[0].split("?", 1)[0].split("#", 1)[0]
    if "@" in s:
        return None
    if ":" in s:                       # strip :port (reject IPv6 literals below)
        head, _, tail = s.rpartition(":")
        if tail.isdigit() and ":" not in head:
            s = head
        else:
            return None
    s = s.rstrip(".")
    if not s or len(s) > 253:
        return None
    try:
        ipaddress.ip_address(s)
        return None                    # IP literals are not domains
    except ValueError:
        pass
    try:
        s = s.encode("idna").decode("ascii")
    except UnicodeError:
        return None
    labels = s.split(".")
    if len(labels) < 2 or not all(_LABEL_RE.match(lbl) for lbl in labels):
        return None
    if is_denied(s):
        return None
    return s


def group_hosts(group_id: str) -> tuple[str, ...]:
    g = GROUPS.get(group_id)
    return g.hosts if g else ()
