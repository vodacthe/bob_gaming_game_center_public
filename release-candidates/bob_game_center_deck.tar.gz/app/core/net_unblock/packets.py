"""
Raw IPv4/TCP/UDP packet helpers for the packet engine (pure Python, no driver, no I/O).

Only what the engine needs: parse a packet, rebuild a TCP segment with another payload / sequence number / TTL,
and compute (or deliberately corrupt) checksums. IPv6 and IP fragments are ignored (parse returns None).
"""

from __future__ import annotations

import struct
from dataclasses import dataclass

TCP, UDP = 6, 17
FLAG_FIN, FLAG_SYN, FLAG_RST, FLAG_PSH, FLAG_ACK = 0x01, 0x02, 0x04, 0x08, 0x10


@dataclass
class Ip4:
    ihl: int            # IP header length in bytes
    total: int          # IP total length
    proto: int
    ttl: int
    ident: int
    src: str
    dst: str
    l4: int             # offset of the TCP/UDP header (== ihl)


@dataclass
class Tcp4(Ip4):
    sport: int = 0
    dport: int = 0
    seq: int = 0
    ack: int = 0
    flags: int = 0
    payload_off: int = 0

    def payload(self, raw: bytes) -> bytes:
        return raw[self.payload_off:self.total]


@dataclass
class Udp4(Ip4):
    sport: int = 0
    dport: int = 0
    payload_off: int = 0

    def payload(self, raw: bytes) -> bytes:
        return raw[self.payload_off:self.total]


def _addr(raw: bytes) -> str:
    return ".".join(str(b) for b in raw)


def _parse_ip(raw: bytes) -> Ip4 | None:
    if len(raw) < 20 or raw[0] >> 4 != 4:
        return None
    ihl = (raw[0] & 0x0F) * 4
    total = struct.unpack("!H", raw[2:4])[0]
    if ihl < 20 or total > len(raw) or total < ihl:
        return None
    if struct.unpack("!H", raw[6:8])[0] & 0x3FFF:          # fragment (MF flag or offset): not ours
        return None
    return Ip4(ihl, total, raw[9], raw[8], struct.unpack("!H", raw[4:6])[0], _addr(raw[12:16]), _addr(raw[16:20]), ihl)


def parse_tcp4(raw: bytes) -> Tcp4 | None:
    ip = _parse_ip(raw)
    if ip is None or ip.proto != TCP or ip.total < ip.ihl + 20:
        return None
    off = ip.ihl
    thl = (raw[off + 12] >> 4) * 4
    if thl < 20 or ip.total < off + thl:
        return None
    sport, dport, seq, ack = struct.unpack("!HHII", raw[off:off + 12])
    return Tcp4(**ip.__dict__, sport=sport, dport=dport, seq=seq, ack=ack, flags=raw[off + 13],
                payload_off=off + thl)


def parse_udp4(raw: bytes) -> Udp4 | None:
    ip = _parse_ip(raw)
    if ip is None or ip.proto != UDP or ip.total < ip.ihl + 8:
        return None
    sport, dport = struct.unpack("!HH", raw[ip.ihl:ip.ihl + 4])
    return Udp4(**ip.__dict__, sport=sport, dport=dport, payload_off=ip.ihl + 8)


def is_private(ip: str) -> bool:
    a, b, *_ = (int(p) for p in ip.split("."))
    return (a in (0, 10, 127) or (a == 169 and b == 254) or (a == 172 and 16 <= b <= 31)
            or (a == 192 and b == 168) or a >= 224)


# ---- checksums ----------------------------------------------------------------------------------------

def _sum16(data: bytes) -> int:
    if len(data) % 2:
        data += b"\x00"
    total = sum(struct.unpack(f"!{len(data) // 2}H", data))
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return total


def ip_checksum(header: bytes) -> int:
    return ~_sum16(header[:10] + b"\x00\x00" + header[12:]) & 0xFFFF


def tcp_checksum(raw: bytes, info: Ip4) -> int:
    segment = raw[info.l4:info.total]
    pseudo = raw[12:20] + struct.pack("!BBH", 0, TCP, len(segment))
    return ~_sum16(pseudo + segment[:16] + b"\x00\x00" + segment[18:]) & 0xFFFF


def build_segment(raw: bytes, info: Tcp4, payload: bytes, *, seq: int | None = None, ttl: int | None = None,
                  ident: int | None = None, flags: int | None = None, bad_checksum: bool = False) -> bytes:
    """Copy of the packet `raw` carrying `payload` (headers and TCP options kept), checksums recomputed."""
    head = bytearray(raw[:info.payload_off])
    total = info.payload_off + len(payload)
    struct.pack_into("!H", head, 2, total)
    if ident is not None:
        struct.pack_into("!H", head, 4, ident & 0xFFFF)
    if ttl is not None:
        head[8] = ttl & 0xFF
    if seq is not None:
        struct.pack_into("!I", head, info.l4 + 4, seq & 0xFFFFFFFF)
    if flags is not None:
        head[info.l4 + 13] = flags & 0xFF
    packet = bytearray(head + payload)
    struct.pack_into("!H", packet, 10, 0)
    struct.pack_into("!H", packet, 10, ip_checksum(bytes(packet[:info.ihl])))
    rebuilt = Ip4(info.ihl, total, TCP, 0, 0, "", "", info.l4)
    checksum = tcp_checksum(bytes(packet), rebuilt)
    if bad_checksum:
        checksum ^= 0xFFFF
    struct.pack_into("!H", packet, info.l4 + 16, checksum)
    return bytes(packet)


def refresh_checksums(raw: bytes) -> bytes:
    """Same packet with valid IP and TCP checksums (outbound packets may carry offloaded, empty ones)."""
    info = parse_tcp4(raw)
    return raw if info is None else build_segment(raw, info, info.payload(raw))
