"""
OS access seam for Network Unblock.

This is the ONLY module of the feature allowed to touch winreg / ctypes / subprocess.
Everything else receives a SystemOps instance, so tests inject a fake and never touch the
real registry, DNS cache or processes.
"""

from __future__ import annotations

import logging
import sys

from app.core.net_unblock.paths import assert_safe_for_tests

logger = logging.getLogger(__name__)

# WinINET option flags (wininet.h)
INTERNET_OPTION_REFRESH = 37
INTERNET_OPTION_SETTINGS_CHANGED = 39

_STILL_ACTIVE = 259
_PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


class SystemOps:
    """Real Windows implementation. Registry access is HKEY_CURRENT_USER only."""

    def __init__(self):
        assert_safe_for_tests("SystemOps")

    # ---- privileges -------------------------------------------------------------------------
    def is_admin(self) -> bool:
        from app.utils.helpers import is_admin
        return is_admin()

    # ---- registry (HKCU) --------------------------------------------------------------------
    def reg_get(self, key_path: str, name: str):
        """Return (value, type) or None if the value/key does not exist."""
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_READ) as key:
                value, reg_type = winreg.QueryValueEx(key, name)
                return value, reg_type
        except FileNotFoundError:
            return None
        except OSError as e:
            logger.debug(f"[NetUnblock] reg_get {key_path}\\{name}: {e}")
            return None

    def reg_set(self, key_path: str, name: str, value, reg_type: int) -> None:
        import winreg
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, name, 0, reg_type, value)

    def reg_delete(self, key_path: str, name: str) -> None:
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
                winreg.DeleteValue(key, name)
        except FileNotFoundError:
            pass

    def reg_get_machine(self, key_path: str, name: str):
        """Read-only HKLM lookup (used to detect policy-managed proxy settings)."""
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0, winreg.KEY_READ) as key:
                return winreg.QueryValueEx(key, name)
        except OSError:
            return None

    def notify_proxy_changed(self) -> None:
        """Tell WinINET consumers (browsers) that proxy settings changed."""
        import ctypes
        from ctypes import wintypes
        wininet = ctypes.WinDLL("wininet", use_last_error=True)
        fn = wininet.InternetSetOptionW
        fn.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPVOID, wintypes.DWORD]
        fn.restype = wintypes.BOOL
        fn(None, INTERNET_OPTION_SETTINGS_CHANGED, None, 0)
        fn(None, INTERNET_OPTION_REFRESH, None, 0)

    # ---- DNS cache --------------------------------------------------------------------------
    def flush_dns(self) -> bool:
        try:
            import ctypes
            dnsapi = ctypes.WinDLL("dnsapi", use_last_error=True)
            dnsapi.DnsFlushResolverCache.restype = ctypes.c_int
            if dnsapi.DnsFlushResolverCache():
                return True
        except Exception as e:
            logger.debug(f"[NetUnblock] DnsFlushResolverCache failed: {e}")
        try:
            from app.utils.helpers import run_hidden
            return run_hidden(["ipconfig", "/flushdns"], timeout=10).returncode == 0
        except Exception as e:
            logger.warning(f"[NetUnblock] ipconfig /flushdns failed: {e}")
            return False

    # ---- processes --------------------------------------------------------------------------
    def running_process_names(self) -> set[str]:
        """Lower-case image names of every running process (empty set when the list cannot be read)."""
        try:
            from app.utils.helpers import run_hidden
            result = run_hidden(["tasklist", "/fo", "csv", "/nh"], timeout=15)
        except Exception as e:
            logger.debug(f"[NetUnblock] tasklist failed: {e}")
            return set()
        names = set()
        for line in result.stdout.splitlines():
            if line.startswith('"'):
                names.add(line[1:].split('"', 1)[0].lower())
        return names

    def process_token(self, pid: int):
        """Creation time (FILETIME as int) of a live process, or None if it is gone.

        (pid, creation time) identifies a process instance, so a reused PID never matches.
        """
        if sys.platform != "win32":
            return None
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.OpenProcess.restype = wintypes.HANDLE
        k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        handle = k32.OpenProcess(_PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not handle:
            return None
        try:
            code = wintypes.DWORD()
            if not k32.GetExitCodeProcess(handle, ctypes.byref(code)) or code.value != _STILL_ACTIVE:
                return None
            created, exited, kernel, user = (wintypes.FILETIME() for _ in range(4))
            if not k32.GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(exited),
                                       ctypes.byref(kernel), ctypes.byref(user)):
                return None
            return (created.dwHighDateTime << 32) | created.dwLowDateTime
        finally:
            k32.CloseHandle(handle)
