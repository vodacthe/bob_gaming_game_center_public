"""
Packet engine: a GoodbyeDPI-style, driverless-looking-but-driver-backed DPI bypass written in Python.

It captures only the packets it must touch (outbound TLS ClientHello on :443, SYN-ACKs for TTL discovery, injected
RSTs from passive DPI, QUIC initials) and re-injects everything else untouched. For a ClientHello it can

  * send a FAKE hello first (SNI swapped for a harmless host) that the server never accepts: low TTL derived from the
    SYN-ACK, a corrupted TCP checksum and/or an old sequence number - the DPI box sees it, the server drops it;
  * split the real hello into two TCP segments, optionally in reverse order, so the filter cannot match the SNI.

Algorithms follow ValdikSS/GoodbyeDPI (Apache-2.0) options -f/-e/--reverse-frag/--auto-ttl/--wrong-chksum/
--wrong-seq/-p/-q. Packet I/O goes through windivert.py (WinDivert 2.2.2, LGPL-3.0). `PacketProcessor` is pure and
unit-tested; `DpiEngine` owns the capture thread. IPv6 and HTTP (port 80) are intentionally not handled.
"""

from __future__ import annotations

import logging
import os
import threading
from collections import Counter
from dataclasses import dataclass
from typing import Callable

from app.core.net_unblock import packets as pk
from app.core.net_unblock import windivert
from app.core.net_unblock.tls import _cut_point, parse_client_hello

logger = logging.getLogger(__name__)

# Processes that mean "an anti-cheat is (about to be) active": the packet driver must not run next to them.
ANTICHEAT_PROCESSES = frozenset({
    "easyanticheat.exe", "easyanticheat_eos.exe", "easyanticheat_launcher.exe", "beservice.exe", "bedaisy.exe",
    "vgc.exe", "vgtray.exe", "faceit.exe", "faceitclient.exe", "faceitservice.exe", "gameguard.des",
})
FAKE_SNI_SUFFIX = b".w3.org"
MIN_FAKE_SNI_LEN = 8
WRONG_SEQ_DELTA = 10000
MIN_TTL_DISTANCE = 3        # --min-ttl: closer servers get no TTL-limited fake (it could reach them)
AUTO_TTL_MAX = 10           # the fake never travels further than this many hops
MAX_TRACKED_SERVERS = 4096
HTTPS_PORT = 443


@dataclass(frozen=True)
class DpiPreset:
    id: str
    label: str
    description: str
    frag_pos: int               # split offset inside the ClientHello; 0 = right inside the SNI
    reverse: bool = False       # send the second segment first
    fake_ttl: bool = False      # fake hello with a TTL that dies before the server (needs a seen SYN-ACK)
    fake_badsum: bool = False   # fake hello with a corrupted TCP checksum
    fake_badseq: bool = False   # fake hello with a sequence number in the past
    block_passive: bool = False  # drop RSTs injected by passive DPI (IP id 0/1)
    block_quic: bool = False     # drop QUIC initials so browsers fall back to TCP/TLS


PRESETS: dict[str, DpiPreset] = {p.id: p for p in (
    DpiPreset("light", "Light - split only", "Splits the ClientHello inside the host name. Gentlest, works on simple filters.",
              frag_pos=0),
    DpiPreset("balanced", "Balanced (recommended)", "Reverse split at byte 2 + fake hello with automatic TTL, "
              "blocks injected resets and QUIC. Similar to GoodbyeDPI -5.",
              frag_pos=2, reverse=True, fake_ttl=True, block_passive=True, block_quic=True),
    DpiPreset("strong", "Strong - fake with bad checksum", "Reverse split at byte 2 + fake hello with a wrong "
              "checksum and sequence number. Similar to GoodbyeDPI -9; may fail behind some VMs/routers.",
              frag_pos=2, reverse=True, fake_badsum=True, fake_badseq=True, block_passive=True, block_quic=True),
)}
DEFAULT_PRESET = "balanced"


def get_preset(preset_id: str) -> DpiPreset:
    return PRESETS.get(preset_id, PRESETS[DEFAULT_PRESET])


def build_filter(preset: DpiPreset) -> str:
    """WinDivert filter that captures nothing but the packets the preset acts on."""
    parts = [f"outbound and ip and tcp.DstPort == {HTTPS_PORT} and tcp.PayloadLength > 0 and tcp.Payload[0] == 0x16"]
    if preset.fake_ttl:
        parts.append(f"inbound and ip and tcp.SrcPort == {HTTPS_PORT} and tcp.Syn and tcp.Ack")
    if preset.block_passive:
        parts.append(f"inbound and ip and tcp.Rst and (ip.Id == 0 or ip.Id == 1) and "
                     f"(tcp.SrcPort == {HTTPS_PORT} or tcp.SrcPort == 80)")
    if preset.block_quic:
        parts.append(f"outbound and ip and udp.DstPort == {HTTPS_PORT} and udp.PayloadLength >= 1200 "
                     f"and udp.Payload[0] >= 0xC0")
    return "not loopback and (" + " or ".join(f"({p})" for p in parts) + ")"


def _fake_hello(payload: bytes, info) -> bytes | None:
    """The real ClientHello with the SNI replaced by a same-length harmless name, or None if it cannot be done."""
    if info is None or info.sni_offset <= 0 or info.sni_len < MIN_FAKE_SNI_LEN:
        return None
    end = info.sni_offset + info.sni_len
    if end > len(payload):
        return None
    decoy = b"w" * (info.sni_len - len(FAKE_SNI_SUFFIX)) + FAKE_SNI_SUFFIX
    return payload[:info.sni_offset] + decoy + payload[end:]


class PacketProcessor:
    """Pure packet policy: `process(raw, outbound)` returns the packets to inject (empty list = drop)."""

    def __init__(self, preset: DpiPreset, target_domains: set[str] | list[str] | None = None):
        self.preset = preset
        self.target_domains = {d.lower().strip() for d in target_domains if d} if target_domains else None
        self._server_ttl: dict[str, int] = {}
        self.stats: Counter = Counter()

    def process(self, raw: bytes, outbound: bool) -> list[bytes]:
        try:
            return self._process(raw, outbound)
        except Exception:                          # a bug must never cut the user's traffic
            logger.exception("[NetUnblock] packet policy failed; passing the packet through")
            self.stats["errors"] += 1
            return [raw]

    def _process(self, raw: bytes, outbound: bool) -> list[bytes]:
        tcp = pk.parse_tcp4(raw)
        if tcp is not None:
            if outbound:
                if tcp.dport == HTTPS_PORT:
                    payload = tcp.payload(raw)
                    if payload and payload[0] == 0x16:
                        return self._client_hello(raw, tcp, payload)
                return [raw]
            return self._inbound_tcp(raw, tcp)
        udp = pk.parse_udp4(raw)
        if udp is not None and outbound and self.preset.block_quic and udp.dport == HTTPS_PORT:
            payload = udp.payload(raw)
            if len(payload) >= 1200 and payload[0] >= 0xC0 and payload[1:5] == b"\x00\x00\x00\x01":
                self.stats["quic_blocked"] += 1
                return []
        return [raw]

    def _inbound_tcp(self, raw: bytes, tcp: pk.Tcp4) -> list[bytes]:
        if tcp.flags & pk.FLAG_SYN and tcp.flags & pk.FLAG_ACK and tcp.sport == HTTPS_PORT:
            if len(self._server_ttl) >= MAX_TRACKED_SERVERS:
                self._server_ttl.clear()
            self._server_ttl[tcp.src] = tcp.ttl
        elif (self.preset.block_passive and tcp.flags & pk.FLAG_RST and tcp.ident <= 1
              and tcp.sport in (HTTPS_PORT, 80)):
            self.stats["rst_blocked"] += 1
            return []
        return [raw]

    def _fake_ttl(self, server: str) -> int | None:
        seen = self._server_ttl.get(server)
        if seen is None:
            return None
        initial = 64 if seen <= 64 else 128 if seen <= 128 else 255
        distance = initial - seen
        return None if distance < MIN_TTL_DISTANCE else max(1, min(distance - 1, AUTO_TTL_MAX))

    def _fakes(self, raw: bytes, tcp: pk.Tcp4, payload: bytes, info) -> list[bytes]:
        p = self.preset
        if not (p.fake_ttl or p.fake_badsum or p.fake_badseq):
            return []
        ttl = self._fake_ttl(tcp.dst) if p.fake_ttl else None
        if not (ttl or p.fake_badsum or p.fake_badseq):
            return []                              # no protection that keeps the fake away from the server
        body = _fake_hello(payload, info)
        if body is None:
            return []
        seq = tcp.seq - WRONG_SEQ_DELTA if p.fake_badseq else None
        self.stats["fakes"] += 1
        return [pk.build_segment(raw, tcp, body, seq=seq, ttl=ttl, bad_checksum=p.fake_badsum)]

    def _client_hello(self, raw: bytes, tcp: pk.Tcp4, payload: bytes) -> list[bytes]:
        info = parse_client_hello(payload)
        if info is None or pk.is_private(tcp.dst):
            return [raw]
        # If target domains are restricted, pass non-matching SNI through untouched
        if self.target_domains is not None:
            try:
                sni_bytes = payload[info.sni_offset : info.sni_offset + info.sni_len]
                sni = sni_bytes.decode("ascii", "ignore").lower()
                matched = any(sni == d or sni.endswith("." + d) for d in self.target_domains)
                if not matched:
                    return [raw]
            except Exception:
                return [raw]
        cut = self.preset.frag_pos or _cut_point(payload, info)
        if not 0 < cut < len(payload):
            return [raw]
        first = pk.build_segment(raw, tcp, payload[:cut], flags=tcp.flags & ~pk.FLAG_PSH)
        second = pk.build_segment(raw, tcp, payload[cut:], seq=tcp.seq + cut, ident=tcp.ident + 1)
        self.stats["hellos_split"] += 1
        return self._fakes(raw, tcp, payload, info) + ([second, first] if self.preset.reverse else [first, second])


def _default_opener(staging_dir: str) -> Callable[[str], object]:
    def open_handle(expression: str):
        dll = windivert.stage_binaries(windivert.source_folder(), staging_dir)
        problem = windivert.check_filter(dll, expression)
        if problem:
            raise windivert.WinDivertError(f"packet filter rejected: {problem}")
        return windivert.Divert(dll, expression)
    return open_handle


class DpiEngine:
    """Owns the WinDivert handle and the capture thread. `opener(filter)` returns an object with
    recv() / send(packet, addr) / shutdown() / close() (windivert.Divert in production, a fake in tests)."""

    def __init__(self, preset_id: str = DEFAULT_PRESET, staging_dir: str = "", opener: Callable | None = None,
                 target_domains: set[str] | list[str] | None = None):
        self.preset = get_preset(preset_id)
        self.target_domains = target_domains
        self.processor = PacketProcessor(self.preset, target_domains=target_domains)
        self._open = opener or _default_opener(staging_dir or os.path.join(os.getcwd(), "windivert"))
        self._io = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.error = ""

    def start(self) -> None:
        if self.is_alive():
            return
        self.error = ""
        self._stop.clear()
        self._io = self._open(build_filter(self.preset))     # may raise WinDivertError: nothing is left running
        self._thread = threading.Thread(target=self._loop, args=(self._io,), name="NetUnblockDpi", daemon=True)
        self._thread.start()
        logger.info(f"[NetUnblock] Packet engine started (preset {self.preset.id})")

    def is_alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def _loop(self, io) -> None:
        try:
            while not self._stop.is_set():
                try:
                    item = io.recv()
                except Exception as e:
                    if self._stop.is_set():
                        break
                    err_str = str(e).lower()
                    if "error 6" in err_str or "invalid handle" in err_str:
                        raise e
                    logger.debug(f"[NetUnblock] transient packet recv error: {e}")
                    continue
                if item is None:
                    break
                raw, outbound, address = item
                for packet in self.processor.process(raw, outbound):
                    io.send(packet, address)
        except Exception as e:
            self.error = str(e)
            logger.error(f"[NetUnblock] Packet engine stopped: {e}")
        finally:
            try:
                io.close()
            except Exception as e:
                logger.debug(f"[NetUnblock] Error closing io in finally: {e}")
            if self._io is io:
                self._io = None
            logger.info("[NetUnblock] Packet engine loop terminated and handle closed")

    def stop(self) -> None:
        self._stop.set()
        io, thread, self._io, self._thread = self._io, self._thread, None, None
        if io is not None:
            try:
                io.shutdown()
            except Exception as e:
                logger.debug(f"[NetUnblock] packet engine shutdown: {e}")
        if thread is not None:
            thread.join(2.0)
        if io is not None:
            try:
                io.close()
            except Exception as e:
                logger.debug(f"[NetUnblock] packet engine close: {e}")
            logger.info("[NetUnblock] Packet engine stopped")
