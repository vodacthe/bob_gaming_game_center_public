"""
TLS ClientHello parsing / fragmentation and the `tls_probe` primitive.

`tls_probe(ip, host, strategy)` opens a TCP connection to `ip`, performs a REAL TLS handshake for `host`
(certificate chain + host name verified) and an HTTP GET, optionally sending the ClientHello fragmented
according to a Strategy. Diagnose, the IP scanner and the proxy self-test all share this primitive, so a
network that resets the plain ClientHello (SNI filtering) is still probed through the same split code.
"""

from __future__ import annotations

import functools
import logging
import socket
import ssl
import struct
import time
from dataclasses import dataclass

from app.core.net_unblock.models import ProbeKind, ProbeResult, Strategy

logger = logging.getLogger(__name__)

CONTROL_SNI = "www.wikipedia.org"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/130.0.0.0 Safari/537.36"
)
FRAGMENT_GAP_S = 0.004          # pause between TCP fragments so they leave as separate segments
_BLOCKPAGE_MARKERS = (b"mic.gov.vn", b"bi chan", "bị chặn".encode(), b"has been blocked", b"access denied by")

# OpenSSL verify codes for which retrying with another trust store cannot help (it is the wrong certificate)
_NO_RETRY_VERIFY_CODES = {9, 10, 62, 64}   # not yet valid, expired, hostname mismatch, IP mismatch


# ---- ClientHello parsing & splitting -------------------------------------------------------------

@dataclass
class HelloInfo:
    record_len: int     # payload length declared by the TLS record header
    sni_offset: int     # offset (in the whole record) of the first SNI host-name byte, -1 if absent
    sni_len: int


def parse_client_hello(record: bytes) -> HelloInfo | None:
    """Locate the SNI inside a TLS ClientHello record. Returns None if `record` is not a ClientHello."""
    try:
        if len(record) < 9 or record[0] != 0x16:
            return None
        record_len = struct.unpack("!H", record[3:5])[0]
        body = record[5:5 + record_len]
        if len(body) < 4 or body[0] != 0x01:
            return None
        off = 4 + 2 + 32                          # handshake header, client_version, random
        off += 1 + body[off]                      # session id
        off += 2 + int.from_bytes(body[off:off + 2], "big")   # cipher suites
        off += 1 + body[off]                      # compression methods
        ext_total = int.from_bytes(body[off:off + 2], "big")
        off += 2
        end = min(off + ext_total, len(body))
        while off + 4 <= end:
            ext_type = int.from_bytes(body[off:off + 2], "big")
            ext_len = int.from_bytes(body[off + 2:off + 4], "big")
            off += 4
            if ext_type == 0 and ext_len >= 5:    # server_name
                name_len = int.from_bytes(body[off + 3:off + 5], "big")
                return HelloInfo(record_len, 5 + off + 5, name_len)
            off += ext_len
        return HelloInfo(record_len, -1, 0)
    except (IndexError, struct.error):
        return None


def _cut_point(record: bytes, info: HelloInfo | None) -> int:
    """Absolute offset inside `record` where fragments are cut — INSIDE the host name when we can."""
    if info and info.sni_offset > 0 and info.sni_len > 0:
        return info.sni_offset + max(1, info.sni_len // 2)
    return max(6, len(record) // 2)


def split_hello(data: bytes, strategy: Strategy) -> list[bytes]:
    """Return the byte chunks to send, one TCP write each, for the first TLS record in `data`.

    Concatenating the chunks always yields a byte stream a TLS server reassembles correctly (record
    fragmentation uses two valid handshake-fragment records, which RFC 8446 section 5.1 allows).
    """
    if strategy == Strategy.NONE or len(data) < 8 or data[0] != 0x16:
        return [data]
    rec_end = 5 + struct.unpack("!H", data[3:5])[0]
    record, rest = data[:rec_end], data[rec_end:]
    info = parse_client_hello(record)
    cut = _cut_point(record, info)

    if strategy in (Strategy.REC_FRAG, Strategy.REC_TCP):
        body = record[5:]
        c = cut - 5
        if not 0 < c < len(body):
            return [data]
        rec1 = record[:3] + struct.pack("!H", c) + body[:c]
        rec2 = record[:3] + struct.pack("!H", len(body) - c) + body[c:]
        chunks = [rec1 + rec2] if strategy == Strategy.REC_FRAG else [rec1, rec2]
    elif strategy == Strategy.SNI_MID:
        chunks = [record[:cut], record[cut:]] if 0 < cut < len(record) else [record]
    elif strategy == Strategy.SPLIT2:
        chunks = [record[:2], record[2:]]
    elif strategy == Strategy.BYTE1:
        chunks = [record[:1], record[1:]]
    else:
        chunks = [record]
    if rest:
        chunks[-1] += rest
    return chunks


def send_fragments(sock: socket.socket, chunks: list[bytes], gap: float = FRAGMENT_GAP_S) -> None:
    """Send each chunk with its own write (TCP_NODELAY) and a tiny pause so segments stay separate."""
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    except OSError:
        pass
    for i, chunk in enumerate(chunks):
        sock.sendall(chunk)
        if gap and i < len(chunks) - 1:
            time.sleep(gap)


# ---- certificate contexts -------------------------------------------------------------------------

@functools.lru_cache(maxsize=4)
def _context(variant: int) -> ssl.SSLContext:
    """0 = certifi strict, 1 = certifi relaxed, 2 = Windows store relaxed."""
    if variant == 2:
        ctx = ssl.create_default_context()
    else:
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
    if variant >= 1 and hasattr(ssl, "VERIFY_X509_STRICT"):
        ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT
    try:
        ctx.set_alpn_protocols(["http/1.1"])
    except (NotImplementedError, ssl.SSLError):
        pass
    return ctx


def client_context(variant: int = 0) -> ssl.SSLContext:
    """Shared verifying client context (0 = certifi strict, 1 = certifi relaxed, 2 = Windows store)."""
    return _context(variant)


# ---- the probe ------------------------------------------------------------------------------------

class _ProbeAbort(Exception):
    def __init__(self, result: ProbeResult, verify_code: int | None = None):
        super().__init__(result.detail)
        self.result = result
        self.verify_code = verify_code


def _flush(outgoing: ssl.MemoryBIO, sock: socket.socket, strategy: Strategy | None = None) -> None:
    data = outgoing.read()
    if not data:
        return
    if strategy is not None and strategy != Strategy.NONE:
        send_fragments(sock, split_hello(data, strategy))
    else:
        sock.sendall(data)


def _recv_into(sock: socket.socket, incoming: ssl.MemoryBIO, deadline: float, phase: str) -> None:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise _ProbeAbort(ProbeResult(ProbeKind.TIMEOUT, detail=f"no answer ({phase})"))
    sock.settimeout(remaining)
    try:
        chunk = sock.recv(16384)
    except (socket.timeout, TimeoutError):
        raise _ProbeAbort(ProbeResult(ProbeKind.TIMEOUT, detail=f"no answer ({phase})"))
    except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError) as e:
        raise _ProbeAbort(ProbeResult(ProbeKind.RST, detail=f"reset ({phase}): {e.__class__.__name__}"))
    if not chunk:
        raise _ProbeAbort(ProbeResult(ProbeKind.RST, detail=f"closed by peer ({phase})"))
    incoming.write(chunk)


def _http_get(sslobj, incoming, outgoing, sock, host: str, path: str, deadline: float):
    request = (
        f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: {USER_AGENT}\r\nAccept: */*\r\n"
        f"Accept-Encoding: identity\r\nConnection: close\r\n\r\n"
    ).encode("ascii")
    sslobj.write(request)
    _flush(outgoing, sock)
    buf = b""
    while len(buf) < 4096 and b"\r\n\r\n" not in buf:
        try:
            data = sslobj.read(4096)
            if not data:
                break
            buf += data
            continue
        except ssl.SSLWantReadError:
            pass
        except (ssl.SSLZeroReturnError, ssl.SSLEOFError):
            break
        try:
            _recv_into(sock, incoming, deadline, "http")
        except _ProbeAbort as e:
            if buf:
                break
            raise e
    return buf


def _parse_http(buf: bytes) -> tuple[int, str, bytes]:
    head, _, body = buf.partition(b"\r\n\r\n")
    lines = head.split(b"\r\n")
    status = 0
    try:
        status = int(lines[0].split()[1])
    except (IndexError, ValueError):
        pass
    location = ""
    for line in lines[1:]:
        if line.lower().startswith(b"location:"):
            location = line.split(b":", 1)[1].strip().decode("latin-1")
    return status, location, body


def _is_blockpage(status: int, location: str, body: bytes) -> bool:
    if location:
        loc_host = location.split("//", 1)[-1].split("/", 1)[0].split(":", 1)[0]
        if loc_host.replace(".", "").isdigit():       # redirect to a bare IP address
            return True
    low = body.lower()
    return any(marker in low for marker in _BLOCKPAGE_MARKERS)


def _probe_once(ip: str, host: str, strategy: Strategy, sni: str | None, timeout: float, port: int,
                path: str, ctx: ssl.SSLContext, request: bool) -> ProbeResult:
    deadline = time.monotonic() + timeout
    t0 = time.monotonic()
    try:
        sock = socket.create_connection((ip, port), timeout=timeout)
    except (socket.timeout, TimeoutError):
        return ProbeResult(ProbeKind.CONNECT, detail="connect timeout")
    except OSError as e:
        return ProbeResult(ProbeKind.CONNECT, detail=f"connect failed: {e.__class__.__name__}")
    rtt = (time.monotonic() - t0) * 1000.0
    try:
        incoming, outgoing = ssl.MemoryBIO(), ssl.MemoryBIO()
        sslobj = ctx.wrap_bio(incoming, outgoing, server_hostname=sni or host)
        first_flight = True
        while True:
            try:
                sslobj.do_handshake()
                break
            except ssl.SSLWantReadError:
                pass
            _flush(outgoing, sock, strategy if first_flight else None)
            first_flight = False
            _recv_into(sock, incoming, deadline, "hello")
        _flush(outgoing, sock)
        if not request:
            return ProbeResult(ProbeKind.OK, rtt_ms=rtt, detail="handshake ok")
        buf = _http_get(sslobj, incoming, outgoing, sock, host, path, deadline)
        if not buf:
            return ProbeResult(ProbeKind.RST, rtt_ms=rtt, detail="no http response")
        status, location, body = _parse_http(buf)
        if _is_blockpage(status, location, body):
            return ProbeResult(ProbeKind.BLOCKPAGE, status, rtt, "block page", location)
        return ProbeResult(ProbeKind.OK, status, rtt, "ok", location)
    except _ProbeAbort as e:
        e.result.rtt_ms = rtt
        return e.result
    except ssl.SSLCertVerificationError as e:
        return ProbeResult(ProbeKind.CERT, rtt_ms=rtt, detail=f"certificate: {e.verify_message}",
                           verify_code=e.verify_code)
    except ssl.SSLEOFError:
        return ProbeResult(ProbeKind.RST, rtt_ms=rtt, detail="tls eof")
    except ssl.SSLError as e:
        return ProbeResult(ProbeKind.CERT, rtt_ms=rtt, detail=f"tls error: {e.reason or e}")
    except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError) as e:
        return ProbeResult(ProbeKind.RST, rtt_ms=rtt, detail=f"reset: {e.__class__.__name__}")
    except (socket.timeout, TimeoutError):
        return ProbeResult(ProbeKind.TIMEOUT, rtt_ms=rtt, detail="timeout")
    except OSError as e:
        return ProbeResult(ProbeKind.CONNECT, rtt_ms=rtt, detail=f"socket error: {e.__class__.__name__}")
    finally:
        try:
            sock.close()
        except OSError:
            pass


def tls_probe(ip: str, host: str, strategy: Strategy = Strategy.NONE, *, sni: str | None = None,
              timeout: float = 3.0, port: int = 443, path: str = "/",
              context: ssl.SSLContext | None = None, request: bool = True) -> ProbeResult:
    """Probe `host` at `ip`. `sni` overrides the SNI (and verified name) for control probes.

    With `context=None` the certificate is verified against certifi, then (only if that fails for a
    trust reason, not a name mismatch) against a relaxed certifi context and the Windows store, so
    antivirus/MITM roots do not turn every host into a false "blocked".
    """
    if context is not None:
        return _probe_once(ip, host, strategy, sni, timeout, port, path, context, request)
    result = ProbeResult(ProbeKind.CONNECT, detail="no attempt")
    for variant in (0, 1, 2):
        result = _probe_once(ip, host, strategy, sni, timeout, port, path, _context(variant), request)
        if result.kind != ProbeKind.CERT:
            return result
        if result.verify_code is None or result.verify_code in _NO_RETRY_VERIFY_CODES:
            return result
    return result
