"""
IP scanner: find addresses that really serve `host` (valid certificate for the name + an HTTP answer).

Candidates come from DNS-over-HTTPS (several providers), from IPs already validated for a sibling host of the
same group (CDNs serve all names of a service from the same edge) and from the IPs currently in use.
Everything is verified with a real TLS handshake, so a poisoned/decoy address can never be selected.
The scan is deliberately small and bounded — it never sweeps address ranges.
"""

from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Iterable

from app.core.net_unblock.doh import DohResolver, usable_ip
from app.core.net_unblock.models import IpScore, ProbeKind, ProbeResult, ScanResult, Strategy
from app.core.net_unblock.tls import tls_probe

logger = logging.getLogger(__name__)

MAX_CANDIDATES = 24
WANT_GOOD = 3
KEEP = 2


def _status_class(status: int) -> int:
    """0 = normal page, 1 = other 4xx (edge serves us), 2 = 403/451 (maybe bot/legal wall) — worst."""
    if 0 < status < 400:
        return 0
    if status in (403, 451):
        return 2
    return 1


def build_candidates(host: str, resolver: DohResolver, hint_ips: Iterable[str],
                     current_ips: Iterable[str], max_candidates: int = MAX_CANDIDATES) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for ip in (*hint_ips, *resolver.resolve(host).ips, *current_ips):
        if ip not in seen and usable_ip(ip):
            seen.add(ip)
            out.append(ip)
    return out[:max_candidates]


def scan_host(host: str, *, resolver: DohResolver, probe=tls_probe, strategy: Strategy = Strategy.NONE,
              hint_ips: Iterable[str] = (), current_ips: Iterable[str] = (),
              cancel: threading.Event | None = None, max_candidates: int = MAX_CANDIDATES,
              workers: int = 8, want_good: int = WANT_GOOD, timeout: float = 3.0) -> ScanResult:
    """Validate candidate IPs for `host`; returns up to 2 best (lowest status class, then lowest RTT)."""
    candidates = build_candidates(host, resolver, hint_ips, current_ips, max_candidates)
    result = ScanResult(host=host)
    if not candidates:
        result.reason = "no candidate address (DNS-over-HTTPS returned nothing usable)"
        return result

    stop = threading.Event()
    kinds: list[ProbeKind] = []
    scored: list[tuple[tuple, IpScore]] = []

    def work(order: int, ip: str):
        if stop.is_set() or (cancel is not None and cancel.is_set()):
            return None
        pr: ProbeResult = probe(ip, host, strategy, timeout=timeout)
        return order, ip, pr

    pool = ThreadPoolExecutor(max_workers=max(1, min(workers, len(candidates))), thread_name_prefix="scan")
    try:
        futures = [pool.submit(work, i, ip) for i, ip in enumerate(candidates)]
        for fut in as_completed(futures):
            item = fut.result()
            if item is None:
                continue
            order, ip, pr = item
            result.tried += 1
            kinds.append(pr.kind)
            if pr.ok:
                score = IpScore(ip=ip, rtt_ms=pr.rtt_ms, status=pr.status, strategy=strategy)
                scored.append(((_status_class(pr.status), round(pr.rtt_ms), order), score))
                if len(scored) >= want_good:
                    stop.set()
    finally:
        pool.shutdown(wait=True, cancel_futures=True)

    scored.sort(key=lambda t: t[0])
    result.good = [s for _, s in scored[:KEEP]]
    if not result.good:
        if cancel is not None and cancel.is_set():
            result.reason = "cancelled"
        elif kinds and all(k == ProbeKind.CONNECT for k in kinds):
            result.reason = "every candidate is unreachable (IP-level block?)"
        elif kinds and all(k in (ProbeKind.RST, ProbeKind.TIMEOUT) for k in kinds):
            result.reason = "TLS hello is reset/dropped on every candidate (SNI filtering)"
        elif kinds and all(k == ProbeKind.CERT for k in kinds):
            result.reason = "certificate does not match on any candidate"
        else:
            result.reason = "no candidate validated"
    return result
