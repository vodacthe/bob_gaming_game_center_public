"""
DNS-over-HTTPS resolver (RFC 8484 wire format) used to bypass ISP DNS poisoning.

Providers are queried by IP literal (their certificates carry IP SANs), so no DNS bootstrap is needed and
no SNI is sent — which also dodges SNI-based blocking of the resolvers themselves.
The `requests` session ignores the environment / WinINET proxy (trust_env=False); otherwise our own
PAC proxy would capture the resolver traffic.
"""

from __future__ import annotations

import base64
import ipaddress
import logging
import socket
import struct
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from typing import Callable

logger = logging.getLogger(__name__)

TYPE_A = 1
RCODE_NXDOMAIN = 3

MIN_TTL = 60
MAX_TTL = 3600
NEGATIVE_TTL = 30


class DnsError(Exception):
    pass


@dataclass(frozen=True)
class DohProvider:
    name: str
    url: str


# Providers verified to answer RFC 8484 GET over HTTP/1.1 by IP literal with a valid IP-SAN certificate.
# (Quad9 and dns.switch.ch were left out: they answer 505 unless HTTP/2 is used.)
DEFAULT_PROVIDERS = (
    DohProvider("cloudflare", "https://1.1.1.1/dns-query"),
    DohProvider("google", "https://8.8.8.8/dns-query"),
    DohProvider("adguard", "https://94.140.14.14/dns-query"),
    DohProvider("opendns", "https://208.67.222.222/dns-query"),
)

# Only asked when none of the primary providers answered (e.g. their primary IPs are blocked).
FALLBACK_PROVIDERS = (
    DohProvider("cloudflare-2", "https://1.0.0.1/dns-query"),
    DohProvider("google-2", "https://8.8.4.4/dns-query"),
    DohProvider("adguard-2", "https://94.140.15.15/dns-query"),
    DohProvider("dnssb", "https://185.222.222.222/dns-query"),
)


# ---- wire format ----------------------------------------------------------------------------------

def encode_query(name: str, qtype: int = TYPE_A, qid: int = 0) -> bytes:
    """Build a DNS query. RFC 8484 recommends ID 0 (cache friendly)."""
    labels = name.rstrip(".").split(".")
    qname = b""
    for label in labels:
        raw = label.encode("ascii")
        if not raw or len(raw) > 63:
            raise DnsError(f"bad label in {name!r}")
        qname += bytes([len(raw)]) + raw
    header = struct.pack("!HHHHHH", qid, 0x0100, 1, 0, 0, 0)  # RD=1, one question
    return header + qname + b"\x00" + struct.pack("!HH", qtype, 1)


def _skip_name(data: bytes, off: int) -> int:
    while True:
        if off >= len(data):
            raise DnsError("truncated name")
        length = data[off]
        if length == 0:
            return off + 1
        if length & 0xC0 == 0xC0:      # compression pointer ends the name
            return off + 2
        off += 1 + length


def decode_response(data: bytes) -> tuple[int, list[tuple[str, int]]]:
    """Parse a DNS response -> (rcode, [(ipv4, ttl), ...]). CNAME/other records are skipped."""
    if len(data) < 12:
        raise DnsError("short response")
    _id, flags, qdcount, ancount, _ns, _ar = struct.unpack("!HHHHHH", data[:12])
    if not flags & 0x8000:
        raise DnsError("not a response")
    rcode = flags & 0x000F
    off = 12
    for _ in range(qdcount):
        off = _skip_name(data, off) + 4
    records: list[tuple[str, int]] = []
    for _ in range(ancount):
        off = _skip_name(data, off)
        if off + 10 > len(data):
            raise DnsError("truncated record")
        rtype, _rclass, ttl, rdlen = struct.unpack("!HHIH", data[off:off + 10])
        off += 10
        rdata = data[off:off + rdlen]
        if len(rdata) != rdlen:
            raise DnsError("truncated rdata")
        off += rdlen
        if rtype == TYPE_A and rdlen == 4:
            records.append((socket.inet_ntoa(rdata), ttl))
    return rcode, records


def usable_ip(ip: str) -> bool:
    """True for a public IPv4 address (rejects loopback, private, link-local, CGNAT, multicast, 0.0.0.0)."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return addr.version == 4 and addr.is_global and not addr.is_multicast


# ---- resolver -------------------------------------------------------------------------------------

@dataclass
class DohAnswer:
    host: str
    ips: list[str] = field(default_factory=list)          # usable public IPv4, best agreement first
    raw_ips: list[str] = field(default_factory=list)      # everything returned (incl. non-global)
    ttl: int = 0
    nxdomain: bool = False
    failed: bool = False                                   # no provider answered at all
    per_provider: dict = field(default_factory=dict)       # provider -> list of ips (or error string)


Transport = Callable[[DohProvider, bytes], bytes]


class RequestsTransport:
    """GET ?dns=<base64url> over HTTPS using a proxy-immune requests session."""

    def __init__(self, timeout: float = 3.0):
        import requests
        from requests.adapters import HTTPAdapter
        self.timeout = timeout
        self._session = requests.Session()
        self._session.trust_env = False           # never inherit WinINET/env proxies
        adapter = HTTPAdapter(pool_connections=4, pool_maxsize=8, max_retries=0)
        self._session.mount("https://", adapter)

    def __call__(self, provider: DohProvider, query: bytes) -> bytes:
        dns = base64.urlsafe_b64encode(query).rstrip(b"=").decode("ascii")
        resp = self._session.get(
            provider.url,
            params={"dns": dns},
            headers={"accept": "application/dns-message"},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        if "dns-message" not in resp.headers.get("content-type", ""):
            raise DnsError(f"unexpected content-type {resp.headers.get('content-type')!r}")
        return resp.content


class DohResolver:
    """Asks several DoH providers in parallel and merges their answers."""

    def __init__(self, providers=DEFAULT_PROVIDERS, transport: Transport | None = None,
                 clock: Callable[[], float] = time.monotonic, overall_timeout: float = 4.0,
                 fallback_providers=FALLBACK_PROVIDERS):
        self.providers = tuple(providers)
        self.fallback_providers = tuple(fallback_providers)
        self._transport = transport or RequestsTransport()
        self._clock = clock
        self._overall_timeout = overall_timeout
        self._cache: dict[str, tuple[float, DohAnswer]] = {}
        self._lock = threading.Lock()
        workers = max(4, (len(self.providers) + len(self.fallback_providers)) * 2)
        self._pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="doh")

    def close(self) -> None:
        self._pool.shutdown(wait=False, cancel_futures=True)

    def clear_cache(self) -> None:
        with self._lock:
            self._cache.clear()

    def _query_one(self, provider: DohProvider, host: str) -> tuple[int, list[tuple[str, int]]]:
        data = self._transport(provider, encode_query(host))
        return decode_response(data)

    def _collect(self, providers, host: str, acc: dict) -> None:
        """Query `providers` in parallel and fold their answers into `acc`."""
        futures = {self._pool.submit(self._query_one, p, host): p for p in providers}
        done, _pending = wait(futures, timeout=self._overall_timeout)
        for fut in futures:
            provider = futures[fut]
            if fut not in done:
                acc["per_provider"][provider.name] = "error: timeout"
                continue
            try:
                rcode, records = fut.result()
            except Exception as e:
                acc["per_provider"][provider.name] = f"error: {type(e).__name__}: {e}"
                continue
            acc["answered"] += 1
            acc["per_provider"][provider.name] = [ip for ip, _ in records]
            if rcode == RCODE_NXDOMAIN:
                acc["nx_votes"] += 1
            for ip, ttl in records:
                if ip not in acc["counts"]:
                    acc["counts"][ip] = 0
                    acc["order"].append(ip)
                acc["counts"][ip] += 1
                acc["ttls"].append(ttl)

    def resolve(self, host: str, use_cache: bool = True) -> DohAnswer:
        now = self._clock()
        if use_cache:
            with self._lock:
                hit = self._cache.get(host)
                if hit and hit[0] > now:
                    return hit[1]

        acc = {"counts": {}, "order": [], "ttls": [], "nx_votes": 0, "answered": 0, "per_provider": {}}
        self._collect(self.providers, host, acc)
        if acc["answered"] == 0 and self.fallback_providers:
            self._collect(self.fallback_providers, host, acc)

        counts, order, answered = acc["counts"], acc["order"], acc["answered"]
        usable = [ip for ip in order if usable_ip(ip)]
        usable.sort(key=lambda ip: (-counts[ip], order.index(ip)))
        answer = DohAnswer(
            host=host,
            ips=usable,
            raw_ips=list(order),
            nxdomain=bool(answered and not order and acc["nx_votes"] * 2 > answered),
            failed=(answered == 0),
            per_provider=acc["per_provider"],
        )
        if usable:
            ttls = acc["ttls"]
            answer.ttl = max(MIN_TTL, min(MAX_TTL, min(ttls) if ttls else MIN_TTL))
        elif answered:
            answer.ttl = NEGATIVE_TTL
        if answer.ttl and not answer.failed:
            with self._lock:
                self._cache[host] = (now + answer.ttl, answer)
        return answer


# ---- system resolver (to compare against DoH) -----------------------------------------------------

def system_resolve(host: str, timeout: float = 3.0) -> tuple[list[str], str]:
    """Resolve through the OS resolver (honours the hosts file) -> (ipv4 list, error).

    error is "" on success, else "nxdomain", "timeout" or "error".
    """
    result: dict = {}

    def work():
        try:
            infos = socket.getaddrinfo(host, 443, socket.AF_INET, socket.SOCK_STREAM)
            result["ips"] = sorted({i[4][0] for i in infos})
        except socket.gaierror as e:
            result["err"] = "nxdomain" if e.errno in (socket.EAI_NONAME, 11001, 11004) else "error"
        except Exception:
            result["err"] = "error"

    t = threading.Thread(target=work, daemon=True, name="sysresolve")
    t.start()
    t.join(timeout)
    if t.is_alive():
        return [], "timeout"
    if "ips" in result:
        return result["ips"], ""
    return [], result.get("err", "error")
