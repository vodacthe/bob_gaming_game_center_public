"""Shared data types for the Network Unblock feature (Qt-free, no I/O)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, IntEnum


class Verdict(str, Enum):
    """Result of diagnosing one host."""
    OK = "ok"                      # reachable as-is (nothing blocked)
    DNS_POISON = "dns_poison"      # system DNS lies (loopback/private/NXDOMAIN/redirect)
    SNI_RST = "sni_rst"            # TLS ClientHello with the real SNI gets reset/dropped
    IP_BLACKHOLE = "ip_blackhole"  # IP-level block: only a VPN/WARP helps
    UNREACHABLE = "unreachable"    # host does not resolve / bad certificates everywhere
    OFFLINE = "offline"            # no internet connectivity at all


class ProbeKind(str, Enum):
    """Outcome of one TLS probe (see tls.tls_probe)."""
    OK = "ok"                # handshake verified for the host name (+ HTTP answered)
    CERT = "cert"            # TLS answered but certificate/alert is wrong for this host
    RST = "rst"              # connection reset / closed right after the ClientHello
    TIMEOUT = "timeout"      # TCP connected but the ClientHello got no answer (dropped)
    CONNECT = "connect"      # TCP connect refused / unreachable / timed out
    BLOCKPAGE = "blockpage"  # HTTP answer looks like an ISP block page


class Strategy(IntEnum):
    """ClientHello fragmentation strategy, ordered from least to most aggressive."""
    NONE = 0       # send the hello untouched
    REC_FRAG = 1   # split into two TLS records inside the SNI, one TCP write
    REC_TCP = 2    # two TLS records, each in its own TCP segment
    SNI_MID = 3    # one TLS record, TCP-split inside the SNI
    SPLIT2 = 4     # TCP-split after the first 2 bytes
    BYTE1 = 5      # TCP-split after the first byte


ESCALATION = (
    Strategy.REC_FRAG,
    Strategy.REC_TCP,
    Strategy.SNI_MID,
    Strategy.SPLIT2,
    Strategy.BYTE1,
)


class HostStatus(str, Enum):
    """What happened to a host in the last run (drives the UI table)."""
    NOTHING_BLOCKED = "nothing_blocked"
    NEEDS_FIX = "needs_fix"              # diagnose-only: a fix would be applied
    APPLIED_HOSTS = "applied_hosts"
    APPLIED_PROXY = "applied_proxy"
    APPLIED_BOTH = "applied_both"
    APPLIED_DPI = "applied_dpi"          # fixed by the packet engine
    MANUAL_OK = "manual_ok"              # user's own hosts line still validates -> untouched
    MANUAL_STALE = "manual_stale"        # user's own hosts line no longer validates
    NOT_FIXABLE = "not_fixable"          # IP block / nothing worked
    OFFLINE = "offline"
    FAILED = "failed"


class EngineState(str, Enum):
    OFF = "off"
    HOSTS_ONLY = "hosts_only"
    ACTIVE = "active"
    DEGRADED = "degraded"
    NOT_ADMIN = "not_admin"


@dataclass
class ProbeResult:
    kind: ProbeKind
    status: int = 0           # HTTP status when the request completed
    rtt_ms: float = 0.0       # TCP connect time
    detail: str = ""
    location: str = ""        # Location header of a redirect, if any
    verify_code: int | None = None   # OpenSSL X509 verify code when kind == CERT

    @property
    def ok(self) -> bool:
        return self.kind == ProbeKind.OK


@dataclass(frozen=True)
class Target:
    host: str
    group: str


@dataclass
class DiagnosisResult:
    host: str
    group: str
    verdict: Verdict
    dns_poison: bool = False
    sni_rst: bool = False
    strategy: Strategy = Strategy.NONE   # winning strategy when sni_rst is fixable
    local_ips: list[str] = field(default_factory=list)
    doh_ips: list[str] = field(default_factory=list)
    evidence: str = ""

    @property
    def needs_hosts(self) -> bool:
        # hosts alone is useless when the SNI is blocked and no split strategy works
        return self.dns_poison and (
            self.verdict == Verdict.DNS_POISON
            or (self.verdict == Verdict.SNI_RST and self.strategy != Strategy.NONE)
        )

    @property
    def needs_proxy(self) -> bool:
        return self.sni_rst and self.strategy != Strategy.NONE

    @property
    def fixable(self) -> bool:
        if self.verdict == Verdict.OK:
            return False
        return self.needs_hosts or self.needs_proxy


@dataclass
class IpScore:
    ip: str
    rtt_ms: float
    status: int = 0
    strategy: Strategy = Strategy.NONE


@dataclass
class ScanResult:
    host: str
    good: list[IpScore] = field(default_factory=list)   # best first, at most 2
    tried: int = 0
    reason: str = ""                                     # why nothing was found


@dataclass
class HostRow:
    """One row of the UI table / one entry of a run report."""
    host: str
    group: str
    verdict: Verdict
    status: HostStatus
    local_ips: list[str] = field(default_factory=list)
    chosen: str = ""          # "151.101.65.140" and/or "split:REC_FRAG"
    rtt_ms: float = 0.0
    note: str = ""


@dataclass
class EngineStatus:
    state: EngineState = EngineState.OFF
    hosts_applied: int = 0
    proxy_port: int | None = None
    proxy_hosts: int = 0
    warnings: list[str] = field(default_factory=list)
    last_refresh: float | None = None
    is_admin: bool = False
    all_sites: bool = False   # the adaptive all-sites proxy mode is applied
    dpi: bool = False         # the packet engine is running
    dpi_preset: str = ""
