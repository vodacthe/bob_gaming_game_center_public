"""
Apollo Server Commands Manager.
Ported from Artemis PC (servercommandmanager.cpp).
"""

from __future__ import annotations

import logging
import time
from typing import Optional

from PySide6.QtCore import QObject, Signal

from app.core.remote.models import RemoteHost, ServerCommand

logger = logging.getLogger(__name__)

# Friendly display labels for common Apollo command identifiers
BUILTIN_COMMANDS: list[ServerCommand] = [
    ServerCommand(
        id="restart_service",
        name="Khởi động lại Sunshine / Apollo",
        description="Khởi động lại tiến trình máy chủ streaming",
    ),
    ServerCommand(
        id="restart",
        name="Khởi động lại PC chủ",
        description="Khởi động lại toàn bộ máy tính chạy server",
    ),
    ServerCommand(
        id="reboot",
        name="Khởi động lại PC chủ",
        description="Khởi động lại toàn bộ máy tính chạy server",
    ),
    ServerCommand(
        id="sleep",
        name="Chế độ ngủ (Sleep PC)",
        description="Đưa PC chủ vào chế độ Sleep / Suspend",
    ),
    ServerCommand(
        id="suspend",
        name="Chế độ ngủ (Suspend PC)",
        description="Đưa PC chủ vào chế độ Sleep / Suspend",
    ),
    ServerCommand(
        id="hibernate",
        name="Ngủ đông (Hibernate PC)",
        description="Đưa PC chủ vào chế độ Hibernate",
    ),
    ServerCommand(
        id="lock",
        name="Khóa màn hình PC chủ",
        description="Khóa phiên đăng nhập trên PC chủ",
    ),
    ServerCommand(
        id="shutdown",
        name="Tắt PC chủ",
        description="Tắt nguồn máy chủ từ xa an toàn",
    ),
]

_KNOWN_COMMANDS: dict[str, ServerCommand] = {c.id: c for c in BUILTIN_COMMANDS}


class ServerCommandManager(QObject):
    """Executes Apollo and Sunshine server management commands."""

    command_started = Signal(str)
    command_finished = Signal(str, bool, str)

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)

    def get_available_commands(self, host: RemoteHost) -> list[ServerCommand]:
        """Returns list of commands actually advertised by this host."""
        commands: list[ServerCommand] = []
        seen: set[str] = set()

        for raw_id in host.server_commands or []:
            cmd_id = raw_id.strip()
            if not cmd_id or cmd_id in seen:
                continue
            seen.add(cmd_id)
            known = _KNOWN_COMMANDS.get(cmd_id.lower())
            if known is not None:
                commands.append(
                    ServerCommand(
                        id=cmd_id,
                        name=known.name,
                        description=known.description,
                    )
                )
            else:
                commands.append(
                    ServerCommand(
                        id=cmd_id,
                        name=cmd_id,
                        description=f"Lệnh điều khiển Apollo: {cmd_id}",
                    )
                )

        return commands

    def execute_command(self, host: RemoteHost, command_id: str) -> bool:
        """Execute a command on the host PC.

        During an active streaming session, commands are dispatched over the ENet control stream
        via LiSendExecServerCmd(index) (Artemis servercommandmanager.cpp:405-449).
        Outside a session, server commands are disabled per 09-phase6-integration.md §4.
        """
        t0 = time.perf_counter()
        self.command_started.emit(command_id)
        logger.info(f"[ServerCmd] Executing server command '{command_id}' on {host.hostname}...")

        # 1. Check for active streaming session targeting this host
        from app.core.remote.limelight import load_api
        from app.core.remote.manager import RemoteGamingManager

        manager = RemoteGamingManager.get()
        controller = manager.stream_controller
        if not controller.is_active:
            msg = "Chỉ dùng được khi đang stream"
            logger.warning(f"[ServerCmd] Refused '{command_id}' on {host.hostname}: {msg}")
            self.command_finished.emit(command_id, False, msg)
            return False

        active_host = getattr(controller, "active_host", None)
        if active_host is not None and getattr(active_host, "uuid", None) != host.uuid:
            msg = "Phiên stream hiện tại đang kết nối tới máy chủ khác"
            logger.warning(f"[ServerCmd] Refused '{command_id}' on {host.hostname}: {msg}")
            self.command_finished.emit(command_id, False, msg)
            return False

        # 2. Map commandId to index in host's server commands list (servercommandmanager.cpp:388-425, Part 2 Item 24)
        server_commands = host.server_commands or []

        try:
            cmd_index = server_commands.index(command_id)
        except ValueError:
            msg = f"Lệnh '{command_id}' không được hỗ trợ bởi máy chủ"
            logger.warning(f"[ServerCmd] Refused '{command_id}' on {host.hostname}: {msg}")
            self.command_finished.emit(command_id, False, msg)
            return False

        # 3. Send over control stream; treat 1 as success (09-phase6-integration.md §4)
        try:
            api_inst = load_api()
            result = api_inst.LiSendExecServerCmd(cmd_index)
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            if result == 1:
                logger.info(
                    f"[ServerCmd] Command '{command_id}' (idx={cmd_index}) sent to {host.hostname} in {elapsed_ms:.1f}ms"
                )
                self.command_finished.emit(command_id, True, f"Đã gửi lệnh '{command_id}' thành công")
                return True

            logger.warning(
                f"[ServerCmd] Command '{command_id}' (idx={cmd_index}) failed on {host.hostname} "
                f"(rc={result}, {elapsed_ms:.1f}ms)"
            )
            self.command_finished.emit(command_id, False, f"Thực thi lệnh thất bại (mã lỗi: {result})")
            return False
        except Exception as e:
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            logger.error(
                f"[ServerCmd] Unexpected error executing '{command_id}' on {host.hostname} ({elapsed_ms:.1f}ms): {e}",
                exc_info=True,
            )
            self.command_finished.emit(command_id, False, str(e))
            return False
