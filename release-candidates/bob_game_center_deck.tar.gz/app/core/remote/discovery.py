"""
Host Discovery Engine for Remote Gaming using mDNS and Direct IP Probing.
Ported from Artemis PC (computerseeker.cpp, computermanager.cpp).
"""

from __future__ import annotations

import logging
import socket
import threading
import time
from typing import Optional

from PySide6.QtCore import QObject, Signal
from zeroconf import ServiceBrowser, ServiceListener, Zeroconf

from app.core.remote.models import PairState, RemoteHost
from app.core.remote.nvhttp import NvHttpClient

logger = logging.getLogger(__name__)

MDNS_SERVICE_TYPE = "_nvstream._tcp.local."


class _MdnsListener(ServiceListener):
    def __init__(self, callback):
        self.callback = callback

    def add_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        self.callback(zc, type_, name)

    def update_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        self.callback(zc, type_, name)

    def remove_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        pass


class HostDiscoveryEngine(QObject):
    """
    Discovers Sunshine, Apollo, and GameStream hosts on the local network
    via mDNS (_nvstream._tcp.local.) and manual IP probes.
    """

    host_discovered = Signal(object)  # RemoteHost
    discovery_error = Signal(str)
    scan_finished = Signal()

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._zeroconf: Optional[Zeroconf] = None
        self._browser: Optional[ServiceBrowser] = None
        self._is_scanning: bool = False
        self._discovered_hosts: dict[str, RemoteHost] = {}
        self._lock = threading.Lock()

    @property
    def is_scanning(self) -> bool:
        return self._is_scanning

    def start_discovery(self) -> None:
        """Start background mDNS service listener."""
        if self._is_scanning:
            return

        self._is_scanning = True
        logger.info(f"Starting mDNS host discovery for {MDNS_SERVICE_TYPE}...")

        try:
            self._zeroconf = Zeroconf()
            listener = _MdnsListener(self._on_service_resolved)
            self._browser = ServiceBrowser(self._zeroconf, MDNS_SERVICE_TYPE, listener)
        except Exception as e:
            logger.warning(f"Failed to start Zeroconf listener: {e}")
            self._is_scanning = False
            self.discovery_error.emit(str(e))

    def stop_discovery(self) -> None:
        """Stop background mDNS service listener."""
        if not self._is_scanning:
            return

        self._is_scanning = False
        if self._browser:
            self._browser.cancel()
            self._browser = None

        if self._zeroconf:
            self._zeroconf.close()
            self._zeroconf = None

        logger.info("Host discovery stopped.")
        self.scan_finished.emit()

    def _on_service_resolved(self, zc: Zeroconf, type_: str, name: str) -> None:
        """Invoked in background when a new _nvstream._tcp service is found."""
        try:
            info = zc.get_service_info(type_, name)
            if not info or not info.addresses:
                return

            ip = socket.inet_ntoa(info.addresses[0])
            port = info.port or 47989

            # Resolve in thread
            threading.Thread(
                target=self._probe_and_emit,
                args=(ip, port),
                daemon=True,
                name=f"Probe-{ip}",
            ).start()
        except Exception as e:
            logger.debug(f"Error resolving mDNS service: {e}")

    def probe_host(self, ip: str, port: int = 47989, timeout: float = 3.0) -> Optional[RemoteHost]:
        """Synchronously probe a single host by IP/Domain."""
        return self._probe_and_emit(ip, port, timeout=timeout)

    def _probe_and_emit(self, ip: str, port: int = 47989, timeout: float = 3.0) -> Optional[RemoteHost]:
        try:
            client = NvHttpClient(ip, http_port=port)
            server_info = client.get_server_info(use_https=False, timeout=timeout)

            host_uuid = server_info.get("uniqueid") or ip
            pair_state = PairState.PAIRED if server_info.get("pair_status") else PairState.UNPAIRED

            host = RemoteHost(
                uuid=host_uuid,
                hostname=server_info.get("hostname", ip),
                ip=ip,
                port=port,
                https_port=server_info.get("https_port", 47984),
                mac=server_info.get("mac", ""),
                app_version=server_info.get("appversion", ""),
                gfe_version=server_info.get("gfeversion", ""),
                apollo_version=server_info.get("apollo_version", ""),
                is_apollo=server_info.get("is_apollo", False),
                server_codec_mode_support=server_info.get("server_codec_mode_support", 0),
                max_luma_pixels_hevc=server_info.get("max_luma_pixels_hevc", 0),
                pair_state=pair_state,
                server_commands=server_info.get("server_commands", []),
                current_game_id=server_info.get("current_game", 0),
                is_online=True,
                last_seen=time.time(),
            )

            with self._lock:
                self._discovered_hosts[host.uuid] = host

            self.host_discovered.emit(host)
            logger.info(f"Discovered host: {host.hostname} ({host.ip}) - Apollo: {host.is_apollo}")
            return host

        except Exception as e:
            logger.debug(f"Failed to probe host {ip}:{port} - {e}")
            return None
