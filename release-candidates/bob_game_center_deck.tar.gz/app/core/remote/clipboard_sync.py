"""
Bi-directional Clipboard Sync Service for Remote Gaming (Apollo servers).
Ported from Artemis PC (clipboardmanager.cpp).
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Optional

from PySide6.QtCore import QObject, Qt, Signal, Slot
from PySide6.QtGui import QGuiApplication

from app.core.remote.models import RemoteHost
from app.core.remote.nvhttp import NvHttpClient

logger = logging.getLogger(__name__)


class ClipboardSyncService(QObject):
    """Syncs clipboard bidirectionally between client and Apollo host during streaming."""

    clipboard_updated = Signal(str)
    _request_sync_now = Signal()
    _set_local_clipboard = Signal(str)

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._is_running: bool = False
        self._host: Optional[RemoteHost] = None
        self._last_client_text: str = ""
        self._last_server_text: str = ""
        self._worker_thread: Optional[threading.Thread] = None

        # Queue signals to Qt GUI thread (09 §1, Part 2 Item 23)
        self._request_sync_now.connect(self._on_sync_now_requested, Qt.ConnectionType.QueuedConnection)
        self._set_local_clipboard.connect(self._on_set_local_clipboard, Qt.ConnectionType.QueuedConnection)

    def start(self, host: RemoteHost) -> None:
        if self._is_running:
            self.stop()

        self._host = host
        self._is_running = True
        logger.info(f"Started clipboard synchronization with {host.hostname}...")

        app = QGuiApplication.instance()
        if app:
            try:
                app.clipboard().dataChanged.connect(self._on_local_clipboard_changed)
            except Exception as e:
                logger.debug(f"Failed to connect clipboard dataChanged: {e}")

        self._worker_thread = threading.Thread(
            target=self._sync_loop,
            daemon=True,
            name=f"ClipboardSync-{host.hostname}",
        )
        self._worker_thread.start()

    def stop(self) -> None:
        self._is_running = False
        self._host = None
        app = QGuiApplication.instance()
        if app:
            try:
                app.clipboard().dataChanged.disconnect(self._on_local_clipboard_changed)
            except Exception:
                pass
        logger.info("Stopped clipboard synchronization.")

    def sync_now(self) -> None:
        """Trigger immediate bi-directional clipboard sync (e.g. on window focus loss).

        Marshalled to Qt GUI thread via queued signal (Part 2 Item 23).
        """
        if not self._is_running or not self._host:
            return
        self._request_sync_now.emit()

    @Slot()
    def _on_sync_now_requested(self) -> None:
        """Execute on Qt GUI thread: safely read local clipboard and dispatch sync worker."""
        if not self._is_running or not self._host:
            return
        current_local = ""
        app = QGuiApplication.instance()
        if app:
            try:
                current_local = app.clipboard().text()
            except Exception as e:
                logger.debug(f"Error reading local clipboard: {e}")

        threading.Thread(
            target=self._perform_single_sync,
            args=(current_local,),
            daemon=True,
            name="ClipboardSyncNowWorker",
        ).start()

    @Slot()
    def _on_local_clipboard_changed(self) -> None:
        """Triggered on Qt GUI thread when local clipboard content changes."""
        self._on_sync_now_requested()

    @Slot(str)
    def _on_set_local_clipboard(self, text: str) -> None:
        """Execute on Qt GUI thread: update QClipboard text."""
        app = QGuiApplication.instance()
        if app:
            try:
                cb = app.clipboard()
                cb.setText(text)
            except Exception as e:
                logger.debug(f"Error writing to local clipboard: {e}")

    def _perform_single_sync(self, current_local: str = "") -> None:
        if not self._host:
            return
        client = NvHttpClient(
            self._host.ip,
            self._host.port,
            self._host.https_port,
            self._host.server_cert_pem,
        )
        try:
            if (
                current_local
                and current_local != self._last_client_text
                and current_local != self._last_server_text
            ):
                self._last_client_text = current_local
                client.send_clipboard_content(current_local)
                logger.debug(f"Pushed clipboard to server (sync_now): {len(current_local)} chars")

            remote_text = client.get_clipboard_content()
            if (
                remote_text
                and remote_text != self._last_server_text
                and remote_text != self._last_client_text
            ):
                self._last_server_text = remote_text
                self._set_local_clipboard.emit(remote_text)
                self.clipboard_updated.emit(remote_text)
                logger.debug(f"Pulled clipboard from server (sync_now): {len(remote_text)} chars")
        except Exception as e:
            logger.debug(f"sync_now tick error: {e}")
        finally:
            client.close()

    def _sync_loop(self) -> None:
        if not self._host:
            return

        client = NvHttpClient(
            self._host.ip,
            self._host.port,
            self._host.https_port,
            self._host.server_cert_pem,
        )

        try:
            while self._is_running:
                try:
                    # Remote clipboard polling (every 2s)
                    remote_text = client.get_clipboard_content()
                    if (
                        remote_text
                        and remote_text != self._last_server_text
                        and remote_text != self._last_client_text
                    ):
                        self._last_server_text = remote_text
                        self._set_local_clipboard.emit(remote_text)
                        self.clipboard_updated.emit(remote_text)
                        logger.debug(f"Pulled clipboard from server: {len(remote_text)} chars")

                except Exception as e:
                    logger.debug(f"Clipboard sync tick error: {e}")

                time.sleep(2.0)
        finally:
            client.close()
