"""
Data models for Remote Gaming (Sunshine / Apollo / NVIDIA GameStream).
Ported and adapted from Artemis PC / Moonlight Qt.
"""

from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional


class PairState(str, Enum):
    UNPAIRED = "unpaired"
    PAIRING = "pairing"
    PAIRED = "paired"
    FAILED = "failed"


class EngineMode(str, Enum):
    PYTHON = "python"


class VideoCodec(str, Enum):
    AUTO = "AUTO"
    H264 = "H.264"
    HEVC = "HEVC"
    AV1 = "AV1"


@dataclass
class ServerCommand:
    id: str
    name: str
    description: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)


@dataclass
class RemoteApp:
    id: int
    title: str
    uuid: str = ""
    is_hdr_supported: bool = False
    is_running: bool = False
    box_art_path: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RemoteApp:
        return cls(
            id=data.get("id", 0),
            title=data.get("title", "Unknown Game"),
            uuid=data.get("uuid", ""),
            is_hdr_supported=data.get("is_hdr_supported", False),
            is_running=data.get("is_running", False),
            box_art_path=data.get("box_art_path", ""),
        )


@dataclass
class RemoteHost:
    uuid: str
    hostname: str
    ip: str
    port: int = 47989
    https_port: int = 47984
    mac: str = ""
    app_version: str = ""
    gfe_version: str = ""
    apollo_version: str = ""
    is_apollo: bool = False
    server_codec_mode_support: int = 0
    max_luma_pixels_hevc: int = 0
    pair_state: PairState = PairState.UNPAIRED
    server_cert_pem: str = ""
    server_commands: list[str] = field(default_factory=list)
    current_game_id: int = 0
    current_game_name: str = ""
    is_online: bool = False
    last_seen: float = field(default_factory=time.time)
    apps: list[RemoteApp] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["pair_state"] = self.pair_state.value
        d["apps"] = [app.to_dict() for app in self.apps]
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RemoteHost:
        raw_pair_state = data.get("pair_state", PairState.UNPAIRED.value)
        try:
            pair_state = PairState(raw_pair_state)
        except ValueError:
            pair_state = PairState.UNPAIRED

        apps = [RemoteApp.from_dict(a) for a in data.get("apps", [])]

        return cls(
            uuid=data.get("uuid", ""),
            hostname=data.get("hostname", "Unknown Host"),
            ip=data.get("ip", "127.0.0.1"),
            port=data.get("port", 47989),
            https_port=data.get("https_port", 47984),
            mac=data.get("mac", ""),
            app_version=data.get("app_version", ""),
            gfe_version=data.get("gfe_version", ""),
            apollo_version=data.get("apollo_version", ""),
            is_apollo=data.get("is_apollo", False),
            server_codec_mode_support=data.get("server_codec_mode_support", 0),
            max_luma_pixels_hevc=data.get("max_luma_pixels_hevc", 0),
            pair_state=pair_state,
            server_cert_pem=data.get("server_cert_pem", ""),
            server_commands=data.get("server_commands", []),
            current_game_id=data.get("current_game_id", 0),
            current_game_name=data.get("current_game_name", ""),
            is_online=data.get("is_online", False),
            last_seen=data.get("last_seen", time.time()),
            apps=apps,
        )


_RES_TABLE = (
    (640 * 360, 1),
    (854 * 480, 2),
    (1280 * 720, 5),
    (1920 * 1080, 10),
    (2560 * 1440, 20),
    (3840 * 2160, 40),
)


def default_bitrate_kbps(width: int, height: int, fps: int, yuv444: bool = False) -> int:
    """Port of StreamingPreferences::getDefaultBitrate from Artemis."""
    # Don't scale bitrate linearly beyond 60 FPS (Artemis comment)
    frame_rate_factor = (fps if fps <= 60 else math.sqrt(fps / 60.0) * 60.0) / 30.0
    pixels = width * height
    factor = None
    for i, (px, f) in enumerate(_RES_TABLE):
        if pixels == px:
            factor = float(f)
            break
        if pixels < px:
            if i == 0:
                factor = float(f)
            else:
                p0, f0 = _RES_TABLE[i - 1]
                factor = (pixels - p0) / (px - p0) * (f - f0) + f0
            break
    if factor is None:
        factor = float(_RES_TABLE[-1][1])
    if yuv444:
        factor *= 2
    return int(math.floor(factor * frame_rate_factor + 0.5)) * 1000  # qRound; Python round() is banker's rounding


@dataclass
class StreamSettings:
    settings_version: int = 3
    width: int = 1920
    height: int = 1080
    fps: int = 60
    bitrate_kbps: int = 20000
    codec: VideoCodec = VideoCodec.AUTO
    video_decoder: str = "AUTO"  # AUTO / FORCE_HARDWARE / FORCE_SOFTWARE (Artemis session.cpp:1080-1110)
    window_mode: str = "borderless"  # borderless / fullscreen / windowed
    vsync: bool = True  # Used in exclusive fullscreen
    show_performance_overlay: bool = False
    absolute_mouse: bool = False  # False = relative (games), True = absolute (desktop)
    capture_sys_keys: str = "off"  # off / fullscreen / always (Artemis CSK_OFF)
    swap_mouse_buttons: bool = False
    reverse_scroll: bool = False
    multi_controller: bool = True
    swap_face_buttons: bool = False
    gamepad_mouse: bool = True
    background_gamepad: bool = False
    mute_on_focus_loss: bool = False
    keep_awake: bool = True  # SDL_DisableScreenSaver
    packet_size: int = 0  # 0 = auto
    audio_channels: int = 2
    enable_virtual_display: bool = False
    resolution_scale: int = 100
    enable_fractional_fps: bool = False
    custom_refresh_rate: float = 60.0
    clipboard_sync: bool = True
    quit_app_after: bool = False

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["codec"] = self.codec.value
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StreamSettings:
        raw_codec = data.get("codec", VideoCodec.AUTO.value)
        try:
            codec = VideoCodec(raw_codec)
        except ValueError:
            codec = VideoCodec.AUTO

        width = data.get("width", 1920)
        height = data.get("height", 1080)
        fps = data.get("fps", 60)
        settings_version = data.get("settings_version", 1)

        # Bitrate default or migration
        bitrate_kbps = data.get("bitrate_kbps")
        if bitrate_kbps is None:
            bitrate_kbps = default_bitrate_kbps(width, height, fps)
        elif settings_version < 2 and bitrate_kbps == 20000 and (width != 1920 or height != 1080 or fps != 60):
            bitrate_kbps = default_bitrate_kbps(width, height, fps)

        # Mouse mode migration: absolute_mouse = not mouse_relative (09-phase6-integration.md §3)
        if "absolute_mouse" in data:
            absolute_mouse = bool(data["absolute_mouse"])
        elif "mouse_relative" in data:
            absolute_mouse = not bool(data["mouse_relative"])
        else:
            absolute_mouse = False

        return cls(
            settings_version=3,
            width=width,
            height=height,
            fps=fps,
            bitrate_kbps=int(bitrate_kbps),
            codec=codec,
            video_decoder=str(data.get("video_decoder", "AUTO")).upper(),
            window_mode=str(data.get("window_mode", "borderless")).lower(),
            vsync=bool(data.get("vsync", True)),
            show_performance_overlay=(
                False if settings_version < 3 else bool(data.get("show_performance_overlay", False))
            ),
            absolute_mouse=absolute_mouse,
            capture_sys_keys=str(data.get("capture_sys_keys", "off")).lower(),
            swap_mouse_buttons=bool(data.get("swap_mouse_buttons", False)),
            reverse_scroll=bool(data.get("reverse_scroll", False)),
            multi_controller=bool(data.get("multi_controller", True)),
            swap_face_buttons=bool(data.get("swap_face_buttons", False)),
            gamepad_mouse=bool(data.get("gamepad_mouse", True)),
            background_gamepad=bool(data.get("background_gamepad", False)),
            mute_on_focus_loss=bool(data.get("mute_on_focus_loss", False)),
            keep_awake=bool(data.get("keep_awake", True)),
            packet_size=int(data.get("packet_size", 0)),
            audio_channels=int(data.get("audio_channels", 2)),
            enable_virtual_display=bool(data.get("enable_virtual_display", False)),
            resolution_scale=int(data.get("resolution_scale", 100)),
            enable_fractional_fps=bool(data.get("enable_fractional_fps", False)),
            custom_refresh_rate=float(data.get("custom_refresh_rate", 60.0)),
            clipboard_sync=bool(data.get("clipboard_sync", True)),
            quit_app_after=bool(data.get("quit_app_after", False)),
        )


