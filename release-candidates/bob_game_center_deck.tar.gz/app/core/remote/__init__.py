"""
Remote Gaming package for Bob Gaming Game Center.
Ported from Artemis PC (Moonlight Qt / Apollo / Sunshine).
"""

from app.core.remote.crypto import IdentityManager
from app.core.remote.discovery import HostDiscoveryEngine
from app.core.remote.manager import RemoteGamingManager
from app.core.remote.models import (
    PairState,
    RemoteApp,
    RemoteHost,
    ServerCommand,
    StreamSettings,
    VideoCodec,
)
from app.core.remote.nvhttp import NvHttpClient, NvHttpException
from app.core.remote.pairing import PairingManager
from app.core.remote.server_commands import ServerCommandManager
from app.core.remote.stream_runner import StreamController, StreamRunner

__all__ = [
    "RemoteGamingManager",
    "RemoteHost",
    "RemoteApp",
    "StreamSettings",
    "ServerCommand",
    "PairState",
    "VideoCodec",
    "IdentityManager",
    "NvHttpClient",
    "NvHttpException",
    "PairingManager",
    "HostDiscoveryEngine",
    "ServerCommandManager",
    "StreamController",
    "StreamRunner",
]
