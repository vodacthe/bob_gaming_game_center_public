"""
Central resolver for native binary directories (x64 DLLs).
Supports both development environment and frozen PyInstaller bundles.
"""

from __future__ import annotations

import ctypes
import logging
import os
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

_dll_dir_cookie = None


def native_bin_dir() -> Path:
    """Return the directory containing native x64 runtime DLLs.

    - When frozen (PyInstaller bundle): returns sys._MEIPASS.
    - When running in dev: returns <repo_root>/native/bin/x64.
    """
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)

    repo_root = Path(__file__).resolve().parent.parent.parent.parent
    return repo_root / "native" / "bin" / "x64"


def ensure_dll_directory() -> Path:
    """Register native_bin_dir() with os.add_dll_directory on Windows."""
    global _dll_dir_cookie
    bin_dir = native_bin_dir()
    if _dll_dir_cookie is None and hasattr(os, "add_dll_directory") and bin_dir.exists():
        try:
            _dll_dir_cookie = os.add_dll_directory(str(bin_dir))
            logger.debug(f"[NativePaths] Added DLL directory: {bin_dir}")
        except Exception as e:
            logger.warning(f"[NativePaths] Failed to add DLL directory {bin_dir}: {e}")
    return bin_dir


def get_loaded_module_path(dll_handle: int) -> str:
    """Return the filesystem path of a loaded Win32 module handle."""
    if sys.platform == "win32":
        buf = ctypes.create_unicode_buffer(1024)
        ctypes.windll.kernel32.GetModuleFileNameW(ctypes.c_void_p(dll_handle), buf, 1024)
        return buf.value
    return ""


def verify_and_log_native_dlls(stdout: bool = False) -> dict[str, str]:
    """Verify and log the actual filesystem paths of bundled runtime DLLs.

    Loads avcodec-61.dll and moonlight-common-c.dll via ctypes, records
    their GetModuleFileNameW path, and logs them.
    """
    bin_dir = ensure_dll_directory()
    loaded_paths: dict[str, str] = {}

    def _try_load(name: str) -> None:
        target = bin_dir / name
        try:
            if target.exists():
                dll = ctypes.CDLL(str(target))
            else:
                dll = ctypes.CDLL(name)
            p = get_loaded_module_path(dll._handle)
            loaded_paths[name] = p
        except Exception as err:
            logger.warning(f"[NativePaths] Could not load {name}: {err}")
            loaded_paths[name] = f"ERROR: {err}"

    # Preload dependencies in safe order
    for dep in ("avutil-59.dll", "swscale-8.dll", "libcrypto-3-x64.dll"):
        try:
            target = bin_dir / dep
            if target.exists():
                ctypes.CDLL(str(target))
        except Exception:
            pass

    _try_load("avcodec-61.dll")
    _try_load("moonlight-common-c.dll")
    _try_load("libopus-0.dll")

    log_msg = (
        f"[NativePaths] Verified runtime DLLs (bin_dir={bin_dir}):\n"
        f"  avcodec-61.dll: {loaded_paths.get('avcodec-61.dll')}\n"
        f"  moonlight-common-c.dll: {loaded_paths.get('moonlight-common-c.dll')}\n"
        f"  libopus-0.dll: {loaded_paths.get('libopus-0.dll')}"
    )
    logger.info(log_msg)
    if stdout:
        print(log_msg)

    return loaded_paths

