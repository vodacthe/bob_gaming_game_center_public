"""
Cryptographic functions and Identity Manager for Remote Gaming (GameStream / Sunshine / Apollo).
Ported from Artemis PC (identitymanager.cpp, nvpairingmanager.cpp, otppairingmanager.cpp).
"""

from __future__ import annotations

import datetime
import hashlib
import logging
import os
import random
import socket
from typing import Optional

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.x509.oid import NameOID

from app.config import CONFIG_DIR

logger = logging.getLogger(__name__)

REMOTE_DIR = os.path.join(CONFIG_DIR, "remote")
os.makedirs(REMOTE_DIR, exist_ok=True)

CLIENT_KEY_PATH = os.path.join(REMOTE_DIR, "client.key")
CLIENT_CRT_PATH = os.path.join(REMOTE_DIR, "client.crt")
UNIQUE_ID_PATH = os.path.join(REMOTE_DIR, "uniqueid.dat")


class IdentityManager:
    """Manages RSA private key, self-signed X.509 certificate, and unique client ID."""

    _instance: Optional[IdentityManager] = None

    def __init__(self):
        self.key_path = CLIENT_KEY_PATH
        self.crt_path = CLIENT_CRT_PATH
        self.unique_id_path = UNIQUE_ID_PATH
        self._private_key: Optional[rsa.RSAPrivateKey] = None
        self._certificate: Optional[x509.Certificate] = None
        self._unique_id: str = ""
        self._load_or_generate()

    @classmethod
    def get(cls) -> IdentityManager:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _try_import_from_registry(self) -> bool:
        """Try to import existing credentials from Artemis or Moonlight Windows Registry."""
        try:
            import winreg
            import re
            for org, name in [("Artemis Desktop Project", "Artemis"), ("Moonlight Game Streaming Project", "Moonlight")]:
                try:
                    key_path = f"Software\\{org}\\{name}"
                    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path)
                    cert_val, _ = winreg.QueryValueEx(k, "certificate")
                    key_val, _ = winreg.QueryValueEx(k, "key")
                    winreg.CloseKey(k)

                    cert_pem = re.sub(r"^@ByteArray\(|\)$", "", cert_val).strip()
                    key_pem = re.sub(r"^@ByteArray\(|\)$", "", key_val).strip()
                    if not cert_pem or not key_pem:
                        continue

                    # Validate key and certificate
                    test_cert = x509.load_pem_x509_certificate(cert_pem.encode("utf-8"))
                    test_key = serialization.load_pem_private_key(key_pem.encode("utf-8"), password=None)

                    # Persist to disk
                    with open(self.crt_path, "wb") as f:
                        f.write(cert_pem.encode("utf-8"))
                    with open(self.key_path, "wb") as f:
                        f.write(key_pem.encode("utf-8"))

                    self._certificate = test_cert
                    self._private_key = test_key
                    logger.info(f"Successfully imported remote gaming credentials from {org}\\{name} registry")
                    return True
                except OSError:
                    continue
        except Exception as e:
            logger.debug(f"Could not import credentials from registry: {e}")
        return False

    def _load_or_generate(self) -> None:
        """Load existing key/cert or generate new RSA-2048 credentials."""
        need_gen = not (os.path.exists(self.key_path) and os.path.exists(self.crt_path))

        if not need_gen:
            try:
                with open(self.key_path, "rb") as f:
                    self._private_key = serialization.load_pem_private_key(f.read(), password=None)
                with open(self.crt_path, "rb") as f:
                    self._certificate = x509.load_pem_x509_certificate(f.read())

                # Verify that CN is "NVIDIA GameStream Client" to ensure compatibility with Sunshine/GFE
                cns = self._certificate.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
                if not cns or cns[0].value != "NVIDIA GameStream Client":
                    logger.info("Regenerating client certificate to CN=NVIDIA GameStream Client for Sunshine compatibility...")
                    need_gen = True
            except Exception as e:
                logger.warning(f"Failed to load existing remote credentials: {e}. Regenerating...")
                need_gen = True

        if need_gen:
            if not self._try_import_from_registry():
                self._generate_credentials()

        # Load or generate Unique Machine ID
        if os.path.exists(self.unique_id_path):
            try:
                with open(self.unique_id_path, "r", encoding="utf-8") as f:
                    self._unique_id = f.read().strip()
            except Exception:
                self._unique_id = ""

        if not self._unique_id:
            hostname = socket.gethostname().upper()[:8]
            rand_hex = "".join(random.choices("0123456789ABCDEF", k=16))
            self._unique_id = (hostname + rand_hex)[:16]
            try:
                with open(self.unique_id_path, "w", encoding="utf-8") as f:
                    f.write(self._unique_id)
            except OSError as e:
                logger.warning(f"Could not persist unique ID: {e}")

    def _generate_credentials(self) -> None:
        """Generate a fresh RSA-2048 private key and self-signed certificate matching Artemis/Moonlight."""
        logger.info("Generating new RSA-2048 key and self-signed X.509 certificate for Remote Gaming...")
        self._private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )

        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, "NVIDIA GameStream Client"),
        ])

        now = datetime.datetime.now(datetime.timezone.utc)
        self._certificate = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(self._private_key.public_key())
            .serial_number(1)
            .not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=365 * 20))
            .sign(self._private_key, hashes.SHA256())
        )

        # Write to disk
        with open(self.key_path, "wb") as f:
            f.write(
                self._private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption(),
                )
            )

        with open(self.crt_path, "wb") as f:
            f.write(self._certificate.public_bytes(serialization.Encoding.PEM))

        logger.info(f"Saved remote gaming credentials to {self.crt_path}")

    @property
    def private_key(self) -> rsa.RSAPrivateKey:
        if self._private_key is None:
            raise RuntimeError("Private key not initialized")
        return self._private_key

    @property
    def certificate(self) -> x509.Certificate:
        if self._certificate is None:
            raise RuntimeError("Certificate not initialized")
        return self._certificate

    def get_certificate_pem(self) -> bytes:
        """Returns PEM encoded certificate bytes."""
        return self.certificate.public_bytes(serialization.Encoding.PEM)

    def get_certificate_hex(self) -> str:
        """Returns lowercase hex representation of client PEM certificate matching Artemis/Moonlight."""
        return self.get_certificate_pem().hex()

    def get_signature_bytes(self) -> bytes:
        """Returns the signature bytes from our self-signed certificate."""
        return self.certificate.signature

    @property
    def unique_id(self) -> str:
        return self._unique_id


# ==================== CRYPTOGRAPHY PRIMITIVES ====================


def generate_random_bytes(length: int = 16) -> bytes:
    """Generate cryptographically secure random bytes."""
    return os.urandom(length)


def aes_128_ecb_encrypt(key: bytes, plaintext: bytes) -> bytes:
    """
    Encrypt plaintext using AES-128 in ECB mode with NO padding.
    Plaintext length must be a multiple of 16.
    """
    if len(key) != 16:
        raise ValueError("AES-128 key must be exactly 16 bytes")
    if len(plaintext) % 16 != 0:
        raise ValueError("Plaintext length must be multiple of 16 for ECB without padding")

    cipher = Cipher(algorithms.AES(key), modes.ECB())
    encryptor = cipher.encryptor()
    return encryptor.update(plaintext) + encryptor.finalize()


def aes_128_ecb_decrypt(key: bytes, ciphertext: bytes) -> bytes:
    """
    Decrypt ciphertext using AES-128 in ECB mode with NO padding.
    Ciphertext length must be a multiple of 16.
    """
    if len(key) != 16:
        raise ValueError("AES-128 key must be exactly 16 bytes")
    if len(ciphertext) % 16 != 0:
        raise ValueError("Ciphertext length must be multiple of 16 for ECB without padding")

    cipher = Cipher(algorithms.AES(key), modes.ECB())
    decryptor = cipher.decryptor()
    return decryptor.update(ciphertext) + decryptor.finalize()


def derive_aes_key(salt: bytes, pin: str, is_gen7_or_newer: bool = True) -> bytes:
    """
    Derive 16-byte AES key from salt and PIN.
    Server Gen 7+ uses SHA-256; earlier generations use SHA-1.
    """
    salted_pin = salt + pin.encode("utf-8")
    if is_gen7_or_newer:
        digest = hashlib.sha256(salted_pin).digest()
    else:
        digest = hashlib.sha1(salted_pin).digest()
    return digest[:16]


def generate_otp_hash(pin: str, salt_hex: str, passphrase: str = "") -> str:
    """
    Generate Apollo/Artemis One-Time Password hash:
    SHA-256(pin + salt + passphrase) in uppercase hex.
    """
    plaintext = pin + salt_hex + passphrase
    hash_bytes = hashlib.sha256(plaintext.encode("utf-8")).digest()
    return hash_bytes.hex().upper()


def sign_data(data: bytes, private_key: Optional[rsa.RSAPrivateKey] = None) -> bytes:
    """Sign data using RSA-SHA256 (PKCS#1 v1.5)."""
    if private_key is None:
        private_key = IdentityManager.get().private_key

    return private_key.sign(
        data,
        padding.PKCS1v15(),
        hashes.SHA256(),
    )


def verify_signature(server_cert_pem: str | bytes, data: bytes, signature: bytes) -> bool:
    """Verify signature using server's X.509 certificate."""
    try:
        if isinstance(server_cert_pem, str):
            pem_bytes = server_cert_pem.encode("utf-8")
        else:
            pem_bytes = server_cert_pem

        cert = x509.load_pem_x509_certificate(pem_bytes)
        pub_key = cert.public_key()
        if not isinstance(pub_key, rsa.RSAPublicKey):
            return False

        pub_key.verify(
            signature,
            data,
            padding.PKCS1v15(),
            hashes.SHA256(),
        )
        return True
    except Exception as e:
        logger.debug(f"Signature verification failed: {e}")
        return False


def get_cert_signature(cert_pem: str | bytes) -> bytes:
    """Extract signature bytes from a PEM certificate."""
    if isinstance(cert_pem, str):
        pem_bytes = cert_pem.encode("utf-8")
    else:
        pem_bytes = cert_pem
    cert = x509.load_pem_x509_certificate(pem_bytes)
    return cert.signature
