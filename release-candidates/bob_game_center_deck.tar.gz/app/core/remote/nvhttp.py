"""
NVHTTP Client for Sunshine, Apollo, and NVIDIA GameStream servers.
Ported and adapted from Artemis PC (nvhttp.cpp, servercommandmanager.cpp).
"""

from __future__ import annotations

import logging
import os
import uuid
import xml.etree.ElementTree as ET
from typing import Any, Optional
import urllib3

import requests

from app.core.remote.crypto import IdentityManager
from app.core.remote.limelight.api import SURROUNDAUDIOINFO_FROM_AUDIO_CONFIGURATION
from app.core.remote.limelight.config import StreamParams
from app.core.remote.models import RemoteApp, RemoteHost, StreamSettings

# Suppress InsecureRequestWarning because GameStream/Sunshine servers use self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)


class NvHttpException(Exception):
    def __init__(self, status_code: int, status_message: str):
        super().__init__(f"NvHTTP Error [{status_code}]: {status_message}")
        self.status_code = status_code
        self.status_message = status_message


class NvHttpClient:
    """HTTP and HTTPS client communicating with GameStream / Sunshine / Apollo server."""

    def __init__(
        self,
        host: str,
        http_port: int = 47989,
        https_port: int = 47984,
        server_cert_pem: str = "",
    ):
        self.host = host
        self.http_port = http_port
        self.https_port = https_port
        self.server_cert_pem = server_cert_pem

        self.identity = IdentityManager.get()
        self._session = requests.Session()
        self._session.trust_env = False  # Ignore WinINET / OS proxies
        self._session.headers.update({
            "Connection": "close",
            "User-Agent": "BobGaming/1.0",
        })

        # Client certificate for mutual TLS handshake on HTTPS
        if os.path.exists(self.identity.crt_path) and os.path.exists(self.identity.key_path):
            self._session.cert = (self.identity.crt_path, self.identity.key_path)

        self._session.verify = False

    def close(self) -> None:
        """Close underlying HTTP session and all active adapter socket connections."""
        try:
            self._session.close()
        except Exception:
            pass

    def __enter__(self) -> NvHttpClient:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    @property
    def http_base(self) -> str:
        return f"http://{self.host}:{self.http_port}"

    @property
    def https_base(self) -> str:
        return f"https://{self.host}:{self.https_port}"

    def _build_url(self, base: str, endpoint: str, params: Optional[dict[str, Any]] = None) -> str:
        query_params = {
            "uniqueid": self.identity.unique_id,
            "uuid": str(uuid.uuid4()),
        }
        if params:
            query_params.update(params)

        param_str = "&".join(f"{k}={v}" for k, v in query_params.items() if v is not None)
        endpoint = endpoint.lstrip("/")
        return f"{base}/{endpoint}?{param_str}"

    def _verify_response_xml(self, xml_text: str) -> ET.Element:
        """Parse response XML and check status_code attribute on root."""
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError as e:
            raise NvHttpException(-1, f"Malformed XML response: {e}")

        # Status code attribute
        code_str = root.attrib.get("status_code", "200")
        try:
            status_code = int(code_str)
        except ValueError:
            status_code = -1

        status_message = root.attrib.get("status_message", "OK")

        if status_code != 200:
            raise NvHttpException(status_code, status_message)

        return root

    # ==================== SERVER INFO ====================

    def get_server_info(self, use_https: bool = False, timeout: float = 4.0) -> dict[str, Any]:
        """Fetch /serverinfo from host and parse XML into dictionary."""
        base = self.https_base if use_https else self.http_base
        url = self._build_url(base, "serverinfo")

        try:
            resp = self._session.get(url, timeout=timeout)
            resp.raise_for_status()
        except requests.exceptions.SSLError as e:
            if use_https:
                # Retry on plain HTTP if SSL handshake fails (e.g. before pairing)
                logger.debug(f"HTTPS serverinfo failed: {e}. Falling back to HTTP...")
                return self.get_server_info(use_https=False, timeout=timeout)
            raise

        root = self._verify_response_xml(resp.text)

        apollo_ver = root.findtext("ApolloVersion") or ""
        has_permission = root.find("Permission") is not None
        has_virtual_display = root.find("VirtualDisplayCapable") is not None
        has_game_uuid = root.find("currentgameuuid") is not None
        is_apollo = bool(apollo_ver) or has_permission or has_virtual_display or has_game_uuid

        codec_mode_support_str = root.findtext("ServerCodecModeSupport") or "0"
        try:
            server_codec_mode_support = int(codec_mode_support_str)
        except ValueError:
            server_codec_mode_support = 0

        max_luma_str = root.findtext("MaxLumaPixelsHEVC") or "0"
        try:
            max_luma_pixels_hevc = int(max_luma_str)
        except ValueError:
            max_luma_pixels_hevc = 0

        info: dict[str, Any] = {
            "hostname": root.findtext("hostname") or root.findtext("name") or self.host,
            "appversion": root.findtext("appversion") or "",
            "gfeversion": root.findtext("GfeVersion") or "",
            "uniqueid": root.findtext("uniqueid") or "",
            "mac": root.findtext("mac") or "",
            "local_ip": root.findtext("LocalIP") or self.host,
            "pair_status": root.findtext("PairStatus") == "1",
            "current_game": int(root.findtext("currentgame") or "0"),
            "state": root.findtext("state") or "",
            "https_port": int(root.findtext("HttpsPort") or str(self.https_port)),
            "apollo_version": apollo_ver,
            "is_apollo": is_apollo,
            "server_codec_mode_support": server_codec_mode_support,
            "max_luma_pixels_hevc": max_luma_pixels_hevc,
            "server_commands": [],
        }

        # Check server commands (both direct <ServerCommand> and grouped <ServerCommands><Command>)
        for cmd_el in root.findall("ServerCommand"):
            if cmd_el.text and cmd_el.text.strip():
                cmd = cmd_el.text.strip()
                if cmd not in info["server_commands"]:
                    info["server_commands"].append(cmd)

        commands_el = root.find("ServerCommands")
        if commands_el is not None:
            for cmd_el in commands_el.findall("Command"):
                if cmd_el.text and cmd_el.text.strip():
                    cmd = cmd_el.text.strip()
                    if cmd not in info["server_commands"]:
                        info["server_commands"].append(cmd)

        return info

    # ==================== APP LIST & ASSETS ====================

    def get_app_list(self, timeout: float = 8.0) -> list[RemoteApp]:
        """Fetch list of available applications from /applist."""
        url = self._build_url(self.https_base, "applist")
        logger.info(f"NvHttpClient: Requesting app list from {url}...")
        resp = self._session.get(url, timeout=timeout)
        resp.raise_for_status()

        root = self._verify_response_xml(resp.text)
        apps: list[RemoteApp] = []

        for app_el in root.findall("App"):
            app_id_str = app_el.findtext("ID") or "0"
            try:
                app_id = int(app_id_str)
            except ValueError:
                app_id = 0

            title = app_el.findtext("AppTitle") or f"App {app_id}"
            uuid_str = app_el.findtext("UUID") or ""
            hdr_str = app_el.findtext("IsHdrSupported") or "0"

            apps.append(
                RemoteApp(
                    id=app_id,
                    title=title,
                    uuid=uuid_str,
                    is_hdr_supported=(hdr_str == "1"),
                )
            )

        return apps

    def get_box_art(self, app_id: int, timeout: float = 5.0) -> Optional[bytes]:
        """Fetch box art image bytes for a given application ID."""
        url = self._build_url(
            self.https_base,
            "appasset",
            {"appid": app_id, "AssetType": 2, "AssetIdx": 0},
        )
        try:
            resp = self._session.get(url, timeout=timeout)
            if resp.status_code == 200 and len(resp.content) > 100:
                return resp.content
        except Exception as e:
            logger.debug(f"Failed to fetch box art for app {app_id}: {e}")
        return None

    # ==================== STREAM SESSION MANAGEMENT ====================

    def _start_app(
        self,
        verb: str,
        app: RemoteApp,
        settings: StreamSettings,
        params: StreamParams,
        gamepad_mask: int = 0,
        timeout: float = 30.0,
    ) -> str:
        """
        Launch or resume remote game stream session on host.
        Port of Artemis app/backend/nvhttp.cpp:186-288 (NvHTTP::startApp).
        """
        # rikeyid is signed 32-bit int from first 4 bytes of IV (qFromBigEndian in nvhttp.cpp:201)
        rikey_id = int.from_bytes(params.aes_iv[:4], "big", signed=True)
        surround_info = SURROUNDAUDIOINFO_FROM_AUDIO_CONFIGURATION(params.config.audioConfiguration)

        if settings.enable_fractional_fps:
            mode = f"{settings.width}x{settings.height}x{settings.custom_refresh_rate:.2f}"
        else:
            mode = f"{settings.width}x{settings.height}x{settings.fps}"

        query_params: dict[str, Any] = {
            "appid": app.id,
            "mode": mode,
            "additionalStates": 1,
            "sops": 1,
            "rikey": params.aes_key.hex(),
            "rikeyid": rikey_id,
            "localAudioPlayMode": 0,
            "surroundAudioInfo": surround_info,
            "remoteControllersBitmap": gamepad_mask,
            "gcmap": gamepad_mask,
            "gcpersist": 0,  # Artemis default: persistGameControllersOnDisconnect=false (nvhttp.cpp:261)
        }

        # Apollo extensions (nvhttp.cpp:242-272)
        if app.uuid:
            query_params["appuuid"] = app.uuid

        if settings.enable_virtual_display:
            query_params["virtualDisplay"] = 1

        if settings.resolution_scale != 100:
            query_params["scaleFactor"] = settings.resolution_scale

        url = self._build_url(self.https_base, verb, query_params)

        # Append Limelight parameters (e.g. &corever=1, nvhttp.cpp:275)
        try:
            from app.core.remote.limelight._loader import load_api

            core_suffix = load_api().LiGetLaunchUrlQueryParameters().decode("ascii")
            if core_suffix:
                url += core_suffix
        except Exception:
            url += "&corever=1"

        logger.info(f"NvHttpClient: {verb} remote app {app.title} (ID {app.id}) with mode {query_params['mode']}...")

        resp = self._session.get(url, timeout=timeout)
        resp.raise_for_status()

        root = self._verify_response_xml(resp.text)
        session_url = root.findtext("sessionUrl0")
        if not session_url:
            raise NvHttpException(-1, f"Server {verb}ed app but did not return sessionUrl0")

        return session_url.strip()

    def launch_app(
        self,
        app: RemoteApp,
        settings: StreamSettings,
        params: StreamParams,
        gamepad_mask: int = 0,
        timeout: float = 30.0,
    ) -> str:
        """
        Request the host to launch a game stream session.
        Returns the RTSP session URL (sessionUrl0).
        """
        return self._start_app("launch", app, settings, params, gamepad_mask=gamepad_mask, timeout=timeout)

    def resume_app(
        self,
        app: RemoteApp,
        settings: StreamSettings,
        params: StreamParams,
        gamepad_mask: int = 0,
        timeout: float = 20.0,
    ) -> str:
        """Resume an already running stream session."""
        return self._start_app("resume", app, settings, params, gamepad_mask=gamepad_mask, timeout=timeout)

    def quit_app(self, timeout: float = 15.0) -> bool:
        """Cancel and terminate the currently running remote game session."""
        url = self._build_url(self.https_base, "cancel")
        try:
            resp = self._session.get(url, timeout=timeout)
            resp.raise_for_status()
            self._verify_response_xml(resp.text)
            return True
        except Exception as e:
            logger.warning(f"Error canceling remote stream session: {e}")
            return False

    # ==================== APOLLO CLIPBOARD & COMMANDS ====================

    def get_clipboard_content(self, timeout: float = 3.0) -> Optional[str]:
        """Fetch remote server clipboard text (Apollo servers only)."""
        url = self._build_url(self.https_base, "actions/clipboard", {"type": "text"})
        try:
            resp = self._session.get(url, timeout=timeout)
            if resp.status_code == 200:
                return resp.text
        except Exception as e:
            logger.debug(f"Failed to fetch clipboard: {e}")
        return None

    def send_clipboard_content(self, text: str, timeout: float = 3.0) -> bool:
        """Send local clipboard text to remote server (Apollo servers only)."""
        url = self._build_url(self.https_base, "actions/clipboard", {"type": "text"})
        try:
            resp = self._session.post(
                url,
                data=text.encode("utf-8"),
                headers={"Content-Type": "text/plain; charset=utf-8"},
                timeout=timeout,
            )
            return resp.status_code == 200
        except Exception as e:
            logger.debug(f"Failed to send clipboard: {e}")
            return False

    def execute_server_command(self, command_id: str, timeout: float = 10.0) -> bool:
        """Execute custom server command on Apollo / Sunshine server."""
        url = self._build_url(self.https_base, "actions/command", {"cmd": command_id})
        try:
            resp = self._session.post(url, timeout=timeout)
            return resp.status_code == 200
        except Exception as e:
            logger.warning(f"Failed to execute server command {command_id}: {e}")
            return False
