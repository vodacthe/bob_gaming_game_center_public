"""
Central Remote Gaming Orchestrator and State Manager.
Unites discovery, pairing, server commands, persistence, and stream execution.
"""

from __future__ import annotations

import json
import logging
import os
import socket
import threading
from typing import Any, Optional

from PySide6.QtCore import QObject, Signal

from app.config import CONFIG_DIR
from app.core.remote.discovery import HostDiscoveryEngine
from app.core.remote.models import PairState, RemoteApp, RemoteHost, StreamSettings
from app.core.remote.nvhttp import NvHttpClient
from app.core.remote.pairing import PairingManager
from app.core.remote.server_commands import ServerCommandManager
from app.core.remote.stream_runner import StreamController, StreamRunner

logger = logging.getLogger(__name__)

REMOTE_DIR = os.path.join(CONFIG_DIR, "remote")
HOSTS_FILE = os.path.join(REMOTE_DIR, "hosts.json")
SETTINGS_FILE = os.path.join(REMOTE_DIR, "settings.json")
BOXART_DIR = os.path.join(REMOTE_DIR, "boxart")

os.makedirs(BOXART_DIR, exist_ok=True)


class RemoteGamingManager(QObject):
    """Central manager coordinating discovery, host database, pairing, and streaming."""

    hosts_changed = Signal()
    host_selected = Signal(object)  # RemoteHost
    apps_updated = Signal(object)    # RemoteHost
    stream_started = Signal(object, object)  # RemoteHost, RemoteApp
    stream_stopped = Signal()
    stream_error = Signal(str)

    _instance: Optional[RemoteGamingManager] = None

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._hosts: dict[str, RemoteHost] = {}
        self._settings = StreamSettings()
        self._selected_host_uuid: Optional[str] = None
        self._lock = threading.Lock()

        # Subsystems
        self.discovery = HostDiscoveryEngine(self)
        self.pairing = PairingManager(self)
        self.server_commands = ServerCommandManager(self)
        self.stream_controller = StreamController(self)
        self.stream_runner = self.stream_controller

        # Wire signals
        self.discovery.host_discovered.connect(self._on_host_discovered)
        self.stream_controller.stream_started.connect(self.stream_started)
        self.stream_controller.stream_stopped.connect(self.stream_stopped)
        self.stream_controller.stream_error.connect(self.stream_error)

        self._load_settings()
        self._load_hosts()

    @classmethod
    def get(cls) -> RemoteGamingManager:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ==================== PERSISTENCE ====================

    def _load_settings(self) -> None:
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self._settings = StreamSettings.from_dict(data)
                if data.get("settings_version", 1) < self._settings.settings_version:
                    self.save_settings(self._settings)
            except Exception as e:
                logger.warning(f"[Remote] Failed to load remote settings: {e}")

    def save_settings(self, settings: StreamSettings) -> None:
        self._settings = settings
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(settings.to_dict(), f, indent=2, ensure_ascii=False)
            logger.info("Saved remote stream settings.")
        except Exception as e:
            logger.error(f"Failed to save remote settings: {e}")

    @property
    def settings(self) -> StreamSettings:
        return self._settings

    @staticmethod
    def _clear_running_state(host: RemoteHost) -> bool:
        """Mark host offline and clear any stale running-game flags. Returns True if mutated."""
        changed = bool(host.is_online or host.current_game_id != 0 or host.current_game_name)
        host.is_online = False
        host.current_game_id = 0
        host.current_game_name = ""
        for a in host.apps:
            if a.is_running:
                a.is_running = False
                changed = True
        return changed

    def _emit_safe(self, sig: Any, *args: Any) -> None:
        """Emit a Qt signal safely from background threads even if QObject was torn down."""
        try:
            sig.emit(*args)
        except RuntimeError:
            pass

    def _load_hosts(self) -> None:
        if os.path.exists(HOSTS_FILE):
            try:
                with open(HOSTS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for item in data:
                        host = RemoteHost.from_dict(item)
                        # Assume offline on startup until probed; clear stale running flags from cache
                        self._clear_running_state(host)
                        self._hosts[host.uuid] = host
                logger.info(f"[Remote] Loaded {len(self._hosts)} saved remote hosts.")
            except Exception as e:
                logger.warning(f"[Remote] Failed to load remote hosts: {e}")

    def _save_hosts(self) -> None:
        try:
            data = [h.to_dict() for h in self._hosts.values()]
            with open(HOSTS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save remote hosts: {e}")

    # ==================== HOST MANAGEMENT ====================

    def get_hosts(self) -> list[RemoteHost]:
        with self._lock:
            hosts = list(self._hosts.values())
        hosts.sort(
            key=lambda h: (
                0 if h.pair_state == PairState.PAIRED else 1,
                0 if h.is_online else 1,
            )
        )
        return hosts

    def get_host(self, host_uuid: str) -> Optional[RemoteHost]:
        with self._lock:
            return self._hosts.get(host_uuid)

    def select_host(self, host_uuid: str) -> None:
        host = self.get_host(host_uuid)
        if host:
            self._selected_host_uuid = host_uuid
            self.host_selected.emit(host)
            # If paired and online, refresh app list in background
            if host.pair_state == PairState.PAIRED:
                self.refresh_host_apps(host)

    def add_host_manually(self, ip: str, port: int = 47989) -> Optional[RemoteHost]:
        """Probe and add a host by IP address."""
        host = self.discovery.probe_host(ip, port=port)
        if host:
            self._on_host_discovered(host)
            return host
        return None

    def remove_host(self, host_uuid: str) -> None:
        with self._lock:
            if host_uuid in self._hosts:
                del self._hosts[host_uuid]
                self._save_hosts()
        self.hosts_changed.emit()

    def save_host_pairing(self, host: RemoteHost) -> None:
        """Persist newly paired host certificate and state to disk."""
        with self._lock:
            existing = self._hosts.get(host.uuid)
            if existing:
                existing.pair_state = host.pair_state
                existing.server_cert_pem = host.server_cert_pem
            else:
                self._hosts[host.uuid] = host
            self._save_hosts()
        self.hosts_changed.emit()

    def _on_host_discovered(self, host: RemoteHost) -> None:
        with self._lock:
            existing = self._hosts.get(host.uuid)
            if existing:
                # Merge dynamic fields preserving saved pairing cert
                existing.is_online = True
                existing.hostname = host.hostname
                existing.ip = host.ip
                existing.port = host.port
                existing.https_port = host.https_port
                if host.mac and host.mac != "00:00:00:00:00:00":
                    existing.mac = host.mac
                existing.app_version = host.app_version
                existing.apollo_version = host.apollo_version
                existing.is_apollo = host.is_apollo
                if host.server_commands:
                    existing.server_commands = host.server_commands
                existing.current_game_id = host.current_game_id
                for a in existing.apps:
                    a.is_running = bool(existing.current_game_id == a.id and a.id != 0)
            else:
                self._hosts[host.uuid] = host

            self._save_hosts()

        self._emit_safe(self.hosts_changed)

    def rescan_hosts(self) -> None:
        """Restart mDNS discovery and probe saved hosts in background to detect offline transitions."""
        self.discovery.stop_discovery()
        self.discovery.start_discovery()
        for host in self.get_hosts():
            threading.Thread(
                target=self._probe_saved_host,
                args=(host,),
                daemon=True,
                name=f"ProbeSaved-{host.hostname}",
            ).start()

    def _probe_saved_host(self, host: RemoteHost) -> None:
        probed = self.discovery.probe_host(host.ip, port=host.port, timeout=2.5)
        if probed is None:
            with self._lock:
                changed = self._clear_running_state(host)
                if changed:
                    self._save_hosts()
            if changed:
                logger.info(f"[Remote] Saved host {host.hostname} ({host.ip}) is offline; cleared running state")
                self._emit_safe(self.hosts_changed)
                self._emit_safe(self.apps_updated, host)

    def wake_host(self, host: RemoteHost) -> bool:
        """Send Wake-on-LAN magic packet if host has a valid MAC address."""
        mac_clean = (host.mac or "").replace(":", "").replace("-", "").strip()
        if len(mac_clean) != 12 or mac_clean == "0" * 12:
            logger.warning(f"[Remote] Cannot send Wake-on-LAN to {host.hostname}: missing or invalid MAC")
            return False
        try:
            payload = b"\xff" * 6 + bytes.fromhex(mac_clean) * 16
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                for target in ("255.255.255.255", host.ip):
                    for port in (9, 7):
                        try:
                            sock.sendto(payload, (target, port))
                        except OSError:
                            pass
            logger.info(f"[Remote] Sent Wake-on-LAN packet to {host.hostname} ({host.ip})")
            return True
        except Exception as e:
            logger.warning(f"[Remote] Failed to send Wake-on-LAN packet to {host.hostname}: {e}")
            return False

    # ==================== APP LIST & ASSETS ====================

    def refresh_host_apps(self, host: RemoteHost) -> None:
        """Fetch app list and download missing box art in background thread."""
        threading.Thread(
            target=self._run_refresh_apps,
            args=(host,),
            daemon=True,
            name=f"RefreshApps-{host.hostname}",
        ).start()

    # Backwards compatibility alias
    fetch_apps = refresh_host_apps

    def set_gamepad_monitor(self, monitor: Any) -> None:
        """Forward global GamepadMonitor instance to StreamController."""
        self.stream_controller.set_gamepad_monitor(monitor)

    def _run_refresh_apps(self, host: RemoteHost) -> None:
        client: Optional[NvHttpClient] = None
        was_online = host.is_online
        server_reachable = False
        try:
            logger.info(f"[Remote] Connecting to host {host.hostname} ({host.ip}:{host.https_port})...")
            client = NvHttpClient(host.ip, host.port, host.https_port, host.server_cert_pem)

            # Refresh server_info over HTTPS first to capture current game, server commands, and Apollo capabilities
            try:
                info = client.get_server_info(use_https=True, timeout=5.0)
                server_reachable = True
                if info.get("is_apollo"):
                    host.is_apollo = True
                host.server_commands = info.get("server_commands", [])
                if info.get("mac") and info["mac"] != "00:00:00:00:00:00":
                    host.mac = info["mac"]
                if "server_codec_mode_support" in info:
                    host.server_codec_mode_support = info["server_codec_mode_support"]
                if "max_luma_pixels_hevc" in info:
                    host.max_luma_pixels_hevc = info["max_luma_pixels_hevc"]
                host.current_game_id = info.get("current_game", 0)
                host.is_online = True
            except Exception as e:
                logger.debug(f"[Remote] Failed to refresh serverinfo over HTTPS: {e}")

            apps = client.get_app_list(timeout=10.0)
            server_reachable = True
            host.is_online = True

            # Download box art if missing
            for app in apps:
                art_file = os.path.join(BOXART_DIR, f"{host.uuid}_{app.id}.png")
                if not os.path.exists(art_file) or os.path.getsize(art_file) < 100:
                    art_bytes = client.get_box_art(app.id)
                    if art_bytes:
                        try:
                            with open(art_file, "wb") as f:
                                f.write(art_bytes)
                            app.box_art_path = art_file
                        except Exception:
                            pass
                else:
                    app.box_art_path = art_file

                if host.current_game_id == app.id and app.id != 0:
                    app.is_running = True
                else:
                    app.is_running = False

            with self._lock:
                host.apps = apps
                self._save_hosts()

            if not was_online:
                self._emit_safe(self.hosts_changed)
            self._emit_safe(self.apps_updated, host)
            logger.info(f"[Remote] Successfully loaded {len(apps)} apps for {host.hostname}: {[a.title for a in apps]} (Running game ID: {host.current_game_id})")

        except Exception as e:
            if not server_reachable and client is not None:
                try:
                    client.get_server_info(use_https=False, timeout=2.0)
                    server_reachable = True
                except Exception:
                    server_reachable = False

            if not server_reachable:
                with self._lock:
                    changed = self._clear_running_state(host)
                    if changed:
                        self._save_hosts()
                logger.warning(f"[Remote] Host {host.hostname} unreachable during app refresh ({e}); marked OFFLINE")
                if changed:
                    self._emit_safe(self.hosts_changed)
            else:
                logger.error(f"[Remote] Failed to fetch app list for {host.hostname}: {e}")
            self._emit_safe(self.apps_updated, host)
        finally:
            if client:
                client.close()

    # ==================== STREAM ACTIONS ====================

    def launch_game(self, host: RemoteHost, app: RemoteApp) -> bool:
        return self.stream_runner.start_stream(host, app, self._settings)

    def stop_stream(self) -> None:
        self.stream_runner.stop_stream()

    def quit_current_app(self, host: RemoteHost) -> bool:
        """Terminate any currently running remote game session on the host."""
        try:
            logger.info(f"[Remote] Requesting cancel/quit for running app on {host.hostname}...")
            with NvHttpClient(host.ip, host.port, host.https_port, host.server_cert_pem) as client:
                success = client.quit_app()
                if success:
                    host.current_game_id = 0
                    for a in host.apps:
                        a.is_running = False
                    with self._lock:
                        self._save_hosts()
                    self._emit_safe(self.apps_updated, host)
                    self._emit_safe(self.hosts_changed)
                return success
        except Exception as e:
            logger.warning(f"Failed to quit current app on host {host.hostname}: {e}")
            return False
