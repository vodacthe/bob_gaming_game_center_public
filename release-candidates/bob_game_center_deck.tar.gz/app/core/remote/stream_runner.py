"""
StreamController: Qt-facing facade for Remote Gaming streaming sessions.

Rewrite of app/core/remote/stream_runner.py for Phase 6.
Owns no SDL or C objects itself; delegates to StreamSession thread.
Reference: streaming-technical/09-phase6-integration.md §1
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from PySide6.QtCore import QObject, Signal

from app.core.remote.clipboard_sync import ClipboardSyncService
from app.core.remote.models import RemoteApp, RemoteHost, StreamSettings
from app.core.remote.stream.session import StreamSession

logger = logging.getLogger(__name__)


class StreamController(QObject):
    """Supervises active game streaming session from Qt main thread."""

    # Core Phase 6 signals (09-phase6-integration.md §1)
    stage_changed = Signal(str)                  # Localized stage text for the progress dialog
    session_started = Signal()                   # Emitted when SDL window is up (connects to progress.accept)
    session_ended = Signal(int, str)             # ML_ERROR_* / stage error code, user message ('' if graceful)

    # Relay / Compatibility signals for RemoteGamingManager & Main UI
    stream_started = Signal(object, object)      # RemoteHost, RemoteApp
    stream_stopped = Signal()
    stream_error = Signal(str)
    stats_updated = Signal(dict)

    def __init__(self, parent: Optional[QObject] = None, gamepad_monitor: Optional[Any] = None) -> None:
        super().__init__(parent)
        self._session: Optional[StreamSession] = None
        self._active_host: Optional[RemoteHost] = None
        self._active_app: Optional[RemoteApp] = None
        self._settings: Optional[StreamSettings] = None
        self._clipboard: Optional[ClipboardSyncService] = None
        self._gamepad_monitor: Optional[Any] = gamepad_monitor
        self._is_active: bool = False

    def set_gamepad_monitor(self, monitor: Any) -> None:
        """Set the global GamepadMonitor instance so sessions can pause it before SDL init."""
        self._gamepad_monitor = monitor

    @property
    def is_active(self) -> bool:
        """True while a streaming session is connecting or running."""
        return self._is_active

    @property
    def is_streaming(self) -> bool:
        """Alias for is_active for backward compatibility."""
        return self._is_active

    @property
    def current_session(self) -> Optional[StreamSession]:
        return self._session

    @property
    def active_host(self) -> Optional[RemoteHost]:
        return self._active_host

    @property
    def active_app(self) -> Optional[RemoteApp]:
        return self._active_app

    def start(
        self,
        host: RemoteHost,
        app: RemoteApp,
        settings: Optional[StreamSettings] = None,
    ) -> bool:
        if self._is_active or (self._session is not None and getattr(self._session, "is_alive", False)):
            logger.warning("[StreamController] Refusing to start: a stream session is already active or stopping.")
            return False

        if settings is None:
            parent = self.parent()
            if parent is not None and hasattr(parent, "settings"):
                settings = parent.settings
            else:
                settings = StreamSettings()

        self._is_active = True
        self._active_host = host
        self._active_app = app
        self._settings = settings

        logger.info(f"[StreamController] Starting stream session for {app.title} on {host.hostname}...")

        # Setup clipboard sync if enabled and host is Apollo
        if settings.clipboard_sync and host.is_apollo:
            try:
                self._clipboard = ClipboardSyncService(self)
                self._clipboard.start(host)
            except Exception as e:
                logger.warning(f"[StreamController] Failed to start clipboard sync: {e}")
                self._clipboard = None

        def _on_stage(text: str) -> None:
            self.stage_changed.emit(text)

        def _on_started() -> None:
            logger.info(f"[StreamController] Session window up for {app.title} on {host.hostname}")
            self.session_started.emit()
            self.stream_started.emit(host, app)

        def _on_focus_lost() -> None:
            if self._clipboard:
                try:
                    self._clipboard.sync_now()
                except Exception as e:
                    logger.debug(f"[StreamController] Clipboard sync_now error: {e}")

        def _on_ended(term_code: int, error_msg: str = "") -> None:
            logger.info(f"[StreamController] Session ended (code={term_code}, msg='{error_msg}')")
            if self._clipboard:
                try:
                    self._clipboard.stop()
                except Exception:
                    pass
                self._clipboard = None

            self._is_active = False
            self._session = None
            self.session_ended.emit(term_code, error_msg)
            if error_msg:
                self.stream_error.emit(error_msg)
            self.stream_stopped.emit()

        def _on_error(exc: Exception) -> None:
            logger.error(f"[StreamController] StreamSession error: {exc}")
            # The teardown will trigger _on_ended

        self._session = StreamSession(
            host=host,
            app=app,
            settings=settings,
            title=f"Bob Remote Gaming — {app.title}",
            gamepad_monitor=self._gamepad_monitor,
            on_stage_changed=_on_stage,
            on_session_started=_on_started,
            on_session_ended=_on_ended,
            on_error=_on_error,
            on_focus_lost=_on_focus_lost,
        )
        self._session.start()
        return True

    def start_stream(self, host: RemoteHost, app: RemoteApp, settings: Optional[StreamSettings] = None) -> bool:
        """Compatibility wrapper returning True immediately after launching thread."""
        try:
            return self.start(host, app, settings)
        except Exception as e:
            logger.error(f"[StreamController] Failed to spawn stream session: {e}")
            self._is_active = False
            self.stream_error.emit(str(e))
            return False

    def cancel(self) -> None:
        """Cancel while starting: calls api.LiInterruptConnection() (09-phase6-integration.md §1)."""
        logger.info("[StreamController] Cancelling stream session during connect...")
        if self._session:
            self._session.interrupt()

    def stop(self) -> None:
        """Stop while running: sends SDL_QUIT event to StreamSession thread."""
        logger.info("[StreamController] Stopping stream session...")
        if self._session:
            self._session.request_stop()

    def stop_stream(self) -> None:
        """Compatibility alias for stop()."""
        self.stop()


# Backwards compatibility alias
StreamRunner = StreamController
