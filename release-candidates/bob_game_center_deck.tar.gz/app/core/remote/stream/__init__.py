"""
Stream subsystem for Remote Gaming (port of Artemis app/streaming/*).
"""

from __future__ import annotations
