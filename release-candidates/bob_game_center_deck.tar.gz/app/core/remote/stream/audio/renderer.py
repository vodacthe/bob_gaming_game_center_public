"""
SDL audio renderer with Opus decode, FEC, and packet-loss concealment (PLC).
Ports Artemis PC audio session and renderer:
  - app/streaming/audio/audio.cpp:149-271 (arInit, arCleanup, arDecodeAndPlaySample, reinit drop window)
  - app/streaming/audio/renderers/sdlaud.cpp:19-140 (prepareForPlayback, submitAudio, latency & backpressure)
  - app/streaming/audio/renderers/renderer.h:20-46 (buffer size & format calculations)
"""

from __future__ import annotations

import ctypes
import logging
import sys
import threading
import time
from ctypes import wintypes
from typing import Any, Optional

import sdl2

from app.core.remote.limelight.api import (
    CAPABILITY_SUPPORTS_ARBITRARY_AUDIO_DURATION,
    OPUS_MULTISTREAM_CONFIGURATION,
    LimelightApi,
)
from app.core.remote.stream.audio.opus import LibOpus

logger = logging.getLogger(__name__)


class SdlAudioRenderer:
    """Port of Artemis audio.cpp and sdlaud.cpp.

    Handles audio playback via SDL2 audio queue, decoding frames with libopus
    in float32 format, handling packet-loss concealment when packets are lost (NULL data),
    maintaining 30 ms queue latency bounds, and recovering gracefully if the audio device fails.
    """

    def __init__(
        self,
        api: Optional[LimelightApi] = None,
        opus_api: Optional[LibOpus] = None,
        channels: Optional[int] = None,
        sample_rate: Optional[int] = None,
        **kwargs: Any,
    ):
        self._api = api
        self._opus_api = opus_api
        self.capabilities = CAPABILITY_SUPPORTS_ARBITRARY_AUDIO_DURATION

        self._device: int = 0
        self._decoder: Optional[ctypes.c_void_p] = None
        self._out_buffer: Optional[Any] = None

        self._sample_rate: int = sample_rate or 48000
        self._channel_count: int = channels or 2
        self._streams: int = 1
        self._coupled_streams: int = 1
        self._samples_per_frame: int = 240
        self._mapping = (ctypes.c_ubyte * 8)(0, 1, 0, 0, 0, 0, 0, 0)
        self._frame_size: int = 240 * self._channel_count * 4  # bytes per packet across all channels

        self._sample_count: int = 0
        self._drop_audio_end_time: int = 0
        self._muted: bool = False
        self._initialized: bool = False
        self._lock = threading.Lock()

    @property
    def muted(self) -> bool:
        """True if audio is temporarily muted (e.g. mute_on_focus_loss)."""
        return self._muted

    @muted.setter
    def muted(self, val: bool) -> None:
        self._muted = bool(val)

    @property
    def sample_count(self) -> int:
        return self._sample_count

    @property
    def drop_audio_end_time(self) -> int:
        return self._drop_audio_end_time

    @property
    def device(self) -> int:
        return self._device

    @property
    def decoder(self) -> Optional[ctypes.c_void_p]:
        return self._decoder

    @property
    def frame_size(self) -> int:
        return self._frame_size

    def init(
        self,
        audio_configuration: int,
        p_opus_config: Any,
        context: Any = None,
        ar_flags: int = 0,
    ) -> int:
        """Called on thread calling LiStartConnection.

        Ports Artemis audio.cpp:149-156, audio.cpp:61-107, sdlaud.cpp:19-79.
        """
        # Ensure libopus function table is loaded
        if self._opus_api is None:
            try:
                self._opus_api = LibOpus.load()
            except Exception as e:
                logger.error("[AudioRenderer] Failed to load libopus: %s", e)
                return -1

        # Copy OPUS_MULTISTREAM_CONFIGURATION (audio.cpp:153)
        if p_opus_config:
            if hasattr(p_opus_config, "contents"):
                cfg = p_opus_config.contents
            elif hasattr(p_opus_config, "_obj"):
                cfg = getattr(p_opus_config, "_obj")
            elif isinstance(p_opus_config, int):
                cfg = ctypes.cast(
                    p_opus_config, ctypes.POINTER(OPUS_MULTISTREAM_CONFIGURATION)
                ).contents
            else:
                cfg = p_opus_config

            self._sample_rate = int(cfg.sampleRate)
            self._channel_count = int(cfg.channelCount)
            self._streams = int(cfg.streams)
            self._coupled_streams = int(cfg.coupledStreams)
            self._samples_per_frame = int(cfg.samplesPerFrame)
            for i in range(8):
                self._mapping[i] = cfg.mapping[i]

        self._frame_size = self._samples_per_frame * self._channel_count * 4
        self._sample_count = 0
        self._drop_audio_end_time = 0
        self._initialized = True

        # Initialize SDL audio device and Opus decoder
        # A missing audio device is not fatal (audio.cpp:78-80): Artemis keeps streaming video
        success = self._init_audio_device_and_decoder()
        if not success and self._decoder is None:
            # Check if decoder can be created at all (to return -1 if Opus config is invalid)
            mapping_arr = (ctypes.c_uint8 * 8)(*self._mapping)
            err = ctypes.c_int(0)
            dec = self._opus_api.opus_multistream_decoder_create(
                self._sample_rate,
                self._channel_count,
                self._streams,
                self._coupled_streams,
                mapping_arr,
                ctypes.byref(err),
            )
            if not dec or err.value != 0:
                logger.error("[AudioRenderer] Opus decoder configuration invalid: err=%d", err.value)
                return -1
            self._opus_api.opus_multistream_decoder_destroy(dec)

        return 0

    def start(self) -> None:
        """No-op (Artemis audio.cpp does nothing here)."""
        pass

    def stop(self) -> None:
        """No-op (Artemis audio.cpp does nothing here)."""
        pass

    def cleanup(self) -> None:
        """Called on thread calling LiStopConnection (AR cleanup callback).

        Ports Artemis audio.cpp:158-165, sdlaud.cpp:81-95.
        Must be idempotent and guarded by self._lock shared with decode_and_play_sample.
        """
        with self._lock:
            self._close_device_and_decoder()
            self._initialized = False

    def decode_and_play_sample(self, sample_data: Any, sample_length: int) -> None:
        """Called on C AudioDec thread (~200 calls/s).

        Ports Artemis audio.cpp:167-271, sdlaud.cpp:102-140.
        Must remain lean: no per-call allocations, no per-call logging, no Qt touches.
        """
        # 1. First call: raise thread priority (audio.cpp:176-183)
        if self._sample_count == 0:
            if sys.platform == "win32":
                try:
                    k32 = ctypes.windll.kernel32
                    k32.GetCurrentThread.restype = wintypes.HANDLE
                    k32.SetThreadPriority.argtypes = [wintypes.HANDLE, ctypes.c_int]
                    k32.SetThreadPriority.restype = wintypes.BOOL
                    k32.SetThreadPriority(k32.GetCurrentThread(), 2)  # THREAD_PRIORITY_HIGHEST = 2
                except Exception:
                    pass

        # 2. Drop window check (audio.cpp:186-198)
        if self._drop_audio_end_time != 0:
            now = sdl2.SDL_GetTicks()
            if (self._drop_audio_end_time - now) <= 0:
                self._drop_audio_end_time = 0
            else:
                return

        self._sample_count += 1

        # 3. Mute check (audio.cpp:203-205)
        if self._muted:
            return

        with self._lock:
            # 4. Decode & Submit (audio.cpp:207-252)
            if self._device != 0 and self._decoder is not None and self._out_buffer is not None:
                # When sample_data is NULL / 0 or length is 0, libopus performs PLC (audio.cpp:217-223)
                is_plc = sample_data is None or sample_data == 0 or sample_length == 0
                data_ptr = (
                    None
                    if is_plc
                    else (
                        sample_data
                        if isinstance(sample_data, ctypes.c_void_p)
                        else ctypes.c_void_p(sample_data)
                    )
                )
                data_len = 0 if is_plc else sample_length

                # When PLC: frame_size must be exact missing frame length (self._samples_per_frame)
                # When normal decode: give capacity up to buffer size so 10ms packets decode without truncation
                decode_frames = self._samples_per_frame if is_plc else max(self._samples_per_frame, 960)

                samples_decoded = self._opus_api.opus_multistream_decode_float(
                    self._decoder,
                    data_ptr,
                    data_len,
                    ctypes.cast(self._out_buffer, ctypes.c_void_p),
                    decode_frames,
                    0,
                )

                if samples_decoded > 0:
                    bytes_to_queue = samples_decoded * self._channel_count * 4
                    if not self._submit_audio(bytes_to_queue):
                        # Device failure (unplugged headset, SDL_AUDIO_STOPPED) - audio.cpp:242-252
                        self._close_device_and_decoder()

            # 5. Device failure retry & drop window calculation (audio.cpp:254-271)
            # Only try to recreate the audio renderer every 200 samples (~1 second) to avoid thrashing
            if (
                (self._device == 0 or self._decoder is None)
                and (self._sample_count % 200) == 0
                and self._initialized
            ):
                reinit_start = sdl2.SDL_GetTicks()
                if self._init_audio_device_and_decoder():
                    reinit_stop = sdl2.SDL_GetTicks()
                    duration = reinit_stop - reinit_start
                    self._drop_audio_end_time = reinit_stop + duration
                    logger.info(
                        "[AudioRenderer] Audio reinitialization took %d ms - starting drop window",
                        duration,
                    )

    def _submit_audio(self, bytes_written: int) -> bool:
        """Submit audio buffer to SDL audio queue with backpressure and latency control.

        Ports Artemis sdlaud.cpp:102-140.
        """
        if bytes_written == 0:
            return True

        # Artemis sdlaud.cpp:111-113: Don't queue if there's > 30 ms of audio waiting in Moonlight queue
        if self._api is not None and hasattr(self._api, "LiGetPendingAudioDuration"):
            try:
                if self._api.LiGetPendingAudioDuration() > 30:
                    return True
            except Exception:
                pass

        # Artemis sdlaud.cpp:118-131: Backpressure loop (up to 100 iterations of 1 ms sleep)
        for _ in range(100):
            if sdl2.SDL_GetAudioDeviceStatus(self._device) == sdl2.SDL_AUDIO_STOPPED:
                return False

            if sdl2.SDL_GetQueuedAudioSize(self._device) // self._frame_size <= 10:
                break

            time.sleep(0.001)

        # Artemis sdlaud.cpp:133-137: Queue audio buffer
        sdl2.SDL_QueueAudio(
            self._device,
            ctypes.cast(self._out_buffer, ctypes.c_void_p),
            bytes_written,
        )
        return True

    def _init_audio_device_and_decoder(self) -> bool:
        """Open SDL audio device and create Opus multistream decoder.

        Ports Artemis sdlaud.cpp:19-79, audio.cpp:88-101.
        """
        if sdl2.SDL_InitSubSystem(sdl2.SDL_INIT_AUDIO) != 0:
            logger.warning(
                "[AudioRenderer] SDL_InitSubSystem(SDL_INIT_AUDIO) failed: %s",
                sdl2.SDL_GetError(),
            )

        # sdlaud.cpp:24-34: Desired buffer: floor of 480 samples, up to 3 frames (15 ms)
        buffer_samples = max(480, self._samples_per_frame * 3)
        want = sdl2.SDL_AudioSpec(
            freq=self._sample_rate,
            aformat=sdl2.AUDIO_F32SYS,
            channels=self._channel_count,
            samples=buffer_samples,
        )
        have = sdl2.SDL_AudioSpec(0, 0, 0, 0)

        dev = sdl2.SDL_OpenAudioDevice(None, 0, ctypes.byref(want), ctypes.byref(have), 0)
        if dev == 0:
            logger.warning("[AudioRenderer] Failed to open audio device: %s", sdl2.SDL_GetError())
            return False

        # Allocate reusable float32 buffer (audio.cpp:211)
        max_samples = max(self._samples_per_frame, 960)
        self._out_buffer = (ctypes.c_float * (max_samples * self._channel_count))()

        # Create Opus decoder (audio.cpp:88-101)
        mapping_arr = (ctypes.c_uint8 * 8)(*self._mapping)
        err = ctypes.c_int(0)
        dec = self._opus_api.opus_multistream_decoder_create(
            self._sample_rate,
            self._channel_count,
            self._streams,
            self._coupled_streams,
            mapping_arr,
            ctypes.byref(err),
        )
        if not dec or err.value != 0:
            logger.warning("[AudioRenderer] Failed to create Opus decoder: err=%d", err.value)
            sdl2.SDL_CloseAudioDevice(dev)
            return False

        # Start playback (sdlaud.cpp:76)
        sdl2.SDL_PauseAudioDevice(dev, 0)

        self._device = dev
        self._decoder = dec
        return True

    def _close_device_and_decoder(self) -> None:
        """Stop device, close SDL audio subsystem, destroy opus decoder.

        Ports Artemis sdlaud.cpp:81-95, audio.cpp:158-165.
        """
        if self._device != 0:
            try:
                sdl2.SDL_PauseAudioDevice(self._device, 1)
                sdl2.SDL_CloseAudioDevice(self._device)
            except Exception:
                pass
            self._device = 0

        try:
            sdl2.SDL_QuitSubSystem(sdl2.SDL_INIT_AUDIO)
        except Exception:
            pass

        if self._decoder is not None and self._opus_api is not None:
            try:
                self._opus_api.opus_multistream_decoder_destroy(self._decoder)
            except Exception:
                pass
            self._decoder = None

        self._out_buffer = None
