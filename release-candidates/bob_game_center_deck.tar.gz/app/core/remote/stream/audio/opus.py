"""
ctypes bindings for libopus (libopus-0.dll).
Supports multi-stream Opus decoding with packet-loss concealment (PLC).
"""

from __future__ import annotations

import ctypes
import logging
import sys
from pathlib import Path
from typing import Optional

from app.core.remote.native_paths import native_bin_dir

logger = logging.getLogger(__name__)

# Opus error codes
OPUS_OK = 0
OPUS_BAD_ARG = -1
OPUS_BUFFER_TOO_SMALL = -2
OPUS_INTERNAL_ERROR = -3
OPUS_INVALID_PACKET = -4
OPUS_UNIMPLEMENTED = -5
OPUS_INVALID_STATE = -6
OPUS_ALLOC_FAIL = -7

_OPUS_LIB: Optional[ctypes.CDLL] = None


def find_libopus_path() -> Optional[Path]:
    """Find libopus-0.dll in runtime and dev locations."""
    # 1. PyInstaller frozen directory
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        meipass_p = Path(sys._MEIPASS) / "libopus-0.dll"
        if meipass_p.exists():
            return meipass_p

    # 2. native/bin/x64 directory
    bin_p = native_bin_dir() / "libopus-0.dll"
    if bin_p.exists():
        return bin_p

    # 3. pysdl2-dll directory
    try:
        import sdl2dll

        dll_dir = getattr(sdl2dll, "postpath", None)
        if dll_dir and (Path(dll_dir) / "libopus-0.dll").exists():
            return Path(dll_dir) / "libopus-0.dll"
        candidate = Path(sdl2dll.__file__).parent / "dll" / "libopus-0.dll"
        if candidate.exists():
            return candidate
    except Exception:
        pass

    # 4. Fallback in sys.path
    for p in sys.path:
        cand = Path(p) / "sdl2dll" / "dll" / "libopus-0.dll"
        if cand.exists():
            return cand

    return None


class LibOpus:
    """Loaded libopus ctypes function table."""

    def __init__(self, dll: ctypes.CDLL):
        self._dll = dll

        self.opus_multistream_decoder_create = dll.opus_multistream_decoder_create
        self.opus_multistream_decoder_create.argtypes = [
            ctypes.c_int32,  # Fs (sample rate)
            ctypes.c_int,    # channels
            ctypes.c_int,    # streams
            ctypes.c_int,    # coupled_streams
            ctypes.POINTER(ctypes.c_uint8),  # mapping
            ctypes.POINTER(ctypes.c_int),    # error
        ]
        self.opus_multistream_decoder_create.restype = ctypes.c_void_p

        self.opus_multistream_decode_float = dll.opus_multistream_decode_float
        self.opus_multistream_decode_float.argtypes = [
            ctypes.c_void_p,  # st (OpusMSDecoder*)
            ctypes.c_void_p,  # data (const unsigned char* or None for PLC)
            ctypes.c_int32,   # len (0 for PLC)
            ctypes.c_void_p,  # pcm (float*)
            ctypes.c_int,     # frame_size (max samples per channel)
            ctypes.c_int,     # decode_fec (0)
        ]
        self.opus_multistream_decode_float.restype = ctypes.c_int

        self.opus_multistream_decode = dll.opus_multistream_decode
        self.opus_multistream_decode.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_int32,
            ctypes.c_void_p,
            ctypes.c_int,
            ctypes.c_int,
        ]
        self.opus_multistream_decode.restype = ctypes.c_int

        self.opus_multistream_decoder_destroy = dll.opus_multistream_decoder_destroy
        self.opus_multistream_decoder_destroy.argtypes = [ctypes.c_void_p]
        self.opus_multistream_decoder_destroy.restype = None

    @classmethod
    def load(cls, dll_path: Optional[str | Path] = None) -> LibOpus:
        """Load and bind libopus-0.dll."""
        global _OPUS_LIB
        if dll_path is not None:
            return cls(ctypes.CDLL(str(dll_path)))
        if _OPUS_LIB is None:
            resolved = find_libopus_path()
            if resolved:
                _OPUS_LIB = ctypes.CDLL(str(resolved))
            else:
                _OPUS_LIB = ctypes.CDLL("libopus-0.dll")
        return cls(_OPUS_LIB)
