"""
Stream video stats tracking and overlay text formatting.

1:1 port of Artemis VIDEO_STATS, addVideoStats, stringifyVideoStats, and window roll.
Source of truth:
- artemis-pc/app/streaming/video/decoder.h:11-33
- artemis-pc/app/streaming/video/ffmpeg.cpp:781-986, 1904-1951
Reference: streaming-technical/06-phase3-session-video.md §7, §8
"""

from __future__ import annotations

import ctypes
from ctypes import byref, c_uint32
import logging
import time
from dataclasses import dataclass
from typing import Callable

from app.core.remote.limelight import api, load_api

logger = logging.getLogger(__name__)


def _get_rtt_info() -> tuple[int, int]:
    try:
        api_inst = load_api()
        rtt = c_uint32()
        rtt_var = c_uint32()
        if api_inst.LiGetEstimatedRttInfo(byref(rtt), byref(rtt_var)):
            return rtt.value, rtt_var.value
    except Exception:
        pass
    return 0, 0


@dataclass
class VideoStats:
    """Port of Artemis VIDEO_STATS struct (decoder.h:11-33)."""

    received_frames: int = 0
    decoded_frames: int = 0
    rendered_frames: int = 0
    total_frames: int = 0
    network_dropped_frames: int = 0
    pacer_dropped_frames: int = 0
    min_host_processing_latency: int = 0  # 1/10 ms units
    max_host_processing_latency: int = 0  # 1/10 ms units
    total_host_processing_latency: int = 0
    frames_with_host_processing_latency: int = 0
    total_reassembly_time: int = 0
    total_decode_time: float = 0.0  # ms
    total_pacer_time: float = 0.0  # ms
    total_render_time: float = 0.0  # ms
    last_rtt: int = 0
    last_rtt_variance: int = 0
    total_fps: float = 0.0
    received_fps: float = 0.0
    decoded_fps: float = 0.0
    rendered_fps: float = 0.0
    measurement_start_timestamp: float = 0.0  # seconds


def add_video_stats(src: VideoStats, dst: VideoStats, now_ts: float | None = None) -> None:
    """Port of FFmpegVideoDecoder::addVideoStats (ffmpeg.cpp:781-828)."""
    dst.received_frames += src.received_frames
    dst.decoded_frames += src.decoded_frames
    dst.rendered_frames += src.rendered_frames
    dst.total_frames += src.total_frames
    dst.network_dropped_frames += src.network_dropped_frames
    dst.pacer_dropped_frames += src.pacer_dropped_frames
    dst.total_reassembly_time += src.total_reassembly_time
    dst.total_decode_time += src.total_decode_time
    dst.total_pacer_time += src.total_pacer_time
    dst.total_render_time += src.total_render_time

    if dst.min_host_processing_latency == 0:
        dst.min_host_processing_latency = src.min_host_processing_latency
    elif src.min_host_processing_latency != 0:
        dst.min_host_processing_latency = min(
            dst.min_host_processing_latency, src.min_host_processing_latency
        )
    dst.max_host_processing_latency = max(
        dst.max_host_processing_latency, src.max_host_processing_latency
    )
    dst.total_host_processing_latency += src.total_host_processing_latency
    dst.frames_with_host_processing_latency += src.frames_with_host_processing_latency

    rtt, rtt_var = _get_rtt_info()
    if rtt > 0:
        dst.last_rtt = rtt
        dst.last_rtt_variance = rtt_var
    else:
        dst.last_rtt = 0
        dst.last_rtt_variance = 0

    now = now_ts if now_ts is not None else time.monotonic()
    if dst.measurement_start_timestamp == 0.0:
        dst.measurement_start_timestamp = src.measurement_start_timestamp

    elapsed = max(0.001, now - dst.measurement_start_timestamp)
    dst.total_fps = dst.total_frames / elapsed
    dst.received_fps = dst.received_frames / elapsed
    dst.decoded_fps = dst.decoded_frames / elapsed
    dst.rendered_fps = dst.rendered_frames / elapsed


def get_codec_display_name(video_format: int) -> str:
    """Port of codecString switch (ffmpeg.cpp:839-905)."""
    if video_format == api.VIDEO_FORMAT_H264:
        return "H.264"
    if video_format == api.VIDEO_FORMAT_H264_HIGH8_444:
        return "H.264 4:4:4"
    if video_format == api.VIDEO_FORMAT_H265:
        return "HEVC"
    if video_format == api.VIDEO_FORMAT_H265_REXT8_444:
        return "HEVC 4:4:4"
    if video_format == api.VIDEO_FORMAT_H265_MAIN10:
        return "HEVC 10-bit SDR"
    if video_format == api.VIDEO_FORMAT_H265_REXT10_444:
        return "HEVC 10-bit SDR 4:4:4"
    if video_format == api.VIDEO_FORMAT_AV1_MAIN8:
        return "AV1"
    if video_format == api.VIDEO_FORMAT_AV1_HIGH8_444:
        return "AV1 4:4:4"
    if video_format == api.VIDEO_FORMAT_AV1_MAIN10:
        return "AV1 10-bit SDR"
    if video_format == api.VIDEO_FORMAT_AV1_HIGH10_444:
        return "AV1 10-bit SDR 4:4:4"
    return "UNKNOWN"


def stringify_video_stats(
    stats: VideoStats,
    width: int,
    height: int,
    video_format: int,
) -> str:
    """Port of FFmpegVideoDecoder::stringifyVideoStats (ffmpeg.cpp:830-986).

    Matches the 11 lines specified in streaming-technical/06-phase3-session-video.md §7.
    """
    codec_name = get_codec_display_name(video_format)
    lines: list[str] = []

    if stats.received_fps > 0 or stats.total_frames > 0:
        lines.append(f"Video stream: {width}x{height} {stats.total_fps:.2f} FPS (Codec: {codec_name})")
        lines.append(f"Incoming frame rate from network: {stats.received_fps:.2f} FPS")
        lines.append(f"Decoding frame rate: {stats.decoded_fps:.2f} FPS")
        lines.append(f"Rendering frame rate: {stats.rendered_fps:.2f} FPS")

    if stats.frames_with_host_processing_latency > 0:
        min_lat = stats.min_host_processing_latency / 10.0
        max_lat = stats.max_host_processing_latency / 10.0
        avg_lat = (
            stats.total_host_processing_latency
            / 10.0
            / stats.frames_with_host_processing_latency
        )
        lines.append(f"Host processing latency min/max/average: {min_lat:.1f}/{max_lat:.1f}/{avg_lat:.1f} ms")

    if stats.rendered_frames > 0 or stats.decoded_frames > 0:
        net_drop_pct = (
            (stats.network_dropped_frames / stats.total_frames * 100.0)
            if stats.total_frames > 0
            else 0.0
        )
        pacer_drop_pct = (
            (stats.pacer_dropped_frames / stats.decoded_frames * 100.0)
            if stats.decoded_frames > 0
            else 0.0
        )
        rtt_str = (
            f"{stats.last_rtt} ms (variance: {stats.last_rtt_variance} ms)"
            if stats.last_rtt != 0
            else "N/A"
        )
        avg_decode_time = (
            stats.total_decode_time / stats.decoded_frames
            if stats.decoded_frames > 0
            else 0.0
        )
        avg_pacer_time = (
            stats.total_pacer_time / stats.rendered_frames
            if stats.rendered_frames > 0
            else 0.0
        )
        avg_render_time = (
            stats.total_render_time / stats.rendered_frames
            if stats.rendered_frames > 0
            else 0.0
        )

        lines.append(f"Frames dropped by your network connection: {net_drop_pct:.2f}%")
        lines.append(f"Frames dropped due to network jitter: {pacer_drop_pct:.2f}%")
        lines.append(f"Average network latency: {rtt_str}")
        lines.append(f"Average decoding time: {avg_decode_time:.2f} ms")
        lines.append(f"Average frame queue delay: {avg_pacer_time:.2f} ms")
        lines.append(f"Average rendering time (including monitor V-sync latency): {avg_render_time:.2f} ms")

    return "\n".join(lines)


class StatsTracker:
    """Manages active and last 1-second stat windows and rolls them.

    Port of Artemis ffmpeg.cpp:1904-1951.
    """

    def __init__(
        self,
        width: int,
        height: int,
        video_format: int,
        on_overlay_text_updated: Callable[[str], None] | None = None,
    ) -> None:
        self.width = width
        self.height = height
        self.video_format = video_format
        self._on_overlay_text_updated = on_overlay_text_updated

        self.last_wnd = VideoStats()
        self.active_wnd = VideoStats()
        self.global_stats = VideoStats()
        self._last_frame_number: int | None = None

    def on_submit(self, du: api.DECODE_UNIT) -> None:
        """Called by decoder on submitDecodeUnit (ffmpeg.cpp:1904-1951)."""
        now = time.monotonic()
        if self._last_frame_number is None:
            self.active_wnd.measurement_start_timestamp = now
            self._last_frame_number = du.frameNumber
        else:
            if du.frameNumber > self._last_frame_number + 1:
                gap = du.frameNumber - (self._last_frame_number + 1)
                self.active_wnd.network_dropped_frames += gap
                self.active_wnd.total_frames += gap
            self._last_frame_number = du.frameNumber

        # Check for 1000ms window roll (ffmpeg.cpp:1916)
        if now >= self.active_wnd.measurement_start_timestamp + 1.0:
            self._roll_window(now)

        if du.frameHostProcessingLatency != 0:
            lat = du.frameHostProcessingLatency
            if self.active_wnd.min_host_processing_latency != 0:
                self.active_wnd.min_host_processing_latency = min(
                    self.active_wnd.min_host_processing_latency, lat
                )
            else:
                self.active_wnd.min_host_processing_latency = lat
            self.active_wnd.max_host_processing_latency = max(
                self.active_wnd.max_host_processing_latency, lat
            )
            self.active_wnd.total_host_processing_latency += lat
            self.active_wnd.frames_with_host_processing_latency += 1

        self.active_wnd.received_frames += 1
        self.active_wnd.total_frames += 1

    def on_frame_decoded(self, decode_time_ms: float) -> None:
        """Called when a frame finishes decoding (ffmpeg.cpp:1817-1833)."""
        self.active_wnd.decoded_frames += 1
        self.active_wnd.total_decode_time += max(0.0, decode_time_ms)

    def on_frame_rendered(self, render_time_ms: float, pacer_time_ms: float, pacer_drops: int = 0) -> None:
        """Called after SDL present (sdlvid.cpp / ffmpeg.cpp)."""
        self.active_wnd.rendered_frames += 1
        self.active_wnd.total_render_time += max(0.0, render_time_ms)
        self.active_wnd.total_pacer_time += max(0.0, pacer_time_ms)
        self.active_wnd.pacer_dropped_frames += pacer_drops

    def _roll_window(self, now: float) -> None:
        """Roll active window into last window and format overlay text."""
        # Calculate combined stats over last two windows (ffmpeg.cpp:1919-1926)
        combined = VideoStats()
        add_video_stats(self.last_wnd, combined, now_ts=now)
        add_video_stats(self.active_wnd, combined, now_ts=now)

        text = stringify_video_stats(combined, self.width, self.height, self.video_format)
        if self._on_overlay_text_updated:
            self._on_overlay_text_updated(text)

        # Log diagnostic line per second (06-phase3-session-video.md §8)
        logger.info(
            f"[STATS] Total FPS: {combined.total_fps:.1f} | Dec: {combined.decoded_fps:.1f} | "
            f"Ren: {combined.rendered_fps:.1f} | DecTime: {combined.total_decode_time / max(1, combined.decoded_frames):.2f}ms | "
            f"NetDrop: {combined.network_dropped_frames} | PacerDrop: {combined.pacer_dropped_frames}"
        )

        add_video_stats(self.active_wnd, self.global_stats, now_ts=now)
        self.last_wnd = self.active_wnd
        self.active_wnd = VideoStats(measurement_start_timestamp=now)
