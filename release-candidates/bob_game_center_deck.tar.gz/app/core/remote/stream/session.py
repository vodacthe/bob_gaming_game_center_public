"""
StreamSession lifecycle and SDL event loop thread.

1:1 port of Artemis Session::exec and Session::execInternal (session.cpp:2150-2580).
Reference: streaming-technical/06-phase3-session-video.md §6
"""

from __future__ import annotations

import ctypes
from ctypes import byref
import inspect
import logging
import os
import sys
import threading
import time
from typing import Any, Callable
import sdl2

from app.core.remote.limelight import (
    COLOR_RANGE_LIMITED,
    COLORSPACE_REC_601,
    api,
    build_server_info,
    build_stream_config,
    load_api,
)
from app.core.remote.limelight.api import LimelightApi
from app.core.remote.limelight.callbacks import CallbackSet, ConnectionListener
from app.core.remote.limelight.connection import LimelightConnection
from app.core.remote.limelight.errors import (
    format_connection_status_warning,
    format_stage_failed,
    format_termination_error,
    translate_stage_name,
)
from app.core.remote.models import RemoteApp, RemoteHost, StreamSettings, VideoCodec
from app.core.remote.nvhttp import NvHttpClient, NvHttpException
from app.core.remote.stream.audio.renderer import SdlAudioRenderer
from app.core.remote.stream.input.handler import SdlInputHandler
from app.core.remote.stream.stats import StatsTracker
from app.core.remote.stream.video.decoder import (
    DecoderConfig,
    PullDecoder,
    select_video_decoder,
)
from app.core.remote.stream.video.mailbox import FrameMailbox
from app.core.remote.stream.video.overlay import Overlay
from app.core.remote.stream.video.renderer import SdlVideoRenderer
from app.core.remote.stream.window import create_stream_window
from app.core.remote.stream.video import ffmpeg_api

logger = logging.getLogger(__name__)


class VideoCallbacks:
    """Video callbacks adapter providing capabilities and setup/cleanup callbacks (06 §2, Limelight.h)."""

    def __init__(self, session: StreamSession, capabilities: int) -> None:
        self.session = session
        self.capabilities = capabilities

    def setup(self, video_format: int, width: int, height: int, redraw_rate: int, context: Any, dr_flags: int) -> int:
        return self.session._dr_setup(video_format, width, height, redraw_rate, context, dr_flags)

    def cleanup(self) -> None:
        self.session._dr_cleanup()


class StreamSession:

    """Dedicated session thread owning all SDL video and event processing.

    Port of Artemis Session::exec / execInternal (session.cpp:2150-2580).
    """

    def __init__(
        self,
        connection: LimelightConnection | None = None,
        host: RemoteHost | None = None,
        app: RemoteApp | None = None,
        settings: StreamSettings | None = None,
        title: str = "Bob Remote Gaming",
        server_codec_support: int = 0x00000101,  # H264 | HEVC
        max_luma_hevc: int = 0,
        width: int | None = None,
        height: int | None = None,
        fps: int | None = None,
        window_mode: str | None = None,
        display_index: int = 0,
        on_stage_changed: Callable[[str], None] | None = None,
        on_session_started: Callable[[], None] | None = None,
        on_session_ended: Callable[..., None] | None = None,
        on_error: Callable[[Exception], None] | None = None,
        on_stage: Callable[[int], None] | None = None,
        on_focus_lost: Callable[[], None] | None = None,
        gamepad_monitor: Any | None = None,
        audio: SdlAudioRenderer | None = None,
    ) -> None:
        self._connection = connection
        self._host = host
        self._app = app
        self._settings = settings or StreamSettings()
        self._title = title
        self._api = None

        # Auto-extract from host if available
        if host and host.server_codec_mode_support:
            self._server_codec_support = host.server_codec_mode_support
        else:
            self._server_codec_support = server_codec_support

        if host and host.max_luma_pixels_hevc:
            self._max_luma_hevc = host.max_luma_pixels_hevc
        else:
            self._max_luma_hevc = max_luma_hevc

        # Auto-extract from settings if passed, else explicit arg or default
        self._width = width if width is not None else (settings.width if settings else 1920)
        self._height = height if height is not None else (settings.height if settings else 1080)
        self._fps = fps if fps is not None else (settings.fps if settings else 60)
        self._window_mode = window_mode if window_mode is not None else (settings.window_mode if settings else "borderless")
        self._display_index = display_index

        self._on_stage_changed = on_stage_changed
        self._on_session_started = on_session_started
        self._on_session_ended = on_session_ended
        self._on_error = on_error
        self._on_stage = on_stage
        self._on_focus_lost = on_focus_lost
        self._gamepad_monitor = gamepad_monitor

        if audio is not None:
            self._audio_renderer: SdlAudioRenderer | None = audio
        elif connection and getattr(connection, "callbacks", None) and getattr(connection.callbacks, "audio", None):
            self._audio_renderer = connection.callbacks.audio
        else:
            self._audio_renderer = None

        self._thread: threading.Thread | None = None
        self._quit = threading.Event()
        self._stop_requested = False

        # Registered custom SDL events
        self._ev_frame_ready: int = 0
        self._ev_conn_terminated: int = 0
        self._ev_status: int = 0
        self._ev_decoder_reset: int = 0
        self._ev_feedback: int = 0
        self._ev_renegotiated: int = 0

        # Subsystems
        self._window: ctypes.c_void_p | None = None
        self._renderer: SdlVideoRenderer | None = None
        self._overlay: Overlay | None = None
        self._decoder: PullDecoder | None = None
        self._mailbox: FrameMailbox | None = None
        self._stats: StatsTracker | None = None
        self._decoder_config: DecoderConfig | None = None
        self._input_handler: SdlInputHandler | None = None

        # Feedback queue (C threads -> SDL event loop)
        self._feedback_queue: list[tuple[str, tuple[Any, ...]]] = []
        self._feedback_lock = threading.Lock()
        self._status_toast_expiry: int = 0
        self._should_exit_app: bool = False

        # Session tracking & diagnostics (09-phase6-integration.md §7)
        self._launched_on_host: bool = False
        self._connection_started: bool = False
        self._error_message: str = ""
        self._start_time: float = 0.0
        self._idr_requests_count: int = 0
        self._zero_frame_resets: int = 0
        self._renegotiated_compat: bool = False
        self._renegotiate_in_progress: bool = False
        self._renegotiate_thread: threading.Thread | None = None
        self._renegotiate_error: str = ""

    def start(self) -> None:
        """Start the dedicated StreamSession thread."""
        self._thread = threading.Thread(target=self._run, name="StreamSession", daemon=True)
        self._thread.start()

    def request_stop(self) -> None:
        """Request clean session stop from any thread (e.g. Qt UI button).

        Pushes SDL_QUIT into the SDL event queue (thread-safe, session.cpp:2206).
        """
        self._stop_requested = True
        ev = sdl2.SDL_Event()
        ev.type = sdl2.SDL_QUIT
        sdl2.SDL_PushEvent(byref(ev))

    def interrupt(self) -> None:
        """Abort a pending connection attempt (e.g. user pressed Cancel)."""
        self._stop_requested = True
        self._quit.set()
        if self._connection:
            try:
                self._connection.interrupt()
            except Exception:
                pass
        elif getattr(self, "_api", None):
            try:
                self._api.LiInterruptConnection()
            except Exception:
                pass
        else:
            try:
                load_api().LiInterruptConnection()
            except Exception:
                pass

    @property
    def is_interrupted(self) -> bool:
        return self._stop_requested

    @property
    def is_alive(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def join(self, timeout: float | None = None) -> None:
        """Wait for the session thread to finish."""
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=timeout)

    def _push_user_event(self, event_type: int, code: int = 0) -> int:
        """Thread-safe event dispatch into the SDL event queue.

        Returns 1 on success, 0 on failure/queue full, or negative on error (SDL_PushEvent).
        """
        ev = sdl2.SDL_Event()
        ev.type = event_type
        ev.user.code = code
        return int(sdl2.SDL_PushEvent(byref(ev)))

    def on_frame_ready(self) -> None:
        """Called by PullDecoder when a frame is published in mailbox."""
        if self._ev_frame_ready:
            rc = self._push_user_event(self._ev_frame_ready)
            if rc <= 0:
                logger.warning(
                    f"[Session] SDL_PushEvent(EV_FRAME_READY) failed (rc={rc}); resetting pending_event"
                )
                if self._mailbox:
                    self._mailbox.reset_pending_event()

    def on_decoder_reset_needed(self) -> None:
        """Called by PullDecoder when consecutive decode errors exceed threshold."""
        if self._ev_decoder_reset:
            self._push_user_event(self._ev_decoder_reset)

    def _dr_setup(
        self,
        video_format: int,
        width: int,
        height: int,
        redraw_rate: int,
        context: Any,
        dr_flags: int,
    ) -> int:
        logger.info(
            f"[Session] dr.setup: format=0x{video_format:04X}, {width}x{height}@{redraw_rate}fps, flags=0x{dr_flags:X}"
        )
        self._width = width
        self._height = height
        self._fps = redraw_rate
        # If decoder was already instantiated and format or size changed, recreate it (06 §2, Part 2 Item 13)
        if self._decoder_config and (
            self._decoder_config.video_format != video_format
            or self._decoder_config.width != width
            or self._decoder_config.height != height
        ):
            logger.info(
                f"[Session] Format or resolution changed in dr.setup (0x{self._decoder_config.video_format:04X} -> 0x{video_format:04X}, "
                f"{self._decoder_config.width}x{self._decoder_config.height} -> {width}x{height})"
            )
            if self._decoder_config.video_format != video_format:
                negotiated_codec = VideoCodec.H264 if video_format == api.VIDEO_FORMAT_H264 else (
                    VideoCodec.HEVC if video_format == api.VIDEO_FORMAT_H265 else VideoCodec.AV1
                )
                settings_copy = StreamSettings(**self._settings.__dict__) if hasattr(self._settings, "__dict__") else self._settings
                settings_copy.codec = negotiated_codec
                self._decoder_config = select_video_decoder(
                    settings=settings_copy,
                    server_codec_support=video_format,
                    max_luma_hevc=self._max_luma_hevc,
                    width=width,
                    height=height,
                    fps=redraw_rate,
                )
            else:
                self._decoder_config.width = width
                self._decoder_config.height = height
                self._decoder_config.fps = redraw_rate

            if self._decoder:
                self._decoder.stop()
                if self._mailbox and self._stats and self._connection:
                    self._decoder = PullDecoder(
                        config=self._decoder_config,
                        width=self._width,
                        height=self._height,
                        mailbox=self._mailbox,
                        stats=self._stats,
                        on_reset_needed=self.on_decoder_reset_needed,
                        on_frame_ready=self.on_frame_ready,
                        api_inst=self._connection.api,
                    )
                    self._decoder.start()
        return 0

    def _dr_cleanup(self) -> None:
        logger.info("[Session] dr.cleanup invoked")
        if self._decoder:
            self._decoder.stop()
            self._decoder = None

    def _build_callback_set(self, api_inst: LimelightApi, listener: Any) -> CallbackSet:
        caps = self._decoder_config.capabilities if self._decoder_config else (0x20 | 0x04 | 0x40)
        video_callbacks = VideoCallbacks(session=self, capabilities=caps)
        return CallbackSet(
            api=api_inst,
            listener=listener,
            video=video_callbacks,
            audio=self._audio_renderer,
        )


    @property
    def input_handler(self) -> SdlInputHandler | None:
        return self._input_handler

    @property
    def audio_renderer(self) -> SdlAudioRenderer | None:
        return self._audio_renderer

    @property
    def should_exit_app(self) -> bool:
        return self._should_exit_app

    def toggle_fullscreen(self) -> None:
        """Toggle between borderless fullscreen and windowed (session.cpp:1619-1662)."""
        if not self._window:
            return
        flags = sdl2.SDL_GetWindowFlags(self._window)
        is_fs = bool(flags & (sdl2.SDL_WINDOW_FULLSCREEN | sdl2.SDL_WINDOW_FULLSCREEN_DESKTOP))
        if is_fs:
            sdl2.SDL_SetWindowFullscreen(self._window, 0)
        else:
            sdl2.SDL_SetWindowFullscreen(self._window, sdl2.SDL_WINDOW_FULLSCREEN_DESKTOP)
        if self._renderer:
            self._renderer.on_window_changed()
        if self._input_handler:
            self._input_handler.update_keyboard_grab_state()
            self._input_handler.update_pointer_region_lock()

    def toggle_overlay(self) -> bool:
        """Toggle debug stats overlay visibility."""
        if self._overlay:
            return self._overlay.toggle_debug()
        return False

    def _on_quit_and_exit(self) -> None:
        """Quit stream and signal app exit (KeyComboQuitAndExit)."""
        self._should_exit_app = True
        self.request_stop()

    def on_rumble(self, controller_number: int, low_freq: int, high_freq: int) -> None:
        """Called by connection listener when host requests controller rumble."""
        with self._feedback_lock:
            self._feedback_queue.append(("rumble", (controller_number, low_freq, high_freq)))
        if self._ev_feedback:
            self._push_user_event(self._ev_feedback)

    def on_rumble_triggers(self, controller_number: int, left: int, right: int) -> None:
        """Called by connection listener when host requests trigger rumble."""
        with self._feedback_lock:
            self._feedback_queue.append(("rumble_triggers", (controller_number, left, right)))
        if self._ev_feedback:
            self._push_user_event(self._ev_feedback)

    def on_set_motion_event_state(
        self, controller_number: int, motion_type: int, report_rate_hz: int
    ) -> None:
        """Called by connection listener when host configures motion sensors."""
        with self._feedback_lock:
            self._feedback_queue.append(("motion", (controller_number, motion_type, report_rate_hz)))
        if self._ev_feedback:
            self._push_user_event(self._ev_feedback)

    def on_set_controller_led(self, controller_number: int, r: int, g: int, b: int) -> None:
        """Called by connection listener when host configures controller LED."""
        with self._feedback_lock:
            self._feedback_queue.append(("led", (controller_number, r, g, b)))
        if self._ev_feedback:
            self._push_user_event(self._ev_feedback)

    def on_connection_status(self, status: int) -> None:
        """Called by Limelight callback when network status changes."""
        if self._ev_status:
            self._push_user_event(self._ev_status, code=status)

    def on_connection_terminated(self, error_code: int) -> None:
        """Called by Limelight callback when the host or library terminates stream."""
        if not self._error_message and error_code != 0:
            try:
                api_inst = load_api()
                port_flags = api_inst.LiGetPortFlagsFromTerminationErrorCode(error_code)
                failing_ports = ""
                if port_flags != 0:
                    buf = ctypes.create_string_buffer(128)
                    api_inst.LiStringifyPortFlags(port_flags, b", ", buf, ctypes.sizeof(buf))
                    failing_ports = buf.value.decode("utf-8", "replace")
                self._error_message = format_termination_error(error_code, failing_ports)
            except Exception:
                self._error_message = format_termination_error(error_code)
        if self._ev_conn_terminated:
            self._push_user_event(self._ev_conn_terminated, code=error_code)

    def _make_conn_listener(self, api_inst: LimelightApi, report_stages: bool = True) -> ConnectionListener:
        """Create a ConnectionListener forwarding C callbacks into this StreamSession."""
        session_ref = self

        class SessionConnListener(ConnectionListener):
            def on_stage_starting(self, stage: int) -> None:
                if not report_stages:
                    return
                try:
                    raw_name = api_inst.LiGetStageName(stage)
                    stage_name = raw_name.decode("utf-8", "replace") if raw_name else ""
                except Exception:
                    stage_name = ""
                stage_vi = translate_stage_name(stage_name)
                if session_ref._on_stage_changed:
                    session_ref._on_stage_changed(f"Đang kết nối: {stage_vi}...")
                if session_ref._on_stage:
                    session_ref._on_stage(stage)

            def on_stage_failed(self, stage: int, error_code: int) -> None:
                try:
                    raw_name = api_inst.LiGetStageName(stage)
                    stage_name = raw_name.decode("utf-8", "replace") if raw_name else ""
                    port_flags = api_inst.LiGetPortFlagsFromStage(stage)
                    failing_ports = ""
                    if port_flags != 0:
                        buf = ctypes.create_string_buffer(128)
                        api_inst.LiStringifyPortFlags(port_flags, b", ", buf, ctypes.sizeof(buf))
                        failing_ports = buf.value.decode("utf-8", "replace")
                except Exception:
                    stage_name = ""
                    failing_ports = ""
                session_ref._error_message = format_stage_failed(stage_name, error_code, failing_ports)
                logger.error(f"[Session] Stage {stage} failed: {session_ref._error_message}")

            def on_connection_status_update(self, status: int) -> None:
                session_ref.on_connection_status(status)

            def on_connection_terminated(self, error_code: int) -> None:
                try:
                    port_flags = api_inst.LiGetPortFlagsFromTerminationErrorCode(error_code)
                    failing_ports = ""
                    if port_flags != 0:
                        buf = ctypes.create_string_buffer(128)
                        api_inst.LiStringifyPortFlags(port_flags, b", ", buf, ctypes.sizeof(buf))
                        failing_ports = buf.value.decode("utf-8", "replace")
                except Exception:
                    failing_ports = ""
                session_ref._error_message = format_termination_error(error_code, failing_ports)
                session_ref.on_connection_terminated(error_code)

            def on_rumble(self, controller_number: int, low_freq: int, high_freq: int) -> None:
                session_ref.on_rumble(controller_number, low_freq, high_freq)

            def on_rumble_triggers(self, controller_number: int, left: int, right: int) -> None:
                session_ref.on_rumble_triggers(controller_number, left, right)

            def on_set_motion_event_state(
                self, controller_number: int, motion_type: int, report_rate_hz: int
            ) -> None:
                session_ref.on_set_motion_event_state(controller_number, motion_type, report_rate_hz)

            def on_set_controller_led(self, controller_number: int, r: int, g: int, b: int) -> None:
                session_ref.on_set_controller_led(controller_number, r, g, b)

        return SessionConnListener()

    def _build_compat_settings(self) -> StreamSettings:
        """Build an in-memory H.264 compatibility profile without mutating saved user settings."""
        compat = StreamSettings.from_dict(self._settings.to_dict())
        compat.codec = VideoCodec.H264
        compat.hdr = False
        compat.enable_fractional_fps = False
        if compat.width > 1920 or compat.height > 1200:
            compat.width = 1920
            compat.height = 1080
        if compat.fps > 60:
            compat.fps = 60
        if compat.bitrate_kbps > 20000:
            compat.bitrate_kbps = 20000
        return compat

    def _perform_nvhttp_launch_or_resume(
        self,
        client: NvHttpClient,
        stream_params: Any = None,
        settings_override: StreamSettings | None = None,
        force_relaunch_desktop: bool = False,
    ) -> str:
        """Launch or resume the app on the host, handling 400 'already running' gracefully."""
        if not self._app:
            return ""

        from app.core.remote.stream.input.gamepad import SdlGamepadHandler

        active_settings = settings_override or self._settings
        gamepad_mask = SdlGamepadHandler.get_attached_gamepad_mask(
            getattr(active_settings, "multi_controller", True)
        )

        is_desktop = self._app.id == 881448767 or self._app.title.strip().lower() == "desktop"
        if force_relaunch_desktop and is_desktop:
            logger.info("[Session] Resetting Desktop stream session on host for compatibility renegotiation...")
            client.quit_app()
            time.sleep(0.25)
            is_running = False
        else:
            is_running = (
                self._launched_on_host
                or self._app.is_running
                or (self._host and self._host.current_game_id == self._app.id)
                or (self._host and self._host.current_game_id != 0 and self._app.id == 881448767)
            )

        if is_running:
            try:
                logger.info(f"[Session] App {self._app.title} is running; attempting /resume...")
                session_url = client.resume_app(self._app, active_settings, stream_params, gamepad_mask=gamepad_mask)
                self._launched_on_host = False
                return session_url
            except Exception as resume_err:
                logger.warning(f"[Session] Resume failed ({resume_err}); attempting fresh /launch...")
                session_url = client.launch_app(self._app, active_settings, stream_params, gamepad_mask=gamepad_mask)
                self._launched_on_host = True
                return session_url
        else:
            try:
                host_name = self._host.hostname if self._host else "remote host"
                logger.info(f"[Session] Launching app {self._app.title} on {host_name}...")
                session_url = client.launch_app(self._app, active_settings, stream_params, gamepad_mask=gamepad_mask)
                self._launched_on_host = True
                return session_url
            except NvHttpException as launch_err:
                err_str = str(launch_err).lower()
                if launch_err.status_code == 400 or "already running" in err_str:
                    logger.info("[Session] Host reports already running; attempting /resume...")
                    try:
                        session_url = client.resume_app(self._app, active_settings, stream_params, gamepad_mask=gamepad_mask)
                        self._launched_on_host = False
                        self._app.is_running = True
                        return session_url
                    except Exception as resume_err:
                        logger.info(
                            f"[Session] Resume failed ({resume_err}). Quitting stale running app on host and re-launching {self._app.title}..."
                        )
                        client.quit_app()
                        time.sleep(1.0)
                        session_url = client.launch_app(self._app, active_settings, stream_params, gamepad_mask=gamepad_mask)
                        self._launched_on_host = True
                        return session_url
                else:
                    raise

    def _renegotiate_worker(self) -> None:
        """Background worker that renegotiates the host stream into a safe H.264 compatibility profile."""
        t0 = time.monotonic()
        try:
            if self._connection is not None:
                logger.info("[Session] Stopping incompatible stream connection before H.264 renegotiation...")
                self._connection.stop()
                self._connection = None
            if self._stop_requested or self._host is None or self._app is None:
                return
            time.sleep(0.25)
            if self._stop_requested:
                return

            api_inst = load_api()
            compat_settings = self._build_compat_settings()
            compat_cfg = select_video_decoder(
                compat_settings,
                server_codec_support=api.SCM_H264,
                max_luma_hevc=0,
                width=compat_settings.width,
                height=compat_settings.height,
                fps=compat_settings.fps,
            )
            self._decoder_config = compat_cfg
            self._width = compat_cfg.width
            self._height = compat_cfg.height
            self._fps = compat_cfg.fps

            stream_params = build_stream_config(
                api_inst,
                compat_settings,
                compat_cfg.video_format,
                COLORSPACE_REC_601,
                COLOR_RANGE_LIMITED,
            )

            with NvHttpClient(
                self._host.ip,
                self._host.port,
                self._host.https_port,
                self._host.server_cert_pem,
            ) as client:
                session_url = self._perform_nvhttp_launch_or_resume(
                    client,
                    stream_params,
                    settings_override=compat_settings,
                    force_relaunch_desktop=True,
                )

            if self._stop_requested:
                return

            server_info, server_info_keep = build_server_info(api_inst, self._host, session_url)
            listener = self._make_conn_listener(api_inst, report_stages=False)
            cbs = self._build_callback_set(api_inst, listener)
            new_conn = LimelightConnection(
                api=api_inst,
                server_info=server_info,
                server_info_keep=server_info_keep,
                stream_params=stream_params,
                callback_set=cbs,
            )
            new_conn.start()
            self._connection = new_conn
            elapsed_ms = (time.monotonic() - t0) * 1000.0
            logger.info(
                f"[Session] H.264 compatibility renegotiation succeeded in {elapsed_ms:.0f}ms "
                f"({self._width}x{self._height}@{self._fps}fps, {compat_settings.bitrate_kbps}kbps, "
                f"dec={compat_cfg.decoder_name}, hw={compat_cfg.hw_device_type_name})"
            )
            if self._ev_renegotiated:
                self._push_user_event(self._ev_renegotiated, code=0)
        except Exception as exc:
            self._renegotiate_error = str(exc)
            logger.error(f"[Session] H.264 compatibility renegotiation failed: {exc}", exc_info=True)
            if self._ev_renegotiated and not self._stop_requested:
                self._push_user_event(self._ev_renegotiated, code=-1)

    def _cleanup_teardown(self, term_code: int) -> None:
        """Clean up remote app on host if aborted, quit requested via Ctrl+Alt+Shift+E, or quit_app_after (09 §1, Artemis session.cpp:1366-1394)."""
        if self._should_exit_app and self._host:
            try:
                with NvHttpClient(
                    self._host.ip,
                    self._host.port,
                    self._host.https_port,
                    self._host.server_cert_pem,
                ) as client:
                    logger.info("[Session] Quitting remote app on host per exit request (Ctrl+Alt+Shift+E)...")
                    client.quit_app()
            except Exception as e:
                logger.debug(f"[Session] Error quitting remote app on exit request: {e}")
        elif not self._connection_started and self._launched_on_host and self._host:
            try:
                with NvHttpClient(
                    self._host.ip,
                    self._host.port,
                    self._host.https_port,
                    self._host.server_cert_pem,
                ) as client:
                    logger.info("[Session] Cancelling aborted stream session on host...")
                    client.quit_app()
            except Exception as cleanup_err:
                logger.debug(f"[Session] Failed to clean up aborted session on host: {cleanup_err}")
        elif self._connection_started and term_code == 0 and self._host:
            quit_after = getattr(self._settings, "quit_app_after", False)
            if quit_after:
                try:
                    with NvHttpClient(
                        self._host.ip,
                        self._host.port,
                        self._host.https_port,
                        self._host.server_cert_pem,
                    ) as client:
                        logger.info("[Session] Quitting remote app on host per quit_app_after...")
                        client.quit_app()
                except Exception as e:
                    logger.debug(f"[Session] Error quitting remote app: {e}")

    def _handle_sdl_event(self, ev: sdl2.SDL_Event) -> tuple[bool, int]:
        """Dispatch a single SDL event. Returns (should_break, term_code)."""
        # Independent toast expiry check before event dispatch (Part 1 Item 8)
        if self._status_toast_expiry and sdl2.SDL_GetTicks() >= self._status_toast_expiry:
            if self._overlay and self._overlay._status_text.startswith(("Ctrl+Alt+Shift+Q", "Đã tự động chuyển")):
                self._overlay.set_status_text("")
            self._status_toast_expiry = 0

        if ev.type == sdl2.SDL_QUIT:
            logger.info("[Session] SDL_QUIT received; exiting loop")
            if self._renegotiate_in_progress:
                try:
                    load_api().LiInterruptConnection()
                except Exception:
                    pass
            return True, 0

        elif ev.type == self._ev_frame_ready:
            if self._renderer and self._mailbox:
                frame = self._mailbox.take()
                if frame:
                    self._renderer.render(frame)

        elif ev.type == self._ev_conn_terminated:
            if self._renegotiate_in_progress:
                return False, 0
            term_code = ev.user.code
            logger.info(f"[Session] Connection terminated event received (code={term_code})")
            return True, term_code

        elif ev.type == self._ev_status:
            status_val = ev.user.code
            bitrate_kbps = getattr(self._settings, "bitrate_kbps", 10000)
            warning_text = format_connection_status_warning(status_val, bitrate_kbps)
            if self._overlay:
                self._overlay.set_status_text(warning_text)

        elif ev.type and ev.type == self._ev_renegotiated:
            self._renegotiate_in_progress = False
            if ev.user.code != 0:
                self._error_message = (
                    self._renegotiate_error or "Không thể chuyển sang chế độ tương thích H.264"
                )
                logger.error(f"[Session] Renegotiation event failed: {self._error_message}")
                return True, -1

            if self._stats and self._decoder_config:
                self._stats.width = self._width
                self._stats.height = self._height
                self._stats.video_format = self._decoder_config.video_format
                self._stats._last_frame_number = None
            if self._input_handler:
                self._input_handler.stream_width = self._width
                self._input_handler.stream_height = self._height
                self._input_handler.mouse.stream_width = self._width
                self._input_handler.mouse.stream_height = self._height
                self._input_handler.update_pointer_region_lock()
            if self._renderer:
                self._renderer.on_window_changed()
            if self._decoder_config and self._mailbox and self._stats:
                self._decoder = PullDecoder(
                    config=self._decoder_config,
                    width=self._width,
                    height=self._height,
                    mailbox=self._mailbox,
                    stats=self._stats,
                    on_reset_needed=self.on_decoder_reset_needed,
                    on_frame_ready=self.on_frame_ready,
                    api_inst=self._connection.api if self._connection else None,
                )
                self._decoder.start()
            if self._connection and self._connection.api:
                self._connection.api.LiRequestIdrFrame()
            if self._overlay:
                self._overlay.set_status_text("Đã tự động chuyển sang H.264 tương thích")
                self._status_toast_expiry = sdl2.SDL_GetTicks() + 4000

        elif ev.type in (
            self._ev_decoder_reset,
            sdl2.SDL_RENDER_DEVICE_RESET,
            sdl2.SDL_RENDER_TARGETS_RESET,
        ):
            if self._renegotiate_in_progress:
                return False, 0
            event_name = (
                "EV_DECODER_RESET"
                if ev.type == self._ev_decoder_reset
                else (
                    "SDL_RENDER_DEVICE_RESET"
                    if ev.type == sdl2.SDL_RENDER_DEVICE_RESET
                    else "SDL_RENDER_TARGETS_RESET"
                )
            )
            logger.warning(
                f"[Session] {event_name} received; resetting renderer resources and recreating decoder"
            )
            raw_presented = getattr(self._decoder, "frames_presented", 0) if self._decoder else 0
            prev_presented = raw_presented if isinstance(raw_presented, int) else 0
            if self._renderer and hasattr(self._renderer, "on_device_reset"):
                self._renderer.on_device_reset()
            if self._decoder:
                self._decoder.stop()
                self._decoder = None

            if (
                ev.type == self._ev_decoder_reset
                and self._decoder_config is not None
                and prev_presented == 0
            ):
                self._zero_frame_resets += 1
                if (
                    self._decoder_config.is_hardware
                    and getattr(self._settings, "video_decoder", "AUTO").upper() != "FORCE_HARDWARE"
                ):
                    prev_hw = self._decoder_config.hw_device_type_name
                    self._decoder_config.hw_device_type_name = None
                    if self._decoder_config.video_format == api.VIDEO_FORMAT_AV1_MAIN8:
                        self._decoder_config.decoder_name = "libdav1d"
                    slices = min(4, os.cpu_count() or 1)
                    self._decoder_config.capabilities = (
                        api.CAPABILITY_PULL_RENDERER
                        | api.CAPABILITY_REFERENCE_FRAME_INVALIDATION_HEVC
                        | api.CAPABILITY_REFERENCE_FRAME_INVALIDATION_AV1
                        | api.CAPABILITY_SLICES_PER_FRAME(slices)
                    )
                    logger.warning(
                        f"[Session] Hardware decoder ({prev_hw}) produced 0 frames before reset; "
                        f"falling back to software decoder ({self._decoder_config.decoder_name})"
                    )
                elif (
                    not self._renegotiated_compat
                    and self._host is not None
                    and self._app is not None
                ):
                    self._renegotiated_compat = True
                    self._renegotiate_in_progress = True
                    logger.warning(
                        "[Session] Host bitstream failed hardware and software decode (0 frames presented); "
                        "renegotiating compatible H.264 stream..."
                    )
                    if self._overlay:
                        self._overlay.set_status_text("Đang chuyển sang chế độ tương thích (H.264)...")
                        self._status_toast_expiry = 0
                    self._renegotiate_thread = threading.Thread(
                        target=self._renegotiate_worker,
                        name="StreamRenegotiate",
                        daemon=True,
                    )
                    self._renegotiate_thread.start()
                    return False, 0
                elif self._zero_frame_resets >= 4:
                    self._error_message = (
                        "Máy chủ không thể mã hóa luồng hình ảnh hợp lệ (kể cả ở chế độ tương thích H.264). "
                        "Hãy kiểm tra cấu hình encoder trên Sunshine/Steam Deck."
                    )
                    logger.error(
                        f"[Session] Aborting stream after {self._zero_frame_resets} consecutive 0-frame decoder resets"
                    )
                    return True, -1
            elif prev_presented > 0:
                self._zero_frame_resets = 0

            if self._decoder_config and self._mailbox and self._stats:
                try:
                    self._decoder = PullDecoder(
                        config=self._decoder_config,
                        width=self._width,
                        height=self._height,
                        mailbox=self._mailbox,
                        stats=self._stats,
                        on_reset_needed=self.on_decoder_reset_needed,
                        on_frame_ready=self.on_frame_ready,
                        api_inst=self._connection.api if self._connection else None,
                    )
                except Exception as exc:
                    if (
                        self._decoder_config.is_hardware
                        and getattr(self._settings, "video_decoder", "AUTO").upper() != "FORCE_HARDWARE"
                    ):
                        logger.warning(
                            f"[Session] Hardware decoder recreation failed ({exc}); falling back to software"
                        )
                        self._decoder_config.hw_device_type_name = None
                        if self._decoder_config.video_format == api.VIDEO_FORMAT_AV1_MAIN8:
                            self._decoder_config.decoder_name = "libdav1d"
                        self._decoder = PullDecoder(
                            config=self._decoder_config,
                            width=self._width,
                            height=self._height,
                            mailbox=self._mailbox,
                            stats=self._stats,
                            on_reset_needed=self.on_decoder_reset_needed,
                            on_frame_ready=self.on_frame_ready,
                            api_inst=self._connection.api if self._connection else None,
                        )
                    else:
                        raise
                self._decoder.start()
            if self._connection and self._connection.api:
                self._connection.api.LiRequestIdrFrame()

        elif ev.type == self._ev_feedback:
            with self._feedback_lock:
                queued = list(self._feedback_queue)
                self._feedback_queue.clear()
            for cmd, args in queued:
                if self._input_handler:
                    if cmd == "rumble":
                        self._input_handler.rumble(*args)
                    elif cmd == "rumble_triggers":
                        self._input_handler.rumble_triggers(*args)
                    elif cmd == "motion":
                        self._input_handler.set_motion_event_state(*args)
                    elif cmd == "led":
                        self._input_handler.set_controller_led(*args)

        elif ev.type in (sdl2.SDL_KEYDOWN, sdl2.SDL_KEYUP):
            if self._input_handler:
                self._input_handler.handle_key_event(ev.key)

        elif ev.type in (sdl2.SDL_MOUSEBUTTONDOWN, sdl2.SDL_MOUSEBUTTONUP):
            if self._input_handler:
                self._input_handler.handle_mouse_button_event(ev.button)

        elif ev.type == sdl2.SDL_MOUSEMOTION:
            if self._input_handler:
                self._input_handler.handle_mouse_motion_event(ev.motion)

        elif ev.type == sdl2.SDL_MOUSEWHEEL:
            if self._input_handler:
                self._input_handler.handle_mouse_wheel_event(ev.wheel)

        elif ev.type == sdl2.SDL_CONTROLLERAXISMOTION:
            if self._input_handler:
                self._input_handler.handle_controller_axis_event(ev.caxis)

        elif ev.type in (sdl2.SDL_CONTROLLERBUTTONDOWN, sdl2.SDL_CONTROLLERBUTTONUP):
            if self._input_handler:
                self._input_handler.handle_controller_button_event(ev.cbutton)

        elif ev.type in (sdl2.SDL_CONTROLLERDEVICEADDED, sdl2.SDL_CONTROLLERDEVICEREMOVED):
            if self._input_handler:
                self._input_handler.handle_controller_device_event(ev.cdevice)

        elif ev.type == sdl2.SDL_WINDOWEVENT:
            win_event = ev.window.event
            if win_event == sdl2.SDL_WINDOWEVENT_FOCUS_LOST:
                # Artemis session.cpp:2254-2258: mute on focus loss
                if getattr(self._settings, "mute_on_focus_loss", False) and self._audio_renderer:
                    self._audio_renderer.muted = True
                if self._input_handler:
                    self._input_handler.notify_focus_lost()
                if self._on_focus_lost:
                    try:
                        self._on_focus_lost()
                    except Exception:
                        pass
            elif win_event == sdl2.SDL_WINDOWEVENT_FOCUS_GAINED:
                # Artemis session.cpp:2265-2268: unmute on focus gained
                if getattr(self._settings, "mute_on_focus_loss", False) and self._audio_renderer:
                    self._audio_renderer.muted = False
            elif win_event == sdl2.SDL_WINDOWEVENT_LEAVE:
                if self._input_handler:
                    self._input_handler.notify_mouse_leave()
            elif win_event in (
                sdl2.SDL_WINDOWEVENT_SIZE_CHANGED,
                sdl2.SDL_WINDOWEVENT_DISPLAY_CHANGED,
            ):
                if self._renderer:
                    self._renderer.on_window_changed()
                if self._input_handler:
                    self._input_handler.update_pointer_region_lock()

        return False, 0

    def _run(self) -> None:
        """StreamSession thread procedure (session.cpp:2150-2580)."""
        logger.info("[Session] StreamSession thread starting")
        orig_switch = sys.getswitchinterval()
        self._start_time = time.monotonic()
        term_code = 0

        try:
            # 0. Ensure FFmpeg DLLs loaded (Part A Item B1)
            ffmpeg_api.ensure_ffmpeg_loaded()

            # 1. Pause GamepadMonitor & reduce GIL switch interval (session.cpp / 02 §3)
            if self._gamepad_monitor and hasattr(self._gamepad_monitor, "pause"):
                try:
                    self._gamepad_monitor.pause(timeout=0.250)
                except Exception as e:
                    logger.warning(f"[Session] Failed to pause GamepadMonitor: {e}")

            sys.setswitchinterval(0.001)

            # 2. Set SDL hints (06-phase3-session-video.md §6.2)
            override = getattr(sdl2, "SDL_HINT_OVERRIDE", 2)
            sdl2.SDL_SetHint(sdl2.SDL_HINT_TIMER_RESOLUTION, b"1")
            sdl2.SDL_SetHint(sdl2.SDL_HINT_VIDEO_MINIMIZE_ON_FOCUS_LOSS, b"0")
            sdl2.SDL_SetHint(b"SDL_MOUSE_RELATIVE_SCALING", b"0")
            sdl2.SDL_SetHint(b"SDL_MOUSE_AUTO_CAPTURE", b"0")
            sdl2.SDL_SetHint(b"SDL_MOUSE_FOCUS_CLICKTHROUGH", b"1")
            sdl2.SDL_SetHint(b"SDL_ALLOW_ALT_TAB_WHILE_GRABBED", b"0")
            sdl2.SDL_SetHint(sdl2.SDL_HINT_GAMECONTROLLER_USE_BUTTON_LABELS, b"0")
            sdl2.SDL_SetHint(b"SDL_JOYSTICK_HIDAPI_PS4_RUMBLE", b"1")
            sdl2.SDL_SetHint(b"SDL_JOYSTICK_HIDAPI_PS5_RUMBLE", b"1")

            bg_gp = b"1" if getattr(self._settings, "background_gamepad", False) else b"0"
            sdl2.SDL_SetHintWithPriority(b"SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", bg_gp, override)
            sdl2.SDL_SetHint(sdl2.SDL_HINT_RENDER_SCALE_QUALITY, b"1")
            sdl2.SDL_SetHint(sdl2.SDL_HINT_RENDER_DRIVER, b"direct3d11")

            # 3. SDL Init SubSystem and register custom events
            # Audio is initialized independently by SdlAudioRenderer (non-fatal, review round 2 item B4)
            if sdl2.SDL_InitSubSystem(sdl2.SDL_INIT_VIDEO | sdl2.SDL_INIT_GAMECONTROLLER) != 0:
                raise RuntimeError(f"SDL_InitSubSystem failed: {sdl2.SDL_GetError()}")

            base_ev = sdl2.SDL_RegisterEvents(6)
            if base_ev == 0xFFFFFFFF or base_ev < 0:
                base_ev = sdl2.SDL_USEREVENT
            self._ev_frame_ready = base_ev + 0
            self._ev_conn_terminated = base_ev + 1
            self._ev_status = base_ev + 2
            self._ev_decoder_reset = base_ev + 3
            self._ev_feedback = base_ev + 4
            self._ev_renegotiated = base_ev + 5

            # 4. Probe decoders and pick best codec / decoder
            self._decoder_config = select_video_decoder(
                self._settings,
                server_codec_support=self._server_codec_support,
                max_luma_hevc=self._max_luma_hevc,
                width=self._width,
                height=self._height,
                fps=self._fps,
            )

            # 4.5 NVHTTP launch/resume on session thread before LiStartConnection (09-phase6-integration.md §1)
            if self._stop_requested:
                logger.info("[Session] Stop requested before launch; aborting")
                return

            api_inst = load_api()
            if self._connection is None:
                if self._host is None or self._app is None:
                    raise RuntimeError("Either connection or both host and app must be provided to StreamSession")

                if self._stop_requested:
                    logger.info("[Session] Stop requested before launch; aborting")
                    return

                if self._on_stage_changed:
                    self._on_stage_changed("Đang kết nối tới máy chủ...")

                logger.info(f"[Session] Connecting to host {self._host.hostname} ({self._host.ip})...")
                stream_params = build_stream_config(
                    api_inst,
                    self._settings,
                    self._decoder_config.video_format,
                    COLORSPACE_REC_601,
                    COLOR_RANGE_LIMITED,
                )

                session_url = ""
                with NvHttpClient(
                    self._host.ip,
                    self._host.port,
                    self._host.https_port,
                    self._host.server_cert_pem,
                ) as client:
                    session_url = self._perform_nvhttp_launch_or_resume(client, stream_params)

                logger.info(f"[Session] RTSP Session URL: {session_url}")
                server_info, server_info_keep = build_server_info(api_inst, self._host, session_url)
                listener = self._make_conn_listener(api_inst, report_stages=True)
                if self._audio_renderer is None:
                    try:
                        self._audio_renderer = SdlAudioRenderer(
                            api=api_inst,
                            channels=self._settings.audio_channels,
                            sample_rate=48000,
                        )
                        logger.info(
                            f"[Session] SdlAudioRenderer initialized (channels={self._settings.audio_channels}, 48kHz)"
                        )
                    except Exception as audio_err:
                        logger.error(f"[Session] Failed to init SdlAudioRenderer: {audio_err}", exc_info=True)

                cbs = self._build_callback_set(api_inst, listener)
                self._connection = LimelightConnection(
                    api=api_inst,
                    server_info=server_info,
                    server_info_keep=server_info_keep,
                    stream_params=stream_params,
                    callback_set=cbs,
                )

            # Check if stop was requested while launching / negotiating
            if self._stop_requested:
                logger.info("[Session] Stop requested before connection.start(); aborting")
                return

            # 5. Start Limelight connection on this thread (blocks for seconds, no window yet)
            logger.info("[Session] Starting Limelight connection...")
            self._connection.start()
            self._connection_started = True
            logger.info("[Session] Limelight connection established")

            # 6. Create window, renderer, overlay, decoder
            self._window, display_hz, enable_vsync = create_stream_window(
                title=self._title,
                stream_w=self._width,
                stream_h=self._height,
                fps=self._fps,
                window_mode=self._window_mode,
                display_index=self._display_index,
                vsync=getattr(self._settings, "vsync", True),
            )

            sdl2.SDL_StopTextInput()
            if getattr(self._settings, "keep_awake", True):
                sdl2.SDL_DisableScreenSaver()
            sdl2.SDL_RaiseWindow(self._window)

            self._mailbox = FrameMailbox(pool_size=3)

            def on_stats_text(text: str) -> None:
                if self._overlay:
                    self._overlay.set_debug_text(text)

            self._stats = StatsTracker(
                width=self._width,
                height=self._height,
                video_format=self._decoder_config.video_format,
                on_overlay_text_updated=on_stats_text,
            )

            self._overlay = Overlay(
                self._window,
                initial_debug_enabled=getattr(self._settings, "show_performance_overlay", False),
            )

            self._renderer = SdlVideoRenderer(
                window=self._window,
                mailbox=self._mailbox,
                stats=self._stats,
                overlay=self._overlay,
                vsync=enable_vsync,
            )

            self._decoder = PullDecoder(
                config=self._decoder_config,
                width=self._width,
                height=self._height,
                mailbox=self._mailbox,
                stats=self._stats,
                on_reset_needed=self.on_decoder_reset_needed,
                on_frame_ready=self.on_frame_ready,
                api_inst=self._connection.api,
            )
            self._decoder.start()

            # Initialize input handler and open connected gamepads (session.cpp:2160-2170)
            self._input_handler = SdlInputHandler(
                api_inst=self._connection.api,
                stream_width=self._width,
                stream_height=self._height,
                settings=self._settings,
                on_quit=self.request_stop,
                on_toggle_fullscreen=self.toggle_fullscreen,
                on_toggle_stats=self.toggle_overlay,
                on_paste_text=None,
                on_quit_and_exit=self._on_quit_and_exit,
            )
            self._input_handler.set_window(self._window)
            self._input_handler.open_connected_gamepads()

            # Initial mouse capture (mouse.cpp:15-28, session.cpp:2441-2444)
            self._input_handler.set_capture_active(True)

            # Show initial 5-second shortcut toast (07-phase4-input.md §2.3)
            if self._overlay:
                self._overlay.set_status_text("Ctrl+Alt+Shift+Q: thoát · Z: nhả chuột/bàn phím · S: thống kê")
                self._status_toast_expiry = sdl2.SDL_GetTicks() + 5000

            if self._on_session_started:
                try:
                    self._on_session_started()
                except Exception as e:
                    logger.warning(f"[Session] on_session_started callback failed: {e}")

            # 7. Main SDL event loop (session.cpp:2172-2512)
            ev = sdl2.SDL_Event()
            while not self._quit.is_set():
                if not sdl2.SDL_WaitEventTimeout(byref(ev), 1000):
                    if self._status_toast_expiry and sdl2.SDL_GetTicks() >= self._status_toast_expiry:
                        if self._overlay and self._overlay._status_text.startswith(("Ctrl+Alt+Shift+Q", "Đã tự động chuyển")):
                            self._overlay.set_status_text("")
                        self._status_toast_expiry = 0
                    continue

                should_break, code = self._handle_sdl_event(ev)
                if should_break:
                    term_code = code
                    break

        except Exception as exc:
            logger.exception(f"[Session] Error during streaming session: {exc}")
            if not self._error_message:
                self._error_message = str(exc)
            if self._on_error:
                try:
                    self._on_error(exc)
                except Exception:
                    pass
        finally:
            # 8. Teardown (06-phase3-session-video.md §6.8, 07-phase4-input.md §5)
            logger.info("[Session] Starting teardown...")
            if self._renegotiate_thread and self._renegotiate_thread.is_alive():
                try:
                    load_api().LiInterruptConnection()
                except Exception:
                    pass
                self._renegotiate_thread.join(timeout=5.0)
                self._renegotiate_thread = None
            if self._input_handler:
                try:
                    self._input_handler.close()
                except Exception as e:
                    logger.warning(f"[Session] Error closing input handler: {e}")
                self._input_handler = None

            if self._decoder:
                try:
                    self._decoder.stop()
                except Exception as e:
                    logger.warning(f"[Session] Error stopping decoder: {e}")
                self._decoder = None

            if self._renderer:
                try:
                    self._renderer.close()
                except Exception as e:
                    logger.warning(f"[Session] Error closing renderer: {e}")
                self._renderer = None

            if self._overlay:
                try:
                    self._overlay.close()
                except Exception as e:
                    logger.warning(f"[Session] Error closing overlay: {e}")
                self._overlay = None

            if self._mailbox:
                try:
                    self._mailbox.close()
                except Exception as e:
                    logger.warning(f"[Session] Error closing mailbox: {e}")
                self._mailbox = None

            if self._window:
                try:
                    sdl2.SDL_DestroyWindow(self._window)
                except Exception as e:
                    logger.warning(f"[Session] Error destroying window: {e}")
                self._window = None

            try:
                sdl2.SDL_QuitSubSystem(sdl2.SDL_INIT_VIDEO | sdl2.SDL_INIT_GAMECONTROLLER)
            except Exception as e:
                logger.warning(f"[Session] SDL_QuitSubSystem error: {e}")

            # Restore SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS to "1" with OVERRIDE (Part 2 Item 18)
            try:
                override = getattr(sdl2, "SDL_HINT_OVERRIDE", 2)
                sdl2.SDL_SetHintWithPriority(b"SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", b"1", override)
            except Exception as e:
                logger.warning(f"[Session] Failed to restore background joystick hint: {e}")

            sys.setswitchinterval(orig_switch)

            # Cleanup thread to stop connection (Invariant §6.5)
            if self._connection:
                logger.info("[Session] Stopping Limelight connection on cleanup thread...")
                cleanup_th = threading.Thread(
                    target=self._connection.stop,
                    name="LimelightConnStop",
                    daemon=True,
                )
                cleanup_th.start()
                cleanup_th.join()

            # Clean up remote app on host if aborted or quit_app_after requested
            self._cleanup_teardown(term_code)

            # Session summary diagnostics per §7
            duration_s = max(0.001, time.monotonic() - self._start_time)
            if self._stats and self._decoder_config:
                glob = self._stats.global_stats
                rec = glob.received_frames + self._stats.active_wnd.received_frames
                dec = glob.decoded_frames + self._stats.active_wnd.decoded_frames
                ren = glob.rendered_frames + self._stats.active_wnd.rendered_frames
                tot = max(1, glob.total_frames + self._stats.active_wnd.total_frames)
                net_drop = glob.network_dropped_frames + self._stats.active_wnd.network_dropped_frames
                pacer_drop = glob.pacer_dropped_frames + self._stats.active_wnd.pacer_dropped_frames
                avg_dec = (glob.total_decode_time + self._stats.active_wnd.total_decode_time) / max(1, dec)
                avg_ren = (glob.total_render_time + self._stats.active_wnd.total_render_time) / max(1, ren)
                rtt = glob.last_rtt or self._stats.active_wnd.last_rtt
                idr_total = self._idr_requests_count + (self._decoder.idr_requests if self._decoder else 0)
                logger.info(
                    f"[SessionSummary] Duration: {duration_s:.1f}s | Format: 0x{self._decoder_config.video_format:04X} | "
                    f"Frames: Recv={rec} Dec={dec} Ren={ren} | NetDrop={net_drop} ({net_drop/tot*100:.1f}%) | "
                    f"PacerDrop={pacer_drop} ({pacer_drop/tot*100:.1f}%) | AvgDec={avg_dec:.2f}ms | AvgRen={avg_ren:.2f}ms | "
                    f"RTT={rtt}ms | IDR_Requests={idr_total}"
                )

            # Resume GamepadMonitor (Invariant §6.7)
            if self._gamepad_monitor and hasattr(self._gamepad_monitor, "resume"):
                try:
                    self._gamepad_monitor.resume()
                except Exception as e:
                    logger.warning(f"[Session] Error resuming GamepadMonitor: {e}")

            logger.info(f"[Session] StreamSession ended with code {term_code}")
            if self._on_session_ended:
                try:
                    sig = inspect.signature(self._on_session_ended)
                    if len(sig.parameters) >= 2:
                        self._on_session_ended(term_code, self._error_message)
                    else:
                        self._on_session_ended(term_code)
                except Exception as e:
                    logger.warning(f"[Session] on_session_ended callback failed: {e}")
