"""
SDL video renderer handling GPU color conversion, letterbox viewport, and texture upload.

1:1 port of Artemis app/streaming/video/ffmpeg-renderers/sdlvid.cpp.
Reference: streaming-technical/06-phase3-session-video.md §4
"""

from __future__ import annotations

import ctypes
from ctypes import byref, c_int, c_void_p
import logging
import time
import sdl2
from sdl2.surface import (
    SDL_YUV_CONVERSION_BT601,
    SDL_YUV_CONVERSION_BT709,
    SDL_YUV_CONVERSION_JPEG,
)

from app.core.remote.stream.stats import StatsTracker
from app.core.remote.stream.video import ffmpeg_api
from app.core.remote.stream.video.mailbox import FrameMailbox
from app.core.remote.stream.video.overlay import Overlay
from app.core.remote.stream.window import scale_source_to_destination

logger = logging.getLogger(__name__)


class SdlVideoRenderer:
    """Renders video frames onto an SDL window with GPU shader color conversion.

    Port of Artemis SdlRenderer (sdlvid.cpp).
    """

    def __init__(
        self,
        window: ctypes.c_void_p,
        mailbox: FrameMailbox,
        stats: StatsTracker,
        overlay: Overlay | None = None,
        vsync: bool = False,
    ) -> None:
        self._window = window
        self._mailbox = mailbox
        self._stats = stats
        self._overlay = overlay

        # Set renderer hints (06-phase3-session-video.md §4.1)
        sdl2.SDL_SetHint(sdl2.SDL_HINT_RENDER_SCALE_QUALITY, b"1")  # Linear filter
        sdl2.SDL_SetHint(sdl2.SDL_HINT_RENDER_DRIVER, b"direct3d11")
        sdl2.SDL_SetHint(sdl2.SDL_HINT_VIDEO_MINIMIZE_ON_FOCUS_LOSS, b"0")

        render_flags = sdl2.SDL_RENDERER_ACCELERATED
        if vsync:
            render_flags |= sdl2.SDL_RENDERER_PRESENTVSYNC

        self._renderer = sdl2.SDL_CreateRenderer(window, -1, render_flags)
        if not self._renderer:
            # Fallback to default direct3d driver if direct3d11 fails
            logger.warning(
                f"[Renderer] D3D11 renderer creation failed ({sdl2.SDL_GetError()}); retrying with default"
            )
            sdl2.SDL_ResetHint(sdl2.SDL_HINT_RENDER_DRIVER)
            self._renderer = sdl2.SDL_CreateRenderer(window, -1, render_flags)
            if not self._renderer:
                raise RuntimeError(
                    f"SDL_CreateRenderer failed: {sdl2.SDL_GetError()}"
                )

        # Log backend name
        info = sdl2.SDL_RendererInfo()
        if sdl2.SDL_GetRendererInfo(self._renderer, byref(info)) == 0:
            logger.info(f"[Renderer] Backend initialized: {info.name.decode('utf-8', errors='ignore')}")

        # Draw black frame initially (prepareToRender, sdlvid.cpp:69-75)
        sdl2.SDL_SetRenderDrawColor(self._renderer, 0, 0, 0, 255)
        sdl2.SDL_RenderClear(self._renderer)
        sdl2.SDL_RenderPresent(self._renderer)

        self._texture: ctypes.c_void_p | None = None
        self._sws_ctx: int | None = None
        self._tex_w: int = 0
        self._tex_h: int = 0
        self._tex_fmt: int = 0
        self._color_space: int = -1
        self._color_range: int = -1

    @property
    def raw_renderer(self) -> ctypes.c_void_p:
        return self._renderer

    def on_window_changed(self) -> None:
        """Called on SDL_WINDOWEVENT_SIZE_CHANGED / DISPLAY_CHANGED (sdlvid.cpp:273-296)."""
        logger.debug("[Renderer] Window size/display changed; updating swapchain")
        # SDL automatically updates its swapchain on Windows D3D
        if self._texture:
            self._destroy_texture()

    def on_device_reset(self) -> None:
        """Called on SDL_RENDER_DEVICE_RESET / SDL_RENDER_TARGETS_RESET (sdlvid.cpp:298-315)."""
        logger.warning("[Renderer] Render device/targets reset; destroying textures")
        self._destroy_texture()
        if self._renderer:
            sdl2.SDL_SetRenderDrawColor(self._renderer, 0, 0, 0, 255)
            sdl2.SDL_RenderClear(self._renderer)
            sdl2.SDL_RenderPresent(self._renderer)

    def _destroy_texture(self) -> None:
        if self._sws_ctx:
            ffmpeg_api.sws_freeContext(self._sws_ctx)
            self._sws_ctx = None
        if self._texture:
            sdl2.SDL_DestroyTexture(self._texture)
            self._texture = None
            self._tex_w = 0
            self._tex_h = 0
            self._tex_fmt = 0
            self._color_space = -1
            self._color_range = -1

    def _ensure_texture(self, frame: int) -> bool:
        """Recreate texture if format, dimensions, or colorspace changed (sdlvid.cpp:298-436)."""
        w, h = ffmpeg_api.frame_get_dimensions(frame)
        fmt = ffmpeg_api.frame_get_format(frame)
        cs = ffmpeg_api.frame_get_colorspace(frame)
        cr = ffmpeg_api.frame_get_color_range(frame)

        if (
            self._texture is not None
            and self._tex_w == w
            and self._tex_h == h
            and self._tex_fmt == fmt
            and self._color_space == cs
            and self._color_range == cr
        ):
            return True

        self._destroy_texture()

        # Set YUV conversion mode before texture creation (06-phase3-session-video.md §4.3)
        if cs == ffmpeg_api.AVCOL_SPC_BT709:
            sdl2.surface.SDL_SetYUVConversionMode(SDL_YUV_CONVERSION_BT709)
        elif cr == ffmpeg_api.AVCOL_RANGE_JPEG:
            sdl2.surface.SDL_SetYUVConversionMode(SDL_YUV_CONVERSION_JPEG)
        else:
            sdl2.surface.SDL_SetYUVConversionMode(SDL_YUV_CONVERSION_BT601)

        # Pick SDL texture pixel format
        needs_swscale = False
        if fmt == ffmpeg_api.PIX_FMT_NV12:
            sdl_pix_fmt = sdl2.SDL_PIXELFORMAT_NV12
        elif fmt in (ffmpeg_api.PIX_FMT_YUV420P, ffmpeg_api.PIX_FMT_YUVJ420P):
            sdl_pix_fmt = sdl2.SDL_PIXELFORMAT_IYUV
        else:
            sdl_pix_fmt = sdl2.SDL_PIXELFORMAT_XRGB8888
            needs_swscale = True

        if needs_swscale:
            self._sws_ctx = ffmpeg_api.sws_getContext(
                w,
                h,
                fmt,
                w,
                h,
                ffmpeg_api.PIX_FMT_BGR0,
                ffmpeg_api.SWS_FAST_BILINEAR,
                None,
                None,
                None,
            )
            if not self._sws_ctx:
                logger.error(f"[Renderer] sws_getContext failed for pixel format {fmt} ({w}x{h})")
                return False
            logger.info(f"[Renderer] Using swscale CPU color conversion for pixel format {fmt} ({w}x{h})")

        tex = sdl2.SDL_CreateTexture(
            self._renderer,
            sdl_pix_fmt,
            sdl2.SDL_TEXTUREACCESS_STREAMING,
            w,
            h,
        )
        if not tex:
            self._destroy_texture()
            logger.error(f"[Renderer] SDL_CreateTexture failed: {sdl2.SDL_GetError()}")
            return False

        # Set texture scale mode to linear explicitly
        sdl2.SDL_SetTextureScaleMode(tex, sdl2.SDL_ScaleModeLinear)

        self._texture = tex
        self._tex_w = w
        self._tex_h = h
        self._tex_fmt = fmt
        self._color_space = cs
        self._color_range = cr
        return True

    def render(self, frame_slot: int | None) -> None:
        """Upload and render frame onto the SDL window (sdlvid.cpp:579-605)."""
        if frame_slot is None:
            return

        pacer_start = time.monotonic()
        try:
            if not self._ensure_texture(frame_slot):
                return

            planes, linesizes = ffmpeg_api.frame_get_planes(frame_slot)
            fmt = ffmpeg_api.frame_get_format(frame_slot)

            # Upload texture
            ubyte_ptr = ctypes.POINTER(ctypes.c_ubyte)
            if fmt == ffmpeg_api.PIX_FMT_NV12:
                # data[0]: Y plane, data[1]: UV interleaved plane
                sdl2.SDL_UpdateNVTexture(
                    self._texture,
                    None,
                    ctypes.cast(planes[0], ubyte_ptr),
                    linesizes[0],
                    ctypes.cast(planes[1], ubyte_ptr),
                    linesizes[1],
                )
            elif fmt in (ffmpeg_api.PIX_FMT_YUV420P, ffmpeg_api.PIX_FMT_YUVJ420P):
                # data[0]: Y, data[1]: U, data[2]: V
                sdl2.SDL_UpdateYUVTexture(
                    self._texture,
                    None,
                    ctypes.cast(planes[0], ubyte_ptr),
                    linesizes[0],
                    ctypes.cast(planes[1], ubyte_ptr),
                    linesizes[1],
                    ctypes.cast(planes[2], ubyte_ptr),
                    linesizes[2],
                )
            elif self._sws_ctx:
                pixels = c_void_p()
                pitch = c_int()
                if sdl2.SDL_LockTexture(self._texture, None, byref(pixels), byref(pitch)) == 0:
                    try:
                        src_data = (c_void_p * 8)(*planes)
                        src_stride = (c_int * 8)(*linesizes)
                        dst_data = (c_void_p * 8)(pixels.value or 0, 0, 0, 0, 0, 0, 0, 0)
                        dst_stride = (c_int * 8)(pitch.value, 0, 0, 0, 0, 0, 0, 0)
                        ffmpeg_api.sws_scale(
                            self._sws_ctx, src_data, src_stride, 0, self._tex_h, dst_data, dst_stride
                        )
                    finally:
                        sdl2.SDL_UnlockTexture(self._texture)
        finally:
            # Release slot immediately after texture upload (06-phase3-session-video.md §4.2)
            self._mailbox.release(frame_slot)

        # Draw frame into aspect-fit viewport
        out_w = c_int()
        out_h = c_int()
        sdl2.SDL_GetRendererOutputSize(self._renderer, byref(out_w), byref(out_h))

        sdl2.SDL_RenderClear(self._renderer)

        dst = scale_source_to_destination(
            (0, 0, self._tex_w, self._tex_h),
            (0, 0, out_w.value, out_h.value),
        )
        viewport = sdl2.SDL_Rect(dst[0], dst[1], dst[2], dst[3])
        sdl2.SDL_RenderSetViewport(self._renderer, byref(viewport))
        sdl2.SDL_RenderCopy(self._renderer, self._texture, None, None)
        sdl2.SDL_RenderSetViewport(self._renderer, None)

        if self._overlay:
            self._overlay.draw(out_w.value, out_h.value, renderer=self._renderer)

        t_present_start = time.monotonic()
        sdl2.SDL_RenderPresent(self._renderer)
        t_present_end = time.monotonic()

        render_time_ms = (t_present_end - t_present_start) * 1000.0
        pacer_time_ms = (t_present_start - pacer_start) * 1000.0
        pacer_drops = self._mailbox.pop_pacer_drops()

        self._stats.on_frame_rendered(render_time_ms, pacer_time_ms, pacer_drops)

    def close(self) -> None:
        """Destroy textures and renderer."""
        self._destroy_texture()
        if self._renderer:
            sdl2.SDL_DestroyRenderer(self._renderer)
            self._renderer = None
