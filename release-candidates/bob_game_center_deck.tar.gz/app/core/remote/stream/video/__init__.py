"""
Video decode and rendering pipeline for Remote Gaming.
"""

from __future__ import annotations
