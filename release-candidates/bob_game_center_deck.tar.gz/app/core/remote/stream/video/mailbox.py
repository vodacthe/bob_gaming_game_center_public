"""
Frame mailbox providing a 3-slot AVFrame pool with latest-frame-wins pacing.

Replaces an unrendered frame when a newer one arrives, keeping display latency
minimal on a single-threaded Python/SDL event loop.
Port of Artemis pacer.cpp logic adapted to event-thread rendering.
Reference: streaming-technical/06-phase3-session-video.md §5
"""

from __future__ import annotations

import threading
from ctypes import POINTER, c_void_p

from app.core.remote.stream.video import ffmpeg_api


class FrameMailbox:
    """3-slot AVFrame pool. publish() replaces an unrendered frame (counted as a pacer drop)."""

    def __init__(self, pool_size: int = 3) -> None:
        self._lock = threading.Lock()
        self._pool_size = pool_size
        self._all_frames: list[int] = []
        self._free_pool: list[int] = []
        self._latest: int | None = None
        self._pending_event: bool = False
        self._pacer_dropped_frames: int = 0
        self._acquire_dropped_frames: int = 0

        for _ in range(pool_size):
            frame = ffmpeg_api.av_frame_alloc()
            if not frame:
                self.close()
                raise MemoryError("Failed to allocate AVFrame for mailbox pool")
            self._all_frames.append(frame)
            self._free_pool.append(frame)

    def acquire(self) -> int | None:
        """Acquire a free frame from the pool.

        Returns slot address, or None if no slots are free (increments acquire drop count).
        """
        with self._lock:
            if self._free_pool:
                return self._free_pool.pop()
            self._acquire_dropped_frames += 1
            return None

    def publish(self, slot: int) -> bool:
        """Publish a decoded frame into the mailbox.

        If a previous frame was published but not yet taken by the renderer,
        it is replaced, counted as a pacer drop, and recycled.
        Returns True if an EV_FRAME_READY event must be pushed to SDL.
        """
        with self._lock:
            if self._latest is not None:
                # Displace the unrendered frame (latest-frame-wins)
                old_slot = self._latest
                self._pacer_dropped_frames += 1
                ffmpeg_api.av_frame_unref(old_slot)
                self._free_pool.append(old_slot)

            self._latest = slot
            if not self._pending_event:
                self._pending_event = True
                return True
            return False

    def take(self) -> int | None:
        """Take the latest frame for rendering on the SDL thread.

        Clears the pending event flag. The caller must call release() when done.
        """
        with self._lock:
            self._pending_event = False
            slot = self._latest
            self._latest = None
            return slot

    def reset_pending_event(self) -> None:
        """Reset pending event flag if pushing EV_FRAME_READY failed."""
        with self._lock:
            self._pending_event = False

    def release(self, slot: int) -> None:
        """Release a rendered frame back to the pool."""
        with self._lock:
            ffmpeg_api.av_frame_unref(slot)
            if slot not in self._free_pool:
                self._free_pool.append(slot)

    @property
    def pacer_dropped_frames(self) -> int:
        with self._lock:
            return self._pacer_dropped_frames

    def pop_pacer_drops(self) -> int:
        with self._lock:
            drops = self._pacer_dropped_frames
            self._pacer_dropped_frames = 0
            return drops

    def close(self) -> None:
        """Free all underlying AVFrames."""
        with self._lock:
            self._latest = None
            self._free_pool.clear()
            for frame in self._all_frames:
                ptr = c_void_p(frame)
                ffmpeg_api.av_frame_free(POINTER(c_void_p)(ptr))
            self._all_frames.clear()
