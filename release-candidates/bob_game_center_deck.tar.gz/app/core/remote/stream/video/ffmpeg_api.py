"""
ctypes wrapper for FFmpeg 7.1 (avcodec-61, avutil-59, swscale-8).

Offsets are measured against artemis-pc/libs/windows/include/x64 and verified
at runtime via avcodec_version().
Reference: streaming-technical/06-phase3-session-video.md §1
"""

from __future__ import annotations

import ctypes
import logging
import os
from ctypes import (
    POINTER,
    c_char_p,
    c_double,
    c_int,
    c_int64,
    c_size_t,
    c_uint,
    c_void_p,
)

from app.core.remote.native_paths import ensure_dll_directory, native_bin_dir

logger = logging.getLogger(__name__)

# Struct member offsets for FFmpeg 7.1 (avcodec 61.19.100, x64 MSVC)
# Measured via native/ffmpeg_layout/avprobe.c
FFMPEG_LAYOUT = {
    "LIBAVCODEC_VERSION_INT": 4002660,  # 61.19.100
    "AVCodecContext.hw_device_ctx": 560,
    "AVPacket.data": 24,
    "AVPacket.size": 32,
    "AVPacket.flags": 40,
    "AVFrame.data": 0,
    "AVFrame.linesize": 64,
    "AVFrame.width": 104,
    "AVFrame.height": 108,
    "AVFrame.format": 116,
    "AVFrame.flags": 292,
    "AVFrame.color_range": 296,
    "AVFrame.colorspace": 308,
    "AVFrame.decode_error_flags": 344,
    "AVFrame.hw_frames_ctx": 352,
}
AV_INPUT_BUFFER_PADDING_SIZE = 64

# Common error codes & flags
AVERROR_EAGAIN = -11
AVERROR_ENOSYS = -40
AV_PKT_FLAG_KEY = 1
AV_FRAME_FLAG_CORRUPT = 1 << 0

# Color ranges (AVColorRange)
AVCOL_RANGE_UNSPECIFIED = 0
AVCOL_RANGE_MPEG = 1  # Limited range
AVCOL_RANGE_JPEG = 2  # Full range

# Color spaces (AVColorSpace)
AVCOL_SPC_RGB = 0
AVCOL_SPC_BT709 = 1
AVCOL_SPC_UNSPECIFIED = 2
AVCOL_SPC_RESERVED = 3
AVCOL_SPC_FCC = 4
AVCOL_SPC_BT470BG = 5
AVCOL_SPC_SMPTE170M = 6  # BT.601
AVCOL_SPC_SMPTE240M = 7
AVCOL_SPC_YCGCO = 8
AVCOL_SPC_BT2020_NCL = 9
AVCOL_SPC_BT2020_CL = 10

import threading
from typing import Any

_load_lock = threading.Lock()
_loaded = False

_lib_avutil: ctypes.CDLL | None = None
_lib_avcodec: ctypes.CDLL | None = None
_lib_swscale: ctypes.CDLL | None = None

# Default standard constants (evaluated without loading DLL)
PIX_FMT_D3D11 = 171
PIX_FMT_DXVA2_VLD = 51
PIX_FMT_NV12 = 23
PIX_FMT_YUV420P = 0
PIX_FMT_YUVJ420P = 12
PIX_FMT_BGR0 = 121
SWS_FAST_BILINEAR = 1

HWDEVICE_TYPE_D3D11VA = 7
HWDEVICE_TYPE_DXVA2 = 4

def ensure_ffmpeg_loaded() -> None:
    """Lazily load FFmpeg native DLLs at stream start or first decode use (05 §2, Part 2 Item 26)."""
    global _loaded, _lib_avutil, _lib_avcodec, _lib_swscale
    if _loaded:
        return
    with _load_lock:
        if _loaded:
            return
        ensure_dll_directory()
        _bin = native_bin_dir()

        # Preload dependencies in safe order
        for _dep in ("libcrypto-3-x64.dll", "dav1d.dll", "swscale-8.dll"):
            _p = _bin / _dep
            if _p.exists():
                try:
                    ctypes.CDLL(str(_p))
                except Exception:
                    pass

        _lib_avutil = ctypes.CDLL(str(_bin / "avutil-59.dll"))
        _lib_avcodec = ctypes.CDLL(str(_bin / "avcodec-61.dll"))
        _lib_swscale = ctypes.CDLL(str(_bin / "swscale-8.dll"))

        _init_function_pointers()
        _loaded = True


def _init_function_pointers() -> None:
    global _lib_avutil, _lib_avcodec, _lib_swscale
    global avcodec_version, avcodec_find_decoder_by_name, avcodec_alloc_context3, avcodec_open2
    global avcodec_send_packet, avcodec_receive_frame, avcodec_flush_buffers, avcodec_free_context
    global av_packet_alloc, av_packet_free, av_frame_alloc, av_frame_free, av_frame_unref, av_frame_ref
    global av_opt_set, _raw_av_opt_set_int, av_opt_set_image_size, av_opt_get_image_size
    global av_hwdevice_ctx_create, av_hwdevice_find_type_by_name, av_buffer_ref, av_buffer_unref
    global av_hwframe_transfer_data, av_get_pix_fmt, av_strerror, av_log_set_level
    global sws_getContext, sws_scale, sws_freeContext
    global PIX_FMT_D3D11, PIX_FMT_DXVA2_VLD, PIX_FMT_NV12, PIX_FMT_YUV420P, PIX_FMT_YUVJ420P, PIX_FMT_BGR0
    global HWDEVICE_TYPE_D3D11VA, HWDEVICE_TYPE_DXVA2

    # --- avcodec functions ---
    avcodec_version = _lib_avcodec.avcodec_version
    avcodec_version.restype = c_uint
    avcodec_version.argtypes = []

    avcodec_find_decoder_by_name = _lib_avcodec.avcodec_find_decoder_by_name
    avcodec_find_decoder_by_name.restype = c_void_p
    avcodec_find_decoder_by_name.argtypes = [c_char_p]

    avcodec_alloc_context3 = _lib_avcodec.avcodec_alloc_context3
    avcodec_alloc_context3.restype = c_void_p
    avcodec_alloc_context3.argtypes = [c_void_p]

    avcodec_open2 = _lib_avcodec.avcodec_open2
    avcodec_open2.restype = c_int
    avcodec_open2.argtypes = [c_void_p, c_void_p, POINTER(c_void_p)]

    avcodec_send_packet = _lib_avcodec.avcodec_send_packet
    avcodec_send_packet.restype = c_int
    avcodec_send_packet.argtypes = [c_void_p, c_void_p]

    avcodec_receive_frame = _lib_avcodec.avcodec_receive_frame
    avcodec_receive_frame.restype = c_int
    avcodec_receive_frame.argtypes = [c_void_p, c_void_p]

    avcodec_flush_buffers = _lib_avcodec.avcodec_flush_buffers
    avcodec_flush_buffers.restype = None
    avcodec_flush_buffers.argtypes = [c_void_p]

    avcodec_free_context = _lib_avcodec.avcodec_free_context
    avcodec_free_context.restype = None
    avcodec_free_context.argtypes = [POINTER(c_void_p)]

    av_packet_alloc = _lib_avcodec.av_packet_alloc
    av_packet_alloc.restype = c_void_p
    av_packet_alloc.argtypes = []

    av_packet_free = _lib_avcodec.av_packet_free
    av_packet_free.restype = None
    av_packet_free.argtypes = [POINTER(c_void_p)]

    # --- avutil functions ---
    av_frame_alloc = _lib_avutil.av_frame_alloc
    av_frame_alloc.restype = c_void_p
    av_frame_alloc.argtypes = []

    av_frame_free = _lib_avutil.av_frame_free
    av_frame_free.restype = None
    av_frame_free.argtypes = [POINTER(c_void_p)]

    av_frame_unref = _lib_avutil.av_frame_unref
    av_frame_unref.restype = None
    av_frame_unref.argtypes = [c_void_p]

    av_frame_ref = _lib_avutil.av_frame_ref
    av_frame_ref.restype = c_int
    av_frame_ref.argtypes = [c_void_p, c_void_p]

    av_opt_set = _lib_avutil.av_opt_set
    av_opt_set.restype = c_int
    av_opt_set.argtypes = [c_void_p, c_char_p, c_char_p, c_int]

    _raw_av_opt_set_int = _lib_avutil.av_opt_set_int
    _raw_av_opt_set_int.restype = c_int
    _raw_av_opt_set_int.argtypes = [c_void_p, c_char_p, c_int64, c_int]

    av_opt_set_image_size = _lib_avutil.av_opt_set_image_size
    av_opt_set_image_size.restype = c_int
    av_opt_set_image_size.argtypes = [c_void_p, c_char_p, c_int, c_int, c_int]

    av_opt_get_image_size = _lib_avutil.av_opt_get_image_size
    av_opt_get_image_size.restype = c_int
    av_opt_get_image_size.argtypes = [c_void_p, c_char_p, c_int, POINTER(c_int), POINTER(c_int)]

    av_hwdevice_ctx_create = _lib_avutil.av_hwdevice_ctx_create
    av_hwdevice_ctx_create.restype = c_int
    av_hwdevice_ctx_create.argtypes = [POINTER(c_void_p), c_int, c_char_p, c_void_p, c_int]

    av_hwdevice_find_type_by_name = _lib_avutil.av_hwdevice_find_type_by_name
    av_hwdevice_find_type_by_name.restype = c_int
    av_hwdevice_find_type_by_name.argtypes = [c_char_p]

    av_buffer_ref = _lib_avutil.av_buffer_ref
    av_buffer_ref.restype = c_void_p
    av_buffer_ref.argtypes = [c_void_p]

    av_buffer_unref = _lib_avutil.av_buffer_unref
    av_buffer_unref.restype = None
    av_buffer_unref.argtypes = [POINTER(c_void_p)]

    av_hwframe_transfer_data = _lib_avutil.av_hwframe_transfer_data
    av_hwframe_transfer_data.restype = c_int
    av_hwframe_transfer_data.argtypes = [c_void_p, c_void_p, c_int]

    av_get_pix_fmt = _lib_avutil.av_get_pix_fmt
    av_get_pix_fmt.restype = c_int
    av_get_pix_fmt.argtypes = [c_char_p]

    av_strerror = _lib_avutil.av_strerror
    av_strerror.restype = c_int
    av_strerror.argtypes = [c_int, c_char_p, c_size_t]

    av_log_set_level = _lib_avutil.av_log_set_level
    av_log_set_level.restype = None
    av_log_set_level.argtypes = [c_int]

    # --- swscale functions ---
    sws_getContext = _lib_swscale.sws_getContext
    sws_getContext.restype = c_void_p
    sws_getContext.argtypes = [
        c_int, c_int, c_int, c_int, c_int, c_int, c_int, c_void_p, c_void_p, POINTER(c_double)
    ]

    sws_scale = _lib_swscale.sws_scale
    sws_scale.restype = c_int
    sws_scale.argtypes = [
        c_void_p, POINTER(c_void_p), POINTER(c_int), c_int, c_int, POINTER(c_void_p), POINTER(c_int)
    ]

    sws_freeContext = _lib_swscale.sws_freeContext
    sws_freeContext.restype = None
    sws_freeContext.argtypes = [c_void_p]

    # Update formats/hw types from runtime library
    PIX_FMT_D3D11 = av_get_pix_fmt(b"d3d11")
    PIX_FMT_DXVA2_VLD = av_get_pix_fmt(b"dxva2_vld")
    PIX_FMT_NV12 = av_get_pix_fmt(b"nv12")
    PIX_FMT_YUV420P = av_get_pix_fmt(b"yuv420p")
    PIX_FMT_YUVJ420P = av_get_pix_fmt(b"yuvj420p")
    PIX_FMT_BGR0 = av_get_pix_fmt(b"bgr0")

    HWDEVICE_TYPE_D3D11VA = av_hwdevice_find_type_by_name(b"d3d11va")
    HWDEVICE_TYPE_DXVA2 = av_hwdevice_find_type_by_name(b"dxva2")


def __getattr__(name: str) -> Any:
    """Support lazy loading when module attributes or function pointers are accessed."""
    ensure_ffmpeg_loaded()
    if name in globals():
        return globals()[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def av_opt_set_int(obj: int | c_void_p, name: bytes | str, val: int, search_flags: int = 0) -> int:
    """Set integer option on an FFmpeg object.

    Handles 'width' and 'height' on AVCodecContext via video_size (Part 1 Item 10).
    """
    ensure_ffmpeg_loaded()
    name_bytes = name.encode("utf-8") if isinstance(name, str) else name
    if name_bytes in (b"width", b"height"):
        w = c_int(0)
        h = c_int(0)
        av_opt_get_image_size(obj, b"video_size", search_flags, ctypes.byref(w), ctypes.byref(h))
        new_w = val if name_bytes == b"width" else (w.value or 0)
        new_h = val if name_bytes == b"height" else (h.value or 0)
        return av_opt_set_image_size(obj, b"video_size", new_w, new_h, search_flags)
    return _raw_av_opt_set_int(obj, name_bytes, val, search_flags)


def check_ffmpeg_version() -> bool:
    """Return True if runtime avcodec_version matches FFMPEG_LAYOUT."""
    ensure_ffmpeg_loaded()
    return avcodec_version() == FFMPEG_LAYOUT["LIBAVCODEC_VERSION_INT"]


def av_strerror_str(errnum: int) -> str:
    """Format FFmpeg error code to human-readable string."""
    buf = ctypes.create_string_buffer(256)
    if av_strerror(errnum, buf, len(buf)) == 0:
        return buf.value.decode("utf-8", errors="replace")
    return f"Error {errnum}"


def configure_codec_context(
    ctx: int,
    hardware: bool,
    device_ref: int | None = None,
    strict_err_detect: bool = True,
) -> bool:
    """Configure AVCodecContext options matching Artemis ffmpeg.cpp:569-623.

    Returns True if hardware decoding was configured, False if software decoding.
    """
    # Low delay + output corrupt (ffmpeg.cpp:569-573)
    av_opt_set(ctx, b"flags", b"+low_delay+output_corrupt", 0)
    av_opt_set(ctx, b"flags2", b"+showall", 0)
    if strict_err_detect:
        av_opt_set(ctx, b"err_detect", b"+explode", 0)  # err_recognition = AV_EF_EXPLODE (ffmpeg.cpp:57-64)
    else:
        av_opt_set(ctx, b"err_detect", b"0", 0)

    is_hw = False
    if hardware and device_ref:
        if not check_ffmpeg_version():
            logger.error(
                "[FFmpeg] Runtime libavcodec version mismatch with layout offsets; disabling hardware decoding"
            )
        else:
            is_hw = True

    if is_hw and device_ref:
        # "No threading for HW decode" (ffmpeg.cpp:610)
        av_opt_set_int(ctx, b"threads", 1, 0)
        # ctx->hw_device_ctx = av_buffer_ref(device_ref)
        hw_ctx_addr = ctx + FFMPEG_LAYOUT["AVCodecContext.hw_device_ctx"]
        c_void_p.from_address(hw_ctx_addr).value = av_buffer_ref(device_ref)
        return True
    else:
        # Software decode: slice threads only, never frame threads (ffmpeg.cpp:613-623)
        av_opt_set(ctx, b"thread_type", b"slice", 0)
        cpu_slices = min(4, os.cpu_count() or 1)  # MAX_SLICES 4 (decoder.h:9)
        av_opt_set_int(ctx, b"threads", cpu_slices, 0)
        return False


# Struct member helpers
def packet_set_data(pkt: int, data_addr: int, size: int, is_key: bool) -> None:
    """Set data, size, and keyframe flag on an allocated AVPacket."""
    c_void_p.from_address(pkt + FFMPEG_LAYOUT["AVPacket.data"]).value = data_addr
    c_int.from_address(pkt + FFMPEG_LAYOUT["AVPacket.size"]).value = size
    c_int.from_address(pkt + FFMPEG_LAYOUT["AVPacket.flags"]).value = 1 if is_key else 0


def frame_get_dimensions(frame: int) -> tuple[int, int]:
    """Return (width, height) of an AVFrame."""
    w = c_int.from_address(frame + FFMPEG_LAYOUT["AVFrame.width"]).value
    h = c_int.from_address(frame + FFMPEG_LAYOUT["AVFrame.height"]).value
    return w, h


def frame_get_format(frame: int) -> int:
    """Return pixel format of an AVFrame."""
    return c_int.from_address(frame + FFMPEG_LAYOUT["AVFrame.format"]).value


def frame_set_format(frame: int, fmt: int) -> None:
    """Set pixel format on an AVFrame."""
    c_int.from_address(frame + FFMPEG_LAYOUT["AVFrame.format"]).value = fmt


def frame_get_color_range(frame: int) -> int:
    """Return color_range of an AVFrame."""
    return c_int.from_address(frame + FFMPEG_LAYOUT["AVFrame.color_range"]).value


def frame_get_colorspace(frame: int) -> int:
    """Return colorspace of an AVFrame."""
    return c_int.from_address(frame + FFMPEG_LAYOUT["AVFrame.colorspace"]).value


def frame_get_planes(frame: int) -> tuple[list[int], list[int]]:
    """Return ([data[0]..data[7]], [linesize[0]..linesize[7]]) of an AVFrame."""
    data_base = frame + FFMPEG_LAYOUT["AVFrame.data"]
    linesize_base = frame + FFMPEG_LAYOUT["AVFrame.linesize"]
    data = [c_void_p.from_address(data_base + i * 8).value or 0 for i in range(8)]
    linesizes = [c_int.from_address(linesize_base + i * 4).value for i in range(8)]
    return data, linesizes


def frame_get_flags(frame: int) -> int:
    """Return AVFrame.flags bitmask."""
    return c_int.from_address(frame + FFMPEG_LAYOUT["AVFrame.flags"]).value


def frame_get_decode_error_flags(frame: int) -> int:
    """Return AVFrame.decode_error_flags bitmask."""
    return c_int.from_address(frame + FFMPEG_LAYOUT["AVFrame.decode_error_flags"]).value


def frame_is_corrupt(frame: int) -> bool:
    """Return True if AVFrame has AV_FRAME_FLAG_CORRUPT or non-zero decode_error_flags."""
    return bool(
        (frame_get_flags(frame) & AV_FRAME_FLAG_CORRUPT)
        or frame_get_decode_error_flags(frame) != 0
    )
