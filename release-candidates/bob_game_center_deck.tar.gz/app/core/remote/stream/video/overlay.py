"""
Text overlays for performance stats (top-left) and connection status (bottom-left).

1:1 port of Artemis overlaymanager.cpp and sdlvid.cpp:225-271.
Reference: streaming-technical/06-phase3-session-video.md §7
"""

from __future__ import annotations

import ctypes
import logging
from pathlib import Path
import threading
import sdl2
import sdl2.sdlttf as sdlttf

logger = logging.getLogger(__name__)

def _find_font() -> Path:
    base = Path(__file__).resolve()
    for parent in (base.parents[5], base.parents[4]):
        candidate = parent / "assets" / "fonts" / "ModeSeven.ttf"
        if candidate.exists():
            return candidate
    return base.parents[5] / "assets" / "fonts" / "ModeSeven.ttf"


FONT_PATH = _find_font()


class Overlay:
    """Manages debug and status text overlays rendered via SDL_ttf."""

    def __init__(self, renderer: ctypes.c_void_p | None = None, initial_debug_enabled: bool = False) -> None:
        self._renderer = renderer
        self._debug_enabled = initial_debug_enabled
        self._status_text: str = ""

        self._debug_text: str = ""
        self._debug_surface: ctypes.c_void_p | None = None
        self._debug_texture: ctypes.c_void_p | None = None
        self._debug_rect = sdl2.SDL_Rect(10, 10, 0, 0)

        self._status_surface: ctypes.c_void_p | None = None
        self._status_texture: ctypes.c_void_p | None = None
        self._status_rect = sdl2.SDL_Rect(10, 10, 0, 0)
        self._surface_lock = threading.Lock()

        self._font_debug: ctypes.c_void_p | None = None
        self._font_status: ctypes.c_void_p | None = None

        # Colors from overlaymanager.cpp:12-16
        # Debug: (0xD0, 0xD0, 0x00, 0xFF)
        self._color_debug = sdl2.SDL_Color(0xD0, 0xD0, 0x00, 0xFF)
        # Status: (0xCC, 0x00, 0x00, 0xFF)
        self._color_status = sdl2.SDL_Color(0xCC, 0x00, 0x00, 0xFF)

        if sdlttf.TTF_Init() != 0:
            logger.warning(f"[Overlay] TTF_Init failed: {sdlttf.TTF_GetError()}")
            return

        font_file = str(FONT_PATH)
        if FONT_PATH.exists():
            self._font_debug = sdlttf.TTF_OpenFont(font_file.encode("utf-8"), 20)
            self._font_status = sdlttf.TTF_OpenFont(font_file.encode("utf-8"), 36)
            if not self._font_debug:
                logger.warning(f"[Overlay] Failed to load debug font: {sdlttf.TTF_GetError()}")
        else:
            logger.warning(f"[Overlay] Font file not found at {FONT_PATH}")

    @property
    def is_debug_enabled(self) -> bool:
        return self._debug_enabled

    def toggle_debug(self) -> bool:
        """Toggle debug overlay visibility (Ctrl+Alt+Shift+S)."""
        self._debug_enabled = not self._debug_enabled
        if not self._debug_enabled:
            self._destroy_debug_texture()
        return self._debug_enabled

    def set_debug_text(self, text: str) -> None:
        """Update stats text (called when 1-second stat window flips)."""
        self._debug_text = text
        if self._debug_enabled and self._font_debug:
            self._recreate_debug_surface()

    def set_status_text(self, text: str) -> None:
        """Update connection status line (e.g. poor connection warning)."""
        self._status_text = text
        if self._font_status:
            self._recreate_status_surface()

    def _recreate_debug_surface(self) -> None:
        if not self._debug_text or not self._font_debug:
            return
        surf = sdlttf.TTF_RenderUTF8_Blended_Wrapped(
            self._font_debug,
            self._debug_text.encode("utf-8"),
            self._color_debug,
            1024,
        )
        if surf:
            with self._surface_lock:
                if self._debug_surface:
                    sdl2.SDL_FreeSurface(self._debug_surface)
                self._debug_surface = surf

    def _recreate_status_surface(self) -> None:
        if not self._status_text or not self._font_status:
            return
        surf = sdlttf.TTF_RenderUTF8_Blended_Wrapped(
            self._font_status,
            self._status_text.encode("utf-8"),
            self._color_status,
            1024,
        )
        if surf:
            with self._surface_lock:
                if self._status_surface:
                    sdl2.SDL_FreeSurface(self._status_surface)
                self._status_surface = surf

    def draw(self, output_w: int, output_h: int, renderer: ctypes.c_void_p | None = None) -> None:
        """Draw overlays to current SDL renderer. Must be called on SDL thread."""
        target_renderer = renderer or self._renderer
        if not target_renderer:
            return

        # Atomically take pending debug surface
        debug_surf = None
        with self._surface_lock:
            if self._debug_surface:
                debug_surf = self._debug_surface
                self._debug_surface = None

        if debug_surf:
            self._destroy_debug_texture()
            tex = sdl2.SDL_CreateTextureFromSurface(target_renderer, debug_surf)
            if tex:
                surf = debug_surf.contents
                self._debug_rect.w = surf.w
                self._debug_rect.h = surf.h
                self._debug_texture = tex
            sdl2.SDL_FreeSurface(debug_surf)

        if self._debug_enabled and self._debug_texture:
            sdl2.SDL_RenderCopy(target_renderer, self._debug_texture, None, ctypes.byref(self._debug_rect))

        # Atomically take pending status surface
        status_surf = None
        with self._surface_lock:
            if self._status_surface:
                status_surf = self._status_surface
                self._status_surface = None

        if status_surf:
            self._destroy_status_texture()
            tex = sdl2.SDL_CreateTextureFromSurface(target_renderer, status_surf)
            if tex:
                surf = status_surf.contents
                self._status_rect.w = surf.w
                self._status_rect.h = surf.h
                self._status_rect.x = 20
                self._status_rect.y = max(10, output_h - surf.h - 20)  # Bottom-left
                self._status_texture = tex
            sdl2.SDL_FreeSurface(status_surf)

        if self._status_text and self._status_texture:
            sdl2.SDL_RenderCopy(target_renderer, self._status_texture, None, ctypes.byref(self._status_rect))

    def _destroy_debug_texture(self) -> None:
        if self._debug_texture:
            sdl2.SDL_DestroyTexture(self._debug_texture)
            self._debug_texture = None

    def _destroy_status_texture(self) -> None:
        if self._status_texture:
            sdl2.SDL_DestroyTexture(self._status_texture)
            self._status_texture = None

    def close(self) -> None:
        """Clean up textures, surfaces, and fonts."""
        self._destroy_debug_texture()
        self._destroy_status_texture()
        with self._surface_lock:
            if self._debug_surface:
                sdl2.SDL_FreeSurface(self._debug_surface)
                self._debug_surface = None
            if self._status_surface:
                sdl2.SDL_FreeSurface(self._status_surface)
                self._status_surface = None
        if self._font_debug:
            sdlttf.TTF_CloseFont(self._font_debug)
            self._font_debug = None
        if self._font_status:
            sdlttf.TTF_CloseFont(self._font_status)
            self._font_status = None
        sdlttf.TTF_Quit()
