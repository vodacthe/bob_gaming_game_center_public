"""
Pull video decoder with D3D11VA hardware acceleration and software fallback.

1:1 port of Artemis app/streaming/video/ffmpeg.cpp:
- decoder selection and probing (session.cpp:799-1000, ffmpeg.cpp:1560-1692)
- pull decoder thread loop (ffmpeg.cpp:1741-1900)
- decode unit submission & concatenation (ffmpeg.cpp:1892-2011)
Reference: streaming-technical/06-phase3-session-video.md §2, §3
"""

from __future__ import annotations

import collections
import ctypes
from ctypes import byref, c_int, c_ubyte, c_void_p, wintypes
import json
import logging
import os
from pathlib import Path
import threading
import time
from typing import Callable

from app.core.remote.limelight import api, load_api
from app.core.remote.limelight.api import LimelightApi
from app.core.remote.models import StreamSettings, VideoCodec
from app.core.remote.stream.stats import StatsTracker
from app.core.remote.stream.video import ffmpeg_api, test_frames
from app.core.remote.stream.video.mailbox import FrameMailbox

from app.config import CONFIG_DIR

logger = logging.getLogger(__name__)

CACHE_FILE_PATH = Path(CONFIG_DIR) / "remote" / "decoder_cache.json"


class DecoderConfig:
    """Configuration for an initialized video decoder."""

    def __init__(
        self,
        video_format: int,
        capabilities: int,
        color_space: int,
        color_range: int,
        decoder_name: str,
        hw_device_type_name: str | None,
        width: int,
        height: int,
        fps: int,
        strict_err_detect: bool = True,
    ) -> None:
        self.video_format = video_format
        self.capabilities = capabilities
        self.color_space = color_space
        self.color_range = color_range
        self.decoder_name = decoder_name
        self.hw_device_type_name = hw_device_type_name
        self.width = width
        self.height = height
        self.fps = fps
        self.strict_err_detect = strict_err_detect

    @property
    def is_hardware(self) -> bool:
        return self.hw_device_type_name is not None


def get_gpu_identifier() -> str:
    """Identify the primary GPU adapter using DXGI for cache indexing."""
    if os.name == "nt":
        class DXGI_ADAPTER_DESC(ctypes.Structure):
            _fields_ = [
                ("Description", wintypes.WCHAR * 128),
                ("VendorId", wintypes.UINT),
                ("DeviceId", wintypes.UINT),
                ("SubSysId", wintypes.UINT),
                ("Revision", wintypes.UINT),
                ("DedicatedVideoMemory", ctypes.c_size_t),
                ("DedicatedSystemMemory", ctypes.c_size_t),
                ("SharedSystemMemory", ctypes.c_size_t),
                ("AdapterLuid", wintypes.ULARGE_INTEGER),
            ]

        try:
            dxgi = ctypes.windll.dxgi
            factory = c_void_p()
            # IID_IDXGIFactory1: 770aae78-f26f-4dba-a829-253c83d1b387
            iid = (ctypes.c_byte * 16)(*bytes.fromhex("78ae0a77 6ff2 ba4d a829 253c83d1b387".replace(" ", "")))
            if dxgi.CreateDXGIFactory1(byref(iid), byref(factory)) == 0 and factory.value:
                vtbl = ctypes.cast(
                    ctypes.cast(factory, ctypes.POINTER(c_void_p)).contents,
                    ctypes.POINTER(c_void_p),
                )
                adapter = c_void_p()
                enum_fn = ctypes.WINFUNCTYPE(ctypes.c_long, c_void_p, wintypes.UINT, ctypes.POINTER(c_void_p))(vtbl[7])
                if enum_fn(factory, 0, byref(adapter)) == 0 and adapter.value:
                    avtbl = ctypes.cast(
                        ctypes.cast(adapter, ctypes.POINTER(c_void_p)).contents,
                        ctypes.POINTER(c_void_p),
                    )
                    get_desc = ctypes.WINFUNCTYPE(
                        ctypes.c_long, c_void_p, ctypes.POINTER(DXGI_ADAPTER_DESC)
                    )(avtbl[8])
                    desc = DXGI_ADAPTER_DESC()
                    if get_desc(adapter, byref(desc)) == 0:
                        return f"{desc.Description} (DevId: 0x{desc.DeviceId:04X})"
        except Exception as e:
            logger.debug(f"[Decoder] DXGI GPU query failed: {e}")

    return "Generic-GPU"


def probe_single_decoder(
    codec_name: str,
    hw_type_name: str | None,
    test_frame_bytes: bytes,
) -> tuple[bool, str]:
    """Test decode a 720p bitstream sample.

    Port of Artemis ffmpeg.cpp:636-738.
    """
    ffmpeg_api.ensure_ffmpeg_loaded()
    decoder = ffmpeg_api.avcodec_find_decoder_by_name(codec_name.encode("utf-8"))
    if not decoder:
        return False, f"Decoder '{codec_name}' not found"

    ctx = ffmpeg_api.avcodec_alloc_context3(decoder)
    if not ctx:
        return False, "Failed to allocate AVCodecContext"

    device_ref: int | None = None
    if hw_type_name:
        hw_type = ffmpeg_api.av_hwdevice_find_type_by_name(hw_type_name.encode("utf-8"))
        if hw_type < 0:
            ffmpeg_api.avcodec_free_context(byref(c_void_p(ctx)))
            return False, f"HW device type '{hw_type_name}' not found"
        dref = c_void_p()
        rc = ffmpeg_api.av_hwdevice_ctx_create(byref(dref), hw_type, None, None, 0)
        if rc < 0:
            ffmpeg_api.avcodec_free_context(byref(c_void_p(ctx)))
            return False, f"av_hwdevice_ctx_create failed ({ffmpeg_api.av_strerror_str(rc)})"
        device_ref = dref.value

    ffmpeg_api.configure_codec_context(ctx, hardware=(hw_type_name is not None), device_ref=device_ref)

    # Set 720p dimensions via av_opt_set_int (Part 1 Item 10, ffmpeg.cpp:3-4)
    ffmpeg_api.av_opt_set_int(ctx, b"width", 1280, 0)
    ffmpeg_api.av_opt_set_int(ctx, b"height", 720, 0)

    rc = ffmpeg_api.avcodec_open2(ctx, decoder, None)
    if rc < 0:
        if device_ref:
            ffmpeg_api.av_buffer_unref(byref(c_void_p(device_ref)))
        ffmpeg_api.avcodec_free_context(byref(c_void_p(ctx)))
        return False, f"avcodec_open2 failed ({ffmpeg_api.av_strerror_str(rc)})"

    pkt = ffmpeg_api.av_packet_alloc()
    frame = ffmpeg_api.av_frame_alloc()

    buf = (c_ubyte * (len(test_frame_bytes) + ffmpeg_api.AV_INPUT_BUFFER_PADDING_SIZE)).from_buffer_copy(
        test_frame_bytes + (b"\x00" * ffmpeg_api.AV_INPUT_BUFFER_PADDING_SIZE)
    )
    buf_addr = ctypes.addressof(buf)
    ffmpeg_api.packet_set_data(pkt, buf_addr, len(test_frame_bytes), is_key=True)

    err = -1
    # Up to 5 EAGAIN retries 100 ms apart (ffmpeg.cpp:694-718)
    for _ in range(5):
        err = ffmpeg_api.avcodec_send_packet(ctx, pkt)
        if err < 0:
            break
        err = ffmpeg_api.avcodec_receive_frame(ctx, frame)
        if err == ffmpeg_api.AVERROR_EAGAIN:
            time.sleep(0.1)
        else:
            break

    success = False
    details = ""
    if err == 0:
        fmt = ffmpeg_api.frame_get_format(frame)
        if hw_type_name == "d3d11va":
            if fmt == ffmpeg_api.PIX_FMT_D3D11:
                # Test av_hwframe_transfer_data to NV12 slot (06-phase3-session-video.md §2.3)
                sw_slot = ffmpeg_api.av_frame_alloc()
                ffmpeg_api.frame_set_format(sw_slot, ffmpeg_api.PIX_FMT_NV12)
                tr_rc = ffmpeg_api.av_hwframe_transfer_data(sw_slot, frame, 0)
                ffmpeg_api.av_frame_free(byref(c_void_p(sw_slot)))
                if tr_rc == 0:
                    success = True
                    details = "D3D11VA hardware decode + NV12 readback OK"
                else:
                    details = f"D3D11VA transfer failed ({ffmpeg_api.av_strerror_str(tr_rc)})"
            else:
                details = f"Unexpected format for D3D11VA: {fmt}"
        elif hw_type_name == "dxva2":
            if fmt == ffmpeg_api.PIX_FMT_DXVA2_VLD:
                success = True
                details = "DXVA2 hardware decode OK"
            else:
                details = f"Unexpected format for DXVA2: {fmt}"
        else:
            # Software format must be YUV420P or YUVJ420P
            if fmt in (ffmpeg_api.PIX_FMT_YUV420P, ffmpeg_api.PIX_FMT_YUVJ420P):
                success = True
                details = f"Software decode OK (fmt={fmt})"
            else:
                details = f"Unexpected software format: {fmt}"
    else:
        details = f"Decode failed ({ffmpeg_api.av_strerror_str(err)})"

    ffmpeg_api.av_frame_free(byref(c_void_p(frame)))
    ffmpeg_api.av_packet_free(byref(c_void_p(pkt)))
    if device_ref:
        ffmpeg_api.av_buffer_unref(byref(c_void_p(device_ref)))
    ffmpeg_api.avcodec_free_context(byref(c_void_p(ctx)))

    return success, details


def select_video_decoder(
    settings: StreamSettings,
    server_codec_support: int,
    max_luma_hevc: int = 0,
    width: int = 1920,
    height: int = 1080,
    fps: int = 60,
    use_cache: bool = True,
) -> DecoderConfig:
    """Select the best codec and decoder matching Artemis rules.

    Port of Artemis session.cpp:799-1000, 1077-1130 and ffmpeg.cpp:1560-1692.
    Reference: streaming-technical/06-phase3-session-video.md §2
    """
    # 1. Ensure FFmpeg DLLs loaded (Part A Item B1)
    ffmpeg_api.ensure_ffmpeg_loaded()

    # Candidate order per setting (compare VideoCodec members)
    codec_setting = settings.codec
    if isinstance(codec_setting, str):
        codec_str = codec_setting.strip().upper()
        if codec_str in ("H264", "H.264"):
            codec = VideoCodec.H264
        elif codec_str == "HEVC":
            codec = VideoCodec.HEVC
        elif codec_str == "AV1":
            codec = VideoCodec.AV1
        else:
            codec = VideoCodec.AUTO
    elif isinstance(codec_setting, VideoCodec):
        codec = codec_setting
    else:
        codec = VideoCodec.AUTO

    if codec == VideoCodec.H264:
        candidates = ["H264"]
    elif codec == VideoCodec.HEVC:
        candidates = ["HEVC", "H264"]
    elif codec == VideoCodec.AV1:
        candidates = ["AV1", "HEVC", "H264"]
    else:  # AUTO
        candidates = ["HEVC", "H264"]

    # 2. Filter out codecs host lacks
    available_candidates: list[str] = []
    for c in candidates:
        if c == "HEVC":
            if not (server_codec_support & api.SCM_HEVC):
                logger.info("[Decoder] Host does not support HEVC (SCM_HEVC missing); skipping")
                continue
            if max_luma_hevc > 0 and (width * height) > max_luma_hevc:
                logger.info(
                    f"[Decoder] Stream size {width}x{height} exceeds MaxLumaPixelsHEVC ({max_luma_hevc}); skipping HEVC"
                )
                continue
        elif c == "AV1":
            if not (server_codec_support & api.SCM_AV1_MAIN8):
                logger.info("[Decoder] Host does not support AV1 (SCM_AV1_MAIN8 missing); skipping")
                continue
        available_candidates.append(c)

    if not available_candidates:
        available_candidates = ["H264"]

    # Load cache if enabled
    gpu_id = get_gpu_identifier()
    cache_key = f"{gpu_id}_{ffmpeg_api.avcodec_version()}"
    cache_data: dict[str, dict] = {}
    if use_cache and CACHE_FILE_PATH.exists():
        try:
            cache_data = json.loads(CACHE_FILE_PATH.read_text(encoding="utf-8"))
        except Exception:
            cache_data = {}

    cached_probes = cache_data.get(cache_key, {})

    # Map candidate to test frame and decoders to probe
    codec_meta = {
        "H264": {
            "format": api.VIDEO_FORMAT_H264,
            "test_frame": test_frames.k_H264TestFrame,
            "probes": [
                ("h264", "d3d11va"),
                ("h264", "dxva2"),
                ("h264", None),
            ],
        },
        "HEVC": {
            "format": api.VIDEO_FORMAT_H265,
            "test_frame": test_frames.k_HEVCMainTestFrame,
            "probes": [
                ("hevc", "d3d11va"),
                ("hevc", "dxva2"),
                ("hevc", None),
            ],
        },
        "AV1": {
            "format": api.VIDEO_FORMAT_AV1_MAIN8,
            "test_frame": test_frames.k_AV1Main8TestFrame,
            "probes": [
                ("av1", "d3d11va"),
                ("libdav1d", None),  # Software AV1 uses libdav1d
            ],
        },
    }

    # Execute probes for available candidates
    probed_results: dict[str, list[tuple[str, str | None, bool]]] = {}
    cache_dirty = False

    for c in available_candidates:
        meta = codec_meta[c]
        probed_results[c] = []
        for dec_name, hw_name in meta["probes"]:
            probe_key = f"{c}_{dec_name}_{hw_name}"
            if probe_key in cached_probes:
                success = cached_probes[probe_key]
            else:
                success, details = probe_single_decoder(dec_name, hw_name, meta["test_frame"])
                logger.info(f"[DecoderProbe] {probe_key}: success={success} ({details})")
                cached_probes[probe_key] = success
                cache_dirty = True
            probed_results[c].append((dec_name, hw_name, success))

    if cache_dirty:
        try:
            CACHE_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)
            cache_data[cache_key] = cached_probes
            CACHE_FILE_PATH.write_text(json.dumps(cache_data, indent=2), encoding="utf-8")
        except Exception as e:
            logger.warning(f"[Decoder] Failed to write cache: {e}")

    # 4. Selection: Pick decoder based on settings.video_decoder (AUTO / FORCE_HARDWARE / FORCE_SOFTWARE)
    # Port of Artemis session.cpp:1080-1110 (StreamingPreferences::VDS_*)
    vds = getattr(settings, "video_decoder", "AUTO").upper()
    chosen_codec: str | None = None
    chosen_dec: str | None = None
    chosen_hw: str | None = None

    if vds != "FORCE_SOFTWARE":
        # Search for hardware decoder
        for c in available_candidates:
            for dec_name, hw_name, ok in probed_results[c]:
                if ok and hw_name is not None:
                    chosen_codec = c
                    chosen_dec = dec_name
                    chosen_hw = hw_name
                    break
            if chosen_codec:
                break

    # If software is requested or hardware wasn't found (and FORCE_HARDWARE not strictly demanded)
    if not chosen_codec and vds != "FORCE_HARDWARE":
        if codec == VideoCodec.AUTO:
            chosen_codec = "H264"
        else:
            chosen_codec = available_candidates[0]

        # Find working software decoder
        for dec_name, hw_name, ok in probed_results[chosen_codec]:
            if ok and hw_name is None:
                chosen_dec = dec_name
                chosen_hw = None
                break

    if not chosen_dec:
        # Ultimate fallback
        chosen_codec = "H264"
        chosen_dec = "h264"
        chosen_hw = None

    meta = codec_meta[chosen_codec]
    video_format = meta["format"]

    # 5. Capability calculation (06-phase3-session-video.md §2.5)
    capabilities = api.CAPABILITY_PULL_RENDERER  # 0x20
    if chosen_hw is not None:
        # Hardware: | RFI_HEVC (0x4) | RFI_AV1 (0x40) -> 0x64 (d3d11va.cpp:1207-1211)
        capabilities |= (
            api.CAPABILITY_REFERENCE_FRAME_INVALIDATION_HEVC
            | api.CAPABILITY_REFERENCE_FRAME_INVALIDATION_AV1
        )
    else:
        # Software: | RFI_HEVC | RFI_AV1 | CAPABILITY_SLICES_PER_FRAME(min(4, cpus)) (ffmpeg.cpp:124-170)
        cpu_count = os.cpu_count() or 1
        slices = min(4, cpu_count)
        capabilities |= (
            api.CAPABILITY_REFERENCE_FRAME_INVALIDATION_HEVC
            | api.CAPABILITY_REFERENCE_FRAME_INVALIDATION_AV1
            | api.CAPABILITY_SLICES_PER_FRAME(slices)
        )

    logger.info(
        f"[Decoder] Selected {chosen_codec} (dec={chosen_dec}, hw={chosen_hw}, caps=0x{capabilities:x}) "
        f"for {width}x{height}@{fps}fps"
    )

    return DecoderConfig(
        video_format=video_format,
        capabilities=capabilities,
        color_space=api.COLORSPACE_REC_601,
        color_range=api.COLOR_RANGE_LIMITED,
        decoder_name=chosen_dec,
        hw_device_type_name=chosen_hw,
        width=width,
        height=height,
        fps=fps,
    )


class PullDecoder:
    """Pull video decoder thread consuming decode units from moonlight-common-c.

    Port of Artemis FFmpegVideoDecoder::decoderThreadProc and submitDecodeUnit.
    Source: artemis-pc/app/streaming/video/ffmpeg.cpp:1741-2011.
    Reference: streaming-technical/06-phase3-session-video.md §3
    """

    FAILED_DECODES_RESET_THRESHOLD = 20  # ffmpeg.cpp:61

    def __init__(
        self,
        config: DecoderConfig,
        width: int,
        height: int,
        mailbox: FrameMailbox,
        stats: StatsTracker,
        on_reset_needed: Callable[[], None] | None = None,
        on_frame_ready: Callable[[], None] | None = None,
        api_inst: LimelightApi | None = None,
    ) -> None:
        self._config = config
        self._width = width
        self._height = height
        self._mailbox = mailbox
        self._stats = stats
        self._on_reset_needed = on_reset_needed
        self._on_frame_ready = on_frame_ready
        self._api = api_inst or load_api()

        ffmpeg_api.ensure_ffmpeg_loaded()

        self._quit = threading.Event()
        self._thread: threading.Thread | None = None

        self._frames_in: int = 0
        self._frames_out: int = 0
        self._frames_presented: int = 0
        self._consecutive_failures: int = 0
        self.idr_requests: int = 0

        # Timing queue for matching decode units: deque of (enqueueTimeMs, presentationTimeMs)
        self._frame_info: collections.deque[tuple[int, int]] = collections.deque()

        # Reused buffer for LENTRY concatenation
        self._buf_cap: int = 256 * 1024
        self._buf = (c_ubyte * self._buf_cap)()
        self._buf_addr = ctypes.addressof(self._buf)

        # Initialize FFmpeg decoder
        decoder = ffmpeg_api.avcodec_find_decoder_by_name(config.decoder_name.encode("utf-8"))
        if not decoder:
            raise RuntimeError(f"Decoder '{config.decoder_name}' not found")

        self._ctx = ffmpeg_api.avcodec_alloc_context3(decoder)
        if not self._ctx:
            raise RuntimeError("Failed to allocate AVCodecContext")

        self._device_ref: int | None = None
        if config.hw_device_type_name:
            hw_type = ffmpeg_api.av_hwdevice_find_type_by_name(config.hw_device_type_name.encode("utf-8"))
            dref = c_void_p()
            rc = ffmpeg_api.av_hwdevice_ctx_create(byref(dref), hw_type, None, None, 0)
            if rc < 0:
                self._cleanup_ctx()
                raise RuntimeError(
                    f"av_hwdevice_ctx_create failed: {ffmpeg_api.av_strerror_str(rc)}"
                )
            self._device_ref = dref.value

        ffmpeg_api.configure_codec_context(
            self._ctx,
            hardware=config.is_hardware,
            device_ref=self._device_ref,
            strict_err_detect=config.strict_err_detect,
        )

        ffmpeg_api.av_opt_set_int(self._ctx, b"width", width, 0)
        ffmpeg_api.av_opt_set_int(self._ctx, b"height", height, 0)

        rc = ffmpeg_api.avcodec_open2(self._ctx, decoder, None)
        if rc < 0:
            self._cleanup_ctx()
            raise RuntimeError(f"avcodec_open2 failed: {ffmpeg_api.av_strerror_str(rc)}")

        self._pkt = ffmpeg_api.av_packet_alloc()
        self._frame = ffmpeg_api.av_frame_alloc()
        if not self._pkt or not self._frame:
            self._cleanup_ctx()
            raise MemoryError("Failed to allocate AVPacket or AVFrame")

    @property
    def frames_presented(self) -> int:
        return self._frames_presented

    def _grow(self, need: int) -> None:
        """Grow reused decode buffer."""
        self._buf_cap = max(need, self._buf_cap * 2)
        self._buf = (c_ubyte * self._buf_cap)()
        self._buf_addr = ctypes.addressof(self._buf)

    def start(self) -> None:
        """Start the decoder pull thread."""
        self._thread = threading.Thread(target=self._thread_main, name="VideoDecode", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop the decoder pull thread and clean up FFmpeg contexts (ffmpeg.cpp:286-288)."""
        self._quit.set()
        self._api.LiWakeWaitForVideoFrame()
        if self._thread and self._thread.is_alive():
            self._thread.join()
        self._cleanup_ctx()

    def _cleanup_ctx(self) -> None:
        if hasattr(self, "_frame") and self._frame:
            ptr_f = c_void_p(self._frame)
            ffmpeg_api.av_frame_free(byref(ptr_f))
            self._frame = 0
        if hasattr(self, "_pkt") and self._pkt:
            ptr_p = c_void_p(self._pkt)
            ffmpeg_api.av_packet_free(byref(ptr_p))
            self._pkt = 0
        if hasattr(self, "_device_ref") and self._device_ref:
            ptr_d = c_void_p(self._device_ref)
            ffmpeg_api.av_buffer_unref(byref(ptr_d))
            self._device_ref = None
        if hasattr(self, "_ctx") and self._ctx:
            ptr_c = c_void_p(self._ctx)
            ffmpeg_api.avcodec_free_context(byref(ptr_c))
            self._ctx = 0

    def _thread_main(self) -> None:
        """Port of FFmpegVideoDecoder::decoderThreadProc (ffmpeg.cpp:1741-1900)."""
        # Elevate priority to THREAD_PRIORITY_ABOVE_NORMAL (1)
        if os.name == "nt":
            try:
                ctypes.windll.kernel32.SetThreadPriority(
                    ctypes.windll.kernel32.GetCurrentThread(), 1
                )
            except Exception:
                pass

        handle = c_void_p()
        du_ptr = ctypes.POINTER(api.DECODE_UNIT)()

        while not self._quit.is_set():
            if self._frames_in == self._frames_out:
                if not self._api.LiWaitForNextVideoFrame(byref(handle), byref(du_ptr)):
                    continue
                if self._quit.is_set():
                    self._api.LiCompleteVideoFrame(handle, api.DR_OK)
                    break
                submit_rc = self._submit(du_ptr.contents)
                self._api.LiCompleteVideoFrame(handle, submit_rc)

            if self._frames_in != self._frames_out:
                while True:
                    rc = ffmpeg_api.avcodec_receive_frame(self._ctx, self._frame)
                    if rc == 0:
                        self._frames_out += 1
                        self._on_frame()
                        break
                    if rc == ffmpeg_api.AVERROR_EAGAIN:
                        if self._frames_presented == 0 and (
                            self._frames_in - self._frames_out >= self.FAILED_DECODES_RESET_THRESHOLD
                        ):
                            logger.error(
                                f"[Decoder] Resetting decoder due to EAGAIN starvation "
                                f"({self._frames_in} packets queued, 0 frames produced, "
                                f"dec={self._config.decoder_name}, hw={self._config.hw_device_type_name})"
                            )
                            if self._on_reset_needed:
                                self._on_reset_needed()
                            self._quit.set()
                            break
                        if self._api.LiPollNextVideoFrame(byref(handle), byref(du_ptr)):
                            submit_rc = self._submit(du_ptr.contents)
                            self._api.LiCompleteVideoFrame(handle, submit_rc)
                        else:
                            time.sleep(0.002)  # SDL_Delay(2) (ffmpeg.cpp:1852)
                        if self._quit.is_set():
                            break
                        continue

                    # Real decode error
                    self._consecutive_failures += 1
                    err_str = ffmpeg_api.av_strerror_str(rc)
                    if self._consecutive_failures == 1:
                        logger.warning(
                            f"[Decoder] avcodec_receive_frame failed "
                            f"(dec={self._config.decoder_name}, hw={self._config.hw_device_type_name}): "
                            f"{err_str} ({rc})"
                        )
                    if self._consecutive_failures >= self.FAILED_DECODES_RESET_THRESHOLD:
                        logger.error(
                            f"[Decoder] Resetting decoder due to {self._consecutive_failures} failures "
                            f"(last error: {err_str} [{rc}])"
                        )
                        if self._on_reset_needed:
                            self._on_reset_needed()
                        self._quit.set()
                    self.idr_requests += 1
                    self._api.LiRequestIdrFrame()  # ffmpeg.cpp:1880
                    break

    def _submit(self, du: api.DECODE_UNIT) -> int:
        """Submit a decode unit to FFmpeg.

        Port of FFmpegVideoDecoder::submitDecodeUnit (ffmpeg.cpp:1892-2011).
        """
        # First frame must be an IDR frame (ffmpeg.cpp:1900-1902)
        if self._frames_in == 0 and du.frameType != api.FRAME_TYPE_IDR:
            self.idr_requests += 1
            return api.DR_NEED_IDR

        self._stats.on_submit(du)

        need = du.fullLength + ffmpeg_api.AV_INPUT_BUFFER_PADDING_SIZE
        if need > self._buf_cap:
            self._grow(need)

        # Concatenate LENTRY chain via memmove (no bytes objects on hot path)
        off = 0
        entry = du.bufferList
        while entry:
            e = entry.contents
            if e.length > 0 and e.data:
                ctypes.memmove(self._buf_addr + off, e.data, e.length)
                off += e.length
            entry = e.next

        # Zero input buffer padding
        ctypes.memset(self._buf_addr + off, 0, ffmpeg_api.AV_INPUT_BUFFER_PADDING_SIZE)

        ffmpeg_api.packet_set_data(
            self._pkt,
            self._buf_addr,
            off,
            is_key=(du.frameType == api.FRAME_TYPE_IDR),
        )

        rc = ffmpeg_api.avcodec_send_packet(self._ctx, self._pkt)
        if rc == ffmpeg_api.AVERROR_EAGAIN:
            # Drain pending output frames if FFmpeg's internal output slot is full, then retry once
            while ffmpeg_api.avcodec_receive_frame(self._ctx, self._frame) == 0:
                self._frames_out += 1
                self._frames_in = max(self._frames_in, self._frames_out)
                self._on_frame()
            rc = ffmpeg_api.avcodec_send_packet(self._ctx, self._pkt)

        if rc < 0:
            self._consecutive_failures += 1
            err_str = ffmpeg_api.av_strerror_str(rc)
            if self._consecutive_failures == 1:
                logger.warning(
                    f"[Decoder] avcodec_send_packet failed on frame {du.frameNumber} "
                    f"(type={du.frameType}, size={off}, dec={self._config.decoder_name}, "
                    f"hw={self._config.hw_device_type_name}, strict={self._config.strict_err_detect}): "
                    f"{err_str} ({rc})"
                )
            # Flush buffered decoder state so a half-decoded packet cannot wedge subsequent IDRs with EAGAIN
            ffmpeg_api.avcodec_flush_buffers(self._ctx)
            self._frames_in = 0
            self._frames_out = 0
            self._frame_info.clear()
            if self._consecutive_failures >= self.FAILED_DECODES_RESET_THRESHOLD:
                logger.error(
                    f"[Decoder] Resetting decoder due to {self._consecutive_failures} failures in send_packet "
                    f"(last error: {err_str} [{rc}], dec={self._config.decoder_name}, "
                    f"hw={self._config.hw_device_type_name}, strict={self._config.strict_err_detect})"
                )
                if self._on_reset_needed:
                    self._on_reset_needed()
                self._quit.set()
            return api.DR_NEED_IDR

        self._frame_info.append((du.enqueueTimeMs, du.presentationTimeMs))
        self._frames_in += 1
        return api.DR_OK

    def _on_frame(self) -> None:
        """Handle a successfully decoded AVFrame from avcodec_receive_frame.

        Port of Artemis ffmpeg.cpp:1817-1838.
        """
        if self._frames_presented == 0 and ffmpeg_api.frame_is_corrupt(self._frame):
            if self._frame_info:
                self._frame_info.popleft()
            flags_val = ffmpeg_api.frame_get_flags(self._frame)
            dec_err_val = ffmpeg_api.frame_get_decode_error_flags(self._frame)
            ffmpeg_api.av_frame_unref(self._frame)
            self._consecutive_failures += 1
            if self._consecutive_failures == 1:
                logger.warning(
                    f"[Decoder] Discarding corrupt initial frame "
                    f"(flags=0x{flags_val:X}, decode_error=0x{dec_err_val:X}, "
                    f"dec={self._config.decoder_name}, hw={self._config.hw_device_type_name})"
                )
            self.idr_requests += 1
            self._api.LiRequestIdrFrame()
            if self._consecutive_failures >= self.FAILED_DECODES_RESET_THRESHOLD:
                logger.error(
                    f"[Decoder] Resetting decoder due to {self._consecutive_failures} corrupt initial frames "
                    f"(flags=0x{flags_val:X}, decode_error=0x{dec_err_val:X}, "
                    f"dec={self._config.decoder_name}, hw={self._config.hw_device_type_name})"
                )
                if self._on_reset_needed:
                    self._on_reset_needed()
                self._quit.set()
            return

        now_ms = self._api.LiGetMillis()
        if self._frame_info:
            enq_time, _ = self._frame_info.popleft()
            decode_time_ms = float(now_ms - enq_time)
            self._stats.on_frame_decoded(decode_time_ms)

        slot = self._mailbox.acquire()
        if slot is not None:
            if self._config.is_hardware:
                ffmpeg_api.frame_set_format(slot, ffmpeg_api.PIX_FMT_NV12)
                rc = ffmpeg_api.av_hwframe_transfer_data(slot, self._frame, 0)
                if rc < 0:
                    # Retry with native surface format (e.g. P010LE for 10-bit streams)
                    ffmpeg_api.frame_set_format(slot, -1)
                    rc = ffmpeg_api.av_hwframe_transfer_data(slot, self._frame, 0)
                if rc < 0:
                    self._consecutive_failures += 1
                    err_str = ffmpeg_api.av_strerror_str(rc)
                    if self._consecutive_failures == 1:
                        logger.warning(f"[Decoder] av_hwframe_transfer_data failed: {err_str} ({rc})")
                    self._mailbox.release(slot)
                    ffmpeg_api.av_frame_unref(self._frame)
                    if self._consecutive_failures >= self.FAILED_DECODES_RESET_THRESHOLD:
                        logger.error(
                            f"[Decoder] Resetting decoder due to {self._consecutive_failures} failures in hwframe_transfer "
                            f"(last error: {err_str} [{rc}])"
                        )
                        if self._on_reset_needed:
                            self._on_reset_needed()
                        self._quit.set()
                    return
            else:
                ffmpeg_api.av_frame_ref(slot, self._frame)

        self._consecutive_failures = 0
        self._frames_presented += 1
        ffmpeg_api.av_frame_unref(self._frame)

        if slot is not None:
            needs_event = self._mailbox.publish(slot)
            if needs_event and self._on_frame_ready:
                self._on_frame_ready()
