"""
SdlInputHandler: Unified input manager coordinating keyboard, mouse, and gamepad.

1:1 Python port of Artemis app/streaming/input/input.h and input.cpp.
Reference: streaming-technical/07-phase4-input.md §1, §5
"""

from __future__ import annotations

import logging
from typing import Callable, Optional
import sdl2

from app.core.remote.limelight import api
from app.core.remote.models import StreamSettings
from app.core.remote.stream.input.gamepad import GamepadHandler
from app.core.remote.stream.input.keyboard import (
    CSK_ALWAYS,
    CSK_FULLSCREEN,
    CSK_OFF,
    KeyboardHandler,
)
from app.core.remote.stream.input.mouse import MouseHandler

logger = logging.getLogger(__name__)


class SdlInputHandler:
    """Coordinates keyboard, mouse, and gamepad subsystems for a streaming session."""

    def __init__(
        self,
        api_inst: api.LimelightApi,
        stream_width: int,
        stream_height: int,
        settings: Optional[StreamSettings] = None,
        on_quit: Optional[Callable[[], None]] = None,
        on_toggle_fullscreen: Optional[Callable[[], None]] = None,
        on_toggle_stats: Optional[Callable[[], None]] = None,
        on_paste_text: Optional[Callable[[], None]] = None,
        on_quit_and_exit: Optional[Callable[[], None]] = None,
    ) -> None:
        self._api = api_inst
        self.stream_width = stream_width
        self.stream_height = stream_height
        self._settings = settings

        self._window: Optional[sdl2.SDL_Window] = None

        # Determine settings values with Artemis defaults
        capture_sys_keys_str = getattr(settings, "capture_sys_keys", "off") if settings else "off"
        if capture_sys_keys_str == "fullscreen":
            capture_mode = CSK_FULLSCREEN
        elif capture_sys_keys_str == "always":
            capture_mode = CSK_ALWAYS
        else:
            capture_mode = CSK_OFF

        abs_mouse = bool(getattr(settings, "absolute_mouse", False)) if settings else False
        swap_mouse = bool(getattr(settings, "swap_mouse_buttons", False)) if settings else False
        rev_scroll = bool(getattr(settings, "reverse_scroll", False)) if settings else False
        multi_ctrl = bool(getattr(settings, "multi_controller", True)) if settings else True
        swap_face = bool(getattr(settings, "swap_face_buttons", False)) if settings else False

        # Subsystems
        self.mouse = MouseHandler(
            api_inst=api_inst,
            stream_width=stream_width,
            stream_height=stream_height,
            absolute_mouse_mode=abs_mouse,
            swap_mouse_buttons=swap_mouse,
            reverse_scroll=rev_scroll,
            on_capture_changed=self._on_mouse_capture_changed,
        )

        self.keyboard = KeyboardHandler(
            api_inst=api_inst,
            capture_sys_keys_mode=capture_mode,
            is_capture_active_cb=self.mouse.is_capture_active,
            on_quit=on_quit,
            on_toggle_capture=self._toggle_capture,
            on_toggle_fullscreen=on_toggle_fullscreen,
            on_toggle_stats=on_toggle_stats,
            on_toggle_mouse_mode=self._toggle_mouse_mode,
            on_toggle_cursor_hide=self._toggle_cursor_hide,
            on_minimize=self._minimize_window,
            on_paste_text=on_paste_text,
            on_toggle_pointer_region_lock=self._toggle_pointer_region_lock,
            on_quit_and_exit=on_quit_and_exit,
        )

        self.gamepad = GamepadHandler(
            api_inst=api_inst,
            multi_controller=multi_ctrl,
            swap_face_buttons=swap_face,
            on_quit=on_quit,
            on_toggle_stats=on_toggle_stats,
        )

    def set_window(self, window: Optional[sdl2.SDL_Window]) -> None:
        """Associate SDL Window with input handler (input.cpp:256-259)."""
        self._window = window
        self.keyboard.set_window(window)
        self.mouse.set_window(window)

    def _on_mouse_capture_changed(self, active: bool) -> None:
        """Invoked when mouse capture state changes."""
        self.keyboard.update_keyboard_grab_state()

    def _toggle_capture(self) -> None:
        """Toggle mouse capture on/off (keyboard.cpp:30-41)."""
        new_state = not self.mouse.is_capture_active()
        self.mouse.set_capture_active(new_state)
        self.keyboard.update_keyboard_grab_state()

    def _toggle_mouse_mode(self) -> None:
        """Toggle between relative and absolute mouse modes (keyboard.cpp:61-73)."""
        self.mouse.set_capture_active(False)
        self.mouse.absolute_mouse_mode = not self.mouse.absolute_mouse_mode
        logger.info(
            "Mouse mode toggled: %s",
            "absolute" if self.mouse.absolute_mouse_mode else "relative",
        )
        self.mouse.set_capture_active(True)

    def _toggle_cursor_hide(self) -> None:
        """Toggle cursor visibility in absolute mode (keyboard.cpp:75-87)."""
        if not sdl2.SDL_GetRelativeMouseMode():
            cur = self.mouse.cursor_visible_when_captured
            new_cur = sdl2.SDL_ENABLE if cur == sdl2.SDL_DISABLE else sdl2.SDL_DISABLE
            self.mouse.cursor_visible_when_captured = new_cur
            sdl2.SDL_ShowCursor(new_cur)
        else:
            logger.warning("Cursor can only be shown in remote desktop (absolute) mouse mode")

    def _minimize_window(self) -> None:
        """Minimize stream window (keyboard.cpp:89-93)."""
        if self._window is not None:
            sdl2.SDL_MinimizeWindow(self._window)

    def _toggle_pointer_region_lock(self) -> None:
        """Toggle pointer region lock (keyboard.cpp:129-141)."""
        self.mouse.pointer_region_lock_active = not self.mouse.pointer_region_lock_active
        self.mouse.pointer_region_lock_toggled_by_user = True
        self.mouse.update_pointer_region_lock()

    # ---- Public API Matching Artemis SdlInputHandler ----

    def is_capture_active(self) -> bool:
        return self.mouse.is_capture_active()

    def set_capture_active(self, active: bool) -> None:
        self.mouse.set_capture_active(active)
        self.keyboard.update_keyboard_grab_state()

    def raise_all_keys(self) -> None:
        self.keyboard.raise_all_keys()

    def notify_focus_lost(self) -> None:
        """Handle window focus loss: uncapture if windowed and raise all keys (input.cpp:298-311)."""
        if self._window is not None:
            flags = sdl2.SDL_GetWindowFlags(self._window)
            is_fullscreen = bool(flags & (sdl2.SDL_WINDOW_FULLSCREEN | sdl2.SDL_WINDOW_FULLSCREEN_DESKTOP))
            if not is_fullscreen and not self.mouse.absolute_mouse_mode:
                self.set_capture_active(False)

        self.raise_all_keys()

    def notify_mouse_leave(self) -> None:
        """Handle mouse leaving window bounds (input.cpp:278-296)."""
        self.mouse.notify_mouse_leave()

    def update_keyboard_grab_state(self) -> None:
        self.keyboard.update_keyboard_grab_state()

    def update_pointer_region_lock(self) -> None:
        self.mouse.update_pointer_region_lock()

    # Event Dispatchers

    def handle_key_event(self, ev: sdl2.SDL_KeyboardEvent) -> None:
        self.keyboard.handle_key_event(ev)

    def handle_mouse_button_event(self, ev: sdl2.SDL_MouseButtonEvent) -> None:
        self.mouse.handle_mouse_button_event(ev)

    def handle_mouse_motion_event(self, ev: sdl2.SDL_MouseMotionEvent) -> None:
        self.mouse.handle_mouse_motion_event(ev)

    def handle_mouse_wheel_event(self, ev: sdl2.SDL_MouseWheelEvent) -> None:
        self.mouse.handle_mouse_wheel_event(ev)

    def handle_controller_axis_event(self, ev: sdl2.SDL_ControllerAxisEvent) -> None:
        self.gamepad.handle_controller_axis_event(ev)

    def handle_controller_button_event(self, ev: sdl2.SDL_ControllerButtonEvent) -> None:
        self.gamepad.handle_controller_button_event(ev)

    def handle_controller_device_event(self, ev: sdl2.SDL_ControllerDeviceEvent) -> None:
        self.gamepad.handle_controller_device_event(ev)

    # Controller Feedback

    def rumble(self, controller_number: int, low_freq: int, high_freq: int) -> None:
        self.gamepad.rumble(controller_number, low_freq, high_freq)

    def rumble_triggers(self, controller_number: int, left: int, right: int) -> None:
        self.gamepad.rumble_triggers(controller_number, left, right)

    def set_motion_event_state(self, controller_number: int, motion_type: int, report_rate_hz: int) -> None:
        self.gamepad.set_motion_event_state(controller_number, motion_type, report_rate_hz)

    def set_controller_led(self, controller_number: int, r: int, g: int, b: int) -> None:
        self.gamepad.set_controller_led(controller_number, r, g, b)

    def open_connected_gamepads(self) -> None:
        self.gamepad.open_all_connected()

    def close(self) -> None:
        """Teardown input handler at session end (input.cpp:207-254)."""
        self.set_capture_active(False)
        self.raise_all_keys()
        self.gamepad.close_all()
