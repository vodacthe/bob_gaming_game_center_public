"""
Gamepad event handling, multi-controller mapping, axis batching, and rumble feedback.

1:1 Python port of Artemis app/streaming/input/gamepad.cpp.
Reference: streaming-technical/07-phase4-input.md §4
"""

from __future__ import annotations

import ctypes
from dataclasses import dataclass
import logging
from typing import Any, Callable, List, Optional
import sdl2

from app.core.remote.limelight import api
from app.core.remote.limelight.api import (
    A_FLAG,
    B_FLAG,
    BACK_FLAG,
    DOWN_FLAG,
    LB_FLAG,
    LEFT_FLAG,
    LI_CCAP_ACCEL,
    LI_CCAP_ANALOG_TRIGGERS,
    LI_CCAP_BATTERY_STATE,
    LI_CCAP_GYRO,
    LI_CCAP_RGB_LED,
    LI_CCAP_RUMBLE,
    LI_CCAP_TOUCHPAD,
    LI_CCAP_TRIGGER_RUMBLE,
    LI_CTYPE_NINTENDO,
    LI_CTYPE_PS,
    LI_CTYPE_UNKNOWN,
    LI_CTYPE_XBOX,
    LS_CLK_FLAG,
    MISC_FLAG,
    PADDLE1_FLAG,
    PADDLE2_FLAG,
    PADDLE3_FLAG,
    PADDLE4_FLAG,
    PLAY_FLAG,
    RB_FLAG,
    RIGHT_FLAG,
    RS_CLK_FLAG,
    SPECIAL_FLAG,
    TOUCHPAD_FLAG,
    UP_FLAG,
    X_FLAG,
    Y_FLAG,
)
from app.core.remote.stream.input.keyboard import s16

logger = logging.getLogger(__name__)

K_BUTTON_MAP: list[int] = [
    A_FLAG,
    B_FLAG,
    X_FLAG,
    Y_FLAG,
    BACK_FLAG,
    SPECIAL_FLAG,
    PLAY_FLAG,
    LS_CLK_FLAG,
    RS_CLK_FLAG,
    LB_FLAG,
    RB_FLAG,
    UP_FLAG,
    DOWN_FLAG,
    LEFT_FLAG,
    RIGHT_FLAG,
    MISC_FLAG,
    PADDLE1_FLAG,
    PADDLE2_FLAG,
    PADDLE3_FLAG,
    PADDLE4_FLAG,
    TOUCHPAD_FLAG,
]

MAX_GAMEPADS = 16


@dataclass
class GamepadState:
    controller: Any = None
    js_id: int = -1
    index: int = -1
    buttons: int = 0
    lt: int = 0
    rt: int = 0
    ls_x: int = 0
    ls_y: int = 0
    rs_x: int = 0
    rs_y: int = 0
    clickpad_emulation_enabled: bool = False
    emulated_clickpad_button_down: bool = False
    accel_period_ms: int = 0
    gyro_period_ms: int = 0


class GamepadHandler:
    """Manages SDL GameController events, capabilities, state dispatch, and rumble."""

    def __init__(
        self,
        api_inst: api.LimelightApi,
        multi_controller: bool = True,
        swap_face_buttons: bool = False,
        on_quit: Optional[Callable[[], None]] = None,
        on_toggle_stats: Optional[Callable[[], None]] = None,
    ) -> None:
        self._api = api_inst
        self.multi_controller = multi_controller
        self.swap_face_buttons = swap_face_buttons
        self._on_quit = on_quit
        self._on_toggle_stats = on_toggle_stats

        self.gamepad_states: List[GamepadState] = [GamepadState() for _ in range(MAX_GAMEPADS)]
        self.gamepad_mask: int = self.get_attached_gamepad_mask(self.multi_controller)

    @classmethod
    def get_attached_gamepad_mask(cls, multi_controller: bool = True) -> int:
        """Calculate bitmask of attached controllers (gamepad.cpp:996-1022, 624-638).

        Returns 0 when no controller is attached.
        """
        mask = 0
        count = 0
        try:
            num = sdl2.SDL_NumJoysticks()
            for i in range(num):
                if sdl2.SDL_IsGameController(i):
                    if not multi_controller:
                        return 0x1
                    mask |= 1 << count
                    count += 1
                    if count >= MAX_GAMEPADS:
                        break
        except Exception:
            pass

        return mask

    def find_state_for_gamepad(self, js_id: int) -> Optional[GamepadState]:
        """Find state slot corresponding to SDL Joystick ID (gamepad.cpp:37-52)."""
        for state in self.gamepad_states:
            if state.controller is not None and state.js_id == js_id:
                return state
        return None

    def open_all_connected(self) -> None:
        """Scan and open all connected game controllers at session start."""
        sdl2.SDL_FlushEvents(sdl2.SDL_CONTROLLERDEVICEADDED, sdl2.SDL_CONTROLLERDEVICEREMOVED)
        num = sdl2.SDL_NumJoysticks()
        for i in range(num):
            if sdl2.SDL_IsGameController(i):
                ev = sdl2.SDL_ControllerDeviceEvent()
                ev.type = sdl2.SDL_CONTROLLERDEVICEADDED
                ev.which = i
                self.handle_controller_device_event(ev)

    def close_all(self) -> None:
        """Close all controllers on teardown."""
        for state in self.gamepad_states:
            if state.controller is not None:
                try:
                    sdl2.SDL_GameControllerClose(state.controller)
                except Exception:
                    pass
                state.controller = None
                state.js_id = -1
                state.index = -1
                state.buttons = 0

    def handle_controller_device_event(self, ev: sdl2.SDL_ControllerDeviceEvent) -> None:
        """Process controller connection / removal events (gamepad.cpp:640-774)."""
        if ev.type == sdl2.SDL_CONTROLLERDEVICEADDED:
            pad = sdl2.SDL_GameControllerOpen(ev.which)
            if not pad:
                logger.warning("SDL_GameControllerOpen failed for device %d", ev.which)
                return

            js = sdl2.SDL_GameControllerGetJoystick(pad)
            js_id = sdl2.SDL_JoystickInstanceID(js) if js else -1

            # Duplicate guard: avoid re-adding an already open controller (Part 2 Item 21)
            for st in self.gamepad_states:
                if st.controller is not None and (st.controller == pad or (js_id != -1 and st.js_id == js_id)):
                    logger.debug("Controller device %d (js_id %d) already registered, skipping duplicate", ev.which, js_id)
                    sdl2.SDL_GameControllerClose(pad)
                    return

            # Find free slot
            slot = -1
            for i, st in enumerate(self.gamepad_states):
                if st.controller is None:
                    slot = i
                    break

            if slot < 0:
                logger.warning("No free gamepad slot for controller device %d", ev.which)
                sdl2.SDL_GameControllerClose(pad)
                return

            state = self.gamepad_states[slot]
            state.controller = pad
            state.js_id = js_id
            state.index = slot if self.multi_controller else 0

            sdl2.SDL_GameControllerSetPlayerIndex(pad, state.index)

            # Update gamepad mask
            if self.multi_controller:
                self.gamepad_mask |= 1 << state.index
            else:
                self.gamepad_mask = 0x1

            # 2. Query capabilities and type (gamepad.cpp:655-725)
            supported_buttons = 0
            for btn_idx, flag in enumerate(K_BUTTON_MAP):
                if sdl2.SDL_GameControllerHasButton(pad, btn_idx):
                    supported_buttons |= flag

            caps = 0
            bind_l = sdl2.SDL_GameControllerGetBindForAxis(pad, sdl2.SDL_CONTROLLER_AXIS_TRIGGERLEFT)
            bind_r = sdl2.SDL_GameControllerGetBindForAxis(pad, sdl2.SDL_CONTROLLER_AXIS_TRIGGERRIGHT)
            bind_axis_type = getattr(sdl2, "SDL_CONTROLLER_BINDTYPE_AXIS", 1)
            if bind_l.bindType == bind_axis_type or bind_r.bindType == bind_axis_type:
                caps |= LI_CCAP_ANALOG_TRIGGERS

            if hasattr(sdl2, "SDL_GameControllerHasRumble") and sdl2.SDL_GameControllerHasRumble(pad):
                caps |= LI_CCAP_RUMBLE

            if hasattr(sdl2, "SDL_GameControllerHasRumbleTriggers") and sdl2.SDL_GameControllerHasRumbleTriggers(pad):
                caps |= LI_CCAP_TRIGGER_RUMBLE

            if hasattr(sdl2, "SDL_GameControllerGetNumTouchpads") and sdl2.SDL_GameControllerGetNumTouchpads(pad) > 0:
                caps |= LI_CCAP_TOUCHPAD

            if hasattr(sdl2, "SDL_GameControllerHasSensor"):
                accel_sensor = getattr(sdl2, "SDL_SENSOR_ACCEL", 1)
                gyro_sensor = getattr(sdl2, "SDL_SENSOR_GYRO", 2)
                if sdl2.SDL_GameControllerHasSensor(pad, accel_sensor):
                    caps |= LI_CCAP_ACCEL
                if sdl2.SDL_GameControllerHasSensor(pad, gyro_sensor):
                    caps |= LI_CCAP_GYRO

            caps |= LI_CCAP_BATTERY_STATE

            if hasattr(sdl2, "SDL_GameControllerHasLED") and sdl2.SDL_GameControllerHasLED(pad):
                caps |= LI_CCAP_RGB_LED

            raw_type = sdl2.SDL_GameControllerGetType(pad)
            type_xbox360 = getattr(sdl2, "SDL_CONTROLLER_TYPE_XBOX360", 1)
            type_xboxone = getattr(sdl2, "SDL_CONTROLLER_TYPE_XBOXONE", 2)
            type_ps3 = getattr(sdl2, "SDL_CONTROLLER_TYPE_PS3", 3)
            type_ps4 = getattr(sdl2, "SDL_CONTROLLER_TYPE_PS4", 4)
            type_ps5 = getattr(sdl2, "SDL_CONTROLLER_TYPE_PS5", 5)
            type_switch = getattr(sdl2, "SDL_CONTROLLER_TYPE_NINTENDO_SWITCH_PRO", 6)

            if raw_type in (type_xbox360, type_xboxone):
                c_type = LI_CTYPE_XBOX
            elif raw_type in (type_ps3, type_ps4, type_ps5):
                c_type = LI_CTYPE_PS
            elif raw_type == type_switch:
                c_type = LI_CTYPE_NINTENDO
            else:
                c_type = LI_CTYPE_UNKNOWN

            touchpad_btn = getattr(sdl2, "SDL_CONTROLLER_BUTTON_TOUCHPAD", 20)
            bind_none = getattr(sdl2, "SDL_CONTROLLER_BINDTYPE_NONE", 0)
            bind_touchpad = sdl2.SDL_GameControllerGetBindForButton(pad, touchpad_btn)
            state.clickpad_emulation_enabled = (c_type == LI_CTYPE_PS and bind_touchpad.bindType == bind_none)

            logger.info(
                "Gamepad added slot=%d index=%d js_id=%d type=%d caps=0x%04X mask=0x%04X",
                slot,
                state.index,
                state.js_id,
                c_type,
                caps,
                self.gamepad_mask,
            )

            # Send controller arrival event (gamepad.cpp:725)
            self._api.LiSendControllerArrivalEvent(
                state.index,
                self.gamepad_mask,
                c_type,
                supported_buttons,
                caps,
            )

        elif ev.type == sdl2.SDL_CONTROLLERDEVICEREMOVED:
            state = self.find_state_for_gamepad(ev.which)
            if state is not None:
                logger.info("Gamepad removed index=%d js_id=%d", state.index, state.js_id)
                sdl2.SDL_GameControllerClose(state.controller)

                idx = state.index
                if self.multi_controller:
                    self.gamepad_mask &= ~(1 << idx)
                else:
                    self.gamepad_mask = 0x1

                # Send final event informing host of removal (gamepad.cpp:767-769)
                self._api.LiSendMultiControllerEvent(idx, self.gamepad_mask, 0, 0, 0, 0, 0, 0, 0)

                # Reset state
                state.controller = None
                state.js_id = -1
                state.index = -1
                state.buttons = 0
                state.lt = 0
                state.rt = 0
                state.ls_x = 0
                state.ls_y = 0
                state.rs_x = 0
                state.rs_y = 0

    def _apply_axis(self, state: GamepadState, axis: int, value: int) -> None:
        """Update single axis on GamepadState with overflow guard (gamepad.cpp:202-232)."""
        if axis == sdl2.SDL_CONTROLLER_AXIS_LEFTX:
            state.ls_x = value
        elif axis == sdl2.SDL_CONTROLLER_AXIS_LEFTY:
            # Avoid -32768 overflow when inverting sign (gamepad.cpp:213)
            state.ls_y = -max(value, -32767)
        elif axis == sdl2.SDL_CONTROLLER_AXIS_RIGHTX:
            state.rs_x = value
        elif axis == sdl2.SDL_CONTROLLER_AXIS_RIGHTY:
            state.rs_y = -max(value, -32767)
        elif axis == sdl2.SDL_CONTROLLER_AXIS_TRIGGERLEFT:
            state.lt = max(0, min(255, int(value * 255 // 32767)))
        elif axis == sdl2.SDL_CONTROLLER_AXIS_TRIGGERRIGHT:
            state.rt = max(0, min(255, int(value * 255 // 32767)))

    def handle_controller_axis_event(self, ev: sdl2.SDL_ControllerAxisEvent) -> None:
        """Process axis motion with batching across queued events (gamepad.cpp:191-253)."""
        state = self.find_state_for_gamepad(ev.which)
        if state is None:
            return

        self._apply_axis(state, ev.axis, ev.value)

        # Batch all pending axis events for this controller (gamepad.cpp:200-247)
        next_ev = sdl2.SDL_Event()
        while sdl2.SDL_PeepEvents(
            ctypes.pointer(next_ev),
            1,
            sdl2.SDL_PEEKEVENT,
            sdl2.SDL_CONTROLLERAXISMOTION,
            sdl2.SDL_CONTROLLERAXISMOTION,
        ) > 0:
            if next_ev.caxis.which != ev.which:
                break
            sdl2.SDL_PeepEvents(
                ctypes.pointer(next_ev),
                1,
                sdl2.SDL_GETEVENT,
                sdl2.SDL_CONTROLLERAXISMOTION,
                sdl2.SDL_CONTROLLERAXISMOTION,
            )
            self._apply_axis(state, next_ev.caxis.axis, next_ev.caxis.value)

        self.send_gamepad_state(state)

    def handle_controller_button_event(self, ev: sdl2.SDL_ControllerButtonEvent) -> None:
        """Process button press/release and check gamepad combos (gamepad.cpp:255-416)."""
        btn = ev.button
        if btn >= len(K_BUTTON_MAP):
            return

        state = self.find_state_for_gamepad(ev.which)
        if state is None:
            return

        # Swap face buttons if enabled (Nintendo layout, gamepad.cpp:269-284)
        if self.swap_face_buttons:
            if btn == sdl2.SDL_CONTROLLER_BUTTON_A:
                btn = sdl2.SDL_CONTROLLER_BUTTON_B
            elif btn == sdl2.SDL_CONTROLLER_BUTTON_B:
                btn = sdl2.SDL_CONTROLLER_BUTTON_A
            elif btn == sdl2.SDL_CONTROLLER_BUTTON_X:
                btn = sdl2.SDL_CONTROLLER_BUTTON_Y
            elif btn == sdl2.SDL_CONTROLLER_BUTTON_Y:
                btn = sdl2.SDL_CONTROLLER_BUTTON_X

        flag = K_BUTTON_MAP[btn]
        if ev.state == sdl2.SDL_PRESSED:
            state.buttons |= flag
        else:
            state.buttons &= ~flag

        # 1. Start+Select+LB+RB: Gamepad quit combo (gamepad.cpp:367-381)
        if state.buttons == (PLAY_FLAG | BACK_FLAG | LB_FLAG | RB_FLAG):
            logger.info("Detected quit gamepad button combo (Start+Select+LB+RB)")
            if self._on_quit:
                self._on_quit()
            self._api.LiSendMultiControllerEvent(state.index, self.gamepad_mask, 0, 0, 0, 0, 0, 0, 0)
            return

        # 2. Select+LB+RB+X: Toggle stats overlay combo (gamepad.cpp:384-396)
        if state.buttons == (BACK_FLAG | LB_FLAG | RB_FLAG | X_FLAG):
            logger.info("Detected stats toggle gamepad combo (Select+LB+RB+X)")
            if self._on_toggle_stats:
                self._on_toggle_stats()
            self._api.LiSendMultiControllerEvent(state.index, self.gamepad_mask, 0, 0, 0, 0, 0, 0, 0)
            return

        self.send_gamepad_state(state)

    def send_gamepad_state(self, state: GamepadState) -> None:
        """Compose and submit controller state to host via LiSendMultiControllerEvent (gamepad.cpp:54-113)."""
        buttons = state.buttons

        # PlayStation Select+PS clickpad emulation (gamepad.cpp:58-69)
        if state.clickpad_emulation_enabled:
            if state.buttons == (BACK_FLAG | SPECIAL_FLAG):
                buttons = MISC_FLAG
                state.emulated_clickpad_button_down = True
            elif state.emulated_clickpad_button_down:
                buttons &= ~MISC_FLAG
                state.emulated_clickpad_button_down = False

        lt = state.lt
        rt = state.rt
        ls_x = state.ls_x
        ls_y = state.ls_y
        rs_x = state.rs_x
        rs_y = state.rs_y

        # In single-controller mode, merge all active pads together (gamepad.cpp:78-102)
        if not self.multi_controller:
            for other in self.gamepad_states:
                if other.controller is not None and other.index == state.index:
                    buttons |= other.buttons
                    if lt < other.lt:
                        lt = other.lt
                    if rt < other.rt:
                        rt = other.rt
                    if abs(ls_x) < abs(other.ls_x) or abs(ls_y) < abs(other.ls_y):
                        ls_x = other.ls_x
                        ls_y = other.ls_y
                    if abs(rs_x) < abs(other.rs_x) or abs(rs_y) < abs(other.rs_y):
                        rs_x = other.rs_x
                        rs_y = other.rs_y

        active_mask = self.gamepad_mask
        if active_mask == 0 and state.controller is not None:
            active_mask = (1 << state.index) if self.multi_controller else 0x1

        self._api.LiSendMultiControllerEvent(
            s16(state.index),
            s16(active_mask),
            buttons,
            lt,
            rt,
            s16(ls_x),
            s16(ls_y),
            s16(rs_x),
            s16(rs_y),
        )

    # ---- Host -> Client Feedback Callbacks (gamepad.cpp:805-931) ----

    def rumble(self, controller_number: int, low_freq: int, high_freq: int) -> None:
        """Trigger vibration motor on specified controller (gamepad.cpp:805-861)."""
        if controller_number >= MAX_GAMEPADS:
            return
        state = self.gamepad_states[controller_number]
        if state.controller is not None:
            sdl2.SDL_GameControllerRumble(state.controller, low_freq, high_freq, 30000)

    def rumble_triggers(self, controller_number: int, left: int, right: int) -> None:
        """Trigger impulse triggers on Xbox One / Series pads (gamepad.cpp:863-875)."""
        if controller_number >= MAX_GAMEPADS:
            return
        state = self.gamepad_states[controller_number]
        if state.controller is not None and hasattr(sdl2, "SDL_GameControllerRumbleTriggers"):
            sdl2.SDL_GameControllerRumbleTriggers(state.controller, left, right, 30000)

    def set_motion_event_state(self, controller_number: int, motion_type: int, report_rate_hz: int) -> None:
        """Enable or disable accelerometer / gyroscope sensor reporting (gamepad.cpp:877-901)."""
        if controller_number >= MAX_GAMEPADS:
            return
        state = self.gamepad_states[controller_number]
        if state.controller is not None and hasattr(sdl2, "SDL_GameControllerSetSensorEnabled"):
            accel_sensor = getattr(sdl2, "SDL_SENSOR_ACCEL", 1)
            gyro_sensor = getattr(sdl2, "SDL_SENSOR_GYRO", 2)
            period_ms = (1000 // report_rate_hz) if report_rate_hz else 0
            if motion_type == LI_CCAP_ACCEL or motion_type == 1:
                state.accel_period_ms = period_ms
                sdl2.SDL_GameControllerSetSensorEnabled(
                    state.controller, accel_sensor, sdl2.SDL_TRUE if report_rate_hz else sdl2.SDL_FALSE
                )
            elif motion_type == LI_CCAP_GYRO or motion_type == 2:
                state.gyro_period_ms = period_ms
                sdl2.SDL_GameControllerSetSensorEnabled(
                    state.controller, gyro_sensor, sdl2.SDL_TRUE if report_rate_hz else sdl2.SDL_FALSE
                )

    def set_controller_led(self, controller_number: int, r: int, g: int, b: int) -> None:
        """Set controller lightbar / LED colour (gamepad.cpp:903-915)."""
        if controller_number >= MAX_GAMEPADS:
            return
        state = self.gamepad_states[controller_number]
        if state.controller is not None and hasattr(sdl2, "SDL_GameControllerSetLED"):
            sdl2.SDL_GameControllerSetLED(state.controller, r, g, b)


# Backwards compatibility alias
SdlGamepadHandler = GamepadHandler
