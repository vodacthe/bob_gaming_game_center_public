"""Stream input handling package (Phase 4).

Port of Artemis app/streaming/input/* (keyboard, mouse, gamepad, SdlInputHandler).
"""
