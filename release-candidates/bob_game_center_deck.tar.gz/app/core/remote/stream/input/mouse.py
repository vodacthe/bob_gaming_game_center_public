"""
Mouse event handling, capture management, relative raw input, and absolute position mapping.

1:1 Python port of Artemis app/streaming/input/mouse.cpp and input.cpp:278-429.
Reference: streaming-technical/07-phase4-input.md §3
"""

from __future__ import annotations

import ctypes
from ctypes import byref, c_int
import logging
from typing import Callable, Optional
import sdl2

from app.core.remote.limelight import api
from app.core.remote.stream.input.keyboard import s16
from app.core.remote.stream.window import scale_source_to_destination

logger = logging.getLogger(__name__)

# Moonlight mouse button codes (Limelight.h / mouse.cpp:34-51)
BUTTON_LEFT = 1
BUTTON_MIDDLE = 2
BUTTON_RIGHT = 3
BUTTON_X1 = 4
BUTTON_X2 = 5


class MouseHandler:
    """Handles relative and absolute mouse motion, button events, scrolling, and cursor capture."""

    def __init__(
        self,
        api_inst: api.LimelightApi,
        stream_width: int,
        stream_height: int,
        absolute_mouse_mode: bool = False,
        swap_mouse_buttons: bool = False,
        reverse_scroll: bool = False,
        on_capture_changed: Optional[Callable[[bool], None]] = None,
    ) -> None:
        self._api = api_inst
        self.stream_width = stream_width
        self.stream_height = stream_height
        self.absolute_mouse_mode = absolute_mouse_mode
        self.swap_mouse_buttons = swap_mouse_buttons
        self.reverse_scroll = reverse_scroll
        self._on_capture_changed = on_capture_changed

        self._window: Optional[sdl2.SDL_Window] = None

        # Capture & region tracking (input.h:211-224, input.cpp:20-35)
        self.fake_capture_active: bool = False
        self.cursor_visible_when_captured: int = sdl2.SDL_DISABLE
        self.mouse_was_in_video_region: bool = False
        self.pending_buttons_up_on_leave: bool = False
        self.pointer_region_lock_active: bool = False
        self.pointer_region_lock_toggled_by_user: bool = False

    def set_window(self, window: Optional[sdl2.SDL_Window]) -> None:
        self._window = window

    def is_capture_active(self) -> bool:
        """Check if mouse cursor is currently captured (input.cpp:313-321)."""
        if sdl2.SDL_GetRelativeMouseMode():
            return True
        return self.fake_capture_active

    def set_capture_active(self, active: bool) -> None:
        """Enable or disable mouse capture (input.cpp:377-429)."""
        if active:
            # If in relative mode, attempt to enable SDL's relative mouse mode (Raw Input)
            if self.absolute_mouse_mode or sdl2.SDL_SetRelativeMouseMode(sdl2.SDL_TRUE) < 0:
                sdl2.SDL_ShowCursor(self.cursor_visible_when_captured)
                self.fake_capture_active = True

            # Synchronize cursor when activating absolute capture (input.cpp:387-411)
            if self.absolute_mouse_mode and self._window is not None:
                gx, gy = c_int(), c_int()
                wx, wy = c_int(), c_int()
                sdl2.SDL_GetGlobalMouseState(byref(gx), byref(gy))
                sdl2.SDL_GetWindowPosition(self._window, byref(wx), byref(wy))
                mx = gx.value - wx.value
                my = gy.value - wy.value

                if self.is_mouse_in_video_region(mx, my):
                    motion_ev = sdl2.SDL_MouseMotionEvent()
                    motion_ev.type = sdl2.SDL_MOUSEMOTION
                    motion_ev.timestamp = sdl2.SDL_GetTicks()
                    motion_ev.windowID = sdl2.SDL_GetWindowID(self._window)
                    motion_ev.x = mx
                    motion_ev.y = my
                    motion_ev.xrel = 0
                    motion_ev.yrel = 0
                    self.handle_mouse_motion_event(motion_ev)
        else:
            if self.fake_capture_active:
                sdl2.SDL_ShowCursor(sdl2.SDL_ENABLE)
                self.fake_capture_active = False
            else:
                sdl2.SDL_SetRelativeMouseMode(sdl2.SDL_FALSE)

        self.update_pointer_region_lock()

        if self._on_capture_changed:
            self._on_capture_changed(self.is_capture_active())

    def is_mouse_in_video_region(
        self,
        mouse_x: int,
        mouse_y: int,
        window_width: int = -1,
        window_height: int = -1,
    ) -> bool:
        """Check if mouse coordinate lies inside the letterboxed video viewport (mouse.cpp:238-259)."""
        if self._window is None:
            return False

        if window_width < 0 or window_height < 0:
            ww, wh = c_int(), c_int()
            sdl2.SDL_GetWindowSize(self._window, ctypes.pointer(ww), ctypes.pointer(wh))
            window_width, window_height = ww.value, wh.value

        src = (0, 0, self.stream_width, self.stream_height)
        dst = (0, 0, window_width, window_height)
        scaled_x, scaled_y, scaled_w, scaled_h = scale_source_to_destination(src, dst)

        return (
            (scaled_x <= mouse_x <= scaled_x + scaled_w)
            and (scaled_y <= mouse_y <= scaled_y + scaled_h)
        )

    def handle_mouse_button_event(self, ev: sdl2.SDL_MouseButtonEvent) -> None:
        """Process mouse press/release (mouse.cpp:7-69)."""
        # Ignore synthetic touch events (mouse.cpp:11-14)
        if getattr(ev, "which", 0) == getattr(sdl2, "SDL_TOUCH_MOUSEID", -1):
            return

        is_captured = self.is_capture_active()
        in_region = self.is_mouse_in_video_region(ev.x, ev.y)

        if not is_captured:
            # Re-capture on left-button release inside the video region (mouse.cpp:15-28)
            if ev.button == sdl2.SDL_BUTTON_LEFT and ev.state == sdl2.SDL_RELEASED and in_region:
                self.set_capture_active(True)
            return

        if self.absolute_mouse_mode and not in_region and ev.state == sdl2.SDL_PRESSED:
            # In absolute mode, ignore presses outside video region (mouse.cpp:29-32)
            return

        button_map = {
            sdl2.SDL_BUTTON_LEFT: BUTTON_LEFT,
            sdl2.SDL_BUTTON_MIDDLE: BUTTON_MIDDLE,
            sdl2.SDL_BUTTON_RIGHT: BUTTON_RIGHT,
            sdl2.SDL_BUTTON_X1: BUTTON_X1,
            sdl2.SDL_BUTTON_X2: BUTTON_X2,
        }
        btn = button_map.get(ev.button)
        if btn is None:
            logger.debug("Unhandled mouse button event: %d", ev.button)
            return

        # Swap left and right buttons if enabled (mouse.cpp:58-63)
        if self.swap_mouse_buttons:
            if btn == BUTTON_RIGHT:
                btn = BUTTON_LEFT
            elif btn == BUTTON_LEFT:
                btn = BUTTON_RIGHT

        action = api.BUTTON_ACTION_PRESS if ev.state == sdl2.SDL_PRESSED else api.BUTTON_ACTION_RELEASE
        self._api.LiSendMouseButtonEvent(action, btn)

    def handle_mouse_motion_event(self, ev: sdl2.SDL_MouseMotionEvent) -> None:
        """Process mouse motion with batching / coalescing (mouse.cpp:71-155)."""
        if not self.is_capture_active():
            return

        touch_id = getattr(sdl2, "SDL_TOUCH_MOUSEID", -1)
        if getattr(ev, "which", 0) == touch_id:
            return

        # Coalesce all pending motion events to minimize latency & CPU overhead (mouse.cpp:82-95)
        x = ev.x
        y = ev.y
        xrel = ev.xrel
        yrel = ev.yrel

        next_ev = sdl2.SDL_Event()
        while sdl2.SDL_PeepEvents(ctypes.pointer(next_ev), 1, sdl2.SDL_GETEVENT, sdl2.SDL_MOUSEMOTION, sdl2.SDL_MOUSEMOTION) > 0:
            if getattr(next_ev.motion, "which", 0) != touch_id:
                x = next_ev.motion.x
                y = next_ev.motion.y
                xrel += next_ev.motion.xrel
                yrel += next_ev.motion.yrel

        if self.absolute_mouse_mode:
            # Absolute mode mapping (mouse.cpp:100-151)
            if self._window is None:
                return

            ww, wh = c_int(), c_int()
            sdl2.SDL_GetWindowSize(self._window, ctypes.pointer(ww), ctypes.pointer(wh))
            window_width, window_height = ww.value, wh.value

            src = (0, 0, self.stream_width, self.stream_height)
            dst = (0, 0, window_width, window_height)
            dst_x, dst_y, dst_w, dst_h = scale_source_to_destination(src, dst)

            mouse_in_region = self.is_mouse_in_video_region(x, y, window_width, window_height)

            # Clamp coordinates to the video viewport
            clamped_x = min(max(x - dst_x, 0), dst_w)
            clamped_y = min(max(y - dst_y, 0), dst_h)

            button_state = sdl2.SDL_GetMouseState(None, None)
            if button_state == 0 and self.pending_buttons_up_on_leave:
                sdl2.SDL_CaptureMouse(sdl2.SDL_FALSE)
                self.pending_buttons_up_on_leave = False

            # Send position if in region, just left, or still dragging (mouse.cpp:128-138)
            if mouse_in_region or self.mouse_was_in_video_region or self.pending_buttons_up_on_leave:
                self._api.LiSendMousePositionEvent(s16(clamped_x), s16(clamped_y), dst_w, dst_h)

            # Toggle cursor visibility when entering/leaving video boundary (mouse.cpp:140-149)
            if mouse_in_region ^ self.mouse_was_in_video_region:
                cur_mode = (
                    sdl2.SDL_DISABLE
                    if (mouse_in_region and self.cursor_visible_when_captured == sdl2.SDL_DISABLE)
                    else sdl2.SDL_ENABLE
                )
                sdl2.SDL_ShowCursor(cur_mode)
                if not mouse_in_region and button_state != 0:
                    self.pending_buttons_up_on_leave = True

            self.mouse_was_in_video_region = mouse_in_region
        else:
            # Relative mode: raw deltas clamped to 16-bit signed integer (mouse.cpp:153)
            cxrel = s16(max(min(xrel, 32767), -32768))
            cyrel = s16(max(min(yrel, 32767), -32768))
            self._api.LiSendMouseMoveEvent(cxrel, cyrel)

    def handle_mouse_wheel_event(self, ev: sdl2.SDL_MouseWheelEvent) -> None:
        """Process mouse wheel / high-resolution scrolling (mouse.cpp:157-236)."""
        if not self.is_capture_active():
            return

        if getattr(ev, "which", 0) == getattr(sdl2, "SDL_TOUCH_MOUSEID", -1):
            return

        if self.absolute_mouse_mode and self._window is not None:
            mx, my = c_int(), c_int()
            sdl2.SDL_GetMouseState(ctypes.pointer(mx), ctypes.pointer(my))
            if not self.is_mouse_in_video_region(mx.value, my.value):
                return

        precise_y = float(getattr(ev, "preciseY", ev.y))
        precise_x = float(getattr(ev, "preciseX", ev.x))

        if precise_y != 0.0:
            if self.reverse_scroll:
                precise_y = -precise_y
            self._api.LiSendHighResScrollEvent(s16(int(round(precise_y * 120))))

        if precise_x != 0.0:
            if self.reverse_scroll:
                # Fix Artemis copy-paste bug (mouse.cpp:197 negated preciseY instead of preciseX)
                precise_x = -precise_x
            self._api.LiSendHighResHScrollEvent(s16(int(round(precise_x * 120))))

    def update_pointer_region_lock(self) -> None:
        """Constrain mouse pointer to video region in fullscreen or toggled lock (mouse.cpp:261-310)."""
        if self._window is None:
            return

        # Irrelevant in relative mode
        if sdl2.SDL_GetRelativeMouseMode():
            return

        if not self.pointer_region_lock_toggled_by_user:
            flags = sdl2.SDL_GetWindowFlags(self._window)
            self.pointer_region_lock_active = bool(
                (flags & sdl2.SDL_WINDOW_FULLSCREEN_DESKTOP) == sdl2.SDL_WINDOW_FULLSCREEN
            )

        if self.is_capture_active() and self.pointer_region_lock_active:
            ww, wh = c_int(), c_int()
            sdl2.SDL_GetWindowSize(self._window, ctypes.pointer(ww), ctypes.pointer(wh))
            src = (0, 0, self.stream_width, self.stream_height)
            dst = (0, 0, ww.value, wh.value)
            scaled_x, scaled_y, scaled_w, scaled_h = scale_source_to_destination(src, dst)
            rect = sdl2.SDL_Rect(scaled_x, scaled_y, scaled_w, scaled_h)
            sdl2.SDL_SetWindowMouseRect(self._window, byref(rect))
        else:
            sdl2.SDL_SetWindowMouseRect(self._window, None)

    def notify_mouse_leave(self) -> None:
        """Handle window mouse leave for smooth dragging (input.cpp:278-296)."""
        if self.absolute_mouse_mode and self.is_capture_active():
            button_state = sdl2.SDL_GetMouseState(None, None)
            if button_state != 0:
                sdl2.SDL_CaptureMouse(sdl2.SDL_TRUE)
