# Reference implementation for app/core/remote/stream/input/keyboard_map.py (copy verbatim).
# Port of artemis-pc/app/streaming/input/keyboard.cpp:172-476 (SdlInputHandler::handleKeyEvent mapping part).
# Maps PHYSICAL SDL scancodes to Windows virtual-key codes on a US English layout, exactly like Artemis.

"""SDL scancode -> Windows VK mapping and modifier byte, ported 1:1 from Artemis keyboard.cpp."""

from __future__ import annotations

import sdl2

VK_0 = 0x30
VK_A = 0x41
VK_F1 = 0x70
VK_F13 = 0x7C
VK_NUMPAD0 = 0x60
VK_LWIN = 0x5B
VK_RWIN = 0x5C

MODIFIER_SHIFT = 0x01
MODIFIER_CTRL = 0x02
MODIFIER_ALT = 0x04
MODIFIER_META = 0x08
SS_KBE_FLAG_NON_NORMALIZED = 0x01

# keyboard.cpp:253-459 (the switch statement), excluding the range rules handled in map_scancode().
_SPECIAL_KEYS: dict[int, int] = {
    sdl2.SDL_SCANCODE_BACKSPACE: 0x08,
    sdl2.SDL_SCANCODE_TAB: 0x09,
    sdl2.SDL_SCANCODE_CLEAR: 0x0C,
    sdl2.SDL_SCANCODE_KP_ENTER: 0x0D,
    sdl2.SDL_SCANCODE_RETURN: 0x0D,
    sdl2.SDL_SCANCODE_PAUSE: 0x13,
    sdl2.SDL_SCANCODE_CAPSLOCK: 0x14,
    sdl2.SDL_SCANCODE_ESCAPE: 0x1B,
    sdl2.SDL_SCANCODE_SPACE: 0x20,
    sdl2.SDL_SCANCODE_PAGEUP: 0x21,
    sdl2.SDL_SCANCODE_PAGEDOWN: 0x22,
    sdl2.SDL_SCANCODE_END: 0x23,
    sdl2.SDL_SCANCODE_HOME: 0x24,
    sdl2.SDL_SCANCODE_LEFT: 0x25,
    sdl2.SDL_SCANCODE_UP: 0x26,
    sdl2.SDL_SCANCODE_RIGHT: 0x27,
    sdl2.SDL_SCANCODE_DOWN: 0x28,
    sdl2.SDL_SCANCODE_SELECT: 0x29,
    sdl2.SDL_SCANCODE_EXECUTE: 0x2B,
    sdl2.SDL_SCANCODE_PRINTSCREEN: 0x2C,
    sdl2.SDL_SCANCODE_INSERT: 0x2D,
    sdl2.SDL_SCANCODE_DELETE: 0x2E,
    sdl2.SDL_SCANCODE_HELP: 0x2F,
    sdl2.SDL_SCANCODE_KP_0: VK_NUMPAD0,
    sdl2.SDL_SCANCODE_0: VK_0,
    sdl2.SDL_SCANCODE_KP_MULTIPLY: 0x6A,
    sdl2.SDL_SCANCODE_KP_PLUS: 0x6B,
    sdl2.SDL_SCANCODE_KP_COMMA: 0x6C,
    sdl2.SDL_SCANCODE_KP_MINUS: 0x6D,
    sdl2.SDL_SCANCODE_KP_PERIOD: 0x6E,
    sdl2.SDL_SCANCODE_KP_DIVIDE: 0x6F,
    sdl2.SDL_SCANCODE_NUMLOCKCLEAR: 0x90,
    sdl2.SDL_SCANCODE_SCROLLLOCK: 0x91,
    sdl2.SDL_SCANCODE_LSHIFT: 0xA0,
    sdl2.SDL_SCANCODE_RSHIFT: 0xA1,
    sdl2.SDL_SCANCODE_LCTRL: 0xA2,
    sdl2.SDL_SCANCODE_RCTRL: 0xA3,
    sdl2.SDL_SCANCODE_LALT: 0xA4,
    sdl2.SDL_SCANCODE_RALT: 0xA5,
    sdl2.SDL_SCANCODE_APPLICATION: 0x5D,
    sdl2.SDL_SCANCODE_AC_BACK: 0xA6,
    sdl2.SDL_SCANCODE_AC_FORWARD: 0xA7,
    sdl2.SDL_SCANCODE_AC_REFRESH: 0xA8,
    sdl2.SDL_SCANCODE_AC_STOP: 0xA9,
    sdl2.SDL_SCANCODE_AC_SEARCH: 0xAA,
    sdl2.SDL_SCANCODE_AC_BOOKMARKS: 0xAB,
    sdl2.SDL_SCANCODE_AC_HOME: 0xAC,
    sdl2.SDL_SCANCODE_SEMICOLON: 0xBA,
    sdl2.SDL_SCANCODE_EQUALS: 0xBB,
    sdl2.SDL_SCANCODE_COMMA: 0xBC,
    sdl2.SDL_SCANCODE_MINUS: 0xBD,
    sdl2.SDL_SCANCODE_PERIOD: 0xBE,
    sdl2.SDL_SCANCODE_SLASH: 0xBF,
    sdl2.SDL_SCANCODE_GRAVE: 0xC0,
    sdl2.SDL_SCANCODE_LEFTBRACKET: 0xDB,
    sdl2.SDL_SCANCODE_BACKSLASH: 0xDC,
    sdl2.SDL_SCANCODE_RIGHTBRACKET: 0xDD,
    sdl2.SDL_SCANCODE_APOSTROPHE: 0xDE,
    sdl2.SDL_SCANCODE_NONUSBACKSLASH: 0xE2,
    sdl2.SDL_SCANCODE_LANG1: 0x1C,
    sdl2.SDL_SCANCODE_LANG2: 0x1D,
}

# Keys the host must NOT convert to a scancode (SS_KBE_FLAG_NON_NORMALIZED), keyboard.cpp:431-448.
_NON_NORMALIZED_KEYS: dict[int, int] = {
    sdl2.SDL_SCANCODE_INTERNATIONAL3: 0xDC,
    sdl2.SDL_SCANCODE_INTERNATIONAL1: 0xE2,
}


def map_scancode(scancode: int, system_key_capture_active: bool) -> tuple[int, int] | None:
    """
    Return (vk, flags) for a physical SDL scancode, or None when Artemis would drop the event.

    The Windows keys are only forwarded while system-key capture (SDL keyboard grab) is active.
    Otherwise the local OS owns them and they must never reach the host (keyboard.cpp:371-382).
    """
    if sdl2.SDL_SCANCODE_1 <= scancode <= sdl2.SDL_SCANCODE_9:
        return (scancode - sdl2.SDL_SCANCODE_1) + VK_0 + 1, 0
    if sdl2.SDL_SCANCODE_A <= scancode <= sdl2.SDL_SCANCODE_Z:
        return (scancode - sdl2.SDL_SCANCODE_A) + VK_A, 0
    if sdl2.SDL_SCANCODE_F1 <= scancode <= sdl2.SDL_SCANCODE_F12:
        return (scancode - sdl2.SDL_SCANCODE_F1) + VK_F1, 0
    if sdl2.SDL_SCANCODE_F13 <= scancode <= sdl2.SDL_SCANCODE_F24:
        return (scancode - sdl2.SDL_SCANCODE_F13) + VK_F13, 0
    if sdl2.SDL_SCANCODE_KP_1 <= scancode <= sdl2.SDL_SCANCODE_KP_9:
        return (scancode - sdl2.SDL_SCANCODE_KP_1) + VK_NUMPAD0 + 1, 0
    if scancode in (sdl2.SDL_SCANCODE_LGUI, sdl2.SDL_SCANCODE_RGUI):
        if not system_key_capture_active:
            return None
        return (VK_LWIN if scancode == sdl2.SDL_SCANCODE_LGUI else VK_RWIN), 0
    vk = _SPECIAL_KEYS.get(scancode)
    if vk is not None:
        return vk, 0
    vk = _NON_NORMALIZED_KEYS.get(scancode)
    if vk is not None:
        return vk, SS_KBE_FLAG_NON_NORMALIZED
    return None  # "Unhandled button event": not sent, not tracked (keyboard.cpp:455-459)


def modifier_byte(sdl_mod: int, system_key_capture_active: bool) -> int:
    """keyboard.cpp:215-230: built from SDL's current modifier state (left OR right)."""
    modifiers = 0
    if sdl_mod & sdl2.KMOD_CTRL:
        modifiers |= MODIFIER_CTRL
    if sdl_mod & sdl2.KMOD_ALT:
        modifiers |= MODIFIER_ALT
    if sdl_mod & sdl2.KMOD_SHIFT:
        modifiers |= MODIFIER_SHIFT
    if sdl_mod & sdl2.KMOD_GUI and system_key_capture_active:
        modifiers |= MODIFIER_META
    return modifiers
