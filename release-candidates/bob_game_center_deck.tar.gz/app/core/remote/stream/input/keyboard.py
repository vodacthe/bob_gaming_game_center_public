"""
Keyboard event handling and system-key capture.

1:1 Python port of Artemis app/streaming/input/keyboard.cpp:172-476 and input.cpp:261-375.
Reference: streaming-technical/07-phase4-input.md §2
"""

from __future__ import annotations

import ctypes
import logging
from typing import Callable, Optional, Set
import sdl2

# Ensure SDL_GetClipboardText returns a raw pointer so SDL_free does not corrupt CPython memory
sdl2.SDL_GetClipboardText.restype = ctypes.c_void_p

from app.core.remote.limelight import api
from app.core.remote.stream.input import keyboard_map

logger = logging.getLogger(__name__)

# System-key capture modes (StreamingPreferences::CaptureSysKeysMode / §2.4)
CSK_OFF = 0          # Artemis default: local PC handles Win/Alt+Tab
CSK_FULLSCREEN = 1   # Host gets Win/Alt+Tab only when fullscreen + grabbed
CSK_ALWAYS = 2       # Host always gets Win/Alt+Tab while grabbed


def s16(val: int) -> int:
    """Convert unsigned 16-bit value into signed 16-bit integer for ctypes c_short."""
    v = val & 0xFFFF
    return v - 0x10000 if v & 0x8000 else v


class KeyboardHandler:
    """Manages keyboard event mapping, special combos, key-down tracking, and system-key capture."""

    def __init__(
        self,
        api_inst: api.LimelightApi,
        capture_sys_keys_mode: int = CSK_OFF,
        is_capture_active_cb: Optional[Callable[[], bool]] = None,
        on_quit: Optional[Callable[[], None]] = None,
        on_toggle_capture: Optional[Callable[[], None]] = None,
        on_toggle_fullscreen: Optional[Callable[[], None]] = None,
        on_toggle_stats: Optional[Callable[[], None]] = None,
        on_toggle_mouse_mode: Optional[Callable[[], None]] = None,
        on_toggle_cursor_hide: Optional[Callable[[], None]] = None,
        on_minimize: Optional[Callable[[], None]] = None,
        on_paste_text: Optional[Callable[[], None]] = None,
        on_toggle_pointer_region_lock: Optional[Callable[[], None]] = None,
        on_quit_and_exit: Optional[Callable[[], None]] = None,
    ) -> None:
        self._api = api_inst
        self.capture_sys_keys_mode = capture_sys_keys_mode
        self._is_capture_active_cb = is_capture_active_cb or (lambda: False)

        # Callbacks for special combos
        self._on_quit = on_quit
        self._on_toggle_capture = on_toggle_capture
        self._on_toggle_fullscreen = on_toggle_fullscreen
        self._on_toggle_stats = on_toggle_stats
        self._on_toggle_mouse_mode = on_toggle_mouse_mode
        self._on_toggle_cursor_hide = on_toggle_cursor_hide
        self._on_minimize = on_minimize
        self._on_paste_text = on_paste_text
        self._on_toggle_pointer_region_lock = on_toggle_pointer_region_lock
        self._on_quit_and_exit = on_quit_and_exit

        # Track currently held keys (Windows VK without 0x8000 bit, input.h:218)
        self.keys_down: Set[int] = set()

        # Window reference for grab checks
        self._window: Optional[sdl2.SDL_Window] = None

    def set_window(self, window: Optional[sdl2.SDL_Window]) -> None:
        self._window = window

    def is_system_key_capture_active(self) -> bool:
        """Check if system keys (Win, Alt+Tab) should be forwarded (input.cpp:348-375)."""
        if self.capture_sys_keys_mode == CSK_OFF or self._window is None:
            return False

        flags = sdl2.SDL_GetWindowFlags(self._window)
        has_focus = bool(flags & sdl2.SDL_WINDOW_INPUT_FOCUS)
        grabbed_flag = getattr(sdl2, "SDL_WINDOW_KEYBOARD_GRABBED", 0x00100000)
        is_grabbed = bool(flags & grabbed_flag) or bool(flags & getattr(sdl2, "SDL_WINDOW_INPUT_GRABBED", 0x00000100))

        if not has_focus or not is_grabbed:
            return False

        is_fullscreen = bool(flags & (sdl2.SDL_WINDOW_FULLSCREEN | sdl2.SDL_WINDOW_FULLSCREEN_DESKTOP))
        if self.capture_sys_keys_mode == CSK_FULLSCREEN and not is_fullscreen:
            return False

        return True

    def update_keyboard_grab_state(self) -> None:
        """Update SDL keyboard grab and Alt+F4 hints (input.cpp:323-346)."""
        if self.capture_sys_keys_mode == CSK_OFF or self._window is None:
            return

        should_grab = self._is_capture_active_cb()
        flags = sdl2.SDL_GetWindowFlags(self._window)
        is_fullscreen = bool(flags & (sdl2.SDL_WINDOW_FULLSCREEN | sdl2.SDL_WINDOW_FULLSCREEN_DESKTOP))

        if self.capture_sys_keys_mode == CSK_FULLSCREEN and not is_fullscreen:
            should_grab = False

        sdl2.SDL_SetHint(b"SDL_WINDOWS_NO_CLOSE_ON_ALT_F4", b"1" if should_grab else b"0")
        sdl2.SDL_SetWindowKeyboardGrab(self._window, sdl2.SDL_TRUE if should_grab else sdl2.SDL_FALSE)

    def raise_all_keys(self) -> None:
        """Release all currently held keys on the host (input.cpp:261-276).

        This is the primary fix for stuck keys on focus loss or special combos.
        """
        if not self.keys_down:
            return

        logger.info("Raising %d keys", len(self.keys_down))
        # Artemis sends without 0x8000 bit and with modifiers 0 (input.cpp:272)
        for vk in list(self.keys_down):
            self._api.LiSendKeyboardEvent(s16(vk), api.KEY_ACTION_UP, 0)

        self.keys_down.clear()

    def handle_key_event(self, ev: sdl2.SDL_KeyboardEvent) -> None:
        """Process keyboard event (keyboard.cpp:172-476)."""
        # 1. Ignore repeat key down events (keyboard.cpp:178-182)
        if getattr(ev, "repeat", 0):
            return

        mod = ev.keysym.mod
        is_pressed = ev.state == sdl2.SDL_PRESSED

        # 2. Check for special Ctrl+Alt+Shift key combos (keyboard.cpp:184-213)
        if (
            is_pressed
            and bool(mod & sdl2.KMOD_CTRL)
            and bool(mod & sdl2.KMOD_ALT)
            and bool(mod & sdl2.KMOD_SHIFT)
        ):
            if self._check_special_combo(ev):
                return

        # 3. Calculate modifier byte (keyboard.cpp:215-230)
        sys_active = self.is_system_key_capture_active()
        modifiers = keyboard_map.modifier_byte(mod, sys_active)

        # 4. Map physical scancode to Windows Virtual Key (keyboard.cpp:232-461)
        mapped = keyboard_map.map_scancode(ev.keysym.scancode, sys_active)
        if mapped is None:
            logger.debug("Unhandled button event scancode: %d", ev.keysym.scancode)
            return

        vk, flags = mapped

        # 5. Track key state in keys_down (keyboard.cpp:463-470)
        if is_pressed:
            self.keys_down.add(vk)
        else:
            self.keys_down.discard(vk)

        # 6. Send keyboard event to host via Limelight (keyboard.cpp:471-476)
        key_code = s16(0x8000 | vk)
        action = api.KEY_ACTION_DOWN if is_pressed else api.KEY_ACTION_UP
        self._api.LiSendKeyboardEvent2(key_code, action, modifiers, flags)

    def _check_special_combo(self, ev: sdl2.SDL_KeyboardEvent) -> bool:
        """Check and execute special Ctrl+Alt+Shift combos (keyboard.cpp:18-170).

        Returns True if a combo matched and handled.
        """
        sym = ev.keysym.sym
        scancode = ev.keysym.scancode

        # Helper matching both keysym and scancode
        def matches(target_sym: int, target_scancode: int) -> bool:
            return sym == target_sym or scancode == target_scancode

        # Q: Quit
        if matches(sdl2.SDLK_q, sdl2.SDL_SCANCODE_Q):
            logger.info("Detected quit key combo (Ctrl+Alt+Shift+Q)")
            if self._on_quit:
                self._on_quit()
            return True

        # Z: Toggle capture / ungrab input
        if matches(sdl2.SDLK_z, sdl2.SDL_SCANCODE_Z):
            logger.info("Detected mouse capture toggle combo (Ctrl+Alt+Shift+Z)")
            if self._on_toggle_capture:
                self._on_toggle_capture()
            self.raise_all_keys()
            return True

        # X: Toggle full-screen
        if matches(sdl2.SDLK_x, sdl2.SDL_SCANCODE_X):
            logger.info("Detected full-screen toggle combo (Ctrl+Alt+Shift+X)")
            if self._on_toggle_fullscreen:
                self._on_toggle_fullscreen()
            self.raise_all_keys()
            return True

        # S: Toggle stats overlay
        if matches(sdl2.SDLK_s, sdl2.SDL_SCANCODE_S):
            logger.info("Detected stats toggle combo (Ctrl+Alt+Shift+S)")
            if self._on_toggle_stats:
                self._on_toggle_stats()
            return True

        # M: Toggle mouse mode
        if matches(sdl2.SDLK_m, sdl2.SDL_SCANCODE_M):
            logger.info("Detected mouse mode toggle combo (Ctrl+Alt+Shift+M)")
            if self._on_toggle_mouse_mode:
                self._on_toggle_mouse_mode()
            return True

        # C: Toggle cursor hide
        if matches(sdl2.SDLK_c, sdl2.SDL_SCANCODE_C):
            logger.info("Detected show mouse combo (Ctrl+Alt+Shift+C)")
            if self._on_toggle_cursor_hide:
                self._on_toggle_cursor_hide()
            return True

        # D: Minimize window
        if matches(sdl2.SDLK_d, sdl2.SDL_SCANCODE_D):
            logger.info("Detected minimize combo (Ctrl+Alt+Shift+D)")
            if self._on_minimize:
                self._on_minimize()
            return True

        # V: Paste text
        if matches(sdl2.SDLK_v, sdl2.SDL_SCANCODE_V):
            logger.info("Detected type clipboard text combo (Ctrl+Alt+Shift+V)")
            self.raise_all_keys()
            if self._on_paste_text:
                self._on_paste_text()
            else:
                self._default_paste_clipboard()
            return True

        # L: Toggle pointer region lock
        if matches(sdl2.SDLK_l, sdl2.SDL_SCANCODE_L):
            logger.info("Detected pointer region lock toggle combo (Ctrl+Alt+Shift+L)")
            if self._on_toggle_pointer_region_lock:
                self._on_toggle_pointer_region_lock()
            return True

        # E: Quit and exit
        if matches(sdl2.SDLK_e, sdl2.SDL_SCANCODE_E):
            logger.info("Detected quitAndExit key combo (Ctrl+Alt+Shift+E)")
            if self._on_quit_and_exit:
                self._on_quit_and_exit()
            elif self._on_quit:
                self._on_quit()
            return True

        return False

    def _default_paste_clipboard(self) -> None:
        """Paste clipboard text to host via LiSendUtf8TextEvent (keyboard.cpp:95-127)."""
        try:
            sdl2.SDL_GetClipboardText.restype = ctypes.c_void_p
            if sdl2.SDL_HasClipboardText():
                raw_ptr = sdl2.SDL_GetClipboardText()
                if raw_ptr:
                    try:
                        raw_bytes = ctypes.string_at(raw_ptr)
                        text_str = raw_bytes.decode("utf-8", errors="replace")
                        # Replace CRLF with LF to avoid double newlines
                        fixed_str = text_str.replace("\r\n", "\n")
                        encoded = fixed_str.encode("utf-8")
                        self._api.LiSendUtf8TextEvent(encoded, len(encoded))
                    finally:
                        sdl2.SDL_free(ctypes.c_void_p(raw_ptr) if isinstance(raw_ptr, int) else raw_ptr)
        except Exception as e:
            logger.warning("Failed to paste clipboard text: %s", e)
