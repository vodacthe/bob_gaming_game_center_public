"""
SDL window creation, window modes, display modes and letterbox scaling.

1:1 port of Artemis:
- StreamUtils::scaleSourceToDestinationSurface (streamutils.cpp:83-96)
- Session::getWindowDimensions (session.cpp:1412-1496)
- Session::updateOptimalWindowDisplayMode (session.cpp:1498-1617)
Reference: streaming-technical/06-phase3-session-video.md §4.4, §4.5
"""

from __future__ import annotations

import ctypes
import logging
import math
import sdl2

logger = logging.getLogger(__name__)


def scale_source_to_destination(
    src: tuple[int, int, int, int],  # (x, y, w, h)
    dst: tuple[int, int, int, int],  # (x, y, w, h)
) -> tuple[int, int, int, int]:
    """Aspect-fit letterbox calculation.

    Port of StreamUtils::scaleSourceToDestinationSurface (streamutils.cpp:83-96).
    """
    sx, sy, sw, sh = src
    dx, dy, dw, dh = dst

    if sw <= 0 or sh <= 0 or dw <= 0 or dh <= 0:
        return (dx, dy, dw, dh)

    dst_h = math.ceil(float(dw) * sh / sw)
    dst_w = math.ceil(float(dh) * sw / sh)

    if dst_h > dh:
        new_x = dx + (dw - dst_w) // 2
        return (new_x, dy, dst_w, dh)
    else:
        new_y = dy + (dh - dst_h) // 2
        return (dx, new_y, dw, dst_h)


def get_optimal_display_mode(
    display_index: int,
    stream_w: int,
    stream_h: int,
    fps: int,
) -> sdl2.SDL_DisplayMode | None:
    """Find the optimal display mode for exclusive fullscreen.

    Port of Session::updateOptimalWindowDisplayMode (session.cpp:1498-1617).
    """
    desktop_mode = sdl2.SDL_DisplayMode()
    if sdl2.SDL_GetDesktopDisplayMode(display_index, ctypes.byref(desktop_mode)) != 0:
        logger.warning(f"[Window] SDL_GetDesktopDisplayMode failed: {sdl2.SDL_GetError()}")
        return None

    num_modes = sdl2.SDL_GetNumDisplayModes(display_index)
    if num_modes <= 0:
        return desktop_mode

    # 1. Highest refresh rate at desktop resolution divisible by stream fps
    best_mode: sdl2.SDL_DisplayMode | None = None
    best_hz = 0
    mode = sdl2.SDL_DisplayMode()

    for i in range(num_modes):
        if sdl2.SDL_GetDisplayMode(display_index, i, ctypes.byref(mode)) == 0:
            if mode.w == desktop_mode.w and mode.h == desktop_mode.h:
                if fps > 0 and (mode.refresh_rate % fps == 0):
                    if mode.refresh_rate > best_hz:
                        best_hz = mode.refresh_rate
                        best_mode = sdl2.SDL_DisplayMode(
                            mode.format, mode.w, mode.h, mode.refresh_rate, mode.driverdata
                        )

    if best_mode is not None:
        return best_mode

    # 2. Mode >= stream size, divisible by fps, with closest aspect ratio
    target_aspect = float(stream_w) / max(1, stream_h)
    best_aspect_diff = float("inf")

    for i in range(num_modes):
        if sdl2.SDL_GetDisplayMode(display_index, i, ctypes.byref(mode)) == 0:
            if mode.w >= stream_w and mode.h >= stream_h:
                if fps > 0 and (mode.refresh_rate % fps == 0):
                    mode_aspect = float(mode.w) / max(1, mode.h)
                    diff = abs(mode_aspect - target_aspect)
                    if diff < best_aspect_diff:
                        best_aspect_diff = diff
                        best_mode = sdl2.SDL_DisplayMode(
                            mode.format, mode.w, mode.h, mode.refresh_rate, mode.driverdata
                        )

    return best_mode or desktop_mode


def get_windowed_dimensions(
    display_index: int,
    stream_w: int,
    stream_h: int,
) -> tuple[int, int]:
    """Calculate window dimensions for windowed mode (session.cpp:1460-1496).

    Uses 80% usable bounds aspect-fit, rounded to even numbers (& ~0x1).
    """
    usable = sdl2.SDL_Rect()
    if sdl2.SDL_GetDisplayUsableBounds(display_index, ctypes.byref(usable)) == 0:
        max_w = int(usable.w * 0.80) & ~0x1
        max_h = int(usable.h * 0.80) & ~0x1
        scaled = scale_source_to_destination(
            (0, 0, stream_w, stream_h),
            (0, 0, max_w, max_h),
        )
        if stream_w < scaled[2] and stream_h < scaled[3]:
            return stream_w, stream_h
        return scaled[2], scaled[3]
    return stream_w, stream_h


def create_stream_window(
    title: str,
    stream_w: int,
    stream_h: int,
    fps: int,
    window_mode: str = "borderless",  # "borderless" (default), "fullscreen", "windowed"
    display_index: int = 0,
    vsync: bool = True,
) -> tuple[ctypes.c_void_p, int, bool]:
    """Create the SDL stream window.

    Returns:
        (window_handle, display_hz, enable_vsync)
    Reference: streaming-technical/06-phase3-session-video.md §4.4
    """
    window_mode = window_mode.lower()
    flags = sdl2.SDL_WINDOW_ALLOW_HIGHDPI

    display_hz = 60
    desktop_mode = sdl2.SDL_DisplayMode()
    if sdl2.SDL_GetDesktopDisplayMode(display_index, ctypes.byref(desktop_mode)) == 0:
        display_hz = desktop_mode.refresh_rate or 60

    enable_vsync = False

    if window_mode == "fullscreen":
        flags |= sdl2.SDL_WINDOW_FULLSCREEN
        opt_mode = get_optimal_display_mode(display_index, stream_w, stream_h, fps)
        if opt_mode:
            display_hz = opt_mode.refresh_rate or display_hz
        # Vsync only if user enabled vsync AND display Hz + 5 >= stream fps (session.cpp:2414-2428)
        if vsync and (display_hz + 5 >= fps):
            enable_vsync = True
        win_w, win_h = (opt_mode.w, opt_mode.h) if opt_mode else (stream_w, stream_h)
    elif window_mode == "windowed":
        flags |= sdl2.SDL_WINDOW_RESIZABLE
        win_w, win_h = get_windowed_dimensions(display_index, stream_w, stream_h)
    else:  # "borderless" (default in this plan)
        flags |= sdl2.SDL_WINDOW_FULLSCREEN_DESKTOP
        win_w, win_h = desktop_mode.w, desktop_mode.h

    win_x = sdl2.SDL_WINDOWPOS_CENTERED_DISPLAY(display_index)
    win_y = sdl2.SDL_WINDOWPOS_CENTERED_DISPLAY(display_index)

    window = sdl2.SDL_CreateWindow(
        title.encode("utf-8"),
        win_x,
        win_y,
        win_w,
        win_h,
        flags,
    )
    if not window:
        raise RuntimeError(f"SDL_CreateWindow failed: {sdl2.SDL_GetError()}")

    if window_mode == "fullscreen" and opt_mode:
        sdl2.SDL_SetWindowDisplayMode(window, ctypes.byref(opt_mode))

    return window, display_hz, enable_vsync
