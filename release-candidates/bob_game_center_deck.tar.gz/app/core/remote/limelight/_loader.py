"""
Lazy loader for moonlight-common-c.dll.

Maintains a singleton LimelightApi instance, ensuring DLL directory is registered
and struct layouts are validated against the native shim probes on first load.
"""

from __future__ import annotations

import ctypes
import os
import threading
from typing import Optional

from app.core.remote.limelight.api import LimelightApi
from app.core.remote.native_paths import native_bin_dir

_API: Optional[LimelightApi] = None
_LOCK = threading.Lock()
_DLL_DIRECTORY_COOKIE: Optional[object] = None


def load_api() -> LimelightApi:
    """Find and load moonlight-common-c.dll once, returning the LimelightApi instance.

    Raises FileNotFoundError / OSError if DLL cannot be located or loaded.
    Raises RuntimeError if any struct layout probe in LimelightApi mismatches.
    """
    global _API, _DLL_DIRECTORY_COOKIE
    with _LOCK:
        if _API is None:
            bin_dir = native_bin_dir()
            if hasattr(os, "add_dll_directory") and bin_dir.exists():
                try:
                    _DLL_DIRECTORY_COOKIE = os.add_dll_directory(str(bin_dir))
                except Exception:
                    pass

            crypto_path = bin_dir / "libcrypto-3-x64.dll"
            if crypto_path.exists():
                try:
                    ctypes.CDLL(str(crypto_path))
                except Exception:
                    pass

            dll_path = bin_dir / "moonlight-common-c.dll"
            if dll_path.exists():
                dll = ctypes.CDLL(str(dll_path))
            else:
                dll = ctypes.CDLL("moonlight-common-c.dll")

            _API = LimelightApi(dll)
        return _API
