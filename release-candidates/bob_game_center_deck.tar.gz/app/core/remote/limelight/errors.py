"""
Limelight and streaming error types with user-facing Vietnamese translations.
Ports error handling and user messaging from Artemis PC:
  - app/streaming/session.cpp:85-158 (stageFailed, connectionTerminated)
  - app/streaming/session.cpp:185-212 (connectionStatusUpdate overlay text)
"""

from __future__ import annotations

from app.core.remote.limelight.api import (
    CONN_STATUS_POOR,
    ML_ERROR_FRAME_CONVERSION,
    ML_ERROR_GRACEFUL_TERMINATION,
    ML_ERROR_NO_VIDEO_FRAME,
    ML_ERROR_NO_VIDEO_TRAFFIC,
    ML_ERROR_PROTECTED_CONTENT,
    ML_ERROR_UNEXPECTED_EARLY_TERMINATION,
)

STAGE_NAMES_VI: dict[str, str] = {
    "none": "không có",
    "platform initialization": "khởi tạo nền tảng",
    "name resolution": "phân giải địa chỉ máy chủ",
    "audio stream initialization": "khởi tạo luồng âm thanh",
    "RTSP handshake": "bắt tay RTSP",
    "control stream initialization": "khởi tạo luồng điều khiển",
    "video stream initialization": "khởi tạo luồng video",
    "input stream initialization": "khởi tạo luồng nhập liệu",
    "control stream establishment": "thiết lập luồng điều khiển",
    "video stream establishment": "thiết lập luồng video",
    "audio stream establishment": "thiết lập luồng âm thanh",
    "input stream establishment": "thiết lập luồng nhập liệu",
}


def translate_stage_name(stage_name: str) -> str:
    """Translate Limelight stage name to Vietnamese."""
    return STAGE_NAMES_VI.get(stage_name, stage_name)


def format_stage_failed(stage_name: str, error_code: int, failing_ports: str = "") -> str:
    """Format user-facing error message when a connection stage fails.

    Port of Artemis session.cpp:90-99 (Session::clStageFailed).
    """
    stage_vi = translate_stage_name(stage_name)
    ports_suffix = f" Kiểm tra tường lửa / port: {failing_ports}" if failing_ports else ""
    return f'Không thể bắt đầu stream ở bước "{stage_vi}" (mã lỗi {error_code}).{ports_suffix}'


def format_termination_error(error_code: int, failing_ports: str = "") -> str:
    """Format user-facing error message when connection is terminated unexpectedly.

    Port of Artemis session.cpp:101-158 (Session::clConnectionTerminated).
    """
    if error_code == ML_ERROR_GRACEFUL_TERMINATION:
        return ""
    if error_code == ML_ERROR_NO_VIDEO_TRAFFIC:
        ports_str = f" {failing_ports}" if failing_ports else ""
        return f"Không nhận được video từ máy chủ. Kiểm tra tường lửa và chuyển tiếp port:{ports_str}"
    if error_code == ML_ERROR_NO_VIDEO_FRAME:
        return "Kết nối mạng không ổn định. Hãy giảm bitrate hoặc dùng kết nối nhanh hơn."
    if error_code in (ML_ERROR_PROTECTED_CONTENT, ML_ERROR_UNEXPECTED_EARLY_TERMINATION):
        return (
            "Máy chủ gặp lỗi khi bắt đầu stream. "
            "Đóng nội dung có DRM trên máy chủ hoặc khởi động lại máy chủ."
        )
    if error_code == ML_ERROR_FRAME_CONVERSION:
        return (
            "Máy chủ báo lỗi mã hoá video nghiêm trọng. "
            "Thử tắt HDR, đổi độ phân giải stream hoặc độ phân giải màn hình máy chủ."
        )

    # Artemis session.cpp:143: "We'll assume large errors are hex values"
    if abs(error_code) > 1000:
        hex_code = f"0x{error_code & 0xFFFFFFFF:08X}"
        return f"Kết nối bị ngắt. Mã lỗi: {hex_code}"
    return f"Kết nối bị ngắt. Mã lỗi: {error_code}"


def format_connection_status_warning(connection_status: int, bitrate_kbps: int) -> str:
    """Return warning text for connection status overlay.

    Port of Artemis session.cpp:200-212 (Session::clConnectionStatusUpdate).
    """
    if connection_status == CONN_STATUS_POOR:
        if bitrate_kbps > 5000:
            return "Kết nối tới PC chậm — hãy giảm bitrate"
        return "Kết nối tới PC kém"
    return ""


class ConnectionStartError(Exception):
    """Raised when LiStartConnection fails (returns non-zero error code)."""

    def __init__(
        self,
        stage: int,
        error_code: int,
        failing_ports: str = "",
        stage_name: str = "",
    ):
        self.stage = stage
        self.error_code = error_code
        self.failing_ports = failing_ports
        self.stage_name = stage_name
        msg = format_stage_failed(stage_name, error_code, failing_ports)
        super().__init__(msg)
