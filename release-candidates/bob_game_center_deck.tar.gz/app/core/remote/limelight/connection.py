"""
LimelightConnection lifecycle management.
moonlight-common-c maintains global C state, so only one connection may be active per process.
Guards LiStartConnection / LiStopConnection with a class-level process lock.
"""

from __future__ import annotations

import ctypes
import logging
import threading
from ctypes import byref
from typing import Optional

from app.core.remote.limelight.api import SERVER_INFORMATION, LimelightApi
from app.core.remote.limelight.callbacks import CallbackSet
from app.core.remote.limelight.config import StreamParams
from app.core.remote.limelight.errors import ConnectionStartError

logger = logging.getLogger(__name__)


class LimelightConnection:
    """Manages one moonlight-common-c streaming session.

    Enforces invariant §6.1: one connection per process via a module-level lock.
    """

    _process_lock = threading.Lock()

    def __init__(
        self,
        api: LimelightApi,
        server_info: SERVER_INFORMATION,
        server_info_keep: list[bytes],
        stream_params: StreamParams,
        callback_set: CallbackSet,
    ):
        self._api = api
        self._si = server_info
        self._si_keep = server_info_keep
        self._params = stream_params
        self._cbs: Optional[CallbackSet] = callback_set
        self._is_active: bool = False
        self._lock_held: bool = False

    def _release_lock(self) -> None:
        if self._lock_held:
            self._lock_held = False
            try:
                LimelightConnection._process_lock.release()
            except RuntimeError:
                pass

    @property
    def api(self) -> LimelightApi:
        return self._api

    @property
    def callbacks(self) -> Optional[CallbackSet]:
        return self._cbs

    @property
    def is_active(self) -> bool:
        return self._is_active

    def _failing_ports(self, stage: int) -> str:
        try:
            port_flags = self._api.LiGetPortFlagsFromStage(stage)
            if port_flags == 0:
                return ""
            buf = ctypes.create_string_buffer(128)
            self._api.LiStringifyPortFlags(port_flags, b", ", buf, ctypes.sizeof(buf))
            return buf.value.decode("utf-8", "replace")
        except Exception as err:
            logger.warning("Could not stringify port flags for stage %d: %s", stage, err)
            return ""

    def _stage_name(self, stage: int) -> str:
        try:
            raw = self._api.LiGetStageName(stage)
            return raw.decode("utf-8", "replace") if raw else ""
        except Exception:
            return ""

    def start(self) -> None:
        """Start the streaming connection.

        Blocking call (seconds). Call on a dedicated 'ConnStart' thread,
        never on the Qt GUI or SDL event thread (Invariant §6.1, §6.9).
        """
        if not LimelightConnection._process_lock.acquire(blocking=False):
            raise RuntimeError("A stream is already active (one connection per process invariant)")
        self._lock_held = True

        if self._cbs is None:
            self._release_lock()
            raise RuntimeError("LimelightConnection cannot be reused after stop()")

        try:
            rc = self._api.LiStartConnection(
                byref(self._si),
                byref(self._params.config),
                byref(self._cbs.cl),
                byref(self._cbs.dr),
                byref(self._cbs.ar),
                None,
                0,
                None,
                0,
            )
            if rc != 0:
                # The C library already invoked LiStopConnection() on failure (Connection.c:529-534).
                failed_stage = self._cbs.failed_stage
                failing_ports = self._failing_ports(failed_stage)
                stage_name = self._stage_name(failed_stage)
                self._cbs = None
                self._si_keep = []
                self._release_lock()
                raise ConnectionStartError(failed_stage, rc, failing_ports, stage_name)

            self._is_active = True
        except ConnectionStartError:
            raise
        except BaseException:
            self._cbs = None
            self._si_keep = []
            self._release_lock()
            raise

    def interrupt(self) -> None:
        """Abort a pending connection attempt (e.g. user pressed Cancel).

        Safe to invoke from any thread (Connection.c:63-66).
        """
        self._api.LiInterruptConnection()

    def stop(self) -> None:
        """Stop the streaming connection and release all C callbacks.

        Blocking call. Must be called from a cleanup thread AFTER the video decoder
        thread was joined and the SDL window destroyed (session.cpp:2514-2579).
        """
        try:
            if self._is_active:
                self._api.LiStopConnection()
                self._is_active = False
        finally:
            self._cbs = None  # CFUNCTYPE wrappers may now be safely collected
            self._si_keep = []
            self._release_lock()
