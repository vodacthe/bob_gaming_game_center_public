# Reference implementation for app/core/remote/limelight/api.py (copy verbatim).
# Validated on 2026-10-06 against a Release build of moonlight-common-c.dll (Artemis fork @ ad329b2):
# every BobLcLayout() probe matched, and LiStartConnection drove stage/log/failure callbacks end to end.

"""
ctypes mirror of moonlight-common-c's public API (src/Limelight.h, Artemis fork @ ad329b2).
Struct layouts are verified at import time against BobLcLayout() exported by the shim.
"""

from __future__ import annotations

import ctypes
from ctypes import (
    CFUNCTYPE, POINTER, Structure, c_bool, c_byte, c_char, c_char_p, c_float, c_int, c_short, c_ubyte, c_uint,
    c_uint8, c_uint16, c_uint32, c_uint64, c_ushort, c_void_p,
)

# ---- Limelight.h constants ----------------------------------------------------------------------------------------
STREAM_CFG_LOCAL, STREAM_CFG_REMOTE, STREAM_CFG_AUTO = 0, 1, 2
COLORSPACE_REC_601, COLORSPACE_REC_709, COLORSPACE_REC_2020 = 0, 1, 2
COLOR_RANGE_LIMITED, COLOR_RANGE_FULL = 0, 1
ENCFLG_NONE, ENCFLG_AUDIO, ENCFLG_VIDEO, ENCFLG_ALL = 0x0, 0x1, 0x2, -1  # ENCFLG_ALL is 0xFFFFFFFF in a C int

BUFFER_TYPE_PICDATA, BUFFER_TYPE_SPS, BUFFER_TYPE_PPS, BUFFER_TYPE_VPS = 0x00, 0x01, 0x02, 0x03
FRAME_TYPE_PFRAME, FRAME_TYPE_IDR = 0x00, 0x01


def MAKE_AUDIO_CONFIGURATION(channel_count: int, channel_mask: int) -> int:
    return (channel_mask << 16) | (channel_count << 8) | 0xCA


AUDIO_CONFIGURATION_STEREO = MAKE_AUDIO_CONFIGURATION(2, 0x3)
AUDIO_CONFIGURATION_51_SURROUND = MAKE_AUDIO_CONFIGURATION(6, 0x3F)
AUDIO_CONFIGURATION_71_SURROUND = MAKE_AUDIO_CONFIGURATION(8, 0x63F)


def CHANNEL_COUNT_FROM_AUDIO_CONFIGURATION(x: int) -> int:
    return (x >> 8) & 0xFF


def CHANNEL_MASK_FROM_AUDIO_CONFIGURATION(x: int) -> int:
    return (x >> 16) & 0xFFFF


def SURROUNDAUDIOINFO_FROM_AUDIO_CONFIGURATION(x: int) -> int:
    return (CHANNEL_MASK_FROM_AUDIO_CONFIGURATION(x) << 16) | CHANNEL_COUNT_FROM_AUDIO_CONFIGURATION(x)


VIDEO_FORMAT_H264 = 0x0001
VIDEO_FORMAT_H264_HIGH8_444 = 0x0004
VIDEO_FORMAT_H265 = 0x0100
VIDEO_FORMAT_H265_MAIN10 = 0x0200
VIDEO_FORMAT_H265_REXT8_444 = 0x0400
VIDEO_FORMAT_H265_REXT10_444 = 0x0800
VIDEO_FORMAT_AV1_MAIN8 = 0x1000
VIDEO_FORMAT_AV1_MAIN10 = 0x2000
VIDEO_FORMAT_AV1_HIGH8_444 = 0x4000
VIDEO_FORMAT_AV1_HIGH10_444 = 0x8000
VIDEO_FORMAT_MASK_H264 = 0x000F
VIDEO_FORMAT_MASK_H265 = 0x0F00
VIDEO_FORMAT_MASK_AV1 = 0xF000
VIDEO_FORMAT_MASK_10BIT = 0xAA00
VIDEO_FORMAT_MASK_YUV444 = 0xCC04

CAPABILITY_DIRECT_SUBMIT = 0x1
CAPABILITY_REFERENCE_FRAME_INVALIDATION_AVC = 0x2
CAPABILITY_REFERENCE_FRAME_INVALIDATION_HEVC = 0x4
CAPABILITY_SLOW_OPUS_DECODER = 0x8
CAPABILITY_SUPPORTS_ARBITRARY_AUDIO_DURATION = 0x10
CAPABILITY_PULL_RENDERER = 0x20
CAPABILITY_REFERENCE_FRAME_INVALIDATION_AV1 = 0x40


def CAPABILITY_SLICES_PER_FRAME(x: int) -> int:
    return (x & 0xFF) << 24


DR_OK, DR_NEED_IDR = 0, -1

(STAGE_NONE, STAGE_PLATFORM_INIT, STAGE_NAME_RESOLUTION, STAGE_AUDIO_STREAM_INIT, STAGE_RTSP_HANDSHAKE,
 STAGE_CONTROL_STREAM_INIT, STAGE_VIDEO_STREAM_INIT, STAGE_INPUT_STREAM_INIT, STAGE_CONTROL_STREAM_START,
 STAGE_VIDEO_STREAM_START, STAGE_AUDIO_STREAM_START, STAGE_INPUT_STREAM_START, STAGE_MAX) = range(13)

ML_ERROR_GRACEFUL_TERMINATION = 0
ML_ERROR_NO_VIDEO_TRAFFIC = -100
ML_ERROR_NO_VIDEO_FRAME = -101
ML_ERROR_UNEXPECTED_EARLY_TERMINATION = -102
ML_ERROR_PROTECTED_CONTENT = -103
ML_ERROR_FRAME_CONVERSION = -104
CONN_STATUS_OKAY, CONN_STATUS_POOR = 0, 1

SCM_H264, SCM_HEVC, SCM_HEVC_MAIN10 = 0x00000001, 0x00000100, 0x00000200
SCM_AV1_MAIN8, SCM_AV1_MAIN10 = 0x00010000, 0x00020000
SCM_H264_HIGH8_444, SCM_HEVC_REXT8_444, SCM_HEVC_REXT10_444 = 0x00040000, 0x00080000, 0x00100000
SCM_AV1_HIGH8_444, SCM_AV1_HIGH10_444 = 0x00200000, 0x00400000

LI_ERR_UNSUPPORTED = -5501
BUTTON_ACTION_PRESS, BUTTON_ACTION_RELEASE = 0x07, 0x08
BUTTON_LEFT, BUTTON_MIDDLE, BUTTON_RIGHT, BUTTON_X1, BUTTON_X2 = 0x01, 0x02, 0x03, 0x04, 0x05
KEY_ACTION_DOWN, KEY_ACTION_UP = 0x03, 0x04
MODIFIER_SHIFT, MODIFIER_CTRL, MODIFIER_ALT, MODIFIER_META = 0x01, 0x02, 0x04, 0x08
SS_KBE_FLAG_NON_NORMALIZED = 0x01

A_FLAG, B_FLAG, X_FLAG, Y_FLAG = 0x1000, 0x2000, 0x4000, 0x8000
UP_FLAG, DOWN_FLAG, LEFT_FLAG, RIGHT_FLAG = 0x0001, 0x0002, 0x0004, 0x0008
LB_FLAG, RB_FLAG, PLAY_FLAG, BACK_FLAG = 0x0100, 0x0200, 0x0010, 0x0020
LS_CLK_FLAG, RS_CLK_FLAG, SPECIAL_FLAG = 0x0040, 0x0080, 0x0400
PADDLE1_FLAG, PADDLE2_FLAG, PADDLE3_FLAG, PADDLE4_FLAG = 0x010000, 0x020000, 0x040000, 0x080000
TOUCHPAD_FLAG, MISC_FLAG = 0x100000, 0x200000

LI_CTYPE_UNKNOWN, LI_CTYPE_XBOX, LI_CTYPE_PS, LI_CTYPE_NINTENDO = 0x00, 0x01, 0x02, 0x03
LI_CCAP_ANALOG_TRIGGERS, LI_CCAP_RUMBLE, LI_CCAP_TRIGGER_RUMBLE, LI_CCAP_TOUCHPAD = 0x01, 0x02, 0x04, 0x08
LI_CCAP_ACCEL, LI_CCAP_GYRO, LI_CCAP_BATTERY_STATE, LI_CCAP_RGB_LED = 0x10, 0x20, 0x40, 0x80
LI_MOTION_TYPE_ACCEL, LI_MOTION_TYPE_GYRO = 0x01, 0x02
LI_TOUCH_EVENT_DOWN, LI_TOUCH_EVENT_UP, LI_TOUCH_EVENT_MOVE = 0x01, 0x02, 0x03
LI_BATTERY_STATE_UNKNOWN, LI_BATTERY_PERCENTAGE_UNKNOWN = 0x00, 0xFF
LI_FF_PEN_TOUCH_EVENTS, LI_FF_CONTROLLER_TOUCH_EVENTS = 0x01, 0x02


# ---- Structs (layouts verified against BobLcLayout) --------------------------------------------------------------
class STREAM_CONFIGURATION(Structure):
    _fields_ = [
        ("width", c_int), ("height", c_int), ("fps", c_int), ("bitrate", c_int), ("packetSize", c_int),
        ("streamingRemotely", c_int), ("audioConfiguration", c_int), ("supportedVideoFormats", c_int),
        ("clientRefreshRateX100", c_int), ("colorSpace", c_int), ("colorRange", c_int), ("encryptionFlags", c_int),
        ("remoteInputAesKey", c_char * 16), ("remoteInputAesIv", c_char * 16),
    ]


class SERVER_INFORMATION(Structure):
    _fields_ = [
        ("address", c_char_p), ("serverInfoAppVersion", c_char_p), ("serverInfoGfeVersion", c_char_p),
        ("rtspSessionUrl", c_char_p), ("serverCodecModeSupport", c_int),
    ]


class LENTRY(Structure):
    pass


LENTRY._fields_ = [("next", POINTER(LENTRY)), ("data", c_void_p), ("length", c_int), ("bufferType", c_int)]


class DECODE_UNIT(Structure):
    _fields_ = [
        ("frameNumber", c_int), ("frameType", c_int), ("frameHostProcessingLatency", c_uint16),
        ("receiveTimeMs", c_uint64), ("enqueueTimeMs", c_uint64), ("presentationTimeMs", c_uint),
        ("fullLength", c_int), ("bufferList", POINTER(LENTRY)), ("hdrActive", c_bool), ("colorspace", c_uint8),
    ]


class OPUS_MULTISTREAM_CONFIGURATION(Structure):
    _fields_ = [
        ("sampleRate", c_int), ("channelCount", c_int), ("streams", c_int), ("coupledStreams", c_int),
        ("samplesPerFrame", c_int), ("mapping", c_ubyte * 8),
    ]


# ---- Callback types (Limelight.h:282-480) ------------------------------------------------------------------------
# Binary buffers are c_void_p, never c_char_p: c_char_p would copy only up to the first NUL byte.
DecoderRendererSetup = CFUNCTYPE(c_int, c_int, c_int, c_int, c_int, c_void_p, c_int)
DecoderRendererStart = CFUNCTYPE(None)
DecoderRendererStop = CFUNCTYPE(None)
DecoderRendererCleanup = CFUNCTYPE(None)
DecoderRendererSubmitDecodeUnit = CFUNCTYPE(c_int, POINTER(DECODE_UNIT))
AudioRendererInit = CFUNCTYPE(c_int, c_int, POINTER(OPUS_MULTISTREAM_CONFIGURATION), c_void_p, c_int)
AudioRendererStart = CFUNCTYPE(None)
AudioRendererStop = CFUNCTYPE(None)
AudioRendererCleanup = CFUNCTYPE(None)
AudioRendererDecodeAndPlaySample = CFUNCTYPE(None, c_void_p, c_int)  # (NULL, 0) = conceal a lost packet
ConnListenerStageStarting = CFUNCTYPE(None, c_int)
ConnListenerStageComplete = CFUNCTYPE(None, c_int)
ConnListenerStageFailed = CFUNCTYPE(None, c_int, c_int)
ConnListenerConnectionStarted = CFUNCTYPE(None)
ConnListenerConnectionTerminated = CFUNCTYPE(None, c_int)
ConnListenerRumble = CFUNCTYPE(None, c_ushort, c_ushort, c_ushort)
ConnListenerConnectionStatusUpdate = CFUNCTYPE(None, c_int)
ConnListenerSetHdrMode = CFUNCTYPE(None, c_bool)
ConnListenerRumbleTriggers = CFUNCTYPE(None, c_uint16, c_uint16, c_uint16)
ConnListenerSetMotionEventState = CFUNCTYPE(None, c_uint16, c_uint8, c_uint16)
ConnListenerSetControllerLED = CFUNCTYPE(None, c_uint16, c_uint8, c_uint8, c_uint8)
ConnListenerSetAdaptiveTriggers = CFUNCTYPE(None, c_uint16, c_uint8, c_uint8, c_uint8, POINTER(c_uint8), POINTER(c_uint8))
BobLcLogSink = CFUNCTYPE(None, c_char_p)


class DECODER_RENDERER_CALLBACKS(Structure):
    _fields_ = [
        ("setup", DecoderRendererSetup), ("start", DecoderRendererStart), ("stop", DecoderRendererStop),
        ("cleanup", DecoderRendererCleanup), ("submitDecodeUnit", DecoderRendererSubmitDecodeUnit),
        ("capabilities", c_int),
    ]


class AUDIO_RENDERER_CALLBACKS(Structure):
    _fields_ = [
        ("init", AudioRendererInit), ("start", AudioRendererStart), ("stop", AudioRendererStop),
        ("cleanup", AudioRendererCleanup), ("decodeAndPlaySample", AudioRendererDecodeAndPlaySample),
        ("capabilities", c_int),
    ]


class CONNECTION_LISTENER_CALLBACKS(Structure):
    _fields_ = [
        ("stageStarting", ConnListenerStageStarting), ("stageComplete", ConnListenerStageComplete),
        ("stageFailed", ConnListenerStageFailed), ("connectionStarted", ConnListenerConnectionStarted),
        ("connectionTerminated", ConnListenerConnectionTerminated),
        ("logMessage", c_void_p),  # variadic: filled with the pointer returned by BobLcSetLogSink()
        ("rumble", ConnListenerRumble), ("connectionStatusUpdate", ConnListenerConnectionStatusUpdate),
        ("setHdrMode", ConnListenerSetHdrMode), ("rumbleTriggers", ConnListenerRumbleTriggers),
        ("setMotionEventState", ConnListenerSetMotionEventState), ("setControllerLED", ConnListenerSetControllerLED),
        ("setAdaptiveTriggers", ConnListenerSetAdaptiveTriggers),
    ]


_LAYOUT_EXPECTATIONS = (
    (0, lambda: ctypes.sizeof(STREAM_CONFIGURATION)),
    (1, lambda: ctypes.sizeof(SERVER_INFORMATION)),
    (2, lambda: ctypes.sizeof(LENTRY)),
    (3, lambda: ctypes.sizeof(DECODE_UNIT)),
    (4, lambda: ctypes.sizeof(DECODER_RENDERER_CALLBACKS)),
    (5, lambda: ctypes.sizeof(AUDIO_RENDERER_CALLBACKS)),
    (6, lambda: ctypes.sizeof(OPUS_MULTISTREAM_CONFIGURATION)),
    (7, lambda: ctypes.sizeof(CONNECTION_LISTENER_CALLBACKS)),
    (8, lambda: DECODE_UNIT.receiveTimeMs.offset),
    (9, lambda: DECODE_UNIT.bufferList.offset),
    (10, lambda: DECODE_UNIT.hdrActive.offset),
    (11, lambda: STREAM_CONFIGURATION.remoteInputAesKey.offset),
    (12, lambda: SERVER_INFORMATION.serverCodecModeSupport.offset),
    (13, lambda: DECODER_RENDERER_CALLBACKS.capabilities.offset),
    (14, lambda: OPUS_MULTISTREAM_CONFIGURATION.mapping.offset),
    (15, lambda: LENTRY.bufferType.offset),
)


class LimelightApi:
    """Typed function table for one loaded moonlight-common-c.dll."""

    def __init__(self, dll: ctypes.CDLL):
        self.dll = dll

        def fn(name, restype, *argtypes):
            f = getattr(dll, name)
            f.restype = restype
            f.argtypes = list(argtypes)
            setattr(self, name, f)

        fn("BobLcLayout", c_int, c_int)
        fn("BobLcSetLogSink", c_void_p, BobLcLogSink)
        fn("LiGetLaunchUrlQueryParameters", c_char_p)
        fn("LiInitializeStreamConfiguration", None, POINTER(STREAM_CONFIGURATION))
        fn("LiInitializeVideoCallbacks", None, POINTER(DECODER_RENDERER_CALLBACKS))
        fn("LiInitializeAudioCallbacks", None, POINTER(AUDIO_RENDERER_CALLBACKS))
        fn("LiInitializeConnectionCallbacks", None, POINTER(CONNECTION_LISTENER_CALLBACKS))
        fn("LiInitializeServerInformation", None, POINTER(SERVER_INFORMATION))
        fn("LiStartConnection", c_int, POINTER(SERVER_INFORMATION), POINTER(STREAM_CONFIGURATION),
           POINTER(CONNECTION_LISTENER_CALLBACKS), POINTER(DECODER_RENDERER_CALLBACKS),
           POINTER(AUDIO_RENDERER_CALLBACKS), c_void_p, c_int, c_void_p, c_int)
        fn("LiStopConnection", None)
        fn("LiInterruptConnection", None)
        fn("LiGetStageName", c_char_p, c_int)
        fn("LiGetEstimatedRttInfo", c_bool, POINTER(c_uint32), POINTER(c_uint32))
        fn("LiSendExecServerCmd", c_int, c_uint8)  # returns 1 on success, 0 on failure (Artemis fork)
        fn("LiSendMouseMoveEvent", c_int, c_short, c_short)
        fn("LiSendMousePositionEvent", c_int, c_short, c_short, c_short, c_short)
        fn("LiSendMouseMoveAsMousePositionEvent", c_int, c_short, c_short, c_short, c_short)
        fn("LiSendMouseButtonEvent", c_int, c_byte, c_int)
        fn("LiSendKeyboardEvent", c_int, c_short, c_byte, c_byte)
        fn("LiSendKeyboardEvent2", c_int, c_short, c_byte, c_byte, c_byte)
        fn("LiSendUtf8TextEvent", c_int, c_char_p, c_uint)
        fn("LiSendMultiControllerEvent", c_int, c_short, c_short, c_int, c_ubyte, c_ubyte, c_short, c_short,
           c_short, c_short)
        fn("LiSendControllerArrivalEvent", c_int, c_uint8, c_uint16, c_uint8, c_uint32, c_uint16)
        fn("LiSendControllerTouchEvent", c_int, c_uint8, c_uint8, c_uint32, c_float, c_float, c_float)
        fn("LiSendControllerMotionEvent", c_int, c_uint8, c_uint8, c_float, c_float, c_float)
        fn("LiSendControllerBatteryEvent", c_int, c_uint8, c_uint8, c_uint8)
        fn("LiSendScrollEvent", c_int, c_byte)
        fn("LiSendHighResScrollEvent", c_int, c_short)
        fn("LiSendHScrollEvent", c_int, c_byte)
        fn("LiSendHighResHScrollEvent", c_int, c_short)
        fn("LiGetMillis", c_uint64)
        fn("LiGetPendingVideoFrames", c_int)
        fn("LiGetPendingAudioFrames", c_int)
        fn("LiGetPendingAudioDuration", c_int)
        fn("LiGetPortFlagsFromStage", c_uint, c_int)
        fn("LiGetPortFlagsFromTerminationErrorCode", c_uint, c_int)
        fn("LiStringifyPortFlags", None, c_uint, c_char_p, c_char_p, c_int)
        fn("LiWaitForNextVideoFrame", c_bool, POINTER(c_void_p), POINTER(POINTER(DECODE_UNIT)))
        fn("LiPollNextVideoFrame", c_bool, POINTER(c_void_p), POINTER(POINTER(DECODE_UNIT)))
        fn("LiPeekNextVideoFrame", c_bool, POINTER(POINTER(DECODE_UNIT)))
        fn("LiWakeWaitForVideoFrame", None)
        fn("LiCompleteVideoFrame", None, c_void_p, c_int)
        fn("LiGetCurrentHostDisplayHdrMode", c_bool)
        fn("LiRequestIdrFrame", None)
        fn("LiGetHostFeatureFlags", c_uint32)

        for index, expected in _LAYOUT_EXPECTATIONS:
            actual = self.BobLcLayout(index)
            if actual != expected():
                raise RuntimeError(f"Limelight struct layout mismatch at probe {index}: C={actual} ctypes={expected()}")


def s16(value: int) -> int:
    """Reinterpret an unsigned 16-bit value (e.g. 0x8000 | VK) as the signed short the C API expects."""
    value &= 0xFFFF
    return value - 0x10000 if value & 0x8000 else value
