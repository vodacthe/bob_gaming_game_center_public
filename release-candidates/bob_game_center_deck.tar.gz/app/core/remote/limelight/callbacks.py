"""
CFUNCTYPE trampolines, exception guard, and callback lifetime registry for Limelight.
Ports callback structure from Artemis PC:
  - app/streaming/session.cpp:80-212 (connection listener callbacks)
  - app/streaming/video/ffmpeg.cpp (video callbacks, pull renderer)
  - app/streaming/audio/audio.cpp (audio callbacks)
"""

from __future__ import annotations

import functools
import logging
from ctypes import byref, c_void_p
from typing import Any, Callable, Optional

from app.core.remote.limelight.api import (
    AUDIO_RENDERER_CALLBACKS,
    CONNECTION_LISTENER_CALLBACKS,
    DECODER_RENDERER_CALLBACKS,
    AudioRendererCleanup,
    AudioRendererDecodeAndPlaySample,
    AudioRendererInit,
    AudioRendererStart,
    AudioRendererStop,
    BobLcLogSink,
    CAPABILITY_PULL_RENDERER,
    CAPABILITY_SUPPORTS_ARBITRARY_AUDIO_DURATION,
    ConnListenerConnectionStarted,
    ConnListenerConnectionStatusUpdate,
    ConnListenerConnectionTerminated,
    ConnListenerRumble,
    ConnListenerRumbleTriggers,
    ConnListenerSetAdaptiveTriggers,
    ConnListenerSetControllerLED,
    ConnListenerSetHdrMode,
    ConnListenerSetMotionEventState,
    ConnListenerStageComplete,
    ConnListenerStageFailed,
    ConnListenerStageStarting,
    DecoderRendererCleanup,
    DecoderRendererSetup,
    DecoderRendererStart,
    DecoderRendererStop,
    LimelightApi,
)

logger = logging.getLogger(__name__)


def guarded(default: Any = None) -> Callable:
    """Wrap a Python callback so an exception can never unwind into C."""
    def deco(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any) -> Any:
            try:
                return fn(*args)
            except BaseException:  # noqa: BLE001 - must never propagate into C
                logger.exception("Limelight callback %s failed", fn.__name__)
                return default
        return wrapper
    return deco


class ConnectionListener:
    """Base class for receiving Limelight connection listener events."""

    def on_stage_starting(self, stage: int) -> None:
        pass

    def on_stage_complete(self, stage: int) -> None:
        pass

    def on_stage_failed(self, stage: int, error_code: int) -> None:
        pass

    def on_connection_started(self) -> None:
        pass

    def on_connection_terminated(self, error_code: int) -> None:
        pass

    def on_log(self, message: str) -> None:
        logging.getLogger("app.core.remote.lc").info("[LC] %s", message)

    def on_rumble(self, controller_number: int, low_freq: int, high_freq: int) -> None:
        pass

    def on_connection_status_update(self, status: int) -> None:
        pass

    def on_set_hdr_mode(self, enabled: bool) -> None:
        pass

    def on_rumble_triggers(self, controller_number: int, left: int, right: int) -> None:
        pass

    def on_set_motion_event_state(self, controller_number: int, motion_type: int, report_rate_hz: int) -> None:
        pass

    def on_set_controller_led(self, controller_number: int, r: int, g: int, b: int) -> None:
        pass

    def on_set_adaptive_triggers(
        self,
        controller_number: int,
        event_flags: int,
        trigger_type: int,
        left_state: int,
        left_data: Any,
        right_data: Any,
    ) -> None:
        pass


class CallbackSet:
    """Holds every CFUNCTYPE trampoline and ctypes struct handed to moonlight-common-c.dll.

    Guarantees that Python callable wrappers and native structs are kept alive in memory
    for the entire duration of the connection until LiStopConnection() returns.
    """

    def __init__(
        self,
        api: LimelightApi,
        listener: Optional[ConnectionListener] = None,
        video: Optional[Any] = None,
        audio: Optional[Any] = None,
    ):
        self.api = api
        self.listener = listener or ConnectionListener()
        self.video = video
        self.audio = audio
        self.failed_stage: int = 0
        self.failed_error: int = 0

        # ---- Connection Listener Callbacks ----
        self.cl = CONNECTION_LISTENER_CALLBACKS()
        self.api.LiInitializeConnectionCallbacks(byref(self.cl))

        self._stage_starting = ConnListenerStageStarting(guarded()(self.listener.on_stage_starting))
        self.cl.stageStarting = self._stage_starting

        self._stage_complete = ConnListenerStageComplete(guarded()(self.listener.on_stage_complete))
        self.cl.stageComplete = self._stage_complete

        def _handle_stage_failed(stage: int, error_code: int) -> None:
            self.failed_stage = stage
            self.failed_error = error_code
            self.listener.on_stage_failed(stage, error_code)

        self._stage_failed = ConnListenerStageFailed(guarded()(_handle_stage_failed))
        self.cl.stageFailed = self._stage_failed

        self._connection_started = ConnListenerConnectionStarted(guarded()(self.listener.on_connection_started))
        self.cl.connectionStarted = self._connection_started

        self._connection_terminated = ConnListenerConnectionTerminated(
            guarded()(self.listener.on_connection_terminated)
        )
        self.cl.connectionTerminated = self._connection_terminated

        def _raw_log_sink(raw_msg: bytes | None) -> None:
            if raw_msg is not None:
                text = raw_msg.decode("utf-8", "replace").rstrip()
                self.listener.on_log(text)

        self._log_sink = BobLcLogSink(guarded()(_raw_log_sink))
        self.cl.logMessage = self.api.BobLcSetLogSink(self._log_sink)

        self._rumble = ConnListenerRumble(guarded()(self.listener.on_rumble))
        self.cl.rumble = self._rumble

        self._status_update = ConnListenerConnectionStatusUpdate(
            guarded()(self.listener.on_connection_status_update)
        )
        self.cl.connectionStatusUpdate = self._status_update

        self._set_hdr_mode = ConnListenerSetHdrMode(guarded()(self.listener.on_set_hdr_mode))
        self.cl.setHdrMode = self._set_hdr_mode

        self._rumble_triggers = ConnListenerRumbleTriggers(guarded()(self.listener.on_rumble_triggers))
        self.cl.rumbleTriggers = self._rumble_triggers

        self._set_motion = ConnListenerSetMotionEventState(
            guarded()(self.listener.on_set_motion_event_state)
        )
        self.cl.setMotionEventState = self._set_motion

        self._set_led = ConnListenerSetControllerLED(guarded()(self.listener.on_set_controller_led))
        self.cl.setControllerLED = self._set_led

        self._set_adaptive_triggers = ConnListenerSetAdaptiveTriggers(
            guarded()(self.listener.on_set_adaptive_triggers)
        )
        self.cl.setAdaptiveTriggers = self._set_adaptive_triggers

        # ---- Video (Decoder/Renderer) Callbacks ----
        self.dr = DECODER_RENDERER_CALLBACKS()
        self.api.LiInitializeVideoCallbacks(byref(self.dr))

        if video is not None:
            self._dr_setup = DecoderRendererSetup(guarded(-1)(video.setup))
            self._dr_cleanup = DecoderRendererCleanup(guarded()(video.cleanup))
            self.dr.setup = self._dr_setup
            self.dr.cleanup = self._dr_cleanup
            if hasattr(video, "start"):
                self._dr_start = DecoderRendererStart(guarded()(video.start))
                self.dr.start = self._dr_start
            if hasattr(video, "stop"):
                self._dr_stop = DecoderRendererStop(guarded()(video.stop))
                self.dr.stop = self._dr_stop
            # In pull mode, capabilities MUST include CAPABILITY_PULL_RENDERER, and submitDecodeUnit MUST be NULL
            self.dr.capabilities = getattr(video, "capabilities", CAPABILITY_PULL_RENDERER)
        else:
            self.dr.capabilities = CAPABILITY_PULL_RENDERER

        # ---- Audio Renderer Callbacks ----
        self.ar = AUDIO_RENDERER_CALLBACKS()
        self.api.LiInitializeAudioCallbacks(byref(self.ar))

        if audio is not None:
            self._ar_init = AudioRendererInit(guarded(-1)(audio.init))
            self._ar_cleanup = AudioRendererCleanup(guarded()(audio.cleanup))
            self._ar_decode_and_play = AudioRendererDecodeAndPlaySample(
                guarded()(audio.decode_and_play_sample)
            )
            self.ar.init = self._ar_init
            self.ar.cleanup = self._ar_cleanup
            self.ar.decodeAndPlaySample = self._ar_decode_and_play
            if hasattr(audio, "start"):
                self._ar_start = AudioRendererStart(guarded()(audio.start))
                self.ar.start = self._ar_start
            if hasattr(audio, "stop"):
                self._ar_stop = AudioRendererStop(guarded()(audio.stop))
                self.ar.stop = self._ar_stop
            self.ar.capabilities = getattr(
                audio, "capabilities", CAPABILITY_SUPPORTS_ARBITRARY_AUDIO_DURATION
            )
        else:
            self.ar.capabilities = CAPABILITY_SUPPORTS_ARBITRARY_AUDIO_DURATION
