"""
STREAM_CONFIGURATION and SERVER_INFORMATION builders for Limelight.
Ports stream configuration logic from Artemis PC:
  - app/streaming/session.cpp:678-797, 1772-1826 (build_stream_config)
  - app/streaming/session.cpp:1732-1770 (build_server_info)
"""

from __future__ import annotations

import os
from ctypes import byref
from dataclasses import dataclass
from typing import TYPE_CHECKING, Tuple

from app.core.remote.limelight.api import (
    AUDIO_CONFIGURATION_51_SURROUND,
    AUDIO_CONFIGURATION_71_SURROUND,
    AUDIO_CONFIGURATION_STEREO,
    ENCFLG_ALL,
    ENCFLG_AUDIO,
    SCM_H264,
    SERVER_INFORMATION,
    STREAM_CFG_AUTO,
    STREAM_CFG_LOCAL,
    STREAM_CONFIGURATION,
    LimelightApi,
)

if TYPE_CHECKING:
    from app.core.remote.models import RemoteHost, StreamSettings


@dataclass
class StreamParams:
    """Holds the native STREAM_CONFIGURATION struct and the generated AES key/IV."""

    config: STREAM_CONFIGURATION
    aes_key: bytes  # 16 random bytes
    aes_iv: bytes  # 4 random bytes + 12 zero bytes (Artemis fills only the first 4)


def build_stream_config(
    api: LimelightApi,
    s: StreamSettings,
    video_format: int,
    color_space: int,
    color_range: int,
) -> StreamParams:
    """Build native STREAM_CONFIGURATION from StreamSettings and chosen video format.

    Port of Artemis session.cpp:678-797, 1772-1826.
    """
    sc = STREAM_CONFIGURATION()
    api.LiInitializeStreamConfiguration(byref(sc))

    w, h = s.width, s.height
    if s.resolution_scale != 100:  # Artemis enableResolutionScaling (session.cpp:683-693)
        w = w * s.resolution_scale // 100
        h = h * s.resolution_scale // 100

    sc.width = w
    sc.height = h

    # Apollo convention (session.cpp:726-736): custom refresh rate * 1000 for fractional fps
    if s.enable_fractional_fps:
        sc.fps = int(s.custom_refresh_rate * 1000)
    else:
        sc.fps = s.fps

    sc.bitrate = s.bitrate_kbps

    # User override forces LOCAL; default is AUTO where library selects 1024 for WAN (session.cpp:1774-1779)
    packet_size = getattr(s, "packet_size", 0)
    if packet_size:
        sc.packetSize = packet_size
        sc.streamingRemotely = STREAM_CFG_LOCAL
    else:
        sc.packetSize = 1392
        sc.streamingRemotely = STREAM_CFG_AUTO

    audio_configs = {
        2: AUDIO_CONFIGURATION_STEREO,
        6: AUDIO_CONFIGURATION_51_SURROUND,
        8: AUDIO_CONFIGURATION_71_SURROUND,
    }
    sc.audioConfiguration = audio_configs.get(s.audio_channels, AUDIO_CONFIGURATION_STEREO)

    sc.supportedVideoFormats = video_format
    sc.clientRefreshRateX100 = 0  # Artemis never sets it
    sc.colorSpace = color_space
    sc.colorRange = color_range

    # session.cpp:741-748: encrypt video only if CPU has more than 2 cores
    cpu_count = os.cpu_count() or 1
    sc.encryptionFlags = ENCFLG_ALL if cpu_count > 2 else ENCFLG_AUDIO

    key = os.urandom(16)
    iv = os.urandom(4) + bytes(12)
    sc.remoteInputAesKey = key
    sc.remoteInputAesIv = iv

    return StreamParams(sc, key, iv)


def build_server_info(
    api: LimelightApi,
    host: RemoteHost,
    rtsp_session_url: str,
) -> Tuple[SERVER_INFORMATION, list[bytes]]:
    """Build native SERVER_INFORMATION struct.

    Returns the struct along with a list of encoded bytes buffers that MUST remain referenced
    in Python memory as long as the native struct pointers are active.
    Port of Artemis session.cpp:1732-1770 and Connection.c:228-233.
    """
    si = SERVER_INFORMATION()
    api.LiInitializeServerInformation(byref(si))

    address_bytes = host.ip.encode("utf-8")
    app_version_bytes = host.app_version.encode("utf-8")
    gfe_version_bytes = (host.gfe_version or "").encode("utf-8")
    rtsp_url_bytes = rtsp_session_url.encode("utf-8")

    keep = [address_bytes, app_version_bytes, gfe_version_bytes, rtsp_url_bytes]
    si.address = address_bytes
    si.serverInfoAppVersion = app_version_bytes
    si.serverInfoGfeVersion = gfe_version_bytes
    si.rtspSessionUrl = rtsp_url_bytes

    # serverCodecModeSupport must be non-zero (Connection.c:228-233)
    si.serverCodecModeSupport = host.server_codec_mode_support or SCM_H264

    return si, keep
