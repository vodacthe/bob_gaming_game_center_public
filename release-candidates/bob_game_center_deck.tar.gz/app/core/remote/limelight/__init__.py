"""
Limelight C binding package for moonlight-common-c.dll.
Provides typed ctypes interfaces, lifecycle management, and configuration builders.
"""

from __future__ import annotations

from app.core.remote.limelight._loader import load_api
from app.core.remote.limelight.api import (
    COLOR_RANGE_FULL,
    COLOR_RANGE_LIMITED,
    COLORSPACE_REC_601,
    COLORSPACE_REC_709,
    COLORSPACE_REC_2020,
    DECODE_UNIT,
    DR_NEED_IDR,
    DR_OK,
    FRAME_TYPE_IDR,
    FRAME_TYPE_PFRAME,
    LENTRY,
    SCM_AV1_MAIN8,
    SCM_AV1_MAIN10,
    SCM_H264,
    SCM_HEVC,
    SCM_HEVC_MAIN10,
    VIDEO_FORMAT_AV1_MAIN8,
    VIDEO_FORMAT_AV1_MAIN10,
    VIDEO_FORMAT_H264,
    VIDEO_FORMAT_H265,
    VIDEO_FORMAT_H265_MAIN10,
    LimelightApi,
    s16,
)
from app.core.remote.limelight.callbacks import CallbackSet, ConnectionListener, guarded
from app.core.remote.limelight.config import StreamParams, build_server_info, build_stream_config
from app.core.remote.limelight.connection import LimelightConnection
from app.core.remote.limelight.errors import (
    ConnectionStartError,
    format_connection_status_warning,
    format_stage_failed,
    format_termination_error,
    translate_stage_name,
)

__all__ = [
    "COLOR_RANGE_FULL",
    "COLOR_RANGE_LIMITED",
    "COLORSPACE_REC_601",
    "COLORSPACE_REC_709",
    "COLORSPACE_REC_2020",
    "CallbackSet",
    "ConnectionListener",
    "ConnectionStartError",
    "DECODE_UNIT",
    "DR_NEED_IDR",
    "DR_OK",
    "FRAME_TYPE_IDR",
    "FRAME_TYPE_PFRAME",
    "LENTRY",
    "LimelightApi",
    "LimelightConnection",
    "SCM_AV1_MAIN10",
    "SCM_AV1_MAIN8",
    "SCM_H264",
    "SCM_HEVC",
    "SCM_HEVC_MAIN10",
    "StreamParams",
    "VIDEO_FORMAT_AV1_MAIN10",
    "VIDEO_FORMAT_AV1_MAIN8",
    "VIDEO_FORMAT_H264",
    "VIDEO_FORMAT_H265",
    "VIDEO_FORMAT_H265_MAIN10",
    "build_server_info",
    "build_stream_config",
    "format_connection_status_warning",
    "format_stage_failed",
    "format_termination_error",
    "guarded",
    "load_api",
    "s16",
    "translate_stage_name",
]
