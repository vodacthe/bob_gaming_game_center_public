"""Controller battery levels and when to warn about them (Qt-free, so the policy is easy to test).

SDL only reports coarse levels (SDL_JoystickCurrentPowerLevel): empty (<= 5%), low (<= 20%), medium (<= 70%), full,
wired (charging / cable) or unknown (not reported, e.g. many DirectInput pads). Only empty and low are warned about.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)
TAG = "[GamepadBattery]"

UNKNOWN, EMPTY, LOW, MEDIUM, FULL, WIRED = "unknown", "empty", "low", "medium", "full", "wired"

# SDL_JoystickPowerLevel values
_FROM_SDL = {-1: UNKNOWN, 0: EMPTY, 1: LOW, 2: MEDIUM, 3: FULL, 4: WIRED, 5: FULL}   # 5 = SDL_JOYSTICK_POWER_MAX

# "wired" is what XInput says; wireless receivers that pretend to be a wired Xbox 360 pad (Flydigi, many 8BitDo /
# GameSir dongles in X-input mode) say it too, so it only means "no battery reading", not "charging".
LABELS = {EMPTY: "sắp hết", LOW: "yếu", MEDIUM: "trung bình", FULL: "đầy", WIRED: "không đọc được (báo là có dây)",
          UNKNOWN: "không rõ"}
ICONS = {EMPTY: "🪫", LOW: "🪫", MEDIUM: "🔋", FULL: "🔋", WIRED: "🔌", UNKNOWN: ""}
WIRED_HINT = ("Tay cầm / receiver tự báo là có dây nên Windows (XInput) không cho biết pin. Receiver không dây giả "
              "làm tay Xbox 360 (Flydigi, nhiều dongle 8BitDo / GameSir ở chế độ X-input) đều như vậy dù đang chạy pin; "
              "xem pin bằng phần mềm của hãng hoặc đèn báo trên tay cầm.")

REMIND_LOW_SECONDS = 10 * 60      # while still low, warn again this often
REMIND_EMPTY_SECONDS = 3 * 60     # ... and more often when nearly empty


def from_sdl(value) -> str:
    try:
        return _FROM_SDL.get(int(value), UNKNOWN)
    except (TypeError, ValueError):
        return UNKNOWN


def is_warning(level: str) -> bool:
    return level in (EMPTY, LOW)


@dataclass(frozen=True)
class BatteryAlert:
    device: str
    level: str

    @property
    def text(self) -> str:
        if self.level == EMPTY:
            return f"Pin tay cầm sắp hết: {self.device} — sạc ngay"
        return f"Pin tay cầm yếu: {self.device}"

    @property
    def urgent(self) -> bool:
        return self.level == EMPTY


class BatteryWatch:
    """Remembers each controller's level and decides when a warning is due.

    A warning is due when a controller drops to low / empty, again every REMIND_* seconds while it stays there, and at
    once when it goes from low to empty. Charging, a better level or unplugging the controller clears its state.
    """

    def __init__(self):
        self.levels: dict[str, str] = {}
        self._warned: dict[str, tuple[str, float]] = {}       # device -> (level warned about, when)

    def update(self, levels: dict[str, str], now: float) -> list[BatteryAlert]:
        alerts: list[BatteryAlert] = []
        for device in list(self.levels):
            if device not in levels:                          # unplugged / switched off
                self.levels.pop(device, None)
                self._warned.pop(device, None)
        for device, level in levels.items():
            previous = self.levels.get(device)
            self.levels[device] = level
            if previous != level:
                logger.info(f"{TAG} {device}: {previous or 'new'} -> {level}")
            if not is_warning(level):
                self._warned.pop(device, None)
                continue
            warned = self._warned.get(device)
            gap = REMIND_EMPTY_SECONDS if level == EMPTY else REMIND_LOW_SECONDS
            due = (warned is None
                   or (level == EMPTY and warned[0] != EMPTY)        # got worse
                   or now - warned[1] >= gap)
            if due:
                self._warned[device] = (level, now)
                alerts.append(BatteryAlert(device, level))
                logger.info(f"{TAG} warning: {device} battery {level}")
        return alerts

    def summary(self) -> str:
        """"Xbox Controller: yếu" for the status badges ("" when no level is known)."""
        parts = [f"{d}: {LABELS[l]}" for d, l in self.levels.items() if l != UNKNOWN]
        return " · ".join(parts)
