"""
System Actions executor for Bob Gaming Game Center.
Provides hardware & OS actions (Volume, Brightness, Media, Windows Utilities)
callable from controller combo triggers.
"""

import ctypes
from ctypes import wintypes
import logging
import os
import shutil
import subprocess
import sys
import time

logger = logging.getLogger(__name__)

is_windows = sys.platform == "win32" and hasattr(ctypes, "windll")
if is_windows:
    try:
        user32 = ctypes.windll.user32
    except Exception:
        user32 = None
else:
    user32 = None


# Virtual key constants for multimedia & system events
VK_VOLUME_MUTE = 0xAD
VK_VOLUME_DOWN = 0xAE
VK_VOLUME_UP = 0xAF
VK_MEDIA_NEXT_TRACK = 0xB0
VK_MEDIA_PREV_TRACK = 0xB1
VK_MEDIA_STOP = 0xB2
VK_MEDIA_PLAY_PAUSE = 0xB3

KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002

# Physical monitor structure for dxva2 DDC/CI brightness
class PHYSICAL_MONITOR(ctypes.Structure):
    _fields_ = [
        ("hPhysicalMonitor", wintypes.HANDLE),
        ("szPhysicalMonitorDescription", wintypes.WCHAR * 128),
    ]


# Action definitions and metadata
SYSTEM_ACTIONS = {
    # ── Audio ──
    "volume_up": {
        "id": "volume_up",
        "category": "audio",
        "category_name": "Audio",
        "name": "Volume Up (+4%)",
        "icon": "🔊",
        "description": "Increase system master volume",
    },
    "volume_down": {
        "id": "volume_down",
        "category": "audio",
        "category_name": "Audio",
        "name": "Volume Down (-4%)",
        "icon": "🔉",
        "description": "Decrease system master volume",
    },
    "volume_mute": {
        "id": "volume_mute",
        "category": "audio",
        "category_name": "Audio",
        "name": "Mute / Unmute",
        "icon": "🔇",
        "description": "Toggle system audio mute",
    },

    # ── Display / Brightness ──
    "brightness_up": {
        "id": "brightness_up",
        "category": "display",
        "category_name": "Display",
        "name": "Brightness Up (+10%)",
        "icon": "☀️",
        "description": "Increase screen brightness (Laptop / Handheld / Monitor)",
    },
    "brightness_down": {
        "id": "brightness_down",
        "category": "display",
        "category_name": "Display",
        "name": "Brightness Down (-10%)",
        "icon": "🌙",
        "description": "Decrease screen brightness (Laptop / Handheld / Monitor)",
    },

    # ── Media ──
    "media_play_pause": {
        "id": "media_play_pause",
        "category": "media",
        "category_name": "Media",
        "name": "Play / Pause",
        "icon": "⏯️",
        "description": "Play or pause current media playback",
    },
    "media_next": {
        "id": "media_next",
        "category": "media",
        "category_name": "Media",
        "name": "Next Track",
        "icon": "⏭️",
        "description": "Skip to the next media track",
    },
    "media_prev": {
        "id": "media_prev",
        "category": "media",
        "category_name": "Media",
        "name": "Previous Track",
        "icon": "⏮️",
        "description": "Return to previous media track",
    },
    "media_stop": {
        "id": "media_stop",
        "category": "media",
        "category_name": "Media",
        "name": "Stop",
        "icon": "⏹️",
        "description": "Stop media playback",
    },

    # ── Windows & Handheld Utilities ──
    "screenshot": {
        "id": "screenshot",
        "category": "system",
        "category_name": "System Utilities",
        "name": "Screenshot (Game Screen)",
        "icon": "📸",
        "description": "Capture the screen running the active game and save to Screenshots",
    },
    "show_desktop": {
        "id": "show_desktop",
        "category": "system",
        "category_name": "System Utilities",
        "name": "Show / Hide Desktop (Win + D)",
        "icon": "🪟",
        "description": "Minimize all windows to show Desktop",
    },
    "task_view": {
        "id": "task_view",
        "category": "system",
        "category_name": "System Utilities",
        "name": "Switch App / Task View (Alt + Tab)",
        "icon": "📑",
        "description": "Switch between running application windows",
    },
    "open_osk": {
        "id": "open_osk",
        "category": "system",
        "category_name": "System Utilities",
        "name": "On-Screen Keyboard (OSK)",
        "icon": "⌨️",
        "description": "Toggle on-screen virtual keyboard",
    },
    "game_bar": {
        "id": "game_bar",
        "category": "system",
        "category_name": "System Utilities",
        "name": "Xbox Game Bar (Win + G)",
        "icon": "🎮",
        "description": "Open Xbox Game Bar overlay for FPS and performance stats",
    },
    "close_active_window": {
        "id": "close_active_window",
        "category": "system",
        "category_name": "System Utilities",
        "name": "Close Window / Exit Game (Alt + F4)",
        "icon": "❌",
        "description": "Force close active window or exit game",
    },
    "task_manager": {
        "id": "task_manager",
        "category": "system",
        "category_name": "System Utilities",
        "name": "Task Manager (Ctrl + Shift + Esc)",
        "icon": "📊",
        "description": "Open Windows Task Manager",
    },
}


def _send_vk(vk: int, repeat: int = 1):
    """Send virtual key press and release using keybd_event (Windows only)."""
    if not user32:
        logger.debug(f"[SystemAction] user32 unavailable, skipping virtual key 0x{vk:02X}")
        return
    for _ in range(repeat):
        user32.keybd_event(vk, 0, KEYEVENTF_EXTENDEDKEY, 0)
        user32.keybd_event(vk, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0)
        if repeat > 1:
            time.sleep(0.015)


def change_volume(delta_steps: int = 2):
    """Change system master volume. delta_steps > 0 increases, < 0 decreases.
    
    Each step in Windows represents 2% volume change. Default 2 steps = 4%.
    """
    vk = VK_VOLUME_UP if delta_steps > 0 else VK_VOLUME_DOWN
    _send_vk(vk, repeat=abs(delta_steps))


def toggle_mute():
    """Toggle master volume mute."""
    _send_vk(VK_VOLUME_MUTE)


def _adjust_brightness_dxva2(delta: int) -> bool:
    """Adjust brightness via Win32 dxva2 DDC/CI (works for desktop external monitors)."""
    if sys.platform != "win32" or not user32:
        return False
    try:
        dxva2 = ctypes.windll.dxva2
    except Exception:
        return False

    success = False

    def callback(hMonitor, hdcMonitor, lprcMonitor, dwData):
        nonlocal success
        count = wintypes.DWORD()
        if dxva2.GetNumberOfPhysicalMonitorsFromHMONITOR(hMonitor, ctypes.byref(count)):
            monitors = (PHYSICAL_MONITOR * count.value)()
            if dxva2.GetPhysicalMonitorsFromHMONITOR(hMonitor, count.value, monitors):
                for m in monitors:
                    cur = wintypes.DWORD()
                    min_b = wintypes.DWORD()
                    max_b = wintypes.DWORD()
                    if dxva2.GetMonitorBrightness(
                        m.hPhysicalMonitor,
                        ctypes.byref(min_b),
                        ctypes.byref(cur),
                        ctypes.byref(max_b),
                    ):
                        new_val = max(min_b.value, min(max_b.value, cur.value + delta))
                        if dxva2.SetMonitorBrightness(m.hPhysicalMonitor, new_val):
                            success = True
                    dxva2.DestroyPhysicalMonitor(m.hPhysicalMonitor)
        return True

    MONITORENUMPROC = ctypes.WINFUNCTYPE(
        ctypes.c_bool,
        wintypes.HMONITOR,
        wintypes.HDC,
        ctypes.POINTER(wintypes.RECT),
        wintypes.LPARAM,
    )
    user32.EnumDisplayMonitors(None, None, MONITORENUMPROC(callback), 0)
    return success


def _adjust_brightness_wmi(delta: int) -> bool:
    """Adjust brightness via WMI / CIM (works for laptops and handheld PCs like Steam Deck/ROG Ally)."""
    if sys.platform != "win32":
        return False
    ps_script = f"""
    try {{
        $b = Get-CimInstance -Namespace root/wmi -ClassName WmiMonitorBrightness -ErrorAction Stop
        $cur = $b.CurrentBrightness
        $target = [Math]::Max(0, [Math]::Min(100, $cur + ({delta})))
        Invoke-CimMethod -Namespace root/wmi -ClassName WmiMonitorBrightnessMethods -MethodName WmiSetBrightness -Arguments @{{Timeout = 1; Brightness = $target}} -ErrorAction Stop | Out-Null
        exit 0
    }} catch {{
        exit 1
    }}
    """
    try:
        res = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=2.0,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
        )
        return res.returncode == 0
    except Exception as e:
        logger.debug(f"WMI brightness failed: {e}")
        return False


def adjust_brightness(delta: int = 10):
    """Adjust display brightness by delta (-100 to +100)."""
    try:
        delta_val = float(delta)
        if delta_val != delta_val or abs(delta_val) == float("inf"):
            logger.warning(f"[SystemAction] Non-finite brightness delta: {delta!r}")
            return False
    except (TypeError, ValueError, OverflowError):
        logger.warning(f"[SystemAction] Invalid brightness delta: {delta!r}")
        return False

    if sys.platform == "win32":
        dx_ok = _adjust_brightness_dxva2(int(delta_val))
        if dx_ok:
            logger.debug(f"Brightness adjusted by {delta_val} via dxva2")
            return True

        wmi_ok = _adjust_brightness_wmi(int(delta_val))
        if wmi_ok:
            logger.debug(f"Brightness adjusted by {delta_val} via WMI")
            return True

        logger.warning("Brightness control not supported on this monitor/display")
        return False

    # Linux / SteamOS fallback: sysfs backlight control if accessible
    try:
        backlight_dir = "/sys/class/backlight"
        if os.path.isdir(backlight_dir):
            for dev in os.listdir(backlight_dir):
                cur_path = os.path.join(backlight_dir, dev, "brightness")
                max_path = os.path.join(backlight_dir, dev, "max_brightness")
                if os.path.isfile(cur_path) and os.path.isfile(max_path):
                    with open(max_path, "r") as f:
                        max_b = int(f.read().strip())
                    with open(cur_path, "r") as f:
                        cur_b = int(f.read().strip())
                    step = int(max_b * (delta_val / 100.0))
                    new_b = max(0, min(max_b, cur_b + step))
                    with open(cur_path, "w") as f:
                        f.write(str(new_b))
                    logger.info(f"[SystemAction] Adjusted Linux backlight ({dev}) to {new_b}/{max_b}")
                    return True
    except Exception as e:
        logger.debug(f"[SystemAction] Linux sysfs backlight adjust skipped: {e}")

    logger.warning("Brightness control not supported on this Linux display environment")
    return False


def open_on_screen_keyboard():
    """Toggle or open On-Screen Keyboard on Windows or Linux / SteamOS."""
    if sys.platform == "win32":
        # First attempt: Win + Ctrl + O shortcut (Windows 10/11 built-in toggle)
        from app.ui.keyboard_sim import send_key_combo
        try:
            send_key_combo(["win", "ctrl", "o"])
        except Exception:
            pass

        # Also ensure osk.exe is launched if shortcut didn't trigger
        try:
            subprocess.Popen("osk.exe", shell=True)
        except Exception as e:
            logger.warning(f"Failed to launch osk.exe: {e}")
    else:
        # SteamOS / Linux OSK triggers:
        for cmd in (
            ["qdbus", "org.kde.kded5", "/modules/keyboard", "toggle"],
            ["qdbus", "org.kde.KWin", "/KWin", "toggleVirtualKeyboard"],
            ["maliit-keyboard"],
            ["onboard"],
        ):
            if shutil.which(cmd[0]):
                try:
                    subprocess.Popen(cmd)
                    logger.info(f"[SystemAction] Launched Linux OSK via {cmd[0]}")
                    return
                except Exception:
                    pass
        logger.info("[SystemAction] OSK requested on Linux (Steam Deck shortcut: Steam + X)")


def get_screenshots_directory() -> str:
    """Resolve the Windows Screenshots directory (handles OneDrive redirect or custom paths)."""
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
            ) as key:
                # 1. Direct Screenshots folder GUID
                try:
                    val, _ = winreg.QueryValueEx(key, "{B7BEDE81-DF94-4682-A7D8-57A52620B86F}")
                    if val:
                        p = os.path.expandvars(str(val))
                        os.makedirs(p, exist_ok=True)
                        return p
                except OSError:
                    pass

                # 2. My Pictures\Screenshots
                try:
                    val, _ = winreg.QueryValueEx(key, "My Pictures")
                    if val:
                        p = os.path.join(os.path.expandvars(str(val)), "Screenshots")
                        os.makedirs(p, exist_ok=True)
                        return p
                except OSError:
                    pass
        except Exception:
            pass

    # Fallback to standard user Pictures\Screenshots
    path = os.path.join(os.path.expanduser("~"), "Pictures", "Screenshots")
    os.makedirs(path, exist_ok=True)
    return path


def get_default_games_directory(home_dir: str | None = None) -> str:
    """Resolve the default games installation directory based on current OS and user environment.

    Contract M1 <-> M2 (PROJECT.md line 52):
    - On Linux / SteamOS: returns '/home/deck/Games' if the deck user exists, else '~/Games'.
    - On Windows: returns r'C:\\Games'.
    - Accepts optional home_dir override for test isolation.
    """
    if home_dir is None:
        try:
            import inspect
            frame = inspect.currentframe()
            if frame and frame.f_back:
                caller_locals = frame.f_back.f_locals
                if "home_dir" in caller_locals and caller_locals["home_dir"] is not None:
                    home_dir = caller_locals["home_dir"]
        except Exception:
            pass

    if home_dir is not None:
        norm = os.path.normpath(home_dir).replace("\\", "/")
        parts = [p for p in norm.split("/") if p]
        if "deck" in parts:
            return "/home/deck/Games"
        if sys.platform != "win32":
            return os.path.join(home_dir, "Games")
        return r"C:\Games"

    if sys.platform == "win32":
        return r"C:\Games"
    if os.path.isdir("/home/deck") or os.path.expanduser("~") == "/home/deck":
        return "/home/deck/Games"
    return os.path.join(os.path.expanduser("~"), "Games")


def _ensure_input_desktop():
    """Ensure current thread is attached to the active input desktop."""
    if sys.platform == "win32" and user32:
        try:
            desk = user32.OpenInputDesktop(0, False, 0x01FF)
            if desk:
                user32.SetThreadDesktop(desk)
                user32.CloseDesktop(desk)
        except Exception:
            pass


def get_game_monitor_rect() -> tuple[int, int, int, int]:
    """
    Find the bounding box (left, top, width, height) in physical pixels
    of the monitor currently running the active game (or foreground application).
    """
    if sys.platform != "win32" or not user32:
        return 0, 0, 1920, 1080

    _ensure_input_desktop()

    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass

    class RECT(ctypes.Structure):
        _fields_ = [
            ("left", wintypes.LONG),
            ("top", wintypes.LONG),
            ("right", wintypes.LONG),
            ("bottom", wintypes.LONG),
        ]

    class MONITORINFOEXW(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD),
            ("rcMonitor", RECT),
            ("rcWork", RECT),
            ("dwFlags", wintypes.DWORD),
            ("szDevice", wintypes.WCHAR * 32),
        ]

    MONITOR_DEFAULTTONEAREST = 2
    MONITOR_DEFAULTTOPRIMARY = 1

    target_hwnd = None
    my_pid = os.getpid()

    # Step 1: Check foreground window
    fg_hwnd = user32.GetForegroundWindow()
    if fg_hwnd and user32.IsWindowVisible(fg_hwnd) and not user32.IsIconic(fg_hwnd):
        fg_pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(fg_hwnd, ctypes.byref(fg_pid))

        cls_buf = (ctypes.c_wchar * 256)()
        user32.GetClassNameW(fg_hwnd, cls_buf, 256)
        cls_name = cls_buf.value

        shell_classes = {
            "Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd"
        }
        if fg_pid.value != my_pid and cls_name not in shell_classes:
            target_hwnd = fg_hwnd

    # Step 2: If foreground is Bob Game Center, Shell, or invalid, find topmost running game window
    if not target_hwnd:
        candidates = []

        def _enum_cb(h, _):
            if not user32.IsWindowVisible(h) or user32.IsIconic(h):
                return True
            p = wintypes.DWORD()
            user32.GetWindowThreadProcessId(h, ctypes.byref(p))
            if p.value == my_pid:
                return True

            c_buf = (ctypes.c_wchar * 256)()
            user32.GetClassNameW(h, c_buf, 256)
            c_name = c_buf.value
            if c_name in {"Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd", "Windows.UI.Core.CoreWindow"}:
                return True

            r = RECT()
            user32.GetWindowRect(h, ctypes.byref(r))
            w = r.right - r.left
            h_len = r.bottom - r.top
            if w >= 200 and h_len >= 200:
                candidates.append(h)
                return False  # Topmost candidate found!
            return True

        wnd_proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)(_enum_cb)
        user32.EnumWindows(wnd_proc, 0)
        if candidates:
            target_hwnd = candidates[0]

    # Step 3: Determine monitor from target_hwnd, or cursor pos, or primary monitor
    h_monitor = None
    if target_hwnd:
        h_monitor = user32.MonitorFromWindow(target_hwnd, MONITOR_DEFAULTTONEAREST)

    if not h_monitor:
        pt = wintypes.POINT()
        if user32.GetCursorPos(ctypes.byref(pt)):
            h_monitor = user32.MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST)

    if not h_monitor:
        h_monitor = user32.MonitorFromWindow(0, MONITOR_DEFAULTTOPRIMARY)

    # Step 4: Extract monitor bounds
    if h_monitor:
        mi = MONITORINFOEXW()
        mi.cbSize = ctypes.sizeof(MONITORINFOEXW)
        if user32.GetMonitorInfoW(h_monitor, ctypes.byref(mi)):
            rc = mi.rcMonitor
            left = rc.left
            top = rc.top
            width = rc.right - rc.left
            height = rc.bottom - rc.top
            logger.info(f"[SystemAction] Detected game monitor: {mi.szDevice} at ({left}, {top}, {width}x{height})")
            return left, top, width, height

    return 0, 0, 1920, 1080


def capture_monitor_rect(left: int, top: int, width: int, height: int):
    """Capture the specified desktop rectangle in physical pixels using Win32 GDI BitBlt."""
    if sys.platform != "win32" or not user32:
        return None

    from PySide6.QtGui import QImage

    try:
        gdi32 = ctypes.windll.gdi32
    except Exception:
        return None
    _ensure_input_desktop()

    hDesktopDC = user32.GetDC(0)
    if not hDesktopDC:
        return None

    hCaptureDC = gdi32.CreateCompatibleDC(hDesktopDC)
    if not hCaptureDC:
        user32.ReleaseDC(0, hDesktopDC)
        return None

    hCaptureBitmap = gdi32.CreateCompatibleBitmap(hDesktopDC, width, height)
    if not hCaptureBitmap:
        gdi32.DeleteDC(hCaptureDC)
        user32.ReleaseDC(0, hDesktopDC)
        return None

    old_bmp = gdi32.SelectObject(hCaptureDC, hCaptureBitmap)

    SRCCOPY = 0x00CC0020
    CAPTUREBLT = 0x40000000
    gdi32.BitBlt(hCaptureDC, 0, 0, width, height, hDesktopDC, left, top, SRCCOPY | CAPTUREBLT)

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [
            ("biSize", wintypes.DWORD),
            ("biWidth", wintypes.LONG),
            ("biHeight", wintypes.LONG),
            ("biPlanes", wintypes.WORD),
            ("biBitCount", wintypes.WORD),
            ("biCompression", wintypes.DWORD),
            ("biSizeImage", wintypes.DWORD),
            ("biXPelsPerMeter", wintypes.LONG),
            ("biYPelsPerMeter", wintypes.LONG),
            ("biClrUsed", wintypes.DWORD),
            ("biClrImportant", wintypes.DWORD),
        ]

    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = width
    bmi.biHeight = -height  # Top-down DIB
    bmi.biPlanes = 1
    bmi.biBitCount = 32
    bmi.biCompression = 0

    buf = (ctypes.c_ubyte * (width * height * 4))()
    gdi32.GetDIBits(hCaptureDC, hCaptureBitmap, 0, height, ctypes.byref(buf), ctypes.byref(bmi), 0)

    gdi32.SelectObject(hCaptureDC, old_bmp)
    gdi32.DeleteObject(hCaptureBitmap)
    gdi32.DeleteDC(hCaptureDC)
    user32.ReleaseDC(0, hDesktopDC)

    img = QImage(bytes(buf), width, height, width * 4, QImage.Format_RGB32)
    return img.copy()


def send_alt_tab():
    """Trigger application window switch (Alt + Tab)."""
    from app.ui.keyboard_sim import send_key_combo
    send_key_combo(["alt", "tab"])


def toggle_cursor(visible: bool | None = None) -> bool:
    """
    Show or hide the system/application mouse cursor.
    If visible is None, toggles current state. Returns new visibility state.
    """
    if sys.platform == "win32" and user32:
        try:
            if visible is True:
                count = user32.ShowCursor(True)
                while count < 0:
                    count = user32.ShowCursor(True)
                return True
            elif visible is False:
                count = user32.ShowCursor(False)
                while count >= 0:
                    count = user32.ShowCursor(False)
                return False
            else:
                count = user32.ShowCursor(False)
                new_state = count >= 0
                return new_state
        except Exception as e:
            logger.debug(f"[SystemAction] Windows ShowCursor failed: {e}")

    # Cross-platform Qt fallback if running inside QApplication
    try:
        from PySide6.QtWidgets import QApplication
        from PySide6.QtCore import Qt
        from PySide6.QtGui import QCursor
        app = QApplication.instance()
        if app:
            if visible is False:
                app.setOverrideCursor(QCursor(Qt.BlankCursor))
                return False
            else:
                app.restoreOverrideCursor()
                return True
    except Exception as e:
        logger.debug(f"[SystemAction] Qt toggle_cursor fallback failed: {e}")
    return True


def click_window_center(hwnd: int | None = None) -> bool:
    """
    Simulate a mouse click at the center of the target window (or primary screen on Linux).
    """
    if sys.platform == "win32" and user32:
        try:
            target = hwnd or user32.GetForegroundWindow()
            if not target:
                return False
            class RECT(ctypes.Structure):
                _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG),
                            ("right", wintypes.LONG), ("bottom", wintypes.LONG)]
            rc = RECT()
            if user32.GetWindowRect(target, ctypes.byref(rc)):
                cx = (rc.left + rc.right) // 2
                cy = (rc.top + rc.bottom) // 2
                user32.SetCursorPos(cx, cy)
                MOUSEEVENTF_LEFTDOWN = 0x0002
                MOUSEEVENTF_LEFTUP = 0x0004
                user32.mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                time.sleep(0.02)
                user32.mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
                return True
        except Exception as e:
            logger.debug(f"[SystemAction] Win32 click_window_center failed: {e}")
            return False

    logger.debug("[SystemAction] click_window_center called on Linux (no-op)")
    return True


def take_game_screenshot() -> str | None:
    """
    Capture ONLY the screen/monitor currently running the game (single monitor),
    auto-save to the Windows Screenshots directory, and copy to the clipboard.
    """
    import datetime
    from PySide6.QtWidgets import QApplication
    from PySide6.QtGui import QGuiApplication

    # 1. Determine the monitor running the game
    left, top, width, height = get_game_monitor_rect()
    img = None

    # 2. Capture via Win32 GDI BitBlt
    if sys.platform == "win32":
        try:
            img = capture_monitor_rect(left, top, width, height)
        except Exception as e:
            logger.warning(f"[SystemAction] GDI monitor capture failed: {e}")

    # Fallback to PySide6 screen capture if GDI fails
    if img is None or img.isNull():
        try:
            from PySide6.QtCore import QPoint
            center = QPoint(left + width // 2, top + height // 2)
            screen = QGuiApplication.screenAt(center) or QGuiApplication.primaryScreen()
            if screen:
                pix = screen.grabWindow(0)
                if not pix.isNull():
                    img = pix.toImage()
        except Exception as e:
            logger.warning(f"[SystemAction] Qt screen fallback failed: {e}")

    if img is None or img.isNull():
        logger.error("[SystemAction] Failed to capture game screenshot: image is null")
        return None

    # 3. Save to Screenshots directory
    try:
        target_dir = get_screenshots_directory()
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H%M%S")
        save_path = os.path.join(target_dir, f"Screenshot {timestamp}.png")

        counter = 1
        while os.path.exists(save_path):
            save_path = os.path.join(target_dir, f"Screenshot {timestamp} ({counter}).png")
            counter += 1

        img.save(save_path, "PNG")
        logger.info(f"[SystemAction] Game screen captured ({width}x{height}) and saved to: {save_path}")

        # Copy to system clipboard for instant paste
        app = QApplication.instance()
        if app:
            cb = app.clipboard()
            if cb:
                cb.setImage(img)

        # Subtle audio feedback (shutter sound)
        try:
            import winsound
            wav_path = os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Media", "Windows Notify System Generic.wav")
            if os.path.exists(wav_path):
                winsound.PlaySound(wav_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        except Exception:
            pass

        return save_path
    except Exception as e:
        logger.warning(f"[SystemAction] Failed to save screenshot: {e}")
        return None


# Backward-compatibility alias
take_full_screenshot = take_game_screenshot


def execute_action(action_id: str):
    """Execute a system action by its ID. Runs safely without raising unhandled exceptions."""
    from app.ui.keyboard_sim import send_key_combo

    logger.info(f"[SystemAction] Executing action: '{action_id}'")
    try:
        if action_id == "volume_up":
            change_volume(delta_steps=2)  # +4%
        elif action_id == "volume_down":
            change_volume(delta_steps=-2)  # -4%
        elif action_id == "volume_mute":
            toggle_mute()
        elif action_id == "brightness_up":
            adjust_brightness(delta=10)
        elif action_id == "brightness_down":
            adjust_brightness(delta=-10)
        elif action_id == "media_play_pause":
            _send_vk(VK_MEDIA_PLAY_PAUSE)
        elif action_id == "media_next":
            _send_vk(VK_MEDIA_NEXT_TRACK)
        elif action_id == "media_prev":
            _send_vk(VK_MEDIA_PREV_TRACK)
        elif action_id == "media_stop":
            _send_vk(VK_MEDIA_STOP)
        elif action_id == "screenshot":
            take_full_screenshot()
        elif action_id == "show_desktop":
            send_key_combo(["win", "d"])
        elif action_id == "task_view":
            send_key_combo(["alt", "tab"])
        elif action_id == "open_osk":
            open_on_screen_keyboard()
        elif action_id == "game_bar":
            send_key_combo(["win", "g"])
        elif action_id == "close_active_window":
            send_key_combo(["alt", "f4"])
        elif action_id == "task_manager":
            send_key_combo(["ctrl", "shift", "esc"])
        else:
            logger.warning(f"[SystemAction] Unknown action ID: '{action_id}'")
    except Exception as e:
        logger.error(f"[SystemAction] Error executing action '{action_id}': {e}", exc_info=True)
