"""Pin PyInstaller's embedded PYZ archive to its original file inode on Windows.

PyInstaller --onefile re-opens ``sys.executable`` by string path on every lazy
import so the executable is not locked against rename. When ``build.py`` or an
updater renames the running ``.exe`` to ``.old_*`` and writes a new ``.exe`` at
the original path, subsequent lazy imports read the new file using the old
archive's byte offsets and fail with ``zlib.error: Error -3``.

Opening the archive once at startup with ``FILE_SHARE_READ | FILE_SHARE_WRITE |
FILE_SHARE_DELETE`` keeps rename/delete-on-close working while pinning all lazy
imports to the original executable's bytes.
"""

from __future__ import annotations

import logging
import marshal
import os
import sys
import threading
import time
import zlib
from typing import BinaryIO

logger = logging.getLogger(__name__)

_GENERIC_READ = 0x80000000
_FILE_SHARE_ALL = 0x01 | 0x02 | 0x04  # READ | WRITE | DELETE
_OPEN_EXISTING = 3

_PYZ_ITEM_MODULE = 0
_PYZ_ITEM_PKG = 1
_PYZ_ITEM_NSPKG = 3

_PINNED_STREAMS: list[BinaryIO] = []


def _open_shared_readonly(path: str) -> BinaryIO | None:
    """Open *path* on Windows with FILE_SHARE_DELETE so rename/unlink still succeed."""
    if sys.platform != "win32":
        return None
    import ctypes
    import msvcrt

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateFileW.argtypes = [
        ctypes.c_wchar_p,
        ctypes.c_uint32,
        ctypes.c_uint32,
        ctypes.c_void_p,
        ctypes.c_uint32,
        ctypes.c_uint32,
        ctypes.c_void_p,
    ]
    kernel32.CreateFileW.restype = ctypes.c_void_p

    invalid = ctypes.c_void_p(-1).value
    handle = kernel32.CreateFileW(path, _GENERIC_READ, _FILE_SHARE_ALL, None, _OPEN_EXISTING, 0, None)
    if not handle or handle == invalid:
        err = ctypes.get_last_error()
        logger.warning(f"[PyzPin] Could not open PYZ archive {path!r} (winerr={err}); keeping default reader")
        return None

    fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
    return os.fdopen(fd, "rb")


def pin_pyz_archive(archive: object) -> bool:
    """Bind *archive.extract* to a shared-delete file handle for *archive._filename*."""
    t0 = time.perf_counter()
    try:
        if getattr(archive, "_pyz_pinned", False):
            return True
        filename = getattr(archive, "_filename", None)
        start_offset = getattr(archive, "_start_offset", None)
        toc = getattr(archive, "toc", None)
        if not filename or start_offset is None or not isinstance(toc, dict):
            logger.warning("[PyzPin] Archive object missing expected attributes; skipping pin")
            return False

        fp = _open_shared_readonly(filename)
        if fp is None:
            return False

        lock = threading.Lock()
        _PINNED_STREAMS.append(fp)

        def _pinned_extract(name: str, raw: bool = False):
            entry = toc.get(name)
            if entry is None:
                raise KeyError(f"No entry named {name!r} found in the archive!")
            typecode, entry_offset, entry_length = entry
            if typecode == _PYZ_ITEM_NSPKG:
                return None
            try:
                with lock:
                    fp.seek(start_offset + entry_offset)
                    data = fp.read(entry_length)
                decompressed = zlib.decompress(data)
                if typecode in (_PYZ_ITEM_MODULE, _PYZ_ITEM_PKG) and not raw:
                    return marshal.loads(decompressed)
                return decompressed
            except EOFError as exc:
                logger.error(f"[PyzPin] Truncated PYZ entry {name!r}", exc_info=True)
                raise ImportError(f"Failed to unmarshal PYZ entry {name!r}!") from exc
            except Exception as exc:
                logger.error(f"[PyzPin] Failed to extract PYZ entry {name!r}: {exc}", exc_info=True)
                raise

        archive.extract = _pinned_extract  # type: ignore[attr-defined]
        archive._pyz_pinned = True  # type: ignore[attr-defined]
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        logger.info(
            f"[PyzPin] Pinned frozen PYZ archive ({len(toc)} modules, file={os.path.basename(filename)}) "
            f"in {elapsed_ms:.1f}ms"
        )
        return True
    except Exception:
        logger.exception("[PyzPin] Unexpected error while pinning PYZ archive")
        return False


def install_frozen_pyz_pin() -> bool:
    """Pin PyInstaller's global ``pyimod02_importers.pyz_archive`` when running frozen on Windows."""
    if sys.platform != "win32" or not getattr(sys, "frozen", False):
        return False
    importers = sys.modules.get("pyimod02_importers")
    archive = getattr(importers, "pyz_archive", None) if importers is not None else None
    if archive is None:
        logger.warning("[PyzPin] Frozen runtime active but pyimod02_importers.pyz_archive not found")
        return False
    return pin_pyz_archive(archive)


def _close_pinned_streams_for_test() -> None:
    """Close pinned file handles in unit tests so temporary directories can be cleaned up."""
    while _PINNED_STREAMS:
        stream = _PINNED_STREAMS.pop()
        try:
            stream.close()
        except OSError:
            pass
