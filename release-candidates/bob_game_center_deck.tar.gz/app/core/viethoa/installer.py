"""Vietnamese Localization (Việt Hoá) Installer and Game Directory Resolver.

Complies with Bob Game Center architectural standards:
- Logging: TAG = "[VietHoa/Installer]"
- Step-out root detection for bin/, Engine/Binaries/Win64/, etc.
- Process lock guard: prevents WinError 32 overwrite errors when game is running
- Non-blocking execution with progress callbacks
- Atomic write-ahead journal and automated rollback on failure
"""

from __future__ import annotations

import ctypes
import logging
import os
import re
import shutil
import sys
import threading
from typing import Callable, Optional

from app.core.viethoa.extractor import extract_archive
from app.core.viethoa.manifest import (
    STATUS_COMMITTED,
    _force_remove_file,
    commit_manifest,
    create_manifest_journal,
    force_remove_tree,
    load_manifest,
    rollback_manifest,
)
from app.core.viethoa.models import VietHoaTranslation

logger = logging.getLogger(__name__)
TAG = "[VietHoa/Installer]"

# Subdirectories containing executables that must step out to game root
_BINARY_SUBDIRS = frozenset(
    {
        "bin",
        "bins",
        "binaries",
        "binary",
        "x64",
        "x86",
        "win64",
        "win32",
        "win_x64",
        "win_x86",
        "x86_64",
        "amd64",
        "retail",
        "release",
        "shipping",
        "final",
        "pc",
        "game_exe",
    }
)

_folder_locks: dict[str, threading.RLock] = {}
_folder_locks_guard = threading.Lock()


def folder_lock(game_root: str) -> threading.RLock:
    """Thread-safe re-entrant lock ensuring operations on the same game directory do not race."""
    key = os.path.normcase(os.path.normpath(os.path.abspath(game_root)))
    with _folder_locks_guard:
        return _folder_locks.setdefault(key, threading.RLock())


def resolve_game_install_dir(game_path: str) -> str:
    """Resolve the actual root installation folder for a game.

    Steps out of executable files, binary subdirectories (bin/, bin/x64/),
    and Unreal Engine hierarchy (Engine/Binaries/Win64/, <Project>/Binaries/Win64/).

    Args:
        game_path: Full path to a game executable or any subdirectory.

    Returns:
        Absolute normalized path to the root installation directory.
    """
    if not game_path or not str(game_path).strip():
        return ""

    p = os.path.normpath(os.path.abspath(str(game_path).strip().strip('"')))
    if os.path.isfile(p) or p.lower().endswith((".exe", ".bat", ".cmd", ".lnk")):
        p = os.path.dirname(p)

    parts = p.replace("/", os.sep).split(os.sep)

    # 1. Unreal Engine 3-level step-out:
    # E.g. <Root>/Engine/Binaries/Win64 -> <Root>
    # E.g. <Root>/<Project>/Binaries/Win64 -> <Root>
    if len(parts) >= 4:
        p_leaf = parts[-1].lower()
        p_mid = parts[-2].lower()
        p_top = parts[-3].lower()

        if p_leaf in ("win64", "win32", "x64") and p_mid in ("binaries", "bin"):
            if p_top == "engine":
                return os.path.dirname(os.path.dirname(os.path.dirname(p)))
            # Check if grandparent has Content, Engine, or game structure
            grandparent = os.path.dirname(os.path.dirname(os.path.dirname(p)))
            parent_dir = os.path.dirname(p)
            if (
                os.path.isdir(os.path.join(grandparent, "Engine"))
                or os.path.isdir(os.path.join(grandparent, parts[-3], "Content"))
                or os.path.isdir(os.path.join(parent_dir, "Content"))
            ):
                return grandparent

    # 2. 2-level step-out:
    # E.g. <Root>/bin/x64, <Root>/bin/win64, <Root>/binaries/win64
    if len(parts) >= 3:
        p_leaf = parts[-1].lower()
        p_mid = parts[-2].lower()
        if p_mid in ("bin", "binaries") and p_leaf in ("x64", "win64", "win32", "x86"):
            return os.path.dirname(os.path.dirname(p))

    # 3. 1-level step-out:
    # E.g. <Root>/bin, <Root>/x64, <Root>/bin64, <Root>/win64, <Root>/shipping, <Root>/retail
    if len(parts) >= 2:
        p_leaf = parts[-1].lower()
        if p_leaf in _BINARY_SUBDIRS:
            return os.path.dirname(p)

    return p


_REPO_ROOT_META_FILES = frozenset(
    {".gitattributes", ".gitignore", "license", "license.txt", "license.md", "readme.md"}
)


def _strip_rel_path(clean_rel: str, strip_components: int) -> str | None:
    """Apply tar-style strip_components to an extracted relative path."""
    if strip_components <= 0:
        return clean_rel
    parts = [seg for seg in clean_rel.split("/") if seg]
    if len(parts) <= strip_components:
        return None
    remainder = parts[strip_components:]
    if len(remainder) == 1 and remainder[0].lower() in _REPO_ROOT_META_FILES:
        return None
    return "/".join(remainder)


def _find_steam_library_roots() -> list[str]:
    """Locate Steam library root folders across Windows and Linux/SteamOS."""
    steam_roots: list[str] = []
    if sys.platform == "win32":
        try:
            import winreg

            for hive, subkey, val_name in (
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath"),
                (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
            ):
                try:
                    with winreg.OpenKey(hive, subkey) as k:
                        val, _ = winreg.QueryValueEx(k, val_name)
                        if val and os.path.isdir(str(val)):
                            steam_roots.append(os.path.normpath(str(val)))
                except OSError:
                    pass
        except ImportError:
            pass
        for fallback in (r"C:\Program Files (x86)\Steam", r"C:\Program Files\Steam"):
            if os.path.isdir(fallback):
                steam_roots.append(fallback)
    else:
        home = os.path.expanduser("~")
        for fallback in (
            os.path.join(home, ".local", "share", "Steam"),
            os.path.join(home, ".steam", "steam"),
            os.path.join(home, ".var", "app", "com.valvesoftware.Steam", "data", "Steam"),
        ):
            if os.path.isdir(fallback):
                steam_roots.append(fallback)

    libs: list[str] = []
    seen: set[str] = set()
    for root in steam_roots:
        for cand in [root]:
            nk = os.path.normcase(os.path.normpath(cand))
            if nk not in seen and os.path.isdir(cand):
                seen.add(nk)
                libs.append(os.path.normpath(cand))
        vdf_path = os.path.join(root, "steamapps", "libraryfolders.vdf")
        if os.path.isfile(vdf_path):
            try:
                with open(vdf_path, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read()
                for m in re.finditer(r'"path"\s+"([^"]+)"', text):
                    lib_dir = os.path.normpath(m.group(1).replace("\\\\", "\\"))
                    nk = os.path.normcase(lib_dir)
                    if nk not in seen and os.path.isdir(lib_dir):
                        seen.add(nk)
                        libs.append(lib_dir)
            except OSError:
                pass
    return libs


def discover_installed_game_dir(game_name: str, steam_appid: int | None = None) -> str:
    """Discover install directory for an installed Steam/local game when config omits install_location."""
    if steam_appid:
        # 1. Check Steam libraryfolders.vdf + appmanifest_<appid>.acf (Windows & SteamOS)
        for lib in _find_steam_library_roots():
            acf = os.path.join(lib, "steamapps", f"appmanifest_{int(steam_appid)}.acf")
            if os.path.isfile(acf):
                try:
                    with open(acf, "r", encoding="utf-8", errors="ignore") as f:
                        acf_text = f.read()
                    m = re.search(r'"installdir"\s+"([^"]+)"', acf_text)
                    if m:
                        cand = os.path.join(lib, "steamapps", "common", m.group(1))
                        if os.path.isdir(cand):
                            logger.info(
                                f"{TAG} Discovered Steam install dir via appmanifest_{steam_appid}.acf: {cand}"
                            )
                            return cand
                except OSError:
                    pass

        # 2. Windows Uninstall Registry fallback for Steam App <appid>
        if sys.platform == "win32":
            try:
                import winreg

                sub = rf"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App {int(steam_appid)}"
                for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                    for flag in (0, getattr(winreg, "KEY_WOW64_64KEY", 0), getattr(winreg, "KEY_WOW64_32KEY", 0)):
                        try:
                            with winreg.OpenKey(hive, sub, 0, winreg.KEY_READ | flag) as k:
                                loc, _ = winreg.QueryValueEx(k, "InstallLocation")
                                if loc and os.path.isdir(str(loc)):
                                    logger.info(f"{TAG} Discovered Registry InstallLocation for {steam_appid}: {loc}")
                                    return os.path.normpath(str(loc))
                        except OSError:
                            pass
            except ImportError:
                pass

    # 3. Exact name match against installed Steam games
    clean_query = (game_name or "").strip().lower()
    if clean_query:
        try:
            from app.core.game_scanner import scan_steam_games

            for sg in scan_steam_games():
                loc = sg.get("install_location") or ""
                if loc and str(sg.get("name") or "").strip().lower() == clean_query and os.path.isdir(loc):
                    logger.info(f"{TAG} Discovered Steam scan install dir for {game_name!r}: {loc}")
                    return os.path.normpath(loc)
        except Exception as e:
            logger.debug(f"{TAG} scan_steam_games fallback skipped: {e}")

    return ""


def _get_running_process_names_windows() -> set[str]:
    """Enumerate running process names on Windows via Toolhelp32 snapshot."""
    names: set[str] = set()
    if sys.platform != "win32":
        return names

    from ctypes import wintypes

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.c_size_t),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", wintypes.LONG),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", wintypes.WCHAR * 260),
        ]

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    k32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    k32.Process32FirstW.argtypes = k32.Process32NextW.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(PROCESSENTRY32W),
    ]
    k32.CloseHandle.argtypes = [wintypes.HANDLE]

    snap = k32.CreateToolhelp32Snapshot(0x2, 0)  # TH32CS_SNAPPROCESS
    if snap in (None, wintypes.HANDLE(-1).value):
        return names

    try:
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(entry)
        ok = k32.Process32FirstW(snap, ctypes.byref(entry))
        while ok:
            names.add(entry.szExeFile.lower())
            ok = k32.Process32NextW(snap, ctypes.byref(entry))
    except Exception as e:
        logger.debug(f"{TAG} Toolhelp32 process enumeration error: {e}")
    finally:
        k32.CloseHandle(snap)

    return names


def get_running_game_processes(game_root: str) -> list[str]:
    """Find any running processes that originate from or match executables in game_root."""
    norm_root = resolve_game_install_dir(game_root)
    if not os.path.isdir(norm_root):
        return []

    # 1. Collect all .exe names located inside game_root (search root and immediate binary subfolders)
    exe_names: set[str] = set()
    try:
        for root, _, files in os.walk(norm_root):
            depth = root[len(norm_root) :].count(os.sep)
            if depth > 3:
                continue
            for f in files:
                if f.lower().endswith(".exe"):
                    exe_names.add(f.lower())
    except OSError:
        pass

    if not exe_names:
        return []

    # 2. Check running processes via psutil if available
    try:
        import psutil

        found: set[str] = set()
        for proc in psutil.process_iter(["name", "exe"]):
            try:
                name = (proc.info.get("name") or "").lower()
                if name in exe_names:
                    found.add(name)
                exe_path = proc.info.get("exe")
                if exe_path and os.path.normcase(os.path.abspath(exe_path)).startswith(
                    os.path.normcase(norm_root) + os.sep
                ):
                    found.add(os.path.basename(exe_path).lower())
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return sorted(found)
    except ImportError:
        pass

    # 3. Fallback on Windows via Toolhelp32
    if sys.platform == "win32":
        all_running = _get_running_process_names_windows()
        matched = exe_names.intersection(all_running)
        return sorted(matched)

    return []


def is_game_running(game_root: str) -> bool:
    """Return True if game executables in game_root are currently active or lockfile is present."""
    norm_root = resolve_game_install_dir(game_root)

    # Check test fixture lockfile (.game_running.lock)
    lock_file = os.path.join(norm_root, ".game_running.lock")
    if os.path.exists(lock_file):
        return True

    try:
        running = get_running_game_processes(norm_root)
        if running:
            logger.warning(f"{TAG} Active game processes detected in {norm_root}: {running}")
            return True
        return False
    except Exception as e:
        logger.warning(f"{TAG} Could not query running processes in {norm_root}: {e}")
        return False


def is_viethoa_installed(game_root: str) -> bool:
    """Return True if Vietnamese localization is installed and committed."""
    norm_root = resolve_game_install_dir(game_root)
    manifest = load_manifest(norm_root)
    if not manifest:
        return False
    return manifest.status == STATUS_COMMITTED or manifest.state == "applied"


def get_installed_viethoa_manifest(game_root: str) -> dict | None:
    """Return dictionary representation of the installed manifest if committed, else None."""
    norm_root = resolve_game_install_dir(game_root)
    manifest = load_manifest(norm_root)
    return manifest.to_dict() if manifest else None


def install_viethoa(
    game_root: str,
    archive_path: Optional[str] = None,
    translation: Optional[VietHoaTranslation] = None,
    game_title: str = "Unknown Game",
    progress_callback: Optional[Callable[[int, str], None]] = None,
    cancel_event: Optional[threading.Event] = None,
    staging_dir: Optional[str] = None,
    game_id: str | int = "",
    patch_dir: Optional[str] = None,
) -> tuple[bool, str]:
    """Install Vietnamese localization patch archive into game_root.

    Args:
        game_root: Path to game root directory or game executable.
        archive_path: Optional local path to patch archive (.zip, .7z, etc.).
        translation: VietHoaTranslation metadata release.
        game_title: Display name of the game.
        progress_callback: Optional callback receiving (percent: int, status_message: str).
        cancel_event: Optional threading.Event to abort installation.
        staging_dir: Optional custom staging directory path.
        game_id: Optional game ID for manifest tracking.
        patch_dir: Optional pre-extracted directory containing patch files.
            If provided, skips archive decompression to prevent duplicate extraction.

    Returns:
        Tuple (success: bool, user_message: str).
    """
    root_dir = resolve_game_install_dir(game_root)
    with folder_lock(root_dir):
        # 1. Process lock guard
        if is_game_running(root_dir):
            msg = "Cannot install: Game is currently running. Please close the game first."
            logger.warning(f"{TAG} {msg} ({root_dir})")
            return False, msg

        if cancel_event and cancel_event.is_set():
            return False, "Cancelled by user"

        os.makedirs(root_dir, exist_ok=True)
        active_staging = patch_dir or staging_dir or os.path.join(root_dir, "BobVietHoa_staging")
        os.makedirs(active_staging, exist_ok=True)

        try:
            extracted_rel_paths: list[str] = []

            # 2. Extract or locate patch files
            if patch_dir:
                for root, _, files in os.walk(active_staging):
                    for f in files:
                        src_file = os.path.join(root, f)
                        rel_file = os.path.relpath(src_file, active_staging).replace("\\", "/").lstrip("/")
                        extracted_rel_paths.append(rel_file)
                extracted_rel_paths.sort()
            elif archive_path:
                if progress_callback:
                    progress_callback(10, "Extracting archive...")
                archive_pwd = getattr(getattr(translation, "install_rules", None), "archive_password", None) or None
                extracted_rel_paths = extract_archive(
                    archive_path, active_staging, password=archive_pwd, cancel_event=cancel_event
                )
            elif staging_dir and os.path.exists(staging_dir) and any(os.scandir(staging_dir)):
                for root, _, files in os.walk(active_staging):
                    for f in files:
                        src_file = os.path.join(root, f)
                        rel_file = os.path.relpath(src_file, active_staging).replace("\\", "/").lstrip("/")
                        extracted_rel_paths.append(rel_file)
                extracted_rel_paths.sort()
            else:
                return False, "Installation failed: Neither archive_path nor extracted patch_dir was provided."

            if cancel_event and cancel_event.is_set():
                if not staging_dir and not patch_dir:
                    force_remove_tree(active_staging)
                return False, "Cancelled by user"

            # Determine destination files mapping
            target_sub = getattr(translation, "target_subdir", "")
            if not target_sub and hasattr(translation, "install_rules") and translation.install_rules:
                target_sub = getattr(translation.install_rules, "target_subdir", "")
            strip_n = int(getattr(translation, "strip_components", 0) or 0)
            if not strip_n and hasattr(translation, "install_rules") and translation.install_rules:
                strip_n = int(getattr(translation.install_rules, "strip_components", 0) or 0)

            effective_strip = (
                strip_n
                if strip_n > 0
                and any(len([s for s in r.replace("\\", "/").split("/") if s]) > strip_n for r in extracted_rel_paths)
                else 0
            )
            files_to_install: list[tuple[str, str]] = []
            for rel in extracted_rel_paths:
                src = os.path.join(active_staging, rel)
                clean_rel = rel.replace("\\", "/").lstrip("/")
                stripped_rel = _strip_rel_path(clean_rel, effective_strip)
                if not stripped_rel:
                    continue
                target_rel = f"{target_sub.strip('/')}/{stripped_rel}" if target_sub else stripped_rel
                files_to_install.append((src, target_rel))

            if progress_callback:
                progress_callback(40, "Creating write-ahead journal and backing up files...")

            create_manifest_journal(
                game_root=root_dir,
                game_title=game_title,
                translation=translation,
                files_to_install=files_to_install,
                game_id=game_id,
            )

            if cancel_event and cancel_event.is_set():
                rollback_manifest(root_dir)
                if not staging_dir and not patch_dir:
                    force_remove_tree(active_staging)
                return False, "Cancelled by user"

            if progress_callback:
                progress_callback(70, "Copying localization files into game directory...")

            # 2. Atomic copy using .bobtmp
            for src_abs, target_rel in files_to_install:
                if cancel_event and cancel_event.is_set():
                    rollback_manifest(root_dir)
                    if not staging_dir and not patch_dir:
                        force_remove_tree(active_staging)
                    return False, "Cancelled by user"

                dest_abs = os.path.join(root_dir, target_rel)
                os.makedirs(os.path.dirname(dest_abs), exist_ok=True)
                tmp_dest = dest_abs + ".bobtmp"
                shutil.copy2(src_abs, tmp_dest)
                _force_remove_file(dest_abs)
                os.replace(tmp_dest, dest_abs)

            if progress_callback:
                progress_callback(95, "Finalizing installation manifest...")

            commit_ok = commit_manifest(root_dir)
            if not commit_ok:
                logger.error(
                    f"{TAG} Failed to commit manifest journal for '{game_title}' into '{root_dir}'. Initiating auto-rollback."
                )
                rollback_manifest(root_dir)
                if not staging_dir and not patch_dir and os.path.exists(active_staging):
                    force_remove_tree(active_staging)
                return False, "Failed to commit installation manifest journal"

            # Clean staging
            if not staging_dir and not patch_dir:
                force_remove_tree(active_staging)

            if progress_callback:
                progress_callback(100, "Installation completed successfully")

            logger.info(f"{TAG} Successfully installed VietHoa for '{game_title}' into '{root_dir}'")
            return True, "Vietnamese localization installed successfully"

        except Exception as e:
            logger.error(
                f"{TAG} Installation failed for '{game_title}': {e}. Initiating auto-rollback.",
                exc_info=True,
            )
            rollback_manifest(root_dir)
            if not staging_dir and not patch_dir and os.path.exists(active_staging):
                force_remove_tree(active_staging)
            return False, f"Installation failed: {e}"


def install_viethoa_patch(
    game_root: str,
    extracted_patch_dir: str,
    translation: VietHoaTranslation,
    progress_callback: Optional[Callable[[int, str], None]] = None,
    game_title: str = "Unknown Game",
    game_id: str | int = "",
) -> tuple[bool, str]:
    """Install patch directly from an extracted directory."""
    root_dir = resolve_game_install_dir(game_root)
    with folder_lock(root_dir):
        if is_game_running(root_dir):
            return False, "Cannot install: Game is currently running. Please close the game first."

        os.makedirs(root_dir, exist_ok=True)
        try:
            target_sub = getattr(translation, "target_subdir", "")
            if not target_sub and hasattr(translation, "install_rules") and translation.install_rules:
                target_sub = getattr(translation.install_rules, "target_subdir", "")
            strip_n = int(getattr(translation, "strip_components", 0) or 0)
            if not strip_n and hasattr(translation, "install_rules") and translation.install_rules:
                strip_n = int(getattr(translation.install_rules, "strip_components", 0) or 0)

            raw_patch_files: list[tuple[str, str]] = []
            for root, _, files in os.walk(extracted_patch_dir):
                for f in files:
                    src = os.path.join(root, f)
                    rel = os.path.relpath(src, extracted_patch_dir).replace("\\", "/").lstrip("/")
                    raw_patch_files.append((src, rel))
            effective_strip = (
                strip_n
                if strip_n > 0
                and any(len([s for s in r.split("/") if s]) > strip_n for _, r in raw_patch_files)
                else 0
            )
            files_to_install: list[tuple[str, str]] = []
            for src, rel in raw_patch_files:
                stripped_rel = _strip_rel_path(rel, effective_strip)
                if not stripped_rel:
                    continue
                target_rel = f"{target_sub.strip('/')}/{stripped_rel}" if target_sub else stripped_rel
                files_to_install.append((src, target_rel))

            if progress_callback:
                progress_callback(30, "Creating write-ahead journal and backing up files...")

            create_manifest_journal(root_dir, game_title, translation, files_to_install, game_id=game_id)

            if progress_callback:
                progress_callback(70, "Copying localization files into game directory...")

            for src_abs, target_rel in files_to_install:
                dest_abs = os.path.join(root_dir, target_rel)
                os.makedirs(os.path.dirname(dest_abs), exist_ok=True)
                tmp_dest = dest_abs + ".bobtmp"
                shutil.copy2(src_abs, tmp_dest)
                _force_remove_file(dest_abs)
                os.replace(tmp_dest, dest_abs)

            commit_ok = commit_manifest(root_dir)
            if not commit_ok:
                logger.error(
                    f"{TAG} Failed to commit manifest journal for '{game_title}' into '{root_dir}'. Initiating auto-rollback."
                )
                rollback_manifest(root_dir)
                return False, "Failed to commit installation manifest journal"

            if progress_callback:
                progress_callback(100, "Installation completed successfully")

            return True, "Vietnamese localization installed successfully"
        except Exception as e:
            logger.error(f"{TAG} Patch install failed: {e}. Auto-rolling back.")
            rollback_manifest(root_dir)
            return False, f"Installation failed: {e}"


def uninstall_viethoa(
    game_root: str,
    progress_callback: Optional[Callable[[int, str], None]] = None,
) -> tuple[bool, str]:
    """Uninstall Vietnamese localization and restore original game files."""
    root_dir = resolve_game_install_dir(game_root)
    with folder_lock(root_dir):
        if is_game_running(root_dir):
            msg = "Cannot uninstall: Game is currently running. Please close the game first."
            logger.warning(f"{TAG} {msg} ({root_dir})")
            return False, msg

        if progress_callback:
            progress_callback(20, "Checking running processes...")

        if progress_callback:
            progress_callback(50, "Restoring original files and removing patch...")

        ok, msg = rollback_manifest(root_dir)

        if progress_callback:
            progress_callback(100, "Uninstallation completed")

        return ok, msg


def uninstall_viethoa_patch(
    game_root: str,
    progress_callback: Optional[Callable[[int, str], None]] = None,
) -> tuple[bool, str]:
    """Alias for uninstall_viethoa."""
    return uninstall_viethoa(game_root, progress_callback)


install_viethoa_package = install_viethoa
