"""Multi-Format Archive Extractor & Path Traversal Guards for Bob Game Center.

Features:
- Mandatory Zip-Slip Defense (_safe_target) using os.path.realpath and os.path.commonpath
- Rejects relative traversals (../), leading slashes (/etc), Windows drive letters, and null bytes
- Unpacks .zip, .tar, .tar.gz, .tgz, .tar.bz2, .tar.xz, .7z, .rar
- Handles multi-volume archives (.part1.rar, .7z.001) resolving to primary entry volume
- Tooling discovery using app.core.binary_finder (7z, tar, unrar)
- Returns list of extracted relative file paths
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import sys
import tarfile
import threading
from typing import Callable, Optional

import zipfile

from app.core.binary_finder import find_7z, find_binary, find_tar
from app.utils.helpers import run_hidden

logger = logging.getLogger(__name__)
TAG = "[VietHoa/Extractor]"


class ZipSlipError(ValueError):
    """Raised when an archive member attempts directory traversal outside destination root."""

    pass


def find_unrar() -> Optional[str]:
    """Resolve unrar / rar binary across candidate search directories, system PATH,
    and platform fallback locations.
    """
    if sys.platform == "win32":
        return find_binary(
            "unrar.exe",
            alternate_names=("unrar", "rar.exe", "rar"),
            system_fallbacks=(
                r"C:\Program Files\WinRAR\UnRAR.exe",
                r"C:\Program Files\WinRAR\WinRAR.exe",
                r"C:\Program Files (x86)\WinRAR\UnRAR.exe",
            ),
        )
    return find_binary(
        "unrar",
        alternate_names=("rar",),
        system_fallbacks=(
            "/usr/bin/unrar",
            "/usr/local/bin/unrar",
            "/usr/bin/rar",
        ),
    )


def _safe_target(extract_to: str, member_name: str) -> str:
    """Zip-slip defense: verifies destination path stays strictly inside extract_to root.
    Uses os.path.realpath and os.path.commonpath to prevent path traversal.

    Raises:
        ZipSlipError (subclass of ValueError) on path traversal attempts.
    """
    if not member_name or not str(member_name).strip():
        raise ZipSlipError("Path traversal attempt detected: empty archive member name")

    raw_name = str(member_name).strip()

    # 1. Reject embedded null bytes
    if "\0" in raw_name:
        raise ZipSlipError(f"Path traversal attempt detected: null byte in {raw_name!r}")

    # 2. Reject absolute Unix/POSIX paths and leading backslashes
    if raw_name.startswith("/") or raw_name.startswith("\\"):
        raise ZipSlipError(f"Path traversal attempt detected: absolute path {raw_name!r}")

    # 3. Reject Windows drive letters (e.g. C:\...)
    drive, _ = os.path.splitdrive(raw_name)
    if drive:
        raise ZipSlipError(f"Path traversal attempt detected: drive specification {raw_name!r}")

    norm_dest = os.path.realpath(os.path.abspath(extract_to))
    candidate = os.path.normpath(os.path.join(norm_dest, raw_name))
    real_candidate = os.path.realpath(candidate)

    # 4. Enforce strict commonpath containment
    try:
        common = os.path.commonpath([norm_dest, real_candidate])
    except ValueError as exc:
        raise ZipSlipError(f"Path traversal attempt detected: cross-drive path {raw_name!r}") from exc

    if common != norm_dest:
        raise ZipSlipError(f"Path traversal attempt detected: {raw_name!r} escapes {extract_to!r}")

    # 5. Enforce destination prefix boundaries
    if not (candidate == norm_dest or candidate.startswith(norm_dest + os.sep)):
        raise ZipSlipError(f"Path traversal attempt detected: {raw_name!r}")

    return candidate


def _validate_archive_with_7z(
    z7_path: str,
    archive_path: str,
    extract_to: str,
    password: Optional[str] = None,
) -> None:
    """Pre-validate all member paths in an archive using 7-Zip listing to reject Zip-Slip.

    Raises:
        ZipSlipError / ValueError: If any member attempts directory traversal.
    """
    list_cmd = [z7_path, "l", "-ba", "-slt", f"-p{password or ''}", archive_path]
    list_res = run_hidden(list_cmd, timeout=60)
    if list_res.returncode == 0:
        for line in list_res.stdout.splitlines():
            if line.startswith("Path = "):
                m_path = line[7:].strip()
                if m_path and m_path != os.path.basename(archive_path):
                    _safe_target(extract_to, m_path)


def _validate_archive_with_tar(
    tar_path: str,
    archive_path: str,
    extract_to: str,
) -> None:
    """Pre-validate all member paths in an archive using tar -tf to reject Zip-Slip.

    Raises:
        ZipSlipError / ValueError: If any member attempts directory traversal.
    """
    list_res = run_hidden([tar_path, "-tf", archive_path], timeout=60)
    if list_res.returncode == 0:
        for line in list_res.stdout.splitlines():
            m_path = line.strip()
            if m_path:
                _safe_target(extract_to, m_path)


def _validate_archive_with_unrar(
    unrar_path: str,
    archive_path: str,
    extract_to: str,
    password: Optional[str] = None,
) -> None:
    """Pre-validate all member paths in an archive using unrar lb to reject Zip-Slip.

    Raises:
        ZipSlipError / ValueError: If any member attempts directory traversal.
    """
    cmd = [unrar_path, "lb", f"-p{password}" if password else "-p-", archive_path]
    res = run_hidden(cmd, timeout=60)
    if res.returncode == 0:
        for line in res.stdout.splitlines():
            m_path = line.strip()
            if m_path:
                _safe_target(extract_to, m_path)


def is_multi_volume_archive(archive_path: str) -> bool:
    """Check if archive file matches common multi-volume naming schemes."""
    name = os.path.basename(archive_path).lower()
    return bool(
        re.search(r"\.part\d+\.rar$", name)
        or re.search(r"\.7z\.\d+$", name)
        or re.search(r"\.zip\.\d+$", name)
        or re.search(r"\.r\d{2,}$", name)
        or re.search(r"\.z\d{2,}$", name)
    )


def get_primary_volume_path(archive_path: str) -> str:
    """Resolve primary entry volume (e.g., .part1.rar or .7z.001) given any volume in a set."""
    dirname, filename = os.path.split(archive_path)

    # RAR part scheme: .part2.rar -> .part1.rar or .part01.rar
    m_rar = re.search(r"^(.*?)\.part(\d+)\.rar$", filename, re.IGNORECASE)
    if m_rar:
        base, num_str = m_rar.group(1), m_rar.group(2)
        digits = len(num_str)
        part1_name = f"{base}.part{1:0{digits}d}.rar"
        part1_path = os.path.join(dirname, part1_name)
        if os.path.exists(part1_path):
            return part1_path
        # Fallback to 1-digit part1.rar
        fallback = os.path.join(dirname, f"{base}.part1.rar")
        if os.path.exists(fallback):
            return fallback

    # 7z scheme: .7z.002 -> .7z.001
    m_7z = re.search(r"^(.*?)\.7z\.(\d+)$", filename, re.IGNORECASE)
    if m_7z:
        base, num_str = m_7z.group(1), m_7z.group(2)
        digits = len(num_str)
        v1_name = f"{base}.7z.{1:0{digits}d}"
        v1_path = os.path.join(dirname, v1_name)
        if os.path.exists(v1_path):
            return v1_path

    # Old RAR scheme: .r00 / .r01 -> .rar
    m_old_rar = re.search(r"^(.*?)\.r\d+$", filename, re.IGNORECASE)
    if m_old_rar:
        rar_name = f"{m_old_rar.group(1)}.rar"
        rar_path = os.path.join(dirname, rar_name)
        if os.path.exists(rar_path):
            return rar_path

    return archive_path


def _sniff_archive_kind(archive_path: str) -> str:
    """Sniff magic bytes when a downloaded archive filename has no standard extension."""
    try:
        with open(archive_path, "rb") as f:
            head = f.read(8)
    except OSError:
        return ""
    if head.startswith(b"PK\x03\x04") or head.startswith(b"PK\x05\x06"):
        return "zip"
    if head.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "7z"
    if head.startswith(b"Rar!\x1a\x07"):
        return "rar"
    if head.startswith(b"\x1f\x8b") or head.startswith(b"BZh") or head.startswith(b"\xfd7zXZ\x00"):
        return "tar"
    return ""


def _collect_extracted_files(dest_root: str) -> list[str]:
    """Collect relative paths of all non-directory files extracted inside dest_root."""
    extracted: list[str] = []
    norm_root = os.path.abspath(dest_root)
    for root, _, files in os.walk(norm_root):
        for f in files:
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, norm_root).replace("/", os.sep)
            extracted.append(rel_path)
    return sorted(extracted)


def extract_archive(
    archive_path: str,
    extract_to: str,
    password: Optional[str] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None,
    cancel_event: Optional[threading.Event] = None,
) -> list[str]:
    """Extracts multi-format archives (.zip, .7z, .rar, .tar, .tar.gz) with Zip-Slip defense.

    Args:
        archive_path: Absolute path to the archive file.
        extract_to: Destination directory path.
        password: Optional archive decryption password.
        progress_callback: Optional callback receiving (percent: int, message: str).
        cancel_event: Optional threading.Event to cancel in-transit extraction.

    Returns:
        List of relative file paths extracted into extract_to.

    Raises:
        ZipSlipError / ValueError: If archive contains traversal attacks or unsupported format.
        zipfile.BadZipFile / Exception: On corrupted or truncated archive data.
        RuntimeError: If external extraction tools fail or are missing.
    """
    archive_path = os.path.abspath(archive_path)
    extract_to = os.path.abspath(extract_to)
    os.makedirs(extract_to, exist_ok=True)

    if not os.path.isfile(archive_path):
        raise FileNotFoundError(f"Archive not found: {archive_path}")

    if cancel_event and cancel_event.is_set():
        raise RuntimeError("Extraction cancelled by user")

    # Check for multi-volume archive primary volume
    target_archive = get_primary_volume_path(archive_path)
    name_lower = target_archive.lower()
    sniffed = ""
    if not (
        name_lower.endswith((".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tar.xz", ".7z", ".rar"))
        or re.search(r"\.7z\.\d+$", name_lower)
        or re.search(r"\.part\d+\.rar$", name_lower)
        or re.search(r"\.r\d+$", name_lower)
    ):
        sniffed = _sniff_archive_kind(target_archive)

    logger.info(f"{TAG} Extracting archive: {target_archive} -> {extract_to}")
    if progress_callback:
        progress_callback(10, f"Preparing extraction: {os.path.basename(target_archive)}")

    # 1. ZIP Archives (.zip)
    if name_lower.endswith(".zip") or sniffed == "zip":
        try:
            with zipfile.ZipFile(target_archive, "r") as zf:
                corrupted = zf.testzip()
                if corrupted:
                    raise zipfile.BadZipFile(f"Archive file CRC-32 corruption detected in member: {corrupted}")

                infos = zf.infolist()
                for member in infos:
                    _safe_target(extract_to, member.filename)

                pwd_bytes = password.encode("utf-8") if password else None
                zf.extractall(extract_to, pwd=pwd_bytes)

            files = _collect_extracted_files(extract_to)
            logger.info(f"{TAG} Extracted {len(files)} files from zip: {target_archive}")
            if progress_callback:
                progress_callback(100, f"Extracted {len(files)} files")
            return files
        except (ZipSlipError, ValueError):
            # Path traversal is a security violation: NEVER fall back to external tools
            raise
        except zipfile.BadZipFile:
            raise
        except Exception as exc:
            if cancel_event and cancel_event.is_set():
                raise RuntimeError("Extraction cancelled by user") from exc

            # Fallback to 7z for specialized/split zips if zipfile fails
            z7 = find_7z()
            if z7:
                logger.warning(f"{TAG} zipfile failed ({exc}), attempting fallback to {z7}")
                # Pre-validate 7z listing for Zip-Slip before extraction
                _validate_archive_with_7z(z7, target_archive, extract_to, password=password)

                cmd = [z7, "x", f"-o{extract_to}", f"-p{password or ''}", "-y", target_archive]
                res = run_hidden(cmd, timeout=300)
                if res.returncode == 0:
                    files = _collect_extracted_files(extract_to)
                    if progress_callback:
                        progress_callback(100, f"Extracted {len(files)} files")
                    return files
            raise

    # 2. TAR Archives (.tar, .tar.gz, .tgz, .tar.bz2, .tar.xz)
    elif name_lower.endswith((".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tar.xz")) or sniffed == "tar":
        mode = "r:*"
        with tarfile.open(target_archive, mode) as tf:
            for member in tf.getmembers():
                _safe_target(extract_to, member.name)
            tf.extractall(extract_to)

        files = _collect_extracted_files(extract_to)
        logger.info(f"{TAG} Extracted {len(files)} files from tar: {target_archive}")
        if progress_callback:
            progress_callback(100, f"Extracted {len(files)} files")
        return files

    # 3. 7Z Archives (.7z, .7z.001)
    elif name_lower.endswith(".7z") or re.search(r"\.7z\.\d+$", name_lower) or sniffed == "7z":
        z7 = find_7z()
        if z7:
            # Pre-validate listing for Zip-Slip
            _validate_archive_with_7z(z7, target_archive, extract_to, password=password)

            cmd = [z7, "x", f"-o{extract_to}", f"-p{password or ''}", "-y", target_archive]
            res = run_hidden(cmd, timeout=600)
            if res.returncode != 0:
                err = (res.stderr or "").strip()
                logger.error(f"{TAG} 7z extraction failed ({res.returncode}): {err[:300]}")
                raise RuntimeError(f"7z extraction failed ({res.returncode}): {err[:200]}")

            files = _collect_extracted_files(extract_to)
            if progress_callback:
                progress_callback(100, f"Extracted {len(files)} files")
            return files

        tar = find_tar()
        if tar:
            logger.info(f"{TAG} 7z binary missing, falling back to tar for {target_archive}")
            # Pre-validate tar listing for Zip-Slip before extraction
            _validate_archive_with_tar(tar, target_archive, extract_to)

            cmd = [tar, "-xf", target_archive, "-C", extract_to]
            res = run_hidden(cmd, timeout=600)
            if res.returncode != 0:
                raise RuntimeError(f"tar extraction failed ({res.returncode}): {(res.stderr or '').strip()[:200]}")
            files = _collect_extracted_files(extract_to)
            if progress_callback:
                progress_callback(100, f"Extracted {len(files)} files")
            return files

        raise RuntimeError("No 7z or tar extractor available on system to unpack .7z archive.")

    # 4. RAR Archives (.rar, .part1.rar, .r00)
    elif (
        name_lower.endswith(".rar")
        or re.search(r"\.part\d+\.rar$", name_lower)
        or re.search(r"\.r\d+$", name_lower)
        or sniffed == "rar"
    ):
        last_rar_err = ""
        z7 = find_7z()
        if z7:
            _validate_archive_with_7z(z7, target_archive, extract_to, password=password)
            cmd = [z7, "x", f"-o{extract_to}", f"-p{password or ''}", "-y", target_archive]
            res = run_hidden(cmd, timeout=600)
            if res.returncode == 0:
                files = _collect_extracted_files(extract_to)
                if progress_callback:
                    progress_callback(100, f"Extracted {len(files)} files")
                return files
            last_rar_err = (res.stderr or res.stdout or "").strip()[:200]
            logger.warning(f"{TAG} 7z failed to unpack RAR ({res.returncode}), trying unrar fallback")

        unrar = find_unrar()
        if unrar:
            _validate_archive_with_unrar(unrar, target_archive, extract_to, password=password)
            cmd = [unrar, "x", "-y", "-o+", f"-p{password}" if password else "-p-", target_archive, extract_to + os.sep]
            res = run_hidden(cmd, timeout=600)
            if res.returncode != 0:
                raise RuntimeError(f"unrar extraction failed ({res.returncode}): {(res.stderr or '').strip()[:200]}")
            files = _collect_extracted_files(extract_to)
            if progress_callback:
                progress_callback(100, f"Extracted {len(files)} files")
            return files

        tar = find_tar()
        if tar and not last_rar_err:
            _validate_archive_with_tar(tar, target_archive, extract_to)
            cmd = [tar, "-xf", target_archive, "-C", extract_to]
            res = run_hidden(cmd, timeout=600)
            if res.returncode == 0:
                files = _collect_extracted_files(extract_to)
                if progress_callback:
                    progress_callback(100, f"Extracted {len(files)} files")
                return files

        if last_rar_err:
            raise RuntimeError(f"RAR extraction failed: {last_rar_err}")
        raise RuntimeError("Neither 7z nor unrar found on system to extract RAR archive.")

    # 5. Raw single-file localization packages (.pak, .archive, .rpf, .w3strings)
    elif name_lower.endswith((".pak", ".archive", ".rpf", ".w3strings")):
        dest_file = _safe_target(extract_to, os.path.basename(target_archive))
        shutil.copy2(target_archive, dest_file)
        files = _collect_extracted_files(extract_to)
        logger.info(f"{TAG} Staged raw localization file: {os.path.basename(dest_file)}")
        if progress_callback:
            progress_callback(100, f"Extracted {len(files)} files")
        return files

    else:
        logger.error(f"{TAG} Unsupported archive format: {archive_path}")
        raise ValueError(f"Unsupported archive format: {archive_path}")
