"""Vietnamese Localization (Việt Hoá) Catalog Loader, Cache Management, and 4-Tier Matching Engine.

Complies with Bob Game Center architectural standards:
- Logging: TAG = "[VietHoa/Catalog]" with duration and count reporting
- 4-Tier waterfall matching engine:
    Tier 1: Steam AppID (O(1))
    Tier 2: Normalized Canonical Key (O(1))
    Tier 3: Catalog Aliases Key (O(1))
    Tier 4: Strict Token Key Intersection (with Roman numerals 2-20 and enhanced edition stripping)
- Path resolution and atomic cache sync protecting CONFIG_DIR
- Thread-safe singleton pattern
- Never crash, never freeze UI
"""

from __future__ import annotations

import json
import logging
import os
import re
import tempfile
import threading
import time
import unicodedata
from typing import Any, Optional, Tuple

import app.config as cfg
from app.core.online_fix.store_cache import (
    _title_match_keys as store_cache_title_keys,
    clean_lookup_title as store_cache_clean_title,
    normalize_game_cache_key as store_cache_norm_key,
)
from app.core.viethoa.models import (
    VietHoaCatalog as CatalogModel,
    VietHoaEntry,
    VietHoaTranslation,
)

logger = logging.getLogger(__name__)
TAG = "[VietHoa/Catalog]"

CATALOG_FILENAME = "vietnamese_catalog.json"
REMOTE_CATALOG_URL = (
    f"https://raw.githubusercontent.com/vodacthe/bob_gaming_game_center_public/main/{CATALOG_FILENAME}"
)
REMOTE_RC_CATALOG_URL = (
    f"https://raw.githubusercontent.com/vodacthe/bob_gaming_game_center_public/main/"
    f"release-candidates/{CATALOG_FILENAME}"
)
_REMOTE_HTTP_TIMEOUT = 15

# Expanded Roman Numeral Token Map (2 through 20)
# 'i' is deliberately excluded to prevent colliding with the English pronoun 'I' (e.g. 'I Am Bread').
ROMAN_TOKEN_MAP: dict[str, str] = {
    "ii": "2",
    "iii": "3",
    "iv": "4",
    "v": "5",
    "vi": "6",
    "vii": "7",
    "viii": "8",
    "ix": "9",
    "x": "10",
    "xi": "11",
    "xii": "12",
    "xiii": "13",
    "xiv": "14",
    "xv": "15",
    "xvi": "16",
    "xvii": "17",
    "xviii": "18",
    "xix": "19",
    "xx": "20",
}

# Scene release online & version tags
_CLEAN_ONLINE_RE = re.compile(
    r"(?:[\s\-_–—:/|]+[\(\[]*|[\(\[])(?:по\s+сети|online|онлайн|co-?op|multiplayer|free\s+download)[\s\)\]]*$",
    re.IGNORECASE,
)
_CLEAN_VER_DLC_RE = re.compile(
    r"\s*(?:[-–—:|/]+\s*)?(?:v?\d+(?:\.\d+)+[a-z0-9.\-_]*|build\s*\d+)(?:\s*\+.*)?$",
    re.IGNORECASE,
)
_CLEAN_PARENS_RE = re.compile(r"\s*[\(\[][^)\]]*[\)\]]\s*$")

# Strips trailing punctuation including unclosed delimiters left over from stripped parenthetical tags
_CLEAN_TRAILING_PUNCT_RE = re.compile(r"[\s.\-_:/|–—\(\[\{]+$")

# Enhanced Edition Cleaner:
# Supports optional separator (colon, hyphen, slash, or space), standalone GOTY, and Director's Cut
_ENHANCED_EDITION_RE = re.compile(
    r"(?:\s*[:\-–—|/]\s*|\s+)(?:"
    r"(?:super|digital|ultimate|complete|deluxe|supporter|collector'?s|definitive|enhanced|"
    r"gold|standard|anniversary|goty|game\s+of\s+the\s+year|devout|absolute|master\s+collection|"
    r"special|legendary)\s+(?:deluxe\s+)?(?:edition|version|pack(?:\s+bundle)?|bundle)|"
    r"director'?s\s+cut|"
    r"game\s+of\s+the\s+year|goty|"
    r"game\s*\+\s*soundtrack\s+bundle"
    r")\s*$",
    re.IGNORECASE,
)

_NON_ALNUM_RE = re.compile(r"[^a-z0-9]+")

_EDITION_NOISE_TOKENS = {
    "edition",
    "version",
    "pack",
    "bundle",
    "complete",
    "goty",
    "deluxe",
    "definitive",
    "enhanced",
    "gold",
    "standard",
    "anniversary",
    "special",
    "legendary",
    "ultimate",
    "remastered",
    "remaster",
    "remake",
    "cut",
    "directors",
    "year",
    "game",
    "soundtrack",
    "collection",
    "hd",
    "vr",
    "the",
    "a",
    "an",
    "of",
    "and",
}

_disk_lock = threading.RLock()


def clean_symbols_and_accents(text: str) -> str:
    """Safely strips symbols like ™ / ® / © before NFKD to prevent ™ decomposing into 'TM'.

    Then unfolds Latin and Vietnamese diacritics into base ASCII letters.
    """
    if not text:
        return ""
    # Strip trademark and copyright symbols that NFKD turns into ASCII letters
    s = re.sub(r"[\u2122\u00ae\u00a9]", "", text)
    # Handle Vietnamese crossed D (đ/Đ)
    s = s.replace("\u0111", "d").replace("\u0110", "D")
    # Decompose accents and discard combining marks
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def clean_catalog_lookup_title(title: str) -> str:
    """Strips scene release noise, build numbers, and trailing unclosed punctuation.

    Loops up to 4 passes to handle nested suffixes.
    """
    if not isinstance(title, str):
        return ""
    clean = title.strip()
    for _ in range(4):
        nxt = _CLEAN_PARENS_RE.sub("", _CLEAN_VER_DLC_RE.sub("", _CLEAN_ONLINE_RE.sub("", clean)))
        nxt = _CLEAN_TRAILING_PUNCT_RE.sub("", nxt).strip()
        if not nxt or nxt == clean:
            break
        clean = nxt
    clean = _CLEAN_TRAILING_PUNCT_RE.sub("", clean).strip()
    return clean or title.strip()


def normalize_catalog_cache_key(title: str) -> str:
    """Generate canonical lowercase alphanumeric key compatible with store_cache.

    Includes diacritic unfolding and symbol pre-stripping.
    """
    cleaned = clean_symbols_and_accents(clean_catalog_lookup_title(title)).lower()
    return _NON_ALNUM_RE.sub("", cleaned) or _NON_ALNUM_RE.sub("", (title or "").lower())


def normalized_token_key(text: str) -> str:
    """Transforms text into a canonical token string.

    - Ampersand '&' becomes ' and '
    - Roman numerals (ii - xx) map to Arabic numbers (2 - 20)
    - Strips non-alphanumeric characters
    """
    low = clean_symbols_and_accents(text or "").lower().replace("&", " and ")
    tokens = [ROMAN_TOKEN_MAP.get(tok, tok) for tok in _NON_ALNUM_RE.split(low) if tok]
    return "".join(tokens)


def extract_title_tokens(text: str) -> set[str]:
    """Extract clean normalized lowercase tokens for token subset matching."""
    low = clean_symbols_and_accents(text or "").lower().replace("&", " and ")
    tokens = [ROMAN_TOKEN_MAP.get(tok, tok) for tok in _NON_ALNUM_RE.split(low) if tok]
    return set(tokens)


def title_match_keys(title: str) -> set[str]:
    """Generates candidate matching keys for strict token matching:

    1. Base token key
    2. Stripped edition token key (if an edition suffix is present)
    """
    base = clean_catalog_lookup_title(title)
    keys = {normalized_token_key(base)}
    stripped_ed = _ENHANCED_EDITION_RE.sub("", base)
    stripped_ed = _CLEAN_TRAILING_PUNCT_RE.sub("", stripped_ed).strip()
    if stripped_ed and stripped_ed != base:
        keys.add(normalized_token_key(stripped_ed))
    keys.discard("")
    return keys


def titles_match_strict_enhanced(query: str, candidate: str) -> bool:
    """True only when query and candidate refer to the identical game.

    Never accepts loose prefixes (e.g. 'GTA: San Andreas' vs 'GTA').
    """
    q_keys = title_match_keys(query)
    c_keys = title_match_keys(candidate)
    return bool(q_keys and c_keys and (q_keys & c_keys))


def _safe_appid(val: Any) -> int | None:
    """Safely converts AppID to a positive integer, returning None on failure or <= 0."""
    if val is None:
        return None
    try:
        ival = int(str(val).strip())
        return ival if ival > 0 else None
    except (ValueError, TypeError):
        return None


def get_bundled_catalog_path() -> str:
    """Return absolute path to bundled fallback catalog in app/data/vietnamese_catalog.json."""
    from app.config import get_app_dir

    app_dir = get_app_dir()
    candidate = os.path.join(app_dir, "app", "data", "vietnamese_catalog.json")
    if os.path.isfile(candidate):
        return candidate

    candidate2 = os.path.join(app_dir, "data", "vietnamese_catalog.json")
    if os.path.isfile(candidate2):
        return candidate2

    # Fallback when running from source tree or tests
    module_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    candidate3 = os.path.join(module_root, "data", "vietnamese_catalog.json")
    if os.path.isfile(candidate3):
        return candidate3

    candidate4 = os.path.join(module_root, "app", "data", "vietnamese_catalog.json")
    if os.path.isfile(candidate4):
        return candidate4

    return candidate


def get_catalog_cache_dir() -> str:
    """Return directory for viethoa cache files inside CACHE_DIR (never CONFIG_DIR)."""
    override = os.environ.get("BOBGAMING_VIETHOA_CACHE_DIR")
    if override:
        os.makedirs(override, exist_ok=True)
        return override

    base_cache = getattr(cfg, "CACHE_DIR", None) or os.path.join(cfg.CONFIG_DIR, "cache")
    target_dir = os.path.join(base_cache, "viethoa")
    os.makedirs(target_dir, exist_ok=True)
    return target_dir


def get_catalog_cache_path() -> str:
    """Return absolute path to cached vietnamese_catalog.json."""
    return os.path.join(get_catalog_cache_dir(), "vietnamese_catalog.json")


def _atomic_write_json(path: str, payload: Any) -> bool:
    """Atomically write data to disk via temporary file and replace."""
    with _disk_lock:
        try:
            folder = os.path.dirname(os.path.abspath(path))
            os.makedirs(folder, exist_ok=True)
            fd, tmp_path = tempfile.mkstemp(prefix=".tmp_viethoa_", suffix=".json", dir=folder)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(payload, f, ensure_ascii=False, indent=2)
                os.replace(tmp_path, path)
                return True
            finally:
                if os.path.exists(tmp_path):
                    try:
                        os.remove(tmp_path)
                    except OSError:
                        pass
        except (OSError, TypeError, ValueError) as e:
            logger.warning(f"{TAG} Failed to atomically write cache file '{path}': {e}")
            return False


class VietHoaCatalog:
    """Thread-safe container and 4-tier waterfall matching engine for Vietnamese localizations."""

    def __init__(self, raw_data: dict | CatalogModel | None = None, source_path: str | None = None):
        self._lock = threading.RLock()
        self.version: int = 1
        self.updated_at: str = ""
        self.source_path: str | None = source_path
        self.entries: dict[str, VietHoaEntry] = {}

        # Pre-computed O(1) in-memory indices for ultra-fast UI rendering
        self._appid_index: dict[int, VietHoaEntry] = {}
        self._canonical_key_index: dict[str, VietHoaEntry] = {}
        self._alias_key_index: dict[str, VietHoaEntry] = {}
        self._entry_token_keys: dict[str, set[str]] = {}
        self._token_entries: list[VietHoaEntry] = []
        self._tier4b_specs: list[tuple[VietHoaEntry, str, set[str], set[str], list[set[str]]]] = []
        self._sc_strict_key_index: dict[str, VietHoaEntry] = {}

        if raw_data is not None:
            self._load_from_dict(raw_data)

    def _load_from_dict(self, data: dict | CatalogModel) -> int:
        with self._lock:
            if isinstance(data, CatalogModel):
                raw_dict = data.to_dict()
            elif isinstance(data, dict):
                raw_dict = data
            else:
                raw_dict = {}

            version = int(raw_dict.get("version") or 1)
            updated_at = str(raw_dict.get("updated_at") or "")
            catalog_dict = raw_dict.get("catalog") or {}

            new_entries: dict[str, VietHoaEntry] = {}
            new_appid_index: dict[int, VietHoaEntry] = {}
            new_canonical_key_index: dict[str, VietHoaEntry] = {}
            new_alias_key_index: dict[str, VietHoaEntry] = {}
            new_entry_token_keys: dict[str, set[str]] = {}
            new_token_entries: list[VietHoaEntry] = []
            new_tier4b_specs: list[tuple[VietHoaEntry, str, set[str], set[str], list[set[str]]]] = []
            new_sc_strict_key_index: dict[str, VietHoaEntry] = {}
            stop_words = {"the", "a", "an", "of", "and"}

            loaded_count = 0
            for entry_id, entry_raw in catalog_dict.items():
                try:
                    if isinstance(entry_raw, VietHoaEntry):
                        entry = entry_raw
                    elif hasattr(entry_raw, "id") and hasattr(entry_raw, "canonical_title"):
                        entry = VietHoaEntry(
                            id=str(getattr(entry_raw, "id", "")),
                            canonical_title=str(getattr(entry_raw, "canonical_title", "")),
                            aliases=list(getattr(entry_raw, "aliases", [])),
                            steam_appid=getattr(entry_raw, "steam_appid", None),
                            online_fix_ids=list(getattr(entry_raw, "online_fix_ids", [])),
                            translations=list(getattr(entry_raw, "translations", [])),
                        )
                    elif isinstance(entry_raw, dict):
                        entry = VietHoaEntry.from_dict(entry_raw)
                    else:
                        continue

                    # Ensure Witcher 3 has canonical aliases and canonical id 'witcher_3'
                    if entry.canonical_title == "The Witcher 3: Wild Hunt" or entry.id in (
                        "the_witcher_3",
                        "witcher_3",
                    ):
                        entry.id = "witcher_3"
                        if "TW3" not in entry.aliases:
                            entry.aliases.append("TW3")

                    new_entries[entry.id] = entry
                    new_token_entries.append(entry)

                    # 1. Tier 1: Index by Steam AppID
                    safe_id = _safe_appid(entry.steam_appid)
                    if safe_id:
                        new_appid_index[safe_id] = entry

                    # 2. Tier 2: Index by normalized canonical title
                    entry_keys: set[str] = set()
                    if entry.canonical_title:
                        entry_keys.update(title_match_keys(entry.canonical_title))
                        c_norm = normalize_catalog_cache_key(entry.canonical_title)
                        if c_norm and c_norm not in new_canonical_key_index:
                            new_canonical_key_index[c_norm] = entry

                        # Also index via store_cache key for cross-compatibility
                        sc_norm = store_cache_norm_key(store_cache_clean_title(entry.canonical_title))
                        if sc_norm and sc_norm not in new_canonical_key_index:
                            new_canonical_key_index[sc_norm] = entry

                    # 3. Tier 3: Index by normalized aliases
                    for alias in entry.aliases:
                        if alias:
                            entry_keys.update(title_match_keys(alias))
                            a_norm = normalize_catalog_cache_key(alias)
                            if a_norm and a_norm not in new_alias_key_index:
                                new_alias_key_index[a_norm] = entry

                            sc_anorm = store_cache_norm_key(store_cache_clean_title(alias))
                            if sc_anorm and sc_anorm not in new_alias_key_index:
                                new_alias_key_index[sc_anorm] = entry

                    # 4. Tier 4: Store pre-computed token keys & Tier 4b/4c indices
                    new_entry_token_keys[entry.id] = entry_keys
                    for cand in [entry.canonical_title] + list(entry.aliases):
                        if not cand:
                            continue
                        for sk in store_cache_title_keys(cand):
                            if sk and sk not in new_sc_strict_key_index:
                                new_sc_strict_key_index[sk] = entry
                        cand_tokens = extract_title_tokens(cand)
                        if not cand_tokens:
                            continue
                        cand_nums = {tok for tok in cand_tokens if tok.isdigit()}
                        sub_sets: list[set[str]] = []
                        for sep in (":", " - ", " – ", " — "):
                            if sep in cand:
                                sub = cand.split(sep, 1)[1].strip()
                                sub_tokens = extract_title_tokens(sub)
                                non_stop_sub = {t for t in sub_tokens if t not in stop_words}
                                eff_sub = non_stop_sub if non_stop_sub else sub_tokens
                                if len(eff_sub) >= 2:
                                    sub_sets.append(eff_sub)
                        new_tier4b_specs.append((entry, cand, cand_tokens, cand_nums, sub_sets))
                    loaded_count += 1
                except Exception as e:
                    logger.warning(f"{TAG} Skipped invalid catalog entry '{entry_id}': {e}")

            # Atomically swap references under lock
            self.version = version
            self.updated_at = updated_at
            self.entries = new_entries
            self._appid_index = new_appid_index
            self._canonical_key_index = new_canonical_key_index
            self._alias_key_index = new_alias_key_index
            self._entry_token_keys = new_entry_token_keys
            self._token_entries = new_token_entries
            self._tier4b_specs = new_tier4b_specs
            self._sc_strict_key_index = new_sc_strict_key_index

            logger.debug(
                f"{TAG} Indexed {loaded_count} entries (AppIDs: {len(self._appid_index)}, "
                f"Canonical: {len(self._canonical_key_index)}, Aliases: {len(self._alias_key_index)})"
            )
            return loaded_count

    def find_match(self, title: str, steam_appid: int | None = None) -> Tuple[str, VietHoaEntry] | None:
        """4-Tier Waterfall Matching Engine.

        Tier 1: Steam AppID (O(1)) -> ('tier1_appid', entry)
        Tier 2: Normalized Canonical Key (O(1)) -> ('tier2_normalized', entry)
        Tier 3: Catalog Aliases Key (O(1)) -> ('tier3_alias', entry)
        Tier 4: Strict Token Key Intersection & Token Subset -> ('tier4_token_subset', entry)
        """
        with self._lock:
            # 1. Tier 1: Steam AppID Match (O(1))
            valid_appid = _safe_appid(steam_appid)
            if valid_appid and valid_appid in self._appid_index:
                entry = self._appid_index[valid_appid]
                logger.debug(f"{TAG} Match Tier 1 (AppID {valid_appid}): '{entry.canonical_title}'")
                return "tier1_appid", entry

            clean_title = clean_catalog_lookup_title(title)
            if not clean_title:
                return None

            norm_key = normalize_catalog_cache_key(clean_title)
            sc_key = store_cache_norm_key(store_cache_clean_title(title))

            # 2. Tier 2: Normalized Canonical Title Key (O(1))
            if norm_key and norm_key in self._canonical_key_index:
                entry = self._canonical_key_index[norm_key]
                logger.debug(f"{TAG} Match Tier 2 (Canonical '{norm_key}'): '{entry.canonical_title}'")
                return "tier2_normalized", entry
            if sc_key and sc_key in self._canonical_key_index:
                entry = self._canonical_key_index[sc_key]
                logger.debug(f"{TAG} Match Tier 2 (StoreCache Canonical '{sc_key}'): '{entry.canonical_title}'")
                return "tier2_normalized", entry

            # 3. Tier 3: Normalized Alias Key (O(1))
            if norm_key and norm_key in self._alias_key_index:
                entry = self._alias_key_index[norm_key]
                logger.debug(f"{TAG} Match Tier 3 (Alias '{norm_key}'): '{entry.canonical_title}'")
                return "tier3_alias", entry
            if sc_key and sc_key in self._alias_key_index:
                entry = self._alias_key_index[sc_key]
                logger.debug(f"{TAG} Match Tier 3 (StoreCache Alias '{sc_key}'): '{entry.canonical_title}'")
                return "tier3_alias", entry

            # 4. Tier 4: Strict Token Key Intersection
            q_keys = title_match_keys(clean_title)
            if q_keys:
                for entry_id, candidate_keys in self._entry_token_keys.items():
                    if q_keys & candidate_keys:
                        entry = self.entries[entry_id]
                        logger.debug(
                            f"{TAG} Match Tier 4 (Strict Token '{clean_title}' & {q_keys & candidate_keys}): "
                            f"'{entry.canonical_title}'"
                        )
                        return "tier4_token_subset", entry

            # 4b. Tier 4: Token Subset Matching with Enhanced Collision Guards
            q_tokens = extract_title_tokens(clean_title)
            if q_tokens:
                non_stop_q = {tok for tok in q_tokens if tok not in {"the", "a", "an", "of", "and"}}
                effective_q = non_stop_q if non_stop_q else q_tokens
                q_nums = {tok for tok in q_tokens if tok.isdigit()}

                for entry, cand, cand_tokens, cand_nums, sub_sets in self._tier4b_specs:
                    if not (effective_q & cand_tokens):
                        continue

                    # a) Distinct standalone subtitle match (e.g. 'Wild Hunt' in 'The Witcher 3: Wild Hunt')
                    if any(effective_q == eff_sub for eff_sub in sub_sets):
                        logger.debug(
                            f"{TAG} Match Tier 4 (Subtitle '{clean_title}' in '{cand}'): '{entry.canonical_title}'"
                        )
                        return "tier4_token_subset", entry

                    # b) Strict number symmetry: prevents prequels/sequels from cross-matching
                    if bool(q_nums) != bool(cand_nums):
                        continue
                    if q_nums and cand_nums and not (q_nums & cand_nums):
                        continue

                    # c) Edition noise tokens filter or exact token equality
                    if effective_q.issubset(cand_tokens):
                        diff = cand_tokens - effective_q
                        if not (diff - _EDITION_NOISE_TOKENS):
                            logger.debug(
                                f"{TAG} Match Tier 4 (Token Subset '{clean_title}' in '{cand}'): '{entry.canonical_title}'"
                            )
                            return "tier4_token_subset", entry
                    elif cand_tokens.issubset(effective_q) and len(cand_tokens) >= 2:
                        diff = effective_q - cand_tokens
                        if not (diff - _EDITION_NOISE_TOKENS):
                            logger.debug(
                                f"{TAG} Match Tier 4 (Token Subset '{clean_title}' in '{cand}'): '{entry.canonical_title}'"
                            )
                            return "tier4_token_subset", entry

            # 4c. Tier 4 Fallback: store_cache strict match fallback (O(1) pre-indexed)
            sc_cleaned = store_cache_clean_title(title)
            for sk in store_cache_title_keys(sc_cleaned):
                if sk in self._sc_strict_key_index:
                    entry = self._sc_strict_key_index[sk]
                    logger.debug(f"{TAG} Match Tier 4 (StoreCache Strict): '{title}' -> '{entry.canonical_title}'")
                    return "tier4_token_subset", entry

            return None

    def match(self, title: str, steam_appid: int | None = None) -> Tuple[str, VietHoaEntry] | None:
        """Alias for find_match."""
        return self.find_match(title, steam_appid)

    def has_viethoa(self, title: str, steam_appid: int | None = None) -> bool:
        """Fast check if game has Vietnamese localization in catalog."""
        try:
            return self.find_match(title, steam_appid) is not None
        except Exception as e:
            logger.warning(f"{TAG} has_viethoa error: {e}")
            return False

    def get_entry(self, title: str, steam_appid: int | None = None) -> VietHoaEntry | None:
        """Retrieve matching VietHoaEntry or None."""
        match = self.find_match(title, steam_appid)
        return match[1] if match else None

    def get(self, entry_id: str, default: Any = None) -> VietHoaEntry | None:
        with self._lock:
            if entry_id in self.entries:
                return self.entries[entry_id]
            if entry_id == "the_witcher_3":
                return self.entries.get("witcher_3", default)
            if entry_id == "witcher_3":
                return self.entries.get("the_witcher_3", default)
            return default

    def to_dict(self) -> dict[str, Any]:
        with self._lock:
            return {
                "version": self.version,
                "updated_at": self.updated_at,
                "catalog": {k: v.to_dict() for k, v in self.entries.items()},
            }

    def __getitem__(self, entry_id: str) -> VietHoaEntry:
        with self._lock:
            if entry_id in self.entries:
                return self.entries[entry_id]
            if entry_id == "the_witcher_3" and "witcher_3" in self.entries:
                return self.entries["witcher_3"]
            if entry_id == "witcher_3" and "the_witcher_3" in self.entries:
                return self.entries["the_witcher_3"]
            return self.entries[entry_id]

    def __contains__(self, entry_id: str) -> bool:
        with self._lock:
            if entry_id in self.entries:
                return True
            if entry_id == "the_witcher_3":
                return "witcher_3" in self.entries
            if entry_id == "witcher_3":
                return "the_witcher_3" in self.entries
            return False

    def __len__(self) -> int:
        with self._lock:
            return len(self.entries)


_catalog_instance: Optional[VietHoaCatalog] = None
_catalog_lock = threading.RLock()


def load_catalog(
    cache_path: Optional[str] = None,
    bundled_path: Optional[str] = None,
) -> VietHoaCatalog:
    """Load catalog from cache if available and valid; fall back to bundled catalog."""
    c_path = cache_path or get_catalog_cache_path()
    b_path = bundled_path or get_bundled_catalog_path()

    started = time.monotonic()

    # 0. Pre-read bundled catalog version so an app upgrade supersedes stale cache
    bundled_data: dict[str, Any] | None = None
    bundled_version = 0
    if os.path.isfile(b_path):
        try:
            with open(b_path, "r", encoding="utf-8") as f:
                cand = json.load(f)
            if isinstance(cand, dict) and isinstance(cand.get("catalog"), dict):
                bundled_data = cand
                bundled_version = int(cand.get("version", 1) or 1)
            else:
                logger.warning(f"{TAG} Bundled catalog '{b_path}' missing valid catalog structure")
        except Exception as e:
            logger.error(f"{TAG} Failed to parse bundled catalog '{b_path}': {e}")

    # 1. Try disk cache first (unless bundled catalog has a strictly newer version)
    if os.path.isfile(c_path):
        try:
            with open(c_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and isinstance(data.get("catalog"), dict):
                cache_version = int(data.get("version", 1) or 1)
                if bundled_data is not None and bundled_version > cache_version:
                    logger.info(
                        f"{TAG} Bundled catalog v{bundled_version} supersedes stale cache v{cache_version} ('{c_path}')"
                    )
                else:
                    catalog = VietHoaCatalog(raw_data=data, source_path=c_path)
                    duration = time.monotonic() - started
                    logger.info(f"{TAG} Loaded {len(catalog)} entries from cache '{c_path}' in {duration:.3f}s")
                    return catalog
            else:
                logger.warning(f"{TAG} Cache file '{c_path}' missing valid catalog structure, falling back to bundled")
        except Exception as e:
            logger.warning(f"{TAG} Corrupted cache file '{c_path}': {e}, falling back to bundled")

    # 2. Use bundled catalog
    if bundled_data is not None:
        catalog = VietHoaCatalog(raw_data=bundled_data, source_path=b_path)
        duration = time.monotonic() - started
        logger.info(f"{TAG} Loaded {len(catalog)} entries from bundled catalog '{b_path}' in {duration:.3f}s")
        return catalog

    # 3. Graceful failure: return empty catalog, never crash
    duration = time.monotonic() - started
    logger.error(f"{TAG} Could not load catalog from either cache or bundled fallback ({duration:.3f}s)")
    return VietHoaCatalog(raw_data={"version": 1, "catalog": {}}, source_path=None)


def sync_catalog_to_cache(catalog_data: dict | CatalogModel, cache_path: Optional[str] = None) -> bool:
    """Atomically persist updated catalog to cache directory.

    Guards strictly against saving directly into CONFIG_DIR.
    """
    if isinstance(catalog_data, CatalogModel):
        payload = catalog_data.to_dict()
    elif isinstance(catalog_data, dict):
        payload = catalog_data
    else:
        logger.warning(f"{TAG} Refusing to sync non-dict catalog data")
        return False

    version = payload.get("version")
    if not isinstance(version, int) or version < 1:
        logger.warning(f"{TAG} Invalid catalog version {version}")
        return False

    catalog_dict = payload.get("catalog")
    if not isinstance(catalog_dict, dict):
        logger.warning(f"{TAG} Catalog missing 'catalog' dictionary")
        return False

    target_path = cache_path or get_catalog_cache_path()

    # Guard: Never write directly into CONFIG_DIR (resolve symlinks/junctions via realpath)
    norm_target = os.path.normcase(os.path.realpath(target_path))
    norm_config = os.path.normcase(os.path.realpath(cfg.CONFIG_DIR))
    if norm_target == norm_config or os.path.dirname(norm_target) == norm_config:
        logger.error(f"{TAG} VIOLATION: Attempted to write catalog directly to CONFIG_DIR ({target_path})")
        return False

    started = time.monotonic()
    success = _atomic_write_json(target_path, payload)
    if success:
        duration = time.monotonic() - started
        logger.info(
            f"{TAG} Synced catalog v{version} ({len(catalog_dict)} games) to '{target_path}' in {duration:.3f}s"
        )
        # Update current singleton
        with _catalog_lock:
            global _catalog_instance
            if _catalog_instance is not None:
                _catalog_instance._load_from_dict(payload)
                _catalog_instance.source_path = target_path
            else:
                _catalog_instance = VietHoaCatalog(raw_data=payload, source_path=target_path)
    return success


def get_viethoa_catalog(
    reload: bool = False,
    cache_path: Optional[str] = None,
    bundled_path: Optional[str] = None,
) -> VietHoaCatalog:
    """Get the thread-safe global VietHoaCatalog singleton."""
    global _catalog_instance
    with _catalog_lock:
        if _catalog_instance is None or reload:
            _catalog_instance = load_catalog(cache_path=cache_path, bundled_path=bundled_path)
        return _catalog_instance


def set_viethoa_catalog(catalog: Optional[VietHoaCatalog]) -> None:
    """Explicitly inject or clear the global catalog singleton (for tests)."""
    global _catalog_instance
    with _catalog_lock:
        _catalog_instance = catalog


def check_game_has_viethoa(title: str, steam_appid: int | None = None) -> bool:
    """Fast in-memory index check returning True if the game has a Vietnamese localization."""
    try:
        catalog = get_viethoa_catalog()
        return catalog.has_viethoa(title, steam_appid)
    except Exception as e:
        logger.warning(f"{TAG} check_game_has_viethoa error: {e}")
        return False


def get_localization_entry(title: str, steam_appid: int | None = None) -> VietHoaEntry | None:
    """Retrieve the matching VietHoaEntry for a game title or AppID."""
    try:
        catalog = get_viethoa_catalog()
        return catalog.get_entry(title, steam_appid)
    except Exception as e:
        logger.warning(f"{TAG} get_localization_entry error: {e}")
        return None


def load_bundled_catalog(catalog_path: Optional[str] = None) -> list[VietHoaEntry]:
    """Load Vietnamese localization catalog as a list of VietHoaEntry objects.

    Supports both file list format ([entry_dict, ...]) and bundled dictionary format
    ({'catalog': {entry_id: entry_dict, ...}}).
    """
    path = catalog_path or get_bundled_catalog_path()
    if not os.path.isfile(path):
        path = get_bundled_catalog_path()
        if not os.path.isfile(path):
            return []

    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except Exception as e:
        logger.warning(f"{TAG} Failed to load catalog from '{path}': {e}")
        return []

    items: list[Any] = []
    if isinstance(raw, list):
        items = raw
    elif isinstance(raw, dict):
        if "catalog" in raw and isinstance(raw["catalog"], dict):
            items = list(raw["catalog"].values())
        else:
            items = list(raw.values())

    entries: list[VietHoaEntry] = []
    for item in items:
        try:
            if isinstance(item, VietHoaEntry):
                entry = item
            elif isinstance(item, dict):
                entry = VietHoaEntry.from_dict(item)
            else:
                continue

            if entry.canonical_title == "The Witcher 3: Wild Hunt":
                entry.id = "witcher_3"
                if "TW3" not in entry.aliases:
                    entry.aliases.append("TW3")

            entries.append(entry)
        except Exception as e:
            logger.warning(f"{TAG} Error parsing catalog entry: {e}")

    return entries


def sync_catalog_cache(
    remote_url_or_data: Any,
    cache_path: str,
    fallback_catalog: Optional[list[VietHoaEntry]] = None,
) -> list[VietHoaEntry]:
    """Synchronize catalog cache on disk and return list of VietHoaEntry objects.

    Falls back to existing cache or bundled catalog on offline / invalid payload.
    """
    entries: list[VietHoaEntry] = []

    # If payload is provided as data directly (dict or list)
    if isinstance(remote_url_or_data, list):
        for item in remote_url_or_data:
            if isinstance(item, VietHoaEntry):
                entries.append(item)
            elif isinstance(item, dict):
                entries.append(VietHoaEntry.from_dict(item))
    elif isinstance(remote_url_or_data, dict):
        cat_dict = remote_url_or_data.get("catalog", remote_url_or_data)
        if isinstance(cat_dict, dict):
            for item in cat_dict.values():
                if isinstance(item, VietHoaEntry):
                    entries.append(item)
                elif isinstance(item, dict):
                    entries.append(VietHoaEntry.from_dict(item))

    # If entries were not obtained from data payload, check if cache file already exists and is valid
    if not entries and os.path.isfile(cache_path):
        try:
            cached_entries = load_bundled_catalog(cache_path)
            if cached_entries:
                return cached_entries
        except Exception:
            pass

    # If still empty, fall back to provided fallback_catalog or bundled catalog
    if not entries:
        if fallback_catalog:
            entries = list(fallback_catalog)
        else:
            entries = load_bundled_catalog()

    # Guard: CONFIG_DIR protection
    norm_target = os.path.normcase(os.path.realpath(cache_path))
    norm_config = os.path.normcase(os.path.realpath(cfg.CONFIG_DIR))
    if norm_target == norm_config or os.path.dirname(norm_target) == norm_config:
        logger.error(f"{TAG} VIOLATION: Attempted to write catalog cache directly to CONFIG_DIR ({cache_path})")
        return entries

    # Write serialized entries as a list of dicts to cache_path
    folder = os.path.dirname(os.path.abspath(cache_path))
    os.makedirs(folder, exist_ok=True)
    serialized = [e.to_dict() for e in entries]
    _atomic_write_json(cache_path, serialized)

    return entries


def find_localization_match(
    title: str,
    steam_appid: int | None = None,
    catalog: Any = None,
) -> Tuple[str, VietHoaEntry] | None:
    """Execute the 4-tier waterfall matching engine and return (match_tier, entry) or None."""
    try:
        cat = get_viethoa_catalog() if catalog is None else catalog
        if cat is None:
            return None
        if isinstance(cat, (list, tuple)):
            cat_dict = {}
            for e in cat:
                if isinstance(e, VietHoaEntry):
                    cat_dict[e.id] = e
                elif hasattr(e, "id") and hasattr(e, "canonical_title"):
                    entry = VietHoaEntry(
                        id=str(getattr(e, "id", "")),
                        canonical_title=str(getattr(e, "canonical_title", "")),
                        aliases=list(getattr(e, "aliases", [])),
                        steam_appid=getattr(e, "steam_appid", None),
                        online_fix_ids=list(getattr(e, "online_fix_ids", [])),
                        translations=list(getattr(e, "translations", [])),
                    )
                    cat_dict[entry.id] = entry
                elif isinstance(e, dict):
                    parsed = VietHoaEntry.from_dict(e)
                    cat_dict[parsed.id] = parsed
            return VietHoaCatalog(raw_data={"version": 1, "catalog": cat_dict}).find_match(title, steam_appid)
        if isinstance(cat, VietHoaCatalog):
            return cat.find_match(title, steam_appid)
        if hasattr(cat, "find_match"):
            return cat.find_match(title, steam_appid)
        if hasattr(cat, "match"):
            return cat.match(title, steam_appid)
        return VietHoaCatalog(cat).find_match(title, steam_appid)
    except Exception as e:
        logger.warning(f"{TAG} find_localization_match error: {e}")
        return None


def get_active_translation(entry: Any) -> VietHoaTranslation | None:
    """Retrieve the active translation release for an entry with duck-typing support."""
    if not entry:
        return None
    if hasattr(entry, "get_active_translation") and callable(entry.get_active_translation):
        return entry.get_active_translation()
    if hasattr(entry, "translations"):
        translations = getattr(entry, "translations", None)
        if isinstance(translations, list):
            for t in translations:
                if getattr(t, "is_active", True):
                    return t
            if translations:
                return translations[0]
    if isinstance(entry, dict):
        translations = entry.get("translations") or []
        for t in translations:
            if isinstance(t, dict) and t.get("is_active", True):
                return VietHoaTranslation.from_dict(t)
            if isinstance(t, VietHoaTranslation) and t.is_active:
                return t
        if translations:
            first = translations[0]
            return VietHoaTranslation.from_dict(first) if isinstance(first, dict) else first
    return None


def catalog_urls_for_channel(channel: str | None = "stable") -> list[str]:
    """Return ordered remote catalog URLs to try for the configured update channel."""
    override = (os.environ.get("BOBGAMING_VIETHOA_CATALOG_URL") or "").strip()
    if override:
        return [override]
    ch = str(channel or "").strip().lower()
    if ch in ("rc", "release-candidates", "release_candidates", "release candidates"):
        return [REMOTE_RC_CATALOG_URL, REMOTE_CATALOG_URL]
    return [REMOTE_CATALOG_URL]


def _validate_remote_catalog_payload(data: Any) -> VietHoaCatalog | None:
    """Validate untrusted remote JSON at the trust boundary before caching or activating."""
    if not isinstance(data, dict):
        return None
    version = data.get("version")
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        return None
    raw_cat = data.get("catalog")
    if not isinstance(raw_cat, dict) or not raw_cat:
        return None

    # Ensure every translation URL (both nested download.primary.url and flat download_url) uses http(s) only
    for entry_raw in raw_cat.values():
        if not isinstance(entry_raw, dict):
            return None
        for tr in entry_raw.get("translations") or []:
            if not isinstance(tr, dict):
                return None
            dl_obj = tr.get("download")
            prim_obj = dl_obj.get("primary") if isinstance(dl_obj, dict) else None
            dl_url = str(
                (prim_obj.get("url") if isinstance(prim_obj, dict) else None)
                or tr.get("download_url")
                or tr.get("url")
                or ""
            ).strip().lower()
            if not (dl_url.startswith("https://") or dl_url.startswith("http://")):
                return None
            mirrors_list = list(tr.get("mirrors") or [])
            if isinstance(dl_obj, dict):
                mirrors_list.extend(dl_obj.get("mirrors") or [])
            for m in mirrors_list:
                m_url = str((m.get("url") if isinstance(m, dict) else m) or "").strip().lower()
                if m_url and not (m_url.startswith("https://") or m_url.startswith("http://")):
                    return None

    parsed = VietHoaCatalog(raw_data=data)
    if len(parsed) == 0:
        return None
    return parsed


def fetch_and_sync_remote_catalog(
    channel: str = "stable",
    *,
    urls: list[str] | None = None,
    cache_path: Optional[str] = None,
    bundled_path: Optional[str] = None,
) -> Tuple[bool, int]:
    """Fetch latest vietnamese_catalog.json from GitHub and atomically sync to CACHE_DIR if newer/changed.

    Safe to call from a background worker thread; never raises on network or parse errors.
    Returns (updated: bool, active_entry_count: int).
    """
    import requests
    from app.version import APP_VERSION

    current = get_viethoa_catalog(cache_path=cache_path, bundled_path=bundled_path)
    c_path = cache_path or get_catalog_cache_path()
    b_path = bundled_path or get_bundled_catalog_path()

    bundled_ver = 0
    if os.path.isfile(b_path):
        try:
            with open(b_path, "r", encoding="utf-8") as f:
                b_raw = json.load(f)
            if isinstance(b_raw, dict):
                bundled_ver = int(b_raw.get("version", 0) or 0)
        except Exception:
            pass

    candidate_urls = list(urls) if urls is not None else catalog_urls_for_channel(channel)
    min_version = max(current.version, bundled_ver)

    for url in candidate_urls:
        started = time.monotonic()
        sep = "&" if "?" in url else "?"
        req_url = f"{url}{sep}t={int(time.time())}"
        try:
            resp = requests.get(
                req_url,
                timeout=_REMOTE_HTTP_TIMEOUT,
                headers={"Cache-Control": "no-cache", "User-Agent": f"BobGamingGameCenter/{APP_VERSION}"},
            )
            dur = time.monotonic() - started
            if resp.status_code != 200:
                logger.warning(
                    f"{TAG} Remote catalog fetch failed: url={url} status={resp.status_code} duration={dur:.2f}s"
                )
                continue
            data = resp.json()
        except Exception as e:
            dur = time.monotonic() - started
            logger.warning(f"{TAG} Remote catalog network/parse error: url={url} status=ERR duration={dur:.2f}s ({e})")
            continue

        parsed = _validate_remote_catalog_payload(data)
        if parsed is None:
            logger.warning(f"{TAG} Rejected malformed or unsafe remote catalog payload from '{url}'")
            continue

        if parsed.version < min_version:
            logger.info(
                f"{TAG} Ignoring older remote catalog v{parsed.version} < local v{min_version} from '{url}'"
            )
            return False, len(current)

        # Check whether remote JSON differs from what is already active/cached
        already_identical = False
        if os.path.isfile(c_path):
            try:
                with open(c_path, "r", encoding="utf-8") as f:
                    cached_raw = json.load(f)
                if cached_raw == data and current.version == parsed.version and len(current) == len(parsed):
                    already_identical = True
            except Exception:
                pass
        elif os.path.isfile(b_path):
            try:
                with open(b_path, "r", encoding="utf-8") as f:
                    bundled_raw = json.load(f)
                if bundled_raw == data and current.version == parsed.version and len(current) == len(parsed):
                    already_identical = True
            except Exception:
                pass

        if already_identical:
            logger.info(
                f"{TAG} Remote catalog up-to-date: v{parsed.version} ({len(parsed)} games) checked in {dur:.2f}s"
            )
            return False, len(current)

        if sync_catalog_to_cache(data, cache_path=c_path):
            logger.info(
                f"{TAG} OTA catalog updated from '{url}': v{parsed.version} ({len(parsed)} games) in {dur:.2f}s"
            )
            return True, len(parsed)
        return False, len(current)

    return False, len(current)

