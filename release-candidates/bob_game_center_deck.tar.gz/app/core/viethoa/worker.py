"""Background worker thread and signal architecture for Vietnamese Localization (Việt Hoá).

Complies with Bob Game Center P0 rules:
- Logging tag: TAG = "[VietHoa/Worker]"
- Non-blocking UI: Unparented QThread running off the UI thread
- Thread registry: Tracked in _running_workers and safely stopped on app.aboutToQuit
- Pure Qt signals: Never touches UI widgets directly; emits progress and finished signals
- Crash-proof: All execution phases wrapped in try/except; auto-rollback on failure
- Zero emoji: All user-facing status messages strictly use plain text
"""

from __future__ import annotations

import logging
import os
import shutil
import threading
import time
from typing import Any

from PySide6.QtCore import QObject, QThread, Signal
from PySide6.QtWidgets import QApplication

from app.core.viethoa.downloader import download_viethoa_package, get_viethoa_download_cache_dir
from app.core.viethoa.extractor import extract_archive
from app.core.viethoa.installer import (
    install_viethoa,
    install_viethoa_package,
    is_game_running,
    resolve_game_install_dir,
    uninstall_viethoa,
)
from app.core.viethoa.manifest import force_remove_tree, rollback_manifest
from app.core.viethoa.models import VietHoaTranslation

logger = logging.getLogger(__name__)
TAG = "[VietHoa/Worker]"

# Global thread registry keeping strong references to active workers
_running_workers: set[QThread] = set()
_workers_lock = threading.Lock()
_quit_hooked = False


def _stop_all_workers_on_quit() -> None:
    """Invoked on QApplication.aboutToQuit: cancel active workers and wait up to 3s."""
    with _workers_lock:
        workers = list(_running_workers)
    logger.info(f"{TAG} Stopping {len(workers)} active worker(s) at application exit")
    for w in workers:
        if hasattr(w, "cancel"):
            try:
                w.cancel()
            except Exception as e:
                logger.warning(f"{TAG} Error cancelling worker {w.objectName()!r}: {e}")
    for w in workers:
        try:
            if not w.wait(3000):
                logger.warning(f"{TAG} Worker {w.objectName()!r} still running after exit timeout")
        except Exception as e:
            logger.warning(f"{TAG} Error waiting for worker {w.objectName()!r}: {e}")


def _hook_quit() -> None:
    """Ensure QApplication.aboutToQuit is connected once."""
    global _quit_hooked
    app = QApplication.instance()
    if app is not None and not _quit_hooked:
        app.aboutToQuit.connect(_stop_all_workers_on_quit)
        _quit_hooked = True


def register_worker(worker: QThread) -> None:
    """Add worker to global registry and hook finished signal for cleanup."""
    _hook_quit()
    with _workers_lock:
        _running_workers.add(worker)
    worker.finished.connect(lambda: unregister_worker(worker))


def unregister_worker(worker: QThread) -> None:
    """Remove worker from global registry upon completion."""
    with _workers_lock:
        _running_workers.discard(worker)


def get_running_workers() -> list[QThread]:
    """Return snapshot of active workers."""
    with _workers_lock:
        return list(_running_workers)


class VietHoaInstallWorker(QThread):
    """Asynchronous QThread worker executing the automated Vietnamese localization pipeline.

    Carries out:
    1. Game directory resolution & process lock detection (0-5%)
    2. Streaming download of localization archive with SHA-256 verification (5-50%)
    3. Multi-format archive extraction into staging directory with Zip-Slip defense (50-70%)
    4. Write-ahead journaling, pre-install backup, and file replacement (70-98%)
    5. Manifest commit & temporary staging cleanup (98-100%)

    Emits:
        progress(game_name: str, percent: int, status_message: str)
        finished(game_name: str, success: bool, result_message: str)
    """

    progress = Signal(str, int, str)
    finished = Signal(str, bool, str)

    def __init__(
        self,
        game_data: dict[str, Any],
        translation: VietHoaTranslation,
        archive_path: str = "",
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)  # Defaults to None (unparented to survive UI widget destruction)
        self.game_data = dict(game_data or {})
        self.translation = translation
        self.archive_path = str(archive_path or "").strip()
        self._cancelled = False
        self._cancel_event = threading.Event()

        game_name = str(self.game_data.get("name") or self.game_data.get("title") or "Unknown Game")
        self.setObjectName(f"viethoa-install-{game_name}")

    def cancel(self) -> None:
        """Cooperatively request cancellation of download, extraction, or installation."""
        logger.info(f"{TAG} Cancellation requested for {self.objectName()}")
        self._cancelled = True
        self._cancel_event.set()

    def is_cancelled(self) -> bool:
        """Check whether cancellation was requested."""
        return self._cancelled or self._cancel_event.is_set()

    def start_tracked(self) -> None:
        """Register worker in global tracking registry and start QThread off UI thread."""
        register_worker(self)
        self.start()

    def run(self) -> None:
        """Main worker execution loop running off the UI thread."""
        register_worker(self)
        game_name = str(self.game_data.get("name") or self.game_data.get("title") or "Unknown Game")
        raw_dir = (
            self.game_data.get("install_dir")
            or self.game_data.get("path")
            or self.game_data.get("install_location")
            or ""
        )
        started = time.monotonic()
        logger.info(f"{TAG} Worker started for game {game_name!r}")

        staging_dir: str | None = None
        game_root: str | None = None
        archive_to_extract = self.archive_path

        try:
            # ─────────────────────────────────────────────────────────────
            # Phase 1: Directory Resolution & Process Lock Check (0-5%)
            # ─────────────────────────────────────────────────────────────
            if not raw_dir:
                msg = "Khong tim thay duong dan thu muc cai dat tro choi"
                logger.warning(f"{TAG} {game_name!r}: {msg}")
                self.finished.emit(game_name, False, msg)
                return

            game_root = resolve_game_install_dir(raw_dir)
            if not os.path.isdir(game_root):
                msg = f"Thu muc cai dat tro choi khong ton tai: {game_root}"
                logger.warning(f"{TAG} {game_name!r}: {msg}")
                self.finished.emit(game_name, False, msg)
                return

            self.progress.emit(game_name, 5, "Kiem tra tien trinh tro choi...")

            if is_game_running(game_root):
                msg = "Cannot install: Game is currently running. Please close the game first."
                logger.warning(f"{TAG} {game_name!r}: process lock collision in {game_root}")
                self.finished.emit(game_name, False, msg)
                return

            if self.is_cancelled():
                logger.info(f"{TAG} {game_name!r}: Cancelled before download")
                self.finished.emit(game_name, False, "Cancelled by user")
                return

            # ─────────────────────────────────────────────────────────────
            # Phase 2: Patch Download & Verification (5-50%)
            # ─────────────────────────────────────────────────────────────
            if not archive_to_extract or not os.path.isfile(archive_to_extract):
                download_url = self.translation.download_url
                if not download_url and self.translation.download:
                    download_url = self.translation.download.primary_url
                if not download_url:
                    msg = "Khong tim thay lien ket tai ban Viet Hoa cho tro choi"
                    logger.warning(f"{TAG} {game_name!r}: {msg}")
                    self.finished.emit(game_name, False, msg)
                    return

                cache_dir = get_viethoa_download_cache_dir()
                os.makedirs(cache_dir, exist_ok=True)
                url_base = os.path.basename(download_url.split("?")[0]) or "patch.zip"
                safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in url_base)
                if safe_name.lower().endswith((".pak", ".archive", ".rpf", ".w3strings")):
                    sub_cache = os.path.join(cache_dir, self.translation.id)
                    os.makedirs(sub_cache, exist_ok=True)
                    dest_archive = os.path.join(sub_cache, safe_name)
                else:
                    dest_archive = os.path.join(cache_dir, f"{self.translation.id}_{safe_name}")

                def _dl_cb(bytes_done: int, total_bytes: int) -> None:
                    if self.is_cancelled():
                        return
                    if total_bytes > 0:
                        dl_pct = bytes_done / total_bytes
                        worker_pct = 5 + int(dl_pct * 45)  # 5% -> 50%
                        mb_done = bytes_done / (1024 * 1024)
                        mb_total = total_bytes / (1024 * 1024)
                        status_str = f"Dang tai goi Viet Hoa: {mb_done:.1f}/{mb_total:.1f} MB ({int(dl_pct * 100)}%)"
                    else:
                        worker_pct = 25
                        mb_done = bytes_done / (1024 * 1024)
                        status_str = f"Dang tai goi Viet Hoa: {mb_done:.1f} MB"
                    self.progress.emit(game_name, min(50, worker_pct), status_str)

                mirror_urls: list[str] | None = None
                if self.translation.download and self.translation.download.mirrors:
                    extracted_urls: list[str] = []
                    for m in self.translation.download.mirrors:
                        if isinstance(m, str) and m.strip():
                            extracted_urls.append(m.strip())
                        elif hasattr(m, "url") and getattr(m, "url"):
                            extracted_urls.append(str(getattr(m, "url")).strip())
                        elif isinstance(m, dict) and m.get("url"):
                            extracted_urls.append(str(m.get("url")).strip())
                    mirror_urls = extracted_urls if extracted_urls else None

                logger.info(f"{TAG} Downloading {download_url} to {dest_archive}")
                self.progress.emit(game_name, 10, "Bat dau tai goi Viet Hoa...")
                archive_to_extract = download_viethoa_package(
                    url=download_url,
                    dest_path=dest_archive,
                    expected_sha256=self.translation.sha256,
                    cancel_event=self._cancel_event,
                    progress_callback=_dl_cb,
                    mirrors=mirror_urls,
                )

            if self.is_cancelled():
                logger.info(f"{TAG} {game_name!r}: Cancelled after download")
                self.finished.emit(game_name, False, "Cancelled by user")
                return

            self.progress.emit(game_name, 50, "Tai hoan tat. Bat dau giai nen...")

            # ─────────────────────────────────────────────────────────────
            # Phase 3: Extraction to Staging Directory (50-70%)
            # ─────────────────────────────────────────────────────────────
            staging_dir = os.path.join(game_root, "BobVietHoa_staging")
            os.makedirs(staging_dir, exist_ok=True)

            def _extract_cb(pct: int, msg: str) -> None:
                if self.is_cancelled():
                    return
                worker_pct = 50 + int((pct / 100.0) * 20)  # 50% -> 70%
                self.progress.emit(game_name, min(70, worker_pct), f"Dang giai nen: {msg}")

            logger.info(f"{TAG} Extracting {archive_to_extract} to {staging_dir}")
            archive_pwd = getattr(getattr(self.translation, "install_rules", None), "archive_password", None) or None
            extract_archive(
                archive_path=archive_to_extract,
                extract_to=staging_dir,
                password=archive_pwd,
                progress_callback=_extract_cb,
                cancel_event=self._cancel_event,
            )

            if self.is_cancelled():
                logger.info(f"{TAG} {game_name!r}: Cancelled after extraction")
                force_remove_tree(staging_dir)
                self.finished.emit(game_name, False, "Cancelled by user")
                return

            self.progress.emit(game_name, 70, "Giai nen hoan tat. Bat dau cai dat va sao luu...")

            # ─────────────────────────────────────────────────────────────
            # Phase 4 & 5: Journaling, File Copying, Commit (70-100%)
            # ─────────────────────────────────────────────────────────────
            def _install_cb(pct: int, msg: str) -> None:
                if self.is_cancelled():
                    return
                worker_pct = 70 + int((pct / 100.0) * 28)  # 70% -> 98%
                self.progress.emit(game_name, min(98, worker_pct), msg)

            success, install_msg = install_viethoa_package(
                game_root=game_root,
                archive_path=None,
                translation=self.translation,
                game_title=game_name,
                progress_callback=_install_cb,
                cancel_event=self._cancel_event,
                staging_dir=staging_dir,
                patch_dir=staging_dir,
            )

            if staging_dir and os.path.exists(staging_dir):
                force_remove_tree(staging_dir)

            if not success:
                logger.warning(f"{TAG} {game_name!r} install failed: {install_msg}")
                self.finished.emit(game_name, False, install_msg)
                return

            # ─────────────────────────────────────────────────────────────
            # Phase 6: Completion
            # ─────────────────────────────────────────────────────────────
            elapsed = time.monotonic() - started
            logger.info(f"{TAG} Finished installation for {game_name!r} in {elapsed:.2f}s")
            self.progress.emit(game_name, 100, "Cai dat Viet Hoa thanh cong")
            self.finished.emit(game_name, True, "Cai dat Viet Hoa thanh cong")

        except Exception as exc:
            elapsed = time.monotonic() - started
            if self.is_cancelled() or "cancelled" in str(exc).lower():
                logger.info(f"{TAG} {game_name!r} aborted due to cancellation ({elapsed:.2f}s)")
                err_msg = "Cancelled by user"
            else:
                logger.exception(f"{TAG} Worker crashed while installing for {game_name!r}: {exc}")
                err_msg = str(exc) or exc.__class__.__name__

            if staging_dir and os.path.exists(staging_dir):
                try:
                    force_remove_tree(staging_dir)
                except Exception:
                    pass

            if game_root and os.path.isdir(game_root):
                try:
                    rollback_manifest(game_root)
                except Exception as rb_exc:
                    logger.warning(f"{TAG} Rollback after failure error: {rb_exc}")

            self.finished.emit(game_name, False, err_msg)


class VietHoaUninstallWorker(QThread):
    """Background worker executing clean uninstallation and original file restoration."""

    progress = Signal(str, int, str)
    finished = Signal(str, bool, str)

    def __init__(self, game_data: dict[str, Any], parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.game_data = dict(game_data or {})
        game_name = str(self.game_data.get("name") or self.game_data.get("title") or "Unknown Game")
        self.setObjectName(f"viethoa-uninstall-{game_name}")

    def start_tracked(self) -> None:
        """Register worker in global tracking registry and start QThread off UI thread."""
        register_worker(self)
        self.start()

    def run(self) -> None:
        register_worker(self)
        game_name = str(self.game_data.get("name") or self.game_data.get("title") or "Unknown Game")
        raw_dir = (
            self.game_data.get("install_dir")
            or self.game_data.get("path")
            or self.game_data.get("install_location")
            or ""
        )
        logger.info(f"{TAG} Uninstall worker started for {game_name!r}")

        try:
            if not raw_dir:
                msg = "Khong tim thay duong dan thu muc cai dat tro choi"
                self.finished.emit(game_name, False, msg)
                return

            game_root = resolve_game_install_dir(raw_dir)
            if not os.path.isdir(game_root):
                msg = f"Thu muc tro choi khong ton tai: {game_root}"
                self.finished.emit(game_name, False, msg)
                return

            if is_game_running(game_root):
                msg = "Cannot uninstall: Game is currently running. Please close the game first."
                logger.warning(f"{TAG} {game_name!r}: process lock collision in {game_root}")
                self.finished.emit(game_name, False, msg)
                return

            self.progress.emit(game_name, 30, "Dang khoi phuc tep tin goc...")
            success, msg = uninstall_viethoa(game_root)

            if success:
                self.progress.emit(game_name, 100, "Go cai dat Viet Hoa thanh cong")
                self.finished.emit(game_name, True, "Go cai dat Viet Hoa thanh cong")
            else:
                self.finished.emit(game_name, False, msg)
        except Exception as exc:
            logger.exception(f"{TAG} Uninstall crashed for {game_name!r}: {exc}")
            self.finished.emit(game_name, False, str(exc))
