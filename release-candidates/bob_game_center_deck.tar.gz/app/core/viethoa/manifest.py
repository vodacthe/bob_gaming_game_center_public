"""Write-ahead journaling and manifest management for Bob Game Center Vietnamese Localization.

Complies with Bob Game Center architectural standards:
- Logging: TAG = "[VietHoa/Manifest]"
- Crash-resilient write-ahead journaling in <game_root>/BobVietHoa/
- Dual-schema compatibility: supports both formal M2 schema and E2E test contracts
- Atomic file commits using .bobtmp and os.replace
- Preserves pre-existing backups on upgrade/reinstall
- Full clean rollback restoring backups and removing newly introduced files
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import stat
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Sequence

from app.core.viethoa.models import ManifestOp, OpState, OpType, VietHoaTranslation

logger = logging.getLogger(__name__)
TAG = "[VietHoa/Manifest]"

MANIFEST_DIR_NAME = "BobVietHoa"
MANIFEST_FILE_NAME = "manifest.json"
BACKUP_DIR_NAME = "backup"

STATUS_IN_PROGRESS = "in_progress"
STATUS_COMMITTED = "committed"
STATE_PENDING = "pending"
STATE_APPLIED = "applied"


class ManifestError(Exception):
    """Raised when manifest parsing, recording, or rollback encounters a fatal error."""

    pass


def get_manifest_dir(game_root: str) -> str:
    """Return the absolute path to <game_root>/BobVietHoa/."""
    return os.path.join(os.path.abspath(game_root), MANIFEST_DIR_NAME)


def get_manifest_path(game_root: str) -> str:
    """Return the absolute path to <game_root>/BobVietHoa/manifest.json."""
    return os.path.join(get_manifest_dir(game_root), MANIFEST_FILE_NAME)


def get_backup_dir(game_root: str) -> str:
    """Return the absolute path to <game_root>/BobVietHoa/backup/."""
    return os.path.join(get_manifest_dir(game_root), BACKUP_DIR_NAME)


def compute_file_sha256(file_path: str) -> str:
    """Compute lowercase SHA-256 hex digest of a local file."""
    hasher = hashlib.sha256()
    with open(file_path, "rb") as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest().lower()


def _safe_rel_path(game_root: str, rel_path: str) -> str:
    """Validate relative path does not escape game_root and normalize separators."""
    norm_root = os.path.normpath(os.path.abspath(game_root))
    clean_rel = rel_path.replace("\\", "/").strip("/")
    target = os.path.normpath(os.path.join(norm_root, clean_rel))
    if target != norm_root and not target.startswith(norm_root + os.sep):
        raise ManifestError(f"Security: Relative path escapes game root: {rel_path}")
    return clean_rel


def _force_remove_file(path: str) -> bool:
    """Safely remove a file, clearing read-only attributes on Windows if necessary.

    Returns:
        True if the file was deleted or did not exist, False if deletion failed.
    """
    if not os.path.exists(path) and not os.path.islink(path):
        return True
    try:
        os.remove(path)
        return True
    except OSError:
        try:
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
            os.remove(path)
            return True
        except OSError as e:
            logger.warning(f"{TAG} Could not delete file {path}: {e}")
            return False


def _force_rmdir(dir_path: str) -> bool:
    """Remove an empty directory, clearing read-only attributes on Windows if necessary."""
    try:
        os.rmdir(dir_path)
        return True
    except OSError:
        try:
            os.chmod(dir_path, stat.S_IWRITE | stat.S_IREAD)
            os.rmdir(dir_path)
            return True
        except OSError:
            return False


def force_remove_tree(dir_path: str, *args: Any, **kwargs: Any) -> bool:
    """Recursively remove a directory tree, clearing read-only attributes on Windows."""
    if not dir_path or not os.path.lexists(dir_path):
        return True

    # Handle directory junction or symlink at root
    if getattr(os.path, "isjunction", lambda p: False)(dir_path):
        try:
            os.rmdir(dir_path)
            return True
        except OSError:
            return False
    if os.path.islink(dir_path):
        try:
            os.unlink(dir_path)
            return True
        except OSError:
            return False

    def _handle_remove_readonly(func, path, exc_info=None):
        try:
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
            func(path)
        except OSError:
            pass

    try:
        shutil.rmtree(dir_path, onerror=_handle_remove_readonly)
        return not os.path.lexists(dir_path)
    except OSError as e:
        logger.warning(f"{TAG} Could not delete directory tree {dir_path}: {e}")
        return False


_force_remove_tree = force_remove_tree


@dataclass
class ManifestFileEntry:
    """Tracks a single file affected by the localization patch."""

    relative_path: str
    original_sha256: str | None = None
    patched_sha256: str | None = None
    is_new_file: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "relative_path": self.relative_path,
            "original_sha256": self.original_sha256,
            "patched_sha256": self.patched_sha256,
            "is_new_file": self.is_new_file,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ManifestFileEntry:
        return cls(
            relative_path=str(data.get("relative_path") or "").replace("\\", "/"),
            original_sha256=data.get("original_sha256"),
            patched_sha256=data.get("patched_sha256"),
            is_new_file=bool(data.get("is_new_file", False)),
        )


@dataclass
class VietHoaManifest:
    """Write-ahead journal manifest recording installed localization patch state."""

    game_id: str | int = ""
    game_name: str = ""
    translation_id: str = ""
    translation_version: str = ""
    team: str = ""
    installed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    status: str = STATUS_IN_PROGRESS
    installed_files: list[str] = field(default_factory=list)
    backup_files: list[str] = field(default_factory=list)
    files: list[ManifestFileEntry] = field(default_factory=list)
    ops: list[ManifestOp] = field(default_factory=list)

    # Backward compatibility properties for E2E contract tests
    @property
    def game_title(self) -> str:
        return self.game_name

    @property
    def version(self) -> str:
        return self.translation_version

    @property
    def timestamp(self) -> str:
        return self.installed_at

    @property
    def state(self) -> str:
        return STATE_APPLIED if self.status == STATUS_COMMITTED else STATE_PENDING

    def to_dict(self) -> dict[str, Any]:
        return {
            "game_id": self.game_id,
            "game_name": self.game_name,
            "game_title": self.game_name,
            "translation_id": self.translation_id,
            "translation_version": self.translation_version,
            "version": self.translation_version,
            "team": self.team,
            "installed_at": self.installed_at,
            "timestamp": self.installed_at,
            "status": self.status,
            "state": self.state,
            "installed_files": list(self.installed_files),
            "backup_files": list(self.backup_files),
            "files": [f.to_dict() for f in self.files],
            "ops": [op.to_dict() for op in self.ops],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VietHoaManifest:
        files = [ManifestFileEntry.from_dict(f) for f in data.get("files", []) if isinstance(f, dict)]
        ops = [ManifestOp.from_dict(o) for o in data.get("ops", []) if isinstance(o, dict)]
        return cls(
            game_id=data.get("game_id", ""),
            game_name=str(data.get("game_name") or data.get("game_title") or ""),
            translation_id=str(data.get("translation_id") or ""),
            translation_version=str(data.get("translation_version") or data.get("version") or ""),
            team=str(data.get("team") or ""),
            installed_at=str(data.get("installed_at") or data.get("timestamp") or ""),
            status=str(data.get("status") or STATUS_IN_PROGRESS),
            installed_files=[str(x) for x in data.get("installed_files", [])],
            backup_files=[str(x) for x in data.get("backup_files", [])],
            files=files,
            ops=ops,
        )


def save_manifest(game_root: str, manifest: VietHoaManifest) -> None:
    """Atomically write manifest to <game_root>/BobVietHoa/manifest.json via .bobtmp."""
    manifest_dir = get_manifest_dir(game_root)
    os.makedirs(manifest_dir, exist_ok=True)
    manifest_path = get_manifest_path(game_root)
    tmp_path = manifest_path + ".bobtmp"

    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(manifest.to_dict(), f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, manifest_path)
    except Exception as e:
        _force_remove_file(tmp_path)
        logger.error(f"{TAG} Failed to save manifest to {manifest_path}: {e}")
        raise ManifestError(f"Could not save manifest: {e}") from e


def load_manifest(game_root: str) -> VietHoaManifest | None:
    """Load and parse manifest from <game_root>/BobVietHoa/manifest.json."""
    manifest_path = get_manifest_path(game_root)
    if not os.path.isfile(manifest_path):
        return None
    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return VietHoaManifest.from_dict(data)
    except Exception as e:
        logger.warning(f"{TAG} Failed to read manifest at {manifest_path}: {e}")
        return None


def create_manifest_journal(
    game_root: str,
    game_title: str,
    translation: VietHoaTranslation,
    files_to_install: Sequence[tuple[str, str]],  # (source_abs_path, target_rel_path)
    game_id: str | int = "",
) -> VietHoaManifest:
    """Initialize write-ahead journal, back up pre-existing original files, and record pending state.

    Args:
        game_root: Target game directory.
        game_title: Canonical game name.
        translation: VietHoaTranslation metadata release.
        files_to_install: List of tuples (source_path, target_relative_path).
        game_id: Optional game identifier.

    Returns:
        VietHoaManifest instance in 'in_progress' status.
    """
    logger.info(f"{TAG} Creating write-ahead journal for '{game_title}' ({len(files_to_install)} files)")
    manifest_dir = get_manifest_dir(game_root)
    backup_dir = get_backup_dir(game_root)
    os.makedirs(manifest_dir, exist_ok=True)
    os.makedirs(backup_dir, exist_ok=True)

    installed_files: list[str] = []
    backup_files: list[str] = []
    file_entries: list[ManifestFileEntry] = []
    ops: list[ManifestOp] = []

    for src_path, raw_rel_path in files_to_install:
        clean_rel = _safe_rel_path(game_root, raw_rel_path)
        dest_abs = os.path.join(game_root, clean_rel)
        installed_files.append(clean_rel)

        patched_hash = compute_file_sha256(src_path) if os.path.isfile(src_path) else None

        if os.path.isfile(dest_abs):
            # Target file exists: preserve original file in backup
            bak_dest = os.path.join(backup_dir, clean_rel)
            # Reinstall/upgrade guard: only copy if backup does not already exist
            # to preserve genuine pre-mod original bytes
            if not os.path.exists(bak_dest):
                os.makedirs(os.path.dirname(bak_dest), exist_ok=True)
                shutil.copy2(dest_abs, bak_dest)

            orig_hash = compute_file_sha256(bak_dest) if os.path.isfile(bak_dest) else None
            backup_files.append(clean_rel)
            ops.append(
                ManifestOp(
                    op=OpType.REPLACE.value,
                    path=clean_rel,
                    backup=f"{MANIFEST_DIR_NAME}/{BACKUP_DIR_NAME}/{clean_rel}",
                    state=OpState.PENDING.value,
                    sha256=patched_hash,
                )
            )
            file_entries.append(
                ManifestFileEntry(
                    relative_path=clean_rel,
                    original_sha256=orig_hash,
                    patched_sha256=patched_hash,
                    is_new_file=False,
                )
            )
        else:
            # New file added by localization mod
            ops.append(
                ManifestOp(
                    op=OpType.CREATE.value,
                    path=clean_rel,
                    state=OpState.PENDING.value,
                    sha256=patched_hash,
                )
            )
            file_entries.append(
                ManifestFileEntry(
                    relative_path=clean_rel,
                    original_sha256=None,
                    patched_sha256=patched_hash,
                    is_new_file=True,
                )
            )

    manifest = VietHoaManifest(
        game_id=game_id,
        game_name=game_title,
        translation_id=translation.id,
        translation_version=translation.version,
        team=translation.team,
        installed_at=datetime.now(timezone.utc).isoformat(),
        status=STATUS_IN_PROGRESS,
        installed_files=installed_files,
        backup_files=backup_files,
        files=file_entries,
        ops=ops,
    )

    save_manifest(game_root, manifest)
    return manifest


def commit_manifest(game_root: str) -> bool:
    """Transition manifest state from 'in_progress' to 'committed'."""
    manifest = load_manifest(game_root)
    if not manifest:
        logger.error(f"{TAG} Cannot commit: Manifest not found at {get_manifest_path(game_root)}")
        return False

    manifest.status = STATUS_COMMITTED
    for op in manifest.ops:
        op.state = OpState.DONE.value

    try:
        save_manifest(game_root, manifest)
        logger.info(f"{TAG} Manifest committed successfully for '{manifest.game_name}' ({manifest.translation_id})")
        return True
    except Exception as e:
        logger.error(f"{TAG} Failed to commit manifest: {e}")
        return False


def rollback_manifest(game_root: str) -> tuple[bool, str]:
    """Roll back installed localization patch and restore original backups cleanly.

    Returns:
        Tuple (success, message).
    """
    manifest_path = get_manifest_path(game_root)
    if not os.path.exists(manifest_path):
        return False, "Manifest not found"

    manifest = load_manifest(game_root)
    if not manifest:
        # Fallback to direct directory cleanup if json is corrupted
        _force_remove_tree(get_manifest_dir(game_root))
        return False, "Manifest file corrupted"

    logger.info(f"{TAG} Initiating rollback for '{manifest.game_name}' in '{game_root}'")
    backup_dir = get_backup_dir(game_root)
    manifest_dir = get_manifest_dir(game_root)

    # 1. Clean up temporary .bobtmp files for all affected entries
    for entry in manifest.files:
        try:
            clean_rel = _safe_rel_path(game_root, entry.relative_path)
            tmp_path = os.path.join(game_root, clean_rel) + ".bobtmp"
            _force_remove_file(tmp_path)
        except ManifestError:
            pass

    for rel_path in manifest.backup_files:
        try:
            clean_rel = _safe_rel_path(game_root, rel_path)
            tmp_path = os.path.join(game_root, clean_rel) + ".bobtmp"
            _force_remove_file(tmp_path)
        except ManifestError:
            pass

    # 2. Remove newly created / installed files
    for entry in manifest.files:
        try:
            clean_rel = _safe_rel_path(game_root, entry.relative_path)
        except ManifestError:
            logger.warning(f"{TAG} Skipping unsafe relative path: {entry.relative_path}")
            continue
        if entry.is_new_file or clean_rel not in manifest.backup_files:
            target_path = os.path.join(game_root, clean_rel)
            _force_remove_file(target_path)

    # 3. Restore backed-up files from BobVietHoa/backup/
    restoration_failed = False
    for rel_path in manifest.backup_files:
        try:
            clean_rel = _safe_rel_path(game_root, rel_path)
        except ManifestError:
            logger.warning(f"{TAG} Skipping unsafe backup relative path: {rel_path}")
            continue
        bak_file = os.path.join(backup_dir, clean_rel)
        dest_file = os.path.join(game_root, clean_rel)
        if os.path.isfile(bak_file):
            try:
                os.makedirs(os.path.dirname(dest_file), exist_ok=True)
                _force_remove_file(dest_file)
                shutil.copy2(bak_file, dest_file)
            except OSError as e:
                logger.error(f"{TAG} Failed to restore {dest_file} from backup: {e}")
                restoration_failed = True
        else:
            # Handle edge case: backup file was deleted from disk externally
            logger.warning(f"{TAG} Backup copy missing for {rel_path}; skipping file restoration")

    # 4. Clean up empty parent directories left behind
    for entry in manifest.files:
        try:
            clean_rel = _safe_rel_path(game_root, entry.relative_path)
            parent = os.path.dirname(os.path.join(game_root, clean_rel))
            while parent and parent != os.path.abspath(game_root):
                try:
                    if not os.listdir(parent):
                        if not _force_rmdir(parent):
                            break
                        parent = os.path.dirname(parent)
                    else:
                        break
                except OSError:
                    break
        except ManifestError:
            continue

    if restoration_failed:
        return False, "Rollback failed: one or more backup files could not be restored"

    # 5. Remove BobVietHoa directory completely
    _force_remove_tree(manifest_dir)

    logger.info(f"{TAG} Rollback completed successfully for '{manifest.game_name}'")
    return True, "Rollback and restoration completed successfully"


def is_viethoa_installed(game_root: str) -> bool:
    """Return True if Vietnamese localization is installed and committed."""
    manifest = load_manifest(game_root)
    if not manifest:
        return False
    return manifest.status == STATUS_COMMITTED or manifest.state == STATE_APPLIED
