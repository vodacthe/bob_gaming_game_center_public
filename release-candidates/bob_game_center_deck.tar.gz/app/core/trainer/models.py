"""Data shapes shared by the FLiNG client, the trainer library and the Trainer screen."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields

SOURCE_FLING = "fling"
SOURCE_ARCHIVE = "fling_archive"


class TrainerError(Exception):
    """Expected failure with a message the UI can show as-is (Vietnamese)."""


@dataclass(frozen=True)
class TrainerSummary:
    """One search hit. `key` is stable across sessions: "fling:<post id>" or "archive:<file name>"."""

    key: str
    title: str
    page_url: str
    source: str = SOURCE_FLING
    image_url: str = ""
    updated: str = ""           # YYYY-MM-DD when known
    download_url: str = ""      # archive entries link the file directly


@dataclass(frozen=True)
class TrainerOption:
    hotkey: str                 # "Ctrl+Num 1"
    name: str                   # "Edit Rune"


@dataclass(frozen=True)
class TrainerFile:
    """One downloadable trainer build (FLiNG keeps one per supported game-version range)."""

    title: str                  # "Elden.Ring.Nightreign.v1.01-v1.03.1.Plus.26.Trainer-FLiNG"
    url: str
    added: str = ""             # "2025-12-18 10:25"
    size_text: str = ""         # "1.01 MB"
    downloads: int = 0


@dataclass
class TrainerDetail:
    summary: TrainerSummary
    title: str
    options_count: int = 0
    game_version: str = ""
    last_updated: str = ""
    options: list[TrainerOption] = field(default_factory=list)
    files: list[TrainerFile] = field(default_factory=list)   # newest first
    anti_cheat: str = ""        # "EasyAntiCheat", "BattlEye", ... when the page mentions one
    image_url: str = ""


@dataclass
class SearchResult:
    """Search hits; `site_error` is set when flingtrainer.com failed and only archive hits could be returned."""

    items: list[TrainerSummary] = field(default_factory=list)
    site_error: str = ""


@dataclass
class InstalledTrainer:
    """A trainer extracted under <config>/trainers, persisted in installed.json."""

    key: str
    title: str
    file_title: str
    exe_path: str
    folder: str
    source: str = SOURCE_FLING
    page_url: str = ""
    download_url: str = ""
    image_url: str = ""
    anti_cheat: str = ""
    installed_at: float = 0.0
    size_bytes: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "InstalledTrainer":
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in known})
