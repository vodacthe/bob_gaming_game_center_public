"""Game Trainer feature: search, download and run FLiNG trainers (see fling-trainer.md)."""
