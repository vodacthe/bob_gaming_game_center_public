"""
Local trainer library: download a FLiNG trainer build, extract it under <config>/trainers/<game>/<version>, remember it
in installed.json and start it through the Windows shell (so a trainer that needs admin rights gets the UAC prompt).
Thread-safe: the index sits behind a lock and a trainer key can only be installed by one thread at a time. Public
methods raise only TrainerError, whose message is shown to the user as-is.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import threading
import time
import uuid
import zipfile
from typing import Callable, Optional

import requests

from app.core.trainer.fling_client import FlingClient, get_client
from app.core.trainer.models import InstalledTrainer, TrainerDetail, TrainerError, TrainerFile

logger = logging.getLogger(__name__)
TAG = "[Trainer/Library]"

INDEX_NAME = "installed.json"
DOWNLOADS_DIR = "_downloads"
MAX_DOWNLOAD_BYTES = 300 * 1024 * 1024
MAX_EXTRACTED_BYTES = 1024 * 1024 * 1024
_CHUNK = 256 * 1024
_EXTRACT_TIMEOUT_S = 300
_EXCLUDED_EXE = ("unins", "setup", "vc_redist", "vcredist", "dxsetup", "dotnet", "crashreport", "7z")

_MAGIC = (
    (b"PK\x03\x04", "zip"),
    (b"Rar!\x1a\x07", "rar"),
    (b"7z\xbc\xaf\x27\x1c", "7z"),
    (b"MZ", "exe"),
)

ProgressFn = Callable[[int, int], None]     # (bytes done, bytes total or 0)


def trainers_root() -> str:
    from app import config      # read at call time: tests point CONFIG_DIR at a temp folder
    return os.path.join(config.CONFIG_DIR, "trainers")


def safe_name(text: str, fallback: str = "trainer", max_len: int = 80) -> str:
    """Folder-safe name: no reserved characters or device names, no trailing dots/spaces, at most max_len chars."""
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', " ", text or "")
    name = re.sub(r"\s+", " ", name).strip(" .")[:max_len].strip(" .")
    if re.fullmatch(r"(con|prn|aux|nul|com\d|lpt\d)(\..*)?", name, re.IGNORECASE):
        name = f"_{name}"
    return name or fallback


def archive_kind(path: str) -> str:
    try:
        with open(path, "rb") as fh:
            head = fh.read(8)
    except OSError:
        return ""
    for magic, kind in _MAGIC:
        if head.startswith(magic):
            return kind
    return ""


def _inside(path: str, root: str) -> bool:
    path, root = os.path.normcase(os.path.realpath(path)), os.path.normcase(os.path.realpath(root))
    return path == root or path.startswith(root.rstrip("\\/") + os.sep)


def _is_version_folder(path: str, root: str) -> bool:
    """True only for <root>/<game>/<version>: the one shape remove / cleanup may delete (never the root itself)."""
    if not path:
        return False
    try:
        rel = os.path.relpath(os.path.realpath(path), os.path.realpath(root))
    except ValueError:      # another drive
        return False
    parts = rel.split(os.sep)
    return len(parts) == 2 and ".." not in parts and "." not in parts


# ------------------------------------------------------------------ Mark-of-the-Web

_ZONE_STREAM = ":Zone.Identifier"
_MOTW_EXTENSIONS = (".exe", ".dll", ".com", ".scr", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".msi", ".cpl")


def read_zone(path: str) -> str:
    """The Zone.Identifier stream a browser attaches to downloads ("" when absent or not NTFS)."""
    try:
        with open(path + _ZONE_STREAM, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read(4096)
    except OSError:
        return ""


def internet_zone(url: str) -> str:
    """Zone.Identifier text for a file that came from `url` (text mode turns the newlines into CRLF on write)."""
    return f"[ZoneTransfer]\nZoneId=3\nHostUrl={url}\n"


def _replace_folder(staging: str, folder: str) -> None:
    """Move staging into folder, retrying brief OneDrive / Defender scan locks on Windows."""
    for attempt in range(5):
        try:
            os.replace(staging, folder)
            return
        except OSError:
            if attempt == 4:
                raise
            time.sleep(0.15 * (attempt + 1))


def mark_of_the_web(folder: str, zone_text: str) -> int:
    """Copy the archive's Internet-zone mark onto the extracted executables, as Explorer does, so SmartScreen and
    the Attachment Manager still check the trainer when it is started. Returns how many files were marked."""
    marked = 0
    for dirpath, _dirs, files in os.walk(folder):
        for name in files:
            if not name.lower().endswith(_MOTW_EXTENSIONS):
                continue
            try:
                with open(os.path.join(dirpath, name) + _ZONE_STREAM, "w", encoding="utf-8") as fh:
                    fh.write(zone_text)
                marked += 1
            except OSError as e:     # FAT32 / exFAT have no alternate data streams
                logger.debug(f"{TAG} Could not mark {name} with its download zone: {e}")
    return marked


def extract_zip(src: str, dest: str) -> None:
    """Extract a zip, refusing entries that would land outside dest (zip-slip) and oversized archives."""
    try:
        with zipfile.ZipFile(src) as zf:
            infos = zf.infolist()
            if sum(i.file_size for i in infos) > MAX_EXTRACTED_BYTES:
                raise TrainerError("File nén trainer quá lớn bất thường, đã dừng giải nén.")
            for info in infos:
                if not _inside(os.path.join(dest, info.filename), dest):
                    logger.warning(f"{TAG} Zip entry escapes the target folder: {info.filename!r}")
                    raise TrainerError("File nén chứa đường dẫn không an toàn, đã dừng giải nén.")
            zf.extractall(dest)
    except zipfile.BadZipFile:
        raise TrainerError("File trainer tải về bị hỏng. Hãy thử tải lại.") from None
    except RuntimeError as e:   # encrypted entry
        raise TrainerError(f"Không giải nén được trainer: {e}") from None


def extract_with_7z(src: str, dest: str) -> None:
    """Extract .rar / .7z with the bundled 7z.exe (the archive site ships .rar files)."""
    from app.core.online_fix.extractor import clean_subprocess_env, find_7z_binary

    seven = find_7z_binary()
    if not seven:
        raise TrainerError("Không tìm thấy 7-Zip để giải nén file .rar của trainer.")
    cmd = [seven, "x", src, f"-o{dest}", "-y", "-p", "-bso0", "-bsp0"]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, timeout=_EXTRACT_TIMEOUT_S, env=clean_subprocess_env(),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except subprocess.TimeoutExpired:
        raise TrainerError("Giải nén trainer quá lâu, đã dừng.") from None
    except OSError as e:
        raise TrainerError(f"Không chạy được 7-Zip: {e.strerror or e}") from None
    if proc.returncode != 0:
        tail = (proc.stderr or b"").decode("utf-8", "replace").strip().splitlines()[-1:] or [""]
        logger.warning(f"{TAG} 7z exited with {proc.returncode} for {src}: {tail[0]}")
        raise TrainerError("Không giải nén được file trainer (file có thể bị hỏng). Hãy thử tải lại.")
    for dirpath, _dirs, files in os.walk(dest):
        for name in files:
            if not _inside(os.path.join(dirpath, name), dest):
                raise TrainerError("File nén chứa đường dẫn không an toàn, đã dừng giải nén.")


def find_trainer_exe(folder: str) -> Optional[str]:
    """The trainer .exe: prefer a name containing "trainer", otherwise the largest non-helper executable."""
    candidates = []
    for dirpath, _dirs, files in os.walk(folder):
        for name in files:
            low = name.lower()
            if not low.endswith(".exe") or ("trainer" not in low and any(x in low for x in _EXCLUDED_EXE)):
                continue
            path = os.path.join(dirpath, name)
            try:
                size = os.path.getsize(path)
            except OSError:
                continue
            candidates.append(("trainer" in low, size, path))
    if not candidates:
        return None
    return max(candidates)[2]


def downloads_dir() -> str:
    """The user's Downloads folder (known-folder lookup, so a relocated folder is found too)."""
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            class _GUID(ctypes.Structure):
                _fields_ = [("d1", wintypes.DWORD), ("d2", wintypes.WORD), ("d3", wintypes.WORD),
                            ("d4", ctypes.c_ubyte * 8)]

            folder_id = _GUID(0x374DE290, 0x123F, 0x4565, (ctypes.c_ubyte * 8)(0x91, 0x64, 0x39, 0xC4, 0x92, 0x5E,
                                                                                0x46, 0x7B))
            out = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(folder_id), 0, None, ctypes.byref(out)) == 0:
                path = out.value
                ctypes.windll.ole32.CoTaskMemFree(out)
                if path and os.path.isdir(path):
                    return path
        except (OSError, AttributeError, ValueError) as e:
            logger.debug(f"{TAG} Known-folder lookup for Downloads failed: {e}")
    return os.path.join(os.path.expanduser("~"), "Downloads")


def _shell_open(path: str) -> None:
    from app.core.online_fix.extractor import clean_subprocess_env

    clean_subprocess_env()      # resets the frozen app's DLL directory so the child does not inherit it
    os.startfile(path, cwd=os.path.dirname(path))


class TrainerLibrary:
    """Installed trainers on disk. `launcher` starts an exe (os.startfile by default; tests pass a fake)."""

    def __init__(self, root: str | None = None, launcher: Callable[[str], None] | None = None):
        self._root = root
        self._launcher = launcher or _shell_open
        self._lock = threading.RLock()
        self._active: dict[str, threading.Event] = {}

    @property
    def root(self) -> str:
        return self._root or trainers_root()

    def banner_cache_dir(self) -> str:
        if self._root is not None:
            return os.path.join(self._root, "_banners")
        from app import config
        return os.path.join(config.CACHE_DIR, "trainer_banners")

    def _banner_cache_paths(self, url: str) -> tuple[str, str]:
        digest = hashlib.sha256((url or "").strip().encode("utf-8")).hexdigest()[:24]
        base_dir = self.banner_cache_dir()
        return os.path.join(base_dir, f"{digest}.bin"), os.path.join(base_dir, f"{digest}_thumb.png")

    def read_cached_banner(self, url: str) -> bytes:
        if not (url or "").strip():
            return b""
        raw_path, _ = self._banner_cache_paths(url)
        try:
            with open(raw_path, "rb") as fh:
                return fh.read(8 * 1024 * 1024)
        except OSError:
            return b""

    def write_cached_banner(self, url: str, data: bytes) -> None:
        if not (url or "").strip() or not data or len(data) > 8 * 1024 * 1024:
            return
        raw_path, _ = self._banner_cache_paths(url)
        self._atomic_write_bytes(raw_path, data)

    def read_cached_banner_thumb(self, url: str) -> bytes:
        if not (url or "").strip():
            return b""
        _, thumb_path = self._banner_cache_paths(url)
        try:
            with open(thumb_path, "rb") as fh:
                return fh.read(4 * 1024 * 1024)
        except OSError:
            return b""

    def write_cached_banner_thumb(self, url: str, png_bytes: bytes) -> None:
        if not (url or "").strip() or not png_bytes or len(png_bytes) > 4 * 1024 * 1024:
            return
        _, thumb_path = self._banner_cache_paths(url)
        self._atomic_write_bytes(thumb_path, png_bytes)

    @staticmethod
    def _atomic_write_bytes(path: str, data: bytes) -> None:
        tmp = f"{path}.{uuid.uuid4().hex}.tmp"
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(tmp, "wb") as fh:
                fh.write(data)
            os.replace(tmp, path)
        except OSError as e:
            logger.debug(f"{TAG} Could not cache banner file {path}: {e}")
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass

    # -------------------------------------------------------------- index

    def _index_path(self) -> str:
        return os.path.join(self.root, INDEX_NAME)

    def _load_index(self) -> dict[str, dict]:
        path = self._index_path()
        if not os.path.isfile(path):
            return {}
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError) as e:
            logger.warning(f"{TAG} Could not read {path} ({e.__class__.__name__}: {e}); starting with an empty list")
            return {}
        return {k: v for k, v in data.items() if isinstance(v, dict)} if isinstance(data, dict) else {}

    def _save_index(self, data: dict[str, dict]) -> None:
        os.makedirs(self.root, exist_ok=True)
        path = self._index_path()
        tmp = f"{path}.{uuid.uuid4().hex}.tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
        except OSError as e:
            logger.error(f"{TAG} Could not save {path}: {e}")
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise TrainerError(f"Không lưu được danh sách trainer: {e.strerror or e}") from None

    def list_installed(self) -> list[InstalledTrainer]:
        """Installed trainers, newest first. Entries whose exe disappeared (antivirus, manual delete) are dropped."""
        with self._lock:
            data = self._load_index()
            out, missing = [], []
            for key, raw in data.items():
                try:
                    item = InstalledTrainer.from_dict(raw)
                except TypeError:
                    missing.append(key)
                    continue
                if os.path.isfile(item.exe_path):
                    out.append(item)
                else:
                    missing.append(key)
            if missing:
                logger.warning(f"{TAG} {len(missing)} trainer(s) lost their exe and were removed from the list: "
                               f"{', '.join(missing)}")
                for key in missing:
                    data.pop(key, None)
                try:
                    self._save_index(data)
                except TrainerError:
                    pass
        out.sort(key=lambda t: t.installed_at, reverse=True)
        return out

    def get(self, key: str) -> Optional[InstalledTrainer]:
        return next((t for t in self.list_installed() if t.key == key), None)

    # -------------------------------------------------------------- install

    def is_busy(self, key: str) -> bool:
        with self._lock:
            return key in self._active

    def cancel(self, key: str) -> bool:
        with self._lock:
            event = self._active.get(key)
        if event is None:
            return False
        logger.info(f"{TAG} Cancel requested for {key}")
        event.set()
        return True

    def cancel_all(self) -> None:
        with self._lock:
            events = list(self._active.values())
        for event in events:
            event.set()

    def _exclusive(self, key: str) -> threading.Event:
        with self._lock:
            if key in self._active:
                logger.warning(f"{TAG} Refused second install of {key}: already in progress")
                raise TrainerError("Trainer này đang được tải.")
            cancel = threading.Event()
            self._active[key] = cancel
            return cancel

    def _release(self, key: str) -> None:
        with self._lock:
            self._active.pop(key, None)

    def install(self, detail: TrainerDetail, file: TrainerFile, progress: ProgressFn | None = None,
                client: FlingClient | None = None) -> InstalledTrainer:
        """Download `file` directly from FLiNG or the archive site, extract it, find the trainer exe and record it,
        replacing an older version of the same trainer."""
        key = detail.summary.key
        cancel = self._exclusive(key)
        t0 = time.monotonic()
        part = os.path.join(self.root, DOWNLOADS_DIR, f"{uuid.uuid4().hex}.part")
        logger.info(f"{TAG} Install start {detail.title!r} ({file.title}) from {file.url}")
        try:
            os.makedirs(os.path.dirname(part), exist_ok=True)
            size = self._download(file, part, cancel, progress, client or get_client(),
                                  referer=detail.summary.page_url)
            active_client = client or get_client()
            entry = self._extract_and_record(detail, file, part, size, t0, internet_zone(file.url))
            if entry.image_url and not self.read_cached_banner(entry.image_url):
                try:
                    raw_img = active_client.fetch_image(entry.image_url)
                    if raw_img:
                        self.write_cached_banner(entry.image_url, raw_img)
                        logger.info(f"{TAG} Cached banner image for {entry.title!r} ({len(raw_img)} bytes)")
                except Exception as img_err:    # noqa: BLE001
                    logger.debug(f"{TAG} Optional banner pre-cache skipped for {entry.title!r}: {img_err}")
            return entry
        except TrainerError as e:
            logger.warning(f"{TAG} Install of {key} failed after {time.monotonic() - t0:.2f}s: {e}")
            raise
        except OSError as e:
            logger.error(f"{TAG} Install of {key} failed on disk after {time.monotonic() - t0:.2f}s: {e}")
            raise TrainerError(f"Lỗi ghi file trainer: {e.strerror or e}") from None
        finally:
            try:
                if os.path.exists(part):
                    os.remove(part)
            except OSError:
                logger.debug(f"{TAG} Could not delete {part}")
            self._release(key)

    def import_file(self, detail: TrainerDetail, file: TrainerFile, archive_path: str) -> InstalledTrainer:
        """Extract or copy a locally downloaded trainer (.zip/.rar/.7z/.exe) and record it. Leaves user's file intact."""
        key = detail.summary.key
        self._exclusive(key)
        t0 = time.monotonic()
        logger.info(f"{TAG} Import start {detail.title!r} ({file.title}) from {archive_path}")
        try:
            zone = read_zone(archive_path) or internet_zone(file.url)
            return self._extract_and_record(detail, file, archive_path, os.path.getsize(archive_path), t0, zone)
        except TrainerError as e:
            logger.warning(f"{TAG} Import of {key} failed after {time.monotonic() - t0:.2f}s: {e}")
            raise
        except OSError as e:
            logger.error(f"{TAG} Import of {key} failed on disk after {time.monotonic() - t0:.2f}s: {e}")
            raise TrainerError(f"Lỗi đọc / ghi file trainer: {e.strerror or e}") from None
        finally:
            self._release(key)

    def _extract_and_record(self, detail: TrainerDetail, file: TrainerFile, archive: str, size: int,
                            t0: float, zone: str) -> InstalledTrainer:
        key = detail.summary.key
        root = self.root
        # Short folder names keep <Documents>\Bob Gaming\GameCenter\trainers\<game>\<version>\<exe> under MAX_PATH.
        folder = os.path.join(root, safe_name(detail.title, max_len=36), safe_name(file.title, "version", 44))
        staging = f"{folder}.tmp"
        try:
            kind = archive_kind(archive)
            if not kind:
                logger.warning(f"{TAG} {archive} is not an archive or exe ({size} bytes, from {file.url})")
                raise TrainerError("File tải về không phải file nén hoặc .exe trainer (trang FLiNG có thể đang bảo trì). "
                                   "Hãy thử lại sau.")
            shutil.rmtree(staging, ignore_errors=True)
            os.makedirs(staging, exist_ok=True)
            if kind == "zip":
                extract_zip(archive, staging)
            elif kind == "exe":
                shutil.copyfile(archive, os.path.join(staging, f"{safe_name(file.title, 'Trainer', 60)}.exe"))
            else:
                extract_with_7z(archive, staging)
            exe = find_trainer_exe(staging)
            if not exe:
                logger.warning(f"{TAG} No trainer exe after extracting {file.title} (antivirus quarantine?)")
                raise TrainerError(
                    "Không tìm thấy file trainer (.exe) sau khi giải nén. Phần mềm diệt virus thường báo nhầm "
                    "trainer và xóa file: hãy kiểm tra Windows Security > Protection history rồi tải lại.")
            marked = mark_of_the_web(staging, zone)
            logger.debug(f"{TAG} Marked {marked} extracted executable(s) with the download zone")
            rel_exe = os.path.relpath(exe, staging)
            if os.path.isdir(folder):
                try:
                    shutil.rmtree(folder)
                except OSError:
                    raise TrainerError("Không thay được bản cũ: hãy tắt trainer đang chạy rồi thử lại.") from None
            _replace_folder(staging, folder)
            entry = InstalledTrainer(
                key=key,
                title=detail.title,
                file_title=file.title,
                exe_path=os.path.join(folder, rel_exe),
                folder=folder,
                source=detail.summary.source,
                page_url=detail.summary.page_url,
                download_url=detail.summary.download_url or file.url,
                image_url=detail.image_url or detail.summary.image_url,
                anti_cheat=detail.anti_cheat,
                installed_at=time.time(),
                size_bytes=size,
            )
            with self._lock:
                data = self._load_index()
                previous = data.get(key, {}).get("folder")
                data[key] = entry.to_dict()
                self._save_index(data)
            if (previous and os.path.normcase(previous) != os.path.normcase(folder)
                    and _is_version_folder(previous, root)):
                shutil.rmtree(previous, ignore_errors=True)
                logger.info(f"{TAG} Removed previous version folder {previous}")
            logger.info(f"{TAG} Installed {detail.title!r} -> {rel_exe} ({size} bytes) in {time.monotonic() - t0:.2f}s")
            return entry
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    def _download(self, file: TrainerFile, dest: str, cancel: threading.Event, progress: ProgressFn | None,
                  client: FlingClient, referer: str = "") -> int:
        t0 = time.monotonic()
        resp = client.open_download(file.url, referer=referer, timeout=(15, 60))
        written = 0
        with resp:
            total = int(resp.headers.get("Content-Length") or 0)
            ctype = resp.headers.get("Content-Type", "").lower()
            if total > MAX_DOWNLOAD_BYTES:
                logger.warning(f"{TAG} {file.url} is {total} bytes, over the {MAX_DOWNLOAD_BYTES} limit")
                raise TrainerError("File trainer lớn bất thường, đã dừng tải.")
            if "text/html" in ctype:
                logger.warning(f"{TAG} {file.url} answered with a web page ({ctype}) instead of a file")
                raise TrainerError("Trang FLiNG trả về trang web thay vì file trainer. Hãy thử lại sau "
                                   "hoặc mở trang FLiNG để tải thủ công.")
            next_mark = 25
            try:
                with open(dest, "wb") as fh:
                    for chunk in resp.iter_content(_CHUNK):
                        if cancel.is_set():
                            logger.info(f"{TAG} Download of {file.title} cancelled at {written} bytes")
                            raise TrainerError("Đã hủy tải trainer.")
                        if not chunk:
                            continue
                        fh.write(chunk)
                        written += len(chunk)
                        if written > MAX_DOWNLOAD_BYTES:
                            raise TrainerError("File trainer lớn bất thường, đã dừng tải.")
                        if progress is not None:
                            progress(written, total)
                        if total:
                            while next_mark < 100 and written * 100 >= total * next_mark:
                                logger.info(f"{TAG} Download {file.title}: {next_mark}%")
                                next_mark += 25
            except requests.RequestException as e:
                logger.warning(f"{TAG} Download {file.url} broke after {written} bytes "
                               f"({e.__class__.__name__}: {e}) in {time.monotonic() - t0:.2f}s")
                raise TrainerError("Mất kết nối khi đang tải trainer. Hãy thử lại.") from None
        if total and written != total:
            logger.warning(f"{TAG} Download {file.url} incomplete: {written}/{total} bytes")
            raise TrainerError("Tải trainer chưa trọn vẹn. Hãy thử lại.")
        logger.info(f"{TAG} Downloaded {file.title}: {written} bytes in {time.monotonic() - t0:.2f}s")
        return written

    # -------------------------------------------------------------- remove / launch

    def remove(self, key: str) -> None:
        with self._lock:
            data = self._load_index()
            raw = data.get(key)
            if raw is None:
                return
            folder = str(raw.get("folder") or "")
            if folder and not _is_version_folder(folder, self.root):
                logger.warning(f"{TAG} Not deleting {folder!r} for {key}: not a trainer folder under {self.root}")
            elif os.path.isdir(folder):
                try:
                    shutil.rmtree(folder)
                except OSError as e:
                    logger.warning(f"{TAG} Could not delete {folder}: {e}")
                    raise TrainerError("Không xóa được trainer: hãy tắt trainer đang chạy rồi thử lại.") from None
                parent = os.path.dirname(folder)
                if parent != os.path.normpath(self.root) and _inside(parent, self.root):
                    try:
                        os.rmdir(parent)      # only when empty
                    except OSError:
                        pass
            data.pop(key, None)
            self._save_index(data)
        logger.info(f"{TAG} Removed trainer {key} ({raw.get('title')!r})")

    def launch(self, key: str) -> InstalledTrainer:
        item = self.get(key)
        if item is None:
            raise TrainerError("File trainer không còn (có thể đã bị phần mềm diệt virus xóa). Hãy tải lại.")
        if not _inside(item.exe_path, self.root):
            logger.warning(f"{TAG} Refused to launch {item.exe_path}: outside {self.root}")
            raise TrainerError("Đường dẫn trainer không hợp lệ.")
        logger.info(f"{TAG} Launching {item.title!r}: {item.exe_path}")
        try:
            self._launcher(item.exe_path)
        except OSError as e:
            code = getattr(e, "winerror", None)
            logger.warning(f"{TAG} Launch of {item.exe_path} failed (winerror={code}): {e}")
            if code == 1223:
                raise TrainerError("Bạn đã từ chối quyền quản trị (UAC) nên trainer chưa chạy.") from None
            if code == 225:
                raise TrainerError("Windows Security đã chặn trainer vì nghi là virus (trainer hay bị báo nhầm). "
                                   "Bạn có thể cho phép trong Windows Security > Protection history.") from None
            raise TrainerError(f"Không chạy được trainer: {e.strerror or e}") from None
        return item


_library: TrainerLibrary | None = None
_library_lock = threading.Lock()


def get_library() -> TrainerLibrary:
    global _library
    with _library_lock:
        if _library is None:
            _library = TrainerLibrary()
        return _library
