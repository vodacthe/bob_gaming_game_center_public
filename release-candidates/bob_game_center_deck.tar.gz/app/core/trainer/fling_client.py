"""
FLiNG trainer catalogue client: search flingtrainer.com (WordPress REST, HTML search as fallback) plus the old-trainer
archive, and parse a trainer page into its options, notes and download table. Pure parsing functions are module-level
so tests can feed them synthetic HTML; the client only does HTTP. Every call runs off the UI thread.
"""

from __future__ import annotations

import html
import json
import logging
import re
import threading
import time
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse

import requests

from app.core.trainer.models import (
    SOURCE_ARCHIVE,
    SOURCE_FLING,
    SearchResult,
    TrainerDetail,
    TrainerError,
    TrainerFile,
    TrainerOption,
    TrainerSummary,
)

logger = logging.getLogger(__name__)
TAG = "[Trainer/FLiNG]"

SITE_URL = "https://flingtrainer.com/"
REST_POSTS_URL = "https://flingtrainer.com/wp-json/wp/v2/posts"
HTML_SEARCH_URL = "https://flingtrainer.com/"
ARCHIVE_URL = "https://archive.flingtrainer.com/"
TRAINER_CATEGORY_ID = 5
ALLOWED_HOSTS = frozenset({"flingtrainer.com", "www.flingtrainer.com", "archive.flingtrainer.com"})

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/130.0 Safari/537.36"
)
_HTTP_TIMEOUT = 15
_SEARCH_LIMIT = 30
_ARCHIVE_TTL_S = 24 * 3600
_MAX_IMAGE_BYTES = 4 * 1024 * 1024

_ANTI_CHEATS = (
    ("EasyAntiCheat", re.compile(r"easy\s*anti[\s-]*cheat|\bEAC\b", re.IGNORECASE)),
    ("BattlEye", re.compile(r"battl\s*eye", re.IGNORECASE)),
    ("nProtect GameGuard", re.compile(r"game\s*guard", re.IGNORECASE)),
    ("Denuvo Anti-Cheat", re.compile(r"denuvo\s+anti", re.IGNORECASE)),
    ("Anti-cheat", re.compile(r"anti[\s-]*cheat", re.IGNORECASE)),
)
_NOTE_HEADINGS = {"special notes", "notes", "note", "download", "how to use", "instructions"}
_OPTION_SPLIT_RE = re.compile(r"\s+[–—-]\s+")
_ARTICLE_RE = re.compile(r"<article\b[^>]*>.*?</article>", re.DOTALL | re.IGNORECASE)
_TAG_RE = re.compile(r"<[^>]+>")
_ARCHIVE_VERSION_RE = re.compile(r"\s+(?:v\.?\s?\d|Plus\s+\d|Build\s+\d|Update\s+\d|Early Access)", re.IGNORECASE)


# ------------------------------------------------------------------ helpers

def is_allowed_url(url: str) -> bool:
    """Only FLiNG's own hosts over HTTPS; anything else is refused (also after redirects)."""
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    return parsed.scheme == "https" and (parsed.hostname or "").lower() in ALLOWED_HOSTS


def resolve_download_target(base_url: str, location: str) -> str:
    """Turn download-trainer.php?path=/wp-content/... into the direct archive URL so we fetch the .zip/.rar cleanly."""
    loc = urljoin(base_url, location or "")
    parsed = urlparse(loc)
    if parsed.path.rstrip("/") == "/download-trainer.php":
        raw_path = parse_qs(parsed.query).get("path", [""])[0]
        if raw_path.startswith("/wp-content/") and ".." not in raw_path.split("/"):
            return urljoin(f"{parsed.scheme}://{parsed.netloc}/", quote(raw_path, safe="/"))
    return loc


def _text(fragment: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(_TAG_RE.sub(" ", fragment or ""))).strip()


def _html_lines(fragment: str) -> list[str]:
    """Block-level HTML to text lines (<br>, </p>, </h*>, </li> end a line)."""
    frag = re.sub(r"<(script|style|ins)\b.*?</\1>", " ", fragment, flags=re.DOTALL | re.IGNORECASE)
    frag = re.sub(r"<br\s*/?>|</(?:p|h\d|li|div|tr)>", "\n", frag, flags=re.IGNORECASE)
    out = []
    for line in html.unescape(_TAG_RE.sub("", frag)).splitlines():
        line = re.sub(r"\s+", " ", line).strip()
        if line:
            out.append(line)
    return out


def normalize_words(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", re.sub(r"['‘’`]", "", (text or "").lower()))


def matches_query(title: str, query: str) -> bool:
    """Every query word starts a word of the title ("elden ri", "assassin creed" -> "Assassin's Creed")."""
    words = normalize_words(query)
    if not words:
        return False
    title_words = normalize_words(title)
    return all(any(t.startswith(w) for t in title_words) for w in words)


def _iso_date(raw: str) -> str:
    m = re.search(r"(\d{4})[-./](\d{1,2})[-./](\d{1,2})", raw or "")
    return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}" if m else ""


def detect_anti_cheat(text: str) -> str:
    for name, pattern in _ANTI_CHEATS:
        if pattern.search(text or ""):
            return name
    return ""


# ------------------------------------------------------------------ parsers

def parse_search_json(data: object) -> list[TrainerSummary]:
    """WordPress REST /posts response -> summaries (non-trainer or malformed entries are skipped)."""
    out: list[TrainerSummary] = []
    if not isinstance(data, list):
        return out
    for post in data:
        if not isinstance(post, dict):
            continue
        link = str(post.get("link") or "")
        post_id = post.get("id")
        title = post.get("title")
        title = html.unescape(str(title.get("rendered") if isinstance(title, dict) else title or "")).strip()
        if not post_id or not title or not is_allowed_url(link):
            continue
        image = ""
        yoast = post.get("yoast_head_json")
        if isinstance(yoast, dict):
            imgs = yoast.get("og_image")
            if isinstance(imgs, list) and imgs and isinstance(imgs[0], dict):
                image = str(imgs[0].get("url") or "")
        out.append(TrainerSummary(
            key=f"fling:{post_id}",
            title=title,
            page_url=link,
            source=SOURCE_FLING,
            image_url=image if is_allowed_url(image) else "",
            updated=_iso_date(str(post.get("modified") or post.get("date") or "")),
        ))
    return out


def parse_search_html(page: str) -> list[TrainerSummary]:
    """HTML search page (/?s=) -> summaries of posts in the Trainer category."""
    out: list[TrainerSummary] = []
    for art in _ARTICLE_RE.findall(page or ""):
        if "category-trainer" not in art:
            continue
        m_id = re.search(r'id="post-(\d+)"', art)
        m_title = re.search(r'class="post-title"[^>]*>\s*<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>', art, re.DOTALL)
        if not m_id or not m_title or not is_allowed_url(m_title.group(1)):
            continue
        m_img = re.search(r'<img\b[^>]*\bsrc="([^"]+)"', art)
        image = m_img.group(1) if m_img else ""
        # 200x200 thumbnail -> full header image (same upload, without the size suffix)
        image = re.sub(r"-\d+x\d+(\.\w+)$", r"\1", image)
        day = re.search(r'post-details-day">\s*(\d+)', art)
        month = re.search(r'post-details-month">\s*(\w+)', art)
        year = re.search(r'post-details-year">\s*(\d{4})', art)
        updated = ""
        if day and month and year:
            try:
                updated = time.strftime("%Y-%m-%d", time.strptime(f"{day.group(1)} {month.group(1)[:3]} {year.group(1)}", "%d %b %Y"))
            except ValueError:
                updated = ""
        out.append(TrainerSummary(
            key=f"fling:{m_id.group(1)}",
            title=_text(m_title.group(2)),
            page_url=m_title.group(1),
            source=SOURCE_FLING,
            image_url=image if is_allowed_url(image) else "",
            updated=updated,
        ))
    return out


def parse_trainer_page(page: str, summary: TrainerSummary) -> TrainerDetail:
    """Trainer page -> options, supported game version, anti-cheat note and the download table (newest first)."""
    page = page or ""
    m_h1 = re.search(r"<h1\b[^>]*class=\"post-title[^\"]*\"[^>]*>(.*?)</h1>", page, re.DOTALL)
    title = _text(m_h1.group(1)) if m_h1 else summary.title
    m_img = re.search(r'<meta property="og:image" content="([^"]+)"', page)
    image = m_img.group(1) if m_img and is_allowed_url(m_img.group(1)) else summary.image_url

    start = page.find('<div class="entry')
    body = page[start:] if start >= 0 else page
    table_at = body.find("da-attachments-table")
    entry = body[:table_at] if table_at >= 0 else body[:200_000]
    lines = _html_lines(entry)

    options_count, game_version, last_updated = 0, "", ""
    for line in lines[:12]:
        m_count = re.search(r"(\d+)\s+Options?\b", line, re.IGNORECASE)
        if m_count and not options_count:
            options_count = int(m_count.group(1))
        m_ver = re.search(r"Game Version:\s*(.+?)(?:Last Updated|$)", line, re.IGNORECASE)
        if m_ver and not game_version:
            game_version = re.sub(r"[^\w+)\]]+$", "", m_ver.group(1).strip())
        m_upd = re.search(r"Last Updated:\s*([\d./-]+)", line, re.IGNORECASE)
        if m_upd and not last_updated:
            last_updated = _iso_date(m_upd.group(1))

    options: list[TrainerOption] = []
    notes: list[str] = []
    section = ""
    for line in lines:
        low = line.lower().rstrip(":")
        if low == "options":
            section = "options"
            continue
        if low in _NOTE_HEADINGS:
            section = "notes"
            continue
        if section == "options":
            parts = _OPTION_SPLIT_RE.split(line, maxsplit=1)
            if len(parts) == 2 and 0 < len(parts[0]) <= 32 and parts[1].strip():
                options.append(TrainerOption(hotkey=parts[0].strip(), name=parts[1].strip()))
        elif section == "notes":
            notes.append(line)

    files: list[TrainerFile] = []
    if table_at >= 0:
        table = body[table_at:body.find("</table>", table_at) if "</table>" in body[table_at:] else len(body)]
        for row in re.findall(r"<tr\b[^>]*>(.*?)</tr>", table, re.DOTALL | re.IGNORECASE):
            m_link = re.search(r'<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>', row, re.DOTALL)
            if not m_link or not is_allowed_url(html.unescape(m_link.group(1))):
                continue
            added = re.search(r'attachment-date"[^>]*>(.*?)</td>', row, re.DOTALL)
            size = re.search(r'attachment-size"[^>]*>(.*?)</td>', row, re.DOTALL)
            count = re.search(r'attachment-downloads"[^>]*>\s*([\d,.]+)', row)
            files.append(TrainerFile(
                title=_text(m_link.group(2)),
                url=html.unescape(m_link.group(1)),
                added=_text(added.group(1)) if added else "",
                size_text=_text(size.group(1)) if size else "",
                downloads=int(re.sub(r"\D", "", count.group(1)) or 0) if count else 0,
            ))
    files.sort(key=lambda f: f.added, reverse=True)

    return TrainerDetail(
        summary=summary,
        title=title,
        options_count=options_count or len(options),
        game_version=game_version,
        last_updated=last_updated or summary.updated,
        options=options,
        files=files,
        anti_cheat=detect_anti_cheat(" ".join(notes)),
        image_url=image,
    )


def parse_archive_index(page: str, base_url: str = ARCHIVE_URL) -> list[TrainerSummary]:
    """archive.flingtrainer.com index -> one summary per .rar/.zip file."""
    out: list[TrainerSummary] = []
    seen: set[str] = set()
    for href in re.findall(r'href="([^"]+\.(?:rar|zip|7z))"', page or "", re.IGNORECASE):
        url = urljoin(base_url, quote(unquote(html.unescape(href)), safe="/:"))
        if not is_allowed_url(url):
            continue
        file_name = unquote(urlparse(url).path.rsplit("/", 1)[-1])
        if file_name in seen:
            continue
        seen.add(file_name)
        stem = file_name.rsplit(".", 1)[0].replace("_", " ")
        game = _ARCHIVE_VERSION_RE.split(stem, maxsplit=1)[0].strip() or stem
        out.append(TrainerSummary(
            key=f"archive:{file_name}",
            title=f"{game} Trainer",
            page_url=ARCHIVE_URL,
            source=SOURCE_ARCHIVE,
            download_url=url,
            updated="",
        ))
    return out


# ------------------------------------------------------------------ client

class FlingClient:
    """HTTP side of the catalogue. Thread-safe: one requests.Session per thread, archive index behind a lock."""

    def __init__(self):
        self._local = threading.local()
        self._archive_lock = threading.Lock()
        self._archive: list[TrainerSummary] = []
        self._archive_at = 0.0

    @property
    def session(self) -> requests.Session:
        sess = getattr(self._local, "session", None)
        if sess is None:
            sess = requests.Session()
            sess.headers.update({"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9"})
            self._local.session = sess
        return sess

    def get(self, url: str, purpose: str, **kwargs) -> requests.Response:
        """GET with logging of URL / status / duration; network problems become TrainerError."""
        if not is_allowed_url(url):
            logger.warning(f"{TAG} Refused {purpose}: {url} is not a FLiNG https URL")
            raise TrainerError("Địa chỉ tải không thuộc trang FLiNG, đã chặn để đảm bảo an toàn.")
        kwargs.setdefault("timeout", _HTTP_TIMEOUT)
        t0 = time.monotonic()
        try:
            resp = self.session.get(url, **kwargs)
        except requests.Timeout:
            logger.warning(f"{TAG} {purpose} GET {url} timed out after {time.monotonic() - t0:.2f}s")
            raise TrainerError("Trang FLiNG phản hồi quá lâu, vui lòng thử lại sau.") from None
        except requests.RequestException as e:
            logger.warning(f"{TAG} {purpose} GET {url} failed ({e.__class__.__name__}: {e}) "
                           f"in {time.monotonic() - t0:.2f}s")
            raise TrainerError("Không kết nối được tới trang FLiNG. Kiểm tra mạng rồi thử lại.") from None
        if not is_allowed_url(resp.url):
            resp.close()
            logger.warning(f"{TAG} {purpose} GET {url} redirected to a foreign host: {resp.url}")
            raise TrainerError("Trang FLiNG chuyển hướng tới địa chỉ lạ, đã chặn để đảm bảo an toàn.")
        if resp.status_code != 200:
            logger.warning(f"{TAG} {purpose} GET {url} -> HTTP {resp.status_code} in {time.monotonic() - t0:.2f}s")
            resp.close()
            raise TrainerError(f"Trang FLiNG trả về lỗi HTTP {resp.status_code}.")
        logger.debug(f"{TAG} {purpose} GET {url} -> 200 in {time.monotonic() - t0:.2f}s")
        return resp

    def open_download(self, url: str, referer: str = "", timeout: object = (15, 60)) -> requests.Response:
        """Open a streaming trainer download, resolving FLiNG's /downloads/<id>,, redirect to the real archive."""
        if not is_allowed_url(url):
            logger.warning(f"{TAG} Refused trainer download: {url} is not a FLiNG https URL")
            raise TrainerError("Địa chỉ tải không thuộc trang FLiNG, đã chặn để đảm bảo an toàn.")
        headers = {"Referer": referer if is_allowed_url(referer) else SITE_URL}
        t0 = time.monotonic()
        try:
            resp = self.session.get(url, headers=headers, allow_redirects=False, stream=True, timeout=timeout)
        except requests.Timeout:
            logger.warning(f"{TAG} trainer download GET {url} timed out after {time.monotonic() - t0:.2f}s")
            raise TrainerError("Trang FLiNG phản hồi quá lâu, vui lòng thử lại sau.") from None
        except requests.RequestException as e:
            logger.warning(f"{TAG} trainer download GET {url} failed ({e.__class__.__name__}: {e}) "
                           f"in {time.monotonic() - t0:.2f}s")
            raise TrainerError("Không kết nối được tới trang FLiNG. Kiểm tra mạng rồi thử lại.") from None

        if resp.status_code in (301, 302, 303, 307, 308):
            raw_loc = resp.headers.get("Location") or ""
            resp.close()
            loc = urljoin(url, raw_loc)
            if not is_allowed_url(loc):
                logger.warning(f"{TAG} trainer download GET {url} redirected to a foreign host: {loc}")
                raise TrainerError("Trang FLiNG chuyển hướng tới địa chỉ lạ, đã chặn để đảm bảo an toàn.")
            direct = resolve_download_target(url, raw_loc)
            if direct != loc:
                try:
                    return self.get(direct, "trainer archive", headers=headers, stream=True, timeout=timeout)
                except TrainerError as e:
                    logger.warning(f"{TAG} Direct archive {direct} unavailable ({e}), falling back to {loc}")
            return self.get(loc, "trainer download", headers=headers, stream=True, timeout=timeout)

        if not is_allowed_url(resp.url):
            resp.close()
            logger.warning(f"{TAG} trainer download GET {url} redirected to a foreign host: {resp.url}")
            raise TrainerError("Trang FLiNG chuyển hướng tới địa chỉ lạ, đã chặn để đảm bảo an toàn.")
        if resp.status_code != 200:
            logger.warning(f"{TAG} trainer download GET {url} -> HTTP {resp.status_code} in {time.monotonic() - t0:.2f}s")
            resp.close()
            raise TrainerError(f"Trang FLiNG trả về lỗi HTTP {resp.status_code}.")
        logger.debug(f"{TAG} trainer download GET {url} -> 200 in {time.monotonic() - t0:.2f}s")
        return resp

    # -------------------------------------------------------------- search

    def search(self, query: str) -> SearchResult:
        """FLiNG site hits (relevance order) followed by matching archive files. When the site fails but the archive
        has hits, those are returned with `site_error` set so the UI can say the list is incomplete."""
        query = (query or "").strip()
        if not normalize_words(query):
            raise TrainerError("Nhập tên game để tìm trainer.")
        t0 = time.monotonic()
        site: list[TrainerSummary] = []
        site_error: TrainerError | None = None
        try:
            site = self._search_site(query)
        except TrainerError as e:
            site_error = e
        archive: list[TrainerSummary] = []
        try:
            archive = [s for s in self.archive_index() if matches_query(s.title, query)]
        except TrainerError as e:
            logger.warning(f"{TAG} Archive search skipped: {e}")
        if site_error is not None and not archive:
            raise site_error
        # WordPress also matches the page body ("elden ring" finds unrelated trainers that mention it): when some
        # titles match, keep only those, in the site's relevance order.
        titled = [s for s in site if matches_query(s.title, query)]
        if titled:
            site = titled
        if site_error is not None:
            logger.warning(f"{TAG} Search {query!r}: FLiNG site unavailable ({site_error}), "
                           f"returning {len(archive)} archived trainers only")
        logger.info(f"{TAG} Search {query!r}: {len(site)} trainers + {len(archive)} archived "
                    f"in {time.monotonic() - t0:.2f}s")
        return SearchResult(items=site + archive, site_error=str(site_error) if site_error is not None else "")

    def _search_site(self, query: str) -> list[TrainerSummary]:
        params = {
            "search": query,
            "categories": TRAINER_CATEGORY_ID,
            "per_page": _SEARCH_LIMIT,
            "_fields": "id,title,link,modified,date,yoast_head_json",
        }
        try:
            resp = self.get(REST_POSTS_URL, "REST search", params=params)
            try:
                return parse_search_json(resp.json())
            except (ValueError, json.JSONDecodeError):
                logger.warning(f"{TAG} REST search for {query!r} returned non-JSON, using the HTML search")
        except TrainerError as e:
            logger.warning(f"{TAG} REST search for {query!r} failed ({e}), using the HTML search")
        resp = self.get(f"{HTML_SEARCH_URL}?s={quote(query)}", "HTML search")
        return parse_search_html(resp.text)[:_SEARCH_LIMIT]

    def archive_index(self) -> list[TrainerSummary]:
        with self._archive_lock:
            if self._archive and time.monotonic() - self._archive_at < _ARCHIVE_TTL_S:
                return list(self._archive)
            t0 = time.monotonic()
            resp = self.get(ARCHIVE_URL, "archive index")
            items = parse_archive_index(resp.text)
            self._archive, self._archive_at = items, time.monotonic()
            logger.info(f"{TAG} Archive index: {len(items)} trainers in {time.monotonic() - t0:.2f}s")
            return list(items)

    # -------------------------------------------------------------- details

    def get_detail(self, summary: TrainerSummary) -> TrainerDetail:
        if summary.source == SOURCE_ARCHIVE:
            if not is_allowed_url(summary.download_url):
                logger.warning(f"{TAG} Archive entry {summary.key} has no usable download link")
                raise TrainerError("Thiếu link tải của trainer này. Hãy tìm lại trainer rồi tải.")
            file_title = unquote(urlparse(summary.download_url).path.rsplit("/", 1)[-1]).rsplit(".", 1)[0]
            return TrainerDetail(
                summary=summary,
                title=summary.title,
                files=[TrainerFile(title=file_title, url=summary.download_url)],
            )
        t0 = time.monotonic()
        resp = self.get(summary.page_url, "trainer page")
        detail = parse_trainer_page(resp.text, summary)
        logger.info(f"{TAG} Trainer page {summary.title!r}: {len(detail.options)} options, "
                    f"{len(detail.files)} files, anti-cheat={detail.anti_cheat or 'none'} "
                    f"in {time.monotonic() - t0:.2f}s")
        if not detail.files:
            logger.warning(f"{TAG} No download link found on {summary.page_url}")
        return detail

    def fetch_image(self, url: str) -> bytes:
        """Cover image bytes, or b"" on any failure (covers are decoration, never an error)."""
        if not url:
            return b""
        try:
            resp = self.get(url, "cover image")
        except TrainerError:
            return b""
        data = resp.content
        return data if len(data) <= _MAX_IMAGE_BYTES else b""


_client: FlingClient | None = None
_client_lock = threading.Lock()


def get_client() -> FlingClient:
    global _client
    with _client_lock:
        if _client is None:
            _client = FlingClient()
        return _client
