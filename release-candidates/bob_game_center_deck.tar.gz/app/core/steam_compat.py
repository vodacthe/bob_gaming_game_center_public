"""
Steam config.vdf compatibility tool mapping (CompatToolMapping) manager for Bob Game Center.
Pure Python KeyValues 1 (text VDF) parser, serializer, and Proton compatibility configurator.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import time
from typing import Optional

logger = logging.getLogger(__name__)

TAG = "[Steam/Compat]"
DEFAULT_PROTON_TOOL = "proton_experimental"
DEFAULT_PROTON_PRIORITY = "250"
CONFIG_VDF_REL_PATH = os.path.join("config", "config.vdf")


def _normalize_appid(appid: int | str) -> str:
    """Normalize signed or unsigned AppID to 32-bit unsigned decimal string."""
    try:
        val = int(appid)
        return str(val & 0xFFFFFFFF)
    except (ValueError, TypeError):
        return str(appid).strip()


def parse_simple_vdf_text(text: str) -> dict:
    """
    Robust pure Python parser for Valve KeyValues 1 (text VDF) format.
    Handles comments, nested braces, empty strings, and malformed inputs.
    Never throws on corrupted or unbalanced inputs.
    """
    try:
        root: dict = {}
        stack: list[dict] = [root]
        key_stack: list[str] = [""]

        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("//"):
                continue

            # Strip inline comments: // followed by anything
            if "//" in line:
                # Only strip if not inside quotes
                parts = line.split("//", 1)
                if parts[0].count('"') % 2 == 0:
                    line = parts[0].strip()
                    if not line:
                        continue

            if line == "{":
                new_dict: dict = {}
                parent = stack[-1]
                active_key = key_stack[-1] if key_stack and key_stack[-1] else "root"
                parent[active_key] = new_dict
                stack.append(new_dict)
                continue

            if line == "}":
                if len(stack) > 1:
                    stack.pop()
                continue

            # Extract double-quoted tokens supporting escaped characters
            tokens = re.findall(r'"([^"\\]*(?:\\.[^"\\]*)*)"', line)
            if len(tokens) >= 2:
                key, val = tokens[0], tokens[1]
                stack[-1][key] = val
                # Handle potential trailing block open, e.g. "Key" {
                if "{" in line[line.rfind('"'):]:
                    new_dict = {}
                    stack[-1][key] = new_dict
                    stack.append(new_dict)
            elif len(tokens) == 1:
                key = tokens[0]
                key_stack[-1] = key
                # Handle inline block open: "Key" {
                if "{" in line:
                    new_dict = {}
                    stack[-1][key] = new_dict
                    stack.append(new_dict)

        return root
    except Exception as e:
        logger.warning(f"{TAG} Error parsing KeyValues text VDF: {e}")
        return {}


def serialize_simple_vdf_text(data: dict, indent_level: int = 0) -> str:
    """
    Serialize Python dictionary to Valve KeyValues 1 (text VDF) format.
    Formats tab indentation matching Steam client standards.
    """
    out: list[str] = []
    tab = "\t" * indent_level
    for key, val in data.items():
        if isinstance(val, dict):
            out.append(f'{tab}"{key}"')
            out.append(f"{tab}{{")
            out.append(serialize_simple_vdf_text(val, indent_level + 1))
            out.append(f"{tab}}}")
        else:
            out.append(f'{tab}"{key}"\t\t"{val}"')
    return "\n".join(out)


def _find_or_create_child_dict(parent: dict, target_key: str) -> dict:
    """Case-insensitive child dictionary lookup; creates target_key if absent."""
    for k, v in parent.items():
        if k.lower() == target_key.lower():
            if isinstance(v, dict):
                return v
            parent[k] = {}
            return parent[k]
    new_dict: dict = {}
    parent[target_key] = new_dict
    return new_dict


def _find_child_dict(parent: dict, target_key: str) -> Optional[dict]:
    """Case-insensitive child dictionary lookup without creating."""
    for k, v in parent.items():
        if k.lower() == target_key.lower() and isinstance(v, dict):
            return v
    return None


def get_steam_config_path(steam_path: str | None = None) -> Optional[str]:
    """Resolve full path to config/config.vdf for a given or auto-detected Steam path."""
    sp = steam_path
    if not sp:
        from app.core.steam_manager import find_steam_path
        sp = find_steam_path()
    if not sp:
        return None
    return os.path.join(sp, "config", "config.vdf")


def backup_config_vdf(config_file: str) -> bool:
    """Safely create .bak backup copy of config.vdf if file exists and has content."""
    try:
        if os.path.isfile(config_file) and os.path.getsize(config_file) > 0:
            bak_path = f"{config_file}.bak"
            shutil.copy2(config_file, bak_path)
            return True
        return False
    except Exception as e:
        logger.warning(f"{TAG} Failed to backup {config_file}: {e}")
        return False


def get_proton_compatibility(steam_path: str, uint_appid: int | str) -> Optional[dict[str, str]]:
    """
    Retrieve Proton compatibility mapping for given AppID from config.vdf.
    Returns mapping dict or None if not configured.
    """
    str_appid = _normalize_appid(uint_appid)
    config_file = os.path.join(steam_path, "config", "config.vdf")
    if not os.path.isfile(config_file):
        logger.debug(f"{TAG} config.vdf does not exist at {config_file}")
        return None

    try:
        with open(config_file, "r", encoding="utf-8", errors="replace") as f:
            data = parse_simple_vdf_text(f.read())

        store = _find_child_dict(data, "InstallConfigStore")
        if not store:
            return None
        software = _find_child_dict(store, "Software")
        if not software:
            return None
        valve = _find_child_dict(software, "Valve")
        if not valve:
            return None
        steam = _find_child_dict(valve, "Steam")
        if not steam:
            return None
        compat = _find_child_dict(steam, "CompatToolMapping")
        if not compat:
            return None

        mapping = compat.get(str_appid)
        if isinstance(mapping, dict):
            return dict(mapping)
        return None
    except Exception as e:
        logger.warning(f"{TAG} Failed to get proton compatibility for AppID {str_appid}: {e}")
        return None


def list_proton_compatibilities(steam_path: str) -> dict[str, dict[str, str]]:
    """List all Proton compatibility tool mappings configured in config.vdf."""
    config_file = os.path.join(steam_path, "config", "config.vdf")
    if not os.path.isfile(config_file):
        return {}

    try:
        with open(config_file, "r", encoding="utf-8", errors="replace") as f:
            data = parse_simple_vdf_text(f.read())

        store = _find_child_dict(data, "InstallConfigStore") or {}
        software = _find_child_dict(store, "Software") or {}
        valve = _find_child_dict(software, "Valve") or {}
        steam = _find_child_dict(valve, "Steam") or {}
        compat = _find_child_dict(steam, "CompatToolMapping") or {}

        result: dict[str, dict[str, str]] = {}
        for appid, mapping in compat.items():
            if isinstance(mapping, dict):
                result[str(appid)] = dict(mapping)
        return result
    except Exception as e:
        logger.warning(f"{TAG} Failed to list proton compatibilities: {e}")
        return {}


def set_proton_compatibility(
    steam_path: str,
    uint_appid: int | str,
    tool_name: str = DEFAULT_PROTON_TOOL,
    priority: str = DEFAULT_PROTON_PRIORITY,
) -> bool:
    """
    Inject or update CompatToolMapping in config.vdf for given AppID.
    Creates backup config.vdf.bak and writes atomically via .tmp file.
    """
    t0 = time.perf_counter()
    str_appid = _normalize_appid(uint_appid)
    config_dir = os.path.join(steam_path, "config")
    config_file = os.path.join(config_dir, "config.vdf")
    temp_file = f"{config_file}.tmp"

    try:
        os.makedirs(config_dir, exist_ok=True)
        data: dict = {}

        if os.path.isfile(config_file):
            backup_config_vdf(config_file)
            with open(config_file, "r", encoding="utf-8", errors="replace") as f:
                data = parse_simple_vdf_text(f.read())

        # Safely traverse hierarchy
        store = _find_or_create_child_dict(data, "InstallConfigStore")
        software = _find_or_create_child_dict(store, "Software")
        valve = _find_or_create_child_dict(software, "Valve")
        steam = _find_or_create_child_dict(valve, "Steam")
        compat = _find_or_create_child_dict(steam, "CompatToolMapping")

        compat[str_appid] = {
            "name": tool_name,
            "config": "",
            "priority": str(priority),
        }

        serialized = serialize_simple_vdf_text(data) + "\n"
        with open(temp_file, "w", encoding="utf-8") as f:
            f.write(serialized)
            f.flush()
            os.fsync(f.fileno())

        os.replace(temp_file, config_file)
        dt = time.perf_counter() - t0
        logger.info(
            f"{TAG} Set Proton compatibility for AppID {str_appid} -> {tool_name} "
            f"(priority {priority}) in {dt:.3f}s"
        )
        return True
    except Exception as e:
        logger.error(
            f"{TAG} Failed to set proton compatibility for AppID {str_appid}: {e}",
            exc_info=True,
        )
        if os.path.exists(temp_file):
            try:
                os.remove(temp_file)
            except OSError:
                pass
        return False


def remove_proton_compatibility(steam_path: str, uint_appid: int | str) -> bool:
    """Remove Proton compatibility mapping for given AppID."""
    t0 = time.perf_counter()
    str_appid = _normalize_appid(uint_appid)
    config_file = os.path.join(steam_path, "config", "config.vdf")
    if not os.path.isfile(config_file):
        return True

    temp_file = f"{config_file}.tmp"
    try:
        with open(config_file, "r", encoding="utf-8", errors="replace") as f:
            data = parse_simple_vdf_text(f.read())

        store = _find_child_dict(data, "InstallConfigStore")
        if not store:
            return True
        software = _find_child_dict(store, "Software")
        if not software:
            return True
        valve = _find_child_dict(software, "Valve")
        if not valve:
            return True
        steam = _find_child_dict(valve, "Steam")
        if not steam:
            return True
        compat = _find_child_dict(steam, "CompatToolMapping")
        if not compat or str_appid not in compat:
            return True

        backup_config_vdf(config_file)
        del compat[str_appid]

        serialized = serialize_simple_vdf_text(data) + "\n"
        with open(temp_file, "w", encoding="utf-8") as f:
            f.write(serialized)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_file, config_file)

        dt = time.perf_counter() - t0
        logger.info(f"{TAG} Removed Proton compatibility mapping for AppID {str_appid} in {dt:.3f}s")
        return True
    except Exception as e:
        logger.error(f"{TAG} Failed to remove proton compatibility for AppID {str_appid}: {e}", exc_info=True)
        if os.path.exists(temp_file):
            try:
                os.remove(temp_file)
            except OSError:
                pass
        return False
