"""
Cryptographic identity, mutual TLS 1.3 channel-bound authentication, SAS verification codes,
Room PIN proofs, rate limiting, path sanitization, and LAN/VPN IP boundary guards for BobDrop.
"""

from __future__ import annotations

import ctypes
import datetime
import hashlib
import hmac
import ipaddress
import json
import logging
import os
import re
import secrets
import socket
import ssl
import struct
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Iterable

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

from app.core import secret_mask

logger = logging.getLogger(__name__)
TAG = "[BobDrop/Security]"

HANDSHAKE_CONTEXT = b"BOBDROP-V1-HANDSHAKE|"
SAS_CONTEXT = b"BOBDROP-V1-SAS|"
PIN_CONTEXT = b"BOBDROP-V1-PIN|"
PIN_PBKDF2_ITERATIONS = 100_000

# Non-public IANA blocks safe across L3 VPNs (RFC 1918 + RFC 6598 Tailscale/CGNAT + RFC 2544 VPN)
_ALWAYS_ALLOWED_NETS = (
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("100.64.0.0/10"),
    ipaddress.ip_network("198.18.0.0/15"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
    ipaddress.ip_network("::1/128"),
)

_RADMIN_NET = ipaddress.ip_network("26.0.0.0/8")
_HAMACHI_NET = ipaddress.ip_network("25.0.0.0/8")

_WINDOWS_RESERVED_NAMES = frozenset({
    "con", "prn", "aux", "nul",
    *(f"com{i}" for i in range(1, 10)),
    *(f"lpt{i}" for i in range(1, 10)),
})
_INVALID_PATH_CHARS_RE = re.compile(r'[\x00-\x1f<>:"|?*]')


class SecurityError(Exception):
    """Raised when any BobDrop trust, network boundary, or cryptographic check fails."""


@dataclass(frozen=True)
class LocalInterface:
    ip: str
    netmask: str
    network: ipaddress.IPv4Network
    broadcast: str | None


@dataclass(frozen=True)
class DropIdentity:
    device_id: str
    private_key: ec.EllipticCurvePrivateKey
    certificate: x509.Certificate
    key_pem: str
    cert_pem: str
    fingerprint: str

    @property
    def short_fingerprint(self) -> str:
        up = self.fingerprint.upper()
        return f"{up[:4]}-{up[4:8]}"


def normalize_ip(raw_ip: str) -> str:
    """Strip IPv6 zone index and unwrap IPv4-mapped IPv6 addresses."""
    s = (raw_ip or "").strip()
    if "%" in s:
        s = s.split("%", 1)[0]
    try:
        addr = ipaddress.ip_address(s)
    except ValueError as exc:
        raise SecurityError(f"Địa chỉ IP không hợp lệ: {raw_ip!r}") from exc
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped is not None:
        return str(addr.ipv4_mapped)
    return str(addr)


def enumerate_local_ipv4_interfaces() -> list[LocalInterface]:
    """Return active non-loopback IPv4 interfaces and their subnets (LAN, ZeroTier, Radmin, VPN)."""
    interfaces: list[LocalInterface] = []
    seen_ips: set[str] = set()

    if sys.platform == "win32":
        try:
            iphlpapi = ctypes.windll.iphlpapi

            class _MIB_IPADDRROW(ctypes.Structure):
                _fields_ = [
                    ("dwAddr", ctypes.c_uint32),
                    ("dwIndex", ctypes.c_uint32),
                    ("dwMask", ctypes.c_uint32),
                    ("dwBCastAddr", ctypes.c_uint32),
                    ("dwReasmSize", ctypes.c_uint32),
                    ("unused1", ctypes.c_uint16),
                    ("wType", ctypes.c_uint16),
                ]

            size = ctypes.c_ulong(0)
            iphlpapi.GetIpAddrTable(None, ctypes.byref(size), False)
            if size.value > 0:
                buf = ctypes.create_string_buffer(size.value)
                rc = iphlpapi.GetIpAddrTable(buf, ctypes.byref(size), False)
                if rc == 0:
                    num_entries = struct.unpack_from("<I", buf.raw, 0)[0]
                    row_size = ctypes.sizeof(_MIB_IPADDRROW)
                    offset = 4
                    for _ in range(num_entries):
                        if offset + row_size > len(buf.raw):
                            break
                        row = _MIB_IPADDRROW.from_buffer_copy(buf.raw, offset)
                        offset += row_size
                        # Skip disconnected (0x08) or deleted (0x40) rows
                        if row.wType & 0x0048:
                            continue
                        ip_str = socket.inet_ntoa(struct.pack("<I", row.dwAddr))
                        mask_str = socket.inet_ntoa(struct.pack("<I", row.dwMask))
                        addr = ipaddress.IPv4Address(ip_str)
                        if addr.is_loopback or addr.is_unspecified or ip_str in seen_ips:
                            continue
                        try:
                            iface = ipaddress.IPv4Interface(f"{ip_str}/{mask_str}")
                        except ValueError:
                            iface = ipaddress.IPv4Interface(f"{ip_str}/24")
                        net = iface.network
                        bcast = str(net.broadcast_address) if net.prefixlen <= 30 else None
                        seen_ips.add(ip_str)
                        interfaces.append(LocalInterface(ip=ip_str, netmask=str(net.netmask), network=net, broadcast=bcast))
        except Exception as exc:
            logger.warning(f"{TAG} Win32 adapter enumeration fallback triggered: {exc}")
    elif sys.platform.startswith("linux"):
        try:
            proc = subprocess.run(
                ["ip", "-j", "-4", "addr", "show", "up"],
                capture_output=True,
                text=True,
                timeout=2.0,
                check=False,
            )
            if proc.returncode == 0 and proc.stdout.strip():
                for entry in json.loads(proc.stdout):
                    for info in entry.get("addr_info") or ():
                        ip_str = str(info.get("local") or "").strip()
                        if not ip_str or ip_str in seen_ips:
                            continue
                        addr = ipaddress.IPv4Address(ip_str)
                        if addr.is_loopback or addr.is_unspecified:
                            continue
                        prefix = int(info.get("prefixlen") or 24)
                        iface = ipaddress.IPv4Interface(f"{ip_str}/{prefix}")
                        net = iface.network
                        bcast = info.get("broadcast") or (str(net.broadcast_address) if net.prefixlen <= 30 else None)
                        seen_ips.add(ip_str)
                        interfaces.append(LocalInterface(ip=ip_str, netmask=str(net.netmask), network=net, broadcast=bcast))
        except Exception as exc:
            logger.warning(f"{TAG} Linux adapter enumeration fallback triggered: {exc}")

    if not interfaces:
        try:
            for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
                ip_str = str(info[4][0])
                addr = ipaddress.IPv4Address(ip_str)
                if addr.is_loopback or addr.is_unspecified or ip_str in seen_ips:
                    continue
                iface = ipaddress.IPv4Interface(f"{ip_str}/24")
                seen_ips.add(ip_str)
                interfaces.append(
                    LocalInterface(
                        ip=ip_str,
                        netmask="255.255.255.0",
                        network=iface.network,
                        broadcast=str(iface.network.broadcast_address),
                    )
                )
        except Exception as exc:
            logger.debug(f"{TAG} Fallback hostname IP lookup failed: {exc}")

    return interfaces


def is_allowed_peer_ip(raw_ip: str, local_networks: Iterable[ipaddress._BaseNetwork] | None = None) -> bool:
    """Strictly allow only private LAN, link-local, loopback, CGNAT/VPN, or locally attached VPN subnets."""
    try:
        clean = normalize_ip(raw_ip)
        addr = ipaddress.ip_address(clean)
    except (SecurityError, ValueError):
        return False

    if addr.is_unspecified or addr.is_multicast:
        return False

    if any(addr in net for net in _ALWAYS_ALLOWED_NETS):
        return True

    nets = list(local_networks) if local_networks is not None else [i.network for i in enumerate_local_ipv4_interfaces()]
    for net in nets:
        # Ignore 0.0.0.0/0 default route if a misconfigured adapter ever reports mask 0.0.0.0
        if net.prefixlen >= 8 and addr in net:
            return True
    return False


def classify_network_kind(raw_ip: str) -> str:
    """Return a concise Vietnamese/technical network badge for a peer IP."""
    try:
        addr = ipaddress.ip_address(normalize_ip(raw_ip))
    except (SecurityError, ValueError):
        return "LAN"
    if addr.is_loopback:
        return "Local"
    if isinstance(addr, ipaddress.IPv4Address):
        if addr in _RADMIN_NET:
            return "Radmin VPN"
        if addr in _HAMACHI_NET:
            return "Hamachi VPN"
        if addr in ipaddress.ip_network("100.64.0.0/10") or addr in ipaddress.ip_network("198.18.0.0/15"):
            return "VPN"
        if addr in ipaddress.ip_network("10.147.0.0/16") or addr in ipaddress.ip_network("10.241.0.0/15"):
            return "ZeroTier"
    return "LAN / VPN"


def cert_fingerprint_sha256(cert_der: bytes) -> str:
    return hashlib.sha256(cert_der).hexdigest()


def generate_identity(device_id: str | None = None) -> DropIdentity:
    """Generate a fresh ECDSA P-256 keypair and self-signed X.509 certificate."""
    t0 = time.monotonic()
    dev_id = device_id or str(uuid.uuid4())
    private_key = ec.generate_private_key(ec.SECP256R1())
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Bob Gaming Game Center"),
        x509.NameAttribute(NameOID.COMMON_NAME, f"bobdrop-{dev_id}"),
    ])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=3650))
        .sign(private_key, hashes.SHA256())
    )
    key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("ascii")
    cert_pem = cert.public_bytes(serialization.Encoding.PEM).decode("ascii")
    fp = cert_fingerprint_sha256(cert.public_bytes(serialization.Encoding.DER))
    logger.info(f"{TAG} Generated new ECDSA P-256 identity ({fp[:8]}) in {time.monotonic() - t0:.3f}s")
    return DropIdentity(
        device_id=dev_id,
        private_key=private_key,
        certificate=cert,
        key_pem=key_pem,
        cert_pem=cert_pem,
        fingerprint=fp,
    )


def load_or_create_identity(config: dict) -> tuple[DropIdentity, bool]:
    """Load persistent BobDrop identity from config dict, or create one. Returns (identity, mutated)."""
    dev_id = str(config.get("lan_drop_device_id") or "").strip()
    enc_key = str(config.get("lan_drop_key_pem") or "").strip()
    cert_pem = str(config.get("lan_drop_cert_pem") or "").strip()

    if dev_id and enc_key and cert_pem:
        try:
            key_pem = secret_mask.decrypt(enc_key)
            if key_pem:
                priv = serialization.load_pem_private_key(key_pem.encode("ascii"), password=None)
                cert = x509.load_pem_x509_certificate(cert_pem.encode("ascii"))
                if isinstance(priv, ec.EllipticCurvePrivateKey):
                    fp = cert_fingerprint_sha256(cert.public_bytes(serialization.Encoding.DER))
                    return DropIdentity(
                        device_id=dev_id,
                        private_key=priv,
                        certificate=cert,
                        key_pem=key_pem,
                        cert_pem=cert_pem,
                        fingerprint=fp,
                    ), False
        except Exception as exc:
            logger.warning(f"{TAG} Stored identity corrupted ({exc}); regenerating")

    ident = generate_identity(dev_id or None)
    config["lan_drop_device_id"] = ident.device_id
    config["lan_drop_key_pem"] = secret_mask.encrypt(ident.key_pem)
    config["lan_drop_cert_pem"] = ident.cert_pem
    return ident, True


def _load_pem_into_ssl_context(ctx: ssl.SSLContext, cert_pem: str, key_pem: str) -> None:
    """Load in-memory PEM credentials into OpenSSL context and scrub temporary file immediately."""
    tmp_path = ""
    try:
        fd, tmp_path = tempfile.mkstemp(prefix="bobdrop_", suffix=".pem")
        payload = (cert_pem.rstrip() + "\n" + key_pem.rstrip() + "\n").encode("ascii")
        try:
            os.write(fd, payload)
        finally:
            os.close(fd)
        ctx.load_cert_chain(certfile=tmp_path)
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                with open(tmp_path, "r+b") as f:
                    length = f.seek(0, os.SEEK_END)
                    f.seek(0)
                    f.write(b"\x00" * length)
                    f.flush()
            except OSError:
                pass
            try:
                os.remove(tmp_path)
            except OSError:
                pass


def create_server_ssl_context(identity: DropIdentity) -> ssl.SSLContext:
    """Create a strict TLS 1.3 server SSLContext."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    ctx.options |= ssl.OP_NO_COMPRESSION
    _load_pem_into_ssl_context(ctx, identity.cert_pem, identity.key_pem)
    return ctx


def create_client_ssl_context(identity: DropIdentity) -> ssl.SSLContext:
    """Create a strict TLS 1.3 client SSLContext (peer certificate verified via transcript binding)."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ctx.options |= ssl.OP_NO_COMPRESSION
    _load_pem_into_ssl_context(ctx, identity.cert_pem, identity.key_pem)
    return ctx


def sign_client_handshake(
    identity: DropIdentity,
    server_fp_hex: str,
    server_nonce_hex: str,
    client_nonce_hex: str,
) -> str:
    """Sign the TLS server certificate fingerprint + nonces so an active MITM cannot relay the handshake."""
    msg = (
        HANDSHAKE_CONTEXT
        + bytes.fromhex(server_fp_hex)
        + bytes.fromhex(server_nonce_hex)
        + bytes.fromhex(client_nonce_hex)
    )
    sig = identity.private_key.sign(msg, ec.ECDSA(hashes.SHA256()))
    return sig.hex()


def verify_client_handshake(
    client_cert_pem: str,
    signature_hex: str,
    server_fp_hex: str,
    server_nonce_hex: str,
    client_nonce_hex: str,
) -> str:
    """Verify client's X.509 cert and ECDSA transcript signature. Returns client's SHA-256 fingerprint."""
    try:
        cert = x509.load_pem_x509_certificate(client_cert_pem.encode("ascii"))
        pub = cert.public_key()
        if not isinstance(pub, ec.EllipticCurvePublicKey):
            raise SecurityError("Khoá công khai của thiết bị gửi không phải chuẩn ECDSA.")
        msg = (
            HANDSHAKE_CONTEXT
            + bytes.fromhex(server_fp_hex)
            + bytes.fromhex(server_nonce_hex)
            + bytes.fromhex(client_nonce_hex)
        )
        pub.verify(bytes.fromhex(signature_hex), msg, ec.ECDSA(hashes.SHA256()))
        return cert_fingerprint_sha256(cert.public_bytes(serialization.Encoding.DER))
    except SecurityError:
        raise
    except (ValueError, InvalidSignature) as exc:
        raise SecurityError("Chữ ký xác thực thiết bị không hợp lệ (nghi ngờ giả mạo / MITM).") from exc
    except Exception as exc:
        raise SecurityError(f"Không xác thực được chứng chỉ thiết bị: {exc}") from exc


def compute_sas_code(
    client_fp_hex: str,
    server_fp_hex: str,
    server_nonce_hex: str,
    client_nonce_hex: str,
) -> str:
    """Compute a deterministic 6-digit Short Authentication String ('123 456') bound to both certs + nonces."""
    digest = hashlib.sha256(
        SAS_CONTEXT
        + bytes.fromhex(client_fp_hex)
        + bytes.fromhex(server_fp_hex)
        + bytes.fromhex(server_nonce_hex)
        + bytes.fromhex(client_nonce_hex)
    ).digest()
    code = int.from_bytes(digest[:4], "big") % 1_000_000
    s = f"{code:06d}"
    return f"{s[:3]} {s[3:]}"


def compute_pin_proof(
    pin: str,
    client_fp_hex: str,
    server_fp_hex: str,
    server_nonce_hex: str,
    client_nonce_hex: str,
) -> str:
    """Derive a non-replayable PBKDF2-HMAC-SHA256 proof of knowledge of the Room PIN without transmitting the PIN."""
    clean_pin = (pin or "").strip()
    if not clean_pin:
        return ""
    salt = PIN_CONTEXT + bytes.fromhex(server_nonce_hex) + bytes.fromhex(client_nonce_hex)
    derived = hashlib.pbkdf2_hmac("sha256", clean_pin.encode("utf-8"), salt, PIN_PBKDF2_ITERATIONS)
    bound = bytes.fromhex(client_fp_hex) + bytes.fromhex(server_fp_hex)
    return hmac.new(derived, bound, hashlib.sha256).hexdigest()


def verify_pin_proof(
    expected_pin: str,
    provided_proof_hex: str,
    client_fp_hex: str,
    server_fp_hex: str,
    server_nonce_hex: str,
    client_nonce_hex: str,
) -> bool:
    expected = compute_pin_proof(expected_pin, client_fp_hex, server_fp_hex, server_nonce_hex, client_nonce_hex)
    if not expected or not provided_proof_hex:
        return False
    return hmac.compare_digest(expected, provided_proof_hex)


def sanitize_rel_path(raw_rel_path: str) -> str:
    """Validate and normalize a relative file path inside a transfer offer, rejecting any traversal or OS trap."""
    if not raw_rel_path or not isinstance(raw_rel_path, str):
        raise SecurityError("Tên tệp trống hoặc không hợp lệ.")
    if raw_rel_path.startswith(("/", "\\")):
        raise SecurityError(f"Đường dẫn tuyệt đối hoặc UNC bị cấm: {raw_rel_path!r}")
    normalized = raw_rel_path.replace("\\", "/").strip("/")
    if not normalized:
        raise SecurityError(f"Đường dẫn không hợp lệ: {raw_rel_path!r}")

    parts = normalized.split("/")
    if len(parts) > 32:
        raise SecurityError("Đường dẫn thư mục lồng quá sâu.")

    clean_parts: list[str] = []
    for seg in parts:
        if not seg or seg in (".", ".."):
            raise SecurityError(f"Phát hiện đường dẫn thoát thư mục (path traversal): {raw_rel_path!r}")
        if _INVALID_PATH_CHARS_RE.search(seg):
            raise SecurityError(f"Tên tệp chứa ký tự bị cấm: {seg!r}")
        trimmed = seg.rstrip(". ")
        if not trimmed or trimmed != seg:
            raise SecurityError(f"Tên tệp kết thúc bằng dấu chấm hoặc khoảng trắng không an toàn: {seg!r}")
        stem = trimmed.split(".", 1)[0].lower()
        if stem in _WINDOWS_RESERVED_NAMES:
            raise SecurityError(f"Tên tệp trùng thiết bị hệ thống Windows bị cấm: {seg!r}")
        if len(trimmed) > 200:
            raise SecurityError("Tên tệp vượt quá độ dài an toàn.")
        clean_parts.append(trimmed)

    return "/".join(clean_parts)


def resolve_safe_destination(
    dest_root: str,
    sanitized_rel_path: str,
    batch_root_remap: dict[str, str] | None = None,
) -> str:
    """Resolve a safe, non-overwriting destination file path strictly inside dest_root."""
    clean_rel = sanitize_rel_path(sanitized_rel_path)
    abs_root = os.path.abspath(dest_root)
    os.makedirs(abs_root, exist_ok=True)

    parts = clean_rel.split("/")
    if len(parts) > 1:
        top_dir = parts[0]
        remap = batch_root_remap if batch_root_remap is not None else {}
        if top_dir not in remap:
            candidate_dir = top_dir
            idx = 1
            while os.path.exists(os.path.join(abs_root, candidate_dir)):
                candidate_dir = f"{top_dir} ({idx})"
                idx += 1
            remap[top_dir] = candidate_dir
        parts[0] = remap[top_dir]
        target = os.path.abspath(os.path.join(abs_root, *parts))
    else:
        filename = parts[0]
        base, ext = os.path.splitext(filename)
        candidate = filename
        idx = 1
        while os.path.exists(os.path.join(abs_root, candidate)) or os.path.exists(
            os.path.join(abs_root, candidate + ".bobpart")
        ):
            candidate = f"{base} ({idx}){ext}"
            idx += 1
        target = os.path.abspath(os.path.join(abs_root, candidate))

    try:
        common = os.path.commonpath([abs_root, target])
    except ValueError as exc:
        raise SecurityError("Đường dẫn đích nằm khác ổ đĩa lưu trữ.") from exc
    if os.path.normcase(common) != os.path.normcase(abs_root) or os.path.normcase(target) == os.path.normcase(abs_root):
        raise SecurityError("Đường dẫn đích vượt ngoài thư mục nhận an toàn.")
    return target


class RateLimiter:
    """Sliding-window per-IP limiter for offer floods and failed Room PIN attempts."""

    def __init__(self, max_events: int = 8, window_sec: float = 60.0, cooldown_sec: float = 120.0):
        self._max_events = max_events
        self._window_sec = window_sec
        self._cooldown_sec = cooldown_sec
        self._events: dict[str, list[float]] = {}
        self._blocked_until: dict[str, float] = {}
        self._lock = threading.Lock()

    def is_blocked(self, ip: str, now: float | None = None) -> bool:
        ts = time.monotonic() if now is None else now
        with self._lock:
            until = self._blocked_until.get(ip, 0.0)
            if until > ts:
                return True
            if until:
                self._blocked_until.pop(ip, None)
            return False

    def record_and_allow(self, ip: str, now: float | None = None) -> bool:
        ts = time.monotonic() if now is None else now
        with self._lock:
            if self._blocked_until.get(ip, 0.0) > ts:
                return False
            cutoff = ts - self._window_sec
            bucket = [t for t in self._events.get(ip, []) if t >= cutoff]
            bucket.append(ts)
            self._events[ip] = bucket
            if len(bucket) > self._max_events:
                self._blocked_until[ip] = ts + self._cooldown_sec
                self._events.pop(ip, None)
                return False
            return True

    def generate_nonce(self) -> str:
        return secrets.token_hex(32)
