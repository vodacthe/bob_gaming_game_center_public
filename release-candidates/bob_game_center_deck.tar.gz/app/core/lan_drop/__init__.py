"""BobDrop — Encrypted peer-to-peer file and folder sharing over LAN, ZeroTier, and VPN."""
