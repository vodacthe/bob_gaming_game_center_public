"""
Multi-interface LAN, ZeroTier, Radmin VPN, and L3 VPN peer discovery for BobDrop.
Combines per-interface directed UDP subnet broadcasts, unicast VPN probes, and mDNS (Zeroconf).
"""

from __future__ import annotations

import ipaddress
import json
import logging
import socket
import threading
import time
from dataclasses import dataclass
from typing import Callable

from zeroconf import InterfaceChoice, ServiceBrowser, ServiceInfo, ServiceListener, Zeroconf

from app.core.lan_drop.security import (
    classify_network_kind,
    enumerate_local_ipv4_interfaces,
    is_allowed_peer_ip,
    normalize_ip,
)

logger = logging.getLogger(__name__)
TAG = "[BobDrop/Discovery]"

DEFAULT_DISCOVERY_UDP_PORT = 53318
DEFAULT_TRANSFER_TCP_PORT = 53319
MDNS_SERVICE_TYPE = "_bobdrop._tcp.local."
BEACON_INTERVAL_SEC = 3.0
PEER_TTL_SEC = 12.0


@dataclass
class PeerInfo:
    device_id: str
    device_name: str
    ip: str
    port: int
    fingerprint: str
    mode: str = "everyone"        # "everyone" | "trusted"
    pin_required: bool = False
    net_kind: str = "LAN / VPN"
    is_manual: bool = False
    last_seen: float = 0.0

    @property
    def short_fingerprint(self) -> str:
        up = (self.fingerprint or "").upper()
        return f"{up[:4]}-{up[4:8]}" if len(up) >= 8 else up


class _MdnsPeerListener(ServiceListener):
    def __init__(self, on_change: Callable[[Zeroconf, str, str, bool], None]):
        self._on_change = on_change

    def add_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        self._on_change(zc, type_, name, False)

    def update_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        self._on_change(zc, type_, name, False)

    def remove_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        self._on_change(zc, type_, name, True)


class LanDropDiscovery:
    """Background peer presence & discovery engine across LAN, ZeroTier, and VPN adapters."""

    def __init__(
        self,
        device_id: str,
        fingerprint: str,
        get_state: Callable[[], tuple[str, str, int, bool, list[str]]],
        on_peers_changed: Callable[[list[PeerInfo]], None],
        udp_port: int = DEFAULT_DISCOVERY_UDP_PORT,
        enable_mdns: bool = True,
    ):
        """
        get_state() returns: (device_name, mode, tcp_port, pin_required, manual_peers)
        """
        self._device_id = device_id
        self._fingerprint = fingerprint
        self._get_state = get_state
        self._on_peers_changed = on_peers_changed
        self._udp_port = udp_port
        self._enable_mdns = enable_mdns

        self._lock = threading.Lock()
        self._running = False
        self._stop_event = threading.Event()
        self._rx_sock: socket.socket | None = None
        self._rx_thread: threading.Thread | None = None
        self._beacon_thread: threading.Thread | None = None
        self._peers: dict[str, PeerInfo] = {}
        self._warned_ips: set[str] = set()

        self._zeroconf: Zeroconf | None = None
        self._mdns_browser: ServiceBrowser | None = None
        self._mdns_info: ServiceInfo | None = None
        self._mdns_registered_sig: tuple | None = None

    @property
    def udp_port(self) -> int:
        return self._udp_port

    def start(self) -> None:
        with self._lock:
            if self._running:
                return
            self._running = True
            self._stop_event.clear()

        t0 = time.monotonic()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        except OSError:
            pass
        try:
            sock.bind(("0.0.0.0", self._udp_port))
            self._udp_port = sock.getsockname()[1]
        except OSError as exc:
            logger.warning(f"{TAG} UDP port {self._udp_port} busy ({exc}); binding ephemeral port")
            sock.bind(("0.0.0.0", 0))
            self._udp_port = sock.getsockname()[1]
        sock.settimeout(0.5)
        self._rx_sock = sock

        self._rx_thread = threading.Thread(target=self._rx_loop, name="BobDrop-UDP-Rx", daemon=True)
        self._beacon_thread = threading.Thread(target=self._beacon_loop, name="BobDrop-Beacon", daemon=True)
        self._rx_thread.start()
        self._beacon_thread.start()

        if self._enable_mdns:
            threading.Thread(target=self._init_mdns, name="BobDrop-mDNS-Init", daemon=True).start()

        logger.info(f"{TAG} Started LAN/VPN discovery on UDP :{self._udp_port} in {time.monotonic() - t0:.3f}s")
        self.trigger_refresh()

    def stop(self) -> None:
        with self._lock:
            if not self._running:
                return
            self._running = False
            self._stop_event.set()

        # Broadcast polite goodbye so peers remove us immediately
        try:
            self._broadcast_packet({"v": 1, "t": "bye", "id": self._device_id})
        except Exception:
            pass

        sock = self._rx_sock
        self._rx_sock = None
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass

        for t in (self._rx_thread, self._beacon_thread):
            if t is not None and t.is_alive():
                t.join(timeout=1.5)

        self._teardown_mdns()
        logger.info(f"{TAG} Discovery stopped")

    def get_peers(self) -> list[PeerInfo]:
        with self._lock:
            return sorted(self._peers.values(), key=lambda p: (p.device_name.lower(), p.ip))

    def _is_in_local_subnet(self, ip_str: str, local_nets: list[ipaddress.IPv4Network] | None = None) -> bool:
        try:
            addr = ipaddress.ip_address(normalize_ip(ip_str))
            if not isinstance(addr, ipaddress.IPv4Address):
                return False
            nets = local_nets if local_nets is not None else [i.network for i in enumerate_local_ipv4_interfaces()]
            return any(addr in n for n in nets)
        except Exception:
            return False

    def upsert_probed_peer(self, peer: PeerInfo) -> None:
        changed = False
        local_nets: list[ipaddress.IPv4Network] | None = None
        with self._lock:
            if peer.device_id == self._device_id:
                return
            peer.last_seen = time.monotonic()
            prev = self._peers.get(peer.device_id)
            if prev is not None and prev.ip != peer.ip:
                local_nets = [i.network for i in enumerate_local_ipv4_interfaces()]
                if self._is_in_local_subnet(prev.ip, local_nets) and not self._is_in_local_subnet(peer.ip, local_nets):
                    peer.ip = prev.ip
                    peer.net_kind = prev.net_kind
            if prev is None or (prev.ip, prev.port, prev.device_name, prev.mode, prev.pin_required) != (
                peer.ip, peer.port, peer.device_name, peer.mode, peer.pin_required
            ):
                changed = True
                if prev is None:
                    logger.info(f"{TAG} Discovered peer {peer.device_name!r} at {peer.ip}:{peer.port} [{peer.net_kind}]")
            self._peers[peer.device_id] = peer
        if changed:
            self._emit_peers()

    def trigger_refresh(self) -> None:
        """Actively solicit immediate announce replies from all LAN & manual VPN peers."""
        if not self._running:
            return
        threading.Thread(target=self._send_refresh_burst, name="BobDrop-Refresh", daemon=True).start()

    def notify_state_changed(self) -> None:
        """Called when visibility mode, device name, or Room PIN changes."""
        if not self._running:
            return
        threading.Thread(target=self._sync_presence_now, name="BobDrop-StateSync", daemon=True).start()

    def _sync_presence_now(self) -> None:
        try:
            name, mode, tcp_port, pin_req, manual_peers = self._get_state()
            if mode == "off" or tcp_port <= 0:
                self._broadcast_packet({"v": 1, "t": "bye", "id": self._device_id}, manual_peers)
            else:
                self._broadcast_packet(self._build_announce(name, mode, tcp_port, pin_req), manual_peers)
            if self._enable_mdns:
                self._sync_mdns_registration(name, mode, tcp_port, pin_req)
        except Exception as exc:
            logger.debug(f"{TAG} Presence state sync warning: {exc}")

    def _send_refresh_burst(self) -> None:
        try:
            name, mode, tcp_port, pin_req, manual_peers = self._get_state()
            self._broadcast_packet({"v": 1, "t": "discover", "id": self._device_id}, manual_peers)
            if mode != "off" and tcp_port > 0:
                self._broadcast_packet(self._build_announce(name, mode, tcp_port, pin_req), manual_peers)
        except Exception as exc:
            logger.debug(f"{TAG} Refresh burst warning: {exc}")

    def _build_announce(self, name: str, mode: str, tcp_port: int, pin_req: bool) -> dict:
        return {
            "v": 1,
            "t": "announce",
            "id": self._device_id,
            "name": (name or socket.gethostname())[:64],
            "port": int(tcp_port),
            "fp": self._fingerprint,
            "mode": mode,
            "pin": bool(pin_req),
        }

    def _broadcast_packet(self, payload: dict, manual_peers: list[str] | None = None) -> None:
        raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        interfaces = enumerate_local_ipv4_interfaces()

        # Transmit out every active LAN / ZeroTier / Radmin adapter explicitly
        for iface in interfaces:
            targets = {"255.255.255.255"}
            if iface.broadcast:
                targets.add(iface.broadcast)
            tx = None
            try:
                tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                tx.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                tx.bind((iface.ip, 0))
                for dst in targets:
                    try:
                        tx.sendto(raw, (dst, self._udp_port))
                    except OSError:
                        pass
            except OSError:
                pass
            finally:
                if tx is not None:
                    try:
                        tx.close()
                    except OSError:
                        pass

        # Fallback loopback / default interface broadcast when no non-loopback NIC is active (e.g. isolated tests)
        if not interfaces and self._rx_sock is not None:
            try:
                self._rx_sock.sendto(raw, ("127.0.0.1", self._udp_port))
            except OSError:
                pass

        # Unicast directly to configured VPN / Tailscale / WireGuard manual IPs
        for entry in manual_peers or []:
            ip_part, _, port_part = entry.strip().partition(":")
            if not ip_part:
                continue
            try:
                clean_ip = normalize_ip(ip_part)
                if not is_allowed_peer_ip(clean_ip):
                    continue
                target_udp = int(port_part) if port_part.isdigit() else self._udp_port
                if self._rx_sock is not None:
                    self._rx_sock.sendto(raw, (clean_ip, target_udp))
            except Exception:
                pass

    def _beacon_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                name, mode, tcp_port, pin_req, manual_peers = self._get_state()
                if mode != "off" and tcp_port > 0:
                    self._broadcast_packet(self._build_announce(name, mode, tcp_port, pin_req), manual_peers)
                if self._enable_mdns:
                    self._sync_mdns_registration(name, mode, tcp_port, pin_req)
                self._prune_expired_peers()
            except Exception as exc:
                logger.error(f"{TAG} Unexpected error in beacon loop: {exc}", exc_info=True)
            self._stop_event.wait(BEACON_INTERVAL_SEC)

    def _rx_loop(self) -> None:
        while not self._stop_event.is_set():
            sock = self._rx_sock
            if sock is None:
                break
            try:
                data, addr = sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                self._handle_datagram(data, addr[0], addr[1])
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                logger.debug(f"{TAG} Malformed UDP discovery packet ignored: {exc}")
            except Exception as exc:
                logger.warning(f"{TAG} Error processing discovery datagram from {addr[0]}: {exc}")

    def _handle_datagram(self, data: bytes, raw_src_ip: str, src_port: int) -> None:
        src_ip = normalize_ip(raw_src_ip)
        if not is_allowed_peer_ip(src_ip):
            if src_ip not in self._warned_ips:
                self._warned_ips.add(src_ip)
                logger.warning(f"{TAG} Ignored discovery packet from non-LAN/VPN IP {src_ip}")
            return

        msg = json.loads(data.decode("utf-8"))
        if not isinstance(msg, dict) or msg.get("v") != 1:
            return
        peer_id = str(msg.get("id") or "").strip()
        if not peer_id or peer_id == self._device_id:
            return

        pkt_type = msg.get("t")
        if pkt_type == "bye":
            removed = None
            with self._lock:
                removed = self._peers.pop(peer_id, None)
            if removed is not None:
                logger.info(f"{TAG} Peer {removed.device_name!r} ({removed.ip}) went offline")
                self._emit_peers()
            return

        if pkt_type == "discover":
            name, mode, tcp_port, pin_req, _ = self._get_state()
            if mode != "off" and tcp_port > 0 and self._rx_sock is not None:
                reply = json.dumps(self._build_announce(name, mode, tcp_port, pin_req), ensure_ascii=False).encode("utf-8")
                for port in {src_port, self._udp_port}:
                    try:
                        self._rx_sock.sendto(reply, (src_ip, port))
                    except OSError:
                        pass
            return

        if pkt_type == "announce":
            tcp_port = int(msg.get("port") or 0)
            fp = str(msg.get("fp") or "").strip().lower()
            mode = str(msg.get("mode") or "everyone")
            if tcp_port <= 0 or tcp_port > 65535 or len(fp) != 64 or mode == "off":
                return
            peer = PeerInfo(
                device_id=peer_id[:64],
                device_name=str(msg.get("name") or src_ip).strip()[:64] or src_ip,
                ip=src_ip,
                port=tcp_port,
                fingerprint=fp,
                mode="trusted" if mode == "trusted" else "everyone",
                pin_required=bool(msg.get("pin", False)),
                net_kind=classify_network_kind(src_ip),
                last_seen=time.monotonic(),
            )
            self.upsert_probed_peer(peer)

    def _prune_expired_peers(self) -> None:
        now = time.monotonic()
        expired: list[PeerInfo] = []
        with self._lock:
            for pid, peer in list(self._peers.items()):
                if now - peer.last_seen > PEER_TTL_SEC:
                    expired.append(self._peers.pop(pid))
        if expired:
            for p in expired:
                logger.info(f"{TAG} Peer {p.device_name!r} ({p.ip}) timed out")
            self._emit_peers()

    def _emit_peers(self) -> None:
        try:
            self._on_peers_changed(self.get_peers())
        except Exception:
            logger.exception(f"{TAG} on_peers_changed callback failed")

    # ---- Optional Secondary mDNS (Zeroconf) Channel ----

    def _init_mdns(self) -> None:
        try:
            if self._stop_event.is_set():
                return
            zc = Zeroconf(interfaces=InterfaceChoice.All)
            if self._stop_event.is_set():
                zc.close()
                return
            self._zeroconf = zc
            self._mdns_browser = ServiceBrowser(zc, MDNS_SERVICE_TYPE, _MdnsPeerListener(self._on_mdns_event))
            name, mode, tcp_port, pin_req, _ = self._get_state()
            self._sync_mdns_registration(name, mode, tcp_port, pin_req)
        except Exception as exc:
            logger.warning(f"{TAG} mDNS secondary channel unavailable ({exc}); UDP discovery remains active")

    def _sync_mdns_registration(self, name: str, mode: str, tcp_port: int, pin_req: bool) -> None:
        zc = self._zeroconf
        if zc is None:
            return
        if mode == "off" or tcp_port <= 0:
            if self._mdns_info is not None:
                try:
                    zc.unregister_service(self._mdns_info)
                except Exception:
                    pass
                self._mdns_info = None
                self._mdns_registered_sig = None
            return

        addrs = [socket.inet_aton(i.ip) for i in enumerate_local_ipv4_interfaces()]
        if not addrs:
            return
        sig = (name, mode, tcp_port, pin_req, tuple(addrs))
        if sig == self._mdns_registered_sig:
            return

        if self._mdns_info is not None:
            try:
                zc.unregister_service(self._mdns_info)
            except Exception:
                pass
            self._mdns_info = None

        props = {
            b"id": self._device_id.encode("utf-8"),
            b"name": (name or socket.gethostname())[:64].encode("utf-8"),
            b"fp": self._fingerprint.encode("ascii"),
            b"mode": mode.encode("ascii"),
            b"pin": b"1" if pin_req else b"0",
        }
        info = ServiceInfo(
            MDNS_SERVICE_TYPE,
            f"bobdrop-{self._device_id[:12]}.{MDNS_SERVICE_TYPE}",
            addresses=addrs,
            port=int(tcp_port),
            properties=props,
            server=f"bobdrop-{self._device_id[:12]}.local.",
        )
        try:
            zc.register_service(info)
            self._mdns_info = info
            self._mdns_registered_sig = sig
        except Exception as exc:
            logger.debug(f"{TAG} mDNS service register skipped: {exc}")

    def _on_mdns_event(self, zc: Zeroconf, type_: str, sname: str, removed: bool) -> None:
        if self._stop_event.is_set() or removed:
            return
        try:
            info = zc.get_service_info(type_, sname, timeout=1500)
            if not info or not info.addresses:
                return
            props = info.properties or {}
            peer_id = (props.get(b"id") or b"").decode("utf-8", errors="ignore").strip()
            if not peer_id or peer_id == self._device_id:
                return
            fp = (props.get(b"fp") or b"").decode("ascii", errors="ignore").strip().lower()
            mode = (props.get(b"mode") or b"everyone").decode("ascii", errors="ignore").strip()
            if len(fp) != 64 or mode == "off" or not info.port:
                return
            local_nets = [i.network for i in enumerate_local_ipv4_interfaces()]
            same_subnet_ips: list[str] = []
            fallback_ips: list[str] = []
            for raw_addr in info.addresses:
                if len(raw_addr) != 4:
                    continue
                ip = socket.inet_ntoa(raw_addr)
                if is_allowed_peer_ip(ip, local_nets):
                    if self._is_in_local_subnet(ip, local_nets):
                        same_subnet_ips.append(ip)
                    else:
                        fallback_ips.append(ip)
            chosen_ip = (same_subnet_ips or fallback_ips or [None])[0]
            if chosen_ip:
                dev_name = (props.get(b"name") or b"").decode("utf-8", errors="ignore").strip() or chosen_ip
                self.upsert_probed_peer(
                    PeerInfo(
                        device_id=peer_id,
                        device_name=dev_name[:64],
                        ip=chosen_ip,
                        port=int(info.port),
                        fingerprint=fp,
                        mode="trusted" if mode == "trusted" else "everyone",
                        pin_required=(props.get(b"pin") == b"1"),
                        net_kind=classify_network_kind(chosen_ip),
                        last_seen=time.monotonic(),
                    )
                )
        except Exception as exc:
            logger.debug(f"{TAG} mDNS resolve warning: {exc}")

    def _teardown_mdns(self) -> None:
        if self._mdns_browser is not None:
            try:
                self._mdns_browser.cancel()
            except Exception:
                pass
            self._mdns_browser = None
        zc = self._zeroconf
        self._zeroconf = None
        if zc is not None:
            if self._mdns_info is not None:
                try:
                    zc.unregister_service(self._mdns_info)
                except Exception:
                    pass
                self._mdns_info = None
            try:
                zc.close()
            except Exception:
                pass
