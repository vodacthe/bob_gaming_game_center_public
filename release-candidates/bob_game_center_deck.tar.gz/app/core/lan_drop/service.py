"""
BobDrop background P2P transfer service (TLS 1.3 listener, multi-peer sender, folder walker,
streaming SHA-256 verifier, TOFU peer store, and Qt Signal bridge).
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import shutil
import socket
import ssl
import struct
import subprocess
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable

from PySide6.QtCore import QObject, Signal

from app.config import CONFIG_DIR, save_config
from app.core import secret_mask
from app.core.lan_drop.discovery import (
    DEFAULT_DISCOVERY_UDP_PORT,
    DEFAULT_TRANSFER_TCP_PORT,
    LanDropDiscovery,
    PeerInfo,
)
from app.core.lan_drop.security import (
    DropIdentity,
    RateLimiter,
    SecurityError,
    cert_fingerprint_sha256,
    classify_network_kind,
    compute_pin_proof,
    compute_sas_code,
    create_client_ssl_context,
    create_server_ssl_context,
    is_allowed_peer_ip,
    load_or_create_identity,
    normalize_ip,
    resolve_safe_destination,
    sanitize_rel_path,
    sign_client_handshake,
    verify_client_handshake,
    verify_pin_proof,
)

logger = logging.getLogger(__name__)
TAG = "[BobDrop/Service]"

MAX_HEADER_BYTES = 16 * 1024 * 1024
MAX_FILES_PER_OFFER = 100_000
CHUNK_SIZE = 256 * 1024
DISK_SAFETY_MARGIN_BYTES = 64 * 1024 * 1024
HANDSHAKE_TIMEOUT_SEC = 12.0
DECISION_TIMEOUT_SEC = 60.0
IO_TIMEOUT_SEC = 30.0
MAX_CONCURRENT_INCOMING = 8
PROGRESS_EMIT_INTERVAL_SEC = 0.10

VALID_MODES = ("everyone", "trusted", "off")


def default_save_dir() -> str:
    return os.path.join(os.path.expanduser("~"), "Downloads", "BobDrop")


def is_forbidden_save_dir(path: str) -> bool:
    """Enforce project rule: never store received or temporary files inside CONFIG_DIR."""
    if not path:
        return True
    try:
        abs_target = os.path.abspath(path)
        abs_cfg = os.path.abspath(CONFIG_DIR)
        common = os.path.commonpath([abs_target, abs_cfg])
        return os.path.normcase(common) == os.path.normcase(abs_cfg)
    except ValueError:
        return False


def format_bytes(num_bytes: int | float) -> str:
    val = float(max(0, num_bytes))
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if val < 1024.0 or unit == "TB":
            return f"{int(val)} B" if unit == "B" else f"{val:.1f} {unit}"
        val /= 1024.0
    return f"{val:.1f} TB"


@dataclass
class PayloadEntry:
    abs_path: str
    rel_path: str
    size: int


@dataclass
class IncomingOffer:
    transfer_id: str
    sender_id: str
    sender_name: str
    sender_ip: str
    sender_fingerprint: str
    sas_code: str
    is_trusted: bool
    key_changed: bool
    broadcast: bool
    files: list[dict]          # [{"rel_path": str, "size": int}]
    total_size: int
    save_dir: str
    created_at: float = field(default_factory=time.time)

    @property
    def summary_text(self) -> str:
        count = len(self.files)
        first = self.files[0]["rel_path"] if self.files else "tệp"
        label = f'"{first}"' if count == 1 else f'"{first}" và {count - 1} tệp khác'
        return f"{label} ({format_bytes(self.total_size)})"


@dataclass
class TransferRecord:
    transfer_id: str
    direction: str             # "send" | "receive"
    peer_id: str
    peer_name: str
    peer_ip: str
    sas_code: str = ""
    file_count: int = 0
    total_bytes: int = 0
    transferred_bytes: int = 0
    speed_bps: float = 0.0
    status: str = "connecting"  # connecting | waiting | transferring | completed | declined | cancelled | failed
    message: str = ""
    save_dir: str = ""
    broadcast: bool = False
    started_at: float = field(default_factory=time.monotonic)

    def snapshot(self) -> "TransferRecord":
        return TransferRecord(
            transfer_id=self.transfer_id,
            direction=self.direction,
            peer_id=self.peer_id,
            peer_name=self.peer_name,
            peer_ip=self.peer_ip,
            sas_code=self.sas_code,
            file_count=self.file_count,
            total_bytes=self.total_bytes,
            transferred_bytes=self.transferred_bytes,
            speed_bps=self.speed_bps,
            status=self.status,
            message=self.message,
            save_dir=self.save_dir,
            broadcast=self.broadcast,
            started_at=self.started_at,
        )


def collect_payload_entries(paths: list[str]) -> list[PayloadEntry]:
    """Expand dropped files and directories into relative PayloadEntry items (skipping symlinks safely)."""
    entries: list[PayloadEntry] = []
    seen_rel: set[str] = set()
    seen_roots: set[str] = set()

    def _unique_rel(rel: str) -> str:
        clean = sanitize_rel_path(rel)
        if clean.lower() not in seen_rel:
            seen_rel.add(clean.lower())
            seen_roots.add(clean.split("/", 1)[0].lower())
            return clean
        parts = clean.split("/")
        base, ext = os.path.splitext(parts[0])
        idx = 1
        while True:
            cand_parts = [f"{base} ({idx}){ext}", *parts[1:]]
            cand = "/".join(cand_parts)
            if cand.lower() not in seen_rel:
                seen_rel.add(cand.lower())
                seen_roots.add(cand_parts[0].lower())
                return cand
            idx += 1

    for raw in paths:
        if not raw:
            continue
        p = os.path.abspath(raw)
        if os.path.islink(p) or not os.path.exists(p):
            continue
        if os.path.isfile(p):
            rel = _unique_rel(os.path.basename(p))
            entries.append(PayloadEntry(abs_path=p, rel_path=rel, size=os.path.getsize(p)))
        elif os.path.isdir(p):
            root_name = sanitize_rel_path(os.path.basename(p.rstrip("\\/")) or "Folder")
            # Ensure distinct top-level folder prefix if two folders share the same name
            top_prefix = root_name
            idx = 1
            while top_prefix.lower() in seen_roots:
                top_prefix = f"{root_name} ({idx})"
                idx += 1
            seen_roots.add(top_prefix.lower())
            for walk_root, dirnames, filenames in os.walk(p, followlinks=False):
                dirnames[:] = [d for d in dirnames if not os.path.islink(os.path.join(walk_root, d))]
                for fname in filenames:
                    full_f = os.path.join(walk_root, fname)
                    if os.path.islink(full_f) or not os.path.isfile(full_f):
                        continue
                    sub_rel = os.path.relpath(full_f, p).replace("\\", "/")
                    rel = _unique_rel(f"{top_prefix}/{sub_rel}")
                    entries.append(PayloadEntry(abs_path=full_f, rel_path=rel, size=os.path.getsize(full_f)))
                    if len(entries) > MAX_FILES_PER_OFFER:
                        raise ValueError(f"Vượt quá giới hạn {MAX_FILES_PER_OFFER} tệp trong một lần gửi.")

    return entries


# ---- Wire framing helpers over SSLSocket ----

def _recv_exact(sock: socket.socket, n: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < n:
        piece = sock.recv(n - len(chunks))
        if not piece:
            raise ConnectionError("Kết nối mạng bị ngắt đột ngột.")
        chunks.extend(piece)
    return bytes(chunks)


def _send_json(sock: socket.socket, payload: dict) -> None:
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    if len(raw) > MAX_HEADER_BYTES:
        raise ValueError("Khung điều khiển vượt quá kích thước cho phép.")
    sock.sendall(struct.pack(">I", len(raw)) + raw)


def _recv_json(sock: socket.socket) -> dict:
    (length,) = struct.unpack(">I", _recv_exact(sock, 4))
    if length <= 0 or length > MAX_HEADER_BYTES:
        raise SecurityError(f"Kích thước khung điều khiển không hợp lệ ({length} bytes).")
    data = json.loads(_recv_exact(sock, length).decode("utf-8"))
    if not isinstance(data, dict):
        raise SecurityError("Định dạng khung điều khiển không hợp lệ.")
    return data


class _PendingDecision:
    def __init__(self):
        self.event = threading.Event()
        self.accepted: bool = False
        self.trust_peer: bool = False


_FIREWALL_REMOTE_IPS = (
    "LocalSubnet,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,"
    "100.64.0.0/10,198.18.0.0/15,26.0.0.0/8,25.0.0.0/8"
)


def _ensure_windows_lan_firewall_rules(udp_port: int, tcp_port: int) -> None:
    """Register strictly LAN/VPN-scoped inbound firewall rules on Windows (blocks public WAN IPs)."""
    if sys.platform != "win32":
        return
    t0 = time.monotonic()
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    added = 0
    for proto, port in (("UDP", udp_port), ("TCP", tcp_port)):
        if port <= 0:
            continue
        rule_name = f"Bob Gaming BobDrop {proto} ({port})"
        try:
            chk = subprocess.run(
                ["netsh", "advfirewall", "firewall", "show", "rule", f"name={rule_name}"],
                capture_output=True,
                text=True,
                timeout=5.0,
                creationflags=flags,
                check=False,
            )
            if chk.returncode == 0:
                continue
            res = subprocess.run(
                [
                    "netsh", "advfirewall", "firewall", "add", "rule",
                    f"name={rule_name}",
                    "dir=in",
                    "action=allow",
                    f"protocol={proto}",
                    f"localport={port}",
                    "profile=any",
                    f"remoteip={_FIREWALL_REMOTE_IPS}",
                ],
                capture_output=True,
                text=True,
                timeout=5.0,
                creationflags=flags,
                check=False,
            )
            if res.returncode == 0:
                added += 1
            else:
                logger.debug(f"{TAG} Skipped firewall rule {rule_name!r} (non-elevated or denied)")
        except Exception as exc:
            logger.debug(f"{TAG} Firewall rule check failed for {rule_name!r}: {exc}")
    if added:
        logger.info(f"{TAG} Registered {added} LAN/VPN-scoped Windows Firewall rule(s) in {time.monotonic() - t0:.2f}s")


class LanDropService(QObject):
    """
    Process-wide BobDrop P2P engine.
    All socket, TLS, hashing, and disk operations run on background threads;
    UI communicates strictly via thread-safe Qt Signals and locked methods.
    """

    peers_changed = Signal(list)               # list[PeerInfo]
    incoming_offer = Signal(object)            # IncomingOffer
    transfer_updated = Signal(object)          # TransferRecord snapshot
    transfer_finished = Signal(object)         # TransferRecord snapshot
    status_changed = Signal(str, int)          # (mode, tcp_port)
    service_error = Signal(str)

    def __init__(
        self,
        config: dict,
        parent: QObject | None = None,
        udp_port: int = DEFAULT_DISCOVERY_UDP_PORT,
        tcp_port: int = DEFAULT_TRANSFER_TCP_PORT,
        enable_mdns: bool = True,
        save_config_fn: Callable[[dict], bool] = save_config,
    ):
        super().__init__(parent)
        self._config = config
        self._save_config_fn = save_config_fn
        self._lock = threading.RLock()

        self._identity, mutated = load_or_create_identity(self._config)
        if mutated:
            self._persist_config()

        self._server_ssl = create_server_ssl_context(self._identity)
        self._client_ssl = create_client_ssl_context(self._identity)

        self._preferred_tcp_port = tcp_port
        self._bound_tcp_port = 0
        self._udp_port = udp_port
        self._enable_mdns = enable_mdns

        self._running = False
        self._stop_event = threading.Event()
        self._server_sock: socket.socket | None = None
        self._accept_thread: threading.Thread | None = None
        self._incoming_sem = threading.Semaphore(MAX_CONCURRENT_INCOMING)
        self._executor = ThreadPoolExecutor(max_workers=12, thread_name_prefix="BobDrop-Worker")

        self._offer_limiter = RateLimiter(max_events=12, window_sec=60.0, cooldown_sec=90.0)
        self._pin_limiter = RateLimiter(max_events=5, window_sec=60.0, cooldown_sec=180.0)

        self._pending_decisions: dict[str, _PendingDecision] = {}
        self._cancel_flags: dict[str, threading.Event] = {}
        self._active_sockets: dict[str, socket.socket] = {}
        self._transfers: dict[str, TransferRecord] = {}

        self._discovery = LanDropDiscovery(
            device_id=self._identity.device_id,
            fingerprint=self._identity.fingerprint,
            get_state=self._discovery_state,
            on_peers_changed=lambda peers: self.peers_changed.emit(peers),
            udp_port=self._udp_port,
            enable_mdns=self._enable_mdns,
        )

    # ---- Properties & Config Accessors ----

    @property
    def identity(self) -> DropIdentity:
        return self._identity

    @property
    def tcp_port(self) -> int:
        return self._bound_tcp_port

    @property
    def udp_port(self) -> int:
        return self._discovery.udp_port

    @property
    def is_running(self) -> bool:
        return self._running

    def get_mode(self) -> str:
        with self._lock:
            m = str(self._config.get("lan_drop_mode") or "everyone").strip().lower()
            return m if m in VALID_MODES else "everyone"

    def set_mode(self, mode: str) -> None:
        clean = mode.strip().lower() if mode else "everyone"
        if clean not in VALID_MODES:
            raise ValueError(f"Chế độ không hợp lệ: {mode!r}")
        with self._lock:
            self._config["lan_drop_mode"] = clean
            self._persist_config()
        logger.info(f"{TAG} Visibility mode changed to {clean!r}")
        self._discovery.notify_state_changed()
        self.status_changed.emit(clean, self._bound_tcp_port)

    def get_device_name(self) -> str:
        with self._lock:
            custom = str(self._config.get("lan_drop_device_name") or "").strip()
            return custom or socket.gethostname() or "Bob Gaming PC"

    def set_device_name(self, name: str) -> None:
        clean = (name or "").strip()[:64]
        with self._lock:
            self._config["lan_drop_device_name"] = clean
            self._persist_config()
        logger.info(f"{TAG} Device display name updated to {self.get_device_name()!r}")
        self._discovery.notify_state_changed()

    def get_room_pin(self) -> str:
        with self._lock:
            enc = str(self._config.get("lan_drop_room_pin") or "").strip()
            return secret_mask.decrypt(enc) if enc else ""

    def set_room_pin(self, pin: str) -> None:
        clean = (pin or "").strip()[:64]
        with self._lock:
            self._config["lan_drop_room_pin"] = secret_mask.encrypt(clean) if clean else ""
            self._persist_config()
        logger.info(f"{TAG} Room PIN updated (enabled={bool(clean)})")
        self._discovery.notify_state_changed()

    def get_save_dir(self) -> str:
        with self._lock:
            configured = str(self._config.get("lan_drop_save_dir") or "").strip()
            if configured and not is_forbidden_save_dir(configured):
                return configured
            return default_save_dir()

    def set_save_dir(self, folder: str) -> None:
        clean = os.path.abspath((folder or "").strip())
        if is_forbidden_save_dir(clean):
            raise ValueError("Không được phép lưu tệp nhận vào thư mục cấu hình của Bob Gaming.")
        os.makedirs(clean, exist_ok=True)
        with self._lock:
            self._config["lan_drop_save_dir"] = clean
            self._persist_config()
        logger.info(f"{TAG} Receive folder set to {clean!r}")

    def get_trusted_peers(self) -> dict[str, dict]:
        with self._lock:
            raw = self._config.get("lan_drop_trusted_peers")
            return dict(raw) if isinstance(raw, dict) else {}

    def untrust_peer(self, device_id: str) -> None:
        with self._lock:
            trusted = self._config.setdefault("lan_drop_trusted_peers", {})
            removed = trusted.pop(device_id, None)
            if removed is not None:
                self._persist_config()
                logger.info(f"{TAG} Removed trusted peer {device_id[:8]}")

    def trust_peer_explicit(self, device_id: str, fingerprint: str, name: str) -> None:
        with self._lock:
            trusted = self._config.setdefault("lan_drop_trusted_peers", {})
            trusted[device_id] = {
                "fingerprint": fingerprint.lower(),
                "name": name[:64],
                "trusted_at": time.time(),
            }
            self._persist_config()
        logger.info(f"{TAG} Pinned TOFU key for peer {name!r} ({fingerprint[:8]})")

    def get_manual_peers(self) -> list[str]:
        with self._lock:
            raw = self._config.get("lan_drop_manual_peers")
            return [str(x) for x in raw if str(x).strip()] if isinstance(raw, list) else []

    def get_peers(self) -> list[PeerInfo]:
        return self._discovery.get_peers()

    def get_transfers(self) -> list[TransferRecord]:
        with self._lock:
            return [r.snapshot() for r in self._transfers.values()]

    def _discovery_state(self) -> tuple[str, str, int, bool, list[str]]:
        return (
            self.get_device_name(),
            self.get_mode(),
            self._bound_tcp_port,
            bool(self.get_room_pin()),
            self.get_manual_peers(),
        )

    def _persist_config(self) -> None:
        try:
            self._save_config_fn(self._config)
        except Exception as exc:
            logger.error(f"{TAG} Could not persist config: {exc}")

    # ---- Lifecycle ----

    def start(self) -> None:
        with self._lock:
            if self._running:
                return
            self._running = True
            self._stop_event.clear()

        t0 = time.monotonic()
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind(("0.0.0.0", self._preferred_tcp_port))
        except OSError as exc:
            logger.warning(f"{TAG} TCP port {self._preferred_tcp_port} busy ({exc}); binding dynamic port")
            srv.bind(("0.0.0.0", 0))
        srv.listen(16)
        srv.settimeout(0.5)
        self._bound_tcp_port = srv.getsockname()[1]
        self._server_sock = srv

        self._accept_thread = threading.Thread(target=self._accept_loop, name="BobDrop-TLS-Accept", daemon=True)
        self._accept_thread.start()
        self._discovery.start()
        if (
            sys.platform == "win32"
            and "PYTEST_CURRENT_TEST" not in os.environ
            and os.environ.get("BOBGAMING_LANDROP_DISABLE") != "1"
            and self._preferred_tcp_port > 0
        ):
            threading.Thread(
                target=_ensure_windows_lan_firewall_rules,
                args=(self._discovery.udp_port, self._bound_tcp_port),
                name="BobDrop-Firewall",
                daemon=True,
            ).start()

        mode = self.get_mode()
        logger.info(
            f"{TAG} Started BobDrop service on TLS :{self._bound_tcp_port} "
            f"(mode={mode}, id={self._identity.short_fingerprint}) in {time.monotonic() - t0:.3f}s"
        )
        self.status_changed.emit(mode, self._bound_tcp_port)

    def shutdown(self) -> None:
        with self._lock:
            if not self._running:
                return
            self._running = False
            self._stop_event.set()
            for ev in self._cancel_flags.values():
                ev.set()
            for pd in self._pending_decisions.values():
                pd.accepted = False
                pd.event.set()
            active_socks = list(self._active_sockets.values())

        for s in active_socks:
            try:
                s.close()
            except OSError:
                pass

        self._discovery.stop()

        srv = self._server_sock
        self._server_sock = None
        if srv is not None:
            try:
                srv.close()
            except OSError:
                pass

        if self._accept_thread is not None and self._accept_thread.is_alive():
            self._accept_thread.join(timeout=2.0)

        self._executor.shutdown(wait=False, cancel_futures=True)
        self._bound_tcp_port = 0
        logger.info(f"{TAG} BobDrop service stopped cleanly")

    def refresh_peers(self) -> None:
        logger.info(f"{TAG} User requested LAN/VPN peer refresh")
        self._discovery.trigger_refresh()
        for entry in self.get_manual_peers():
            ip_part, _, port_part = entry.partition(":")
            port = int(port_part) if port_part.isdigit() else DEFAULT_TRANSFER_TCP_PORT
            self.probe_manual_peer_async(ip_part, port, persist=False)

    # ---- Manual VPN Peer Probe ----

    def probe_manual_peer_async(self, raw_ip: str, port: int = DEFAULT_TRANSFER_TCP_PORT, persist: bool = True) -> None:
        if not self._running:
            return
        self._executor.submit(self._probe_manual_peer_worker, raw_ip, port, persist)

    def _probe_manual_peer_worker(self, raw_ip: str, port: int, persist: bool) -> PeerInfo | None:
        t0 = time.monotonic()
        try:
            clean_ip = normalize_ip(raw_ip)
            if not is_allowed_peer_ip(clean_ip):
                msg = f"Từ chối kết nối tới IP ngoài mạng nội bộ/VPN: {clean_ip}"
                logger.warning(f"{TAG} {msg}")
                self.service_error.emit(msg)
                return None

            with socket.create_connection((clean_ip, int(port)), timeout=4.0) as raw_sock:
                raw_sock.settimeout(HANDSHAKE_TIMEOUT_SEC)
                with self._client_ssl.wrap_socket(raw_sock, server_side=False) as tls_sock:
                    der = tls_sock.getpeercert(binary_form=True)
                    if not der:
                        raise SecurityError("Thiết bị đích không cung cấp chứng chỉ TLS.")
                    fp = cert_fingerprint_sha256(der)
                    hello = _recv_json(tls_sock)
                    if hello.get("type") != "hello":
                        raise SecurityError("Phản hồi giao thức không hợp lệ.")
                    _send_json(tls_sock, {"type": "ping"})

            peer_id = str(hello.get("device_id") or "").strip()
            if not peer_id or peer_id == self._identity.device_id:
                self.service_error.emit("Địa chỉ IP vừa nhập chính là máy tính hiện tại của bạn.")
                return None

            peer = PeerInfo(
                device_id=peer_id[:64],
                device_name=str(hello.get("device_name") or clean_ip)[:64],
                ip=clean_ip,
                port=int(port),
                fingerprint=fp,
                mode="trusted" if hello.get("mode") == "trusted" else "everyone",
                pin_required=bool(hello.get("pin_required", False)),
                net_kind=classify_network_kind(clean_ip),
                is_manual=True,
                last_seen=time.monotonic(),
            )
            if persist:
                with self._lock:
                    manual = self.get_manual_peers()
                    spec = f"{clean_ip}:{port}" if port != DEFAULT_TRANSFER_TCP_PORT else clean_ip
                    if spec not in manual:
                        manual.append(spec)
                        self._config["lan_drop_manual_peers"] = manual
                        self._persist_config()
            self._discovery.upsert_probed_peer(peer)
            logger.info(
                f"{TAG} Probed VPN/LAN peer {peer.device_name!r} at {clean_ip}:{port} in {time.monotonic() - t0:.2f}s"
            )
            return peer
        except Exception as exc:
            elapsed = time.monotonic() - t0
            logger.warning(f"{TAG} Manual peer probe to {raw_ip}:{port} failed in {elapsed:.2f}s: {exc}")
            if persist:
                self.service_error.emit(f"Không tìm thấy BobDrop tại {raw_ip}:{port} ({exc})")
            return None

    # ---- Outgoing Transfers (Single Peer / Multi-Peer / Share to All) ----

    def send_to_peers(self, paths: list[str], peers: list[PeerInfo], room_pin: str = "") -> list[str]:
        """Dispatch encrypted file/folder transfer offers to 1 or many peers in background threads."""
        if not self._running:
            self.service_error.emit("Dịch vụ BobDrop chưa sẵn sàng.")
            return []
        if not paths or not peers:
            return []

        is_broadcast = len(peers) > 1
        transfer_ids: list[str] = []
        for peer in peers:
            tid = str(uuid.uuid4())
            transfer_ids.append(tid)
            rec = TransferRecord(
                transfer_id=tid,
                direction="send",
                peer_id=peer.device_id,
                peer_name=peer.device_name,
                peer_ip=peer.ip,
                status="connecting",
                message="Đang chuẩn bị danh sách tệp...",
                broadcast=is_broadcast,
            )
            with self._lock:
                self._transfers[tid] = rec
                self._cancel_flags[tid] = threading.Event()
            self.transfer_updated.emit(rec.snapshot())

        logger.info(
            f"{TAG} User initiated send of {len(paths)} root path(s) to {len(peers)} peer(s) "
            f"(broadcast={is_broadcast})"
        )
        self._executor.submit(self._prepare_and_fanout, list(paths), list(peers), transfer_ids, room_pin, is_broadcast)
        return transfer_ids

    def _prepare_and_fanout(
        self,
        paths: list[str],
        peers: list[PeerInfo],
        transfer_ids: list[str],
        room_pin: str,
        is_broadcast: bool,
    ) -> None:
        t0 = time.monotonic()
        try:
            entries = collect_payload_entries(paths)
            if not entries:
                raise ValueError("Không tìm thấy tệp hợp lệ nào để gửi (thư mục trống hoặc tệp không tồn tại).")
            total_bytes = sum(e.size for e in entries)
            logger.info(
                f"{TAG} Collected {len(entries)} file(s) ({format_bytes(total_bytes)}) in {time.monotonic() - t0:.2f}s"
            )
        except Exception as exc:
            logger.warning(f"{TAG} Payload collection failed: {exc}")
            for tid in transfer_ids:
                self._finish_record(tid, "failed", str(exc))
            self.service_error.emit(str(exc))
            return

        effective_pin = (room_pin or "").strip() or self.get_room_pin()
        for peer, tid in zip(peers, transfer_ids):
            self._executor.submit(self._send_single_peer_worker, tid, peer, entries, total_bytes, effective_pin, is_broadcast)

    def _send_single_peer_worker(
        self,
        tid: str,
        peer: PeerInfo,
        entries: list[PayloadEntry],
        total_bytes: int,
        room_pin: str,
        is_broadcast: bool,
    ) -> None:
        started = time.monotonic()
        cancel_ev = self._cancel_flags.get(tid) or threading.Event()

        with self._lock:
            rec = self._transfers.get(tid)
            if rec:
                rec.file_count = len(entries)
                rec.total_bytes = total_bytes
                rec.message = f"Đang kết nối bảo mật TLS 1.3 tới {peer.device_name}..."
                self.transfer_updated.emit(rec.snapshot())

        try:
            clean_ip = normalize_ip(peer.ip)
            if not is_allowed_peer_ip(clean_ip):
                raise SecurityError(f"Chặn gửi ra ngoài mạng nội bộ/VPN ({clean_ip}).")

            with socket.create_connection((clean_ip, int(peer.port)), timeout=HANDSHAKE_TIMEOUT_SEC) as raw_sock:
                raw_sock.settimeout(HANDSHAKE_TIMEOUT_SEC)
                with self._client_ssl.wrap_socket(raw_sock, server_side=False) as tls_sock:
                    with self._lock:
                        self._active_sockets[tid] = tls_sock

                    if tls_sock.version() != "TLSv1.3":
                        raise SecurityError(f"Kết nối không đạt chuẩn TLS 1.3 ({tls_sock.version()}).")

                    der = tls_sock.getpeercert(binary_form=True)
                    if not der:
                        raise SecurityError("Thiết bị nhận không cung cấp chứng chỉ bảo mật.")
                    server_fp = cert_fingerprint_sha256(der)

                    # Verify against discovered fingerprint and TOFU pinned fingerprint
                    if peer.fingerprint and not hmac.compare_digest(peer.fingerprint.lower(), server_fp.lower()):
                        raise SecurityError(
                            "Khoá bảo mật của thiết bị nhận không khớp với radar (nghi ngờ giả mạo / MITM)!"
                        )
                    pinned = self.get_trusted_peers().get(peer.device_id)
                    if pinned and not hmac.compare_digest(str(pinned.get("fingerprint", "")).lower(), server_fp.lower()):
                        raise SecurityError(
                            f"CẢNH BÁO: Khoá bảo mật đã ghim của {peer.device_name} đã thay đổi! Đã chặn truyền tệp."
                        )

                    hello = _recv_json(tls_sock)
                    if hello.get("type") != "hello":
                        raise SecurityError("Phản hồi bắt tay không hợp lệ từ thiết bị nhận.")
                    server_nonce = str(hello.get("nonce") or "")
                    if len(server_nonce) != 64:
                        raise SecurityError("Nonce xác thực của thiết bị nhận không hợp lệ.")

                    client_nonce = self._offer_limiter.generate_nonce()
                    sas = compute_sas_code(self._identity.fingerprint, server_fp, server_nonce, client_nonce)
                    sig = sign_client_handshake(self._identity, server_fp, server_nonce, client_nonce)
                    pin_proof = (
                        compute_pin_proof(room_pin, self._identity.fingerprint, server_fp, server_nonce, client_nonce)
                        if room_pin
                        else ""
                    )

                    offer_msg = {
                        "type": "offer",
                        "transfer_id": tid,
                        "sender_id": self._identity.device_id,
                        "sender_name": self.get_device_name(),
                        "client_cert_pem": self._identity.cert_pem,
                        "client_nonce": client_nonce,
                        "signature": sig,
                        "pin_proof": pin_proof,
                        "broadcast": bool(is_broadcast),
                        "files": [{"rel_path": e.rel_path, "size": e.size} for e in entries],
                    }
                    _send_json(tls_sock, offer_msg)

                    with self._lock:
                        rec = self._transfers.get(tid)
                        if rec:
                            rec.sas_code = sas
                            rec.status = "waiting"
                            rec.message = f"Đang chờ {peer.device_name} chấp nhận (Mã: {sas})..."
                            self.transfer_updated.emit(rec.snapshot())

                    tls_sock.settimeout(DECISION_TIMEOUT_SEC + 5.0)
                    decision = _recv_json(tls_sock)
                    if cancel_ev.is_set():
                        raise InterruptedError("Đã huỷ bởi người gửi.")
                    if decision.get("type") != "decision" or not decision.get("accepted"):
                        reason = str(decision.get("reason") or "Người nhận đã từ chối.")
                        logger.warning(
                            f"{TAG} Offer {tid[:8]} to {peer.device_name!r} ({clean_ip}) declined: {reason}"
                        )
                        self._finish_record(tid, "declined", reason)
                        return

                    # Receiver accepted -> stream files over TLS 1.3
                    tls_sock.settimeout(IO_TIMEOUT_SEC)
                    stream_t0 = time.monotonic()
                    sent_total = 0
                    next_milestone = 25
                    last_emit = 0.0

                    with self._lock:
                        rec = self._transfers.get(tid)
                        if rec:
                            rec.status = "transferring"
                            rec.message = "Đang truyền dữ liệu mã hoá TLS 1.3..."
                            self.transfer_updated.emit(rec.snapshot())

                    for idx, entry in enumerate(entries):
                        if cancel_ev.is_set():
                            raise InterruptedError("Đã huỷ truyền tệp.")
                        actual_size = os.path.getsize(entry.abs_path)
                        _send_json(tls_sock, {"type": "file_start", "index": idx, "size": actual_size})
                        hasher = hashlib.sha256()
                        remaining = actual_size
                        with open(entry.abs_path, "rb") as fp_in:
                            while remaining > 0:
                                if cancel_ev.is_set():
                                    raise InterruptedError("Đã huỷ truyền tệp.")
                                chunk = fp_in.read(min(CHUNK_SIZE, remaining))
                                if not chunk:
                                    raise IOError(f"Tệp nguồn thay đổi kích thước khi đang đọc: {entry.rel_path}")
                                tls_sock.sendall(chunk)
                                hasher.update(chunk)
                                sent_total += len(chunk)
                                remaining -= len(chunk)

                                now = time.monotonic()
                                pct = int((sent_total * 100) / max(1, total_bytes))
                                while pct >= next_milestone and next_milestone <= 100:
                                    logger.info(
                                        f"{TAG} Send {tid[:8]} -> {peer.device_name!r}: {next_milestone}% "
                                        f"({format_bytes(sent_total)}/{format_bytes(total_bytes)})"
                                    )
                                    next_milestone += 25
                                if now - last_emit >= PROGRESS_EMIT_INTERVAL_SEC:
                                    last_emit = now
                                    elapsed_s = max(0.001, now - stream_t0)
                                    self._update_progress(
                                        tid, sent_total, sent_total / elapsed_s, f"Đang gửi: {entry.rel_path}"
                                    )

                        _send_json(tls_sock, {"type": "file_end", "index": idx, "sha256": hasher.hexdigest()})

                    _send_json(tls_sock, {"type": "transfer_complete"})
                    ack = _recv_json(tls_sock)
                    if not ack.get("ok"):
                        raise IOError(str(ack.get("error") or "Người nhận báo lỗi xác thực toàn vẹn."))

                    dur = max(0.001, time.monotonic() - stream_t0)
                    speed = sent_total / dur
                    logger.info(
                        f"{TAG} Completed send {tid[:8]} to {peer.device_name!r} ({clean_ip}): "
                        f"{len(entries)} file(s), {format_bytes(sent_total)} in {dur:.2f}s ({format_bytes(speed)}/s)"
                    )
                    self._finish_record(
                        tid,
                        "completed",
                        f"Đã gửi {len(entries)} tệp ({format_bytes(sent_total)}) — SHA-256 hợp lệ",
                        transferred=sent_total,
                        speed=speed,
                    )
        except InterruptedError as exc:
            logger.info(f"{TAG} Send {tid[:8]} to {peer.device_name!r} cancelled after {time.monotonic() - started:.2f}s")
            self._finish_record(tid, "cancelled", str(exc))
        except SecurityError as exc:
            logger.warning(
                f"{TAG} Security block on send {tid[:8]} to {peer.ip}:{peer.port} "
                f"after {time.monotonic() - started:.2f}s: {exc}"
            )
            self._finish_record(tid, "failed", str(exc))
            self.service_error.emit(str(exc))
        except Exception as exc:
            if cancel_ev.is_set():
                logger.info(f"{TAG} Send {tid[:8]} aborted by user")
                self._finish_record(tid, "cancelled", "Đã huỷ truyền tệp.")
            else:
                logger.warning(
                    f"{TAG} Send {tid[:8]} to {peer.ip}:{peer.port} failed "
                    f"after {time.monotonic() - started:.2f}s: {exc}"
                )
                self._finish_record(tid, "failed", f"Lỗi kết nối: {exc}")
        finally:
            with self._lock:
                self._active_sockets.pop(tid, None)
                self._cancel_flags.pop(tid, None)

    # ---- Incoming Transfers (TLS 1.3 Server) ----

    def respond_to_offer(self, transfer_id: str, accept: bool, trust_peer: bool = False) -> None:
        with self._lock:
            pending = self._pending_decisions.get(transfer_id)
            if pending is None:
                return
            pending.accepted = bool(accept)
            pending.trust_peer = bool(trust_peer)
            pending.event.set()
        logger.info(
            f"{TAG} User responded to incoming offer {transfer_id[:8]}: accept={accept}, trust_peer={trust_peer}"
        )

    def cancel_transfer(self, transfer_id: str) -> None:
        with self._lock:
            ev = self._cancel_flags.get(transfer_id)
            if ev is not None:
                ev.set()
            pd = self._pending_decisions.get(transfer_id)
            if pd is not None:
                pd.accepted = False
                pd.event.set()
            sock = self._active_sockets.get(transfer_id)
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
        logger.info(f"{TAG} User requested cancel for transfer {transfer_id[:8]}")

    def _accept_loop(self) -> None:
        while not self._stop_event.is_set():
            srv = self._server_sock
            if srv is None:
                break
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue
            except OSError:
                break

            peer_ip_raw = addr[0]
            try:
                peer_ip = normalize_ip(peer_ip_raw)
            except SecurityError:
                conn.close()
                continue

            if self.get_mode() == "off":
                conn.close()
                continue

            if not is_allowed_peer_ip(peer_ip):
                logger.warning(f"{TAG} Blocked incoming TCP connection from public/non-LAN IP {peer_ip}")
                conn.close()
                continue

            if self._offer_limiter.is_blocked(peer_ip) or self._pin_limiter.is_blocked(peer_ip):
                logger.warning(f"{TAG} Rate-limited incoming connection from {peer_ip}")
                conn.close()
                continue

            if not self._incoming_sem.acquire(blocking=False):
                logger.warning(f"{TAG} Max concurrent incoming limit reached; dropping {peer_ip}")
                conn.close()
                continue

            threading.Thread(
                target=self._handle_incoming_client,
                args=(conn, peer_ip),
                name=f"BobDrop-In-{peer_ip}",
                daemon=True,
            ).start()

    def _handle_incoming_client(self, raw_conn: socket.socket, peer_ip: str) -> None:
        started = time.monotonic()
        tid = ""
        part_path_cleanup = ""
        cancel_ev = threading.Event()
        try:
            raw_conn.settimeout(HANDSHAKE_TIMEOUT_SEC)
            with raw_conn:
                with self._server_ssl.wrap_socket(raw_conn, server_side=True) as tls_sock:
                    if tls_sock.version() != "TLSv1.3":
                        raise SecurityError(f"Từ chối kết nối TLS thấp hơn 1.3 ({tls_sock.version()}).")

                    server_nonce = self._offer_limiter.generate_nonce()
                    _send_json(
                        tls_sock,
                        {
                            "type": "hello",
                            "v": 1,
                            "nonce": server_nonce,
                            "device_id": self._identity.device_id,
                            "device_name": self.get_device_name(),
                            "mode": self.get_mode(),
                            "pin_required": bool(self.get_room_pin()),
                        },
                    )

                    msg = _recv_json(tls_sock)
                    if msg.get("type") == "ping":
                        return
                    if msg.get("type") != "offer":
                        raise SecurityError("Khung yêu cầu không hợp lệ.")

                    if not self._offer_limiter.record_and_allow(peer_ip):
                        raise SecurityError(f"Quá nhiều yêu cầu liên tiếp từ {peer_ip}; tạm khoá chống spam.")

                    client_nonce = str(msg.get("client_nonce") or "")
                    if len(client_nonce) != 64:
                        raise SecurityError("Client nonce không hợp lệ.")

                    client_fp = verify_client_handshake(
                        client_cert_pem=str(msg.get("client_cert_pem") or ""),
                        signature_hex=str(msg.get("signature") or ""),
                        server_fp_hex=self._identity.fingerprint,
                        server_nonce_hex=server_nonce,
                        client_nonce_hex=client_nonce,
                    )

                    sender_id = str(msg.get("sender_id") or "").strip()[:64]
                    sender_name = str(msg.get("sender_name") or peer_ip).strip()[:64] or peer_ip
                    if not sender_id:
                        raise SecurityError("Thiếu định danh thiết bị gửi.")

                    # 1. Room PIN verification (constant-time PBKDF2-HMAC proof)
                    expected_pin = self.get_room_pin()
                    if expected_pin:
                        ok_pin = verify_pin_proof(
                            expected_pin=expected_pin,
                            provided_proof_hex=str(msg.get("pin_proof") or ""),
                            client_fp_hex=client_fp,
                            server_fp_hex=self._identity.fingerprint,
                            server_nonce_hex=server_nonce,
                            client_nonce_hex=client_nonce,
                        )
                        if not ok_pin:
                            self._pin_limiter.record_and_allow(peer_ip)
                            logger.warning(f"{TAG} Rejected offer from {sender_name!r} ({peer_ip}): invalid Room PIN")
                            _send_json(
                                tls_sock,
                                {"type": "decision", "accepted": False, "reason": "Sai Mã phòng (PIN) bảo mật."},
                            )
                            return

                    # 2. TOFU & Visibility Mode enforcement
                    pinned = self.get_trusted_peers().get(sender_id)
                    is_trusted = bool(
                        pinned and hmac.compare_digest(str(pinned.get("fingerprint", "")).lower(), client_fp.lower())
                    )
                    key_changed = bool(pinned and not is_trusted)

                    if self.get_mode() == "trusted" and not is_trusted:
                        reason = (
                            "Khoá bảo mật của bạn đã thay đổi so với bản ghim trên máy nhận."
                            if key_changed
                            else "Người nhận chỉ chấp nhận tệp từ thiết bị đã tin cậy."
                        )
                        logger.warning(
                            f"{TAG} Rejected untrusted sender {sender_name!r} ({peer_ip}) in trusted-only mode"
                        )
                        _send_json(tls_sock, {"type": "decision", "accepted": False, "reason": reason})
                        return

                    # 3. Manifest validation & sanitization
                    raw_files = msg.get("files")
                    if not isinstance(raw_files, list) or not (1 <= len(raw_files) <= MAX_FILES_PER_OFFER):
                        raise SecurityError("Danh sách tệp gửi sang trống hoặc vượt ngưỡng an toàn.")

                    clean_files: list[dict] = []
                    seen_paths: set[str] = set()
                    total_size = 0
                    for item in raw_files:
                        if not isinstance(item, dict):
                            raise SecurityError("Mục tệp không hợp lệ.")
                        rel = sanitize_rel_path(str(item.get("rel_path") or ""))
                        if rel.lower() in seen_paths:
                            raise SecurityError(f"Danh sách tệp bị trùng lặp đường dẫn: {rel}")
                        seen_paths.add(rel.lower())
                        fsize = int(item.get("size", -1))
                        if fsize < 0 or fsize > (1 << 44):  # 16 TB sanity cap
                            raise SecurityError(f"Kích thước tệp không hợp lệ: {rel}")
                        clean_files.append({"rel_path": rel, "size": fsize})
                        total_size += fsize

                    # 4. Free disk space check before prompting
                    save_dir = self.get_save_dir()
                    os.makedirs(save_dir, exist_ok=True)
                    free_bytes = shutil.disk_usage(save_dir).free
                    if free_bytes < total_size + DISK_SAFETY_MARGIN_BYTES:
                        logger.warning(
                            f"{TAG} Insufficient disk space in {save_dir!r} "
                            f"(need {format_bytes(total_size)}, free {format_bytes(free_bytes)})"
                        )
                        _send_json(
                            tls_sock,
                            {
                                "type": "decision",
                                "accepted": False,
                                "reason": f"Ổ đĩa người nhận không đủ chỗ trống (cần {format_bytes(total_size)}).",
                            },
                        )
                        return

                    tid = str(msg.get("transfer_id") or uuid.uuid4())[:64]
                    if tid in self._transfers:
                        tid = str(uuid.uuid4())
                    sas = compute_sas_code(client_fp, self._identity.fingerprint, server_nonce, client_nonce)
                    offer = IncomingOffer(
                        transfer_id=tid,
                        sender_id=sender_id,
                        sender_name=sender_name,
                        sender_ip=peer_ip,
                        sender_fingerprint=client_fp,
                        sas_code=sas,
                        is_trusted=is_trusted,
                        key_changed=key_changed,
                        broadcast=bool(msg.get("broadcast", False)),
                        files=clean_files,
                        total_size=total_size,
                        save_dir=save_dir,
                    )

                    decision_holder = _PendingDecision()
                    rec = TransferRecord(
                        transfer_id=tid,
                        direction="receive",
                        peer_id=sender_id,
                        peer_name=sender_name,
                        peer_ip=peer_ip,
                        sas_code=sas,
                        file_count=len(clean_files),
                        total_bytes=total_size,
                        status="waiting",
                        message=f"Đang chờ bạn xác nhận nhận {len(clean_files)} tệp...",
                        save_dir=save_dir,
                    )
                    with self._lock:
                        self._transfers[tid] = rec
                        self._pending_decisions[tid] = decision_holder
                        self._cancel_flags[tid] = cancel_ev
                        self._active_sockets[tid] = tls_sock

                    logger.info(
                        f"{TAG} Incoming offer {tid[:8]} from {sender_name!r} ({peer_ip}): "
                        f"{len(clean_files)} file(s), {format_bytes(total_size)}, trusted={is_trusted}"
                    )
                    self.transfer_updated.emit(rec.snapshot())
                    self.incoming_offer.emit(offer)

                    responded = decision_holder.event.wait(timeout=DECISION_TIMEOUT_SEC)
                    with self._lock:
                        self._pending_decisions.pop(tid, None)

                    if not responded or not decision_holder.accepted or cancel_ev.is_set():
                        reason = "Người nhận đã từ chối." if responded else "Hết thời gian chờ người nhận xác nhận."
                        _send_json(tls_sock, {"type": "decision", "accepted": False, "reason": reason})
                        self._finish_record(tid, "declined", reason)
                        return

                    if decision_holder.trust_peer:
                        self.trust_peer_explicit(sender_id, client_fp, sender_name)

                    _send_json(tls_sock, {"type": "decision", "accepted": True})

                    # 5. Receive & verify SHA-256 per file
                    tls_sock.settimeout(IO_TIMEOUT_SEC)
                    stream_t0 = time.monotonic()
                    received_total = 0
                    next_milestone = 25
                    last_emit = 0.0
                    batch_root_remap: dict[str, str] = {}

                    with self._lock:
                        rec = self._transfers.get(tid)
                        if rec:
                            rec.status = "transferring"
                            rec.message = "Đang nhận dữ liệu mã hoá TLS 1.3..."
                            self.transfer_updated.emit(rec.snapshot())

                    for idx, fmeta in enumerate(clean_files):
                        if cancel_ev.is_set():
                            raise InterruptedError("Đã huỷ nhận tệp.")
                        fstart = _recv_json(tls_sock)
                        if fstart.get("type") != "file_start" or int(fstart.get("index", -1)) != idx:
                            raise SecurityError("Thứ tự khung dữ liệu tệp không khớp.")
                        expected_size = int(fstart.get("size", -1))
                        if expected_size < 0 or expected_size > fmeta["size"] + 1024 * 1024:
                            raise SecurityError(f"Kích thước tệp truyền vượt khai báo: {fmeta['rel_path']}")
                        if received_total + expected_size > total_size + 4 * 1024 * 1024:
                            raise SecurityError("Tổng dung lượng truyền vượt quá bản kê khai ban đầu.")
                        if shutil.disk_usage(save_dir).free < expected_size + DISK_SAFETY_MARGIN_BYTES:
                            raise IOError("Ổ đĩa hết dung lượng trống trong lúc nhận tệp.")

                        final_path = resolve_safe_destination(save_dir, fmeta["rel_path"], batch_root_remap)
                        os.makedirs(os.path.dirname(final_path), exist_ok=True)
                        part_path = final_path + ".bobpart"
                        part_path_cleanup = part_path

                        hasher = hashlib.sha256()
                        remaining = expected_size
                        with open(part_path, "wb") as fp_out:
                            while remaining > 0:
                                if cancel_ev.is_set():
                                    raise InterruptedError("Đã huỷ nhận tệp.")
                                chunk = tls_sock.recv(min(CHUNK_SIZE, remaining))
                                if not chunk:
                                    raise ConnectionError(f"Mất kết nối khi đang nhận {fmeta['rel_path']}.")
                                fp_out.write(chunk)
                                hasher.update(chunk)
                                received_total += len(chunk)
                                remaining -= len(chunk)

                                now = time.monotonic()
                                pct = int((received_total * 100) / max(1, total_size))
                                while pct >= next_milestone and next_milestone <= 100:
                                    logger.info(
                                        f"{TAG} Receive {tid[:8]} <- {sender_name!r}: {next_milestone}% "
                                        f"({format_bytes(received_total)}/{format_bytes(total_size)})"
                                    )
                                    next_milestone += 25
                                if now - last_emit >= PROGRESS_EMIT_INTERVAL_SEC:
                                    last_emit = now
                                    elapsed_s = max(0.001, now - stream_t0)
                                    self._update_progress(
                                        tid,
                                        received_total,
                                        received_total / elapsed_s,
                                        f"Đang nhận: {fmeta['rel_path']}",
                                    )

                        fend = _recv_json(tls_sock)
                        if fend.get("type") != "file_end" or int(fend.get("index", -1)) != idx:
                            raise SecurityError("Thiếu khung kết thúc kiểm tra SHA-256 của tệp.")
                        expected_sha = str(fend.get("sha256") or "").lower()
                        actual_sha = hasher.hexdigest().lower()
                        if not expected_sha or not hmac.compare_digest(actual_sha, expected_sha):
                            raise SecurityError(
                                f"Kiểm tra toàn vẹn SHA-256 thất bại cho {fmeta['rel_path']}! Đã xoá tệp tạm."
                            )

                        os.replace(part_path, final_path)
                        part_path_cleanup = ""

                    done_frame = _recv_json(tls_sock)
                    if done_frame.get("type") != "transfer_complete":
                        raise SecurityError("Thiếu khung xác nhận hoàn tất phiên truyền.")
                    _send_json(tls_sock, {"type": "transfer_ack", "ok": True})

                    dur = max(0.001, time.monotonic() - stream_t0)
                    speed = received_total / dur
                    logger.info(
                        f"{TAG} Completed receive {tid[:8]} from {sender_name!r} ({peer_ip}): "
                        f"{len(clean_files)} file(s), {format_bytes(received_total)} in {dur:.2f}s ({format_bytes(speed)}/s)"
                    )
                    self._finish_record(
                        tid,
                        "completed",
                        f"Đã lưu {len(clean_files)} tệp vào {save_dir}",
                        transferred=received_total,
                        speed=speed,
                    )
        except InterruptedError as exc:
            if tid:
                logger.info(f"{TAG} Receive {tid[:8]} cancelled after {time.monotonic() - started:.2f}s")
                self._finish_record(tid, "cancelled", str(exc))
        except SecurityError as exc:
            logger.warning(f"{TAG} Security rejection from {peer_ip} after {time.monotonic() - started:.2f}s: {exc}")
            if tid:
                self._finish_record(tid, "failed", str(exc))
                self.service_error.emit(str(exc))
        except Exception as exc:
            if tid:
                if cancel_ev.is_set():
                    self._finish_record(tid, "cancelled", "Đã huỷ nhận tệp.")
                else:
                    logger.warning(f"{TAG} Incoming transfer {tid[:8]} from {peer_ip} failed: {exc}")
                    self._finish_record(tid, "failed", f"Gián đoạn truyền tệp: {exc}")
            else:
                logger.debug(f"{TAG} Handshake from {peer_ip} closed early: {exc}")
        finally:
            if part_path_cleanup and os.path.exists(part_path_cleanup):
                try:
                    os.remove(part_path_cleanup)
                except OSError:
                    pass
            if tid:
                with self._lock:
                    self._pending_decisions.pop(tid, None)
                    self._active_sockets.pop(tid, None)
                    self._cancel_flags.pop(tid, None)
            self._incoming_sem.release()

    def _update_progress(self, tid: str, transferred: int, speed_bps: float, message: str) -> None:
        with self._lock:
            rec = self._transfers.get(tid)
            if rec is None:
                return
            rec.transferred_bytes = transferred
            rec.speed_bps = speed_bps
            rec.message = message
            snap = rec.snapshot()
        self.transfer_updated.emit(snap)

    def _finish_record(
        self,
        tid: str,
        status: str,
        message: str,
        transferred: int | None = None,
        speed: float | None = None,
    ) -> None:
        with self._lock:
            rec = self._transfers.get(tid)
            if rec is None:
                return
            rec.status = status
            rec.message = message
            if transferred is not None:
                rec.transferred_bytes = transferred
            if speed is not None:
                rec.speed_bps = speed
            snap = rec.snapshot()
        self.transfer_updated.emit(snap)
        self.transfer_finished.emit(snap)
