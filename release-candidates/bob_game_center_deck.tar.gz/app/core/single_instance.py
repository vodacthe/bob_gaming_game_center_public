"""
Cross-platform single-instance enforcement for Bob Gaming Game Center.

On Linux / SteamOS:
  - Uses an atomic kernel-enforced POSIX flock on `app.lock` (never unlinked while active,
    eliminating double-click race conditions during Python/Qt boot).
  - Uses a Qt QLocalServer Unix socket to immediately bring an existing instance to the front
    when the user clicks the app icon again, preserving active downloads and chat sessions.
  - Falls back to SIGTERM -> wait -> SIGKILL when replacing an unresponsive instance (defeating
    SDL2's default SIGTERM handler that otherwise ignores termination signals).
"""

from __future__ import annotations

from collections.abc import Callable
import logging
import os
import signal
import socket
import sys
import time
from typing import Optional

logger = logging.getLogger(__name__)
TAG = "[Startup/SingleInstance]"

DEFAULT_SERVER_NAME = "BobGamingGameCenter_SingleInstance"


def _is_posix_pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False


def terminate_pid_posix(pid: int, term_wait: float = 1.5, kill_wait: float = 0.5) -> bool:
    """Terminate a POSIX process via SIGTERM, escalating to SIGKILL if it ignores SIGTERM (e.g. SDL2)."""
    if pid <= 0 or pid == os.getpid():
        return True

    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return True
    except OSError as exc:
        logger.warning(f"{TAG} SIGTERM failed for PID {pid}: {exc}")
        return False

    deadline = time.monotonic() + max(0.0, term_wait)
    while time.monotonic() < deadline:
        if not _is_posix_pid_alive(pid):
            return True
        time.sleep(0.05)

    sigkill = getattr(signal, "SIGKILL", None)
    if sigkill is None or not _is_posix_pid_alive(pid):
        return not _is_posix_pid_alive(pid)

    logger.warning(f"{TAG} PID {pid} did not exit after SIGTERM ({term_wait:.1f}s); escalating to SIGKILL")
    try:
        os.kill(pid, sigkill)
    except ProcessLookupError:
        return True
    except OSError as exc:
        logger.warning(f"{TAG} SIGKILL failed for PID {pid}: {exc}")
        return False

    kill_deadline = time.monotonic() + max(0.0, kill_wait)
    while time.monotonic() < kill_deadline:
        if not _is_posix_pid_alive(pid):
            return True
        time.sleep(0.05)
    return not _is_posix_pid_alive(pid)


class SingleInstanceGuard:
    """Kernel-backed lock + QLocalServer activation channel guaranteeing one live app instance."""

    def __init__(self, lock_path: str, server_name: str = DEFAULT_SERVER_NAME):
        self.lock_path = lock_path
        self.server_name = server_name
        self._fd: Optional[int] = None
        self._server = None
        if sys.platform != "win32":
            cand = os.path.join(os.path.dirname(os.path.abspath(lock_path)), "instance.sock")
            if len(cand.encode("utf-8")) < 95:
                self.listen_target = cand
            else:
                self.listen_target = f"/tmp/bob_gc_{os.getuid()}.sock"
        else:
            self.listen_target = server_name

    @property
    def is_locked(self) -> bool:
        return self._fd is not None

    def try_acquire(self) -> bool:
        """
        Atomically acquire exclusive OS lock on `lock_path` (POSIX flock).
        Returns True if this process is the primary instance, False if another live process holds it.
        """
        if self._fd is not None:
            return True

        os.makedirs(os.path.dirname(self.lock_path), exist_ok=True)
        fd = os.open(self.lock_path, os.O_CREAT | os.O_RDWR, 0o644)
        try:
            if sys.platform != "win32":
                import fcntl
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except OSError:
                    os.close(fd)
                    return False

            os.ftruncate(fd, 0)
            os.lseek(fd, 0, os.SEEK_SET)
            os.write(fd, str(os.getpid()).encode("ascii"))
            try:
                os.fsync(fd)
            except OSError:
                pass
            self._fd = fd
            logger.info(f"{TAG} Acquired single-instance lock (PID {os.getpid()}, file={self.lock_path})")
            return True
        except Exception:
            try:
                os.close(fd)
            except OSError:
                pass
            raise

    def read_owner_pid(self) -> Optional[int]:
        """Read PID currently recorded in lock_path without modifying or truncating the file."""
        try:
            with open(self.lock_path, "r", encoding="ascii", errors="ignore") as f:
                raw = f.read().strip()
            pid = int(raw)
            return pid if pid > 0 else None
        except (OSError, ValueError):
            return None

    def notify_running_instance(self, message: bytes = b"ACTIVATE\n", wait_timeout: float = 3.5) -> bool:
        """
        Ask the running primary instance to raise/show its window.
        Retries briefly so a rapid double-click waits while the primary instance finishes Qt init.
        """
        t0 = time.monotonic()
        deadline = t0 + max(0.2, wait_timeout)

        if sys.platform != "win32" and hasattr(socket, "AF_UNIX"):
            while time.monotonic() < deadline:
                if os.path.exists(self.listen_target):
                    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    sock.settimeout(1.0)
                    try:
                        sock.connect(self.listen_target)
                        sock.sendall(message)
                        try:
                            reply = sock.recv(64).strip()
                        except OSError:
                            reply = b""
                        logger.info(
                            f"{TAG} Notified existing instance via {self.listen_target!r} "
                            f"(reply={reply!r}) in {time.monotonic() - t0:.2f}s"
                        )
                        return True
                    except OSError as exc:
                        logger.debug(f"{TAG} Unix socket activation attempt failed: {exc}")
                    finally:
                        try:
                            sock.close()
                        except OSError:
                            pass
                time.sleep(0.15)
            logger.warning(f"{TAG} Existing instance did not respond on {self.listen_target!r} after {wait_timeout:.1f}s")
            return False

        try:
            from PySide6.QtNetwork import QLocalSocket
        except Exception as exc:
            logger.warning(f"{TAG} QLocalSocket unavailable: {exc}")
            return False

        while time.monotonic() < deadline:
            sock = QLocalSocket()
            try:
                sock.connectToServer(self.listen_target)
                if sock.waitForConnected(250):
                    sock.write(message)
                    sock.flush()
                    sock.waitForBytesWritten(500)
                    if sock.waitForReadyRead(1000):
                        reply = bytes(sock.readAll()).strip()
                        if reply.startswith(b"OK"):
                            logger.info(
                                f"{TAG} Notified existing instance via {self.listen_target!r} "
                                f"in {time.monotonic() - t0:.2f}s"
                            )
                            return True
                    logger.info(
                        f"{TAG} Sent activation to existing instance via {self.listen_target!r} "
                        f"in {time.monotonic() - t0:.2f}s"
                    )
                    return True
            except Exception as exc:
                logger.debug(f"{TAG} Activation connect attempt failed: {exc}")
            finally:
                try:
                    sock.disconnectFromServer()
                    sock.close()
                except Exception:
                    pass
            time.sleep(0.15)

        logger.warning(f"{TAG} Existing instance did not respond on {self.listen_target!r} after {wait_timeout:.1f}s")
        return False

    def start_activation_server(self, on_activate: Callable[[], None]):
        """Start QLocalServer on the primary instance so subsequent clicks focus this window."""
        try:
            from PySide6.QtNetwork import QLocalServer
        except Exception as exc:
            logger.warning(f"{TAG} QLocalServer unavailable: {exc}")
            return None

        try:
            if sys.platform != "win32" and os.path.exists(self.listen_target):
                try:
                    os.remove(self.listen_target)
                except OSError:
                    pass
            QLocalServer.removeServer(self.listen_target)
            server = QLocalServer()

            def _on_new_connection():
                while server.hasPendingConnections():
                    conn = server.nextPendingConnection()
                    if conn is None:
                        continue
                    try:
                        conn.waitForReadyRead(300)
                        payload = bytes(conn.readAll()).strip().upper()
                        if not payload or payload.startswith(b"ACTIVATE"):
                            logger.info(f"{TAG} Activation requested by secondary launch; raising main window")
                            try:
                                on_activate()
                            except Exception:
                                logger.exception(f"{TAG} Failed raising main window on activation")
                        conn.write(b"OK\n")
                        conn.flush()
                        conn.waitForBytesWritten(300)
                    except Exception:
                        logger.exception(f"{TAG} Error handling activation IPC connection")
                    finally:
                        conn.disconnectFromServer()
                        conn.deleteLater()

            server.newConnection.connect(_on_new_connection)
            if not server.listen(self.listen_target):
                logger.warning(f"{TAG} Could not listen on {self.listen_target!r}: {server.errorString()}")
                return None

            self._server = server
            logger.info(f"{TAG} Listening for single-instance activations on {self.listen_target!r}")
            return server
        except Exception as exc:
            logger.warning(f"{TAG} Failed starting activation server: {exc}")
            return None

    def release(self) -> None:
        """Close QLocalServer and release OS file lock cleanly (keeping lock file inode intact on POSIX)."""
        if self._server is not None:
            try:
                self._server.close()
                from PySide6.QtNetwork import QLocalServer
                QLocalServer.removeServer(self.listen_target)
            except Exception:
                pass
            if sys.platform != "win32" and os.path.exists(self.listen_target):
                try:
                    os.remove(self.listen_target)
                except OSError:
                    pass
            self._server = None

        if self._fd is not None:
            fd = self._fd
            self._fd = None
            try:
                if sys.platform != "win32":
                    import fcntl
                    try:
                        fcntl.flock(fd, fcntl.LOCK_UN)
                    except OSError:
                        pass
                os.close(fd)
            except OSError:
                pass
