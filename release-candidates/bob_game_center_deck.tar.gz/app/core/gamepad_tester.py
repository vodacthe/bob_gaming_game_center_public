"""Controller tester maths (Qt-free): axis scaling, stick circularity / drift, button names, vibration presets.

The circularity test works like hardwaretester.com/gamepad: spin a stick slowly along its outer edge; for each of
BINS angle slices the furthest distance reached is kept. A perfect stick reaches exactly 1.0 everywhere; the
average error is the mean of |1 - r| over the slices visited, in percent. Square gates (common on cheap pads and in
XInput's own scaling) show up as > 10 %.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

AXIS_MAX = 32767
BINS = 72                        # 5 degrees per slice
MIN_BINS_FOR_RESULT = 24         # a third of the circle before an error is shown
EDGE_THRESHOLD = 0.5             # samples closer to the centre are not "at the edge" and do not count
DRIFT_WARN = 0.08                # resting stick further than this from the centre: probably drifting

# SDL_GameControllerButton order (SDL 2.0.14+) and SDL_GameControllerAxis order
GC_BUTTONS = ("A", "B", "X", "Y", "Back", "Guide", "Start", "LS", "RS", "LB", "RB",
              "DPadUp", "DPadDown", "DPadLeft", "DPadRight", "Misc1", "Paddle1", "Paddle2", "Paddle3", "Paddle4",
              "Touchpad")
GC_AXES = ("LeftX", "LeftY", "RightX", "RightY", "TriggerLeft", "TriggerRight")

# SDL_GameControllerType -> label
CONTROLLER_TYPES = {0: "Không rõ", 1: "Xbox 360", 2: "Xbox One / Series", 3: "PlayStation 3", 4: "PlayStation 4",
                    5: "Nintendo Switch Pro", 6: "Thiết bị ảo", 7: "PlayStation 5", 8: "Amazon Luna",
                    9: "Google Stadia", 10: "NVIDIA Shield", 11: "Joy-Con (trái)", 12: "Joy-Con (phải)",
                    13: "Joy-Con (cặp)"}

# (label, low-frequency / left heavy motor 0..1, high-frequency / right light motor 0..1)
RUMBLE_PRESETS = (("Rất nhẹ", 0.10, 0.10), ("Nhẹ", 0.25, 0.25), ("Vừa", 0.50, 0.50), ("Mạnh", 0.75, 0.75),
                  ("Tối đa", 1.00, 1.00))
RUMBLE_MAX_MS = 5000


def axis_value(raw) -> float:
    """SDL int16 axis -> -1.0 .. 1.0."""
    try:
        v = int(raw)
    except (TypeError, ValueError):
        return 0.0
    return max(-1.0, min(1.0, v / (AXIS_MAX if v >= 0 else AXIS_MAX + 1)))


def trigger_value(raw) -> float:
    """SDL trigger axis (0..32767 on game controllers, -32768..32767 on raw joysticks) -> 0.0 .. 1.0."""
    return max(0.0, axis_value(raw))


def motor_value(fraction: float) -> int:
    """0.0 .. 1.0 -> the 0..65535 SDL rumble intensity."""
    return int(round(max(0.0, min(1.0, float(fraction))) * 0xFFFF))


def ramp(steps: int = 10, duration_ms: int = 3000) -> list[tuple[float, int]]:
    """(intensity, start ms) for a light-to-strong vibration sweep."""
    steps = max(2, int(steps))
    return [(round((i + 1) / steps, 3), int(i * duration_ms / steps)) for i in range(steps)]


class CircularityTracker:
    def __init__(self, bins: int = BINS):
        self.bins = bins
        self.reset()

    def reset(self) -> None:
        self.max_r: list[float] = [0.0] * self.bins

    def add(self, x: float, y: float) -> None:
        r = math.hypot(x, y)
        if r < EDGE_THRESHOLD:
            return
        angle = math.atan2(y, x) % (2 * math.pi)
        i = min(self.bins - 1, int(angle / (2 * math.pi) * self.bins))
        if r > self.max_r[i]:
            self.max_r[i] = min(r, 1.5)

    @property
    def covered(self) -> int:
        return sum(1 for r in self.max_r if r > 0)

    def error_percent(self) -> float | None:
        filled = [r for r in self.max_r if r > 0]
        if len(filled) < MIN_BINS_FOR_RESULT:
            return None
        return round(sum(abs(1.0 - r) for r in filled) / len(filled) * 100.0, 1)

    def slices(self) -> list[tuple[float, float, float]]:
        """(start angle rad, end angle rad, reached radius) of each visited slice, for drawing."""
        step = 2 * math.pi / self.bins
        return [(i * step, (i + 1) * step, r) for i, r in enumerate(self.max_r) if r > 0]


def drift(x: float, y: float) -> float:
    return round(math.hypot(x, y), 4)


@dataclass
class DeviceState:
    """One controller as the gamepad thread reports it (see GamepadMonitor._snapshot)."""

    index: int = 0
    instance_id: int = -1
    name: str = ""
    guid: str = ""
    vendor: int = 0
    product: int = 0
    product_version: int = 0
    serial: str = ""
    type_id: int = 0
    is_controller: bool = False
    mapping: str = ""
    player_index: int = -1
    power: int = -1
    rumble: bool = False
    trigger_rumble: bool = False
    led: bool = False
    buttons: list = field(default_factory=list)          # raw joystick buttons (0/1)
    axes: list = field(default_factory=list)             # raw joystick axes (int16)
    hats: list = field(default_factory=list)
    gc_buttons: dict = field(default_factory=dict)       # GC_BUTTONS name -> pressed
    gc_axes: dict = field(default_factory=dict)          # GC_AXES name -> int16

    @classmethod
    def from_dict(cls, d: dict) -> "DeviceState":
        known = {k: v for k, v in (d or {}).items() if k in cls.__dataclass_fields__}
        return cls(**known)

    @property
    def type_label(self) -> str:
        return CONTROLLER_TYPES.get(self.type_id, "Không rõ")

    @property
    def vid_pid(self) -> str:
        return f"{self.vendor:04X}:{self.product:04X}" if self.vendor or self.product else "—"

    def stick(self, side: str) -> tuple[float, float]:
        """(x, y) of the "left" / "right" stick, -1..1 (y down), from the game-controller mapping when there is one."""
        if self.is_controller and self.gc_axes:
            xs, ys = ("LeftX", "LeftY") if side == "left" else ("RightX", "RightY")
            return axis_value(self.gc_axes.get(xs, 0)), axis_value(self.gc_axes.get(ys, 0))
        base = 0 if side == "left" else 2
        ax = self.axes
        return (axis_value(ax[base]) if len(ax) > base else 0.0, axis_value(ax[base + 1]) if len(ax) > base + 1 else 0.0)

    def trigger(self, side: str) -> float:
        name = "TriggerLeft" if side == "left" else "TriggerRight"
        if self.is_controller and name in self.gc_axes:
            return trigger_value(self.gc_axes[name])
        return 0.0

    def pressed_count(self) -> int:
        return sum(1 for b in self.buttons if b)
