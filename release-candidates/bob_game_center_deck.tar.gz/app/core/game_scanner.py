"""
Windows game scanner for Bob Gaming Game Center.
Detects installed non-Steam games from Registry, Epic Games, and GOG.
"""

import os
import json
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Try to import winreg (Windows only)
try:
    import winreg
    HAS_WINREG = True
except ImportError:
    HAS_WINREG = False

# Keywords in DisplayName that indicate non-game software
EXCLUDE_NAME_KEYWORDS = [
    "driver", "redistributable", "redist", "runtime", "framework",
    "update", "hotfix", "service pack", "sdk", "toolkit",
    "microsoft visual c++", "microsoft .net", ".net framework",
    "directx", "vulkan", "openal", "physx", "battleye", "easyanticheat",
    "anti-cheat", "visual studio", "python", "node.js", "java ",
    "adobe", "office", "microsoft office", "onedrive", "teams",
    "chrome", "firefox", "edge", "opera", "brave browser",
    "7-zip", "winrar", "notepad", "vlc", "obs studio",
    "nvidia", "amd software", "intel ", "realtek",
    "bonjour", "apple software update", "itunes",
    "discord", "slack", "zoom", "telegram", "whatsapp",
    "git ", "github", "docker", "virtualbox", "vmware",
    "ccleaner", "malwarebytes", "avast", "kaspersky", "norton",
    "logitech", "corsair", "razer", "steelseries",
    "microsoft edge", "microsoft teams", "microsoft 365",
]

# Publishers that are almost never game publishers
EXCLUDE_PUBLISHERS = [
    "microsoft corporation", "microsoft", "intel corporation", "intel",
    "nvidia corporation", "nvidia", "advanced micro devices", "amd",
    "realtek", "hewlett-packard", "hp inc.", "dell", "lenovo",
    "google llc", "google inc.", "mozilla", "adobe", "apple inc.",
    "oracle", "vmware", "broadcom", "qualcomm", "logitech",
    "corsair", "razer inc.", "steelseries",
]

# Known game publishers (excluding Valve/Steam)
KNOWN_GAME_PUBLISHERS = [
    "electronic arts", "ea ", "ubisoft", "cd projekt",
    "bethesda", "rockstar games", "2k", "2k games", "square enix",
    "capcom", "bandai namco", "sega", "konami", "activision",
    "blizzard", "riot games", "epic games", "devolver digital",
    "team17", "paradox interactive", "focus entertainment",
    "thq nordic", "deep silver", "gog.com", "humble bundle",
    "fromsoftware", "techland", "id software", "obsidian",
    "insomniac", "naughty dog", "guerrilla", "kojima",
    "platinum games", "atlus", "koei tecmo", "snk",
    "gearbox", "telltale", "double fine", "supergiant",
    "klei entertainment", "re-logic", "mojang",
    "coffee stain", "warhorse", "larian studios",
]

# Path fragments suggesting a game install (excludes Steam paths)
GAME_PATH_INDICATORS = [
    "gog games", "epic games",
    "origin games", "ea games", "ubisoft", "riot games",
    "battle.net", "blizzard", "games",
]

# Steam-related indicators for exclusion
STEAM_INDICATORS = [
    "steamapps", "steam\\steamapps", "\\steam\\",
    "steam/steamapps", "/steam/",
]

# Registry paths to scan
REGISTRY_PATHS = []
if HAS_WINREG:
    REGISTRY_PATHS = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]


def _get_reg_value(key, value_name: str) -> Optional[str]:
    """Safely read a registry value."""
    try:
        value, _ = winreg.QueryValueEx(key, value_name)
        return str(value).strip() if value else None
    except (FileNotFoundError, OSError):
        return None


def _scan_registry() -> list[dict]:
    """Scan Windows Registry for installed programs."""
    if not HAS_WINREG:
        return []

    programs = []
    for hive, path in REGISTRY_PATHS:
        try:
            key = winreg.OpenKey(hive, path)
        except FileNotFoundError:
            continue

        try:
            subkey_count = winreg.QueryInfoKey(key)[0]
            for i in range(subkey_count):
                try:
                    subkey_name = winreg.EnumKey(key, i)

                    # Quick skip: Steam games use 'Steam App XXXXX' as key
                    if subkey_name.lower().startswith("steam app"):
                        continue

                    subkey = winreg.OpenKey(key, subkey_name)
                    try:
                        name = _get_reg_value(subkey, "DisplayName")
                        if not name:
                            continue

                        # Quick skip: check name against exclusion keywords early
                        name_lower = name.lower()
                        excluded = False
                        for keyword in EXCLUDE_NAME_KEYWORDS:
                            if keyword in name_lower:
                                excluded = True
                                break
                        if excluded:
                            continue

                        # Skip system components
                        try:
                            sys_comp, _ = winreg.QueryValueEx(subkey, "SystemComponent")
                            if sys_comp == 1:
                                continue
                        except (FileNotFoundError, OSError):
                            pass

                        display_icon = _get_reg_value(subkey, "DisplayIcon")
                        exe_path = ""
                        if display_icon:
                            candidate = display_icon.split(",")[0].strip('"').strip()
                            if candidate.lower().endswith(".exe") and os.path.isfile(candidate):
                                exe_path = os.path.normpath(candidate)

                        install_location = _get_reg_value(subkey, "InstallLocation") or ""
                        if not install_location and exe_path:
                            install_location = os.path.dirname(exe_path)

                        programs.append({
                            "name": name,
                            "install_location": install_location,
                            "publisher": _get_reg_value(subkey, "Publisher") or "",
                            "source": "registry",
                            "registry_key": subkey_name,
                            "exe_path": exe_path,
                        })
                    finally:
                        winreg.CloseKey(subkey)
                except OSError:
                    continue
        finally:
            winreg.CloseKey(key)

    return programs


def _scan_epic_games() -> list[dict]:
    """Scan Epic Games Store manifests for installed games."""
    manifest_dir = os.path.join(
        os.environ.get("PROGRAMDATA", r"C:\ProgramData"),
        "Epic", "EpicGamesLauncher", "Data", "Manifests"
    )

    games = []
    if not os.path.isdir(manifest_dir):
        return games

    for filename in os.listdir(manifest_dir):
        if not filename.endswith(".item"):
            continue
        filepath = os.path.join(manifest_dir, filename)
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)

            name = data.get("DisplayName", "")
            install_loc = data.get("InstallLocation", "")
            launch_exe = data.get("LaunchExecutable", "")
            exe_path = ""
            if launch_exe and install_loc:
                candidate = os.path.normpath(os.path.join(install_loc, launch_exe))
                if os.path.isfile(candidate):
                    exe_path = candidate

            if name and install_loc and os.path.isdir(install_loc):
                games.append({
                    "name": name,
                    "install_location": install_loc,
                    "publisher": "Epic Games Store",
                    "source": "epic",
                    "exe_path": exe_path,
                })
        except (json.JSONDecodeError, OSError) as e:
            logger.debug(f"Failed to parse Epic manifest {filename}: {e}")

    return games


def _scan_gog_games() -> list[dict]:
    """Scan GOG Galaxy registry entries for installed games."""
    if not HAS_WINREG:
        return []

    games = []
    gog_path = r"SOFTWARE\WOW6432Node\GOG.com\Games"

    try:
        gog_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, gog_path)
        try:
            subkey_count = winreg.QueryInfoKey(gog_key)[0]
            for i in range(subkey_count):
                try:
                    game_id = winreg.EnumKey(gog_key, i)
                    game_key = winreg.OpenKey(gog_key, game_id)
                    try:
                        game_name = _get_reg_value(game_key, "GAMENAME") or _get_reg_value(game_key, "gameName")
                        game_path = _get_reg_value(game_key, "PATH") or _get_reg_value(game_key, "path")
                        gog_exe = _get_reg_value(game_key, "EXE") or _get_reg_value(game_key, "exe")
                        exe_path = ""
                        if gog_exe and game_path:
                            candidate = os.path.normpath(os.path.join(game_path, gog_exe)) if not os.path.isabs(gog_exe) else gog_exe
                            if os.path.isfile(candidate):
                                exe_path = candidate

                        if game_name and game_path:
                            games.append({
                                "name": game_name,
                                "install_location": game_path,
                                "publisher": "GOG.com",
                                "source": "gog",
                                "exe_path": exe_path,
                            })
                    finally:
                        winreg.CloseKey(game_key)
                except OSError:
                    continue
        finally:
            winreg.CloseKey(gog_key)
    except FileNotFoundError:
        pass

    return games


def _is_steam_game(program: dict) -> bool:
    """Check if a program is a Steam game (to be excluded)."""
    name_lower = program.get("name", "").lower()
    publisher_lower = program.get("publisher", "").lower()
    install_path_lower = program.get("install_location", "").lower()
    registry_key = program.get("registry_key", "").lower()

    # Check registry key (Steam games use 'Steam App XXXXX' as key)
    if registry_key.startswith("steam app"):
        return True

    # Check publisher
    if "valve" in publisher_lower and ("steam" in name_lower or "steamapps" in install_path_lower):
        return True

    # Check install path for Steam directories
    for indicator in STEAM_INDICATORS:
        if indicator in install_path_lower:
            return True

    return False


def _is_likely_game(program: dict) -> bool:
    """Heuristic filter to determine if a program is likely a non-Steam game."""
    name_lower = program.get("name", "").lower()
    publisher_lower = program.get("publisher", "").lower()
    install_path_lower = program.get("install_location", "").lower()

    # --- STEAM EXCLUSION (must come first) ---
    if _is_steam_game(program):
        return False

    # --- EXCLUSION CHECKS ---
    for keyword in EXCLUDE_NAME_KEYWORDS:
        if keyword in name_lower:
            return False

    for pub in EXCLUDE_PUBLISHERS:
        if pub == publisher_lower or publisher_lower.startswith(pub):
            return False

    # --- INCLUSION CHECKS ---
    # Check install path for game-related directories
    for indicator in GAME_PATH_INDICATORS:
        if indicator in install_path_lower:
            return True

    # Check for known game publishers
    for pub in KNOWN_GAME_PUBLISHERS:
        if pub in publisher_lower:
            return True

    return False


def _deduplicate(games: list[dict]) -> list[dict]:
    """Remove duplicate games by normalized name, prioritizing real executables."""
    seen: dict[str, dict] = {}
    for game in games:
        key = game["name"].lower().strip()
        if key not in seen:
            seen[key] = dict(game)
        else:
            existing = seen[key]
            old_exe = existing.get("exe_path", "")
            new_exe = game.get("exe_path", "")
            # Prefer valid game executable over uninstaller or missing exe
            if new_exe and (not old_exe or "unins" in old_exe.lower()):
                existing["exe_path"] = new_exe
                if game.get("source"):
                    existing["source"] = game["source"]
            if not existing.get("install_location") and game.get("install_location"):
                existing["install_location"] = game["install_location"]
    return list(seen.values())


def _is_installed(game: dict) -> bool:
    """Check if the game is actually installed (install directory or exe exists)."""
    install_loc = game.get("install_location", "").strip()
    exe_path = game.get("exe_path", "").strip()

    # If exe_path exists on disk, it's definitely installed
    if exe_path and os.path.isfile(exe_path):
        return True

    # If no install location, can't verify — skip this game
    if not install_loc:
        return False

    # Check if the install directory exists
    if os.path.isdir(install_loc):
        return True

    # Check if it's a file path (e.g., exe path)
    if os.path.isfile(install_loc):
        return True

    return False


def scan_steam_shortcuts() -> list[dict]:
    """
    Scan Non-Steam game shortcuts from Steam's shortcuts.vdf across all user profiles.
    These are Non-Steam games added to Steam by the user.
    """
    try:
        from app.core.steam_manager import get_all_steam_shortcuts, find_steam_path
        steam_path = find_steam_path()
        if not steam_path:
            return []

        shortcuts = get_all_steam_shortcuts(steam_path)
        games = []
        for s in shortcuts:
            name = s.get("appname", "").strip()
            raw_exe = s.get("exe", "").strip()
            clean_exe = raw_exe.strip('"').strip()
            raw_start = s.get("StartDir", "").strip()
            clean_start = raw_start.strip('"').strip()

            if not name:
                continue

            if not clean_start and clean_exe:
                clean_start = os.path.dirname(clean_exe)

            # Check if installed on disk
            is_valid_exe = bool(clean_exe and os.path.isfile(clean_exe))
            is_valid_dir = bool(clean_start and os.path.isdir(clean_start))

            if not is_valid_exe and not is_valid_dir:
                continue

            games.append({
                "name": name,
                "install_location": clean_start,
                "publisher": "Non-Steam",
                "source": "steam_shortcut",
                "exe_path": clean_exe if is_valid_exe else "",
            })
        return games
    except Exception as e:
        logger.error(f"Error scanning Steam shortcuts: {e}")
        return []


def scan_all_games() -> list[dict]:
    """
    Master scan function: scan all sources and return deduplicated game list.

    Returns:
        List of game dicts with keys: name, install_location, publisher, source
    """
    logger.info("Starting game scan...")
    all_games = []

    # 1. Registry scan (filtered for games)
    try:
        registry_programs = _scan_registry()
        registry_games = [p for p in registry_programs if _is_likely_game(p)]
        logger.info(f"Registry: found {len(registry_games)} games from {len(registry_programs)} programs")
        all_games.extend(registry_games)
    except Exception as e:
        logger.error(f"Registry scan failed: {e}")

    # 2. Epic Games
    try:
        epic_games = _scan_epic_games()
        logger.info(f"Epic Games: found {len(epic_games)} games")
        all_games.extend(epic_games)
    except Exception as e:
        logger.error(f"Epic Games scan failed: {e}")

    # 3. GOG Galaxy
    try:
        gog_games = _scan_gog_games()
        logger.info(f"GOG: found {len(gog_games)} games")
        all_games.extend(gog_games)
    except Exception as e:
        logger.error(f"GOG scan failed: {e}")

    # 4. Steam Non-Steam Shortcuts (shortcuts.vdf)
    try:
        shortcut_games = scan_steam_shortcuts()
        logger.info(f"Steam Shortcuts: found {len(shortcut_games)} non-Steam games")
        all_games.extend(shortcut_games)
    except Exception as e:
        logger.error(f"Steam shortcuts scan failed: {e}")

    # Filter out games whose install location no longer exists
    installed_games = [g for g in all_games if _is_installed(g)]
    logger.info(f"After install check: {len(installed_games)} of {len(all_games)} still installed")

    # Deduplicate and sort
    unique_games = _deduplicate(installed_games)

    # Auto-detect executable for games where exe_path was not directly found
    try:
        from app.core.steam_manager import find_game_executable
        for g in unique_games:
            if not g.get("exe_path") and g.get("install_location") and os.path.isdir(g["install_location"]):
                auto_exe = find_game_executable(g["install_location"], g["name"])
                if auto_exe:
                    g["exe_path"] = auto_exe
    except Exception as e:
        logger.debug(f"Error auto-detecting executables during scan: {e}")

    unique_games.sort(key=lambda g: g["name"].lower())

    logger.info(f"Total unique games found: {len(unique_games)}")
    return unique_games


def scan_steam_games() -> list[dict]:
    """Scan for Steam games from the Windows Registry."""
    if not HAS_WINREG:
        return []

    steam_games = []

    for hive, path in REGISTRY_PATHS:
        try:
            key = winreg.OpenKey(hive, path)
        except FileNotFoundError:
            continue

        try:
            subkey_count = winreg.QueryInfoKey(key)[0]
            for i in range(subkey_count):
                try:
                    subkey_name = winreg.EnumKey(key, i)

                    # Only look for Steam App keys
                    if not subkey_name.lower().startswith("steam app"):
                        continue

                    subkey = winreg.OpenKey(key, subkey_name)
                    try:
                        name = _get_reg_value(subkey, "DisplayName")
                        if not name:
                            continue

                        # Skip known non-game Steam entries
                        name_lower = name.lower()
                        skip = False
                        for kw in ["redistributable", "redist", "proton", "steamworks",
                                   "steam linux runtime", "directx", "vcredist"]:
                            if kw in name_lower:
                                skip = True
                                break
                        if skip:
                            continue

                        install_loc = _get_reg_value(subkey, "InstallLocation") or ""
                        publisher = _get_reg_value(subkey, "Publisher") or "Steam"

                        steam_games.append({
                            "name": name,
                            "install_location": install_loc,
                            "publisher": publisher,
                            "source": "steam",
                        })
                    finally:
                        winreg.CloseKey(subkey)
                except OSError:
                    continue
        finally:
            winreg.CloseKey(key)

    unique = _deduplicate(steam_games)
    unique.sort(key=lambda g: g["name"].lower())
    return unique

