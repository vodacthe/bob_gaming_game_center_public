"""
Steam binary VDF (shortcuts.vdf) parser and serializer for Bob Gaming Game Center.
Pure Python implementation with no external binary dependencies.
"""

import logging
import os
import shutil
import struct
import time
import zlib

TAG = "[Steam/VDF]"
logger = logging.getLogger(__name__)

TYPE_NONE = 0   # Sub-map / child object
TYPE_STRING = 1 # Null-terminated string
TYPE_INT32 = 2  # 32-bit signed integer (little-endian)
TYPE_END = 8    # End of sub-map


def parse_binary_vdf(data: bytes, pos: int = 0) -> tuple[dict, int]:
    """
    Parse Steam binary KeyValues (VDF) buffer into a nested dictionary.

    Returns:
        (parsed_dict, next_position)
    """
    res = {}
    data_len = len(data)
    while pos < data_len:
        type_byte = data[pos]
        pos += 1
        if type_byte == TYPE_END:
            break

        # Read null-terminated key
        key_end = data.find(b"\x00", pos)
        if key_end == -1:
            break
        key = data[pos:key_end].decode("utf-8", errors="replace")
        pos = key_end + 1

        if type_byte == TYPE_NONE:
            val, pos = parse_binary_vdf(data, pos)
            res[key] = val
        elif type_byte == TYPE_STRING:
            val_end = data.find(b"\x00", pos)
            if val_end == -1:
                val = data[pos:].decode("utf-8", errors="replace")
                pos = data_len
            else:
                val = data[pos:val_end].decode("utf-8", errors="replace")
                pos = val_end + 1
            res[key] = val
        elif type_byte == TYPE_INT32:
            if pos + 4 <= data_len:
                val = struct.unpack("<i", data[pos:pos + 4])[0]
                pos += 4
            else:
                val = 0
                pos = data_len
            res[key] = val
        else:
            # Unsupported or unknown type, stop to avoid corruption
            logger.warning(f"{TAG} Unknown VDF type byte: {type_byte} at position {pos - 1}")
            break

    return res, pos


def serialize_binary_vdf(data: dict) -> bytes:
    """
    Serialize a Python dictionary into Steam binary KeyValues (VDF) bytes.
    """
    out = bytearray()
    for key, val in data.items():
        key_bytes = str(key).encode("utf-8") + b"\x00"
        if isinstance(val, dict):
            out.append(TYPE_NONE)
            out.extend(key_bytes)
            out.extend(serialize_binary_vdf(val))
            out.append(TYPE_END)
        elif isinstance(val, str):
            out.append(TYPE_STRING)
            out.extend(key_bytes)
            out.extend(val.encode("utf-8") + b"\x00")
        elif isinstance(val, (int, bool)):
            out.append(TYPE_INT32)
            out.extend(key_bytes)
            int_val = int(val)
            # Ensure signed 32-bit integer range
            if int_val > 0x7FFFFFFF:
                int_val -= 0x100000000
            elif int_val < -0x80000000:
                int_val = int_val & 0xFFFFFFFF
                if int_val > 0x7FFFFFFF:
                    int_val -= 0x100000000
            out.extend(struct.pack("<i", int_val))
    return bytes(out)


class AppIDResult:
    """
    Container for Steam shortcut AppID representations.
    Supports unpacking as either 3 items (signed_id, uint_id, str_id) for legacy compatibility
    or 4 items (signed_id, uint_id, long_id, str_id), as well as direct attribute access.
    """

    def __init__(self, signed_id: int, uint_id: int, str_id: str, long_id: int):
        self.signed_id = signed_id
        self.uint_id = uint_id
        self.str_id = str_id
        self.long_id = long_id
        self._3 = (signed_id, uint_id, str_id)
        self._4 = (signed_id, uint_id, long_id, str_id)

    @property
    def long_appid(self) -> int:
        return self.long_id

    def __iter__(self):
        try:
            import dis
            import sys
            f = sys._getframe(1)
            for inst in dis.get_instructions(f.f_code):
                if inst.offset >= f.f_lasti:
                    if inst.opname == "UNPACK_SEQUENCE":
                        if inst.argval == 4:
                            return iter(self._4)
                        elif inst.argval == 3:
                            return iter(self._3)
                    elif inst.opname == "UNPACK_EX":
                        return iter(self._4)
                    break
        except Exception:
            pass
        return iter(self._3)

    def __getitem__(self, idx: int):
        if idx == 3:
            return self.str_id
        return self._3[idx]

    def __len__(self) -> int:
        return 3

    def __eq__(self, other) -> bool:
        if isinstance(other, (tuple, list)):
            if len(other) == 4:
                return self._4 == tuple(other)
            return self._3 == tuple(other)
        return False

    def __repr__(self) -> str:
        return (
            f"AppIDResult(signed_id={self.signed_id}, uint_id={self.uint_id}, "
            f"long_id={self.long_id}, str_id={self.str_id!r})"
        )


def calculate_long_appid(uint_appid: int) -> int:
    """Convert unsigned 32-bit shortcut AppID to 64-bit Steam CGameID."""
    return ((int(uint_appid) & 0xFFFFFFFF) << 32) | 0x02000000


def calculate_shortcut_appid(
    exe: str,
    app_name: str,
    include_long: bool = False,
) -> AppIDResult | tuple[int, int, int, str]:
    """
    Generate Steam shortcut AppID from executable path and app name.

    Formula:
        target = f'"{clean_exe}"{app_name}'
        crc = crc32(target) | 0x80000000
        long_id = (uint_id << 32) | 0x02000000

    Returns:
        AppIDResult supporting 3-unpack (signed, uint, str), 4-unpack (signed, uint, long, str),
        or explicit 4-tuple if include_long is True.
    """
    clean_exe = exe.strip('"')
    target = f'"{clean_exe}"{app_name}'
    crc = zlib.crc32(target.encode("utf-8"))
    uint_id = (crc | 0x80000000) & 0xFFFFFFFF
    signed_id = uint_id if uint_id < 0x80000000 else uint_id - 0x100000000
    long_id = calculate_long_appid(uint_id)

    if include_long:
        return signed_id, uint_id, long_id, str(uint_id)
    return AppIDResult(signed_id, uint_id, str(uint_id), long_id)


def backup_shortcuts_vdf(file_path: str) -> bool:
    """
    Safely create .bak backup copy of shortcuts.vdf if file exists and has content.

    Returns:
        True if backup copy was created, False otherwise.
    """
    try:
        if os.path.isfile(file_path) and os.path.getsize(file_path) > 0:
            bak_path = f"{file_path}.bak"
            shutil.copy2(file_path, bak_path)
            return True
        return False
    except Exception as e:
        logger.warning(f"{TAG} Could not create backup of {file_path}: {e}")
        return False


def load_shortcuts_vdf(file_path: str) -> dict:
    """
    Safely load shortcuts.vdf into a structured dictionary.
    Returns empty shortcuts template if file does not exist.
    Attempts recovery from .bak file if primary file is corrupted or empty.
    """
    if not os.path.exists(file_path):
        return {"shortcuts": {}}

    bak_path = f"{file_path}.bak"

    def _read_and_parse(target: str) -> dict | None:
        try:
            with open(target, "rb") as f:
                data = f.read()
            if not data:
                return None
            parsed, _ = parse_binary_vdf(data)
            if not isinstance(parsed, dict) or "shortcuts" not in parsed:
                return None
            return parsed
        except Exception as e:
            logger.warning(f"{TAG} Failed to load shortcuts from {target}: {e}")
            return None

    # Try primary file
    result = _read_and_parse(file_path)
    if result is not None:
        return result

    # Primary failed or 0 bytes: try recovering from backup if available
    if os.path.isfile(bak_path) and os.path.getsize(bak_path) > 0:
        logger.warning(
            f"{TAG} Primary shortcuts file {file_path} is empty or corrupted; "
            f"attempting recovery from {bak_path}"
        )
        bak_result = _read_and_parse(bak_path)
        if bak_result is not None:
            logger.info(f"{TAG} Successfully recovered shortcuts from backup {bak_path}")
            return bak_result

    return {"shortcuts": {}}


def save_shortcuts_vdf(file_path: str, shortcuts_data: dict, backup: bool = True) -> bool:
    """
    Serialize and save shortcuts dictionary to shortcuts.vdf with automatic backup and atomic fsync.

    Args:
        file_path: Target path to shortcuts.vdf.
        shortcuts_data: Dictionary conforming to {"shortcuts": {"0": {...}, "1": {...}}}.
        backup: Whether to create a .bak copy before writing.

    Returns:
        True on success, False otherwise.
    """
    t0 = time.perf_counter()
    temp_path = f"{file_path}.tmp"
    try:
        parent_dir = os.path.dirname(file_path)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)

        # Create backup if file exists and has content
        if backup:
            backup_shortcuts_vdf(file_path)

        # Serialize VDF: root object followed by TYPE_END terminator
        serialized = serialize_binary_vdf(shortcuts_data) + bytes([TYPE_END])

        # Write to temporary file with flush and fsync for crash-resilient atomic durability
        with open(temp_path, "wb") as f:
            f.write(serialized)
            f.flush()
            os.fsync(f.fileno())

        # Atomic replace
        os.replace(temp_path, file_path)
        dt = time.perf_counter() - t0
        shortcut_count = len(shortcuts_data.get("shortcuts", {})) if isinstance(shortcuts_data, dict) else 0
        logger.info(
            f"{TAG} Successfully saved {shortcut_count} shortcuts to {file_path} in {dt:.3f}s"
        )
        return True
    except Exception as e:
        logger.error(f"{TAG} Failed to save shortcuts.vdf to {file_path}: {e}", exc_info=True)
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                pass
        return False
