"""
Automatic Non-Steam shortcut registration and artwork downloader for Bob Gaming Game Center.
Adds newly installed games into Steam's shortcuts.vdf and downloads all SteamGridDB artwork assets
(poster, grid, hero, logo, icon) in the background without freezing the UI.
"""

import logging
import os
import shutil
import time
from typing import Optional

from PySide6.QtCore import QObject, Signal, Slot

from app.config import IMAGE_CACHE_DIR, STEAMGRIDB_API_KEY
from app.core.steam_artwork import download_and_apply_steam_artworks
from app.core.steam_manager import (
    add_non_steam_game,
    find_steam_path,
    get_grid_dir,
    is_steam_running,
)
from app.utils.helpers import sanitize_filename

logger = logging.getLogger(__name__)
TAG = "[Steam/AutoAdd]"


def auto_add_game_to_steam(
    game_name: str,
    exe_path: str,
    install_location: Optional[str] = None,
    launch_options: Optional[str] = None,
    steam_path: Optional[str] = None,
    user_ids: Optional[list[str]] = None,
    api_key: str = STEAMGRIDB_API_KEY,
) -> dict:
    """
    Core business logic to add a game to Steam shortcuts and download artwork.
    Runs synchronously (safe for background threads/workers).
    """
    start_time = time.monotonic()
    logger.info(f"{TAG} Starting auto Steam shortcut & artwork process for {game_name!r} (exe: {exe_path})")

    if not game_name or not exe_path:
        msg = "Missing game name or executable path."
        logger.warning(f"{TAG} Refused: {msg}")
        return {"success": False, "game_name": game_name, "message": msg}

    clean_exe = exe_path.strip('"')
    if not os.path.exists(clean_exe):
        msg = f"Executable path does not exist on disk: {clean_exe}"
        logger.warning(f"{TAG} Refused: {msg}")
        return {"success": False, "game_name": game_name, "message": msg}

    start_dir = install_location or os.path.dirname(clean_exe)

    # Detect if Online-Fix game and prepare launch options if not explicitly supplied
    if not launch_options:
        try:
            from app.core.online_fix.runner import detect_online_fix_game, prepare_online_fix_launch
            detection = detect_online_fix_game(start_dir)
            if detection.get("is_online_fix"):
                logger.info(f"{TAG} Detected Online-Fix title for {game_name!r}; preparing launch environment")
                app_id = detection.get("appid") or 480
                prep = prepare_online_fix_launch(start_dir, clean_exe, app_id=app_id)
                launch_options = prep.get("launch_options", "")
        except Exception as exc:
            logger.warning(f"{TAG} Error detecting/preparing Online-Fix launch options for {game_name!r}: {exc}")

    # 1. Add non-Steam game shortcut to shortcuts.vdf
    add_result = add_non_steam_game(
        game_name=game_name,
        exe_path=clean_exe,
        start_dir=start_dir,
        launch_options=launch_options or "",
        steam_path=steam_path,
        target_user_ids=user_ids,
    )


    if not add_result.get("success"):
        msg = add_result.get("message", "Failed to add game to Steam shortcuts.")
        logger.warning(f"{TAG} {msg}")
        return {
            "success": False,
            "game_name": game_name,
            "message": msg,
        }

    uint_appid = add_result["appid"]
    affected_users = add_result.get("affected_users", [])
    logger.info(f"{TAG} Successfully added shortcut for {game_name!r} (AppID: {uint_appid}) across {len(affected_users)} account(s)")

    # 2. Download and deploy artwork
    art_result = download_and_apply_steam_artworks(
        game_name=game_name,
        uint_appid=uint_appid,
        steam_path=steam_path,
        target_user_ids=affected_users or user_ids,
        api_key=api_key,
    )

    downloaded = art_result.get("downloaded", {})
    deployed_files = art_result.get("deployed_files_count", 0)
    logger.info(f"{TAG} Artwork download finished for {game_name!r}: {deployed_files} file(s) deployed, status: {downloaded}")

    # 3. Synchronize poster into local Bob Gaming Game Center cache if needed
    local_poster_path = ""
    resolved_steam_path = steam_path or find_steam_path()
    if resolved_steam_path and affected_users:
        first_uid = affected_users[0]
        grid_folder = get_grid_dir(resolved_steam_path, first_uid)
        sid = str(uint_appid)
        for ext in [".png", ".jpg", ".jpeg"]:
            steam_poster = os.path.join(grid_folder, f"{sid}p{ext}")
            if os.path.isfile(steam_poster):
                try:
                    os.makedirs(IMAGE_CACHE_DIR, exist_ok=True)
                    safe_title = sanitize_filename(game_name)
                    local_poster_path = os.path.join(IMAGE_CACHE_DIR, f"{safe_title}{ext}")
                    from app.core.image_cache import is_valid_cover_file
                    if not is_valid_cover_file(local_poster_path):
                        shutil.copy2(steam_poster, local_poster_path)
                        logger.info(f"{TAG} Copied Steam poster to local image cache: {local_poster_path}")
                    break
                except Exception as e:
                    logger.warning(f"{TAG} Could not copy poster to cache: {e}")

    elapsed = time.monotonic() - start_time
    steam_running = is_steam_running()
    logger.info(f"{TAG} Completed for {game_name!r} in {elapsed:.2f}s (Steam running: {steam_running})")

    return {
        "success": True,
        "game_name": game_name,
        "appid": uint_appid,
        "artworks": art_result,
        "poster_path": local_poster_path,
        "steam_running": steam_running,
        "steam_start_ts": add_result.get("steam_start_ts"),
        "message": f"Added {game_name!r} to Steam with {deployed_files} artwork file(s).",
    }


class SteamAutoAddWorker(QObject):
    """
    QObject worker running in a QThread to perform non-blocking Steam shortcut addition
    and artwork download.
    """

    finished = Signal(dict)

    def __init__(
        self,
        game_name: str,
        exe_path: str,
        install_location: Optional[str] = None,
        launch_options: Optional[str] = None,
        steam_path: Optional[str] = None,
        user_ids: Optional[list[str]] = None,
        parent: Optional[QObject] = None,
    ):
        super().__init__(parent)
        self.game_name = game_name
        self.exe_path = exe_path
        self.install_location = install_location
        self.launch_options = launch_options
        self.steam_path = steam_path
        self.user_ids = user_ids

    @Slot()
    def run(self):
        try:
            result = auto_add_game_to_steam(
                game_name=self.game_name,
                exe_path=self.exe_path,
                install_location=self.install_location,
                launch_options=self.launch_options,
                steam_path=self.steam_path,
                user_ids=self.user_ids,
            )

        except Exception as e:
            logger.exception(f"{TAG} Unexpected error while auto-adding {self.game_name!r} to Steam")
            result = {
                "success": False,
                "game_name": self.game_name,
                "message": f"Unexpected error: {e}",
            }
        self.finished.emit(result)
