"""
Steam artwork fetcher and deployer for Bob Gaming Game Center.
Downloads Poster, Grid, Hero, Logo, and Icon from SteamGridDB and Steam CDN,
and applies them to all Steam user profiles.
"""

import logging
import os
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote_plus

import requests

from app.config import STEAMGRIDB_API_KEY
from app.core.steam_manager import find_steam_path, get_grid_dir, get_steam_user_ids

logger = logging.getLogger(__name__)

USER_AGENT = "BobGamingGameCenter/1.0 (Windows)"


class SteamArtworkDownloader:
    """Fetches high quality artworks from SteamGridDB and Steam CDN."""

    def __init__(self, api_key: str = STEAMGRIDB_API_KEY):
        self.api_key = api_key
        self.sgdb = None
        if self.api_key:
            try:
                from steamgrid import SteamGridDB
                self.sgdb = SteamGridDB(self.api_key)
            except Exception as e:
                logger.warning(f"Could not initialize SteamGridDB: {e}")

    def fetch_artworks(
        self,
        game_name: str,
        progress_cb: Callable[[str, str], None] | None = None,
    ) -> dict[str, tuple[bytes, str] | None]:
        """
        Fetch all 5 Steam asset types for a given game.

        Returns:
            Dict mapping asset_type ('poster', 'grid', 'hero', 'logo', 'icon')
            to (bytes_content, extension_str) or None.
        """
        assets: dict[str, tuple | None] = {
            "poster": None,
            "grid": None,
            "hero": None,
            "logo": None,
            "icon": None,
        }

        # 1. Try SteamGridDB first
        if self.sgdb:
            try:
                if progress_cb:
                    progress_cb("search", f"Searching SteamGridDB for '{game_name}'...")
                results = self.sgdb.search_game(game_name)
                if results:
                    sgdb_game = results[0]
                    gid = sgdb_game.id
                    logger.info(f"[SteamArtwork] Found SteamGridDB game: {sgdb_game.name} (id={gid})")

                    def _fetch_grids():
                        res = {}
                        try:
                            grids = self.sgdb.get_grids_by_gameid(game_ids=[gid])
                            if grids:
                                portraits = [g for g in grids if getattr(g, "height", 0) > getattr(g, "width", 0)]
                                landscapes = [g for g in grids if getattr(g, "width", 0) > getattr(g, "height", 0)]
                                if portraits:
                                    res["poster"] = self._download_best_asset(portraits, "poster", progress_cb)
                                if landscapes:
                                    res["grid"] = self._download_best_asset(landscapes, "grid", progress_cb)
                        except Exception as e:
                            logger.warning(f"[SteamArtwork] Error fetching grids: {e}")
                        return res

                    def _fetch_heroes():
                        res = {}
                        try:
                            heroes = self.sgdb.get_heroes_by_gameid(game_ids=[gid])
                            if heroes:
                                res["hero"] = self._download_best_asset(heroes, "hero", progress_cb)
                        except Exception as e:
                            logger.warning(f"[SteamArtwork] Error fetching heroes: {e}")
                        return res

                    def _fetch_logos():
                        res = {}
                        try:
                            logos = self.sgdb.get_logos_by_gameid(game_ids=[gid])
                            if logos:
                                res["logo"] = self._download_best_asset(logos, "logo", progress_cb)
                        except Exception as e:
                            logger.warning(f"[SteamArtwork] Error fetching logos: {e}")
                        return res

                    def _fetch_icons():
                        res = {}
                        try:
                            icons = self.sgdb.get_icons_by_gameid(game_ids=[gid])
                            if icons:
                                res["icon"] = self._download_best_asset(icons, "icon", progress_cb)
                        except Exception as e:
                            logger.warning(f"[SteamArtwork] Error fetching icons: {e}")
                        return res

                    # Run all 4 asset category fetches in parallel
                    with ThreadPoolExecutor(max_workers=4) as sgdb_pool:
                        fetch_tasks = [
                            sgdb_pool.submit(_fetch_grids),
                            sgdb_pool.submit(_fetch_heroes),
                            sgdb_pool.submit(_fetch_logos),
                            sgdb_pool.submit(_fetch_icons),
                        ]
                        for f in as_completed(fetch_tasks):
                            try:
                                partial = f.result()
                                assets.update(partial)
                            except Exception as e:
                                logger.error(f"[SteamArtwork] Concurrent fetch error: {e}")

            except Exception as e:
                logger.warning(f"[SteamArtwork] SteamGridDB search error: {e}")

        # 2. Fallback to Steam CDN for any missing assets
        missing = [k for k, v in assets.items() if v is None]
        if missing:
            try:
                cdn_assets = self._fetch_from_steam_cdn(game_name, missing, progress_cb)
                for k, v in cdn_assets.items():
                    if assets.get(k) is None and v is not None:
                        assets[k] = v
            except Exception as e:
                logger.warning(f"[SteamArtwork] Steam CDN fallback error: {e}")

        return assets

    def _download_best_asset(
        self,
        candidates: list,
        asset_type: str,
        progress_cb: Callable[[str, str], None] | None = None,
    ) -> tuple | None:
        """Download the first static candidate image."""
        for item in candidates:
            url = getattr(item, "url", "")
            if not url or url.endswith(".webm") or url.endswith(".gif"):
                continue

            try:
                if progress_cb:
                    progress_cb(asset_type, f"Downloading {asset_type}...")
                resp = requests.get(url, timeout=12, headers={"User-Agent": USER_AGENT})
                if resp.status_code == 200 and len(resp.content) > 500:
                    content_type = resp.headers.get("content-type", "")
                    ext = ".png" if "png" in content_type else ".ico" if "icon" in content_type else ".jpg"
                    if url.endswith(".ico"):
                        ext = ".ico"
                    return resp.content, ext
            except Exception as e:
                logger.warning(f"Download failed for {url}: {e}")
                continue
        return None

    def _fetch_from_steam_cdn(
        self,
        game_name: str,
        needed_types: list[str],
        progress_cb: Callable[[str, str], None] | None = None,
    ) -> dict[str, tuple | None]:
        """Fetch missing assets using official Steam Store search and CDN concurrently."""
        res: dict[str, tuple | None] = {}
        try:
            search_url = f"https://store.steampowered.com/api/storesearch/?term={quote_plus(game_name)}&l=en&cc=US"
            resp = requests.get(search_url, timeout=10, headers={"User-Agent": USER_AGENT})
            if resp.status_code != 200:
                return res

            items = resp.json().get("items", [])
            if not items:
                return res

            appid = items[0]["id"]
            # Look for exact match if possible
            for it in items:
                if it.get("name", "").lower() == game_name.lower():
                    appid = it["id"]
                    break

            cdn_map = {
                "poster": [
                    f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_600x900_2x.jpg",
                    f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_600x900.jpg",
                ],
                "grid": [
                    f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/header.jpg",
                ],
                "hero": [
                    f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_hero.jpg",
                ],
                "logo": [
                    f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/logo.png",
                ],
            }

            def _fetch_cdn_type(asset_type):
                urls = cdn_map.get(asset_type, [])
                for url in urls:
                    try:
                        if progress_cb:
                            progress_cb(asset_type, f"Downloading official {asset_type}...")
                        r = requests.get(url, timeout=10, headers={"User-Agent": USER_AGENT})
                        if r.status_code == 200 and len(r.content) > 1000:
                            content_type = r.headers.get("content-type", "")
                            ext = ".png" if "png" in content_type else ".jpg"
                            return asset_type, (r.content, ext)
                    except Exception:
                        continue
                return asset_type, None

            with ThreadPoolExecutor(max_workers=min(4, len(needed_types))) as pool:
                for k, v in pool.map(_fetch_cdn_type, needed_types):
                    if v is not None:
                        res[k] = v

        except Exception as e:
            logger.warning(f"Steam CDN search error for {game_name}: {e}")

        return res


def download_and_apply_steam_artworks(
    game_name: str,
    uint_appid: int,
    steam_path: str | None = None,
    target_user_ids: list[str] | None = None,
    api_key: str = STEAMGRIDB_API_KEY,
    progress_callback: Callable[[str, str], None] | None = None,
) -> dict:
    """
    Download and deploy all 5 Steam artwork assets to all specified Steam profiles.

    Filenames written to Steam's grid folder:
      - Poster: <appid>p.png / .jpg
      - Grid:   <appid>.png / .jpg
      - Hero:   <appid>_hero.png / .jpg
      - Logo:   <appid>_logo.png
      - Icon:   <appid>_icon.png / .ico

    Returns summary dict.
    """
    if not steam_path:
        steam_path = find_steam_path()
    if not steam_path:
        return {"success": False, "message": "Steam directory not found."}

    user_ids = target_user_ids or get_steam_user_ids(steam_path)
    if not user_ids:
        return {"success": False, "message": "No Steam user accounts found."}

    downloader = SteamArtworkDownloader(api_key=api_key)
    artworks = downloader.fetch_artworks(game_name, progress_cb=progress_callback)

    sid = str(uint_appid)
    downloaded_status = {k: bool(v) for k, v in artworks.items()}
    deployed_count = 0

    suffix_map = {
        "poster": "p",
        "grid": "",
        "hero": "_hero",
        "logo": "_logo",
        "icon": "_icon",
    }

    for uid in user_ids:
        grid_dir = get_grid_dir(steam_path, uid)

        for asset_type, asset_data in artworks.items():
            if not asset_data:
                continue

            content, ext = asset_data
            suffix = suffix_map[asset_type]
            target_filename = f"{sid}{suffix}{ext}"
            target_path = os.path.join(grid_dir, target_filename)

            # Remove conflicting opposite extension file (e.g. remove old .jpg if writing .png)
            alt_exts = [".jpg", ".png", ".ico", ".jpeg"]
            for alt in alt_exts:
                if alt != ext:
                    old_path = os.path.join(grid_dir, f"{sid}{suffix}{alt}")
                    if os.path.exists(old_path):
                        try:
                            os.remove(old_path)
                        except OSError:
                            pass

            try:
                with open(target_path, "wb") as f:
                    f.write(content)
                deployed_count += 1
            except OSError as e:
                logger.error(f"Failed to write artwork {target_path}: {e}")

    success = any(downloaded_status.values())
    if progress_callback:
        progress_callback("complete", "All artworks processed.")

    return {
        "success": success,
        "game_name": game_name,
        "uint_appid": uint_appid,
        "downloaded": downloaded_status,
        "affected_users": user_ids,
        "deployed_files_count": deployed_count,
    }
