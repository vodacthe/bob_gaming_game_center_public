"""
App configuration and constants for Bob Gaming Game Center.
"""

import os
import json
import base64
import logging
import sys
from logging.handlers import RotatingFileHandler
from app.core.secret_mask import decrypt

logger = logging.getLogger(__name__)

def get_documents_dir() -> str:
    """Get the user's Documents folder path across platforms."""
    if sys.platform == "win32":
        try:
            import ctypes.wintypes
            buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
            # CSIDL_PERSONAL = 5 (My Documents)
            if ctypes.windll.shell32.SHGetFolderPathW(None, 5, None, 0, buf) == 0 and buf.value:
                return buf.value
        except Exception:
            pass
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    if os.path.exists(docs):
        return docs
    return os.path.expanduser("~")


OLD_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".bobgaming")
DOCUMENTS_DIR = get_documents_dir()
CONFIG_DIR = os.path.join(DOCUMENTS_DIR, "Bob Gaming", "GameCenter")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
CONFIG_BAK_FILE = os.path.join(CONFIG_DIR, "config.json.bak")
CACHE_DIR = os.path.join(CONFIG_DIR, "cache")
IMAGE_CACHE_DIR = os.path.join(CACHE_DIR, "images")
LOG_FILE = os.path.join(CONFIG_DIR, "app.log")
CRASH_LOG_FILE = os.path.join(CONFIG_DIR, "crash.log")

# Nextcloud folder structure
CLOUD_ROOT_FOLDER = "BobGamingGameCenter"


def migrate_old_config_if_needed(old_dir: str = OLD_CONFIG_DIR, new_dir: str = CONFIG_DIR):
    """Migrate config, cache, tokens, logs, and state files from old_dir to new_dir, then delete old_dir."""
    if not os.path.exists(old_dir) or not os.path.isdir(old_dir):
        return
    if os.path.abspath(old_dir).lower() == os.path.abspath(new_dir).lower():
        return

    import shutil

    try:
        os.makedirs(new_dir, exist_ok=True)
        for item in os.listdir(old_dir):
            src_path = os.path.join(old_dir, item)
            dst_path = os.path.join(new_dir, item)

            try:
                if os.path.isdir(src_path):
                    if not os.path.exists(dst_path):
                        shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
                    else:
                        for sub_root, _, sub_files in os.walk(src_path):
                            rel = os.path.relpath(sub_root, src_path)
                            target_sub = os.path.join(dst_path, rel)
                            os.makedirs(target_sub, exist_ok=True)
                            for f in sub_files:
                                sf = os.path.join(sub_root, f)
                                df = os.path.join(target_sub, f)
                                if not os.path.exists(df):
                                    shutil.copy2(sf, df)
                    shutil.rmtree(src_path, ignore_errors=True)
                else:
                    if not os.path.exists(dst_path):
                        shutil.copy2(src_path, dst_path)
                    try:
                        os.remove(src_path)
                    except OSError:
                        pass
            except Exception as e:
                logger.warning(f"Error migrating {item}: {e}")

        # Sanitize migrated config.json if needed
        migrated_config_file = os.path.join(new_dir, "config.json")
        if os.path.exists(migrated_config_file):
            try:
                with open(migrated_config_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if data.get("cloud_url") == "https://drive.vdthe.com":
                    data["cloud_url"] = ""
                    with open(migrated_config_file, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
            except Exception:
                pass

        # Remove old directory
        try:
            shutil.rmtree(old_dir, ignore_errors=True)
            if os.path.exists(old_dir):
                try:
                    os.rmdir(old_dir)
                except OSError:
                    pass
        except Exception:
            pass
    except Exception as e:
        logger.error(f"Failed to migrate config from {old_dir} to {new_dir}: {e}")


# Run migration before initializing logs and creating directories
migrate_old_config_if_needed()


def migrate_online_fix_folder_if_needed(config_dir: str = CONFIG_DIR):
    """Merge legacy online_fix/settings.json and online_fix/cookies.json into config.json, then delete online_fix/ and downloads/."""
    import shutil

    legacy_of_dir = os.path.join(config_dir, "online_fix")
    legacy_dl_dir = os.path.join(config_dir, "downloads")

    if os.path.isdir(legacy_of_dir):
        cfg_file = os.path.join(config_dir, "config.json")
        data = {}
        if os.path.exists(cfg_file):
            try:
                with open(cfg_file, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    if isinstance(loaded, dict):
                        data = loaded
            except Exception:
                data = {}

        changed = False
        settings_file = os.path.join(legacy_of_dir, "settings.json")
        if os.path.exists(settings_file):
            try:
                with open(settings_file, "r", encoding="utf-8") as f:
                    s_data = json.load(f)
                install_root = str((s_data or {}).get("install_root", "")).strip() if isinstance(s_data, dict) else ""
                if install_root and not data.get("online_fix_install_root"):
                    data["online_fix_install_root"] = install_root
                    changed = True
            except Exception:
                pass

        cookies_file = os.path.join(legacy_of_dir, "cookies.json")
        if os.path.exists(cookies_file):
            try:
                with open(cookies_file, "r", encoding="utf-8") as f:
                    c_data = json.load(f)
                if isinstance(c_data, dict) and c_data and not data.get("online_fix_cookies"):
                    data["online_fix_cookies"] = {str(k): str(v) for k, v in c_data.items()}
                    changed = True
            except Exception:
                pass

        if changed:
            try:
                os.makedirs(config_dir, exist_ok=True)
                with open(cfg_file, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            except Exception:
                pass

        legacy_dht = os.path.join(legacy_of_dir, "dht.dat")
        target_dht = os.path.join(config_dir, "dht.dat")
        if os.path.exists(legacy_dht) and not os.path.exists(target_dht):
            try:
                os.makedirs(config_dir, exist_ok=True)
                shutil.move(legacy_dht, target_dht)
            except Exception:
                pass

        shutil.rmtree(legacy_of_dir, ignore_errors=True)

    if os.path.isdir(legacy_dl_dir):
        shutil.rmtree(legacy_dl_dir, ignore_errors=True)


migrate_online_fix_folder_if_needed()

# Ensure directories exist
for _dir in [CONFIG_DIR, CACHE_DIR, IMAGE_CACHE_DIR]:
    os.makedirs(_dir, exist_ok=True)

# Preserve previous session log as app.log.prev (for post-crash analysis)
try:
    if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 0:
        prev_log = LOG_FILE + ".prev"
        if os.path.exists(prev_log):
            os.remove(prev_log)
        os.rename(LOG_FILE, prev_log)
except OSError:
    pass

# Main log: current session (15 MB max, 2 backups)
_main_handler = RotatingFileHandler(
    LOG_FILE, maxBytes=15_000_000, backupCount=2, encoding="utf-8"
)
_main_handler.setLevel(logging.DEBUG)

# Crash log: errors & exceptions only (5 MB max, 2 backups — never truncated on start)
_crash_handler = RotatingFileHandler(
    CRASH_LOG_FILE, maxBytes=5_000_000, backupCount=2, encoding="utf-8"
)
_crash_handler.setLevel(logging.ERROR)

if sys.platform == "win32":
    try:
        if hasattr(sys.stdout, "reconfigure") and sys.stdout is not None:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure") and sys.stderr is not None:
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        _main_handler,
        _crash_handler,
    ]
)

# Suppress noisy external libraries while keeping full Bob Gaming / Remote logs
for _noisy in ("urllib3", "PIL", "zeroconf", "asyncio", "websockets", "charset_normalizer",
               "googleapiclient.discovery", "googleapiclient.discovery_cache"):
    logging.getLogger(_noisy).setLevel(logging.WARNING)

def get_app_dir() -> str:
    """Get the base application directory (works with PyInstaller bundle)."""
    if getattr(sys, 'frozen', False):
        return sys._MEIPASS
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# App constants
APP_NAME = "BobGamingGameCenter"
APP_VERSION = "1.0.0"
STEAMGRIDB_API_KEY = decrypt("xwumchFwdohcpRuEfTYlLVXjxE1woITyAkRlwsIVvmXorWj6adFEJthiUeQAwGIAUMfhhGnKSRErAPoM")


SYNC_STATUS_NOT_CONFIGURED = "not_configured"
SYNC_STATUS_NOT_SYNCED = "not_synced"
SYNC_STATUS_SYNCING = "syncing"
SYNC_STATUS_SYNCED = "synced"
SYNC_STATUS_ERROR = "error"

# Centralized display config for sync statuses
SYNC_STATUS_DISPLAY = {
    SYNC_STATUS_SYNCED: {"color": "#2ed573", "icon": "✓", "emoji": "●", "text": "Đã đồng bộ", "card_text": "Đã đồng bộ"},
    SYNC_STATUS_SYNCING: {"color": "#ffa502", "icon": "⟳", "emoji": "●", "text": "Đang đồng bộ...", "card_text": "Đang đồng bộ..."},
    SYNC_STATUS_NOT_SYNCED: {"color": "#ff4757", "icon": "✗", "emoji": "○", "text": "Chưa đồng bộ", "card_text": "Chưa đồng bộ"},
    SYNC_STATUS_NOT_CONFIGURED: {"color": "#8b949e", "icon": "○", "emoji": "○", "text": "Chưa cấu hình", "card_text": "Cài đặt"},
    SYNC_STATUS_ERROR: {"color": "#ff4757", "icon": "⚠", "emoji": "●", "text": "Lỗi đồng bộ", "card_text": "Lỗi"},
}

_DEFAULT_STATUS_DISPLAY = {"color": "#8b949e", "icon": "?", "emoji": "○", "text": "Không xác định", "card_text": "Không xác định"}


def get_status_display(status: str) -> dict:
    """Get display config (color, icon, emoji, text) for a sync status."""
    return SYNC_STATUS_DISPLAY.get(status, _DEFAULT_STATUS_DISPLAY)

# Cloud provider types
PROVIDER_NEXTCLOUD = "nextcloud"
PROVIDER_GOOGLE_DRIVE = "google_drive"

# Platform detection for cross-platform save location files
def _detect_platform() -> str:
    """Detect the current OS platform."""
    if hasattr(sys, 'getandroidapilevel'):
        return "android"
    if sys.platform.startswith("linux"):
        # Check for SteamOS (Steam Deck)
        try:
            with open("/etc/os-release", "r") as f:
                content = f.read().lower()
                if "steamos" in content:
                    return "steamos"
        except (FileNotFoundError, PermissionError):
            pass
        return "linux"
    if sys.platform == "win32":
        return "windows"
    if sys.platform == "darwin":
        return "macos"
    return sys.platform

PLATFORM_OS = _detect_platform()
SAVE_LOCATION_FILENAME = f"save_location_{PLATFORM_OS}.txt"
BOBIGNORE_FILENAME = ".bobignore"


import threading as _threading

_config_lock = _threading.RLock()
_online_fix_overlay: dict = {}


def get_default_config() -> dict:
    """Return default configuration dictionary."""
    return {
        "cloud_provider": "",  # "nextcloud" or "google_drive"
        "cloud_url": "",
        "username": "",
        "password": "",  # base64 encoded
        "remember_me": True,
        "auto_start": False,
        "minimize_to_tray": True,
        "auto_claim_steam_free_games": True,
        "steam_free_created_debug_marker": False,
        "skipped_version": "",  # update popup: "Bỏ qua version này"
        "update_channel": "stable",  # "stable" or "rc" (Release Candidates)
        "online_fix_install_root": "",
        "enabled_game_stores": ["online_fix", "fitgirl", "steamrip"],
        "online_fix_cookies": {},
        "online_fix_tasks": [],
        "games": {},  # game_name -> {save_path, last_sync, status}
    }


def load_config() -> dict:
    """Load configuration from disk, or return defaults. Falls back to backup if corrupted."""
    with _config_lock:
        config = None
        for target in [CONFIG_FILE, CONFIG_BAK_FILE]:
            if os.path.exists(target):
                try:
                    with open(target, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, dict) and data:
                            config = data
                            break
                except Exception as e:
                    logger.error(f"Failed to load config from {target}: {e}")

        if config is None:
            default = get_default_config()
            if _online_fix_overlay:
                default.update(_online_fix_overlay)
            return default

        # Merge with defaults to ensure all keys exist
        default = get_default_config()
        default.update(config)
        if _online_fix_overlay:
            default.update(_online_fix_overlay)
        if default.get("cloud_url") == "https://drive.vdthe.com":
            default["cloud_url"] = ""
        return default


def save_config(config: dict) -> bool:
    """Save configuration to disk with automatic backup. Returns True on success."""
    import shutil
    with _config_lock:
        try:
            if _online_fix_overlay:
                config.update(_online_fix_overlay)
            os.makedirs(CONFIG_DIR, exist_ok=True)
            # Create backup of current valid config before overwriting
            if os.path.exists(CONFIG_FILE) and os.path.getsize(CONFIG_FILE) > 10:
                try:
                    shutil.copy2(CONFIG_FILE, CONFIG_BAK_FILE)
                except Exception:
                    pass
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            return True
        except IOError as e:
            logger.error(f"Failed to save config: {e}")
            return False


def update_online_fix_config(**kwargs) -> bool:
    """Atomically update online_fix_* keys in config.json without losing concurrent MainWindow changes."""
    with _config_lock:
        _online_fix_overlay.update(kwargs)
        cfg = load_config()
        cfg.update(kwargs)
        return save_config(cfg)


def encode_password(password: str) -> str:
    """Base64 encode a password for storage."""
    return base64.b64encode(password.encode("utf-8")).decode("utf-8")


def decode_password(encoded: str) -> str:
    """Decode a base64 encoded password."""
    try:
        return base64.b64decode(encoded.encode("utf-8")).decode("utf-8")
    except Exception:
        return encoded  # Return as-is if not encoded


def reset_to_default_config() -> bool:
    """Reset configuration to factory defaults.

    Deletes any existing config and backup files, and writes a fresh default config.
    """
    with _config_lock:
        _online_fix_overlay.clear()
        default = get_default_config()
        for target in [CONFIG_FILE, CONFIG_BAK_FILE]:
            try:
                if os.path.exists(target):
                    os.remove(target)
            except Exception as e:
                logger.error(f"Failed to delete {target}: {e}")
        return save_config(default)


def remove_log_files():
    """Safely flush, close and delete all log files."""
    for handler in [_main_handler, _crash_handler]:
        try:
            handler.flush()
            handler.close()
            logging.root.removeHandler(handler)
        except Exception:
            pass

    log_files = [
        LOG_FILE,
        LOG_FILE + ".prev",
        CRASH_LOG_FILE,
        CRASH_LOG_FILE + ".1",
        CRASH_LOG_FILE + ".2",
    ]
    for log_path in log_files:
        try:
            if os.path.exists(log_path):
                os.remove(log_path)
        except Exception as e:
            logger.warning(f"Failed to remove log file {log_path}: {e}")
