"""Single source of truth for the app version. Bumped by tools/release.py (never edit by hand for a release)."""

APP_VERSION = "1.6.4"
