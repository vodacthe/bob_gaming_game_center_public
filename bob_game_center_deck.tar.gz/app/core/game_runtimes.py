"""
Windows / SteamOS Proton game runtime & redistributable installer for Bob Gaming Game Center.
Downloads official redistributable packages once into CONFIG_DIR/cache/runtimes and installs them
directly into a game's Steam Proton prefix (STEAM_COMPAT_DATA_PATH) on Steam Deck / Linux, or onto
the host OS on Windows.

Fixes common Non-Steam launch errors such as Unreal Engine's
"The following component(s) are required to run this program: Microsoft Visual C++ Runtime".
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
import logging
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from typing import Optional

import requests

from app.config import CACHE_DIR, app_temp_dir, make_app_temp_folder
from app.core.online_fix.extractor import clean_subprocess_env
from app.core.steam_manager import (
    find_proton_executable,
    find_steam_path,
    get_all_steam_shortcuts,
)
from app.core.steam_vdf import calculate_shortcut_appid

logger = logging.getLogger(__name__)
TAG = "[Runtime/Installer]"

USER_AGENT = "BobGamingGameCenter/1.0"

# Standard Windows Installer / Burn / Setup exit codes indicating success or already-installed
SUCCESS_EXIT_CODES = {0, 1638, 1641, 3010}

# Minimum valid installer size (bytes) to reject HTML error pages or truncated downloads
MIN_PACKAGE_BYTES = 64 * 1024

_BUNDLED_REDIST_PATTERNS = (
    "ueprereqsetup",
    "vc_redist",
    "vcredist",
    "dxsetup",
    "oalinst",
    "physx",
    "dotnet",
    "ndp4",
)
_BUNDLED_REDIST_DIRS = (
    "engine/extras/redist",
    "_commonredist",
    "_redist",
    "redist",
    "redistributables",
    "support",
    "prerequisites",
)


class RuntimeInstallError(Exception):
    """Recoverable error raised when downloading or installing a runtime package fails."""


@dataclass(frozen=True)
class RuntimePackage:
    id: str
    name: str
    description: str
    url: str
    filename: str
    silent_args: tuple[str, ...]
    size_hint: str
    recommended: bool = False
    kind: str = "exe"  # "exe" | "directx_sfx" | "zip_exe"
    inner_exe: str = ""


@dataclass(frozen=True)
class RuntimeGameTarget:
    name: str
    exe_path: str
    install_dir: str
    uint_appid: int
    compatdata_path: str
    proton_path: str
    source: str
    bundled_redists: tuple[str, ...] = ()


RUNTIME_CATALOG: tuple[RuntimePackage, ...] = (
    RuntimePackage(
        id="vcredist_x64",
        name="Microsoft Visual C++ 2015–2022 (x64)",
        description="Bắt buộc cho game Unreal Engine 4/5 (Phantom Blade Zero, Wukong...) và hầu hết game 64-bit hiện đại.",
        url="https://aka.ms/vs/17/release/vc_redist.x64.exe",
        filename="vc_redist.x64.exe",
        silent_args=("/install", "/quiet", "/norestart"),
        size_hint="~25 MB",
        recommended=True,
    ),
    RuntimePackage(
        id="vcredist_x86",
        name="Microsoft Visual C++ 2015–2022 (x86 / 32-bit)",
        description="Cần cho các launcher 32-bit, plugin phụ trợ và game dùng thư viện x86.",
        url="https://aka.ms/vs/17/release/vc_redist.x86.exe",
        filename="vc_redist.x86.exe",
        silent_args=("/install", "/quiet", "/norestart"),
        size_hint="~14 MB",
        recommended=True,
    ),
    RuntimePackage(
        id="directx_jun2010",
        name="DirectX End-User Runtime (Jun 2010)",
        description="Bổ sung d3dx9/10/11, XAudio2 và XInput cho game thiếu DLL DirectX hoặc mất âm thanh.",
        url="https://download.microsoft.com/download/8/4/A/84A35BF1-DAFE-4AE8-82AF-AD2AE20B6B14/directx_Jun2010_redist.exe",
        filename="directx_Jun2010_redist.exe",
        silent_args=("/silent",),
        size_hint="~96 MB",
        recommended=True,
        kind="directx_sfx",
        inner_exe="DXSETUP.exe",
    ),
    RuntimePackage(
        id="vcredist_2013_x64",
        name="Microsoft Visual C++ 2013 (x64)",
        description="Cần cho nhiều tựa game PC 64-bit phát hành giai đoạn 2013–2019.",
        url="https://aka.ms/highdpimfc2013x64enu",
        filename="vcredist_2013_x64.exe",
        silent_args=("/install", "/quiet", "/norestart"),
        size_hint="~7 MB",
        recommended=False,
    ),
    RuntimePackage(
        id="vcredist_2013_x86",
        name="Microsoft Visual C++ 2013 (x86 / 32-bit)",
        description="Bản 32-bit của Microsoft Visual C++ 2013 Redistributable.",
        url="https://aka.ms/highdpimfc2013x86enu",
        filename="vcredist_2013_x86.exe",
        silent_args=("/install", "/quiet", "/norestart"),
        size_hint="~6.5 MB",
        recommended=False,
    ),
    RuntimePackage(
        id="dotnet8_x64",
        name=".NET 8 Desktop Runtime (x64)",
        description="Cần cho các game Unity/C# hiện đại, mod manager và công cụ hỗ trợ game.",
        url="https://aka.ms/dotnet/8.0/windowsdesktop-runtime-win-x64.exe",
        filename="windowsdesktop-runtime-8-win-x64.exe",
        silent_args=("/install", "/quiet", "/norestart"),
        size_hint="~56 MB",
        recommended=False,
    ),
    RuntimePackage(
        id="dotnet48",
        name=".NET Framework 4.8",
        description="Cần cho game và launcher viết trên .NET Framework (cài đặt có thể mất 2–4 phút trên Proton).",
        url="https://go.microsoft.com/fwlink/?linkid=2088631",
        filename="ndp48-x86-x64-allos-enu.exe",
        silent_args=("/q", "/norestart"),
        size_hint="~116 MB",
        recommended=False,
    ),
    RuntimePackage(
        id="openal",
        name="OpenAL Audio Runtime",
        description="Khắc phục lỗi thiếu OpenAL32.dll hoặc không có tiếng trong các game dùng OpenAL.",
        url="https://www.openal.org/downloads/oalinst.zip",
        filename="oalinst.zip",
        silent_args=("/s",),
        size_hint="~0.6 MB",
        recommended=False,
        kind="zip_exe",
        inner_exe="oalinst.exe",
    ),
)

RUNTIME_BY_ID: dict[str, RuntimePackage] = {pkg.id: pkg for pkg in RUNTIME_CATALOG}


def get_runtime_cache_dir() -> str:
    """Return persistent runtime installer cache directory strictly inside CONFIG_DIR/cache/runtimes."""
    path = os.path.join(CACHE_DIR, "runtimes")
    os.makedirs(path, exist_ok=True)
    return path


def _is_valid_installer_file(path: str, kind: str) -> bool:
    if not path or not os.path.isfile(path):
        return False
    try:
        size = os.path.getsize(path)
        if size < MIN_PACKAGE_BYTES:
            return False
        with open(path, "rb") as f:
            magic = f.read(4)
        if kind == "zip_exe":
            return magic[:2] == b"PK"
        return magic[:2] == b"MZ"
    except OSError:
        return False


def _read_steam_library_roots(steam_path: str) -> list[str]:
    roots: list[str] = []
    if not steam_path or not os.path.isdir(steam_path):
        return roots
    roots.append(os.path.realpath(steam_path))
    vdf_path = os.path.join(steam_path, "steamapps", "libraryfolders.vdf")
    if os.path.isfile(vdf_path):
        try:
            with open(vdf_path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
            for raw_p in re.findall(r'"path"\s+"([^"]+)"', text):
                cleaned = raw_p.replace("\\\\", "\\")
                if os.path.isdir(cleaned):
                    real = os.path.realpath(cleaned)
                    if real not in roots:
                        roots.append(real)
        except OSError as exc:
            logger.debug(f"{TAG} Could not read libraryfolders.vdf: {exc}")
    return roots


def resolve_compatdata_path(
    uint_appid: int,
    steam_path: str | None = None,
    install_dir: str = "",
) -> str:
    """Resolve the Steam Proton compatdata directory for a Steam or Non-Steam game AppID."""
    sp = steam_path or find_steam_path()
    if sp and uint_appid > 0:
        for root in _read_steam_library_roots(sp):
            cand = os.path.join(root, "steamapps", "compatdata", str(uint_appid))
            if os.path.isdir(cand):
                return cand
        return os.path.join(sp, "steamapps", "compatdata", str(uint_appid))

    if install_dir and os.path.isdir(install_dir):
        local_compat = os.path.join(install_dir, "compatdata")
        if os.path.isdir(local_compat):
            return local_compat
        return local_compat
    return ""


def _resolve_ci_subdir(base_dir: str, rel_parts: tuple[str, ...]) -> str | None:
    """Resolve a nested relative directory path case-insensitively (works on Linux ext4 and preserves real case)."""
    cur = base_dir
    for part in rel_parts:
        if not os.path.isdir(cur):
            return None
        target = part.lower()
        matched = None
        try:
            for entry in os.listdir(cur):
                if entry.lower() == target and os.path.isdir(os.path.join(cur, entry)):
                    matched = entry
                    break
        except OSError:
            return None
        if not matched:
            return None
        cur = os.path.join(cur, matched)
    return cur


def find_bundled_redists(install_dir: str) -> list[str]:
    """Scan a game's installation folder for bundled redistributable installers (e.g. UEPrereqSetup_x64.exe)."""
    if not install_dir or not os.path.isdir(install_dir):
        return []

    found: list[str] = []
    seen: set[str] = set()

    def _check_dir(base_dir: str, max_depth: int = 3) -> None:
        if not os.path.isdir(base_dir):
            return
        try:
            for root, dirs, files in os.walk(base_dir):
                rel = os.path.relpath(root, base_dir)
                depth = 0 if rel == "." else rel.count(os.sep) + 1
                if depth > max_depth:
                    dirs.clear()
                    continue
                for fname in files:
                    low = fname.lower()
                    if not (low.endswith(".exe") or low.endswith(".msi")):
                        continue
                    if any(pat in low for pat in _BUNDLED_REDIST_PATTERNS):
                        full = os.path.normpath(os.path.join(root, fname))
                        key = os.path.normcase(full)
                        if key not in seen:
                            seen.add(key)
                            found.append(full)
        except OSError:
            pass

    for rel_sub in _BUNDLED_REDIST_DIRS:
        candidate_dir = _resolve_ci_subdir(install_dir, tuple(rel_sub.split("/")))
        if candidate_dir:
            _check_dir(candidate_dir, max_depth=4)

    # Also check shallow root folders (depth <= 2) for UEPrereqSetup or direct vc_redist installers
    try:
        for root, dirs, files in os.walk(install_dir):
            rel = os.path.relpath(root, install_dir)
            depth = 0 if rel == "." else rel.count(os.sep) + 1
            if depth >= 2:
                dirs.clear()
            for fname in files:
                low = fname.lower()
                if not low.endswith(".exe"):
                    continue
                if any(pat in low for pat in ("ueprereqsetup", "vc_redist", "vcredist", "dxsetup")):
                    full = os.path.normpath(os.path.join(root, fname))
                    key = os.path.normcase(full)
                    if key not in seen:
                        seen.add(key)
                        found.append(full)
    except OSError:
        pass

    found.sort(key=lambda p: (0 if "ueprereq" in os.path.basename(p).lower() else 1, os.path.basename(p).lower()))
    return found


def list_runtime_targets(
    library_games: list[dict] | None = None,
    steam_path: str | None = None,
) -> list[RuntimeGameTarget]:
    """
    Combine Bob Gaming Library games and Steam Non-Steam shortcuts into a unified list of targets
    with resolved Proton prefix (compatdata) paths and bundled redistributables.
    """
    t0 = time.monotonic()
    sp = steam_path or find_steam_path()
    shortcuts = get_all_steam_shortcuts(sp) if sp else []

    shortcut_by_exe: dict[str, dict] = {}
    shortcut_by_name: dict[str, dict] = {}
    for sc in shortcuts:
        sc_name = str(sc.get("appname") or "").strip()
        sc_exe = str(sc.get("exe") or "").strip().strip('"')
        if sc_exe:
            shortcut_by_exe[os.path.normcase(os.path.normpath(sc_exe))] = sc
        if sc_name:
            shortcut_by_name[sc_name.lower()] = sc

    targets: list[RuntimeGameTarget] = []
    seen_keys: set[tuple[str, int]] = set()

    for g in (library_games or []):
        name = str(g.get("name") or "").strip()
        if not name:
            continue
        exe_path = str(g.get("exe_path") or "").strip().strip('"')
        install_dir = str(g.get("install_location") or "").strip().strip('"')
        if not install_dir and exe_path:
            install_dir = os.path.dirname(exe_path)

        source = str(g.get("source") or "manual")
        uint_appid = 0
        raw_appid = g.get("appid") or g.get("steam_appid")
        if source == "steam" and raw_appid:
            try:
                uint_appid = int(raw_appid) & 0xFFFFFFFF
            except (TypeError, ValueError):
                uint_appid = 0

        if not uint_appid:
            matched_sc = None
            if exe_path:
                matched_sc = shortcut_by_exe.get(os.path.normcase(os.path.normpath(exe_path)))
            if not matched_sc:
                matched_sc = shortcut_by_name.get(name.lower())
            if matched_sc:
                uint_appid = int(matched_sc.get("uint_appid") or 0)
            elif exe_path:
                _, uint_appid, _ = calculate_shortcut_appid(exe_path, name)

        if not exe_path and not install_dir and not uint_appid:
            continue

        compat_dir = resolve_compatdata_path(uint_appid, steam_path=sp, install_dir=install_dir)
        proton_bin = find_proton_executable(sp, uint_appid) or ""
        bundled = tuple(find_bundled_redists(install_dir)) if install_dir else ()

        key = (name.lower(), uint_appid)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        targets.append(
            RuntimeGameTarget(
                name=name,
                exe_path=exe_path,
                install_dir=install_dir,
                uint_appid=uint_appid,
                compatdata_path=compat_dir,
                proton_path=proton_bin,
                source=source,
                bundled_redists=bundled,
            )
        )

    # Also include Non-Steam shortcuts registered directly in Steam (even if not in Bob Library)
    known_names = {t.name.lower() for t in targets}
    known_appids = {t.uint_appid for t in targets if t.uint_appid > 0}
    for sc in shortcuts:
        sc_name = str(sc.get("appname") or "").strip()
        sc_appid = int(sc.get("uint_appid") or 0)
        if not sc_name or sc_name.lower() in known_names or (sc_appid and sc_appid in known_appids):
            continue
        sc_exe = str(sc.get("exe") or "").strip().strip('"')
        sc_dir = str(sc.get("StartDir") or "").strip().strip('"') or (os.path.dirname(sc_exe) if sc_exe else "")
        compat_dir = resolve_compatdata_path(sc_appid, steam_path=sp, install_dir=sc_dir)
        proton_bin = find_proton_executable(sp, sc_appid) or ""
        bundled = tuple(find_bundled_redists(sc_dir)) if sc_dir else ()
        targets.append(
            RuntimeGameTarget(
                name=sc_name,
                exe_path=sc_exe,
                install_dir=sc_dir,
                uint_appid=sc_appid,
                compatdata_path=compat_dir,
                proton_path=proton_bin,
                source="steam_shortcut",
                bundled_redists=bundled,
            )
        )

    targets.sort(key=lambda t: t.name.lower())
    logger.info(f"{TAG} Discovered {len(targets)} game runtime target(s) in {time.monotonic() - t0:.2f}s")
    return targets


def _reg_has_installed_key(reg_text: str, section_pattern: str) -> bool:
    """Return True if a Wine system.reg section matching `section_pattern` has Installed=1."""
    if not reg_text:
        return False
    for match in re.finditer(section_pattern, reg_text, flags=re.IGNORECASE):
        block_start = match.end()
        next_sec = reg_text.find("\n[", block_start)
        block = reg_text[block_start : next_sec if next_sec != -1 else block_start + 1500]
        if re.search(r'"Installed"\s*=\s*dword:0*1\b', block, flags=re.IGNORECASE):
            return True
    return False


def _detect_proton_prefix_runtimes(compatdata_path: str) -> dict[str, bool]:
    status = {pkg.id: False for pkg in RUNTIME_CATALOG}
    if not compatdata_path:
        return status

    pfx_dir = os.path.join(compatdata_path, "pfx")
    if not os.path.isdir(pfx_dir):
        return status

    reg_path = os.path.join(pfx_dir, "system.reg")
    reg_text = ""
    if os.path.isfile(reg_path):
        try:
            with open(reg_path, "r", encoding="utf-8", errors="replace") as f:
                reg_text = f.read()
        except OSError as exc:
            logger.debug(f"{TAG} Could not read {reg_path}: {exc}")

    # VC++ 2015–2022 x64 (exact key checked by Unreal Engine bootstrapper!)
    status["vcredist_x64"] = _reg_has_installed_key(
        reg_text,
        r"\[Software\\\\(?:Wow6432Node\\\\)?Microsoft\\\\VisualStudio\\\\14\.0\\\\VC\\\\Runtimes\\\\[xX]64\]",
    )
    status["vcredist_x86"] = _reg_has_installed_key(
        reg_text,
        r"\[Software\\\\(?:Wow6432Node\\\\)?Microsoft\\\\VisualStudio\\\\14\.0\\\\VC\\\\Runtimes\\\\[xX]86\]",
    )
    status["vcredist_2013_x64"] = _reg_has_installed_key(
        reg_text,
        r"\[Software\\\\(?:Wow6432Node\\\\)?Microsoft\\\\VisualStudio\\\\12\.0\\\\VC\\\\Runtimes\\\\[xX]64\]",
    )
    status["vcredist_2013_x86"] = _reg_has_installed_key(
        reg_text,
        r"\[Software\\\\(?:Wow6432Node\\\\)?Microsoft\\\\VisualStudio\\\\12\.0\\\\VC\\\\Runtimes\\\\[xX]86\]",
    )

    drive_c = os.path.join(pfx_dir, "drive_c")
    sys32 = os.path.join(drive_c, "windows", "system32")
    syswow64 = os.path.join(drive_c, "windows", "syswow64")

    def _has_file_ci(folder: str, filename: str) -> bool:
        if not os.path.isdir(folder):
            return False
        target = filename.lower()
        try:
            return any(f.lower() == target for f in os.listdir(folder))
        except OSError:
            return False

    # DirectX Jun 2010: d3dx9_43.dll + xinput1_3.dll installed in system32
    status["directx_jun2010"] = _has_file_ci(sys32, "d3dx9_43.dll") and _has_file_ci(sys32, "d3dx11_43.dll")

    # OpenAL
    status["openal"] = _has_file_ci(sys32, "OpenAL32.dll") or _has_file_ci(syswow64, "OpenAL32.dll")

    # .NET 8 Desktop Runtime (x64)
    dotnet8_dir = os.path.join(drive_c, "Program Files", "dotnet", "shared", "Microsoft.WindowsDesktop.App")
    if os.path.isdir(dotnet8_dir):
        try:
            status["dotnet8_x64"] = any(d.startswith("8.") for d in os.listdir(dotnet8_dir))
        except OSError:
            pass

    # .NET Framework 4.8 (Release >= 528040 in NDP\v4\Full)
    m_ndp = re.search(
        r"\[Software\\\\Microsoft\\\\NET Framework Setup\\\\NDP\\\\v4\\\\Full\][^\[]*?\"Release\"=dword:([0-9a-fA-F]+)",
        reg_text,
        flags=re.IGNORECASE,
    )
    if m_ndp:
        try:
            status["dotnet48"] = int(m_ndp.group(1), 16) >= 528040
        except ValueError:
            pass

    return status


def _detect_windows_host_runtimes() -> dict[str, bool]:
    status = {pkg.id: False for pkg in RUNTIME_CATALOG}
    try:
        import winreg

        def _reg_dword(subkey: str, value_name: str = "Installed") -> int:
            for root_view in (0, getattr(winreg, "KEY_WOW64_64KEY", 0), getattr(winreg, "KEY_WOW64_32KEY", 0)):
                try:
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, subkey, 0, winreg.KEY_READ | root_view) as k:
                        val, _ = winreg.QueryValueEx(k, value_name)
                        return int(val)
                except OSError:
                    continue
            return 0

        status["vcredist_x64"] = _reg_dword(r"SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64") == 1
        status["vcredist_x86"] = _reg_dword(r"SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x86") == 1
        status["vcredist_2013_x64"] = _reg_dword(r"SOFTWARE\Microsoft\VisualStudio\12.0\VC\Runtimes\x64") == 1
        status["vcredist_2013_x86"] = _reg_dword(r"SOFTWARE\Microsoft\VisualStudio\12.0\VC\Runtimes\x86") == 1
        status["dotnet48"] = _reg_dword(r"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full", "Release") >= 528040
    except ImportError:
        pass

    sys_root = os.environ.get("SystemRoot", r"C:\Windows")
    sys32 = os.path.join(sys_root, "System32")
    syswow64 = os.path.join(sys_root, "SysWOW64")
    status["directx_jun2010"] = os.path.isfile(os.path.join(sys32, "d3dx9_43.dll")) and os.path.isfile(
        os.path.join(sys32, "d3dx11_43.dll")
    )
    status["openal"] = os.path.isfile(os.path.join(sys32, "OpenAL32.dll")) or os.path.isfile(
        os.path.join(syswow64, "OpenAL32.dll")
    )
    dotnet_dir = os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "dotnet", "shared", "Microsoft.WindowsDesktop.App")
    if os.path.isdir(dotnet_dir):
        try:
            status["dotnet8_x64"] = any(d.startswith("8.") for d in os.listdir(dotnet_dir))
        except OSError:
            pass

    return status


def detect_installed_runtimes(compatdata_path: str = "", platform: str | None = None) -> dict[str, bool]:
    """Detect which catalog runtimes are already installed in the Proton prefix (Linux) or Windows OS."""
    plat = platform or sys.platform
    if plat == "win32":
        return _detect_windows_host_runtimes()
    return _detect_proton_prefix_runtimes(compatdata_path)


def download_runtime_package(
    pkg: RuntimePackage,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    is_cancelled: Optional[Callable[[], bool]] = None,
    timeout: float = 30.0,
) -> str:
    """Download a runtime installer into CONFIG_DIR/cache/runtimes (reusing valid cached copy)."""
    cache_dir = get_runtime_cache_dir()
    dst_path = os.path.join(cache_dir, pkg.filename)
    if _is_valid_installer_file(dst_path, pkg.kind):
        logger.info(f"{TAG} Using cached installer for {pkg.id}: {dst_path}")
        if progress_cb:
            progress_cb(100, 100, f"Đã có sẵn bộ cài {pkg.name}")
        return dst_path

    part_path = f"{dst_path}.part"
    t0 = time.monotonic()
    logger.info(f"{TAG} Downloading {pkg.id} from {pkg.url}")
    if progress_cb:
        progress_cb(0, 100, f"Đang tải {pkg.name}...")

    try:
        with requests.get(
            pkg.url,
            stream=True,
            allow_redirects=True,
            timeout=timeout,
            headers={"User-Agent": USER_AGENT},
        ) as resp:
            if resp.status_code != 200:
                elapsed = time.monotonic() - t0
                logger.warning(f"{TAG} Download failed for {pkg.id}: HTTP {resp.status_code} ({pkg.url}) in {elapsed:.2f}s")
                raise RuntimeInstallError(f"Không tải được {pkg.name} (HTTP {resp.status_code}).")

            total = int(resp.headers.get("content-length") or 0)
            written = 0
            last_logged_milestone = 0

            with open(part_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=128 * 1024):
                    if is_cancelled and is_cancelled():
                        raise RuntimeInstallError("Đã hủy tải xuống theo yêu cầu.")
                    if not chunk:
                        continue
                    f.write(chunk)
                    written += len(chunk)
                    if total > 0:
                        pct = min(99, int(written * 100 / total))
                        if progress_cb:
                            progress_cb(pct, 100, f"Đang tải {pkg.name}... ({pct}%)")
                        milestone = (pct // 25) * 25
                        if milestone >= 25 and milestone > last_logged_milestone:
                            last_logged_milestone = milestone
                            logger.info(f"{TAG} Download progress {pkg.id}: {milestone}% ({written}/{total} bytes)")

        if not _is_valid_installer_file(part_path, pkg.kind):
            raise RuntimeInstallError(f"Tệp tải về cho {pkg.name} không hợp lệ hoặc bị hỏng.")

        os.replace(part_path, dst_path)
        elapsed = time.monotonic() - t0
        logger.info(f"{TAG} Downloaded {pkg.id} ({os.path.getsize(dst_path)} bytes) in {elapsed:.2f}s")
        if progress_cb:
            progress_cb(100, 100, f"Tải xong {pkg.name}")
        return dst_path
    except RuntimeInstallError:
        if os.path.exists(part_path):
            try:
                os.remove(part_path)
            except OSError:
                pass
        raise
    except Exception as exc:
        elapsed = time.monotonic() - t0
        if os.path.exists(part_path):
            try:
                os.remove(part_path)
            except OSError:
                pass
        logger.warning(f"{TAG} Network error downloading {pkg.id} ({pkg.url}) in {elapsed:.2f}s: {exc}")
        raise RuntimeInstallError(f"Lỗi mạng khi tải {pkg.name}: {exc}") from exc


def _build_proton_exec_env(
    compatdata_path: str,
    steam_path: str | None,
) -> dict[str, str]:
    """Build a sanitized environment for running a Windows installer via Proton without host leaks."""
    env = clean_subprocess_env()
    for var in ("SteamAppId", "SteamGameId", "SteamOverlayGameId"):
        env.pop(var, None)

    ld_preload = env.get("LD_PRELOAD", "")
    if ld_preload and "gameoverlayrenderer.so" in ld_preload:
        sep = ":" if ":" in ld_preload else " "
        kept = [p for p in ld_preload.split(sep) if p and "gameoverlayrenderer.so" not in p]
        if kept:
            env["LD_PRELOAD"] = sep.join(kept)
        else:
            env.pop("LD_PRELOAD", None)

    env["WINEDEBUG"] = "-all"
    env["STEAM_COMPAT_DATA_PATH"] = compatdata_path
    if steam_path and os.path.isdir(steam_path):
        env["STEAM_COMPAT_CLIENT_INSTALL_PATH"] = steam_path

    tmp_dir = app_temp_dir()
    env["TEMP"] = tmp_dir
    env["TMP"] = tmp_dir
    return env


def _find_sniper_entry_point(steam_path: str | None) -> str | None:
    if not steam_path or os.environ.get("PRESSURE_VESSEL_RUNTIME"):
        return None
    cand = os.path.join(steam_path, "steamapps", "common", "SteamLinuxRuntime_sniper", "_v2-entry-point")
    if os.path.isfile(cand) and os.access(cand, os.X_OK):
        return cand
    return None


def _run_subprocess_checked(cmd: list[str], cwd: str, env: dict[str, str], timeout: int) -> tuple[int, str]:
    kwargs: dict = {
        "cwd": cwd,
        "env": env,
        "capture_output": True,
        "text": True,
        "errors": "replace",
        "timeout": timeout,
    }
    if sys.platform == "win32":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.run(cmd, **kwargs)
    combined = ((proc.stderr or "") + "\n" + (proc.stdout or "")).strip()
    return int(proc.returncode), combined[-600:]


def run_installer_in_prefix(
    installer_exe: str,
    silent_args: tuple[str, ...] = (),
    compatdata_path: str = "",
    steam_path: str | None = None,
    proton_bin: str | None = None,
    timeout: int = 420,
    platform: str | None = None,
) -> tuple[bool, int, str]:
    """
    Execute a Windows installer (.exe or .msi) inside a Steam Proton prefix (Linux/SteamOS)
    or directly on Windows.
    """
    if not installer_exe or not os.path.isfile(installer_exe):
        msg = f"Không tìm thấy file cài đặt: {installer_exe}"
        logger.warning(f"{TAG} Refused install: {msg}")
        return False, -1, msg

    plat = platform or sys.platform
    cwd = os.path.dirname(os.path.abspath(installer_exe)) or app_temp_dir()
    is_msi = installer_exe.lower().endswith(".msi")
    t0 = time.monotonic()

    if plat == "win32":
        env = clean_subprocess_env()
        tmp_dir = app_temp_dir()
        env["TEMP"] = tmp_dir
        env["TMP"] = tmp_dir
        if is_msi:
            cmd = ["msiexec", "/i", installer_exe, *(silent_args or ("/qn", "/norestart"))]
        else:
            cmd = [installer_exe, *silent_args]
        logger.info(f"{TAG} Running Windows installer: {os.path.basename(installer_exe)} {list(silent_args)}")
        try:
            rc, out = _run_subprocess_checked(cmd, cwd=cwd, env=env, timeout=timeout)
        except subprocess.TimeoutExpired:
            logger.warning(f"{TAG} Installer timed out after {timeout}s: {installer_exe}")
            return False, -1, f"Bộ cài {os.path.basename(installer_exe)} bị quá thời gian chờ ({timeout}s)."
        except OSError as exc:
            logger.error(f"{TAG} Failed starting Windows installer {installer_exe}: {exc}", exc_info=True)
            return False, -1, f"Không chạy được bộ cài {os.path.basename(installer_exe)}: {exc}"

        ok = rc in SUCCESS_EXIT_CODES
        logger.info(
            f"{TAG} Windows installer {os.path.basename(installer_exe)} exited with rc={rc} "
            f"(ok={ok}) in {time.monotonic() - t0:.2f}s"
        )
        return ok, rc, out

    # Linux / SteamOS (Proton prefix)
    if not compatdata_path:
        msg = "Chưa xác định được thư mục Proton Prefix (compatdata) của game."
        logger.warning(f"{TAG} Refused Proton install: {msg}")
        return False, -1, msg

    sp = steam_path or find_steam_path()
    runner = proton_bin or find_proton_executable(sp)
    wine_fallback = None if runner else shutil.which("wine")
    if not runner and not wine_fallback:
        msg = (
            "Không tìm thấy Proton trên Steam Deck / Linux. "
            "Hãy cài 'Proton Experimental' trong Steam rồi thử lại."
        )
        logger.warning(f"{TAG} Refused Proton install: {msg}")
        return False, -1, msg

    try:
        os.makedirs(compatdata_path, exist_ok=True)
    except OSError as exc:
        msg = f"Không thể tạo thư mục Proton prefix ({compatdata_path}): {exc}"
        logger.error(f"{TAG} {msg}")
        return False, -1, msg

    env = _build_proton_exec_env(compatdata_path, sp)
    if is_msi:
        target_args = ["msiexec", "/i", installer_exe, *(silent_args or ("/qn", "/norestart"))]
    else:
        target_args = [installer_exe, *silent_args]

    if runner:
        direct_cmd = [runner, "waitforexitandrun", *target_args]
        sniper = _find_sniper_entry_point(sp)
        primary_cmd = (
            [sniper, "--verb=waitforexitandrun", "--", *direct_cmd]
            if sniper
            else direct_cmd
        )
    else:
        env["WINEPREFIX"] = os.path.join(compatdata_path, "pfx")
        direct_cmd = [wine_fallback, *target_args]  # type: ignore[list-item]
        primary_cmd = direct_cmd

    logger.info(
        f"{TAG} Installing {os.path.basename(installer_exe)} into prefix {compatdata_path} "
        f"(runner={runner or wine_fallback})"
    )
    try:
        rc, out = _run_subprocess_checked(primary_cmd, cwd=cwd, env=env, timeout=timeout)
        # If SteamLinuxRuntime_sniper fails due to nested sandbox/bwrap, retry direct Proton invocation
        if rc not in SUCCESS_EXIT_CODES and primary_cmd is not direct_cmd:
            logger.warning(
                f"{TAG} Sniper wrapper exited with rc={rc} for {os.path.basename(installer_exe)}; "
                f"retrying direct Proton invocation"
            )
            rc, out = _run_subprocess_checked(direct_cmd, cwd=cwd, env=env, timeout=timeout)
    except subprocess.TimeoutExpired:
        logger.warning(f"{TAG} Proton installer timed out after {timeout}s: {installer_exe}")
        return False, -1, f"Bộ cài {os.path.basename(installer_exe)} bị quá thời gian chờ ({timeout}s)."
    except OSError as exc:
        logger.error(f"{TAG} Failed running Proton installer {installer_exe}: {exc}", exc_info=True)
        return False, -1, f"Không thể chạy Proton để cài {os.path.basename(installer_exe)}: {exc}"

    ok = rc in SUCCESS_EXIT_CODES
    logger.info(
        f"{TAG} Proton installer {os.path.basename(installer_exe)} exited with rc={rc} "
        f"(ok={ok}) in {time.monotonic() - t0:.2f}s"
    )
    return ok, rc, out


def _extract_directx_archive(sfx_path: str, extract_dir: str, compatdata_path: str, steam_path: str | None, proton_bin: str | None) -> str:
    """Extract directx_Jun2010_redist.exe using 7z (preferred) or SFX /Q /T: into `extract_dir`."""
    seven_z = None
    try:
        from app.core.binary_finder import find_7z_binary
        seven_z = find_7z_binary()
    except Exception:
        seven_z = shutil.which("7z") or shutil.which("7za")

    if seven_z:
        env = clean_subprocess_env()
        env["TEMP"] = app_temp_dir()
        env["TMP"] = app_temp_dir()
        proc = subprocess.run(
            [seven_z, "x", "-y", f"-o{extract_dir}", sfx_path],
            env=env,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=120,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0,
        )
        if proc.returncode == 0:
            for fname in os.listdir(extract_dir):
                if fname.lower() == "dxsetup.exe":
                    return os.path.join(extract_dir, fname)

    # Fallback: run self-extracting archive directly with /Q /T:<dir>
    ok, rc, out = run_installer_in_prefix(
        sfx_path,
        silent_args=("/Q", f"/T:{extract_dir}"),
        compatdata_path=compatdata_path,
        steam_path=steam_path,
        proton_bin=proton_bin,
        timeout=180,
    )
    if not ok:
        raise RuntimeInstallError(f"Không giải nén được bộ cài DirectX (mã lỗi {rc}): {out}")

    for fname in os.listdir(extract_dir):
        if fname.lower() == "dxsetup.exe":
            return os.path.join(extract_dir, fname)
    raise RuntimeInstallError("Không tìm thấy DXSETUP.exe sau khi giải nén gói DirectX.")


def install_runtime_package(
    pkg_id: str,
    target: RuntimeGameTarget | None = None,
    steam_path: str | None = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    is_cancelled: Optional[Callable[[], bool]] = None,
) -> dict:
    """Download (if needed) and install a catalog runtime package into a game prefix (Linux) or Windows."""
    pkg = RUNTIME_BY_ID.get(pkg_id)
    if not pkg:
        msg = f"Không tìm thấy gói runtime '{pkg_id}'."
        logger.warning(f"{TAG} {msg}")
        return {"success": False, "pkg_id": pkg_id, "message": msg}

    t0 = time.monotonic()
    compat_path = target.compatdata_path if target else ""
    proton_bin = (target.proton_path or None) if target else None
    target_label = target.name if target else ("Windows" if sys.platform == "win32" else "Prefix")
    logger.info(f"{TAG} Starting install of {pkg.id} for {target_label!r}")

    installer_path = download_runtime_package(pkg, progress_cb=progress_cb, is_cancelled=is_cancelled)
    if is_cancelled and is_cancelled():
        raise RuntimeInstallError("Đã hủy cài đặt theo yêu cầu.")

    temp_extract_dir: str | None = None
    try:
        run_exe = installer_path
        if pkg.kind == "directx_sfx":
            if progress_cb:
                progress_cb(60, 100, f"Đang giải nén {pkg.name}...")
            temp_extract_dir = make_app_temp_folder(prefix="runtime_dx_")
            run_exe = _extract_directx_archive(installer_path, temp_extract_dir, compat_path, steam_path, proton_bin)
        elif pkg.kind == "zip_exe":
            if progress_cb:
                progress_cb(60, 100, f"Đang giải nén {pkg.name}...")
            temp_extract_dir = make_app_temp_folder(prefix="runtime_zip_")
            with zipfile.ZipFile(installer_path, "r") as zf:
                zf.extractall(temp_extract_dir)
            found_inner = ""
            for root, _, files in os.walk(temp_extract_dir):
                for fname in files:
                    if fname.lower() == pkg.inner_exe.lower():
                        found_inner = os.path.join(root, fname)
                        break
                if found_inner:
                    break
            if not found_inner:
                raise RuntimeInstallError(f"Không tìm thấy {pkg.inner_exe} trong gói {pkg.name}.")
            run_exe = found_inner

        if progress_cb:
            progress_cb(80, 100, f"Đang cài đặt {pkg.name} vào {target_label}...")

        ok, rc, out = run_installer_in_prefix(
            run_exe,
            silent_args=pkg.silent_args,
            compatdata_path=compat_path,
            steam_path=steam_path,
            proton_bin=proton_bin,
        )
        elapsed = time.monotonic() - t0
        if not ok:
            detail = f" (mã lỗi {rc})" if rc >= 0 else ""
            err_msg = f"Cài đặt {pkg.name} thất bại{detail}." + (f" {out}" if out else "")
            logger.warning(f"{TAG} Failed {pkg.id} for {target_label!r} in {elapsed:.2f}s: {err_msg}")
            return {"success": False, "pkg_id": pkg.id, "exit_code": rc, "message": err_msg}

        if progress_cb:
            progress_cb(100, 100, f"Đã cài xong {pkg.name}")
        msg = f"Đã cài đặt thành công {pkg.name} cho {target_label}."
        logger.info(f"{TAG} Completed {pkg.id} for {target_label!r} in {elapsed:.2f}s (rc={rc})")
        return {"success": True, "pkg_id": pkg.id, "exit_code": rc, "message": msg}
    finally:
        if temp_extract_dir and os.path.isdir(temp_extract_dir):
            shutil.rmtree(temp_extract_dir, ignore_errors=True)


def infer_silent_args_for_exe(exe_path: str) -> tuple[str, ...]:
    """Guess standard unattended flags for common bundled game redistributables."""
    low = os.path.basename(exe_path or "").lower()
    if low.endswith(".msi"):
        return ("/qn", "/norestart")
    if "dxsetup" in low:
        return ("/silent",)
    if "oalinst" in low:
        return ("/s",)
    if any(tok in low for tok in ("vc_redist", "vcredist", "ueprereqsetup", "dotnet", "windowsdesktop")):
        return ("/install", "/quiet", "/norestart")
    if "ndp4" in low:
        return ("/q", "/norestart")
    return ()


def install_custom_executable(
    exe_path: str,
    target: RuntimeGameTarget | None = None,
    extra_args: tuple[str, ...] | None = None,
    steam_path: str | None = None,
) -> dict:
    """Run a game-bundled redistributable (e.g. UEPrereqSetup_x64.exe) or user-selected installer in the game prefix."""
    t0 = time.monotonic()
    clean_exe = (exe_path or "").strip().strip('"')
    args = infer_silent_args_for_exe(clean_exe) if extra_args is None else tuple(extra_args)
    compat_path = target.compatdata_path if target else ""
    proton_bin = (target.proton_path or None) if target else None
    target_label = target.name if target else ("Windows" if sys.platform == "win32" else "Prefix")

    logger.info(f"{TAG} Running custom/bundled installer {os.path.basename(clean_exe)!r} for {target_label!r}")
    ok, rc, out = run_installer_in_prefix(
        clean_exe,
        silent_args=args,
        compatdata_path=compat_path,
        steam_path=steam_path,
        proton_bin=proton_bin,
    )
    elapsed = time.monotonic() - t0
    if ok:
        msg = f"Đã chạy xong {os.path.basename(clean_exe)} cho {target_label}."
        logger.info(f"{TAG} Custom installer finished in {elapsed:.2f}s (rc={rc})")
        return {"success": True, "exit_code": rc, "message": msg}

    msg = f"Chạy {os.path.basename(clean_exe)} thất bại (mã lỗi {rc})." + (f" {out}" if out else "")
    logger.warning(f"{TAG} Custom installer failed in {elapsed:.2f}s: {msg}")
    return {"success": False, "exit_code": rc, "message": msg}


def ensure_default_proton_runtimes(
    uint_appid: int,
    game_name: str = "",
    install_dir: str = "",
    steam_path: str | None = None,
) -> dict:
    """
    On Linux / SteamOS, silently ensure Visual C++ 2015–2022 (x64) is installed inside a newly added
    Non-Steam game's Proton prefix so Unreal Engine / modern Windows games launch out of the box.
    No-op on Windows.
    """
    if sys.platform == "win32":
        return {"success": True, "skipped": True, "reason": "windows_host"}

    sp = steam_path or find_steam_path()
    proton_bin = find_proton_executable(sp, uint_appid)
    if not proton_bin:
        logger.info(f"{TAG} Skipping auto VC++ setup for {game_name!r}: no Proton runner found")
        return {"success": False, "skipped": True, "reason": "no_proton"}

    compat_dir = resolve_compatdata_path(uint_appid, steam_path=sp, install_dir=install_dir)
    if not compat_dir:
        return {"success": False, "skipped": True, "reason": "no_compatdata"}

    installed = detect_installed_runtimes(compat_dir, platform="linux")
    if installed.get("vcredist_x64"):
        logger.info(f"{TAG} Prefix for {game_name!r} ({uint_appid}) already has vcredist_x64")
        return {"success": True, "already_installed": True, "pkg_id": "vcredist_x64"}

    target = RuntimeGameTarget(
        name=game_name or f"AppID {uint_appid}",
        exe_path="",
        install_dir=install_dir,
        uint_appid=uint_appid,
        compatdata_path=compat_dir,
        proton_path=proton_bin,
        source="steam_shortcut",
    )
    try:
        return install_runtime_package("vcredist_x64", target=target, steam_path=sp)
    except Exception as exc:
        logger.warning(f"{TAG} Auto VC++ install skipped for {game_name!r}: {exc}")
        return {"success": False, "message": str(exc)}
