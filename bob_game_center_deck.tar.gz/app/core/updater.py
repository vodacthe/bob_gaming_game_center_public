"""Self-update: compare against the public release repo, download the new build, swap it in and restart.

The release repo (UPDATE_REPO) holds the release artifacts published by tools/release.py:
    Stable channel (root `/`):
        version.MD                   only the version, e.g. "1.4.0"
        update.MD                    release notes shown in the update popup
        BobGamingCenter.exe          Windows single-file executable
        bob_game_center_deck.tar.gz  Linux / SteamOS user-space bundle
        install.sh                   One-line online installer for Linux / Steam Deck
    Release Candidates channel (`/release-candidates/*`):
        Same 5 files inside `release-candidates/`, versioned `<patch+1>-rcN` (e.g. "1.4.1-rc1", "1.4.1-rc2").
"""

import logging
import os
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import time
from dataclasses import dataclass
from typing import Callable

import requests

from app.version import APP_VERSION

logger = logging.getLogger(__name__)

CHANNEL_STABLE = "stable"
CHANNEL_RC = "rc"
RC_SUBDIR = "release-candidates"

UPDATE_REPO = "vodacthe/bob_gaming_game_center_public"
UPDATE_BRANCH = "main"
RAW_BASE = f"https://raw.githubusercontent.com/{UPDATE_REPO}/{UPDATE_BRANCH}"
RC_RAW_BASE = f"{RAW_BASE}/{RC_SUBDIR}"
VERSION_URL = f"{RAW_BASE}/version.MD"
NOTES_URL = f"{RAW_BASE}/update.MD"
EXE_FILENAME = "BobGamingCenter.exe"
EXE_URL = f"{RAW_BASE}/{EXE_FILENAME}"
LINUX_PACKAGE_FILENAME = "bob_game_center_deck.tar.gz"
LINUX_PACKAGE_URL = f"{RAW_BASE}/{LINUX_PACKAGE_FILENAME}"
LINUX_INSTALL_SCRIPT_FILENAME = "install.sh"
PENDING_LINUX_UPDATE_NAME = ".bob_pending_update.tar.gz"

CHECK_INTERVAL_MS = 15 * 60 * 1000
STARTUP_CHECK_DELAY_MS = 8000
_MIN_EXE_BYTES = 5 * 1024 * 1024     # anything smaller is an error page / truncated download
_MIN_LINUX_TAR_BYTES = 16 * 1024      # valid .tar.gz bundle is multi-MB; <16 KB is an error page / truncated file
_HTTP_TIMEOUT = 20

_FULL_VERSION_RE = re.compile(r"^(\d+(?:\.\d+){0,3})(?:-[rR][cC]([1-9]\d*))?$")


@dataclass(frozen=True)
class UpdateInfo:
    version: str
    notes: str
    channel: str = CHANNEL_STABLE
    allow_downgrade: bool = False


class UpdateCancelled(Exception):
    pass


def normalize_channel(channel: str | None) -> str:
    """Normalize persisted or user-supplied channel name to 'stable' or 'rc'."""
    val = str(channel or "").strip().lower()
    if val in (CHANNEL_RC, RC_SUBDIR, "release_candidates", "release candidates"):
        return CHANNEL_RC
    return CHANNEL_STABLE


def channel_display_name(channel: str | None) -> str:
    return "Release Candidates" if normalize_channel(channel) == CHANNEL_RC else "Stable"


def channel_raw_base(channel: str = CHANNEL_STABLE) -> str:
    return RC_RAW_BASE if normalize_channel(channel) == CHANNEL_RC else RAW_BASE


def version_url_for_channel(channel: str = CHANNEL_STABLE) -> str:
    return f"{RC_RAW_BASE}/version.MD" if normalize_channel(channel) == CHANNEL_RC else VERSION_URL


def notes_url_for_channel(channel: str = CHANNEL_STABLE) -> str:
    return f"{RC_RAW_BASE}/update.MD" if normalize_channel(channel) == CHANNEL_RC else NOTES_URL


def exe_url_for_channel(channel: str = CHANNEL_STABLE) -> str:
    return f"{RC_RAW_BASE}/{EXE_FILENAME}" if normalize_channel(channel) == CHANNEL_RC else EXE_URL


def linux_package_url_for_channel(channel: str = CHANNEL_STABLE) -> str:
    return f"{RC_RAW_BASE}/{LINUX_PACKAGE_FILENAME}" if normalize_channel(channel) == CHANNEL_RC else LINUX_PACKAGE_URL


def parse_full_version(text: str) -> tuple[tuple[int, ...], int | None] | None:
    """Parse '1.4.0' -> ((1, 4, 0), None) or 'v1.4.1-rc2' -> ((1, 4, 1), 2). Returns None on invalid text."""
    cleaned = (text or "").replace("\ufeff", "").strip().lstrip("vV")
    m = _FULL_VERSION_RE.fullmatch(cleaned)
    if not m:
        return None
    nums = tuple(int(p) for p in m.group(1).split("."))
    rc = int(m.group(2)) if m.group(2) is not None else None
    return nums, rc


def parse_version(text: str) -> tuple[int, ...] | None:
    """'v1.2.3' / ' 1.2.3\n' -> (1, 2, 3); None when it is not a dotted numeric version."""
    parsed = parse_full_version(text)
    if parsed is None or parsed[1] is not None:
        return None
    return parsed[0]


def normalize_version(text: str) -> str:
    parsed = parse_full_version(text)
    if parsed is None:
        return ""
    nums, rc = parsed
    base = ".".join(str(p) for p in nums)
    return f"{base}-rc{rc}" if rc is not None else base


def is_rc_version(text: str) -> bool:
    parsed = parse_full_version(text)
    return bool(parsed is not None and parsed[1] is not None)


def _padded(v: tuple[int, ...]) -> tuple[int, ...]:
    return v + (0,) * (4 - len(v))


def _version_key(text: str) -> tuple[tuple[int, ...], int, int] | None:
    parsed = parse_full_version(text)
    if parsed is None:
        return None
    nums, rc = parsed
    # SemVer ordering: 1.4.0 < 1.4.1-rc1 < 1.4.1-rc2 < 1.4.1
    return (_padded(nums), 0 if rc is not None else 1, rc or 0)


def is_newer(remote: str, current: str | None = None) -> bool:
    cur = APP_VERSION if current is None else current
    rk, ck = _version_key(remote), _version_key(cur)
    return rk is not None and ck is not None and rk > ck


def compute_next_rc_version(current_version: str | None = None, existing_rc_version: str = "") -> str:
    """Compute `<patch+1>-rc1` from a Stable version (`1.4.0` -> `1.4.1-rc1`), or increment `-rcN` (`1.4.1-rc2`)."""
    base_ver = APP_VERSION if current_version is None else current_version
    parsed = parse_full_version(base_ver)
    if parsed is None:
        raise ValueError(f"Invalid base version: {base_ver!r}")
    nums, rc = parsed
    base3 = nums + (0,) * max(0, 3 - len(nums))
    if rc is None:
        target_nums = base3[:-1] + (base3[-1] + 1,)
        next_rc = 1
    else:
        target_nums = base3
        next_rc = rc + 1

    ex_parsed = parse_full_version(existing_rc_version) if existing_rc_version else None
    if ex_parsed is not None and ex_parsed[1] is not None:
        ex_nums, ex_rc = ex_parsed
        ex_base3 = ex_nums + (0,) * max(0, 3 - len(ex_nums))
        if _padded(ex_base3) == _padded(target_nums):
            next_rc = max(next_rc, ex_rc + 1)
        elif _padded(ex_base3) > _padded(target_nums):
            target_nums = ex_base3
            next_rc = ex_rc + 1

    return ".".join(str(p) for p in target_nums) + f"-rc{next_rc}"


def can_rollback_to_stable(remote_version: str, current: str | None = None, channel: str = CHANNEL_STABLE) -> bool:
    """True when running an `-rcN` build while on the Stable channel and remote offers a valid Stable build."""
    if normalize_channel(channel) != CHANNEL_STABLE:
        return False
    cur = APP_VERSION if current is None else current
    norm_remote = normalize_version(remote_version)
    return bool(norm_remote and not is_rc_version(norm_remote) and is_rc_version(cur))


def should_offer(
    info: UpdateInfo | None,
    skipped_version: str = "",
    current: str | None = None,
    *,
    channel: str | None = None,
) -> bool:
    """True for a newer version (or an RC -> Stable rollback) that the user has not chosen to skip."""
    if info is None:
        return False
    cur = APP_VERSION if current is None else current
    eff_channel = normalize_channel(channel if channel is not None else info.channel)
    eligible = info.allow_downgrade or is_newer(info.version, cur) or can_rollback_to_stable(info.version, cur, eff_channel)
    if not eligible:
        return False
    return normalize_version(skipped_version) != normalize_version(info.version)


def _get(url: str, **kwargs) -> requests.Response:
    # raw.githubusercontent.com sits behind a CDN cache; a unique query makes a fresh release visible at once
    sep = "&" if "?" in url else "?"
    return requests.get(f"{url}{sep}t={int(time.time())}", timeout=_HTTP_TIMEOUT,
                        headers={"Cache-Control": "no-cache", "User-Agent": f"BobGamingGameCenter/{APP_VERSION}"},
                        **kwargs)


def fetch_update_info(channel: str = CHANNEL_STABLE, current_version: str | None = None) -> UpdateInfo | None:
    """Latest published version + notes for `channel`, or None when offline / unreadable / malformed."""
    ch = normalize_channel(channel)
    cur = APP_VERSION if current_version is None else current_version
    v_url = version_url_for_channel(ch)
    n_url = notes_url_for_channel(ch)
    t0 = time.monotonic()
    resp = None
    try:
        resp = _get(v_url)
        resp.raise_for_status()
        version = normalize_version(resp.text)
        if not version:
            logger.warning(f"[Update] version.MD ({ch}) is not a version: {resp.text[:40]!r}")
            return None
        notes = ""
        notes_t0 = time.monotonic()
        notes_resp = None
        try:
            notes_resp = _get(n_url)
            if notes_resp.ok:
                notes = notes_resp.content.decode("utf-8-sig", errors="replace").strip()
            else:
                logger.warning(
                    f"[Update] update.MD request failed: url={n_url} status={notes_resp.status_code} "
                    f"duration={time.monotonic() - notes_t0:.2f}s"
                )
        except requests.RequestException as e:
            n_status = getattr(getattr(e, "response", None), "status_code", None) or getattr(notes_resp, "status_code", "N/A")
            logger.warning(
                f"[Update] update.MD unavailable: url={n_url} status={n_status} "
                f"duration={time.monotonic() - notes_t0:.2f}s err={e}"
            )
        downgrade = can_rollback_to_stable(version, cur, ch) and not is_newer(version, cur)
        logger.info(f"[Update] Checked remote version v{version} (channel={ch}) in {time.monotonic() - t0:.2f}s")
        return UpdateInfo(version=version, notes=notes, channel=ch, allow_downgrade=downgrade)
    except requests.RequestException as e:
        status = getattr(getattr(e, "response", None), "status_code", None) or getattr(resp, "status_code", "N/A")
        logger.warning(
            f"[Update] Check failed: channel={ch} url={v_url} status={status} duration={time.monotonic() - t0:.2f}s err={e}"
        )
        return None


def _download_artifact(
    url: str,
    filename: str,
    verifier: Callable[[str, int], None],
    progress: Callable[[int, int], None] | None = None,
    is_cancelled: Callable[[], bool] | None = None,
) -> str:
    from app.config import app_temp_dir

    dest_dir = app_temp_dir("update")
    final = os.path.join(dest_dir, filename)
    part = final + ".part"
    t0 = time.monotonic()
    resp = None
    logger.info(f"[Update] Starting update download: url={url} -> {final}")
    try:
        with _get(url, stream=True) as resp:
            resp.raise_for_status()
            total = int(resp.headers.get("Content-Length") or 0)
            done = 0
            with open(part, "wb") as f:
                for chunk in resp.iter_content(chunk_size=256 * 1024):
                    if is_cancelled and is_cancelled():
                        raise UpdateCancelled()
                    f.write(chunk)
                    done += len(chunk)
                    if progress:
                        progress(done, total)
        verifier(part, total)
        os.replace(part, final)
        logger.info(f"[Update] Downloaded {filename} ({done} bytes) in {time.monotonic() - t0:.2f}s")
        return final
    except UpdateCancelled:
        logger.info(f"[Update] Download cancelled after {time.monotonic() - t0:.2f}s: url={url}")
        try:
            os.remove(part)
        except OSError:
            pass
        raise
    except requests.RequestException as e:
        status = getattr(getattr(e, "response", None), "status_code", None) or getattr(resp, "status_code", "N/A")
        logger.error(
            f"[Update] Download network error: url={url} status={status} duration={time.monotonic() - t0:.2f}s err={e}"
        )
        try:
            os.remove(part)
        except OSError:
            pass
        raise
    except BaseException as e:
        logger.error(f"[Update] Download verification failed after {time.monotonic() - t0:.2f}s ({url}): {e}")
        try:
            os.remove(part)
        except OSError:
            pass
        raise


def download_exe(progress: Callable[[int, int], None] | None = None,
                 is_cancelled: Callable[[], bool] | None = None,
                 channel: str = CHANNEL_STABLE) -> str:
    """Download the new Windows exe into a temp folder and return its path. Raises on a bad/partial download."""
    return _download_artifact(exe_url_for_channel(channel), EXE_FILENAME, _verify_exe, progress, is_cancelled)


def download_linux_package(progress: Callable[[int, int], None] | None = None,
                           is_cancelled: Callable[[], bool] | None = None,
                           channel: str = CHANNEL_STABLE) -> str:
    """Download the new Linux .tar.gz bundle into a temp folder and return its path."""
    return _download_artifact(
        linux_package_url_for_channel(channel), LINUX_PACKAGE_FILENAME, _verify_linux_package, progress, is_cancelled
    )


def download_update(progress: Callable[[int, int], None] | None = None,
                    is_cancelled: Callable[[], bool] | None = None,
                    channel: str = CHANNEL_STABLE) -> str:
    """Download the platform-appropriate update artifact (.tar.gz on Linux, .exe on Windows)."""
    if sys.platform.startswith("linux"):
        return download_linux_package(progress, is_cancelled, channel=channel)
    return download_exe(progress, is_cancelled, channel=channel)


def _verify_exe(path: str, expected_size: int = 0):
    size = os.path.getsize(path)
    if size < _MIN_EXE_BYTES:
        raise ValueError(f"Downloaded file is too small ({size} bytes)")
    if expected_size and size != expected_size:
        raise ValueError(f"Download incomplete ({size}/{expected_size} bytes)")
    with open(path, "rb") as f:
        if f.read(2) != b"MZ":
            raise ValueError("Downloaded file is not a Windows executable")


def _verify_linux_package(path: str, expected_size: int = 0):
    size = os.path.getsize(path)
    if size < _MIN_LINUX_TAR_BYTES:
        raise ValueError(f"Downloaded Linux package is too small ({size} bytes)")
    if expected_size and size != expected_size:
        raise ValueError(f"Download incomplete ({size}/{expected_size} bytes)")
    with open(path, "rb") as f:
        if f.read(2) != b"\x1f\x8b":
            raise ValueError("Downloaded file is not a gzip archive")
    try:
        with tarfile.open(path, "r:gz") as tar:
            members = tar.getmembers()
    except tarfile.TarError as exc:
        raise ValueError(f"Corrupted update archive: {exc}") from exc

    seen_sizes: dict[str, int] = {}
    for member in members:
        norm = (member.name or "").replace("\\", "/").strip()
        if norm.startswith("./"):
            norm = norm[2:]
        parts = [p for p in norm.split("/") if p]
        if not parts or norm.startswith("/") or ":" in parts[0] or ".." in parts:
            raise ValueError(f"Unsafe path in update archive: {member.name!r}")
        if member.issym() or member.islnk():
            link_norm = (member.linkname or "").replace("\\", "/")
            if link_norm.startswith("/"):
                raise ValueError(f"Unsafe absolute symlink in update archive: {member.name!r} -> {member.linkname!r}")
            parent = "/".join(parts[:-1])
            joined = os.path.normpath(f"{parent}/{link_norm}" if parent else link_norm).replace("\\", "/")
            if joined == ".." or joined.startswith("../"):
                raise ValueError(f"Unsafe escaping symlink in update archive: {member.name!r} -> {member.linkname!r}")
        seen_sizes["/".join(parts)] = member.size

    for req in ("main.py", "app/version.py", "scripts/deck/bob_game_center.sh"):
        if req not in seen_sizes:
            raise ValueError("Update archive is missing core application files (main.py / app/version.py / bob_game_center.sh)")
        if seen_sizes[req] <= 0:
            raise ValueError(f"Update archive contains empty core file: {req}")


def get_linux_app_dir() -> str:
    """Resolve the root directory of the installed Linux bundle."""
    env_dir = os.environ.get("BOB_APP_DIR", "").strip()
    if env_dir:
        return os.path.abspath(env_dir)
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def can_self_update() -> bool:
    if sys.platform == "win32":
        return bool(getattr(sys, "frozen", False))
    if sys.platform.startswith("linux"):
        app_dir = get_linux_app_dir()
        if os.path.exists(os.path.join(app_dir, ".git")):
            return False
        return os.path.isfile(os.path.join(app_dir, "main.py")) and os.access(app_dir, os.W_OK)
    return False


def restart_environment(env: dict[str, str] | None = None) -> dict[str, str]:
    """Environment for the relaunched exe, without the running PyInstaller one-file process's state.

    A one-file exe hands its temp folder (_MEIxxxx) to the Python child through _PYI_* variables. A restart
    that inherits them makes the new exe look for python3xx.dll in the old, already deleted folder and fail
    with "Failed to load Python DLL" (the exe itself was replaced fine, so the next manual start works).
    """
    env = dict(os.environ if env is None else env)
    for key in list(env):
        if key.upper().startswith("_PYI_") or key.upper() == "_MEIPASS2":
            del env[key]
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"      # also tells PyInstaller >= 6.9 to start as a fresh process
    return env


def build_swap_script(new_exe: str, target_exe: str, script_path: str) -> str:
    """Batch file: wait until target_exe is unlocked, replace it, start it again, delete itself."""
    script = (
        "@echo off\r\n"
        "set tries=0\r\n"
        ":retry\r\n"
        f'move /y "{new_exe}" "{target_exe}" >nul 2>&1\r\n'
        "if not errorlevel 1 goto done\r\n"
        "set /a tries+=1\r\n"
        "if %tries% geq 60 goto fail\r\n"
        "timeout /t 1 /nobreak >nul\r\n"
        "goto retry\r\n"
        ":done\r\n"
        "set _MEIPASS2=\r\n"
        "set PYINSTALLER_RESET_ENVIRONMENT=1\r\n"
        "for /f \"tokens=1 delims==\" %%a in ('set _PYI_ 2^>nul') do set \"%%a=\"\r\n"
        f'start "" "{target_exe}"\r\n'
        ":fail\r\n"
        '(goto) 2>nul & del "%~f0"\r\n'
    )
    with open(script_path, "w", encoding="mbcs", errors="replace", newline="") as f:
        f.write(script)
    return script_path


def build_linux_swap_script(new_tar: str, target_dir: str, script_path: str, wait_pid: int | None = None) -> str:
    """POSIX shell script fallback when launched directly outside bob_game_center.sh."""
    q_tar = shlex.quote(new_tar)
    q_dir = shlex.quote(target_dir)
    pid_val = int(wait_pid) if wait_pid else 0
    script = (
        "#!/usr/bin/env bash\n"
        "set -uo pipefail\n"
        f"NEW_TAR={q_tar}\n"
        f"APP_DIR={q_dir}\n"
        f"WAIT_PID={pid_val}\n"
        "TRIES=0\n"
        'while [ "$WAIT_PID" -gt 0 ] && kill -0 "$WAIT_PID" 2>/dev/null; do\n'
        "    TRIES=$((TRIES + 1))\n"
        '    [ "$TRIES" -ge 120 ] && break\n'
        "    sleep 0.5\n"
        "done\n"
        'STAGE_DIR="$APP_DIR/.bob_update_staging"\n'
        'rm -rf "$STAGE_DIR"\n'
        'mkdir -p "$STAGE_DIR"\n'
        'OLD_REQ_HASH=""\n'
        '[ -f "$APP_DIR/requirements.txt" ] && OLD_REQ_HASH="$(sha256sum "$APP_DIR/requirements.txt" 2>/dev/null | awk \'{print $1}\')"\n'
        'if tar -xzf "$NEW_TAR" -C "$STAGE_DIR" && [ -s "$STAGE_DIR/main.py" ] && [ -s "$STAGE_DIR/scripts/deck/bob_game_center.sh" ]; then\n'
        "    if command -v rsync >/dev/null 2>&1; then\n"
        '        rsync -a --delete --exclude "venv" --exclude ".bob_update_staging" "$STAGE_DIR/" "$APP_DIR/"\n'
        "    else\n"
        '        cp -rf "$STAGE_DIR"/. "$APP_DIR/"\n'
        "    fi\n"
        '    chmod 755 "$APP_DIR/scripts/deck"/*.sh "$APP_DIR/native/bin/linux"/* "$APP_DIR/bin"/* 2>/dev/null || true\n'
        '    ln -sf "$APP_DIR/scripts/deck/bob_game_center.sh" "$APP_DIR/bob_game_center.sh"\n'
        '    NEW_REQ_HASH=""\n'
        '    [ -f "$APP_DIR/requirements.txt" ] && NEW_REQ_HASH="$(sha256sum "$APP_DIR/requirements.txt" 2>/dev/null | awk \'{print $1}\')"\n'
        '    if [ -n "$NEW_REQ_HASH" ] && [ "$OLD_REQ_HASH" != "$NEW_REQ_HASH" ] && [ -x "$APP_DIR/venv/bin/pip" ]; then\n'
        '        "$APP_DIR/venv/bin/pip" install --prefer-binary -r "$APP_DIR/requirements.txt" >/dev/null 2>&1 || true\n'
        "    fi\n"
        "fi\n"
        'rm -rf "$STAGE_DIR" "$NEW_TAR"\n'
        'if [ -x "$APP_DIR/bob_game_center.sh" ]; then\n'
        '    nohup "$APP_DIR/bob_game_center.sh" >/dev/null 2>&1 &\n'
        'elif [ -x "$APP_DIR/venv/bin/python" ]; then\n'
        '    nohup "$APP_DIR/venv/bin/python" "$APP_DIR/main.py" >/dev/null 2>&1 &\n'
        "fi\n"
        'rm -f -- "$0"\n'
    )
    with open(script_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(script)
    try:
        os.chmod(script_path, 0o755)
    except OSError:
        pass
    return script_path


def launch_swap_and_restart(new_exe: str) -> bool:
    """Apply downloaded update and trigger restart. Caller must quit the app right after when True."""
    if not can_self_update():
        logger.info(f"[Update] Self-update unavailable in current environment; downloaded build left at {new_exe}")
        return False

    if sys.platform.startswith("linux"):
        app_dir = get_linux_app_dir()
        _verify_linux_package(new_exe)
        if os.environ.get("BOB_WRAPPER_MANAGED") == "1":
            staged = os.path.join(app_dir, PENDING_LINUX_UPDATE_NAME)
            tmp_staged = f"{staged}.tmp.{os.getpid()}"
            try:
                shutil.copyfile(new_exe, tmp_staged)
                os.replace(tmp_staged, staged)
            except BaseException:
                try:
                    os.remove(tmp_staged)
                except OSError:
                    pass
                raise
            try:
                os.remove(new_exe)
            except OSError:
                pass
            logger.info(f"[Update] Staged Linux update for wrapper reload: {staged}")
            return True

        script = build_linux_swap_script(
            new_exe, app_dir, os.path.join(os.path.dirname(new_exe), "apply_update.sh"), wait_pid=os.getpid()
        )
        subprocess.Popen(
            ["/bin/bash", script],
            start_new_session=True,
            close_fds=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        logger.info(f"[Update] Linux swap script started: {app_dir} <- {new_exe}")
        return True

    script = build_swap_script(new_exe, sys.executable, os.path.join(os.path.dirname(new_exe), "apply_update.bat"))
    flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.Popen(["cmd.exe", "/c", script], creationflags=flags, close_fds=True, env=restart_environment(),
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    logger.info(f"[Update] Swap script started: {sys.executable} <- {new_exe}")
    return True
