"""Self-update: compare against the public release repo, download the new build, swap it in and restart.

The release repo (UPDATE_REPO) holds the release artifacts published by tools/release.py:
    version.MD                   only the version, e.g. "1.1.0"
    update.MD                    release notes shown in the update popup
    BobGamingCenter.exe          Windows single-file executable
    bob_game_center_deck.tar.gz  Linux / SteamOS user-space bundle
    install.sh                   One-line online installer for Linux / Steam Deck
"""

import logging
import os
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from dataclasses import dataclass
from typing import Callable

import requests

from app.version import APP_VERSION

logger = logging.getLogger(__name__)

UPDATE_REPO = "vodacthe/bob_gaming_game_center_public"
UPDATE_BRANCH = "main"
RAW_BASE = f"https://raw.githubusercontent.com/{UPDATE_REPO}/{UPDATE_BRANCH}"
VERSION_URL = f"{RAW_BASE}/version.MD"
NOTES_URL = f"{RAW_BASE}/update.MD"
EXE_FILENAME = "BobGamingCenter.exe"
EXE_URL = f"{RAW_BASE}/{EXE_FILENAME}"
LINUX_PACKAGE_FILENAME = "bob_game_center_deck.tar.gz"
LINUX_PACKAGE_URL = f"{RAW_BASE}/{LINUX_PACKAGE_FILENAME}"
LINUX_INSTALL_SCRIPT_FILENAME = "install.sh"
PENDING_LINUX_UPDATE_NAME = ".bob_pending_update.tar.gz"

CHECK_INTERVAL_MS = 15 * 60 * 1000
STARTUP_CHECK_DELAY_MS = 8000
_MIN_EXE_BYTES = 5 * 1024 * 1024     # anything smaller is an error page / truncated download
_MIN_LINUX_TAR_BYTES = 16 * 1024      # valid .tar.gz bundle is multi-MB; <16 KB is an error page / truncated file
_HTTP_TIMEOUT = 20


@dataclass(frozen=True)
class UpdateInfo:
    version: str
    notes: str


class UpdateCancelled(Exception):
    pass


def parse_version(text: str) -> tuple[int, ...] | None:
    """'v1.2.3' / ' 1.2.3\n' -> (1, 2, 3); None when it is not a dotted number."""
    cleaned = (text or "").replace("\ufeff", "").strip().lstrip("vV")
    if not re.fullmatch(r"\d+(\.\d+){0,3}", cleaned):
        return None
    return tuple(int(p) for p in cleaned.split("."))


def normalize_version(text: str) -> str:
    parsed = parse_version(text)
    return ".".join(str(p) for p in parsed) if parsed else ""


def _padded(v: tuple[int, ...]) -> tuple[int, ...]:
    return v + (0,) * (4 - len(v))


def is_newer(remote: str, current: str = APP_VERSION) -> bool:
    r, c = parse_version(remote), parse_version(current)
    return r is not None and c is not None and _padded(r) > _padded(c)


def should_offer(info: UpdateInfo | None, skipped_version: str = "", current: str = APP_VERSION) -> bool:
    """A newer version the user has not chosen to skip."""
    if info is None or not is_newer(info.version, current):
        return False
    return normalize_version(skipped_version) != normalize_version(info.version)


def _get(url: str, **kwargs) -> requests.Response:
    # raw.githubusercontent.com sits behind a CDN cache; a unique query makes a fresh release visible at once
    sep = "&" if "?" in url else "?"
    return requests.get(f"{url}{sep}t={int(time.time())}", timeout=_HTTP_TIMEOUT,
                        headers={"Cache-Control": "no-cache", "User-Agent": f"BobGamingGameCenter/{APP_VERSION}"},
                        **kwargs)


def fetch_update_info() -> UpdateInfo | None:
    """Latest published version + notes, or None when offline / the repo is not readable / malformed."""
    t0 = time.monotonic()
    resp = None
    try:
        resp = _get(VERSION_URL)
        resp.raise_for_status()
        version = normalize_version(resp.text)
        if not version:
            logger.warning(f"[Update] version.MD is not a version: {resp.text[:40]!r}")
            return None
        notes = ""
        notes_t0 = time.monotonic()
        notes_resp = None
        try:
            notes_resp = _get(NOTES_URL)
            if notes_resp.ok:
                notes = notes_resp.content.decode("utf-8-sig", errors="replace").strip()
            else:
                logger.warning(
                    f"[Update] update.MD request failed: url={NOTES_URL} status={notes_resp.status_code} "
                    f"duration={time.monotonic() - notes_t0:.2f}s"
                )
        except requests.RequestException as e:
            n_status = getattr(getattr(e, "response", None), "status_code", None) or getattr(notes_resp, "status_code", "N/A")
            logger.warning(
                f"[Update] update.MD unavailable: url={NOTES_URL} status={n_status} "
                f"duration={time.monotonic() - notes_t0:.2f}s err={e}"
            )
        logger.info(f"[Update] Checked remote version v{version} in {time.monotonic() - t0:.2f}s")
        return UpdateInfo(version, notes)
    except requests.RequestException as e:
        status = getattr(getattr(e, "response", None), "status_code", None) or getattr(resp, "status_code", "N/A")
        logger.warning(
            f"[Update] Check failed: url={VERSION_URL} status={status} duration={time.monotonic() - t0:.2f}s err={e}"
        )
        return None


def _download_artifact(
    url: str,
    filename: str,
    verifier: Callable[[str, int], None],
    progress: Callable[[int, int], None] | None = None,
    is_cancelled: Callable[[], bool] | None = None,
) -> str:
    dest_dir = os.path.join(tempfile.gettempdir(), "BobGamingUpdate")
    os.makedirs(dest_dir, exist_ok=True)
    final = os.path.join(dest_dir, filename)
    part = final + ".part"
    t0 = time.monotonic()
    resp = None
    logger.info(f"[Update] Starting update download: url={url} -> {final}")
    try:
        with _get(url, stream=True) as resp:
            resp.raise_for_status()
            total = int(resp.headers.get("Content-Length") or 0)
            done = 0
            with open(part, "wb") as f:
                for chunk in resp.iter_content(chunk_size=256 * 1024):
                    if is_cancelled and is_cancelled():
                        raise UpdateCancelled()
                    f.write(chunk)
                    done += len(chunk)
                    if progress:
                        progress(done, total)
        verifier(part, total)
        os.replace(part, final)
        logger.info(f"[Update] Downloaded {filename} ({done} bytes) in {time.monotonic() - t0:.2f}s")
        return final
    except UpdateCancelled:
        logger.info(f"[Update] Download cancelled after {time.monotonic() - t0:.2f}s: url={url}")
        try:
            os.remove(part)
        except OSError:
            pass
        raise
    except requests.RequestException as e:
        status = getattr(getattr(e, "response", None), "status_code", None) or getattr(resp, "status_code", "N/A")
        logger.error(
            f"[Update] Download network error: url={url} status={status} duration={time.monotonic() - t0:.2f}s err={e}"
        )
        try:
            os.remove(part)
        except OSError:
            pass
        raise
    except BaseException as e:
        logger.error(f"[Update] Download verification failed after {time.monotonic() - t0:.2f}s ({url}): {e}")
        try:
            os.remove(part)
        except OSError:
            pass
        raise


def download_exe(progress: Callable[[int, int], None] | None = None,
                 is_cancelled: Callable[[], bool] | None = None) -> str:
    """Download the new Windows exe into a temp folder and return its path. Raises on a bad/partial download."""
    return _download_artifact(EXE_URL, EXE_FILENAME, _verify_exe, progress, is_cancelled)


def download_linux_package(progress: Callable[[int, int], None] | None = None,
                           is_cancelled: Callable[[], bool] | None = None) -> str:
    """Download the new Linux .tar.gz bundle into a temp folder and return its path."""
    return _download_artifact(LINUX_PACKAGE_URL, LINUX_PACKAGE_FILENAME, _verify_linux_package, progress, is_cancelled)


def download_update(progress: Callable[[int, int], None] | None = None,
                    is_cancelled: Callable[[], bool] | None = None) -> str:
    """Download the platform-appropriate update artifact (.tar.gz on Linux, .exe on Windows)."""
    if sys.platform.startswith("linux"):
        return download_linux_package(progress, is_cancelled)
    return download_exe(progress, is_cancelled)


def _verify_exe(path: str, expected_size: int = 0):
    size = os.path.getsize(path)
    if size < _MIN_EXE_BYTES:
        raise ValueError(f"Downloaded file is too small ({size} bytes)")
    if expected_size and size != expected_size:
        raise ValueError(f"Download incomplete ({size}/{expected_size} bytes)")
    with open(path, "rb") as f:
        if f.read(2) != b"MZ":
            raise ValueError("Downloaded file is not a Windows executable")


def _verify_linux_package(path: str, expected_size: int = 0):
    size = os.path.getsize(path)
    if size < _MIN_LINUX_TAR_BYTES:
        raise ValueError(f"Downloaded Linux package is too small ({size} bytes)")
    if expected_size and size != expected_size:
        raise ValueError(f"Download incomplete ({size}/{expected_size} bytes)")
    with open(path, "rb") as f:
        if f.read(2) != b"\x1f\x8b":
            raise ValueError("Downloaded file is not a gzip archive")
    try:
        with tarfile.open(path, "r:gz") as tar:
            members = tar.getmembers()
    except tarfile.TarError as exc:
        raise ValueError(f"Corrupted update archive: {exc}") from exc

    seen_sizes: dict[str, int] = {}
    for member in members:
        norm = (member.name or "").replace("\\", "/").strip()
        if norm.startswith("./"):
            norm = norm[2:]
        parts = [p for p in norm.split("/") if p]
        if not parts or norm.startswith("/") or ":" in parts[0] or ".." in parts:
            raise ValueError(f"Unsafe path in update archive: {member.name!r}")
        if member.issym() or member.islnk():
            link_norm = (member.linkname or "").replace("\\", "/")
            if link_norm.startswith("/"):
                raise ValueError(f"Unsafe absolute symlink in update archive: {member.name!r} -> {member.linkname!r}")
            parent = "/".join(parts[:-1])
            joined = os.path.normpath(f"{parent}/{link_norm}" if parent else link_norm).replace("\\", "/")
            if joined == ".." or joined.startswith("../"):
                raise ValueError(f"Unsafe escaping symlink in update archive: {member.name!r} -> {member.linkname!r}")
        seen_sizes["/".join(parts)] = member.size

    for req in ("main.py", "app/version.py", "scripts/deck/bob_game_center.sh"):
        if req not in seen_sizes:
            raise ValueError("Update archive is missing core application files (main.py / app/version.py / bob_game_center.sh)")
        if seen_sizes[req] <= 0:
            raise ValueError(f"Update archive contains empty core file: {req}")



def get_linux_app_dir() -> str:
    """Resolve the root directory of the installed Linux bundle."""
    env_dir = os.environ.get("BOB_APP_DIR", "").strip()
    if env_dir:
        return os.path.abspath(env_dir)
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def can_self_update() -> bool:
    if sys.platform == "win32":
        return bool(getattr(sys, "frozen", False))
    if sys.platform.startswith("linux"):
        app_dir = get_linux_app_dir()
        if os.path.exists(os.path.join(app_dir, ".git")):
            return False
        return os.path.isfile(os.path.join(app_dir, "main.py")) and os.access(app_dir, os.W_OK)
    return False


def restart_environment(env: dict[str, str] | None = None) -> dict[str, str]:
    """Environment for the relaunched exe, without the running PyInstaller one-file process's state.

    A one-file exe hands its temp folder (_MEIxxxx) to the Python child through _PYI_* variables. A restart
    that inherits them makes the new exe look for python3xx.dll in the old, already deleted folder and fail
    with "Failed to load Python DLL" (the exe itself was replaced fine, so the next manual start works).
    """
    env = dict(os.environ if env is None else env)
    for key in list(env):
        if key.upper().startswith("_PYI_") or key.upper() == "_MEIPASS2":
            del env[key]
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"      # also tells PyInstaller >= 6.9 to start as a fresh process
    return env


def build_swap_script(new_exe: str, target_exe: str, script_path: str) -> str:
    """Batch file: wait until target_exe is unlocked, replace it, start it again, delete itself."""
    script = (
        "@echo off\r\n"
        "set tries=0\r\n"
        ":retry\r\n"
        f'move /y "{new_exe}" "{target_exe}" >nul 2>&1\r\n'
        "if not errorlevel 1 goto done\r\n"
        "set /a tries+=1\r\n"
        "if %tries% geq 60 goto fail\r\n"
        "timeout /t 1 /nobreak >nul\r\n"
        "goto retry\r\n"
        ":done\r\n"
        "set _MEIPASS2=\r\n"
        "set PYINSTALLER_RESET_ENVIRONMENT=1\r\n"
        "for /f \"tokens=1 delims==\" %%a in ('set _PYI_ 2^>nul') do set \"%%a=\"\r\n"
        f'start "" "{target_exe}"\r\n'
        ":fail\r\n"
        '(goto) 2>nul & del "%~f0"\r\n'
    )
    with open(script_path, "w", encoding="mbcs", errors="replace", newline="") as f:
        f.write(script)
    return script_path


def build_linux_swap_script(new_tar: str, target_dir: str, script_path: str, wait_pid: int | None = None) -> str:
    """POSIX shell script fallback when launched directly outside bob_game_center.sh."""
    q_tar = shlex.quote(new_tar)
    q_dir = shlex.quote(target_dir)
    pid_val = int(wait_pid) if wait_pid else 0
    script = (
        "#!/usr/bin/env bash\n"
        "set -uo pipefail\n"
        f"NEW_TAR={q_tar}\n"
        f"APP_DIR={q_dir}\n"
        f"WAIT_PID={pid_val}\n"
        "TRIES=0\n"
        'while [ "$WAIT_PID" -gt 0 ] && kill -0 "$WAIT_PID" 2>/dev/null; do\n'
        "    TRIES=$((TRIES + 1))\n"
        '    [ "$TRIES" -ge 120 ] && break\n'
        "    sleep 0.5\n"
        "done\n"
        'STAGE_DIR="$APP_DIR/.bob_update_staging"\n'
        'rm -rf "$STAGE_DIR"\n'
        'mkdir -p "$STAGE_DIR"\n'
        'OLD_REQ_HASH=""\n'
        '[ -f "$APP_DIR/requirements.txt" ] && OLD_REQ_HASH="$(sha256sum "$APP_DIR/requirements.txt" 2>/dev/null | awk \'{print $1}\')"\n'
        'if tar -xzf "$NEW_TAR" -C "$STAGE_DIR" && [ -s "$STAGE_DIR/main.py" ] && [ -s "$STAGE_DIR/scripts/deck/bob_game_center.sh" ]; then\n'
        "    if command -v rsync >/dev/null 2>&1; then\n"
        '        rsync -a --delete --exclude "venv" --exclude ".bob_update_staging" "$STAGE_DIR/" "$APP_DIR/"\n'
        "    else\n"
        '        cp -rf "$STAGE_DIR"/. "$APP_DIR/"\n'
        "    fi\n"
        '    chmod 755 "$APP_DIR/scripts/deck"/*.sh "$APP_DIR/native/bin/linux"/* "$APP_DIR/bin"/* 2>/dev/null || true\n'
        '    ln -sf "$APP_DIR/scripts/deck/bob_game_center.sh" "$APP_DIR/bob_game_center.sh"\n'
        '    NEW_REQ_HASH=""\n'
        '    [ -f "$APP_DIR/requirements.txt" ] && NEW_REQ_HASH="$(sha256sum "$APP_DIR/requirements.txt" 2>/dev/null | awk \'{print $1}\')"\n'
        '    if [ -n "$NEW_REQ_HASH" ] && [ "$OLD_REQ_HASH" != "$NEW_REQ_HASH" ] && [ -x "$APP_DIR/venv/bin/pip" ]; then\n'
        '        "$APP_DIR/venv/bin/pip" install --prefer-binary -r "$APP_DIR/requirements.txt" >/dev/null 2>&1 || true\n'
        "    fi\n"
        "fi\n"
        'rm -rf "$STAGE_DIR" "$NEW_TAR"\n'
        'if [ -x "$APP_DIR/bob_game_center.sh" ]; then\n'
        '    nohup "$APP_DIR/bob_game_center.sh" >/dev/null 2>&1 &\n'
        'elif [ -x "$APP_DIR/venv/bin/python" ]; then\n'
        '    nohup "$APP_DIR/venv/bin/python" "$APP_DIR/main.py" >/dev/null 2>&1 &\n'
        "fi\n"
        'rm -f -- "$0"\n'
    )
    with open(script_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(script)
    try:
        os.chmod(script_path, 0o755)
    except OSError:
        pass
    return script_path


def launch_swap_and_restart(new_exe: str) -> bool:
    """Apply downloaded update and trigger restart. Caller must quit the app right after when True."""
    if not can_self_update():
        logger.info(f"[Update] Self-update unavailable in current environment; downloaded build left at {new_exe}")
        return False

    if sys.platform.startswith("linux"):
        app_dir = get_linux_app_dir()
        _verify_linux_package(new_exe)
        if os.environ.get("BOB_WRAPPER_MANAGED") == "1":
            staged = os.path.join(app_dir, PENDING_LINUX_UPDATE_NAME)
            tmp_staged = f"{staged}.tmp.{os.getpid()}"
            try:
                shutil.copyfile(new_exe, tmp_staged)
                os.replace(tmp_staged, staged)
            except BaseException:
                try:
                    os.remove(tmp_staged)
                except OSError:
                    pass
                raise
            try:
                os.remove(new_exe)
            except OSError:
                pass
            logger.info(f"[Update] Staged Linux update for wrapper reload: {staged}")
            return True

        script = build_linux_swap_script(
            new_exe, app_dir, os.path.join(os.path.dirname(new_exe), "apply_update.sh"), wait_pid=os.getpid()
        )
        subprocess.Popen(
            ["/bin/bash", script],
            start_new_session=True,
            close_fds=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        logger.info(f"[Update] Linux swap script started: {app_dir} <- {new_exe}")
        return True

    script = build_swap_script(new_exe, sys.executable, os.path.join(os.path.dirname(new_exe), "apply_update.bat"))
    flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.Popen(["cmd.exe", "/c", script], creationflags=flags, close_fds=True, env=restart_environment(),
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    logger.info(f"[Update] Swap script started: {sys.executable} <- {new_exe}")
    return True
