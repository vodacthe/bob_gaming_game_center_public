"""Background QThread service translating Valve Steam Controller (2015) HID input to Virtual Xbox 360 (ViGEm).

All Win32 HID reads, feature reports, ViGEm updates, process checks, and driver installs run off the UI thread.
Unparented `QThread` workers are tracked in `_active_workers` and joined on `QApplication.aboutToQuit`.
"""

from __future__ import annotations

from dataclasses import asdict
import logging
import math
import os
import threading
import time
from typing import Any, Callable

from PySide6.QtCore import QObject, QThread, Signal
from PySide6.QtWidgets import QApplication

from app.config import save_config
from app.core.process_monitor import get_running_process_names
from app.core.steam_controller.hid_win32 import (
    SteamHidDevice,
    SteamHidInfo,
    enumerate_steam_controllers,
    send_win32_mouse_delta,
)
from app.core.steam_controller.protocol import (
    MouseDelta,
    STEAM_RPAD_TOUCH_MASK,
    SteamControllerRawState,
    SteamPacketParser,
    TranslatorConfig,
    XboxState,
    XboxTranslator,
)
from app.core.steam_controller.vigem import (
    ViGEmError,
    VirtualXbox360Pad,
    install_vigembus_driver,
    is_vigembus_installed,
)

logger = logging.getLogger(__name__)
TAG = "[SteamController/Service]"

_active_workers: set[QThread] = set()
_quit_hook_installed = False


def _ensure_quit_hook() -> None:
    global _quit_hook_installed
    if _quit_hook_installed:
        return
    app = QApplication.instance()
    if app is not None:
        app.aboutToQuit.connect(_stop_all_workers)
        _quit_hook_installed = True


def _stop_all_workers() -> None:
    for worker in list(_active_workers):
        try:
            if hasattr(worker, "request_stop"):
                worker.request_stop()
            worker.wait(2500)
        except Exception:  # noqa: BLE001
            pass
    _active_workers.clear()


def _untrack_worker(worker: QThread) -> None:
    _active_workers.discard(worker)


SCHEMA_VERSION = 5

DEFAULT_SERVICE_SETTINGS: dict[str, Any] = {
    **TranslatorConfig().to_dict(),
    "schema_version": SCHEMA_VERSION,
    "enabled": False,
    "manage_lizard_mode": True,
    "pause_when_steam_running": True,
    "haptics_enabled": True,
}


def _needs_imu(cfg: TranslatorConfig) -> bool:
    return cfg.left_grip_button == "gyro_hold" or cfg.right_grip_button == "gyro_hold"


def merge_service_settings(raw: dict | None) -> dict[str, Any]:
    d = dict(DEFAULT_SERVICE_SETTINGS)
    if isinstance(raw, dict):
        d.update(raw)
        try:
            prev_ver = int(raw.get("schema_version", 1))
        except (TypeError, ValueError):
            prev_ver = 1
        if prev_ver < 2 and raw.get("left_pad_mode") == "dpad_touch":
            d["left_pad_mode"] = "dpad_click"
        # Migrate v1/v2 default ("trackball") to absolute position joystick & restore sensitivities lowered due to jitter
        if prev_ver < 3:
            if raw.get("right_pad_mode") == "trackball":
                d["right_pad_mode"] = "joystick"
            if float(d.get("right_pad_sensitivity", 1.0)) < 0.5:
                d["right_pad_sensitivity"] = 1.0
            if float(d.get("gyro_sensitivity", 1.0)) < 0.5:
                d["gyro_sensitivity"] = 1.0
        if prev_ver < 4 and "stick_outer_percent" not in raw:
            d["stick_outer_percent"] = 90
        if prev_ver < 5 and "mouse_sensitivity" not in raw:
            d["mouse_sensitivity"] = 1.0
    tcfg = TranslatorConfig.from_dict(d)
    d.update(tcfg.to_dict())
    d["schema_version"] = SCHEMA_VERSION
    d["enabled"] = bool(d.get("enabled", False))
    d["manage_lizard_mode"] = bool(d.get("manage_lizard_mode", True))
    d["pause_when_steam_running"] = bool(d.get("pause_when_steam_running", True))
    d["haptics_enabled"] = bool(d.get("haptics_enabled", True))
    return d


class _DeviceSlot:
    """Runtime state for one opened Steam Controller HID endpoint."""

    def __init__(self, info: SteamHidInfo, hid_dev: SteamHidDevice, cfg: TranslatorConfig) -> None:
        self.info = info
        self.hid = hid_dev
        self.parser = SteamPacketParser()
        self.translator = XboxTranslator(cfg)
        self.pad: VirtualXbox360Pad | None = None
        self.connected = False
        self.lizard_disabled = False
        self.imu_enabled = False
        self.last_frame_ts = time.monotonic()
        self.last_xbox = XboxState()
        self.last_haptic_ts = 0.0
        self.last_pad_haptic_ts = [0.0, 0.0]
        self._rumble_lock = threading.Lock()
        self._pending_rumble: tuple[int, int] | None = None

    def queue_rumble(self, large: int, small: int, _led: int) -> None:
        with self._rumble_lock:
            self._pending_rumble = (large, small)

    def pop_rumble(self) -> tuple[int, int] | None:
        with self._rumble_lock:
            val = self._pending_rumble
            self._pending_rumble = None
            return val


class _DriverInstallWorker(QThread):
    progress_emitted = Signal(int, str)
    finished_emitted = Signal(bool, str)

    def __init__(self, install_fn: Callable) -> None:
        super().__init__(None)
        self._install_fn = install_fn
        self._stop_event = threading.Event()

    def request_stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        try:
            ok, msg = self._install_fn(
                progress_cb=lambda pct, txt: self.progress_emitted.emit(int(pct), str(txt)),
                is_cancelled=self._stop_event.is_set,
            )
            self.finished_emitted.emit(bool(ok), str(msg))
        except Exception as exc:  # noqa: BLE001
            logger.error("%s Driver install worker crashed: %s", TAG, exc, exc_info=True)
            self.finished_emitted.emit(False, f"Lỗi cài đặt ViGEmBus: {exc}")


class _TranslatorWorker(QThread):
    status_emitted = Signal(dict)
    preview_emitted = Signal(dict)

    def __init__(
        self,
        settings: dict[str, Any],
        *,
        preview_enabled: bool,
        enumerate_fn: Callable[[], list[SteamHidInfo]],
        open_hid_fn: Callable[[SteamHidInfo], SteamHidDevice],
        create_pad_fn: Callable[..., VirtualXbox360Pad],
        check_driver_fn: Callable[[], tuple[bool, str]],
        process_names_fn: Callable[[], set[str]],
        mouse_inject_fn: Callable[[MouseDelta], Any] = send_win32_mouse_delta,
    ) -> None:
        super().__init__(None)
        self._lock = threading.Lock()
        self._settings = merge_service_settings(settings)
        self._translator_cfg = TranslatorConfig.from_dict(self._settings)
        self._preview_enabled = bool(preview_enabled)
        self._stop_event = threading.Event()
        self._enumerate_fn = enumerate_fn
        self._open_hid_fn = open_hid_fn
        self._create_pad_fn = create_pad_fn
        self._check_driver_fn = check_driver_fn
        self._process_names_fn = process_names_fn
        self._mouse_inject_fn = mouse_inject_fn
        self._last_status: dict[str, Any] | None = None

    def request_stop(self) -> None:
        self._stop_event.set()

    def update_settings(self, settings: dict[str, Any]) -> None:
        merged = merge_service_settings(settings)
        with self._lock:
            self._settings = merged
            self._translator_cfg = TranslatorConfig.from_dict(merged)

    def set_preview_enabled(self, enabled: bool) -> None:
        with self._lock:
            self._preview_enabled = bool(enabled)

    def _emit_status(self, payload: dict[str, Any]) -> None:
        if payload != self._last_status:
            self._last_status = dict(payload)
            self.status_emitted.emit(dict(payload))

    def _activate_slot(self, slot: _DeviceSlot, manage_lizard: bool, needs_imu: bool) -> str | None:
        """Create VirtualXbox360Pad, disable Lizard Mode, and configure IMU on a physical Steam Controller."""
        if slot.pad is None:
            try:
                slot.pad = self._create_pad_fn(on_rumble=slot.queue_rumble)
            except ViGEmError as exc:
                logger.warning("%s Cannot create virtual Xbox 360 pad: %s", TAG, exc)
                return str(exc)
            except Exception as exc:  # noqa: BLE001
                logger.error("%s Unexpected error creating virtual Xbox 360 pad: %s", TAG, exc, exc_info=True)
                return str(exc)

        if manage_lizard and not slot.lizard_disabled:
            try:
                try:
                    slot.lizard_disabled = bool(slot.hid.disable_lizard_mode(enable_imu=needs_imu))
                except TypeError:
                    slot.lizard_disabled = bool(slot.hid.disable_lizard_mode())
                    if needs_imu and hasattr(slot.hid, "set_imu_enabled"):
                        slot.hid.set_imu_enabled(True)
                slot.imu_enabled = bool(needs_imu)
            except Exception as exc:  # noqa: BLE001
                logger.warning("%s Failed to disable Lizard Mode on %s: %s", TAG, slot.info.label, exc)
        elif needs_imu and not slot.imu_enabled and hasattr(slot.hid, "set_imu_enabled"):
            try:
                slot.imu_enabled = bool(slot.hid.set_imu_enabled(True))
            except Exception as exc:  # noqa: BLE001
                logger.warning("%s Failed to enable IMU gyro on %s: %s", TAG, slot.info.label, exc)

        slot.connected = True
        slot.last_frame_ts = time.monotonic()
        logger.info(
            "%s Active Steam Controller (%s, pid=0x%04X, xinput_slot=%s, imu=%s)",
            TAG,
            slot.info.label,
            slot.info.product_id,
            slot.pad.user_index,
            slot.imu_enabled,
        )
        return None

    def _deactivate_slot_pad(self, slot: _DeviceSlot, *, restore_lizard: bool) -> None:
        if restore_lizard and slot.lizard_disabled:
            try:
                slot.hid.restore_lizard_mode()
            except Exception:  # noqa: BLE001
                pass
            slot.lizard_disabled = False
        elif restore_lizard and slot.imu_enabled and hasattr(slot.hid, "set_imu_enabled"):
            try:
                slot.hid.set_imu_enabled(False)
            except Exception:  # noqa: BLE001
                pass
        slot.imu_enabled = False
        if slot.pad is not None:
            try:
                slot.pad.close()
            except Exception:  # noqa: BLE001
                pass
            slot.pad = None
        if slot.connected:
            logger.info("%s Steam Controller disconnected (%s)", TAG, slot.info.label)
        rel_mouse = slot.translator.release_mouse()
        if rel_mouse.has_activity:
            try:
                self._mouse_inject_fn(rel_mouse)
            except Exception:  # noqa: BLE001
                pass
        slot.connected = False
        slot.parser.reset()
        slot.translator.reset()
        slot.last_xbox = XboxState()

    def _close_all_slots(self, slots: dict[str, _DeviceSlot], *, restore_lizard: bool) -> None:
        for slot in list(slots.values()):
            self._deactivate_slot_pad(slot, restore_lizard=restore_lizard)
            try:
                slot.hid.close()
            except Exception:  # noqa: BLE001
                pass
        slots.clear()

    def run(self) -> None:
        t_start = time.monotonic()
        slots: dict[str, _DeviceSlot] = {}
        logger.info("%s Translation worker started", TAG)
        try:
            drv_ok, drv_msg = self._check_driver_fn()
            if not drv_ok:
                logger.warning("%s Cannot start translation — ViGEmBus unavailable: %s", TAG, drv_msg)
                self._emit_status({
                    "running": False,
                    "state": "driver_missing",
                    "driver_ok": False,
                    "driver_message": drv_msg,
                    "steam_running": False,
                    "connected_count": 0,
                    "devices": [],
                    "error": drv_msg,
                })
                return

            last_scan_ts = 0.0
            last_steam_ts = 0.0
            last_idle_wireless_ts = 0.0
            last_preview_ts = 0.0
            steam_running = False
            paused_for_steam = False
            last_err = ""

            while not self._stop_event.is_set():
                now = time.monotonic()
                with self._lock:
                    cfg_dict = dict(self._settings)
                    t_cfg = self._translator_cfg
                    preview_on = self._preview_enabled

                needs_imu = _needs_imu(t_cfg)
                for slot in slots.values():
                    slot.translator.config = t_cfg
                    if slot.connected and slot.imu_enabled != needs_imu:
                        if hasattr(slot.hid, "set_imu_enabled"):
                            try:
                                slot.hid.set_imu_enabled(needs_imu)
                            except Exception as exc:  # noqa: BLE001
                                logger.warning("%s Failed to toggle IMU=%s on %s: %s", TAG, needs_imu, slot.info.label, exc)
                        slot.imu_enabled = needs_imu
                        logger.info("%s Toggled IMU gyro=%s on %s", TAG, needs_imu, slot.info.label)

                # 1. Periodic Steam process check (every 3.0s)
                if now - last_steam_ts >= 3.0:
                    last_steam_ts = now
                    try:
                        steam_running = "steam.exe" in self._process_names_fn()
                    except Exception:  # noqa: BLE001
                        steam_running = False

                should_pause_steam = bool(cfg_dict.get("pause_when_steam_running", True)) and steam_running
                if should_pause_steam:
                    if not paused_for_steam:
                        paused_for_steam = True
                        logger.warning("%s Detected running steam.exe — pausing XInput translation to avoid conflict", TAG)
                        self._close_all_slots(slots, restore_lizard=False)
                    self._emit_status({
                        "running": True,
                        "state": "paused_steam",
                        "driver_ok": True,
                        "driver_message": drv_msg,
                        "steam_running": True,
                        "connected_count": 0,
                        "devices": [],
                        "error": "",
                    })
                    self._stop_event.wait(0.25)
                    continue
                if paused_for_steam:
                    paused_for_steam = False
                    last_scan_ts = 0.0
                    logger.info("%s steam.exe closed or conflict guard disabled — resuming translation", TAG)

                # 2. Periodic HID enumeration (every 1.5s when waiting, 2.5s when active)
                has_active = any(s.connected for s in slots.values())
                scan_interval = 2.5 if has_active else 1.5
                if now - last_scan_ts >= scan_interval:
                    last_scan_ts = now
                    try:
                        infos = self._enumerate_fn()
                    except Exception as exc:  # noqa: BLE001
                        infos = []
                        logger.warning("%s HID enumeration error: %s", TAG, exc)

                    present_paths = {inf.path for inf in infos}
                    for dead_path in [p for p in slots if p not in present_paths]:
                        dead_slot = slots.pop(dead_path)
                        self._deactivate_slot_pad(dead_slot, restore_lizard=False)
                        try:
                            dead_slot.hid.close()
                        except Exception:  # noqa: BLE001
                            pass

                    for inf in infos:
                        if inf.path in slots:
                            continue
                        try:
                            hid_dev = self._open_hid_fn(inf)
                        except OSError:
                            continue
                        slot = _DeviceSlot(inf, hid_dev, t_cfg)
                        slots[inf.path] = slot
                        if inf.transport == "wireless":
                            try:
                                is_conn = hid_dev.probe_wireless_connected()
                            except Exception:  # noqa: BLE001
                                is_conn = False
                            if is_conn:
                                err = self._activate_slot(slot, bool(cfg_dict.get("manage_lizard_mode", True)), needs_imu)
                                if err:
                                    last_err = err
                        else:
                            err = self._activate_slot(slot, bool(cfg_dict.get("manage_lizard_mode", True)), needs_imu)
                            if err:
                                last_err = err

                # 3. Publish status snapshot if changed
                active_slots = [s for s in slots.values() if s.connected and s.pad is not None]
                devices_summary = [
                    {
                        "label": s.info.label,
                        "transport": s.info.transport,
                        "pid": s.info.product_id,
                        "player_slot": s.pad.user_index if s.pad else -1,
                        "battery_percent": s.parser.state.battery_percent,
                    }
                    for s in active_slots
                ]
                self._emit_status({
                    "running": True,
                    "state": "active" if active_slots else "waiting_device",
                    "driver_ok": True,
                    "driver_message": drv_msg,
                    "steam_running": steam_running,
                    "connected_count": len(active_slots),
                    "devices": devices_summary,
                    "error": last_err if not active_slots else "",
                })

                if not slots:
                    self._stop_event.wait(0.2)
                    continue

                # 4. Read packets from open endpoints
                poll_idle_wireless = (now - last_idle_wireless_ts) >= 0.2
                if poll_idle_wireless:
                    last_idle_wireless_ts = now

                unplugged: list[str] = []
                for path, slot in list(slots.items()):
                    if not slot.connected and not poll_idle_wireless:
                        continue

                    timeout_ms = 12 if (slot.connected and len(active_slots) == 1) else (3 if slot.connected else 1)
                    try:
                        pkt = slot.hid.read_packet(timeout_ms=timeout_ms)
                    except OSError:
                        unplugged.append(path)
                        continue

                    now_pkt = time.monotonic()
                    dt = max(0.002, min(0.05, now_pkt - slot.last_frame_ts))

                    if pkt is not None:
                        kind, payload = slot.parser.parse_packet(pkt)
                        if kind == "wireless":
                            if payload is True and not slot.connected:
                                err = self._activate_slot(slot, bool(cfg_dict.get("manage_lizard_mode", True)), needs_imu)
                                if err:
                                    last_err = err
                            elif payload is False and slot.connected:
                                self._deactivate_slot_pad(slot, restore_lizard=False)
                        elif kind == "state" and isinstance(payload, SteamControllerRawState):
                            if not slot.connected:
                                err = self._activate_slot(slot, bool(cfg_dict.get("manage_lizard_mode", True)), needs_imu)
                                if err:
                                    last_err = err
                            if slot.pad is not None:
                                slot.last_frame_ts = now_pkt
                                xbox = slot.translator.translate(payload, dt)
                                slot.last_xbox = xbox
                                slot.pad.update(xbox)
                                if slot.translator.last_mouse.has_activity:
                                    self._mouse_inject_fn(slot.translator.last_mouse)
                                if slot.translator.last_haptics and cfg_dict.get("haptics_enabled", True):
                                    for pad_idx, dur_us, cnt in slot.translator.last_haptics:
                                        p_i = 1 if pad_idx else 0
                                        min_gap = 0.014 if dur_us >= 400 else 0.026
                                        if now_pkt - slot.last_pad_haptic_ts[p_i] >= min_gap:
                                            slot.last_pad_haptic_ts[p_i] = now_pkt
                                            if hasattr(slot.hid, "pulse_tick"):
                                                slot.hid.pulse_tick(p_i, duration_us=dur_us, count=cnt)
                                            else:
                                                slot.hid.pulse_haptic(p_i, min(1.0, dur_us / 1500.0))
                    elif slot.connected and slot.pad is not None and dt >= 0.016:
                        # Only decay post-lift trackball coasting when radio is genuinely idle after thumb release;
                        # NEVER re-translate on read timeouts while touching the pad (would see dx=0 and snap RS to 0!)
                        if (
                            slot.translator.config.right_pad_mode == "trackball"
                            and not (slot.parser.state.buttons & STEAM_RPAD_TOUCH_MASK)
                            and math.hypot(slot.translator._vel_x, slot.translator._vel_y) >= 0.015
                        ):
                            slot.last_frame_ts = now_pkt
                            xbox = slot.translator.translate(slot.parser.state, dt)
                            slot.last_xbox = xbox
                            slot.pad.update(xbox)

                    # Forward XInput rumble to Steam Controller L/R haptic actuators (throttled <= 20 Hz)
                    if slot.connected:
                        rumble = slot.pop_rumble()
                        if rumble is not None and cfg_dict.get("haptics_enabled", True):
                            if now_pkt - slot.last_haptic_ts >= 0.05:
                                large, small = rumble
                                slot.last_haptic_ts = now_pkt
                                if large > 4:
                                    slot.hid.pulse_haptic(1, large / 255.0)
                                if small > 4:
                                    slot.hid.pulse_haptic(0, small / 255.0)

                for path in unplugged:
                    dead = slots.pop(path, None)
                    if dead is not None:
                        self._deactivate_slot_pad(dead, restore_lizard=False)
                        try:
                            dead.hid.close()
                        except Exception:  # noqa: BLE001
                            pass

                # 5. Throttled UI preview (~25 Hz) when user has the Steam Controller tab visible
                if preview_on and active_slots:
                    now_prev = time.monotonic()
                    if now_prev - last_preview_ts >= 0.04:
                        last_preview_ts = now_prev
                        primary = active_slots[0]
                        self.preview_emitted.emit({
                            "xbox": asdict(primary.last_xbox),
                            "raw": asdict(primary.parser.state),
                            "device_label": primary.info.label,
                            "player_slot": primary.pad.user_index if primary.pad else -1,
                            "battery_percent": primary.parser.state.battery_percent,
                        })

                if not active_slots:
                    self._stop_event.wait(0.05)

        except Exception as exc:  # noqa: BLE001
            logger.error("%s Unexpected worker failure: %s", TAG, exc, exc_info=True)
            self._emit_status({
                "running": False,
                "state": "error",
                "driver_ok": True,
                "driver_message": "",
                "steam_running": False,
                "connected_count": 0,
                "devices": [],
                "error": str(exc),
            })
        finally:
            restore_lizard = bool(self._settings.get("manage_lizard_mode", True))
            self._close_all_slots(slots, restore_lizard=restore_lizard)
            logger.info("%s Translation worker stopped (ran %.2fs)", TAG, time.monotonic() - t_start)


class SteamControllerService(QObject):
    """UI-facing controller service managing settings persistence, ViGEmBus status, and worker lifecycle."""

    status_changed = Signal(dict)
    live_preview = Signal(dict)
    driver_install_progress = Signal(int, str)
    driver_install_finished = Signal(bool, str)

    def __init__(
        self,
        config: dict,
        parent: QObject | None = None,
        *,
        enumerate_fn: Callable[[], list[SteamHidInfo]] = enumerate_steam_controllers,
        open_hid_fn: Callable[[SteamHidInfo], SteamHidDevice] = SteamHidDevice,
        create_pad_fn: Callable[..., VirtualXbox360Pad] = VirtualXbox360Pad,
        check_driver_fn: Callable[[], tuple[bool, str]] = is_vigembus_installed,
        install_driver_fn: Callable = install_vigembus_driver,
        process_names_fn: Callable[[], set[str]] = get_running_process_names,
        mouse_inject_fn: Callable[[MouseDelta], Any] = send_win32_mouse_delta,
    ) -> None:
        super().__init__(parent)
        _ensure_quit_hook()
        self._config = config
        raw_sc = self._config.get("steam_controller")
        if isinstance(raw_sc, dict) and raw_sc and int(raw_sc.get("schema_version", 1)) < SCHEMA_VERSION:
            self._config["steam_controller"] = merge_service_settings(raw_sc)
        self._enumerate_fn = enumerate_fn
        self._open_hid_fn = open_hid_fn
        self._create_pad_fn = create_pad_fn
        self._check_driver_fn = check_driver_fn
        self._install_driver_fn = install_driver_fn
        self._process_names_fn = process_names_fn
        self._mouse_inject_fn = mouse_inject_fn

        self._worker: _TranslatorWorker | None = None
        self._install_worker: _DriverInstallWorker | None = None
        self._preview_enabled = False
        self._status: dict[str, Any] = {
            "running": False,
            "state": "stopped",
            "driver_ok": False,
            "driver_message": "",
            "steam_running": False,
            "connected_count": 0,
            "devices": [],
            "error": "",
        }

    @property
    def is_inert(self) -> bool:
        return os.environ.get("BOBGAMING_STEAMCONTROLLER_DISABLE") == "1"

    def get_settings(self) -> dict[str, Any]:
        return merge_service_settings(self._config.get("steam_controller"))

    def get_status(self) -> dict[str, Any]:
        return dict(self._status)

    def is_running(self) -> bool:
        return bool(self._worker is not None and self._worker.isRunning())

    def refresh_environment_status(self) -> dict[str, Any]:
        """Synchronously refresh ViGEmBus and Steam status when idle."""
        if self.is_inert:
            return dict(self._status)
        drv_ok, drv_msg = self._check_driver_fn()
        try:
            steam_on = "steam.exe" in self._process_names_fn()
        except Exception:  # noqa: BLE001
            steam_on = False
        if not self.is_running():
            self._set_status({
                "running": False,
                "state": "stopped" if drv_ok else "driver_missing",
                "driver_ok": drv_ok,
                "driver_message": drv_msg,
                "steam_running": steam_on,
                "connected_count": 0,
                "devices": [],
                "error": "",
            })
        return dict(self._status)

    def update_settings(
        self,
        updates: dict[str, Any],
        *,
        persist: bool = True,
        log_change: bool = True,
    ) -> dict[str, Any]:
        cur = self.get_settings()
        cur.update(updates)
        merged = merge_service_settings(cur)
        self._config["steam_controller"] = merged
        if persist:
            save_config(self._config)
        if self._worker is not None:
            self._worker.update_settings(merged)
        if log_change:
            logger.info(
                "%s Updated settings (lpad=%s, rpad=%s, sens=%.2f, msens=%.2f, dz=%d%%, outer=%d%%, lg=%s, rg=%s, gyro=%s@%.2fx, haptics=%s, pause_steam=%s)",
                TAG,
                merged["left_pad_mode"],
                merged["right_pad_mode"],
                merged["right_pad_sensitivity"],
                merged["mouse_sensitivity"],
                merged["deadzone_percent"],
                merged["stick_outer_percent"],
                merged["left_grip_button"],
                merged["right_grip_button"],
                merged["gyro_axis_mode"],
                merged["gyro_sensitivity"],
                merged["haptics_enabled"],
                merged["pause_when_steam_running"],
            )
        return merged

    def set_preview_enabled(self, enabled: bool) -> None:
        self._preview_enabled = bool(enabled)
        if self._worker is not None:
            self._worker.set_preview_enabled(self._preview_enabled)

    def start(self, *, persist: bool = True) -> bool:
        if self.is_inert:
            logger.info("%s Skipped start (BOBGAMING_STEAMCONTROLLER_DISABLE=1)", TAG)
            return False
        if self.is_running():
            return True

        drv_ok, drv_msg = self._check_driver_fn()
        if not drv_ok:
            logger.warning("%s Refused start — %s", TAG, drv_msg)
            self._set_status({
                "running": False,
                "state": "driver_missing",
                "driver_ok": False,
                "driver_message": drv_msg,
                "steam_running": False,
                "connected_count": 0,
                "devices": [],
                "error": drv_msg,
            })
            return False

        settings = self.update_settings({"enabled": True}, persist=persist)
        worker = _TranslatorWorker(
            settings,
            preview_enabled=self._preview_enabled,
            enumerate_fn=self._enumerate_fn,
            open_hid_fn=self._open_hid_fn,
            create_pad_fn=self._create_pad_fn,
            check_driver_fn=self._check_driver_fn,
            process_names_fn=self._process_names_fn,
            mouse_inject_fn=self._mouse_inject_fn,
        )
        worker.status_emitted.connect(self._set_status)
        worker.preview_emitted.connect(self.live_preview.emit)
        worker.finished.connect(lambda w=worker: _untrack_worker(w))
        _active_workers.add(worker)
        self._worker = worker
        logger.info("%s Starting Steam Controller -> XInput service", TAG)
        worker.start()
        return True

    def stop(self, *, persist: bool = True) -> None:
        if persist:
            cur = self.get_settings()
            cur["enabled"] = False
            self._config["steam_controller"] = cur
            save_config(self._config)

        worker = self._worker
        self._worker = None
        if worker is not None:
            logger.info("%s Stopping Steam Controller -> XInput service", TAG)
            worker.request_stop()
            worker.wait(2500)
            _untrack_worker(worker)

        drv_ok, drv_msg = (False, "") if self.is_inert else self._check_driver_fn()
        self._set_status({
            "running": False,
            "state": "stopped" if drv_ok else "driver_missing",
            "driver_ok": drv_ok,
            "driver_message": drv_msg,
            "steam_running": False,
            "connected_count": 0,
            "devices": [],
            "error": "",
        })

    def shutdown(self) -> None:
        """Stop runtime translation on app exit without clearing the user's `enabled` preference."""
        if self._install_worker is not None and self._install_worker.isRunning():
            self._install_worker.request_stop()
            self._install_worker.wait(2000)
            _untrack_worker(self._install_worker)
        self._install_worker = None
        self.stop(persist=False)

    def factory_reset(self) -> None:
        self.stop(persist=False)
        self._config["steam_controller"] = {}

    def install_driver(self) -> bool:
        """Start asynchronous 1-click download & silent install of ViGEmBus v1.22.0."""
        if self._install_worker is not None and self._install_worker.isRunning():
            return False

        logger.info("%s User triggered 1-click ViGEmBus driver install", TAG)
        worker = _DriverInstallWorker(self._install_driver_fn)
        worker.progress_emitted.connect(self.driver_install_progress.emit)
        worker.finished_emitted.connect(self._on_driver_install_done)
        worker.finished.connect(lambda w=worker: _untrack_worker(w))
        _active_workers.add(worker)
        self._install_worker = worker
        worker.start()
        return True

    def _on_driver_install_done(self, ok: bool, msg: str) -> None:
        self._install_worker = None
        self.refresh_environment_status()
        self.driver_install_finished.emit(ok, msg)

    def _set_status(self, st: dict[str, Any]) -> None:
        self._status = dict(st)
        self.status_changed.emit(dict(st))
