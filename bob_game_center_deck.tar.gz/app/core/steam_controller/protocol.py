"""Valve Steam Controller (2015) packet parser, feature-report builders, and Xbox 360 translator.

Pure Python (no Win32 / Qt imports) so protocol decoding and trackpad-to-stick maths are deterministic and fast to test.
Byte offsets, 15-degree trackpad rotation, and interleaved stick/pad decoding match Linux `hid-steam.c` and SDL2
`SDL_hidapi_steam.c`.
"""

from __future__ import annotations

import logging
import math
import struct
from dataclasses import asdict, dataclass

logger = logging.getLogger(__name__)
TAG = "[SteamController/Protocol]"

VALVE_VID = 0x28DE
PID_WIRED = 0x1102
PID_WIRELESS = 0x1142
PID_BLE_OLD = 0x1105
PID_BLE = 0x1106

SUPPORTED_PIDS: dict[int, str] = {
    PID_WIRED: "USB",
    PID_WIRELESS: "Wireless 2.4GHz",
    PID_BLE_OLD: "Bluetooth LE",
    PID_BLE: "Bluetooth LE",
}

# Input message types (byte 2 of 64-byte Valve report)
ID_CONTROLLER_STATE = 0x01
ID_CONTROLLER_WIRELESS = 0x03
ID_CONTROLLER_STATUS = 0x04
ID_CONTROLLER_BLE_STATE = 0x07

WIRELESS_EVENT_DISCONNECT = 0x01
WIRELESS_EVENT_CONNECT = 0x02
WIRELESS_EVENT_PAIR = 0x03

# Feature report command IDs
ID_CLEAR_DIGITAL_MAPPINGS = 0x81
ID_GET_ATTRIBUTES_VALUES = 0x83
ID_SET_DEFAULT_DIGITAL_MAPPINGS = 0x85
ID_SET_SETTINGS_VALUES = 0x87
ID_LOAD_DEFAULT_SETTINGS = 0x8E
ID_TRIGGER_HAPTIC_PULSE = 0x8F

# Controller settings registers
SETTING_LEFT_TRACKPAD_MODE = 7
SETTING_RIGHT_TRACKPAD_MODE = 8
SETTING_SMOOTH_ABSOLUTE_MOUSE = 24
SETTING_LEFT_DPAD_REQUIRES_CLICK = 42
SETTING_IMU_MODE = 48
SETTING_WIRELESS_PACKET_VERSION = 49
TRACKPAD_ABSOLUTE_MOUSE = 0
TRACKPAD_NONE = 7
GYRO_MODE_OFF = 0x0000
GYRO_MODE_RAW_GYRO = 0x0010  # SEND_RAW_GYRO only -> 100% wireless IMU frames carry gyro (no alternating accel frames)
GYRO_MODE_RAW_ACCEL_AND_GYRO = GYRO_MODE_RAW_GYRO

# BLE framing constants (from SDL_hidapi_steam.c / controller_structs.h)
BLE_REPORT_NUMBER = 0x03
BLE_REPORT_STATE = 0x04
BLE_SEGMENT_PAYLOAD = 18
BLE_SEGMENT_SIZE = 20
BLE_SEGMENT_DATA_FLAG = 0x80
BLE_SEGMENT_LAST_FLAG = 0x40

BLE_CHUNK_BUTTON1 = 0x0010
BLE_CHUNK_TRIGGERS = 0x0020
BLE_CHUNK_BUTTON3 = 0x0040
BLE_CHUNK_LEFT_STICK = 0x0080
BLE_CHUNK_LEFT_PAD = 0x0100
BLE_CHUNK_RIGHT_PAD = 0x0200
BLE_CHUNK_ACCEL = 0x0400
BLE_CHUNK_GYRO = 0x0800

# Steam Controller 24-bit button masks (bytes 8..10 of 64-byte state packet)
STEAM_RT_FULL_MASK = 0x000001
STEAM_LT_FULL_MASK = 0x000002
STEAM_RB_MASK = 0x000004
STEAM_LB_MASK = 0x000008
STEAM_Y_MASK = 0x000010
STEAM_B_MASK = 0x000020
STEAM_X_MASK = 0x000040
STEAM_A_MASK = 0x000080
STEAM_DPAD_UP_MASK = 0x000100
STEAM_DPAD_RIGHT_MASK = 0x000200
STEAM_DPAD_LEFT_MASK = 0x000400
STEAM_DPAD_DOWN_MASK = 0x000800
STEAM_BACK_MASK = 0x001000
STEAM_GUIDE_MASK = 0x002000
STEAM_START_MASK = 0x004000
STEAM_GRIP_LEFT_MASK = 0x008000
STEAM_GRIP_RIGHT_MASK = 0x010000
STEAM_LPAD_CLICK_MASK = 0x020000
STEAM_RPAD_CLICK_MASK = 0x040000
STEAM_LPAD_TOUCH_MASK = 0x080000
STEAM_RPAD_TOUCH_MASK = 0x100000
STEAM_STICK_CLICK_MASK = 0x400000
STEAM_LPAD_AND_JOY_MASK = 0x800000

# ViGEm / XInput XUSB_BUTTON masks
XUSB_DPAD_UP = 0x0001
XUSB_DPAD_DOWN = 0x0002
XUSB_DPAD_LEFT = 0x0004
XUSB_DPAD_RIGHT = 0x0008
XUSB_START = 0x0010
XUSB_BACK = 0x0020
XUSB_LEFT_THUMB = 0x0040
XUSB_RIGHT_THUMB = 0x0080
XUSB_LEFT_SHOULDER = 0x0100
XUSB_RIGHT_SHOULDER = 0x0200
XUSB_GUIDE = 0x0400
XUSB_A = 0x1000
XUSB_B = 0x2000
XUSB_X = 0x4000
XUSB_Y = 0x8000

GRIP_TARGETS: dict[str, tuple[str, int]] = {
    "gyro_hold": ("Giữ để ngắm Gyro (Cần phải RS)", 0),
    "mouse_hold": ("Giữ để dùng Chuột (Phải di chuột, Trái cuộn)", 0),
    "a": ("A", XUSB_A),
    "b": ("B", XUSB_B),
    "x": ("X", XUSB_X),
    "y": ("Y", XUSB_Y),
    "lb": ("LB", XUSB_LEFT_SHOULDER),
    "rb": ("RB", XUSB_RIGHT_SHOULDER),
    "ls": ("L3 (Nhấn cần trái)", XUSB_LEFT_THUMB),
    "rs": ("R3 (Nhấn cần phải)", XUSB_RIGHT_THUMB),
    "dpad_up": ("D-Pad Lên", XUSB_DPAD_UP),
    "dpad_down": ("D-Pad Xuống", XUSB_DPAD_DOWN),
    "dpad_left": ("D-Pad Trái", XUSB_DPAD_LEFT),
    "dpad_right": ("D-Pad Phải", XUSB_DPAD_RIGHT),
    "back": ("Back / View", XUSB_BACK),
    "start": ("Start / Menu", XUSB_START),
    "none": ("Không gán", 0),
}

LEFT_PAD_MODES: tuple[str, ...] = ("dpad_click", "dpad_touch", "off")
RIGHT_PAD_MODES: tuple[str, ...] = ("joystick", "trackball", "off")
GYRO_AXIS_MODES: tuple[str, ...] = ("yaw", "roll", "yaw_roll")

# Hardware calibration constants from Valve's SDL_hidapi_steam.c
_PAD_ROTATION_RAD = 0.261799  # 15 degrees natural thumb angle
_COS_15 = math.cos(_PAD_ROTATION_RAD)
_SIN_15 = math.sin(_PAD_ROTATION_RAD)
_TRIGGER_FULL_ANALOG_U8 = 204  # ~26000 / 32767: dual-stage wall before mechanical click
_AXIS_MAX = 32767
_TRACKBALL_SPEED_FULL = 42000.0  # pad units/sec for full right-stick deflection at sensitivity 1.0
_TRACKBALL_ANTI_DEADZONE = 5200  # gentle inner deadzone compensation for explicit trackball mode only
_TRACKBALL_STEP_DEADBAND = 180.0  # ~0.11 mm capacitive jitter deadband so resting thumb never spikes velocity
_TRACKBALL_DECAY = 11.0  # velocity decay per second after thumb lift
_GYRO_SPEED_FULL = 2400.0  # ~146 deg/s angular rate (16.384 LSB per deg/s) for full stick at sensitivity 1.0
_GYRO_NOISE_GATE = 65.0  # ~4.0 deg/s gate filters hand tremor when squeezing stiff 2015 rear grip paddles
_GYRO_BIAS_STATIONARY_MAX = 55.0  # adapt zero-rate bias inside stationary floor


def _clamp_s16(val: float | int) -> int:
    iv = int(round(val))
    return -_AXIS_MAX if iv < -_AXIS_MAX else (_AXIS_MAX if iv > _AXIS_MAX else iv)


def _rotate_pad(x: int, y: int, sign: float) -> tuple[int, int]:
    """Rotate trackpad coordinates by +/-15 degrees (Valve hardware sensor orientation)."""
    cos_a = _COS_15
    sin_a = _SIN_15 * sign
    rx = int(cos_a * x - sin_a * y)
    ry = int(sin_a * x + cos_a * y)
    return rx, ry


def _scale_trigger(raw_u8: int, full_click: bool) -> int:
    if full_click:
        return 255
    if raw_u8 <= 0:
        return 0
    return min(255, int(round(raw_u8 * 255.0 / _TRIGGER_FULL_ANALOG_U8)))


@dataclass
class SteamControllerRawState:
    packet_num: int = 0
    buttons: int = 0
    left_stick_x: int = 0
    left_stick_y: int = 0
    left_pad_x: int = 0
    left_pad_y: int = 0
    right_pad_x: int = 0
    right_pad_y: int = 0
    left_trigger: int = 0
    right_trigger: int = 0
    gyro_x: int = 0
    gyro_y: int = 0
    gyro_z: int = 0
    battery_percent: int | None = None


@dataclass
class XboxState:
    buttons: int = 0
    left_trigger: int = 0
    right_trigger: int = 0
    lx: int = 0
    ly: int = 0
    rx: int = 0
    ry: int = 0


@dataclass
class MouseDelta:
    dx: int = 0
    dy: int = 0
    wheel: int = 0
    left_down: bool | None = None
    right_down: bool | None = None

    @property
    def has_activity(self) -> bool:
        return (
            self.dx != 0
            or self.dy != 0
            or self.wheel != 0
            or self.left_down is not None
            or self.right_down is not None
        )


@dataclass
class TranslatorConfig:
    enabled: bool = False
    auto_start_on_connect: bool = True
    pause_when_steam_running: bool = False
    left_pad_mode: str = "dpad_click"       # "dpad_click" | "dpad_touch" | "off"
    right_pad_mode: str = "joystick"        # "joystick" | "trackball" | "off"
    right_pad_sensitivity: float = 1.0      # 0.2 .. 3.0
    mouse_sensitivity: float = 1.0          # 0.2 .. 3.0
    deadzone_percent: int = 12              # 0 .. 40
    stick_outer_percent: int = 90           # 60 .. 100 (% of post-deadzone travel that reaches 100% stick)
    invert_right_y: bool = False
    left_grip_button: str = "a"
    right_grip_button: str = "b"
    gyro_axis_mode: str = "yaw"             # "yaw" | "roll" | "yaw_roll"
    gyro_sensitivity: float = 1.0           # 0.25 .. 4.0
    invert_gyro_x: bool = False
    invert_gyro_y: bool = False
    haptics_enabled: bool = True

    @classmethod
    def from_dict(cls, raw: dict | None) -> "TranslatorConfig":
        if not isinstance(raw, dict):
            return cls()
        cfg = cls()
        cfg.enabled = bool(raw.get("enabled", cfg.enabled))
        cfg.auto_start_on_connect = bool(raw.get("auto_start_on_connect", cfg.auto_start_on_connect))
        cfg.pause_when_steam_running = bool(raw.get("pause_when_steam_running", cfg.pause_when_steam_running))
        lmode = str(raw.get("left_pad_mode", cfg.left_pad_mode))
        cfg.left_pad_mode = lmode if lmode in LEFT_PAD_MODES else "dpad_click"
        rmode = str(raw.get("right_pad_mode", cfg.right_pad_mode))
        cfg.right_pad_mode = rmode if rmode in RIGHT_PAD_MODES else "joystick"
        try:
            cfg.right_pad_sensitivity = max(0.2, min(3.0, float(raw.get("right_pad_sensitivity", 1.0))))
        except (TypeError, ValueError):
            cfg.right_pad_sensitivity = 1.0
        try:
            cfg.mouse_sensitivity = max(0.2, min(3.0, float(raw.get("mouse_sensitivity", 1.0))))
        except (TypeError, ValueError):
            cfg.mouse_sensitivity = 1.0
        try:
            cfg.deadzone_percent = max(0, min(40, int(raw.get("deadzone_percent", 12))))
        except (TypeError, ValueError):
            cfg.deadzone_percent = 12
        try:
            cfg.stick_outer_percent = max(60, min(100, int(raw.get("stick_outer_percent", 90))))
        except (TypeError, ValueError):
            cfg.stick_outer_percent = 90
        cfg.invert_right_y = bool(raw.get("invert_right_y", False))
        lg = str(raw.get("left_grip_button", "a"))
        rg = str(raw.get("right_grip_button", "b"))
        cfg.left_grip_button = lg if lg in GRIP_TARGETS else "a"
        cfg.right_grip_button = rg if rg in GRIP_TARGETS else "b"
        gmode = str(raw.get("gyro_axis_mode", "yaw"))
        cfg.gyro_axis_mode = gmode if gmode in GYRO_AXIS_MODES else "yaw"
        try:
            cfg.gyro_sensitivity = max(0.25, min(4.0, float(raw.get("gyro_sensitivity", 1.0))))
        except (TypeError, ValueError):
            cfg.gyro_sensitivity = 1.0
        cfg.invert_gyro_x = bool(raw.get("invert_gyro_x", False))
        cfg.invert_gyro_y = bool(raw.get("invert_gyro_y", False))
        cfg.haptics_enabled = bool(raw.get("haptics_enabled", True))
        return cfg

    def to_dict(self) -> dict:
        return asdict(self)


class SteamPacketParser:
    """Stateful packet decoder per physical Steam Controller (handles interleaved stick/pad & BLE delta chunks)."""

    def __init__(self) -> None:
        self.state = SteamControllerRawState()
        self._prev_stick = [0, 0]
        self._prev_lpad = [0, 0]
        self._ble_raw_buttons = 0
        self._ble_trig_l = 0
        self._ble_trig_r = 0

    def reset(self) -> None:
        self.state = SteamControllerRawState()
        self._prev_stick = [0, 0]
        self._prev_lpad = [0, 0]
        self._ble_raw_buttons = 0
        self._ble_trig_l = 0
        self._ble_trig_r = 0

    def parse_packet(self, raw: bytes | bytearray | memoryview) -> tuple[str, SteamControllerRawState | bool | None]:
        """Decode one USB, Wireless Dongle, or BLE input report. Never raises."""
        buf = bytes(raw)
        if not buf:
            return ("ignore", None)

        # Strip Windows HID unnumbered report ID prefix (0x00 + 64 bytes)
        if len(buf) == 65 and buf[0] == 0x00:
            buf = buf[1:]

        # 64-byte USB / 2.4GHz Wireless Valve protocol report (starts with 0x01, 0x00)
        if len(buf) >= 64 and buf[0] == 0x01 and buf[1] == 0x00:
            msg_type = buf[2]
            if msg_type in (ID_CONTROLLER_STATE, ID_CONTROLLER_BLE_STATE):
                return ("state", self._parse_usb_wireless_state(buf, msg_type))
            if msg_type == ID_CONTROLLER_WIRELESS and len(buf) >= 5:
                ev = buf[4]
                if ev in (WIRELESS_EVENT_CONNECT, WIRELESS_EVENT_PAIR):
                    return ("wireless", True)
                if ev == WIRELESS_EVENT_DISCONNECT:
                    self.reset()
                    return ("wireless", False)
            if msg_type == ID_CONTROLLER_STATUS and len(buf) >= 15:
                pct = min(100, max(0, int(buf[14])))
                self.state.battery_percent = pct
                return ("status", self.state)
            return ("ignore", None)

        # BLE GATT HID input report (optional leading report ID 0x03)
        ble = buf[1:] if buf[0] == BLE_REPORT_NUMBER and len(buf) >= 3 else buf
        if len(ble) >= 2 and (ble[0] & 0x0F) == BLE_REPORT_STATE:
            parsed = self._parse_ble_state(ble)
            return ("state", parsed) if parsed is not None else ("ignore", None)

        return ("ignore", None)

    def _parse_usb_wireless_state(self, data: bytes, msg_type: int = ID_CONTROLLER_STATE) -> SteamControllerRawState:
        pkt_num = struct.unpack_from("<I", data, 4)[0]
        if pkt_num == self.state.packet_num and pkt_num != 0:
            return self.state

        buttons = data[8] | (data[9] << 8) | (data[10] << 16)
        raw_lt = data[11]
        raw_rt = data[12]
        lx_or_pad, ly_or_pad, rpad_x, rpad_y = struct.unpack_from("<hhhh", data, 16)
        lx_or_pad = _clamp_s16(lx_or_pad)
        ly_or_pad = _clamp_s16(ly_or_pad)
        rpad_x = _clamp_s16(rpad_x)
        rpad_y = _clamp_s16(rpad_y)

        # Firmware interleaves Left Stick and Left Trackpad on bytes 16..19 when both are touched
        if buttons & STEAM_LPAD_TOUCH_MASK:
            lpad_x, lpad_y = lx_or_pad, ly_or_pad
            self._prev_lpad = [lpad_x, lpad_y]
            if buttons & STEAM_LPAD_AND_JOY_MASK:
                stick_x, stick_y = self._prev_stick
            else:
                stick_x = stick_y = 0
                self._prev_stick = [0, 0]
        else:
            stick_x, stick_y = lx_or_pad, ly_or_pad
            self._prev_stick = [stick_x, stick_y]
            if buttons & STEAM_LPAD_AND_JOY_MASK:
                lpad_x, lpad_y = self._prev_lpad
            else:
                lpad_x = lpad_y = 0
                self._prev_lpad = [0, 0]
                # Early 2015 firmware reports LPad click when clicking L3 while LPad is untouched
                if buttons & STEAM_LPAD_CLICK_MASK:
                    buttons = (buttons & ~STEAM_LPAD_CLICK_MASK) | STEAM_STICK_CLICK_MASK

        if buttons & STEAM_LPAD_AND_JOY_MASK:
            buttons |= STEAM_LPAD_TOUCH_MASK

        rot_lx, rot_ly = _rotate_pad(lpad_x, lpad_y, -1.0)
        rot_rx, rot_ry = _rotate_pad(rpad_x, rpad_y, +1.0)
        l_off = 1000 if (buttons & STEAM_LPAD_TOUCH_MASK) else 0
        r_off = 1000 if (buttons & STEAM_RPAD_TOUCH_MASK) else 0

        st = self.state
        st.packet_num = pkt_num
        st.buttons = buttons
        st.left_stick_x = stick_x
        st.left_stick_y = stick_y
        st.left_pad_x = _clamp_s16(rot_lx + l_off) if l_off else 0
        st.left_pad_y = _clamp_s16(rot_ly + l_off) if l_off else 0
        st.right_pad_x = _clamp_s16(rot_rx + r_off) if r_off else 0
        st.right_pad_y = _clamp_s16(rot_ry + r_off) if r_off else 0
        st.left_trigger = _scale_trigger(raw_lt, bool(buttons & STEAM_LT_FULL_MASK))
        st.right_trigger = _scale_trigger(raw_rt, bool(buttons & STEAM_RT_FULL_MASK))
        payload_end = min(len(data), 4 + data[3])
        if msg_type == ID_CONTROLLER_STATE and payload_end >= 40:
            gx, gy, gz = struct.unpack_from("<hhh", data, 34)
            st.gyro_x, st.gyro_y, st.gyro_z = _clamp_s16(gx), _clamp_s16(gy), _clamp_s16(gz)
        elif msg_type == ID_CONTROLLER_BLE_STATE and payload_end >= 31 and data[24] == 3:
            gx, gy, gz = struct.unpack_from("<hhh", data, 25)
            st.gyro_x, st.gyro_y, st.gyro_z = _clamp_s16(gx), _clamp_s16(gy), _clamp_s16(gz)
        return st

    def _parse_ble_state(self, data: bytes) -> SteamControllerRawState | None:
        mask = (data[0] & 0xF0) | (data[1] << 8)
        idx = 2
        st = self.state

        if mask & BLE_CHUNK_BUTTON1:
            if idx + 3 > len(data):
                return None
            self._ble_raw_buttons = data[idx] | (data[idx + 1] << 8) | (data[idx + 2] << 16)
            idx += 3

        if mask & BLE_CHUNK_TRIGGERS:
            if idx + 2 > len(data):
                return None
            self._ble_trig_l = data[idx]
            self._ble_trig_r = data[idx + 1]
            idx += 2

        if mask & BLE_CHUNK_BUTTON3:
            if idx + 3 > len(data):
                return None
            idx += 3  # upper bytes unused on 2015 D0G controller

        buttons = self._ble_raw_buttons
        st.buttons = buttons
        st.left_trigger = _scale_trigger(self._ble_trig_l, bool(buttons & STEAM_LT_FULL_MASK))
        st.right_trigger = _scale_trigger(self._ble_trig_r, bool(buttons & STEAM_RT_FULL_MASK))

        if mask & BLE_CHUNK_LEFT_STICK:
            if idx + 4 > len(data):
                return None
            lx, ly = struct.unpack_from("<hh", data, idx)
            st.left_stick_x = _clamp_s16(lx)
            st.left_stick_y = _clamp_s16(ly)
            idx += 4

        if mask & BLE_CHUNK_LEFT_PAD:
            if idx + 4 > len(data):
                return None
            px, py = struct.unpack_from("<hh", data, idx)
            rot_x, rot_y = _rotate_pad(px, py, -1.0)
            off = 1000 if (buttons & STEAM_LPAD_TOUCH_MASK) else 0
            st.left_pad_x = _clamp_s16(rot_x + off) if off else 0
            st.left_pad_y = _clamp_s16(rot_y + off) if off else 0
            idx += 4
        elif not (buttons & STEAM_LPAD_TOUCH_MASK):
            st.left_pad_x = st.left_pad_y = 0

        if mask & BLE_CHUNK_RIGHT_PAD:
            if idx + 4 > len(data):
                return None
            px, py = struct.unpack_from("<hh", data, idx)
            rot_x, rot_y = _rotate_pad(px, py, +1.0)
            off = 1000 if (buttons & STEAM_RPAD_TOUCH_MASK) else 0
            st.right_pad_x = _clamp_s16(rot_x + off) if off else 0
            st.right_pad_y = _clamp_s16(rot_y + off) if off else 0
        elif not (buttons & STEAM_RPAD_TOUCH_MASK):
            st.right_pad_x = st.right_pad_y = 0

        if mask & BLE_CHUNK_ACCEL:
            if idx + 6 > len(data):
                return None
            idx += 6

        if mask & BLE_CHUNK_GYRO:
            if idx + 6 > len(data):
                return None
            gx, gy, gz = struct.unpack_from("<hhh", data, idx)
            st.gyro_x, st.gyro_y, st.gyro_z = _clamp_s16(gx), _clamp_s16(gy), _clamp_s16(gz)
            idx += 6

        st.packet_num = (st.packet_num + 1) & 0xFFFFFFFF
        return st


# ---------------------------------------------------------------- feature report builders

def _pack_feature_report(cmd_id: int, payload: bytes = b"") -> bytes:
    buf = bytearray(65)
    buf[0] = 0x00  # HID report ID
    buf[1] = cmd_id & 0xFF
    buf[2] = len(payload) & 0xFF
    buf[3 : 3 + len(payload)] = payload
    return bytes(buf)


def build_settings_report(pairs: list[tuple[int, int]]) -> bytes:
    payload = bytearray()
    for reg, val in pairs:
        payload.append(reg & 0xFF)
        payload.extend(struct.pack("<H", val & 0xFFFF))
    return _pack_feature_report(ID_SET_SETTINGS_VALUES, bytes(payload))


def build_imu_mode_report(enable: bool) -> bytes:
    """Enable or disable raw IMU gyro + accelerometer streaming (`SETTING_IMU_MODE = 48`)."""
    return build_settings_report([
        (SETTING_IMU_MODE, GYRO_MODE_RAW_ACCEL_AND_GYRO if enable else GYRO_MODE_OFF),
    ])


def build_disable_lizard_reports(*, enable_imu: bool = False) -> list[bytes]:
    """Reports sent on start: clear keyboard/mouse lizard bindings, require click on left D-Pad, and configure IMU."""
    return [
        _pack_feature_report(ID_CLEAR_DIGITAL_MAPPINGS),
        _pack_feature_report(ID_LOAD_DEFAULT_SETTINGS),
        build_settings_report([
            (SETTING_WIRELESS_PACKET_VERSION, 2),
            (SETTING_LEFT_TRACKPAD_MODE, TRACKPAD_NONE),
            (SETTING_RIGHT_TRACKPAD_MODE, TRACKPAD_NONE),
            (SETTING_LEFT_DPAD_REQUIRES_CLICK, 1),
            (SETTING_SMOOTH_ABSOLUTE_MOUSE, 0),
            (SETTING_IMU_MODE, GYRO_MODE_RAW_ACCEL_AND_GYRO if enable_imu else GYRO_MODE_OFF),
        ]),
    ]


def build_restore_lizard_reports() -> list[bytes]:
    """Reports sent on stop/exit so desktop Lizard Mode works normally again without Steam."""
    return [
        _pack_feature_report(ID_SET_DEFAULT_DIGITAL_MAPPINGS),
        _pack_feature_report(ID_LOAD_DEFAULT_SETTINGS),
        build_settings_report([
            (SETTING_RIGHT_TRACKPAD_MODE, TRACKPAD_ABSOLUTE_MOUSE),
            (SETTING_IMU_MODE, GYRO_MODE_OFF),
        ]),
    ]


def build_get_attributes_report() -> bytes:
    return _pack_feature_report(ID_GET_ATTRIBUTES_VALUES)


def build_haptic_pulse_report(
    pad: int,
    duration_us: int = 1200,
    interval_us: int = 8000,
    count: int = 4,
    gain_db: int = 0,
) -> bytes:
    """pad: 0 = Right actuator, 1 = Left actuator (Valve firmware convention)."""
    payload = struct.pack(
        "<BHHHhB",
        pad & 0xFF,
        max(50, min(65535, int(duration_us))),
        max(50, min(65535, int(interval_us))),
        max(1, min(65535, int(count))),
        max(-12, min(12, int(gain_db))),
        0,
    )
    return _pack_feature_report(ID_TRIGGER_HAPTIC_PULSE, payload)


def segment_ble_feature_report(report65: bytes, actual_len: int | None = None) -> list[bytes]:
    """Split a 65-byte feature report into 20-byte BLE GATT segments (report ID 0x03)."""
    if not report65:
        return []
    body = report65[1:]
    if actual_len is None:
        # 2-byte header (cmd, len) + payload length
        actual_len = min(len(body), 2 + body[1]) if len(body) >= 2 else len(body)
    data = body[: max(1, actual_len)]
    segments: list[bytes] = []
    seg_num = 0
    offset = 0
    while offset < len(data):
        chunk = data[offset : offset + BLE_SEGMENT_PAYLOAD]
        offset += len(chunk)
        hdr = BLE_SEGMENT_DATA_FLAG | (seg_num & 0x07)
        if offset >= len(data):
            hdr |= BLE_SEGMENT_LAST_FLAG
        pkt = bytearray(BLE_SEGMENT_SIZE)
        pkt[0] = BLE_REPORT_NUMBER
        pkt[1] = hdr
        pkt[2 : 2 + len(chunk)] = chunk
        segments.append(bytes(pkt))
        seg_num += 1
    return segments


# ---------------------------------------------------------------- Steam -> Xbox 360 translator

_DIRECT_BUTTON_MAP: tuple[tuple[int, int], ...] = (
    (STEAM_A_MASK, XUSB_A),
    (STEAM_B_MASK, XUSB_B),
    (STEAM_X_MASK, XUSB_X),
    (STEAM_Y_MASK, XUSB_Y),
    (STEAM_LB_MASK, XUSB_LEFT_SHOULDER),
    (STEAM_RB_MASK, XUSB_RIGHT_SHOULDER),
    (STEAM_BACK_MASK, XUSB_BACK),
    (STEAM_START_MASK, XUSB_START),
    (STEAM_GUIDE_MASK, XUSB_GUIDE),
    (STEAM_STICK_CLICK_MASK, XUSB_LEFT_THUMB),
    (STEAM_RPAD_CLICK_MASK, XUSB_RIGHT_THUMB),
)


def _apply_radial_deadzone(
    x: int,
    y: int,
    dz_fraction: float,
    scale: float = 1.0,
    outer_fraction: float = 0.90,
) -> tuple[int, int]:
    mag = math.hypot(x, y) / _AXIS_MAX
    if mag <= dz_fraction or mag <= 1e-6:
        return 0, 0
    cur_norm = (mag - dz_fraction) / max(1e-6, 1.0 - dz_fraction)
    norm = min(1.0, (cur_norm / max(0.50, outer_fraction)) * scale)
    factor = norm / mag
    return _clamp_s16(x * factor), _clamp_s16(y * factor)


class XboxTranslator:
    """Translates `SteamControllerRawState` frames into `XboxState` with trackpad, grip & gyro customisation."""

    def __init__(self, config: TranslatorConfig | None = None) -> None:
        self.config = config or TranslatorConfig()
        self.last_mouse = MouseDelta()
        self.last_haptics: list[tuple[int, int, int]] = []
        self._rpad_was_touched = False
        self._prev_rx = 0
        self._prev_ry = 0
        self._vel_x = 0.0
        self._vel_y = 0.0
        self._joy_rx = 0.0
        self._joy_ry = 0.0
        self._gyro_vx = 0.0
        self._gyro_vy = 0.0
        self._gyro_bias = [0.0, 0.0, 0.0]
        self._mouse_rpad_touched = False
        self._mouse_touch_frames = 0
        self._mouse_prev_rx = 0
        self._mouse_prev_ry = 0
        self._mouse_vx = 0.0
        self._mouse_vy = 0.0
        self._mouse_rem_x = 0.0
        self._mouse_rem_y = 0.0
        self._mouse_lpad_touched = False
        self._mouse_prev_ly = 0
        self._mouse_scroll_rem = 0.0
        self._mouse_left_pressed = False
        self._mouse_right_pressed = False
        self._mouse_suppress_buttons = 0
        self._mouse_suppress_lt = False
        self._mouse_suppress_rt = False
        self._hap_rpad_touched = False
        self._hap_lpad_touched = False
        self._hap_prev_rx = 0
        self._hap_prev_ry = 0
        self._hap_rpad_dist = 0.0
        self._hap_prev_dpad = 0

    def reset(self) -> None:
        self.last_mouse = MouseDelta()
        self.last_haptics = []
        self._rpad_was_touched = False
        self._prev_rx = 0
        self._prev_ry = 0
        self._vel_x = 0.0
        self._vel_y = 0.0
        self._joy_rx = 0.0
        self._joy_ry = 0.0
        self._gyro_vx = 0.0
        self._gyro_vy = 0.0
        self._gyro_bias = [0.0, 0.0, 0.0]
        self._mouse_rpad_touched = False
        self._mouse_touch_frames = 0
        self._mouse_prev_rx = 0
        self._mouse_prev_ry = 0
        self._mouse_vx = 0.0
        self._mouse_vy = 0.0
        self._mouse_rem_x = 0.0
        self._mouse_rem_y = 0.0
        self._mouse_lpad_touched = False
        self._mouse_prev_ly = 0
        self._mouse_scroll_rem = 0.0
        self._mouse_left_pressed = False
        self._mouse_right_pressed = False
        self._mouse_suppress_buttons = 0
        self._mouse_suppress_lt = False
        self._mouse_suppress_rt = False
        self._hap_rpad_touched = False
        self._hap_lpad_touched = False
        self._hap_prev_rx = 0
        self._hap_prev_ry = 0
        self._hap_rpad_dist = 0.0
        self._hap_prev_dpad = 0

    def _emit_haptic(self, pad: int, duration_us: int, count: int = 1) -> None:
        if not self.config.haptics_enabled:
            return
        for idx, (p, dur, _c) in enumerate(self.last_haptics):
            if p == pad:
                if duration_us > dur:
                    self.last_haptics[idx] = (pad, duration_us, count)
                return
        self.last_haptics.append((pad, duration_us, count))

    def release_mouse(self) -> MouseDelta:
        """Release any held OS mouse buttons when grip is released, controller disconnects, or service stops."""
        left_rel = False if self._mouse_left_pressed else None
        right_rel = False if self._mouse_right_pressed else None
        self._mouse_left_pressed = False
        self._mouse_right_pressed = False
        self._mouse_rpad_touched = False
        self._mouse_touch_frames = 0
        self._mouse_lpad_touched = False
        self._mouse_vx = 0.0
        self._mouse_vy = 0.0
        self._mouse_rem_x = 0.0
        self._mouse_rem_y = 0.0
        self._mouse_scroll_rem = 0.0
        delta = MouseDelta(left_down=left_rel, right_down=right_rel)
        self.last_mouse = delta
        return delta

    def is_gyro_hold_active(self, raw: SteamControllerRawState) -> bool:
        cfg = self.config
        sb = raw.buttons
        return (
            (cfg.left_grip_button == "gyro_hold" and bool(sb & STEAM_GRIP_LEFT_MASK))
            or (cfg.right_grip_button == "gyro_hold" and bool(sb & STEAM_GRIP_RIGHT_MASK))
        )

    def is_mouse_hold_active(self, raw: SteamControllerRawState) -> bool:
        cfg = self.config
        sb = raw.buttons
        return (
            (cfg.left_grip_button == "mouse_hold" and bool(sb & STEAM_GRIP_LEFT_MASK))
            or (cfg.right_grip_button == "mouse_hold" and bool(sb & STEAM_GRIP_RIGHT_MASK))
        )

    def translate(self, raw: SteamControllerRawState, dt: float = 0.008) -> XboxState:
        cfg = self.config
        sb = raw.buttons
        clamped_dt = max(0.002, min(0.1, dt))
        self.last_haptics = []
        mouse_mode = self.is_mouse_hold_active(raw)

        if mouse_mode:
            self.last_mouse = self._update_mouse_hold(raw, clamped_dt)
            self._rpad_was_touched = False
            self._joy_rx = 0.0
            self._joy_ry = 0.0
            self._vel_x = 0.0
            self._vel_y = 0.0
            sb_eff = sb & ~(STEAM_A_MASK | STEAM_B_MASK)
        else:
            self.release_mouse()
            self._mouse_suppress_buttons &= sb
            if raw.left_trigger <= 20 and not (sb & STEAM_LT_FULL_MASK):
                self._mouse_suppress_lt = False
            if raw.right_trigger <= 20 and not (sb & STEAM_RT_FULL_MASK):
                self._mouse_suppress_rt = False
            sb_eff = sb & ~self._mouse_suppress_buttons

        xb = 0
        for s_mask, x_mask in _DIRECT_BUTTON_MAP:
            if sb_eff & s_mask:
                xb |= x_mask

        # Rear grip paddles (digital button or hold-mode activator -> 0 digital mask)
        if sb & STEAM_GRIP_LEFT_MASK:
            xb |= GRIP_TARGETS.get(cfg.left_grip_button, ("", 0))[1]
        if sb & STEAM_GRIP_RIGHT_MASK:
            xb |= GRIP_TARGETS.get(cfg.right_grip_button, ("", 0))[1]

        # Left trackpad -> D-Pad (suppressed while holding Mouse mode where Left Pad scrolls wheel)
        dpad_bits = 0
        if not mouse_mode:
            dpad_bits = self._translate_left_pad(raw)
            xb |= dpad_bits

        self._update_touchpad_haptics(raw, mouse_mode=mouse_mode, dpad_bits=dpad_bits)

        # Left analog stick (with configurable radial inner deadzone & outer saturation threshold)
        dz = cfg.deadzone_percent / 100.0
        outer = cfg.stick_outer_percent / 100.0
        lx, ly = _apply_radial_deadzone(raw.left_stick_x, raw.left_stick_y, dz, 1.0, outer)

        # Right trackpad + Gyro hold aiming -> Right Stick (RS)
        if mouse_mode:
            pad_vx, pad_vy, uses_anti_dz = 0.0, 0.0, False
        else:
            pad_vx, pad_vy, uses_anti_dz = self._compute_right_pad_vector(raw, clamped_dt, dz, outer)
        gyro_vx, gyro_vy = self._compute_gyro_vector(raw)
        comb_x = pad_vx + gyro_vx
        comb_y = pad_vy + gyro_vy
        if uses_anti_dz:
            rx, ry = self._velocity_to_stick(comb_x, comb_y)
        else:
            mag = math.hypot(comb_x, comb_y)
            if mag < 0.008:
                rx = ry = 0
            else:
                if mag > 1.0:
                    comb_x /= mag
                    comb_y /= mag
                rx, ry = _clamp_s16(comb_x * _AXIS_MAX), _clamp_s16(comb_y * _AXIS_MAX)

        out_lt = 0 if (mouse_mode or self._mouse_suppress_lt) else raw.left_trigger
        out_rt = 0 if (mouse_mode or self._mouse_suppress_rt) else raw.right_trigger

        return XboxState(
            buttons=xb,
            left_trigger=out_lt,
            right_trigger=out_rt,
            lx=lx,
            ly=ly,
            rx=rx,
            ry=ry,
        )

    def _update_touchpad_haptics(self, raw: SteamControllerRawState, *, mouse_mode: bool, dpad_bits: int) -> None:
        if not self.config.haptics_enabled:
            self._hap_rpad_touched = False
            self._hap_lpad_touched = False
            self._hap_rpad_dist = 0.0
            self._hap_prev_dpad = 0
            return

        sb = raw.buttons
        # Right Touchpad (actuator 0): landing micro-tick + tactile ball-bearing ticks every ~2800 pad units (~1.7 mm)
        rpad_active = mouse_mode or self.config.right_pad_mode != "off"
        if rpad_active and (sb & STEAM_RPAD_TOUCH_MASK):
            if not self._hap_rpad_touched:
                self._hap_rpad_touched = True
                self._hap_prev_rx = raw.right_pad_x
                self._hap_prev_ry = raw.right_pad_y
                self._hap_rpad_dist = 0.0
                self._emit_haptic(0, 160, 1)
            else:
                step = math.hypot(raw.right_pad_x - self._hap_prev_rx, raw.right_pad_y - self._hap_prev_ry)
                self._hap_prev_rx = raw.right_pad_x
                self._hap_prev_ry = raw.right_pad_y
                if 40.0 <= step <= 16000.0:
                    self._hap_rpad_dist += step
                    if self._hap_rpad_dist >= 2800.0:
                        self._hap_rpad_dist %= 2800.0
                        self._emit_haptic(0, 220, 1)
        else:
            self._hap_rpad_touched = False
            self._hap_rpad_dist = 0.0

        # Left Touchpad (actuator 1): landing micro-tick + D-Pad engage detent (scroll wheel detents fire in _update_mouse_hold)
        lpad_active = mouse_mode or self.config.left_pad_mode != "off"
        if lpad_active and (sb & STEAM_LPAD_TOUCH_MASK):
            if not self._hap_lpad_touched:
                self._hap_lpad_touched = True
                self._emit_haptic(1, 160, 1)
        else:
            self._hap_lpad_touched = False

        if not mouse_mode:
            if dpad_bits != 0 and dpad_bits != self._hap_prev_dpad:
                self._emit_haptic(1, 520, 1)
            self._hap_prev_dpad = dpad_bits
        else:
            self._hap_prev_dpad = 0

    def _update_mouse_hold(self, raw: SteamControllerRawState, dt: float) -> MouseDelta:
        sb = raw.buttons
        dx = dy = wheel = 0

        # 1. Right Touchpad -> Desktop Cursor Move (calibrated for Windows pointer ballistics so 1x is calm & precise)
        if sb & STEAM_RPAD_TOUCH_MASK:
            if not self._mouse_rpad_touched:
                self._mouse_rpad_touched = True
                self._mouse_touch_frames = 1
                self._mouse_prev_rx = raw.right_pad_x
                self._mouse_prev_ry = raw.right_pad_y
                self._mouse_vx = 0.0
                self._mouse_vy = 0.0
            else:
                rdx = float(raw.right_pad_x - self._mouse_prev_rx)
                rdy = float(raw.right_pad_y - self._mouse_prev_ry)
                self._mouse_prev_rx = raw.right_pad_x
                self._mouse_prev_ry = raw.right_pad_y
                if self._mouse_touch_frames == 1:
                    self._mouse_touch_frames = 2
                    rdx *= 0.45
                    rdy *= 0.45
                step = math.hypot(rdx, rdy)
                if 18.0 <= step <= 16000.0:
                    self._mouse_vx = 0.55 * rdx + 0.45 * self._mouse_vx
                    self._mouse_vy = 0.55 * rdy + 0.45 * self._mouse_vy
                    speed = step / max(0.004, dt)
                    gain = (0.0042 + 0.0048 * min(1.0, speed / 220000.0)) * self.config.mouse_sensitivity
                    fx = self._mouse_vx * gain + self._mouse_rem_x
                    fy = (-self._mouse_vy) * gain + self._mouse_rem_y
                    dx = int(fx)
                    dy = int(fy)
                    self._mouse_rem_x = fx - dx
                    self._mouse_rem_y = fy - dy
                else:
                    self._mouse_vx *= 0.3
                    self._mouse_vy *= 0.3
        else:
            self._mouse_rpad_touched = False
            self._mouse_touch_frames = 0
            self._mouse_vx = 0.0
            self._mouse_vy = 0.0
            self._mouse_rem_x = 0.0
            self._mouse_rem_y = 0.0

        # 2. Left Touchpad -> Mouse Scroll Wheel (120 WHEEL_DELTA per ~2800 pad units + notched wheel haptic detent)
        if sb & STEAM_LPAD_TOUCH_MASK:
            if not self._mouse_lpad_touched:
                self._mouse_lpad_touched = True
                self._mouse_prev_ly = raw.left_pad_y
            else:
                ldy = raw.left_pad_y - self._mouse_prev_ly
                self._mouse_prev_ly = raw.left_pad_y
                if 45 <= abs(ldy) <= 16000:
                    self._mouse_scroll_rem += (ldy / 2800.0) * 120.0
                    notches = int(self._mouse_scroll_rem / 120.0)
                    if notches != 0:
                        wheel = notches * 120
                        self._mouse_scroll_rem -= wheel
                        self._emit_haptic(1, 440, min(3, abs(notches)))
        else:
            self._mouse_lpad_touched = False
            self._mouse_scroll_rem = 0.0

        # 3. RT or A -> Left Mouse Button; LT or B -> Right Mouse Button (with trigger hysteresis 90/60)
        rt_active = (
            raw.right_trigger >= 90
            or (self._mouse_left_pressed and raw.right_trigger > 60)
            or bool(sb & STEAM_RT_FULL_MASK)
        )
        lt_active = (
            raw.left_trigger >= 90
            or (self._mouse_right_pressed and raw.left_trigger > 60)
            or bool(sb & STEAM_LT_FULL_MASK)
        )
        want_left = rt_active or bool(sb & STEAM_A_MASK)
        want_right = lt_active or bool(sb & STEAM_B_MASK)

        left_edge: bool | None = None
        if want_left != self._mouse_left_pressed:
            self._mouse_left_pressed = want_left
            left_edge = want_left
            if want_left:
                self._emit_haptic(0, 480, 1)

        right_edge: bool | None = None
        if want_right != self._mouse_right_pressed:
            self._mouse_right_pressed = want_right
            right_edge = want_right
            if want_right:
                self._emit_haptic(1, 480, 1)

        if sb & STEAM_A_MASK:
            self._mouse_suppress_buttons |= STEAM_A_MASK
        if sb & STEAM_B_MASK:
            self._mouse_suppress_buttons |= STEAM_B_MASK
        if raw.left_trigger > 20 or (sb & STEAM_LT_FULL_MASK):
            self._mouse_suppress_lt = True
        if raw.right_trigger > 20 or (sb & STEAM_RT_FULL_MASK):
            self._mouse_suppress_rt = True

        return MouseDelta(dx=dx, dy=dy, wheel=wheel, left_down=left_edge, right_down=right_edge)

    def _translate_left_pad(self, raw: SteamControllerRawState) -> int:
        mode = self.config.left_pad_mode
        if mode == "off":
            return 0
        sb = raw.buttons

        # STEAM_DPAD_*_MASK (0x000100..0x000800) are capacitive touch quadrant bits (`STEAM_TOUCH_0..3`),
        # NOT physical clickswitches — in `dpad_click` mode we strictly require STEAM_LPAD_CLICK_MASK (0x020000).
        if mode == "dpad_click" and not (sb & STEAM_LPAD_CLICK_MASK):
            return 0

        hw_dpad = 0
        if sb & STEAM_DPAD_UP_MASK:
            hw_dpad |= XUSB_DPAD_UP
        if sb & STEAM_DPAD_DOWN_MASK:
            hw_dpad |= XUSB_DPAD_DOWN
        if sb & STEAM_DPAD_LEFT_MASK:
            hw_dpad |= XUSB_DPAD_LEFT
        if sb & STEAM_DPAD_RIGHT_MASK:
            hw_dpad |= XUSB_DPAD_RIGHT

        if not (sb & STEAM_LPAD_TOUCH_MASK):
            return hw_dpad if mode == "dpad_click" else 0

        # Compute 8-way direction from 15-degree-rotated coordinates first so unrotated quadrant bits never cause false diagonals
        min_dz = 6000 if mode == "dpad_click" else 8500
        pad_dz = max(min_dz, int((self.config.deadzone_percent / 100.0) * _AXIS_MAX))
        out = 0
        if raw.left_pad_y > pad_dz:
            out |= XUSB_DPAD_UP
        elif raw.left_pad_y < -pad_dz:
            out |= XUSB_DPAD_DOWN
        if raw.left_pad_x > pad_dz:
            out |= XUSB_DPAD_RIGHT
        elif raw.left_pad_x < -pad_dz:
            out |= XUSB_DPAD_LEFT
        return out if out != 0 else hw_dpad

    def _compute_right_pad_vector(
        self,
        raw: SteamControllerRawState,
        dt: float,
        dz: float,
        outer: float = 0.90,
    ) -> tuple[float, float, bool]:
        cfg = self.config
        mode = cfg.right_pad_mode
        inv_y = -1.0 if cfg.invert_right_y else 1.0
        if mode == "off":
            self._rpad_was_touched = False
            self._prev_rx = 0
            self._prev_ry = 0
            self._vel_x = 0.0
            self._vel_y = 0.0
            self._joy_rx = 0.0
            self._joy_ry = 0.0
            return 0.0, 0.0, False

        touched = bool(raw.buttons & STEAM_RPAD_TOUCH_MASK)
        sens = cfg.right_pad_sensitivity

        if mode == "joystick":
            if not touched:
                self._rpad_was_touched = False
                self._joy_rx = 0.0
                self._joy_ry = 0.0
                return 0.0, 0.0, False
            jx, jy = _apply_radial_deadzone(raw.right_pad_x, raw.right_pad_y, dz, sens, outer)
            tx = jx / _AXIS_MAX
            ty = (jy / _AXIS_MAX) * inv_y
            if not self._rpad_was_touched:
                self._rpad_was_touched = True
                self._joy_rx = tx
                self._joy_ry = ty
            else:
                # EMA filter suppresses capacitive touch micro-jitter while keeping held stick position rock-steady
                self._joy_rx = 0.45 * tx + 0.55 * self._joy_rx
                self._joy_ry = 0.45 * ty + 0.55 * self._joy_ry
            return self._joy_rx, self._joy_ry, False

        # Trackball / Mouse-like Joystick mode
        if touched:
            if not self._rpad_was_touched:
                self._rpad_was_touched = True
                self._prev_rx = raw.right_pad_x
                self._prev_ry = raw.right_pad_y
                self._vel_x = 0.0
                self._vel_y = 0.0
                return 0.0, 0.0, True

            dx = raw.right_pad_x - self._prev_rx
            dy = raw.right_pad_y - self._prev_ry
            self._prev_rx = raw.right_pad_x
            self._prev_ry = raw.right_pad_y

            step = math.hypot(dx, dy)
            if step < _TRACKBALL_STEP_DEADBAND:
                self._vel_x *= 0.4
                self._vel_y *= 0.4
                return 0.0, 0.0, True
            if step > 18000.0:
                return 0.0, 0.0, True

            eff_dt = max(0.008, min(0.05, dt))
            adj = (step - _TRACKBALL_STEP_DEADBAND) / step
            inst_vx = (dx * adj / eff_dt) * sens / _TRACKBALL_SPEED_FULL
            inst_vy = (dy * adj / eff_dt) * sens / _TRACKBALL_SPEED_FULL
            self._vel_x = 0.45 * inst_vx + 0.55 * self._vel_x
            self._vel_y = 0.45 * inst_vy + 0.55 * self._vel_y
            return self._vel_x, self._vel_y * inv_y, True

        # Thumb lifted: smooth trackball coasting decay
        self._rpad_was_touched = False
        decay = math.exp(-_TRACKBALL_DECAY * dt)
        self._vel_x *= decay
        self._vel_y *= decay
        if math.hypot(self._vel_x, self._vel_y) < 0.03:
            self._vel_x = 0.0
            self._vel_y = 0.0
            return 0.0, 0.0, True
        return self._vel_x, self._vel_y * inv_y, True

    def _compute_gyro_vector(self, raw: SteamControllerRawState) -> tuple[float, float]:
        # Adapt zero-rate sensor offset only while controller is resting inside stationary floor
        raw_mag = math.sqrt(raw.gyro_x * raw.gyro_x + raw.gyro_y * raw.gyro_y + raw.gyro_z * raw.gyro_z)
        if raw_mag < _GYRO_BIAS_STATIONARY_MAX:
            self._gyro_bias[0] = max(-80.0, min(80.0, 0.96 * self._gyro_bias[0] + 0.04 * raw.gyro_x))
            self._gyro_bias[1] = max(-80.0, min(80.0, 0.96 * self._gyro_bias[1] + 0.04 * raw.gyro_y))
            self._gyro_bias[2] = max(-80.0, min(80.0, 0.96 * self._gyro_bias[2] + 0.04 * raw.gyro_z))

        if not self.is_gyro_hold_active(raw):
            self._gyro_vx = 0.0
            self._gyro_vy = 0.0
            return 0.0, 0.0

        cfg = self.config
        gx = raw.gyro_x - self._gyro_bias[0]
        gy = raw.gyro_y - self._gyro_bias[1]
        gz = raw.gyro_z - self._gyro_bias[2]

        # Right-hand rule per Valve SDL_hidapi_steam.c: +X = pitch up, -Z = yaw right, -Y = roll right
        axis_mode = cfg.gyro_axis_mode
        if axis_mode == "roll":
            gh = -gy
        elif axis_mode == "yaw_roll":
            gh = -0.5 * (gz + gy)
        else:
            gh = -gz
        gv = gx

        if cfg.invert_gyro_x:
            gh = -gh
        if cfg.invert_gyro_y:
            gv = -gv

        g_mag = math.hypot(gh, gv)
        if g_mag <= _GYRO_NOISE_GATE:
            self._gyro_vx *= 0.45
            self._gyro_vy *= 0.45
            if math.hypot(self._gyro_vx, self._gyro_vy) < 0.008:
                self._gyro_vx = 0.0
                self._gyro_vy = 0.0
                return 0.0, 0.0
            return self._gyro_vx, self._gyro_vy

        # Continuous linear+quadratic curve from 0..1 (no hard anti-deadzone cliff jump around center)
        raw_norm = min(1.0, ((g_mag - _GYRO_NOISE_GATE) / _GYRO_SPEED_FULL) * cfg.gyro_sensitivity)
        curved_mag = 0.55 * raw_norm + 0.45 * (raw_norm * raw_norm)
        scale = curved_mag / g_mag
        inst_gx = gh * scale
        inst_gy = gv * scale
        self._gyro_vx = 0.42 * inst_gx + 0.58 * self._gyro_vx
        self._gyro_vy = 0.42 * inst_gy + 0.58 * self._gyro_vy
        return self._gyro_vx, self._gyro_vy

    @staticmethod
    def _velocity_to_stick(vx: float, vy: float) -> tuple[int, int]:
        mag = math.hypot(vx, vy)
        if mag < 0.015:
            return 0, 0
        clamped = min(1.0, mag)
        out_mag = _TRACKBALL_ANTI_DEADZONE + clamped * (_AXIS_MAX - _TRACKBALL_ANTI_DEADZONE)
        scale = out_mag / mag
        return _clamp_s16(vx * scale), _clamp_s16(vy * scale)
