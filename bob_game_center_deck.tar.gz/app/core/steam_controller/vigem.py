"""Lazy ctypes wrapper around `ViGEmClient.dll` (virtual Xbox 360 pad) and 1-click `ViGEmBus` installer.

`ViGEmClient.dll` (~130 KB, MIT license) is verified by SHA-256 before loading and is never loaded at module import time.
"""

from __future__ import annotations

import ctypes
import hashlib
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Callable

from app.core.steam_controller.protocol import XboxState

logger = logging.getLogger(__name__)
TAG = "[SteamController/ViGEm]"

VIGEM_CLIENT_DLL_NAME = "ViGEmClient.dll"
VIGEM_CLIENT_SHA256 = "2bf0cb1d809039573c922737d298a1653d4dbc61408060ff45a9bcfde82e97d2"

VIGEMBUS_INSTALLER_URL = (
    "https://github.com/nefarius/ViGEmBus/releases/download/v1.22.0/ViGEmBus_1.22.0_x64_x86_arm64.exe"
)
VIGEMBUS_INSTALLER_SHA256 = "89220a7865076b342892f98865f3499fb7c4cfd673159e89d352c360fd014c6a"

VIGEM_ERROR_NONE = 0x20000000
VIGEM_ERROR_BUS_NOT_FOUND = 0xE0000001
VIGEM_ERROR_NO_FREE_SLOT = 0xE0000002
VIGEM_ERROR_BUS_VERSION_MISMATCH = 0xE0000004
VIGEM_ERROR_BUS_ACCESS_FAILED = 0xE0000005


class ViGEmError(RuntimeError):
    """Raised when `ViGEmClient.dll` or `ViGEmBus` cannot be loaded or opened."""


class XUSB_REPORT(ctypes.Structure):
    _fields_ = [
        ("wButtons", ctypes.c_ushort),
        ("bLeftTrigger", ctypes.c_ubyte),
        ("bRightTrigger", ctypes.c_ubyte),
        ("sThumbLX", ctypes.c_short),
        ("sThumbLY", ctypes.c_short),
        ("sThumbRX", ctypes.c_short),
        ("sThumbRY", ctypes.c_short),
    ]


_NOTIFY_CFUNC = (ctypes.WINFUNCTYPE if sys.platform == "win32" else ctypes.CFUNCTYPE)(
    None,
    ctypes.c_void_p,
    ctypes.c_void_p,
    ctypes.c_ubyte,
    ctypes.c_ubyte,
    ctypes.c_ubyte,
    ctypes.c_void_p,
)

_cached_dll = None


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def resolve_vigem_dll_path() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / VIGEM_CLIENT_DLL_NAME
    return Path(__file__).resolve().parents[3] / "native" / "bin" / "x64" / VIGEM_CLIENT_DLL_NAME


def _get_vigem_dll():
    """Verify SHA-256 and load `ViGEmClient.dll` lazily on first call."""
    global _cached_dll
    if _cached_dll is not None:
        return _cached_dll
    if sys.platform != "win32":
        raise ViGEmError("Giả lập tay cầm Xbox 360 (ViGEm) chỉ hỗ trợ trên Windows.")

    dll_path = resolve_vigem_dll_path()
    if not dll_path.is_file():
        logger.error("%s Missing %s at %s", TAG, VIGEM_CLIENT_DLL_NAME, dll_path)
        raise ViGEmError(f"Không tìm thấy thư viện {VIGEM_CLIENT_DLL_NAME} ({dll_path}).")

    digest = _sha256_file(dll_path)
    if digest.lower() != VIGEM_CLIENT_SHA256:
        logger.error(
            "%s SHA-256 mismatch on %s: expected=%s actual=%s",
            TAG,
            dll_path,
            VIGEM_CLIENT_SHA256,
            digest,
        )
        raise ViGEmError(f"Tệp {VIGEM_CLIENT_DLL_NAME} không khớp chữ ký SHA-256 an toàn.")

    dll = ctypes.WinDLL(str(dll_path))

    dll.vigem_alloc.argtypes = []
    dll.vigem_alloc.restype = ctypes.c_void_p

    dll.vigem_free.argtypes = [ctypes.c_void_p]
    dll.vigem_free.restype = None

    dll.vigem_connect.argtypes = [ctypes.c_void_p]
    dll.vigem_connect.restype = ctypes.c_uint32

    dll.vigem_disconnect.argtypes = [ctypes.c_void_p]
    dll.vigem_disconnect.restype = None

    dll.vigem_target_x360_alloc.argtypes = []
    dll.vigem_target_x360_alloc.restype = ctypes.c_void_p

    dll.vigem_target_free.argtypes = [ctypes.c_void_p]
    dll.vigem_target_free.restype = None

    dll.vigem_target_add.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    dll.vigem_target_add.restype = ctypes.c_uint32

    dll.vigem_target_remove.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    dll.vigem_target_remove.restype = ctypes.c_uint32

    dll.vigem_target_x360_update.argtypes = [ctypes.c_void_p, ctypes.c_void_p, XUSB_REPORT]
    dll.vigem_target_x360_update.restype = ctypes.c_uint32

    dll.vigem_target_x360_get_user_index.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint32),
    ]
    dll.vigem_target_x360_get_user_index.restype = ctypes.c_uint32

    dll.vigem_target_x360_register_notification.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        _NOTIFY_CFUNC,
        ctypes.c_void_p,
    ]
    dll.vigem_target_x360_register_notification.restype = ctypes.c_uint32

    dll.vigem_target_x360_unregister_notification.argtypes = [ctypes.c_void_p]
    dll.vigem_target_x360_unregister_notification.restype = None

    _cached_dll = dll
    logger.info("%s Loaded verified %s from %s", TAG, VIGEM_CLIENT_DLL_NAME, dll_path)
    return dll


def is_vigembus_installed() -> tuple[bool, str]:
    """Check whether `ViGEmClient.dll` is valid and `ViGEmBus` kernel driver responds."""
    try:
        dll = _get_vigem_dll()
    except ViGEmError as exc:
        return False, str(exc)
    except Exception as exc:  # noqa: BLE001
        logger.error("%s Unexpected error loading ViGEmClient.dll: %s", TAG, exc, exc_info=True)
        return False, f"Lỗi kiểm tra ViGEmClient: {exc}"

    client = dll.vigem_alloc()
    if not client:
        return False, "Không thể cấp phát bộ nhớ ViGEmClient."
    try:
        rc = int(dll.vigem_connect(client))
        if rc == VIGEM_ERROR_NONE:
            dll.vigem_disconnect(client)
            return True, "Driver ViGEmBus đã sẵn sàng"
        if rc == VIGEM_ERROR_BUS_NOT_FOUND:
            return False, "Chưa cài đặt driver ViGEmBus"
        if rc == VIGEM_ERROR_BUS_VERSION_MISMATCH:
            return False, "Phiên bản driver ViGEmBus quá cũ (cần cập nhật v1.22.0)"
        return False, f"Không thể kết nối ViGEmBus (mã 0x{rc:08X})"
    finally:
        dll.vigem_free(client)


class VirtualXbox360Pad:
    """Lifecycle-managed virtual Xbox 360 controller backed by `ViGEmBus`."""

    def __init__(self, on_rumble: Callable[[int, int, int], None] | None = None) -> None:
        self._dll = _get_vigem_dll()
        self._client: int | None = None
        self._target: int | None = None
        self._notify_cfunc = None
        self._last_state: XboxState | None = None
        self.user_index: int = -1

        client = self._dll.vigem_alloc()
        if not client:
            raise ViGEmError("vigem_alloc thất bại.")

        rc = int(self._dll.vigem_connect(client))
        if rc != VIGEM_ERROR_NONE:
            self._dll.vigem_free(client)
            if rc == VIGEM_ERROR_BUS_NOT_FOUND:
                raise ViGEmError("Chưa cài đặt driver ViGEmBus.")
            raise ViGEmError(f"vigem_connect thất bại (0x{rc:08X}).")

        target = self._dll.vigem_target_x360_alloc()
        if not target:
            self._dll.vigem_disconnect(client)
            self._dll.vigem_free(client)
            raise ViGEmError("vigem_target_x360_alloc thất bại.")

        rc_add = int(self._dll.vigem_target_add(client, target))
        if rc_add != VIGEM_ERROR_NONE:
            self._dll.vigem_target_free(target)
            self._dll.vigem_disconnect(client)
            self._dll.vigem_free(client)
            if rc_add == VIGEM_ERROR_NO_FREE_SLOT:
                raise ViGEmError("Không còn khe XInput trống (tối đa 4 tay cầm Xbox 360).")
            raise ViGEmError(f"vigem_target_add thất bại (0x{rc_add:08X}).")

        self._client = client
        self._target = target

        idx = ctypes.c_uint32(0)
        if int(self._dll.vigem_target_x360_get_user_index(client, target, ctypes.byref(idx))) == VIGEM_ERROR_NONE:
            self.user_index = int(idx.value)

        if on_rumble is not None:
            def _c_notify(_cli, _tgt, large: int, small: int, led: int, _ud) -> None:
                try:
                    if self.user_index < 0 and 0 <= int(led) <= 3:
                        self.user_index = int(led)
                    on_rumble(int(large), int(small), int(led))
                except Exception:  # noqa: BLE001
                    pass

            cfunc = _NOTIFY_CFUNC(_c_notify)
            rc_n = int(self._dll.vigem_target_x360_register_notification(client, target, cfunc, None))
            if rc_n == VIGEM_ERROR_NONE:
                self._notify_cfunc = cfunc
            else:
                logger.warning("%s Rumble notification registration returned 0x%08X", TAG, rc_n)

        logger.info("%s Plugged in virtual Xbox 360 controller (player_slot=%s)", TAG, self.user_index)

    def update(self, state: XboxState) -> None:
        if self._client is None or self._target is None:
            return
        if state == self._last_state:
            return
        report = XUSB_REPORT(
            wButtons=state.buttons & 0xFFFF,
            bLeftTrigger=state.left_trigger & 0xFF,
            bRightTrigger=state.right_trigger & 0xFF,
            sThumbLX=int(state.lx),
            sThumbLY=int(state.ly),
            sThumbRX=int(state.rx),
            sThumbRY=int(state.ry),
        )
        rc = int(self._dll.vigem_target_x360_update(self._client, self._target, report))
        if rc != VIGEM_ERROR_NONE:
            raise ViGEmError(f"vigem_target_x360_update thất bại (0x{rc:08X}).")
        self._last_state = state

    def reset(self) -> None:
        self._last_state = None
        self.update(XboxState())

    def close(self) -> None:
        if self._target is not None and self._client is not None:
            try:
                if self._notify_cfunc is not None:
                    self._dll.vigem_target_x360_unregister_notification(self._target)
            except Exception:  # noqa: BLE001
                pass
            self._notify_cfunc = None
            try:
                self.reset()
            except Exception:  # noqa: BLE001
                pass
            try:
                self._dll.vigem_target_remove(self._client, self._target)
            except Exception:  # noqa: BLE001
                pass
            try:
                self._dll.vigem_target_free(self._target)
            except Exception:  # noqa: BLE001
                pass
            self._target = None
            logger.info("%s Unplugged virtual Xbox 360 controller", TAG)

        if self._client is not None:
            try:
                self._dll.vigem_disconnect(self._client)
            except Exception:  # noqa: BLE001
                pass
            try:
                self._dll.vigem_free(self._client)
            except Exception:  # noqa: BLE001
                pass
            self._client = None


def _is_process_admin() -> bool:
    if sys.platform != "win32":
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:  # noqa: BLE001
        return False


def _run_elevated_installer(exe_path: Path, args: str, timeout_s: int = 180) -> int:
    """Execute `exe_path` silently; request UAC elevation via `ShellExecuteExW` if current process is non-admin."""
    if _is_process_admin():
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        res = subprocess.run(
            [str(exe_path), *args.split()],
            capture_output=True,
            text=True,
            timeout=timeout_s,
            creationflags=flags,
        )
        return int(res.returncode)

    from ctypes import wintypes

    SEE_MASK_NOCLOSEPROCESS = 0x00000040

    class SHELLEXECUTEINFOW(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD),
            ("fMask", wintypes.ULONG),
            ("hwnd", wintypes.HWND),
            ("lpVerb", wintypes.LPCWSTR),
            ("lpFile", wintypes.LPCWSTR),
            ("lpParameters", wintypes.LPCWSTR),
            ("lpDirectory", wintypes.LPCWSTR),
            ("nShow", ctypes.c_int),
            ("hInstApp", wintypes.HINSTANCE),
            ("lpIDList", ctypes.c_void_p),
            ("lpClass", wintypes.LPCWSTR),
            ("hkeyClass", wintypes.HKEY),
            ("dwHotKey", wintypes.DWORD),
            ("hIconOrMonitor", ctypes.c_void_p),
            ("hProcess", ctypes.c_void_p),
        ]

    sei = SHELLEXECUTEINFOW()
    sei.cbSize = ctypes.sizeof(SHELLEXECUTEINFOW)
    sei.fMask = SEE_MASK_NOCLOSEPROCESS
    sei.lpVerb = "runas"
    sei.lpFile = str(exe_path)
    sei.lpParameters = args
    sei.lpDirectory = str(exe_path.parent)
    sei.nShow = 0  # SW_HIDE

    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    shell32.ShellExecuteExW.argtypes = [ctypes.POINTER(SHELLEXECUTEINFOW)]
    shell32.ShellExecuteExW.restype = wintypes.BOOL
    kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, wintypes.DWORD]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD
    kernel32.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD)]
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]

    if not shell32.ShellExecuteExW(ctypes.byref(sei)):
        err = ctypes.get_last_error()
        raise ViGEmError(f"Không thể xin quyền Quản trị viên (UAC) để cài ViGEmBus (winerr={err}).")

    if not sei.hProcess:
        return 0
    try:
        wait_rc = kernel32.WaitForSingleObject(sei.hProcess, int(timeout_s * 1000))
        if wait_rc != 0:
            raise ViGEmError("Quá thời gian chờ trình cài đặt ViGEmBus hoàn tất.")
        exit_code = wintypes.DWORD(0)
        kernel32.GetExitCodeProcess(sei.hProcess, ctypes.byref(exit_code))
        return int(exit_code.value)
    finally:
        kernel32.CloseHandle(sei.hProcess)


def install_vigembus_driver(
    progress_cb: Callable[[int, str], None] | None = None,
    is_cancelled: Callable[[], bool] | None = None,
) -> tuple[bool, str]:
    """Download official `ViGEmBus v1.22.0` to OS temp dir, verify SHA-256, and install silently."""
    if sys.platform != "win32":
        return False, "Chỉ hỗ trợ cài đặt ViGEmBus trên Windows."

    import requests

    t0 = time.monotonic()
    logger.info("%s Starting ViGEmBus v1.22.0 download & install from %s", TAG, VIGEMBUS_INSTALLER_URL)
    tmp_dir = Path(tempfile.mkdtemp(prefix="bob_vigem_"))
    exe_path = tmp_dir / "ViGEmBus_1.22.0_x64_x86_arm64.exe"
    http_status: int | None = None

    try:
        if progress_cb:
            progress_cb(2, "Đang kết nối tải ViGEmBus v1.22.0...")

        try:
            resp = requests.get(VIGEMBUS_INSTALLER_URL, stream=True, timeout=(15, 60))
            http_status = resp.status_code
            resp.raise_for_status()
        except Exception as exc:  # noqa: BLE001
            dur = time.monotonic() - t0
            logger.error(
                "%s Download failed url=%s status=%s duration=%.2fs error=%s",
                TAG,
                VIGEMBUS_INSTALLER_URL,
                http_status,
                dur,
                exc,
            )
            return False, f"Tải trình cài đặt ViGEmBus thất bại ({exc})."

        with resp:
            total = int(resp.headers.get("Content-Length") or 0)
            downloaded = 0
            next_milestone = 25
            hasher = hashlib.sha256()

            with open(exe_path, "wb") as out_f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if is_cancelled and is_cancelled():
                        logger.warning("%s ViGEmBus download cancelled by user after %.2fs", TAG, time.monotonic() - t0)
                        return False, "Đã hủy cài đặt ViGEmBus."
                    if not chunk:
                        continue
                    out_f.write(chunk)
                    hasher.update(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        pct = min(100, int(downloaded * 100 / total))
                        if progress_cb:
                            progress_cb(min(80, max(5, int(pct * 0.8))), f"Đang tải ViGEmBus ({pct}%)...")
                        while pct >= next_milestone:
                            logger.info(
                                "%s Download milestone %d%% (%d/%d bytes)",
                                TAG,
                                next_milestone,
                                downloaded,
                                total,
                            )
                            next_milestone += 25

        digest = hasher.hexdigest().lower()
        if digest != VIGEMBUS_INSTALLER_SHA256:
            logger.error(
                "%s ViGEmBus installer SHA-256 mismatch: expected=%s actual=%s",
                TAG,
                VIGEMBUS_INSTALLER_SHA256,
                digest,
            )
            return False, "Tệp cài đặt ViGEmBus tải về không khớp chữ ký SHA-256 an toàn."

        if progress_cb:
            progress_cb(85, "Đang cài đặt driver ViGEmBus...")

        logger.info("%s Verified SHA-256 (%d bytes); running silent installer", TAG, os.path.getsize(exe_path))
        rc = _run_elevated_installer(exe_path, "/qn /norestart")
        # 0 = success, 3010 = success (reboot optional)
        if rc not in (0, 3010):
            logger.error("%s ViGEmBus installer exited with code %d after %.2fs", TAG, rc, time.monotonic() - t0)
            return False, f"Trình cài đặt ViGEmBus trả về mã lỗi {rc}."

        if progress_cb:
            progress_cb(95, "Đang kiểm tra kết nối driver...")

        for _ in range(10):
            ok, msg = is_vigembus_installed()
            if ok:
                dur = time.monotonic() - t0
                logger.info("%s ViGEmBus v1.22.0 installed and verified in %.2fs", TAG, dur)
                if progress_cb:
                    progress_cb(100, "Đã cài đặt ViGEmBus thành công.")
                return True, msg
            time.sleep(0.4)

        logger.warning("%s Installer succeeded (rc=%d) but bus not yet online; reboot may be required", TAG, rc)
        return False, "Đã cài đặt ViGEmBus nhưng driver chưa khởi động ngay — vui lòng khởi động lại Windows."
    except ViGEmError as exc:
        logger.warning("%s ViGEmBus install refused: %s", TAG, exc)
        return False, str(exc)
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "%s Unexpected failure installing ViGEmBus after %.2fs: %s",
            TAG,
            time.monotonic() - t0,
            exc,
            exc_info=True,
        )
        return False, f"Cài đặt ViGEmBus thất bại: {exc}"
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
