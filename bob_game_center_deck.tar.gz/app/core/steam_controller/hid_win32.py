"""Win32 HID discovery, overlapped input reading, and feature reports for Valve Steam Controller (2015).

Uses `hid.dll`, `setupapi.dll`, and `kernel32.dll` loaded lazily via `ctypes` so module import has zero native side
effects and works cleanly on non-Windows test runners.
"""

from __future__ import annotations

import ctypes
import logging
import sys
import time
from dataclasses import dataclass

from app.core.steam_controller.protocol import (
    ID_GET_ATTRIBUTES_VALUES,
    MouseDelta,
    PID_BLE,
    PID_BLE_OLD,
    PID_WIRED,
    PID_WIRELESS,
    SUPPORTED_PIDS,
    VALVE_VID,
    build_disable_lizard_reports,
    build_get_attributes_report,
    build_haptic_pulse_report,
    build_imu_mode_report,
    build_restore_lizard_reports,
    segment_ble_feature_report,
)

logger = logging.getLogger(__name__)
TAG = "[SteamController/HID]"

STEAM_VENDOR_USAGE_PAGE = 0xFF00
STEAM_VENDOR_USAGE = 0x0001
BLE_STEAM_PIDS = frozenset({PID_BLE_OLD, PID_BLE})

# Win32 constants
_DIGCF_PRESENT = 0x00000002
_DIGCF_DEVICEINTERFACE = 0x00000010
_GENERIC_READ = 0x80000000
_GENERIC_WRITE = 0x40000000
_FILE_SHARE_READ = 0x00000001
_FILE_SHARE_WRITE = 0x00000002
_OPEN_EXISTING = 3
_FILE_FLAG_OVERLAPPED = 0x40000000
_INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
_HIDP_STATUS_SUCCESS = 0x00110000
_WAIT_OBJECT_0 = 0x00000000
_WAIT_TIMEOUT = 0x00000102
_ERROR_IO_PENDING = 997
_DISCONNECT_WINERRS = frozenset({5, 6, 31, 995, 1167})  # ACCESS_DENIED, INVALID_HANDLE, GEN_FAILURE, ABORTED, NOT_CONNECTED


@dataclass(frozen=True)
class SteamHidInfo:
    path: str
    vendor_id: int
    product_id: int
    version_number: int
    usage_page: int
    usage: int
    input_report_len: int
    feature_report_len: int
    transport: str  # "wired" | "wireless" | "ble"

    @property
    def label(self) -> str:
        if self.transport == "wired":
            return "USB có dây"
        if self.transport == "wireless":
            return "Thu phát 2.4GHz"
        return "Bluetooth LE"


_win32_apis: tuple | None = None


def _load_win32_apis():
    """Lazily bind Win32 `hid.dll`, `setupapi.dll`, and `kernel32.dll` prototypes."""
    global _win32_apis
    if _win32_apis is not None:
        return _win32_apis
    if sys.platform != "win32":
        raise OSError("Win32 HID API is only available on Windows")

    from ctypes import wintypes

    class GUID(ctypes.Structure):
        _fields_ = [
            ("Data1", wintypes.DWORD),
            ("Data2", wintypes.WORD),
            ("Data3", wintypes.WORD),
            ("Data4", ctypes.c_ubyte * 8),
        ]

    class SP_DEVICE_INTERFACE_DATA(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD),
            ("InterfaceClassGuid", GUID),
            ("Flags", wintypes.DWORD),
            ("Reserved", ctypes.c_size_t),
        ]

    class HIDD_ATTRIBUTES(ctypes.Structure):
        _fields_ = [
            ("Size", wintypes.ULONG),
            ("VendorID", wintypes.USHORT),
            ("ProductID", wintypes.USHORT),
            ("VersionNumber", wintypes.USHORT),
        ]

    class HIDP_CAPS(ctypes.Structure):
        _fields_ = [
            ("Usage", wintypes.USHORT),
            ("UsagePage", wintypes.USHORT),
            ("InputReportByteLength", wintypes.USHORT),
            ("OutputReportByteLength", wintypes.USHORT),
            ("FeatureReportByteLength", wintypes.USHORT),
            ("Reserved", wintypes.USHORT * 17),
            ("NumberLinkCollectionNodes", wintypes.USHORT),
            ("NumberInputButtonCaps", wintypes.USHORT),
            ("NumberInputValueCaps", wintypes.USHORT),
            ("NumberInputDataIndices", wintypes.USHORT),
            ("NumberOutputButtonCaps", wintypes.USHORT),
            ("NumberOutputValueCaps", wintypes.USHORT),
            ("NumberOutputDataIndices", wintypes.USHORT),
            ("NumberFeatureButtonCaps", wintypes.USHORT),
            ("NumberFeatureValueCaps", wintypes.USHORT),
            ("NumberFeatureDataIndices", wintypes.USHORT),
        ]

    class OVERLAPPED(ctypes.Structure):
        _fields_ = [
            ("Internal", ctypes.c_size_t),
            ("InternalHigh", ctypes.c_size_t),
            ("Offset", wintypes.DWORD),
            ("OffsetHigh", wintypes.DWORD),
            ("hEvent", ctypes.c_void_p),
        ]

    hid = ctypes.WinDLL("hid", use_last_error=True)
    setupapi = ctypes.WinDLL("setupapi", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    hid.HidD_GetHidGuid.argtypes = [ctypes.POINTER(GUID)]
    hid.HidD_GetHidGuid.restype = None

    hid.HidD_GetAttributes.argtypes = [ctypes.c_void_p, ctypes.POINTER(HIDD_ATTRIBUTES)]
    hid.HidD_GetAttributes.restype = wintypes.BOOLEAN

    hid.HidD_GetPreparsedData.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    hid.HidD_GetPreparsedData.restype = wintypes.BOOLEAN

    hid.HidD_FreePreparsedData.argtypes = [ctypes.c_void_p]
    hid.HidD_FreePreparsedData.restype = wintypes.BOOLEAN

    hid.HidP_GetCaps.argtypes = [ctypes.c_void_p, ctypes.POINTER(HIDP_CAPS)]
    hid.HidP_GetCaps.restype = wintypes.LONG

    hid.HidD_SetFeature.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.ULONG]
    hid.HidD_SetFeature.restype = wintypes.BOOLEAN

    hid.HidD_GetFeature.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.ULONG]
    hid.HidD_GetFeature.restype = wintypes.BOOLEAN

    setupapi.SetupDiGetClassDevsW.argtypes = [
        ctypes.POINTER(GUID),
        wintypes.LPCWSTR,
        wintypes.HWND,
        wintypes.DWORD,
    ]
    setupapi.SetupDiGetClassDevsW.restype = ctypes.c_void_p

    setupapi.SetupDiEnumDeviceInterfaces.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.POINTER(GUID),
        wintypes.DWORD,
        ctypes.POINTER(SP_DEVICE_INTERFACE_DATA),
    ]
    setupapi.SetupDiEnumDeviceInterfaces.restype = wintypes.BOOL

    setupapi.SetupDiGetDeviceInterfaceDetailW.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(SP_DEVICE_INTERFACE_DATA),
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
        ctypes.c_void_p,
    ]
    setupapi.SetupDiGetDeviceInterfaceDetailW.restype = wintypes.BOOL

    setupapi.SetupDiDestroyDeviceInfoList.argtypes = [ctypes.c_void_p]
    setupapi.SetupDiDestroyDeviceInfoList.restype = wintypes.BOOL

    kernel32.CreateFileW.argtypes = [
        wintypes.LPCWSTR,
        wintypes.DWORD,
        wintypes.DWORD,
        ctypes.c_void_p,
        wintypes.DWORD,
        wintypes.DWORD,
        ctypes.c_void_p,
    ]
    kernel32.CreateFileW.restype = ctypes.c_void_p

    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel32.CloseHandle.restype = wintypes.BOOL

    kernel32.CreateEventW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.CreateEventW.restype = ctypes.c_void_p

    kernel32.ResetEvent.argtypes = [ctypes.c_void_p]
    kernel32.ResetEvent.restype = wintypes.BOOL

    kernel32.ReadFile.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
        ctypes.POINTER(OVERLAPPED),
    ]
    kernel32.ReadFile.restype = wintypes.BOOL

    kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, wintypes.DWORD]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD

    kernel32.CancelIoEx.argtypes = [ctypes.c_void_p, ctypes.POINTER(OVERLAPPED)]
    kernel32.CancelIoEx.restype = wintypes.BOOL

    kernel32.GetOverlappedResult.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(OVERLAPPED),
        ctypes.POINTER(wintypes.DWORD),
        wintypes.BOOL,
    ]
    kernel32.GetOverlappedResult.restype = wintypes.BOOL

    _win32_apis = (hid, setupapi, kernel32, GUID, SP_DEVICE_INTERFACE_DATA, HIDD_ATTRIBUTES, HIDP_CAPS, OVERLAPPED)
    return _win32_apis


def _classify_interface(pid: int, usage_page: int, usage: int, feature_len: int) -> str | None:
    if pid == PID_WIRED and usage_page == STEAM_VENDOR_USAGE_PAGE and usage == STEAM_VENDOR_USAGE:
        return "wired"
    if pid == PID_WIRELESS and usage_page == STEAM_VENDOR_USAGE_PAGE and usage == STEAM_VENDOR_USAGE:
        return "wireless"
    if pid in BLE_STEAM_PIDS and (usage_page >= STEAM_VENDOR_USAGE_PAGE or feature_len >= 19):
        return "ble"
    return None


def enumerate_steam_controllers() -> list[SteamHidInfo]:
    """Return all present Valve Steam Controller vendor/BLE HID interfaces on Windows."""
    if sys.platform != "win32":
        return []

    from ctypes import wintypes

    hid, setupapi, kernel32, GUID, SP_DEVICE_INTERFACE_DATA, HIDD_ATTRIBUTES, HIDP_CAPS, _ = _load_win32_apis()
    guid = GUID()
    hid.HidD_GetHidGuid(ctypes.byref(guid))

    dev_info = setupapi.SetupDiGetClassDevsW(ctypes.byref(guid), None, None, _DIGCF_PRESENT | _DIGCF_DEVICEINTERFACE)
    if not dev_info or dev_info == _INVALID_HANDLE_VALUE:
        return []

    found: list[SteamHidInfo] = []
    detail_cb_size = 8 if ctypes.sizeof(ctypes.c_void_p) == 8 else 6
    try:
        idx = 0
        while True:
            did = SP_DEVICE_INTERFACE_DATA()
            did.cbSize = ctypes.sizeof(SP_DEVICE_INTERFACE_DATA)
            if not setupapi.SetupDiEnumDeviceInterfaces(dev_info, None, ctypes.byref(guid), idx, ctypes.byref(did)):
                break
            idx += 1

            req = wintypes.DWORD(0)
            setupapi.SetupDiGetDeviceInterfaceDetailW(dev_info, ctypes.byref(did), None, 0, ctypes.byref(req), None)
            if req.value < detail_cb_size:
                continue

            buf = ctypes.create_string_buffer(req.value)
            ctypes.cast(buf, ctypes.POINTER(wintypes.DWORD))[0] = detail_cb_size
            if not setupapi.SetupDiGetDeviceInterfaceDetailW(
                dev_info, ctypes.byref(did), buf, req.value, None, None
            ):
                continue

            path = ctypes.wstring_at(ctypes.addressof(buf) + 4)
            if "28de" not in path.lower():
                continue

            handle = kernel32.CreateFileW(
                path, 0, _FILE_SHARE_READ | _FILE_SHARE_WRITE, None, _OPEN_EXISTING, 0, None
            )
            if not handle or handle == _INVALID_HANDLE_VALUE:
                continue
            try:
                attrs = HIDD_ATTRIBUTES(Size=ctypes.sizeof(HIDD_ATTRIBUTES))
                if not hid.HidD_GetAttributes(handle, ctypes.byref(attrs)):
                    continue
                if attrs.VendorID != VALVE_VID or attrs.ProductID not in SUPPORTED_PIDS:
                    continue

                pp_data = ctypes.c_void_p()
                if not hid.HidD_GetPreparsedData(handle, ctypes.byref(pp_data)) or not pp_data.value:
                    continue
                try:
                    caps = HIDP_CAPS()
                    if hid.HidP_GetCaps(pp_data, ctypes.byref(caps)) != _HIDP_STATUS_SUCCESS:
                        continue
                finally:
                    hid.HidD_FreePreparsedData(pp_data)

                transport = _classify_interface(
                    attrs.ProductID, caps.UsagePage, caps.Usage, caps.FeatureReportByteLength
                )
                if transport is None:
                    continue

                found.append(
                    SteamHidInfo(
                        path=path,
                        vendor_id=int(attrs.VendorID),
                        product_id=int(attrs.ProductID),
                        version_number=int(attrs.VersionNumber),
                        usage_page=int(caps.UsagePage),
                        usage=int(caps.Usage),
                        input_report_len=max(20, int(caps.InputReportByteLength or 65)),
                        feature_report_len=max(20, int(caps.FeatureReportByteLength or 65)),
                        transport=transport,
                    )
                )
            finally:
                kernel32.CloseHandle(handle)
    finally:
        setupapi.SetupDiDestroyDeviceInfoList(dev_info)

    found.sort(key=lambda d: d.path.lower())
    return found


class SteamHidDevice:
    """Overlapped Win32 HID handle for one Valve Steam Controller endpoint."""

    def __init__(self, info: SteamHidInfo) -> None:
        self.info = info
        hid, _, kernel32, _, _, _, _, OVERLAPPED = _load_win32_apis()
        self._hid = hid
        self._kernel32 = kernel32
        self._overlapped_cls = OVERLAPPED
        self._handle: int | None = None
        self._event: int | None = None

        handle = kernel32.CreateFileW(
            info.path,
            _GENERIC_READ | _GENERIC_WRITE,
            _FILE_SHARE_READ | _FILE_SHARE_WRITE,
            None,
            _OPEN_EXISTING,
            _FILE_FLAG_OVERLAPPED,
            None,
        )
        if not handle or handle == _INVALID_HANDLE_VALUE:
            handle = kernel32.CreateFileW(
                info.path,
                _GENERIC_READ,
                _FILE_SHARE_READ | _FILE_SHARE_WRITE,
                None,
                _OPEN_EXISTING,
                _FILE_FLAG_OVERLAPPED,
                None,
            )
        if not handle or handle == _INVALID_HANDLE_VALUE:
            err = ctypes.get_last_error()
            raise OSError(err, f"Cannot open Steam Controller HID endpoint (winerr={err})")

        event = kernel32.CreateEventW(None, True, False, None)
        if not event:
            err = ctypes.get_last_error()
            kernel32.CloseHandle(handle)
            raise OSError(err, f"CreateEventW failed (winerr={err})")

        self._handle = handle
        self._event = event
        self._read_len = max(65, info.input_report_len)
        self._read_buf = ctypes.create_string_buffer(self._read_len)

    def close(self) -> None:
        if self._handle is not None:
            try:
                self._kernel32.CancelIoEx(self._handle, None)
            except Exception:  # noqa: BLE001
                pass
            self._kernel32.CloseHandle(self._handle)
            self._handle = None
        if self._event is not None:
            self._kernel32.CloseHandle(self._event)
            self._event = None

    def read_packet(self, timeout_ms: int = 16) -> bytes | None:
        """Read one input report within `timeout_ms`; returns `None` on timeout, raises `OSError` on unplug."""
        if self._handle is None or self._event is None:
            raise OSError("SteamHidDevice is closed")

        from ctypes import wintypes

        n_read = wintypes.DWORD(0)
        ov = self._overlapped_cls()
        ov.hEvent = self._event
        self._kernel32.ResetEvent(self._event)

        ok = self._kernel32.ReadFile(
            self._handle, self._read_buf, self._read_len, ctypes.byref(n_read), ctypes.byref(ov)
        )
        if ok:
            return self._read_buf.raw[: n_read.value]

        err = ctypes.get_last_error()
        if err != _ERROR_IO_PENDING:
            if err in _DISCONNECT_WINERRS:
                raise OSError(err, f"Steam Controller disconnected (winerr={err})")
            return None

        wait_rc = self._kernel32.WaitForSingleObject(self._event, max(1, int(timeout_ms)))
        if wait_rc == _WAIT_OBJECT_0:
            if self._kernel32.GetOverlappedResult(self._handle, ctypes.byref(ov), ctypes.byref(n_read), False):
                return self._read_buf.raw[: n_read.value]
            err2 = ctypes.get_last_error()
            if err2 in _DISCONNECT_WINERRS:
                raise OSError(err2, f"Steam Controller disconnected (winerr={err2})")
            return None

        if wait_rc == _WAIT_TIMEOUT:
            self._kernel32.CancelIoEx(self._handle, ctypes.byref(ov))
            # Drain kernel IRP completion before `ov` leaves scope so stack memory is never touched post-return
            if self._kernel32.GetOverlappedResult(self._handle, ctypes.byref(ov), ctypes.byref(n_read), True):
                return self._read_buf.raw[: n_read.value]
            err3 = ctypes.get_last_error()
            if err3 in (6, 31, 1167):
                raise OSError(err3, f"Steam Controller disconnected (winerr={err3})")
            return None

        raise OSError(ctypes.get_last_error(), "WaitForSingleObject failed on Steam Controller HID")

    def send_feature_report(self, report65: bytes, *, max_attempts: int | None = None) -> bool:
        """Send a 65-byte Valve feature report (auto-segmented on BLE, retried on 2.4GHz Wireless)."""
        if self._handle is None:
            return False

        if self.info.transport == "ble":
            segments = segment_ble_feature_report(report65)
            for seg in segments:
                target_len = max(len(seg), self.info.feature_report_len)
                buf = ctypes.create_string_buffer(seg.ljust(target_len, b"\x00"), target_len)
                if not self._hid.HidD_SetFeature(self._handle, buf, target_len):
                    return False
            return bool(segments)

        target_len = max(len(report65), self.info.feature_report_len)
        buf = ctypes.create_string_buffer(report65.ljust(target_len, b"\x00"), target_len)
        attempts = max_attempts if max_attempts is not None else (50 if self.info.transport == "wireless" else 3)
        for attempt in range(max(1, attempts)):
            if self._hid.HidD_SetFeature(self._handle, buf, target_len):
                return True
            if attempt + 1 < attempts:
                time.sleep(0.0005)
        return False

    def get_feature_report(self, report_id: int = 0x00) -> bytes | None:
        if self._handle is None:
            return None
        target_len = max(65, self.info.feature_report_len)
        buf = ctypes.create_string_buffer(target_len)
        buf[0] = report_id & 0xFF
        attempts = 50 if self.info.transport == "wireless" else 3
        for attempt in range(attempts):
            buf[0] = report_id & 0xFF
            if self._hid.HidD_GetFeature(self._handle, buf, target_len):
                return buf.raw[:target_len]
            if attempt + 1 < attempts:
                time.sleep(0.0005)
        return None

    def probe_wireless_connected(self) -> bool:
        """Return True if a controller is actively paired & awake on a 2.4GHz wireless receiver slot."""
        if self.info.transport != "wireless":
            return True
        if not self.send_feature_report(build_get_attributes_report()):
            return False
        resp = self.get_feature_report(0x00)
        return bool(resp and len(resp) >= 3 and resp[1] == ID_GET_ATTRIBUTES_VALUES and resp[2] > 0)

    def disable_lizard_mode(self, *, enable_imu: bool = False) -> bool:
        ok_any = False
        for pkt in build_disable_lizard_reports(enable_imu=enable_imu):
            if self.send_feature_report(pkt):
                ok_any = True
        return ok_any

    def set_imu_enabled(self, enabled: bool) -> bool:
        return self.send_feature_report(build_imu_mode_report(enabled))

    def restore_lizard_mode(self) -> bool:
        ok_any = False
        for pkt in build_restore_lizard_reports():
            if self.send_feature_report(pkt):
                ok_any = True
        return ok_any

    def pulse_haptic(self, pad: int, intensity: float) -> bool:
        clamped = max(0.0, min(1.0, float(intensity)))
        if clamped <= 0.02:
            return True
        duration_us = int(350 + 2150 * clamped)
        pkt = build_haptic_pulse_report(pad=pad, duration_us=duration_us, interval_us=7000, count=6)
        return self.send_feature_report(pkt, max_attempts=1)

    def pulse_tick(self, pad: int, duration_us: int = 220, count: int = 1, interval_us: int = 5500) -> bool:
        """Non-blocking single-shot tactile click/detent for Left (1) or Right (0) touchpad linear actuator."""
        pkt = build_haptic_pulse_report(pad=pad, duration_us=duration_us, interval_us=interval_us, count=count)
        return self.send_feature_report(pkt, max_attempts=1)


_INPUT_MOUSE = 0
_MOUSEEVENTF_MOVE = 0x0001
_MOUSEEVENTF_LEFTDOWN = 0x0002
_MOUSEEVENTF_LEFTUP = 0x0004
_MOUSEEVENTF_RIGHTDOWN = 0x0008
_MOUSEEVENTF_RIGHTUP = 0x0010
_MOUSEEVENTF_WHEEL = 0x0800

_mouse_api: tuple | None = None
_last_mouse_warn_ts: float = 0.0


def _load_mouse_api():
    """Lazily bind Win32 `user32.SendInput` with full x86/x64 `INPUT` union size."""
    global _mouse_api
    if _mouse_api is not None:
        return _mouse_api
    if sys.platform != "win32":
        raise OSError("Win32 SendInput is only available on Windows")

    from ctypes import wintypes

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [
            ("dx", wintypes.LONG),
            ("dy", wintypes.LONG),
            ("mouseData", wintypes.DWORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.c_size_t),
        ]

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [
            ("wVk", wintypes.WORD),
            ("wScan", wintypes.WORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.c_size_t),
        ]

    class HARDWAREINPUT(ctypes.Structure):
        _fields_ = [
            ("uMsg", wintypes.DWORD),
            ("wParamL", wintypes.WORD),
            ("wParamH", wintypes.WORD),
        ]

    class _INPUT_UNION(ctypes.Union):
        _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

    class INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("u", _INPUT_UNION)]

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
    user32.SendInput.restype = wintypes.UINT
    _mouse_api = (user32, INPUT, MOUSEINPUT)
    return _mouse_api


def send_win32_mouse_delta(delta: MouseDelta) -> bool:
    """Inject relative mouse move, wheel scroll, and LMB/RMB transitions via Win32 `SendInput`."""
    global _last_mouse_warn_ts
    if not delta.has_activity or sys.platform != "win32":
        return True
    try:
        user32, INPUT, MOUSEINPUT = _load_mouse_api()
    except OSError:
        return False

    events: list[tuple[int, int, int, int]] = []
    if delta.dx != 0 or delta.dy != 0:
        events.append((_MOUSEEVENTF_MOVE, int(delta.dx), int(delta.dy), 0))
    if delta.left_down is True:
        events.append((_MOUSEEVENTF_LEFTDOWN, 0, 0, 0))
    elif delta.left_down is False:
        events.append((_MOUSEEVENTF_LEFTUP, 0, 0, 0))
    if delta.right_down is True:
        events.append((_MOUSEEVENTF_RIGHTDOWN, 0, 0, 0))
    elif delta.right_down is False:
        events.append((_MOUSEEVENTF_RIGHTUP, 0, 0, 0))
    if delta.wheel != 0:
        events.append((_MOUSEEVENTF_WHEEL, 0, 0, int(delta.wheel) & 0xFFFFFFFF))
    if not events:
        return True

    arr = (INPUT * len(events))()
    for idx, (flags, dx, dy, mdata) in enumerate(events):
        arr[idx].type = _INPUT_MOUSE
        arr[idx].u.mi = MOUSEINPUT(dx=dx, dy=dy, mouseData=mdata, dwFlags=flags, time=0, dwExtraInfo=0)

    sent = user32.SendInput(len(events), arr, ctypes.sizeof(INPUT))
    if sent == 0:
        now = time.monotonic()
        if now - _last_mouse_warn_ts >= 10.0:
            _last_mouse_warn_ts = now
            logger.warning(
                "%s SendInput mouse blocked (winerr=%d — target window may run as Administrator)",
                TAG,
                ctypes.get_last_error(),
            )
        return False
    return True
