"""Data models for Vietnamese Localization (Việt Hoá) catalog, translations, and manifest operations.

Complies with Bob Game Center architectural standards:
- Logging: TAG = "[VietHoa/Models]"
- Dataclasses with explicit, crash-resilient to_dict() and from_dict()
- Full support for mirrors, installation rules, and write-ahead journal ops
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)
TAG = "[VietHoa/Models]"


class DownloadType(str, Enum):
    DIRECT = "direct"
    GDRIVE = "gdrive"
    FSHARE = "fshare"
    MIRROR = "mirror"


class InstallType(str, Enum):
    EXTRACT_AND_COPY = "extract_and_copy"
    INNO_SETUP = "inno_setup"
    NSIS = "nsis"


class OpType(str, Enum):
    CREATE = "create"
    REPLACE = "replace"
    MKDIR = "mkdir"


class OpState(str, Enum):
    PENDING = "pending"
    DONE = "done"


class InstallState(str, Enum):
    NOT_INSTALLED = "not_installed"
    AVAILABLE = "available"
    INSTALLING = "installing"
    INSTALLED = "installed"


class VietHoaModelError(ValueError):
    """Raised when catalog or translation model data fails validation."""


@dataclass
class DownloadMirror:
    """Secondary or fallback download location."""

    url: str
    type: str = DownloadType.DIRECT.value
    file_id: str | None = None
    notes: str = ""

    def __post_init__(self):
        self.url = str(self.url or "").strip()
        self.type = str(self.type or DownloadType.DIRECT.value).strip()
        if self.file_id is not None:
            self.file_id = str(self.file_id).strip() or None
        self.notes = str(self.notes or "").strip()

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": self.type,
            "url": self.url,
        }
        if self.file_id:
            data["file_id"] = self.file_id
        if self.notes:
            data["notes"] = self.notes
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DownloadMirror:
        if not isinstance(data, dict):
            raise VietHoaModelError(f"DownloadMirror data must be a dict, got {type(data).__name__}")
        return cls(
            url=data.get("url") or "",
            type=data.get("type") or DownloadType.DIRECT.value,
            file_id=data.get("file_id"),
            notes=data.get("notes") or "",
        )


@dataclass
class VietHoaDownloadInfo:
    """Download specification for a translation release including mirrors and checksums."""

    primary_url: str = ""
    type: str = DownloadType.DIRECT.value
    sha256: str = ""
    size_bytes: int = 0
    mirrors: list[DownloadMirror] = field(default_factory=list)

    def __post_init__(self):
        self.primary_url = str(self.primary_url or "").strip()
        self.type = str(self.type or DownloadType.DIRECT.value).strip()
        self.sha256 = str(self.sha256 or "").strip().lower()
        self.size_bytes = max(0, int(self.size_bytes or 0))

    @property
    def url(self) -> str:
        """Convenience alias for primary download URL."""
        return self.primary_url

    @property
    def all_urls(self) -> list[str]:
        """List of all available download URLs starting with primary."""
        urls = [self.primary_url] if self.primary_url else []
        for m in self.mirrors:
            if m.url and m.url not in urls:
                urls.append(m.url)
        return urls

    def to_dict(self) -> dict[str, Any]:
        return {
            "primary": {
                "type": self.type,
                "url": self.primary_url,
                "sha256": self.sha256,
                "size_bytes": int(self.size_bytes),
            },
            "mirrors": [m.to_dict() for m in self.mirrors],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VietHoaDownloadInfo:
        if not isinstance(data, dict):
            return cls()

        # Handle nested {"primary": {...}, "mirrors": [...]}
        if "primary" in data and isinstance(data["primary"], dict):
            prim = data["primary"]
            mirrors_raw = data.get("mirrors") or []
            mirrors = [DownloadMirror.from_dict(m) for m in mirrors_raw if isinstance(m, dict)]
            return cls(
                primary_url=str(prim.get("url") or "").strip(),
                type=str(prim.get("type") or DownloadType.DIRECT.value).strip(),
                sha256=str(prim.get("sha256") or "").strip().lower(),
                size_bytes=int(prim.get("size_bytes") or 0),
                mirrors=mirrors,
            )

        # Handle flat structure {"url": ..., "sha256": ..., "size_bytes": ...}
        mirrors_raw = data.get("mirrors") or []
        mirrors = [DownloadMirror.from_dict(m) for m in mirrors_raw if isinstance(m, dict)]
        return cls(
            primary_url=str(data.get("url") or data.get("primary_url") or "").strip(),
            type=str(data.get("type") or DownloadType.DIRECT.value).strip(),
            sha256=str(data.get("sha256") or "").strip().lower(),
            size_bytes=int(data.get("size_bytes") or 0),
            mirrors=mirrors,
        )


@dataclass
class InstallRules:
    """Rules specifying how to place unpacked files into the game directory."""

    type: str = InstallType.EXTRACT_AND_COPY.value
    target_subdir: str = ""
    strip_components: int = 0
    backup_patterns: list[str] = field(default_factory=list)
    archive_password: str = ""

    def __post_init__(self):
        self.type = str(self.type or InstallType.EXTRACT_AND_COPY.value).strip()
        self.target_subdir = str(self.target_subdir or "").strip().replace("\\", "/").strip("/")
        self.strip_components = max(0, int(self.strip_components or 0))
        if self.backup_patterns:
            cleaned = []
            for p in self.backup_patterns:
                cp = str(p or "").strip().replace("\\", "/")
                if cp:
                    cleaned.append(cp)
            self.backup_patterns = cleaned
        self.archive_password = str(self.archive_password or "")

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": self.type,
            "strip_components": int(self.strip_components),
            "target_subdir": self.target_subdir,
            "backup_patterns": list(self.backup_patterns),
        }
        if self.archive_password:
            data["archive_password"] = self.archive_password
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> InstallRules:
        if not isinstance(data, dict):
            return cls()

        patterns_raw = data.get("backup_patterns")
        patterns: list[str] = []
        if isinstance(patterns_raw, list):
            patterns = [str(p) for p in patterns_raw if p]
        elif isinstance(patterns_raw, str) and patterns_raw.strip():
            patterns = [patterns_raw]

        return cls(
            type=str(data.get("type") or InstallType.EXTRACT_AND_COPY.value),
            target_subdir=str(data.get("target_subdir") or ""),
            strip_components=int(data.get("strip_components") or 0),
            backup_patterns=patterns,
            archive_password=str(data.get("archive_password") or ""),
        )


@dataclass
class VietHoaTranslation:
    """A specific Vietnamese localization patch release for a game."""

    id: str
    team: str
    version: str
    download_url: str = ""
    sha256: str = ""
    size_bytes: int = 0
    target_subdir: str = ""
    backup_patterns: list[str] = field(default_factory=list)
    team_url: str = ""
    game_version_min: str = ""
    game_version_max: str = ""
    notes: str = ""
    download: VietHoaDownloadInfo = field(default_factory=VietHoaDownloadInfo)
    install_rules: InstallRules = field(default_factory=InstallRules)
    is_active: bool = True

    def __post_init__(self):
        self.id = str(self.id or "").strip()
        self.team = str(self.team or "").strip()
        self.version = str(self.version or "").strip()
        self.team_url = str(self.team_url or "").strip()
        self.game_version_min = str(self.game_version_min or "").strip()
        self.game_version_max = str(self.game_version_max or "").strip()
        self.notes = str(self.notes or "").strip()
        self.is_active = bool(self.is_active)

        # Forward flat parameters to nested structures if provided
        if self.download_url and not self.download.primary_url:
            self.download.primary_url = str(self.download_url).strip()
        if self.sha256 and not self.download.sha256:
            self.download.sha256 = str(self.sha256).strip().lower()
        if self.size_bytes and not self.download.size_bytes:
            self.download.size_bytes = int(self.size_bytes)
        if self.target_subdir and not self.install_rules.target_subdir:
            self.install_rules.target_subdir = str(self.target_subdir).strip()
        if self.backup_patterns and not self.install_rules.backup_patterns:
            self.install_rules.backup_patterns = list(self.backup_patterns)

        # Synchronize flat fields from nested structures
        if not self.download_url and self.download.primary_url:
            self.download_url = self.download.primary_url
        if not self.sha256 and self.download.sha256:
            self.sha256 = self.download.sha256
        if not self.size_bytes and self.download.size_bytes:
            self.size_bytes = self.download.size_bytes
        if not self.target_subdir and self.install_rules.target_subdir:
            self.target_subdir = self.install_rules.target_subdir
        if not self.backup_patterns and self.install_rules.backup_patterns:
            self.backup_patterns = list(self.install_rules.backup_patterns)

    @property
    def strip_components(self) -> int:
        return self.install_rules.strip_components

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "team": self.team,
            "team_url": self.team_url,
            "version": self.version,
            "game_version_min": self.game_version_min,
            "game_version_max": self.game_version_max,
            "notes": self.notes,
            "download": self.download.to_dict(),
            "install_rules": self.install_rules.to_dict(),
            "is_active": self.is_active,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VietHoaTranslation:
        if not isinstance(data, dict):
            raise VietHoaModelError(f"VietHoaTranslation data must be a dict, got {type(data).__name__}")

        tid = str(data.get("id") or "").strip()
        team = str(data.get("team") or "").strip()
        version = str(data.get("version") or "").strip()

        # Download info extraction (nested or flat)
        if "download" in data and isinstance(data["download"], dict):
            download_info = VietHoaDownloadInfo.from_dict(data["download"])
        else:
            download_info = VietHoaDownloadInfo.from_dict(
                {
                    "url": data.get("download_url") or data.get("url") or "",
                    "sha256": data.get("sha256") or "",
                    "size_bytes": data.get("size_bytes") or 0,
                }
            )

        # Install rules extraction (nested or flat)
        if "install_rules" in data and isinstance(data["install_rules"], dict):
            install_rules = InstallRules.from_dict(data["install_rules"])
        else:
            install_rules = InstallRules.from_dict(
                {
                    "target_subdir": data.get("target_subdir") or "",
                    "strip_components": data.get("strip_components") or 0,
                    "backup_patterns": data.get("backup_patterns") or [],
                }
            )

        return cls(
            id=tid,
            team=team,
            version=version,
            team_url=str(data.get("team_url") or "").strip(),
            game_version_min=str(data.get("game_version_min") or "").strip(),
            game_version_max=str(data.get("game_version_max") or "").strip(),
            notes=str(data.get("notes") or "").strip(),
            download=download_info,
            install_rules=install_rules,
            is_active=bool(data.get("is_active", True)),
        )


@dataclass
class VietHoaEntry:
    """Catalog entry mapping a game to its community Vietnamese translations."""

    id: str
    canonical_title: str
    aliases: list[str] = field(default_factory=list)
    steam_appid: int | None = None
    online_fix_ids: list[str] = field(default_factory=list)
    translations: list[VietHoaTranslation] = field(default_factory=list)

    def __post_init__(self):
        self.id = str(self.id or "").strip()
        self.canonical_title = str(self.canonical_title or "").strip()
        if self.aliases:
            self.aliases = [str(a).strip() for a in self.aliases if str(a).strip()]
        if self.online_fix_ids:
            self.online_fix_ids = [str(x).strip() for x in self.online_fix_ids if str(x).strip()]
        if self.steam_appid is not None:
            try:
                parsed = int(self.steam_appid)
                self.steam_appid = parsed if parsed > 0 else None
            except (ValueError, TypeError):
                self.steam_appid = None

    def get_active_translation(self) -> VietHoaTranslation | None:
        """Return the default/active translation release for this game."""
        for t in self.translations:
            if t.is_active:
                return t
        return self.translations[0] if self.translations else None

    def all_search_titles(self) -> list[str]:
        """All searchable title variants (canonical title + aliases)."""
        titles = [self.canonical_title]
        for a in self.aliases:
            if a and a not in titles:
                titles.append(a)
        return titles

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "canonical_title": self.canonical_title,
            "aliases": list(self.aliases),
            "steam_appid": self.steam_appid,
            "online_fix_ids": list(self.online_fix_ids),
            "translations": [t.to_dict() for t in self.translations],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VietHoaEntry:
        if not isinstance(data, dict):
            raise VietHoaModelError(f"VietHoaEntry data must be a dict, got {type(data).__name__}")

        eid = str(data.get("id") or "").strip()
        canonical_title = str(data.get("canonical_title") or "").strip()
        if not eid:
            raise VietHoaModelError("VietHoaEntry must have a non-empty 'id'")
        if not canonical_title:
            raise VietHoaModelError(f"VietHoaEntry '{eid}' must have a non-empty 'canonical_title'")

        # Parse steam_appid safely
        raw_appid = data.get("steam_appid")
        appid: int | None = None
        if raw_appid is not None and str(raw_appid).strip():
            try:
                parsed = int(raw_appid)
                if parsed > 0:
                    appid = parsed
            except (ValueError, TypeError):
                logger.warning(f"{TAG} invalid steam_appid '{raw_appid}' in entry '{eid}'")

        # Parse aliases
        raw_aliases = data.get("aliases") or []
        aliases: list[str] = []
        if isinstance(raw_aliases, list):
            aliases = [str(a).strip() for a in raw_aliases if str(a).strip()]

        # Parse online_fix_ids
        raw_of_ids = data.get("online_fix_ids") or []
        online_fix_ids: list[str] = []
        if isinstance(raw_of_ids, list):
            online_fix_ids = [str(x).strip() for x in raw_of_ids if str(x).strip()]

        # Parse translations
        raw_trans = data.get("translations") or []
        translations: list[VietHoaTranslation] = []
        if isinstance(raw_trans, list):
            for t_data in raw_trans:
                if isinstance(t_data, dict):
                    translations.append(VietHoaTranslation.from_dict(t_data))

        return cls(
            id=eid,
            canonical_title=canonical_title,
            aliases=aliases,
            steam_appid=appid,
            online_fix_ids=online_fix_ids,
            translations=translations,
        )


@dataclass
class ManifestOp:
    """Individual atomic operation in the write-ahead install journal."""

    op: str
    path: str
    backup: str | None = None
    state: str = OpState.PENDING.value
    sha256: str | None = None

    def __post_init__(self):
        self.op = str(self.op or "").strip().lower()
        self.path = str(self.path or "").strip().replace("\\", "/")
        if self.backup:
            self.backup = str(self.backup).strip().replace("\\", "/")
        self.state = str(self.state or OpState.PENDING.value).strip().lower()
        if self.sha256:
            self.sha256 = str(self.sha256).strip().lower()

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "op": self.op,
            "path": self.path,
            "state": self.state,
        }
        if self.backup:
            data["backup"] = self.backup
        if self.sha256:
            data["sha256"] = self.sha256
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ManifestOp:
        if not isinstance(data, dict):
            raise VietHoaModelError(f"ManifestOp data must be a dict, got {type(data).__name__}")
        return cls(
            op=str(data.get("op") or "").strip().lower(),
            path=str(data.get("path") or "").strip().replace("\\", "/"),
            backup=str(data.get("backup")).strip().replace("\\", "/") if data.get("backup") else None,
            state=str(data.get("state") or OpState.PENDING.value).strip().lower(),
            sha256=str(data.get("sha256")).strip().lower() if data.get("sha256") else None,
        )


@dataclass
class VietHoaCatalog:
    """Full Vietnamese localization catalog with version and entry collection."""

    version: int = 1
    updated_at: str = ""
    schema_url: str = ""
    catalog: dict[str, VietHoaEntry] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "version": int(self.version),
            "updated_at": self.updated_at,
            "catalog": {k: v.to_dict() for k, v in self.catalog.items()},
        }
        if self.schema_url:
            data["$schema"] = self.schema_url
        return data

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VietHoaCatalog:
        if not isinstance(data, dict):
            raise VietHoaModelError(f"Catalog data must be a dict, got {type(data).__name__}")

        version = int(data.get("version") or 1)
        updated_at = str(data.get("updated_at") or "")
        schema_url = str(data.get("$schema") or "")

        raw_cat = data.get("catalog") or {}
        entries: dict[str, VietHoaEntry] = {}
        if isinstance(raw_cat, dict):
            for k, v in raw_cat.items():
                if isinstance(v, dict):
                    entries[k] = VietHoaEntry.from_dict(v)

        return cls(
            version=version,
            updated_at=updated_at,
            schema_url=schema_url,
            catalog=entries,
        )

    @classmethod
    def from_json(cls, json_text: str | bytes) -> VietHoaCatalog:
        try:
            raw = json.loads(json_text)
        except Exception as e:
            logger.error(f"{TAG} Failed to parse catalog JSON: {e}")
            raise VietHoaModelError(f"Malformed catalog JSON: {e}") from e
        return cls.from_dict(raw)

    def get(self, entry_id: str) -> VietHoaEntry | None:
        return self.catalog.get(entry_id)

    def __getitem__(self, entry_id: str) -> VietHoaEntry:
        return self.catalog[entry_id]

    def __contains__(self, entry_id: str) -> bool:
        return entry_id in self.catalog

    def __len__(self) -> int:
        return len(self.catalog)
