"""
SteamRipClient: HTTP scraping & WordPress REST API client for https://steamrip.com/
Supports browsing latest pre-installed games, searching by title, extracting download mirrors,
and resolving supported direct hosters (Gofile, PixelDrain, Buzzheavier, Torrent/Magnet) for aria2c.

No login required. Network failures raise OnlineFixError with a clear Vietnamese message.
"""

from collections import OrderedDict
import json
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
from typing import List, Optional
from urllib.parse import quote, urljoin, urlparse

import bs4
import requests

from app.core.online_fix.client import OnlineFixError
from app.core.online_fix.models import (
    LINK_TORRENT,
    LINK_WEB,
    SOURCE_STEAMRIP,
    STEAMRIP_ARCHIVE_PASSWORD,
    OnlineFixGame,
    dotted_acronym_query, format_ts_ddmmyyyy, is_excluded_game, matches_search_query, parse_store_date_ts, sort_games_for_search,
)
from app.core.online_fix.store_cache import (
    _is_test_env,
    classify_game_categories,
    get_store_cache_dir,
)
from app.utils.helpers import is_admin

logger = logging.getLogger(__name__)
TAG = "[SteamRip/Client]"

STEAMRIP_BASE_URL = "https://steamrip.com"
STEAMRIP_PAGE_SIZE = 12
STEAMRIP_BATCH_SIZE = 100
REQUEST_TIMEOUT = 18

_WP_POST_FIELDS = "id,date,modified,link,title,content,categories,_links,_embedded"

_STEAMRIP_WP_CAT_TAGS: dict[int, str] = {
    1538: "Multiplayer, Co-op",
    26: "Action",
    52: "FPS, Action",
    41: "Shooter, Action",
    63: "RPG",
    29: "Anime, RPG",
    27: "Adventure",
    45: "Open World, Adventure",
    70: "Sci-Fi, Adventure",
    32: "Horror",
    119: "Survival, Horror",
    35: "Racing",
    38: "Sports",
    42: "Strategy",
    37: "Simulation",
    53: "Building, Simulation",
    33: "Indie",
}

STEAMRIP_CATEGORY_WP_IDS: dict[str, tuple[int, ...]] = {
    "coop": (1538,),
    "action": (26, 52, 41),
    "rpg": (63, 29),
    "adventure": (27, 45, 70),
    "horror": (32, 119),
    "sports_racing": (35, 38),
    "strategy_sim": (42, 37, 53),
    "indie": (33,),
}

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

_FREE_DL_RE = re.compile(r"\s+free\s+download\b", re.IGNORECASE)
_TRAILING_VER_RE = re.compile(r"\s*[\(\[]([^)\]]+)[\)\]]\s*$")
_LINE_BREAK_TAG_RE = re.compile(r"</?(?:br|p|div|li|tr|h[1-6])\b[^>]*>", re.IGNORECASE)
_GENRE_RE = re.compile(r"Genre\s*:\s*([^\n]+)", re.IGNORECASE)
_SIZE_RE = re.compile(r"Game\s+Size\s*:\s*([^\n]+)", re.IGNORECASE)
_VERSION_RE = re.compile(r"Version\s*:\s*([^\n]+)", re.IGNORECASE)
_COOP_BY_RE = re.compile(r"(?:Co-?op|Multiplayer)\s+By\s*:\s*([^\n]+)", re.IGNORECASE)
_RELEASED_BY_RE = re.compile(r"Released\s+By\s*:\s*([^\n]+)", re.IGNORECASE)
_UPDATE_ONLY_RE = re.compile(r"\bupdate\s+only\b", re.IGNORECASE)
_GOFILE_ID_RE = re.compile(r"gofile\.io/d/([A-Za-z0-9_-]+)", re.IGNORECASE)
_PIXELDRAIN_FILE_RE = re.compile(r"pixeldrain\.com/u/([A-Za-z0-9_-]+)", re.IGNORECASE)
_PIXELDRAIN_LIST_RE = re.compile(r"pixeldrain\.com/l/([A-Za-z0-9_-]+)", re.IGNORECASE)

_IGNORED_DOMAINS = (
    "steamrip.com/faq",
    "steamrip.com/steps-for-games",
    "steamrip.com/request-games",
    "steamrip.com/category/",
    "steamrip.com/tag/",
    "discord.gg",
    "discord.com",
    "reddit.com",
    "store.steampowered.com",
    "youtube.com",
    "youtu.be",
    "facebook.com",
    "twitter.com",
    "x.com",
)


def split_steamrip_title(raw_title: str) -> tuple[str, str]:
    """Split 'ELDEN RING NIGHTREIGN Free Download (v1.03.3 + Co-op)' into ('ELDEN RING NIGHTREIGN', 'v1.03.3 + Co-op')."""
    text = " ".join((raw_title or "").replace("\u2013", "-").replace("\u2014", "-").split()).strip()
    if not text:
        return "", ""

    notes: list[str] = []
    while True:
        m = _TRAILING_VER_RE.search(text)
        if not m:
            break
        inner = m.group(1).strip()
        if any(k in inner.lower() for k in ("v", "build", "co-op", "coop", "dlc", "online", "multiplayer", "hotfix", "+")) or re.search(r"\d", inner):
            notes.insert(0, inner)
            text = text[: m.start()].strip()
        else:
            break

    text = _FREE_DL_RE.sub("", text).strip().rstrip("-:| ")
    while True:
        m = _TRAILING_VER_RE.search(text)
        if not m:
            break
        inner = m.group(1).strip()
        if re.search(r"\d", inner) or "co-op" in inner.lower():
            notes.insert(0, inner)
            text = text[: m.start()].strip()
        else:
            break

    return text, " · ".join(notes)


def _format_iso_date(iso_str: str) -> str:
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", (iso_str or "").strip())
    if m:
        return f"{m.group(3)}/{m.group(2)}/{m.group(1)}"
    return (iso_str or "").strip()


class SteamRipClient:
    """Thread-safe HTTP & WordPress REST API client for SteamRIP."""

    MAX_DETAILS_CACHE = 600
    GOFILE_WT_TTL_SEC = 1200  # 20 minutes (< 6h Gofile secret rotation window)

    def __init__(self):
        self._local = threading.local()
        self._cache_lock = threading.Lock()
        self._details_cache: OrderedDict[str, OnlineFixGame] = OrderedDict()
        self._gofile_lock = threading.Lock()
        self._gofile_token: str = ""
        self._gofile_wt_js: str = ""
        self._gofile_wt_fetched_at: float = 0.0
        self._cdp_lock = threading.Lock()

    @property
    def session(self) -> requests.Session:
        sess = getattr(self._local, "session", None)
        if sess is None:
            sess = requests.Session()
            sess.headers.update({
                "User-Agent": USER_AGENT,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/json,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
            })
            self._local.session = sess
        return sess

    def is_logged_in(self) -> bool:
        return True

    def _get(self, url: str, purpose: str, **kwargs) -> requests.Response:
        kwargs.setdefault("timeout", REQUEST_TIMEOUT)
        started = time.monotonic()
        try:
            resp = self.session.get(url, **kwargs)
        except requests.Timeout as e:
            logger.error(f"{TAG} Timeout ({purpose}) after {time.monotonic() - started:.1f}s: {url}")
            raise OnlineFixError("Kết nối tới SteamRIP quá thời gian chờ. Kiểm tra mạng hoặc thử lại.") from e
        except requests.RequestException as e:
            logger.error(f"{TAG} Network error ({purpose}) after {time.monotonic() - started:.1f}s on {url}: {e}")
            raise OnlineFixError(f"Không kết nối được tới SteamRIP: {e}") from e

        elapsed = time.monotonic() - started
        if resp.status_code >= 400:
            logger.warning(f"{TAG} HTTP {resp.status_code} ({purpose}) in {elapsed:.1f}s: {url}")
            raise OnlineFixError(f"Máy chủ SteamRIP trả về mã lỗi HTTP {resp.status_code}.")
        logger.debug(f"{TAG} GET {purpose} -> {resp.status_code} ({len(resp.content)} B, {elapsed:.2f}s)")
        return resp

    def fetch_bytes(self, url: str, referer: str = "") -> bytes:
        full_url = url if url.startswith("http") else urljoin(STEAMRIP_BASE_URL + "/", url.lstrip("/"))
        headers = {"Referer": referer or (STEAMRIP_BASE_URL + "/")}
        return self._get(full_url, "asset", headers=headers).content

    def _remember_game(self, game: OnlineFixGame) -> None:
        if not game.url:
            return
        key = game.url.rstrip("/").lower()
        with self._cache_lock:
            self._details_cache[key] = game
            self._details_cache.move_to_end(key)
            while len(self._details_cache) > self.MAX_DETAILS_CACHE:
                self._details_cache.popitem(last=False)

    def _get_cached_game(self, game_url: str) -> Optional[OnlineFixGame]:
        if not game_url:
            return None
        key = game_url.rstrip("/").lower()
        with self._cache_lock:
            g = self._details_cache.get(key)
            if g is not None and g.download_links:
                self._details_cache.move_to_end(key)
                return g
        return None

    # ------------------------------------------------------------ browse & search

    def get_latest_games(self, page: int = 1, per_page: int = STEAMRIP_PAGE_SIZE) -> List[OnlineFixGame]:
        """Fetch latest pre-installed games on steamrip.com via WP REST API (HTML fallback)."""
        started = time.monotonic()
        limit = max(1, min(int(per_page or STEAMRIP_PAGE_SIZE), 100))
        wp_url = (
            f"{STEAMRIP_BASE_URL}/wp-json/wp/v2/posts"
            f"?page={page}&per_page={limit}&_embed=wp:featuredmedia&_fields={_WP_POST_FIELDS}"
        )
        try:
            text = self._get(wp_url, f"latest p{page} (n={limit})").text.lstrip()
            if text.startswith("["):
                games = self._parse_wp_json_posts(text)
            else:
                games = self._parse_html_game_list(text)
        except OnlineFixError as err:
            if any(code in str(err) for code in ("HTTP 400", "HTTP 404")) and page > 1:
                logger.info(f"{TAG} Latest games page {page}: 0 games (past last page) in {time.monotonic() - started:.2f}s")
                return []
            fallback_url = f"{STEAMRIP_BASE_URL}/page/{page}/" if page > 1 else f"{STEAMRIP_BASE_URL}/"
            html = self._get(fallback_url, f"latest-html p{page}").text
            games = self._parse_html_game_list(html)

        suffix = f" (per_page={limit})" if limit != STEAMRIP_PAGE_SIZE else ""
        logger.info(f"{TAG} Latest games page {page}{suffix}: {len(games)} games in {time.monotonic() - started:.2f}s")
        return games

    def get_category_games(self, category_slug: str, page: int = 1, per_page: int = 48) -> List[OnlineFixGame]:
        """Fetch games for a specific canonical store category directly from SteamRIP WP category archive."""
        wp_cat_ids = STEAMRIP_CATEGORY_WP_IDS.get(category_slug)
        if not wp_cat_ids:
            return []
        started = time.monotonic()
        limit = max(1, min(int(per_page or 48), 100))
        cat_csv = ",".join(str(cid) for cid in wp_cat_ids)
        wp_url = (
            f"{STEAMRIP_BASE_URL}/wp-json/wp/v2/posts"
            f"?categories={cat_csv}&page={page}&per_page={limit}&_embed=wp:featuredmedia&_fields={_WP_POST_FIELDS}"
        )
        try:
            text = self._get(wp_url, f"category {category_slug!r} p{page}").text.lstrip()
            games = self._parse_wp_json_posts(text) if text.startswith("[") else []
        except OnlineFixError as err:
            if any(code in str(err) for code in ("HTTP 400", "HTTP 404")) and page > 1:
                logger.info(f"{TAG} Category {category_slug!r} page {page}: 0 games (past last page) in {time.monotonic() - started:.2f}s")
                return []
            logger.warning(f"{TAG} Category {category_slug!r} p{page} failed in {time.monotonic() - started:.2f}s: {err}")
            return []
        logger.info(
            f"{TAG} Category {category_slug!r} page {page}: {len(games)} games in {time.monotonic() - started:.2f}s"
        )
        return games

    def search_games(self, query: str, page: int = 1) -> List[OnlineFixGame]:
        """Search SteamRIP by game title using WP REST API `search_columns=post_title`."""
        q = (query or "").strip()
        if not q:
            return self.get_latest_games(page)

        started = time.monotonic()
        encoded = quote(q)
        wp_url = (
            f"{STEAMRIP_BASE_URL}/wp-json/wp/v2/posts"
            f"?search={encoded}&search_columns=post_title&page={page}&per_page={STEAMRIP_PAGE_SIZE}&_embed=wp:featuredmedia"
        )
        try:
            text = self._get(wp_url, f"search {q!r} p{page}").text.lstrip()
            raw_games = self._parse_wp_json_posts(text) if text.startswith("[") else self._parse_html_game_list(text)
            games = [g for g in raw_games if matches_search_query(q, g.title, g.url)]
        except OnlineFixError as err:
            if any(code in str(err) for code in ("HTTP 400", "HTTP 404")) and page > 1:
                logger.info(f"{TAG} Search {q!r} page {page}: 0 games (past last page) in {time.monotonic() - started:.2f}s")
                return []
            # Fallback if WP `search_columns` is rejected on an older endpoint
            fallback_wp = (
                f"{STEAMRIP_BASE_URL}/wp-json/wp/v2/posts"
                f"?search={encoded}&page={page}&per_page={STEAMRIP_PAGE_SIZE}&_embed=wp:featuredmedia"
            )
            text = self._get(fallback_wp, f"search-fallback {q!r} p{page}").text.lstrip()
            raw_games = self._parse_wp_json_posts(text) if text.startswith("[") else self._parse_html_game_list(text)
            games = [g for g in raw_games if matches_search_query(q, g.title, g.url)]

        if page == 1 and not games:
            dotted = dotted_acronym_query(q)
            if dotted:
                try:
                    d_url = (
                        f"{STEAMRIP_BASE_URL}/wp-json/wp/v2/posts"
                        f"?search={quote(dotted)}&search_columns=post_title&page=1&per_page={STEAMRIP_PAGE_SIZE}&_embed=wp:featuredmedia"
                    )
                    d_text = self._get(d_url, f"search-dotted {dotted!r} p1").text.lstrip()
                    d_raw = self._parse_wp_json_posts(d_text) if d_text.startswith("[") else self._parse_html_game_list(d_text)
                    games = [g for g in d_raw if matches_search_query(q, g.title, g.url)]
                except OnlineFixError:
                    pass

        games = sort_games_for_search(q, games)
        logger.info(f"{TAG} Search {q!r} page {page}: {len(games)} games in {time.monotonic() - started:.2f}s")
        return games

    def _parse_wp_json_posts(self, raw_json: str) -> List[OnlineFixGame]:
        try:
            items = json.loads(raw_json)
        except ValueError as e:
            logger.warning(f"{TAG} Could not parse WP JSON response: {e}")
            return []
        if not isinstance(items, list):
            return []

        games: List[OnlineFixGame] = []
        seen: set[str] = set()
        for item in items:
            try:
                game_url = str(item.get("link") or "").strip()
                if not game_url or game_url in seen:
                    continue
                if any(ig in game_url.lower() for ig in _IGNORED_DOMAINS):
                    continue

                raw_title_html = (item.get("title") or {}).get("rendered") or ""
                raw_title = bs4.BeautifulSoup(raw_title_html, "html.parser").get_text(" ").strip()
                title, version_note = split_steamrip_title(raw_title)
                if not title or is_excluded_game(title, game_url):
                    continue

                content_html = (item.get("content") or {}).get("rendered") or ""
                content_soup = bs4.BeautifulSoup(content_html, "html.parser")

                poster_url = self._extract_embedded_poster(item) or self._extract_poster_from_soup(content_soup)
                update_info, game_modes, raw_genres = self._extract_metadata(content_soup, version_note)
                wp_cats = item.get("categories")
                if isinstance(wp_cats, list):
                    for cid in wp_cats:
                        if isinstance(cid, int) and cid in _STEAMRIP_WP_CAT_TAGS:
                            raw_genres.append(_STEAMRIP_WP_CAT_TAGS[cid])
                download_links = self._extract_download_links(content_soup)

                game = OnlineFixGame(
                    id=str(item.get("id") or os.path.basename(game_url.rstrip("/"))),
                    title=title,
                    url=game_url,
                    poster_url=poster_url,
                    date=_format_iso_date(str(item.get("date") or "")), published_ts=parse_store_date_ts(str(item.get("date") or "")), updated_ts=parse_store_date_ts(str(item.get("modified") or "")),
                    update_info=update_info,
                    game_modes=game_modes,
                    archive_password=STEAMRIP_ARCHIVE_PASSWORD,
                    download_links=download_links,
                    source=SOURCE_STEAMRIP,
                )
                game.categories = classify_game_categories(game, extra_genres=raw_genres)
                seen.add(game_url)
                self._remember_game(game)
                games.append(game)
            except Exception as e:   # noqa: BLE001
                logger.debug(f"{TAG} Skipped WP JSON post: {e}")
        return games

    def _parse_html_game_list(self, html: str) -> List[OnlineFixGame]:
        soup = bs4.BeautifulSoup(html, "html.parser")
        games: List[OnlineFixGame] = []
        seen: set[str] = set()
        for art in soup.select("article, li.post-item, div.post-element"):
            try:
                a_tag = (
                    art.select_one("h2.post-title a, h2.entry-title a, h3.post-title a, a.post-thumb")
                    or art.find("a", href=True)
                )
                if not a_tag:
                    continue
                game_url = (a_tag.get("href") or "").strip()
                if not game_url.startswith("http") or game_url in seen:
                    continue
                if any(ig in game_url.lower() for ig in _IGNORED_DOMAINS):
                    continue
                title_node = art.select_one("h2.post-title, h2.entry-title, h3.post-title") or a_tag
                raw_title = title_node.get_text(" ").strip()
                title, version_note = split_steamrip_title(raw_title)
                if not title or is_excluded_game(title, game_url):
                    continue
                poster_url = self._extract_poster_from_soup(art)
                seen.add(game_url)
                g = OnlineFixGame(
                    id=os.path.basename(game_url.rstrip("/")) or title,
                    title=title,
                    url=game_url,
                    poster_url=poster_url,
                    date="",
                    update_info=version_note, published_ts=parse_store_date_ts((art.find("time").get("datetime") or art.find("time").get_text(" ", strip=True)) if art.find("time") else ""),
                    game_modes="",
                    archive_password=STEAMRIP_ARCHIVE_PASSWORD,
                    download_links=[],
                    source=SOURCE_STEAMRIP,
                )
                g.categories = classify_game_categories(g)
                games.append(g)
            except Exception as e:   # noqa: BLE001
                logger.debug(f"{TAG} Skipped HTML list card: {e}")
        return games

    # ------------------------------------------------------------ details

    def get_game_details(self, game_url: str) -> OnlineFixGame:
        """Return cached details when already parsed from WP-JSON, otherwise fetch the post page."""
        cached = self._get_cached_game(game_url)
        if cached is not None:
            kinds: dict[str, int] = {}
            for link in cached.download_links:
                kinds[link["kind"]] = kinds.get(link["kind"], 0) + 1
            logger.info(f"{TAG} Details {cached.title!r} (cache hit): links {kinds or 'none'}, 0.00s")
            return cached

        started = time.monotonic()
        slug = os.path.basename(urlparse(game_url).path.rstrip("/"))
        if slug:
            wp_slug_url = f"{STEAMRIP_BASE_URL}/wp-json/wp/v2/posts?slug={quote(slug)}&_embed=wp:featuredmedia"
            try:
                raw = self._get(wp_slug_url, f"details-wp {slug}").text.lstrip()
                if raw.startswith("["):
                    parsed = self._parse_wp_json_posts(raw)
                    if parsed:
                        game = parsed[0]
                        logger.info(f"{TAG} Details {game.title!r}: {len(game.download_links)} links in {time.monotonic() - started:.2f}s")
                        return game
            except OnlineFixError:
                pass

        html = self._get(game_url, "details-html").text
        game = self._parse_html_details(html, game_url)
        self._remember_game(game)
        kinds = {}
        for link in game.download_links:
            kinds[link["kind"]] = kinds.get(link["kind"], 0) + 1
        logger.info(f"{TAG} Details {game.title!r}: links {kinds or 'none'}, {time.monotonic() - started:.2f}s")
        return game

    def _parse_html_details(self, html: str, game_url: str) -> OnlineFixGame:
        soup = bs4.BeautifulSoup(html, "html.parser")
        h1 = soup.select_one("h1.post-title, h1.entry-title, h1")
        raw_title = h1.get_text(" ").strip() if h1 else ""
        title, version_note = split_steamrip_title(raw_title)

        og_img = soup.find("meta", property="og:image")
        poster_url = (og_img.get("content") or "").strip() if og_img else ""

        content_node = soup.select_one("div.entry-content, div.entry, article") or soup
        if not poster_url:
            poster_url = self._extract_poster_from_soup(content_node)

        update_info, game_modes, raw_genres = self._extract_metadata(content_node, version_note)
        download_links = self._extract_download_links(content_node)

        game = OnlineFixGame(
            id=os.path.basename(game_url.rstrip("/")) or "steamrip",
            title=title or raw_title or "SteamRIP Game", published_ts=parse_store_date_ts(str(soup.find("meta", property="article:published_time").get("content") or "")) if soup.find("meta", property="article:published_time") else 0.0, updated_ts=parse_store_date_ts(str(soup.find("meta", property="article:modified_time").get("content") or "")) if soup.find("meta", property="article:modified_time") else 0.0,
            url=game_url,
            poster_url=poster_url,
            date="",
            update_info=update_info,
            game_modes=game_modes,
            archive_password=STEAMRIP_ARCHIVE_PASSWORD,
            download_links=download_links,
            source=SOURCE_STEAMRIP,
        )
        game.categories = classify_game_categories(game, extra_genres=raw_genres)
        return game

    # ------------------------------------------------------------ metadata & link helpers

    @staticmethod
    def _extract_embedded_poster(item: dict) -> str:
        embedded = item.get("_embedded")
        if not isinstance(embedded, dict):
            return ""
        media_list = embedded.get("wp:featuredmedia")
        if not isinstance(media_list, list) or not media_list:
            return ""
        first = media_list[0]
        if not isinstance(first, dict):
            return ""
        src = ""
        sizes = (first.get("media_details") or {}).get("sizes") if isinstance(first.get("media_details"), dict) else None
        if isinstance(sizes, dict):
            for sz_key in ("medium_large", "large", "full", "jannah-image-large"):
                cand = sizes.get(sz_key)
                if isinstance(cand, dict) and cand.get("source_url"):
                    src = str(cand["source_url"]).strip()
                    break
        if not src:
            src = str(first.get("source_url") or "").strip()
        if not src and isinstance(sizes, dict):
            med = sizes.get("medium")
            if isinstance(med, dict) and med.get("source_url"):
                src = str(med["source_url"]).strip()
        if src.startswith("//"):
            return "https:" + src
        return src

    @staticmethod
    def _extract_poster_from_soup(node: bs4.Tag) -> str:
        for img in node.find_all("img"):
            src = (img.get("data-src") or img.get("data-lazy-src") or img.get("src") or "").strip()
            if not src or src.startswith("data:"):
                continue
            low = src.lower()
            if any(skip in low for skip in ("avatar", "emoji", "logo", "icon-")):
                continue
            if src.startswith("//"):
                return "https:" + src
            if src.startswith("/"):
                return STEAMRIP_BASE_URL + src
            return src
        return ""

    @staticmethod
    def _extract_metadata(content_node: bs4.Tag, version_note: str) -> tuple[str, str, list[str]]:
        raw_html = _LINE_BREAK_TAG_RE.sub("\n", str(content_node))
        text = bs4.BeautifulSoup(raw_html, "html.parser").get_text(" ")
        lines_text = "\n".join(" ".join(ln.split()) for ln in raw_html.splitlines())
        plain_lines = bs4.BeautifulSoup(lines_text, "html.parser").get_text("\n")

        genre_m = _GENRE_RE.search(plain_lines)
        size_m = _SIZE_RE.search(plain_lines)
        ver_m = _VERSION_RE.search(plain_lines)
        coop_m = _COOP_BY_RE.search(plain_lines)
        rel_m = _RELEASED_BY_RE.search(plain_lines)

        genres_str = genre_m.group(1).strip(" :-·") if genre_m else ""
        raw_genres = [g.strip() for g in re.split(r"[,/|]+", genres_str) if g.strip()]
        game_size = size_m.group(1).strip(" :-·") if size_m else ""
        ver_str = ver_m.group(1).strip(" :-·") if ver_m else version_note
        coop_by = coop_m.group(1).strip(" :-·") if coop_m else ""
        rel_by = rel_m.group(1).strip(" :-·") if rel_m else ""

        update_parts = []
        if ver_str:
            update_parts.append(ver_str)
        elif version_note:
            update_parts.append(version_note)
        if game_size:
            update_parts.append(f"Dung lượng: {game_size}")
        update_info = " · ".join(update_parts)

        mode_parts = []
        if genres_str:
            mode_parts.append(f"Thể loại: {genres_str}")
        if coop_by:
            mode_parts.append(f"Co-op / Online: {coop_by}")
        elif "co-op" in (version_note + " " + text[:400]).lower():
            mode_parts.append("Hỗ trợ Co-op / Multiplayer")
        if rel_by:
            mode_parts.append(f"Bản dựng: {rel_by}")
        if game_size and not ver_str:
            mode_parts.append(f"Dung lượng: {game_size}")
        return update_info, " · ".join(mode_parts), raw_genres

    @staticmethod
    def _detect_hoster_label(href: str, a_tag: bs4.Tag) -> str:
        host = urlparse(href).netloc.lower().removeprefix("www.")
        known = (
            (("gofile.io",), "Gofile"),
            (("bzzhr.to", "buzzheavier.com"), "Buzzheavier"),
            (("pixeldrain.com",), "PixelDrain"),
            (("fileditch", "itsfileditchfiles"), "FileDitch"),
            (("megadb.net",), "MegaDB"),
            (("1fichier.com",), "1fichier"),
            (("qiwi.gg",), "Qiwi"),
            (("datanodes.to",), "DataNodes"),
            (("filecrypt.",), "FileCrypt"),
            (("mega.nz",), "Mega.nz"),
            (("mediafire.com",), "MediaFire"),
        )
        for domains, label in known:
            if any(d in host for d in domains):
                return label

        parent = a_tag.parent
        if parent:
            strong = parent.find("strong")
            if strong:
                st = " ".join(strong.get_text(" ").split()).strip(" :-")
                if st and len(st) <= 28 and "download" not in st.lower():
                    return st.title()
        txt = " ".join(a_tag.get_text(" ").split()).strip()
        if txt and "download" not in txt.lower() and len(txt) <= 28:
            return txt
        return host or "Mirror"

    @classmethod
    def _extract_download_links(cls, content_node: bs4.Tag) -> List[dict]:
        """Extract direct aria2c-compatible hoster links (LINK_TORRENT) and browser mirrors (LINK_WEB)."""
        direct_links: List[dict] = []
        web_links: List[dict] = []
        seen_urls: set[str] = set()
        in_update_only = False

        for elem in content_node.descendants:
            if not isinstance(elem, bs4.Tag):
                continue
            if elem.name in ("p", "h2", "h3", "h4", "strong"):
                heading_txt = elem.get_text(" ").strip()
                if _UPDATE_ONLY_RE.search(heading_txt):
                    in_update_only = True
            if elem.name != "a":
                continue

            href = (elem.get("href") or "").strip()
            if not href:
                continue
            if href.startswith("//"):
                href = "https:" + href
            low = href.lower()
            if href in seen_urls:
                continue
            if any(ig in low for ig in _IGNORED_DOMAINS):
                continue
            if "steamrip.com" in low and not low.endswith(".torrent"):
                continue

            # Magnet / .torrent links
            if low.startswith("magnet:?"):
                seen_urls.add(href)
                if not in_update_only:
                    direct_links.append({"title": "Tải Torrent (Magnet)", "url": href, "kind": LINK_TORRENT})
                continue
            if low.endswith(".torrent"):
                seen_urls.add(href)
                if not in_update_only:
                    direct_links.append({"title": "Tải tệp .torrent", "url": href, "kind": LINK_TORRENT})
                continue

            if not low.startswith(("http://", "https://")):
                continue

            # Only pick actual download buttons / known file hosters
            classes = " ".join(elem.get("class") or []).lower()
            btn_text = " ".join(elem.get_text(" ").split()).strip().lower()
            host_label = cls._detect_hoster_label(href, elem)
            is_download_btn = (
                "shortc-button" in classes
                or "download" in btn_text
                or host_label in (
                    "Gofile", "Buzzheavier", "PixelDrain", "FileDitch",
                    "MegaDB", "1fichier", "Qiwi", "DataNodes", "FileCrypt", "Mega.nz", "MediaFire",
                )
            )
            if not is_download_btn:
                continue

            seen_urls.add(href)
            if in_update_only:
                web_links.append({
                    "title": f"{host_label} (Update Only)",
                    "url": href,
                    "kind": LINK_WEB,
                })
                continue

            if _GOFILE_ID_RE.search(href):
                direct_links.append({
                    "title": "Tải Trực Tiếp (Gofile High-Speed CDN)",
                    "url": f"steamrip-gofile:{href}",
                    "kind": LINK_TORRENT,
                })
                web_links.append({"title": "Gofile (Trình duyệt)", "url": href, "kind": LINK_WEB})
            elif _PIXELDRAIN_FILE_RE.search(href) or _PIXELDRAIN_LIST_RE.search(href):
                direct_links.append({
                    "title": "Tải Trực Tiếp (PixelDrain CDN)",
                    "url": f"steamrip-pixeldrain:{href}",
                    "kind": LINK_TORRENT,
                })
                web_links.append({"title": "PixelDrain (Trình duyệt)", "url": href, "kind": LINK_WEB})
            elif "bzzhr.to/" in low or "buzzheavier.com/" in low:
                direct_links.append({
                    "title": "Tải Trực Tiếp (Buzzheavier CDN)",
                    "url": f"steamrip-buzzheavier:{href}",
                    "kind": LINK_TORRENT,
                })
                web_links.append({"title": "Buzzheavier (Trình duyệt)", "url": href, "kind": LINK_WEB})
            else:
                web_links.append({"title": host_label, "url": href, "kind": LINK_WEB})

        # Order direct links: Gofile & PixelDrain & Torrent first, Buzzheavier after (since Buzzheavier may enable CF)
        direct_links.sort(key=lambda d: 1 if "buzzheavier" in d["url"] else 0)
        return direct_links + web_links

    # ------------------------------------------------------------ direct hoster resolution

    def resolve_torrent_download(self, url: str, referer: str = "") -> str:
        """Resolve a SteamRIP direct hoster or torrent source into an aria2-list payload or magnet/.torrent URL."""
        if url.startswith("steamrip-gofile:"):
            return self._resolve_gofile(url[len("steamrip-gofile:"):])
        if url.startswith("steamrip-pixeldrain:"):
            return self._resolve_pixeldrain(url[len("steamrip-pixeldrain:"):])
        if url.startswith("steamrip-buzzheavier:"):
            return self._resolve_buzzheavier(url[len("steamrip-buzzheavier:"):], referer=referer)
        return url

    def _gofile_guest_cache_path(self) -> str:
        return os.path.join(get_store_cache_dir(), "gofile_guest.json")

    def _get_or_create_gofile_token(self, force_refresh: bool = False) -> str:
        with self._gofile_lock:
            if self._gofile_token and not force_refresh:
                return self._gofile_token

            cache_path = self._gofile_guest_cache_path()
            if not force_refresh and os.path.isfile(cache_path):
                try:
                    with open(cache_path, "r", encoding="utf-8") as f:
                        saved = json.load(f)
                    tok = str(saved.get("token") or "").strip()
                    if tok:
                        self._gofile_token = tok
                        return tok
                except Exception:   # noqa: BLE001
                    pass

            started = time.monotonic()
            try:
                resp = self.session.post("https://api.gofile.io/accounts", timeout=15)
            except requests.RequestException as e:
                logger.warning(f"{TAG} Gofile guest account creation failed in {time.monotonic() - started:.1f}s: {e}")
                raise OnlineFixError(
                    "Không kết nối được tới máy chủ Gofile API (có thể bị nhà mạng chặn hoặc giới hạn tạm thời). "
                    "Hãy bật 'Mở chặn mạng' hoặc bấm nút Gofile (Trình duyệt) bên dưới."
                ) from e

            if resp.status_code != 200:
                logger.warning(f"{TAG} Gofile POST /accounts returned HTTP {resp.status_code}")
                raise OnlineFixError(
                    f"Máy chủ Gofile từ chối cấp phiên tải tạm thời (HTTP {resp.status_code}). "
                    "Vui lòng thử lại sau ít phút hoặc mở Gofile trên trình duyệt."
                )
            data = resp.json() if resp.content else {}
            tok = str((data.get("data") or {}).get("token") or "").strip()
            if data.get("status") != "ok" or not tok:
                raise OnlineFixError("Không lấy được phiên tải Gofile. Vui lòng dùng nút mở trình duyệt bên dưới.")

            self._gofile_token = tok
            try:
                os.makedirs(os.path.dirname(cache_path), exist_ok=True)
                with open(cache_path, "w", encoding="utf-8") as f:
                    json.dump({"token": tok, "saved_at": time.time()}, f)
            except OSError:
                pass
            return tok

    def _generate_gofile_wt(self, account_token: str) -> str:
        """Evaluate Gofile's live /js/wt.obf.js in PySide6.QtQml.QJSEngine so we never send a retired secret."""
        now = time.monotonic()
        with self._gofile_lock:
            wt_js = self._gofile_wt_js if (now - self._gofile_wt_fetched_at) < self.GOFILE_WT_TTL_SEC else ""

        if not wt_js:
            try:
                r_js = self.session.get("https://gofile.io/js/wt.obf.js", timeout=15)
                if r_js.status_code != 200 or "generateWT" not in r_js.text:
                    logger.warning(f"{TAG} Gofile wt.obf.js fetch returned HTTP {r_js.status_code}")
                    raise OnlineFixError("Không lấy được mã xác thực Gofile CDN. Hãy dùng nút mở trình duyệt.")
                wt_js = r_js.text
                with self._gofile_lock:
                    self._gofile_wt_js = wt_js
                    self._gofile_wt_fetched_at = time.monotonic()
            except requests.RequestException as e:
                logger.warning(f"{TAG} Gofile wt.obf.js request error: {e}")
                raise OnlineFixError("Không kết nối được tới Gofile CDN.") from e

        try:
            from PySide6.QtCore import QCoreApplication
            from PySide6.QtQml import QJSEngine

            if QCoreApplication.instance() is None:
                raise RuntimeError("QCoreApplication not initialized")

            lang = "en-US"
            engine = QJSEngine()
            shim = (
                "var window = this, self = this, top = this;\n"
                f"var navigator = {{ userAgent: {json.dumps(USER_AGENT)}, language: {json.dumps(lang)}, "
                f"languages: [{json.dumps(lang)}], webdriver: false }};\n"
                'var location = { hostname: "gofile.io", host: "gofile.io", origin: "https://gofile.io", '
                'href: "https://gofile.io/", protocol: "https:" };\n'
                'var document = { createElement: function() { return {}; }, cookie: "", referrer: "", '
                'currentScript: { src: "https://gofile.io/js/wt.obf.js" } };\n'
            )
            r1 = engine.evaluate(shim)
            r2 = engine.evaluate(wt_js)
            r3 = engine.evaluate(f"generateWT({json.dumps(account_token)})")
            wt = r3.toString().strip() if not (r1.isError() or r2.isError() or r3.isError()) else ""
        except Exception as e:   # noqa: BLE001
            logger.warning(f"{TAG} QJSEngine evaluation for Gofile WT failed: {e}")
            wt = ""

        if not wt or len(wt) < 16:
            raise OnlineFixError("Không tạo được khóa phiên Gofile. Vui lòng mở Gofile trên trình duyệt.")
        return wt

    def _resolve_gofile(self, share_url: str) -> str:
        started = time.monotonic()
        m = _GOFILE_ID_RE.search(share_url)
        if not m:
            raise OnlineFixError(f"Liên kết Gofile không hợp lệ: {share_url}")
        content_id = m.group(1)

        token = self._get_or_create_gofile_token(force_refresh=False)
        wt = self._generate_gofile_wt(token)

        api_url = (
            f"https://api.gofile.io/contents/{content_id}"
            "?page=1&pageSize=100&sortField=name&sortDirection=1"
        )
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Website-Token": wt,
            "X-BL": "en-US",
            "Origin": "https://gofile.io",
            "Referer": "https://gofile.io/",
        }
        try:
            resp = self.session.get(api_url, headers=headers, timeout=18)
            if resp.status_code == 401:
                token = self._get_or_create_gofile_token(force_refresh=True)
                wt = self._generate_gofile_wt(token)
                headers["Authorization"] = f"Bearer {token}"
                headers["X-Website-Token"] = wt
                resp = self.session.get(api_url, headers=headers, timeout=18)
        except requests.RequestException as e:
            logger.error(f"{TAG} Gofile contents error for {content_id}: {e}")
            raise OnlineFixError(f"Lỗi kết nối Gofile API: {e}") from e

        if resp.status_code != 200:
            logger.warning(f"{TAG} Gofile contents {content_id} returned HTTP {resp.status_code}")
            raise OnlineFixError(f"Gofile trả về HTTP {resp.status_code}. Hãy thử mở trên trình duyệt.")

        payload = resp.json() if resp.content else {}
        if payload.get("status") != "ok":
            status_str = payload.get("status", "unknown")
            logger.warning(f"{TAG} Gofile contents {content_id} refused with status={status_str!r}")
            raise OnlineFixError(
                f"Gofile từ chối truy cập tệp ({status_str}). Vui lòng tải qua nút Gofile (Trình duyệt)."
            )

        data_obj = payload.get("data") or {}
        candidates = []
        if isinstance(data_obj, dict):
            children = data_obj.get("children")
            if isinstance(children, dict) and children:
                candidates.extend(children.values())
            elif data_obj.get("type") == "file" or data_obj.get("link"):
                candidates.append(data_obj)

        items = []
        cookie_hdr = f"Cookie: accountToken={token}"
        for child in candidates:
            if not isinstance(child, dict) or child.get("type") == "folder":
                continue
            dl_link = str(child.get("link") or "").strip()
            fname = str(child.get("name") or "").strip()
            fsize = int(child.get("size") or 0)
            if dl_link:
                entry: dict = {
                    "url": dl_link,
                    "headers": [cookie_hdr, "Referer: https://gofile.io/"],
                }
                if fname:
                    entry["out"] = fname
                if fsize > 0:
                    entry["size"] = fsize
                items.append(entry)

        if not items:
            raise OnlineFixError("Thư mục Gofile không còn tệp tải (có thể liên kết đã hết hạn). Hãy chọn nguồn khác.")

        logger.info(
            f"{TAG} Resolved Gofile {content_id} -> {len(items)} file(s) in {time.monotonic() - started:.2f}s"
        )
        return "aria2-list:" + json.dumps(items, ensure_ascii=False)

    def _resolve_pixeldrain(self, share_url: str) -> str:
        started = time.monotonic()
        m_file = _PIXELDRAIN_FILE_RE.search(share_url)
        if m_file:
            fid = m_file.group(1)
            info_url = f"https://pixeldrain.com/api/file/{fid}/info"
            fname = ""
            fsize = 0
            try:
                r = self.session.get(info_url, timeout=12)
                if r.status_code == 200:
                    info = r.json()
                    fname = str(info.get("name") or "").strip()
                    fsize = int(info.get("size") or 0)
            except Exception:   # noqa: BLE001
                pass
            entry: dict = {"url": f"https://pixeldrain.com/api/file/{fid}?download"}
            if fname:
                entry["out"] = fname
            if fsize > 0:
                entry["size"] = fsize
            logger.info(f"{TAG} Resolved PixelDrain file {fid} in {time.monotonic() - started:.2f}s")
            return "aria2-list:" + json.dumps([entry], ensure_ascii=False)

        m_list = _PIXELDRAIN_LIST_RE.search(share_url)
        if m_list:
            lid = m_list.group(1)
            r = self._get(f"https://pixeldrain.com/api/list/{lid}", f"pixeldrain-list {lid}")
            files = (r.json() or {}).get("files") or []
            items = []
            for f in files:
                fid = f.get("id")
                if not fid:
                    continue
                entry = {"url": f"https://pixeldrain.com/api/file/{fid}?download"}
                if f.get("name"):
                    entry["out"] = str(f["name"])
                if f.get("size"):
                    entry["size"] = int(f["size"])
                items.append(entry)
            if items:
                logger.info(f"{TAG} Resolved PixelDrain list {lid} -> {len(items)} file(s) in {time.monotonic() - started:.2f}s")
                return "aria2-list:" + json.dumps(items, ensure_ascii=False)

        raise OnlineFixError("Không phân giải được liên kết PixelDrain.")

    @staticmethod
    def _pick_free_port() -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            return int(sock.getsockname()[1])

    @staticmethod
    def _spawn_deelevated_win32(args: list[str]):
        """
        Launch Chromium at Medium Integrity using explorer.exe's primary token when running as Admin (--uac-admin).
        Prevents Chromium/Edge from rejecting elevated runs or silently re-launching without --remote-debugging-port.
        """
        if sys.platform != "win32" or not args:
            return None
        try:
            import ctypes
            from ctypes import wintypes

            class _STARTUPINFOW(ctypes.Structure):
                _fields_ = [
                    ("cb", wintypes.DWORD),
                    ("lpReserved", wintypes.LPWSTR),
                    ("lpDesktop", wintypes.LPWSTR),
                    ("lpTitle", wintypes.LPWSTR),
                    ("dwX", wintypes.DWORD),
                    ("dwY", wintypes.DWORD),
                    ("dwXSize", wintypes.DWORD),
                    ("dwYSize", wintypes.DWORD),
                    ("dwXCountChars", wintypes.DWORD),
                    ("dwYCountChars", wintypes.DWORD),
                    ("dwFillAttribute", wintypes.DWORD),
                    ("dwFlags", wintypes.DWORD),
                    ("wShowWindow", wintypes.WORD),
                    ("cbReserved2", wintypes.WORD),
                    ("lpReserved2", ctypes.POINTER(ctypes.c_byte)),
                    ("hStdInput", wintypes.HANDLE),
                    ("hStdOutput", wintypes.HANDLE),
                    ("hStdError", wintypes.HANDLE),
                ]

            class _PROCESS_INFORMATION(ctypes.Structure):
                _fields_ = [
                    ("hProcess", wintypes.HANDLE),
                    ("hThread", wintypes.HANDLE),
                    ("dwProcessId", wintypes.DWORD),
                    ("dwThreadId", wintypes.DWORD),
                ]

            user32 = ctypes.WinDLL("user32", use_last_error=True)
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)

            user32.GetShellWindow.argtypes = []
            user32.GetShellWindow.restype = wintypes.HWND
            user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
            user32.GetWindowThreadProcessId.restype = wintypes.DWORD
            kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel32.OpenProcess.restype = wintypes.HANDLE
            kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel32.CloseHandle.restype = wintypes.BOOL
            kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            kernel32.GetExitCodeProcess.restype = wintypes.BOOL
            kernel32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
            kernel32.TerminateProcess.restype = wintypes.BOOL
            kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
            kernel32.WaitForSingleObject.restype = wintypes.DWORD
            advapi32.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
            advapi32.OpenProcessToken.restype = wintypes.BOOL
            advapi32.DuplicateTokenEx.argtypes = [
                wintypes.HANDLE, wintypes.DWORD, wintypes.LPVOID,
                ctypes.c_int, ctypes.c_int, ctypes.POINTER(wintypes.HANDLE),
            ]
            advapi32.DuplicateTokenEx.restype = wintypes.BOOL
            advapi32.CreateProcessWithTokenW.argtypes = [
                wintypes.HANDLE, wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPWSTR,
                wintypes.DWORD, wintypes.LPVOID, wintypes.LPCWSTR,
                ctypes.POINTER(_STARTUPINFOW), ctypes.POINTER(_PROCESS_INFORMATION),
            ]
            advapi32.CreateProcessWithTokenW.restype = wintypes.BOOL

            shell_hwnd = user32.GetShellWindow()
            if not shell_hwnd:
                return None
            shell_pid = wintypes.DWORD(0)
            user32.GetWindowThreadProcessId(shell_hwnd, ctypes.byref(shell_pid))
            if not shell_pid.value:
                return None

            h_proc = kernel32.OpenProcess(0x1000, False, shell_pid.value) or kernel32.OpenProcess(0x0400, False, shell_pid.value)
            if not h_proc:
                return None
            h_tok = wintypes.HANDLE()
            h_dup = wintypes.HANDLE()
            try:
                if not advapi32.OpenProcessToken(h_proc, 0x0002, ctypes.byref(h_tok)):
                    return None
                # MAXIMUM_ALLOWED=0x02000000, SecurityImpersonation=2, TokenPrimary=1
                if not advapi32.DuplicateTokenEx(h_tok, 0x02000000, None, 2, 1, ctypes.byref(h_dup)):
                    return None
                si = _STARTUPINFOW()
                si.cb = ctypes.sizeof(_STARTUPINFOW)
                si.dwFlags = 0x00000001  # STARTF_USESHOWWINDOW
                si.wShowWindow = 7       # SW_SHOWMINNOACTIVE
                pi = _PROCESS_INFORMATION()
                cmd_buf = ctypes.create_unicode_buffer(subprocess.list2cmdline(args))
                if not advapi32.CreateProcessWithTokenW(
                    h_dup, 0, args[0], cmd_buf, 0, None, None, ctypes.byref(si), ctypes.byref(pi)
                ):
                    logger.debug(f"{TAG} CreateProcessWithTokenW failed (winerr={ctypes.get_last_error()})")
                    return None
                if pi.hThread:
                    kernel32.CloseHandle(pi.hThread)

                class _Win32Proc:
                    def __init__(self, handle):
                        self._handle = handle

                    def poll(self):
                        if not self._handle:
                            return 0
                        code = wintypes.DWORD(0)
                        if not kernel32.GetExitCodeProcess(self._handle, ctypes.byref(code)):
                            return 0
                        return None if code.value == 259 else int(code.value)

                    def terminate(self):
                        if self._handle:
                            kernel32.TerminateProcess(self._handle, 1)

                    def kill(self):
                        self.terminate()

                    def wait(self, timeout=3.0):
                        if self._handle:
                            kernel32.WaitForSingleObject(self._handle, max(0, int(float(timeout or 0) * 1000)))
                            kernel32.CloseHandle(self._handle)
                            self._handle = None
                        return 0

                    def __del__(self):
                        if getattr(self, "_handle", None):
                            try:
                                kernel32.CloseHandle(self._handle)
                            except Exception:   # noqa: BLE001
                                pass
                            self._handle = None

                return _Win32Proc(pi.hProcess)
            finally:
                if h_dup:
                    kernel32.CloseHandle(h_dup)
                if h_tok:
                    kernel32.CloseHandle(h_tok)
                if h_proc:
                    kernel32.CloseHandle(h_proc)
        except Exception as e:   # noqa: BLE001
            logger.debug(f"{TAG} De-elevated Chromium launch unavailable: {e}")
            return None

    _FLATPAK_CHROMIUM_IDS: tuple[str, ...] = (
        "com.brave.Browser",
        "com.google.Chrome",
        "com.microsoft.Edge",
        "org.chromium.Chromium",
        "io.github.ungoogled_software.ungoogled_chromium",
        "com.vivaldi.Vivaldi",
    )
    _FLATPAK_FIREFOX_IDS: tuple[str, ...] = (
        "org.mozilla.firefox",
        "io.gitlab.librewolf-community",
        "one.ablaze.floorp",
        "app.zen_browser.zen",
    )

    @staticmethod
    def _find_flatpak_binary() -> str:
        fp = shutil.which("flatpak")
        if fp:
            return fp
        if sys.platform != "win32" and os.path.isfile("/usr/bin/flatpak"):
            return "/usr/bin/flatpak"
        return ""

    @staticmethod
    def _is_flatpak_app_installed(app_id: str) -> bool:
        home = os.path.expanduser("~")
        return any(
            os.path.exists(p)
            for p in (
                os.path.join(home, ".local", "share", "flatpak", "app", app_id),
                os.path.join("/var/lib/flatpak/app", app_id),
                os.path.join(home, ".local", "share", "flatpak", "exports", "bin", app_id),
                os.path.join("/var/lib/flatpak/exports/bin", app_id),
            )
        )

    @classmethod
    def _find_chromium_binaries(cls) -> list[str]:
        """Locate installed Chromium browsers (Windows + Linux/SteamOS native & Flatpak; disabled in pytest)."""
        if _is_test_env():
            return []
        found: list[str] = []
        seen: set[str] = set()
        if sys.platform == "win32":
            pf = os.environ.get("ProgramFiles", r"C:\Program Files")
            pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
            local_app = os.environ.get("LOCALAPPDATA", "")
            candidates = [
                os.path.join(pf, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
                os.path.join(pf86, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
                os.path.join(local_app, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
                os.path.join(pf, "Google", "Chrome", "Application", "chrome.exe"),
                os.path.join(pf86, "Google", "Chrome", "Application", "chrome.exe"),
                os.path.join(local_app, "Google", "Chrome", "Application", "chrome.exe"),
                os.path.join(pf86, "Microsoft", "Edge", "Application", "msedge.exe"),
                os.path.join(pf, "Microsoft", "Edge", "Application", "msedge.exe"),
            ]
            for path in candidates:
                if not path or not os.path.isfile(path):
                    continue
                norm = os.path.normcase(os.path.abspath(path))
                if norm not in seen:
                    seen.add(norm)
                    found.append(path)
            return found

        linux_cmds = (
            "brave-browser",
            "brave",
            "/opt/brave.com/brave/brave-browser",
            "google-chrome-stable",
            "google-chrome",
            "/opt/google/chrome/google-chrome",
            "microsoft-edge-stable",
            "microsoft-edge",
            "/opt/microsoft/msedge/microsoft-edge",
            "chromium",
            "chromium-browser",
            "/usr/bin/chromium",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/microsoft-edge-stable",
            "vivaldi-stable",
            "vivaldi",
        )
        for cand in linux_cmds:
            resolved = cand if os.path.isabs(cand) else (shutil.which(cand) or "")
            if not resolved or not os.path.isfile(resolved):
                continue
            if "flatpak/exports/bin" in resolved.replace("\\", "/"):
                continue
            real = os.path.realpath(resolved)
            if real not in seen:
                seen.add(real)
                found.append(resolved)

        if cls._find_flatpak_binary():
            for app_id in cls._FLATPAK_CHROMIUM_IDS:
                if cls._is_flatpak_app_installed(app_id):
                    spec = f"flatpak:{app_id}"
                    if spec not in seen:
                        seen.add(spec)
                        found.append(spec)
        return found

    @classmethod
    def _find_firefox_binaries(cls) -> list[str]:
        """Locate installed Firefox-family browsers for WebDriver BiDi fallback (Windows + Linux/SteamOS Flatpak & native)."""
        if _is_test_env():
            return []
        found: list[str] = []
        seen: set[str] = set()
        if sys.platform == "win32":
            pf = os.environ.get("ProgramFiles", r"C:\Program Files")
            pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
            local_app = os.environ.get("LOCALAPPDATA", "")
            for path in (
                os.path.join(pf, "Mozilla Firefox", "firefox.exe"),
                os.path.join(pf86, "Mozilla Firefox", "firefox.exe"),
                os.path.join(local_app, "Mozilla Firefox", "firefox.exe"),
            ):
                if path and os.path.isfile(path):
                    norm = os.path.normcase(os.path.abspath(path))
                    if norm not in seen:
                        seen.add(norm)
                        found.append(path)
            return found

        for cand in ("firefox", "firefox-esr", "librewolf", "/usr/bin/firefox", "/usr/lib/firefox/firefox"):
            resolved = cand if os.path.isabs(cand) else (shutil.which(cand) or "")
            if not resolved or not os.path.isfile(resolved):
                continue
            if "flatpak/exports/bin" in resolved.replace("\\", "/"):
                continue
            real = os.path.realpath(resolved)
            if real not in seen:
                seen.add(real)
                found.append(resolved)

        if cls._find_flatpak_binary():
            for app_id in cls._FLATPAK_FIREFOX_IDS:
                if cls._is_flatpak_app_installed(app_id):
                    spec = f"flatpak:{app_id}"
                    if spec not in seen:
                        seen.add(spec)
                        found.append(spec)
        return found

    @staticmethod
    def _browser_display_label(browser_spec: str) -> str:
        if (browser_spec or "").startswith("flatpak:"):
            return browser_spec.split(":", 1)[1]
        return os.path.basename(browser_spec or "browser")

    @staticmethod
    def _make_cdp_profile_dir(prefix: str) -> str:
        """Create an isolated browser profile folder in the app's scratch space (never %TEMP%); Flatpak browsers
        get it mounted with --filesystem=<dir>."""
        from app.config import make_app_temp_folder

        return make_app_temp_folder(prefix)

    @classmethod
    def _build_chromium_launch_cmd(
        cls,
        browser_spec: str,
        ud: str,
        port: int,
        win_size: str = "900,680",
    ) -> list[str]:
        flags = [
            f"--user-data-dir={ud}",
            f"--remote-debugging-port={port}",
            "--remote-allow-origins=*",
            "--do-not-de-elevate",
            "--no-first-run",
            "--no-default-browser-check",
            "--window-position=-32000,-32000",
            f"--window-size={win_size}",
            "--disable-background-timer-throttling",
            "--disable-renderer-backgrounding",
            "--disable-blink-features=AutomationControlled",
            "--mute-audio",
        ]
        if sys.platform != "win32":
            flags.extend(["--password-store=basic", "--use-mock-keychain"])
            if hasattr(os, "geteuid") and os.geteuid() == 0:
                flags.append("--no-sandbox")
        flags.append("about:blank")
        if browser_spec.startswith("flatpak:"):
            app_id = browser_spec.split(":", 1)[1]
            fp_bin = cls._find_flatpak_binary() or "flatpak"
            return [fp_bin, "run", "--share=network", f"--filesystem={ud}", app_id, *flags]
        return [browser_spec, *flags]

    @classmethod
    def _build_firefox_launch_cmd(cls, browser_spec: str, ud: str, port: int) -> list[str]:
        flags = [
            "--no-remote",
            "--new-instance",
            "--profile",
            ud,
            "--remote-debugging-port",
            str(port),
            "about:blank",
        ]
        if browser_spec.startswith("flatpak:"):
            app_id = browser_spec.split(":", 1)[1]
            fp_bin = cls._find_flatpak_binary() or "flatpak"
            return [fp_bin, "run", "--share=network", f"--filesystem={ud}", app_id, *flags]
        return [browser_spec, *flags]

    @staticmethod
    def _browser_subprocess_env() -> dict[str, str]:
        from app.core.online_fix.extractor import clean_subprocess_env

        env = clean_subprocess_env()
        if sys.platform != "win32":
            orig_ld = env.pop("LD_LIBRARY_PATH_ORIG", None)
            if orig_ld is not None:
                if orig_ld:
                    env["LD_LIBRARY_PATH"] = orig_ld
                else:
                    env.pop("LD_LIBRARY_PATH", None)
            if not env.get("XDG_RUNTIME_DIR") and hasattr(os, "getuid"):
                rt = f"/run/user/{os.getuid()}"
                if os.path.isdir(rt):
                    env["XDG_RUNTIME_DIR"] = rt
            if not env.get("DISPLAY") and not env.get("WAYLAND_DISPLAY"):
                env["DISPLAY"] = ":0"
        return env

    @classmethod
    def _spawn_browser_process(cls, cli_args: list[str]):
        popen_kwargs: dict = {
            "stdout": subprocess.DEVNULL,
            "stderr": subprocess.DEVNULL,
        }
        if sys.platform == "win32":
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = 7  # SW_SHOWMINNOACTIVE: minimized, never steals foreground focus
            popen_kwargs["startupinfo"] = si
        else:
            popen_kwargs["env"] = cls._browser_subprocess_env()
            popen_kwargs["start_new_session"] = True
        return subprocess.Popen(cli_args, **popen_kwargs)

    @staticmethod
    def _terminate_browser_process(proc) -> None:
        if proc is None:
            return
        if sys.platform != "win32" and isinstance(getattr(proc, "pid", None), int):
            try:
                import signal

                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except Exception:   # noqa: BLE001
                pass
        try:
            if not hasattr(proc, "poll") or proc.poll() is None:
                proc.terminate()
            proc.wait(timeout=3)
        except Exception:   # noqa: BLE001
            try:
                proc.kill()
            except Exception:   # noqa: BLE001
                pass

    @classmethod
    def _find_chromium_binary(cls) -> str:
        """Primary Chromium binary for silent CDP resolution (disabled in pytest)."""
        bins = cls._find_chromium_binaries()
        return bins[0] if bins else ""

    def _resolve_buzzheavier_via_cdp(self, clean_url: str, referer: str = "") -> Optional[dict]:
        """
        Resolve bzzhr.to / buzzheavier.com via a background minimized Chromium CDP session.
        SteamRIP's Buzzheavier files enforce BOTH Cloudflare Managed Challenge AND `Referer: https://steamrip.com/`;
        opening bzzhr.to without a SteamRIP Referer 302-redirects straight back to https://steamrip.com/.
        """
        first_bin = self._find_chromium_binary()
        if not first_bin:
            return None
        binaries = [first_bin] + [b for b in self._find_chromium_binaries() if b != first_bin]

        from app.core.online_fix.aria2_downloader import parse_size_to_bytes
        from app.core.steam_chat.cdp import CdpSession, CdpUnavailable, list_targets

        effective_ref = referer if (referer and "steamrip.com" in referer.lower()) else (STEAMRIP_BASE_URL + "/")
        use_deelevated = (
            sys.platform == "win32"
            and not _is_test_env()
            and getattr(subprocess.Popen, "__module__", "") == "subprocess"
            and is_admin()
        )
        launch_modes = (True, False) if use_deelevated else (False,)
        started = time.monotonic()

        with self._cdp_lock:
            for browser_bin in binaries:
                for deelevate in launch_modes:
                    ud = self._make_cdp_profile_dir("bob_sr_cdp_")
                    port = self._pick_free_port()
                    proc = None
                    sess: Optional[CdpSession] = None
                    label = self._browser_display_label(browser_bin)
                    try:
                        cli_args = self._build_chromium_launch_cmd(browser_bin, ud, port, win_size="800,600")
                        if deelevate:
                            proc = self._spawn_deelevated_win32(cli_args)
                            if proc is None:
                                continue
                        else:
                            proc = self._spawn_browser_process(cli_args)

                        ws_url = ""
                        max_polls = 40 if sys.platform == "win32" else 60
                        for _ in range(max_polls):
                            if hasattr(proc, "poll") and proc.poll() is not None:
                                break
                            try:
                                targets = list_targets(port=port, timeout=1.0)
                                ws_url = next(
                                    (
                                        t["webSocketDebuggerUrl"]
                                        for t in targets
                                        if t.get("type") == "page" and t.get("webSocketDebuggerUrl")
                                    ),
                                    "",
                                )
                                if ws_url:
                                    break
                            except CdpUnavailable:
                                pass
                            time.sleep(0.15 if sys.platform == "win32" else 0.2)

                        if not ws_url:
                            logger.warning(
                                f"{TAG} Buzzheavier CDP target unavailable via {label} "
                                f"(port={port}, deelevate={deelevate}) for {clean_url}"
                            )
                            continue

                        sess = CdpSession(ws_url, connect_timeout=4.0)
                        sess.call("Page.navigate", {"url": clean_url, "referrer": effective_ref}, timeout=10.0)
                        for _ in range(30):
                            time.sleep(0.4)
                            try:
                                state = sess.evaluate(
                                    "(() => {"
                                    "  if (document.querySelector('a[hx-get*=\"/download\"]')) return 'ready';"
                                    "  if ((location.hostname || '').includes('steamrip.com')) return 'redirected';"
                                    "  return '';"
                                    "})()",
                                    timeout=3.0,
                                    await_promise=False,
                                )
                            except Exception:   # noqa: BLE001
                                state = ""
                            if state in ("ready", "redirected"):
                                break

                        info = sess.evaluate(
                            "(async () => {"
                            "  const a = document.querySelector('a[hx-get*=\"/download\"]');"
                            "  if (!a) return {error: 'no-btn', href: location.href};"
                            "  const r = await fetch(location.origin + a.getAttribute('hx-get'), {"
                            "    headers: {'HX-Request': 'true', 'HX-Current-URL': location.href}"
                            "  });"
                            "  return {"
                            "    href: location.href || '',"
                            "    title: document.title || '',"
                            "    sizeText: (a.querySelector('.size') || {}).innerText || '',"
                            "    hxRedirect: r.headers.get('HX-Redirect') || '',"
                            "    ua: navigator.userAgent || ''"
                            "  };"
                            "})()",
                            timeout=10.0,
                            await_promise=True,
                        )
                        try:
                            sess.call("Browser.close", {}, timeout=1.5)
                        except Exception:   # noqa: BLE001
                            pass

                        if not isinstance(info, dict) or not info.get("hxRedirect"):
                            logger.warning(f"{TAG} Buzzheavier CDP could not find HX-Redirect on {clean_url}: {info}")
                            continue

                        raw_dl = str(info["hxRedirect"]).strip()
                        full_dl = raw_dl if raw_dl.startswith("http") else urljoin(clean_url + "/", raw_dl)
                        if "steamrip.com" in full_dl.lower():
                            continue

                        page_ref = str(info.get("href") or "").strip() or clean_url
                        headers = [f"Referer: {page_ref}"]
                        ua = str(info.get("ua") or "").strip()
                        if ua:
                            headers.append(f"User-Agent: {ua}")

                        entry: dict = {"url": full_dl, "headers": headers}
                        doc_title = str(info.get("title") or "").strip()
                        if doc_title and any(doc_title.lower().endswith(ext) for ext in (".rar", ".7z", ".zip", ".iso")):
                            entry["out"] = doc_title
                        sz = parse_size_to_bytes(str(info.get("sizeText") or ""))
                        if sz > 0:
                            entry["size"] = sz

                        logger.info(
                            f"{TAG} Resolved Buzzheavier CDN via CDP ({label}, "
                            f"deelevate={deelevate}) -> {entry.get('out') or 'stream'} in {time.monotonic() - started:.2f}s"
                        )
                        return entry
                    except Exception as e:   # noqa: BLE001
                        logger.warning(
                            f"{TAG} Buzzheavier CDP attempt ({label}, deelevate={deelevate}) "
                            f"failed after {time.monotonic() - started:.2f}s: {e}"
                        )
                    finally:
                        if sess is not None:
                            try:
                                sess.close()
                            except Exception:   # noqa: BLE001
                                pass
                        self._terminate_browser_process(proc)
                        shutil.rmtree(ud, ignore_errors=True)
        return None

    def _resolve_buzzheavier(self, share_url: str, referer: str = "") -> str:
        started = time.monotonic()
        clean_url = share_url.rstrip("/")
        dl_endpoint = f"{clean_url}/download"
        resp = None
        req_err: Optional[Exception] = None
        try:
            resp = self.session.get(
                dl_endpoint,
                headers={"HX-Request": "true", "HX-Current-URL": clean_url, "Referer": clean_url},
                allow_redirects=False,
                timeout=12,
            )
        except requests.RequestException as e:
            req_err = e
            logger.warning(f"{TAG} Buzzheavier probe failed in {time.monotonic() - started:.1f}s ({clean_url}): {e}")

        if resp is not None:
            hx_redirect = (resp.headers.get("hx-redirect") or resp.headers.get("Location") or "").strip()
            if hx_redirect and "steamrip.com" not in hx_redirect.lower():
                full_dl = hx_redirect if hx_redirect.startswith("http") else urljoin(clean_url + "/", hx_redirect)
                logger.info(f"{TAG} Resolved Buzzheavier direct link in {time.monotonic() - started:.2f}s")
                return "aria2-list:" + json.dumps(
                    [{"url": full_dl, "headers": [f"Referer: {clean_url}"]}],
                    ensure_ascii=False,
                )

        is_cf = resp is not None and (
            resp.status_code in (403, 503) or "cf-mitigated" in {k.lower() for k in resp.headers}
        )
        if is_cf:
            logger.warning(
                f"{TAG} Buzzheavier blocked by Cloudflare challenge (HTTP {resp.status_code}) on {clean_url}"
            )

        cdp_entry = self._resolve_buzzheavier_via_cdp(clean_url, referer=referer)
        if cdp_entry is not None:
            return "aria2-list:" + json.dumps([cdp_entry], ensure_ascii=False)

        if req_err is not None:
            raise OnlineFixError(f"Không kết nối được Buzzheavier: {req_err}") from req_err

        if is_cf:
            raise OnlineFixError(
                "Buzzheavier đang bật lớp chống bot Cloudflare. Vui lòng chọn nguồn Gofile ở trên "
                "hoặc bấm nút 'Mở trang game' rồi bấm tải Buzzheavier từ trang SteamRIP."
            )

        logger.warning(f"{TAG} Buzzheavier did not return hx-redirect (HTTP {resp.status_code}) on {clean_url}")
        raise OnlineFixError(
            "Không lấy được liên kết tải trực tiếp từ Buzzheavier. Hãy chọn nguồn Gofile hoặc bấm 'Mở trang game'."
        )

    def resolve_browser_download_url(self, url: str, referer: str = "") -> str:
        """
        Resolve a browser-mirror URL before opening it in the user's default browser.
        Direct navigation to SteamRIP's `bzzhr.to` / `buzzheavier.com` links without `Referer: https://steamrip.com/`
        is 302-redirected back to `https://steamrip.com/`. Resolving the signed `ts.bzzhr.to/d/...` stream URL
        lets the user's browser start the `.rar` file download immediately without redirecting to SteamRIP.
        """
        low = (url or "").lower()
        if "bzzhr.to/" not in low and "buzzheavier.com/" not in low:
            return url
        try:
            payload = self._resolve_buzzheavier(url, referer=referer)
            if payload.startswith("aria2-list:"):
                items = json.loads(payload[len("aria2-list:"):])
                if items and items[0].get("url"):
                    return str(items[0]["url"])
        except Exception as e:   # noqa: BLE001
            logger.warning(f"{TAG} Browser Buzzheavier direct-stream fallback to SteamRIP post ({url}): {e}")
        return referer if (referer and "steamrip.com" in referer.lower()) else url
