"""Central Qt-signal coordinator for Android Store downloads, Runtime provisioning, and Library sync."""

from __future__ import annotations

from dataclasses import replace
import json
import logging
import os
import shutil
import threading
import time
import uuid
import zipfile

from PySide6.QtCore import QObject, QThread, Signal
from PySide6.QtWidgets import QApplication

from app.config import load_config, save_config
from app.core.android.installer import AndroidPackageInstaller
from app.core.android.models import (
    ACTIVE_ANDROID_STATUSES,
    CATEGORY_GAMES,
    RUNTIME_PORTABLE_SDK,
    SOURCE_LOCAL,
    AndroidAbiMismatchError,
    AndroidApp,
    AndroidError,
    AndroidInstallTask,
    AndroidTaskStatus,
    RuntimeInfo,
    get_apps_dir,
    is_valid_android_root,
    resolve_android_root,
    sanitize_package_dir_name,
)
from app.core.android.runtime import ARM32_RUNTIME_ID, AndroidRuntimeManager, get_portable_profile
from app.core.android.store_client import AndroidStoreClient

logger = logging.getLogger(__name__)
TAG = "[Android/Manager]"

_workers: set[QThread] = set()
_workers_lock = threading.Lock()
_quit_hooked = False
_manager_instance: AndroidManager | None = None
_manager_lock = threading.Lock()


def _stop_all_workers_on_quit() -> None:
    with _workers_lock:
        active = list(_workers)
    for w in active:
        if hasattr(w, "cancel"):
            w.cancel()
    for w in active:
        if not w.wait(3000):
            logger.warning(f"{TAG} Worker {w.objectName()!r} still running at app exit")


class _AndroidWorkerThread(QThread):
    """Unparented tracked QThread so screen teardown never destroys a running thread."""

    done = Signal(object, str)

    def __init__(self, fn, name: str):
        super().__init__(None)
        self._fn = fn
        self._cancelled = False
        self.setObjectName(f"android-{name}")

    def cancel(self) -> None:
        self._cancelled = True

    def is_cancelled(self) -> bool:
        return self._cancelled

    def start_tracked(self) -> None:
        global _quit_hooked
        app = QApplication.instance()
        if app is not None and not _quit_hooked:
            app.aboutToQuit.connect(_stop_all_workers_on_quit)
            _quit_hooked = True
        with _workers_lock:
            _workers.add(self)
        self.finished.connect(self._forget)
        self.start()

    def _forget(self) -> None:
        with _workers_lock:
            _workers.discard(self)

    def run(self) -> None:
        result, err = None, ""
        try:
            result = self._fn(self.is_cancelled)
        except AndroidError as exc:
            err = str(exc) or exc.__class__.__name__
            logger.warning(f"{TAG} Worker {self.objectName()!r} reported error: {err}")
        except Exception as exc:  # noqa: BLE001
            logger.exception(f"{TAG} Unexpected crash in worker {self.objectName()!r}")
            err = f"Lỗi không mong muốn: {exc}"
        try:
            self.done.emit(result, err)
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Could not deliver signal for {self.objectName()!r}")


class AndroidManager(QObject):
    """Coordinates Android Store queue, runtime setup, local APK/XAPK install, and Library hooks."""

    task_updated = Signal(str)
    task_completed = Signal(str, dict)
    task_failed = Signal(str, str)
    runtime_progress = Signal(int, str)
    runtime_ready = Signal(object)
    runtime_launched = Signal(object)
    runtime_stopped = Signal()
    runtime_failed = Signal(str)
    app_launch_started = Signal(str, str)
    app_launch_finished = Signal(str, str, str)

    def __init__(self):
        super().__init__(None)
        self._lock = threading.RLock()
        self._tasks: dict[str, AndroidInstallTask] = {}
        self._task_workers: dict[str, _AndroidWorkerThread] = {}
        self._runtime_worker: _AndroidWorkerThread | None = None
        self._launching_packages: set[str] = set()
        self._launch_cancel_event = threading.Event()
        self.store = AndroidStoreClient()
        self.runtime_mgr = AndroidRuntimeManager()
        self.installer = AndroidPackageInstaller(self.runtime_mgr)

    # ------------------------------------------------------------------ Config & Paths

    def get_install_root(self) -> str:
        cfg = load_config()
        return resolve_android_root(
            str(cfg.get("android_install_root") or ""),
            str(cfg.get("online_fix_install_root") or ""),
        )

    def set_install_root(self, new_root: str) -> bool:
        if not is_valid_android_root(new_root):
            logger.warning(f"{TAG} Refused invalid Android install root: {new_root!r}")
            return False
        norm = os.path.normpath(new_root.strip())
        cfg = load_config()
        cfg["android_install_root"] = norm
        save_config(cfg)
        logger.info(f"{TAG} Updated android_install_root -> {norm}")
        return True

    def get_preferred_runtime_id(self) -> str:
        return str(load_config().get("android_preferred_runtime") or "").strip()

    def set_preferred_runtime_id(self, runtime_id: str) -> None:
        cfg = load_config()
        cfg["android_preferred_runtime"] = (runtime_id or "").strip()
        save_config(cfg)
        logger.info(f"{TAG} Selected preferred Android runtime: {runtime_id!r}")

    def get_active_runtime(self) -> RuntimeInfo:
        runtimes = self.runtime_mgr.discover_runtimes(self.get_install_root(), self.get_preferred_runtime_id())
        return runtimes[0]

    def list_runtimes(self) -> list[RuntimeInfo]:
        return self.runtime_mgr.discover_runtimes(self.get_install_root(), self.get_preferred_runtime_id())

    def find_runtime(self, runtime_id: str) -> RuntimeInfo | None:
        if not runtime_id:
            return None
        return next((r for r in self.list_runtimes() if r.runtime_id == runtime_id), None)

    def _ensure_runtime_provisioned(
        self,
        runtime: RuntimeInfo,
        android_root: str,
        progress_cb=None,
        is_cancelled=None,
    ) -> RuntimeInfo:
        """Download a managed runtime on first use; external runtimes must already be installed."""
        if runtime.installed:
            return runtime
        if runtime.kind != RUNTIME_PORTABLE_SDK:
            raise AndroidError(f"Runtime '{runtime.label}' chưa sẵn sàng.")
        return self.runtime_mgr.provision_portable_runtime(
            android_root, progress_cb=progress_cb, is_cancelled=is_cancelled, runtime_id=runtime.runtime_id
        )

    @staticmethod
    def runtime_supports_arm32(runtime: RuntimeInfo) -> bool:
        """Managed Android 14 is 64-bit only; external emulators decide for themselves (assume yes)."""
        if runtime.kind != RUNTIME_PORTABLE_SDK:
            return True
        return get_portable_profile(runtime.runtime_id).supports_arm32

    def _install_routed(self, runtime: RuntimeInfo, android_root: str, install_fn, progress_cb=None, is_cancelled=None):
        """Run `install_fn(runtime)`; a 32-bit-only ARM game is retried once on the Android 11 (ARM32) runtime.

        Returns `(install_fn result, runtime actually used)`.
        """
        try:
            return install_fn(runtime), runtime
        except AndroidAbiMismatchError as exc:
            if not exc.needs_arm32 or self.runtime_supports_arm32(runtime):
                raise
            legacy = self.find_runtime(ARM32_RUNTIME_ID)
            if legacy is None:
                raise
            logger.info(
                f"{TAG} {exc.app_title or 'Package'!r} ships only 32-bit ARM code "
                f"({', '.join(sorted(exc.package_abis)) or 'unknown ABI'}); installing into {legacy.label} "
                f"instead of {runtime.label}"
            )
            if progress_cb:
                progress_cb(72, f"Game chỉ có mã ARM 32-bit — chuyển sang {legacy.label}...")
            legacy = self._ensure_runtime_provisioned(legacy, android_root, progress_cb, is_cancelled)
            return install_fn(legacy), legacy

    # ------------------------------------------------------------------ Installed Apps Registry

    def list_installed_apps(self) -> dict[str, dict]:
        """Return {package_name: metadata_dict} for all Android apps installed under AndroidApps/."""
        apps_root = get_apps_dir(self.get_install_root())
        if not os.path.isdir(apps_root):
            return {}
        installed: dict[str, dict] = {}
        try:
            for entry in os.listdir(apps_root):
                if entry.startswith("_"):
                    continue
                sub = os.path.join(apps_root, entry)
                meta_p = os.path.join(sub, "android_app.json")
                if not os.path.isfile(meta_p):
                    continue
                try:
                    with open(meta_p, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                    pkg = str(meta.get("package_name") or "").strip()
                    if pkg:
                        meta["install_dir"] = sub
                        launcher = os.path.join(
                            sub, "launch_android.cmd" if os.name == "nt" else "launch_android.sh"
                        )
                        meta["launcher_path"] = launcher if os.path.isfile(launcher) else ""
                        installed[pkg] = meta
                except Exception:
                    continue
        except OSError:
            pass
        return installed

    # ------------------------------------------------------------------ Tasks Snapshot

    def get_task(self, task_id: str) -> AndroidInstallTask | None:
        with self._lock:
            t = self._tasks.get(task_id)
            return replace(t) if t else None

    def list_tasks(self) -> list[AndroidInstallTask]:
        with self._lock:
            return [replace(t) for t in self._tasks.values()]

    def has_active_task_for(self, package_name: str) -> bool:
        pkg_low = (package_name or "").strip().lower()
        with self._lock:
            return any(
                t.package_name.lower() == pkg_low and t.status in ACTIVE_ANDROID_STATUSES
                for t in self._tasks.values()
            )

    def cancel_task(self, task_id: str) -> None:
        with self._lock:
            worker = self._task_workers.get(task_id)
            task = self._tasks.get(task_id)
            if task and task.status in ACTIVE_ANDROID_STATUSES:
                task.status = AndroidTaskStatus.CANCELLED
                task.status_text = "Đã hủy"
        if worker:
            worker.cancel()
            logger.info(f"{TAG} Cancelled Android install task {task_id}")
        self.task_updated.emit(task_id)

    def _update_task(self, task_id: str, **changes) -> None:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return
            for k, v in changes.items():
                setattr(task, k, v)
        self.task_updated.emit(task_id)

    # ------------------------------------------------------------------ Async Runtime Provisioning

    def is_runtime_provisioning(self) -> bool:
        w = self._runtime_worker
        with self._lock:
            launching = bool(self._launching_packages)
        return bool((w is not None and w.isRunning()) or launching)

    def is_package_launching(self, package_name: str) -> bool:
        pkg_low = (package_name or "").strip().lower()
        with self._lock:
            return pkg_low in self._launching_packages

    def cancel_runtime_operation(self) -> None:
        self._launch_cancel_event.set()
        w = self._runtime_worker
        if w is not None and w.isRunning():
            w.cancel()
            logger.info(f"{TAG} Cancelled active Android runtime operation")

    def setup_portable_runtime_async(self, runtime_id: str = "") -> None:
        if self.is_runtime_provisioning():
            return
        root = self.get_install_root()
        logger.info(f"{TAG} User requested download of managed runtime {runtime_id or 'default'!r}")

        def _work(is_cancelled):
            return self.runtime_mgr.provision_portable_runtime(
                root,
                progress_cb=lambda pct, msg: self.runtime_progress.emit(pct, msg),
                is_cancelled=is_cancelled,
                runtime_id=runtime_id,
            )

        worker = _AndroidWorkerThread(_work, "provision-runtime")
        self._runtime_worker = worker

        def _finished(res, err: str):
            self._runtime_worker = None
            if err:
                self.runtime_failed.emit(err)
            else:
                self.runtime_ready.emit(res)

        worker.done.connect(_finished)
        worker.start_tracked()

    def boot_runtime_async(self, runtime: RuntimeInfo) -> None:
        if self.is_runtime_provisioning():
            return

        def _work(is_cancelled):
            return self.runtime_mgr.ensure_running(
                runtime,
                is_cancelled=is_cancelled,
                progress_cb=lambda pct, msg: self.runtime_progress.emit(pct, msg),
            )

        worker = _AndroidWorkerThread(_work, "boot-runtime")
        self._runtime_worker = worker

        def _finished(res, err: str):
            self._runtime_worker = None
            if err:
                self.runtime_failed.emit(err)
            else:
                self.runtime_ready.emit(res)

        worker.done.connect(_finished)
        worker.start_tracked()

    def stop_active_runtime_async(self) -> None:
        if self.is_runtime_provisioning():
            return

        def _work(_is_cancelled):
            # Stop whichever runtime is actually on screen: a 32-bit game may run on Android 11 while the
            # preferred runtime is Android 14.
            rts = self.list_runtimes()
            rt = next((r for r in rts if r.running and r.kind == RUNTIME_PORTABLE_SDK), None)
            rt = rt or next((r for r in rts if r.running), None) or rts[0]
            self.runtime_mgr.stop_runtime(rt)
            return rt

        worker = _AndroidWorkerThread(_work, "stop-runtime")
        self._runtime_worker = worker

        def _finished(_res, err: str):
            self._runtime_worker = None
            if err:
                self.runtime_failed.emit(err)
            else:
                self.runtime_stopped.emit()

        worker.done.connect(_finished)
        worker.start_tracked()

    # ------------------------------------------------------------------ Store & Local App Installation

    def start_store_install(self, app: AndroidApp) -> str:
        """Queue and start downloading + installing an AndroidApp from the store."""
        if self.has_active_task_for(app.package_name):
            raise AndroidError(f'"{app.name}" đang được tải và cài đặt.')

        task_id = uuid.uuid4().hex[:10]
        task = AndroidInstallTask(
            task_id=task_id,
            package_name=app.package_name,
            app_name=app.name,
            kind=app.kind or CATEGORY_GAMES,
            source=app.source,
            icon_url=app.poster_url,
            status=AndroidTaskStatus.QUEUED,
            progress=1,
            status_text="Đang chuẩn bị...",
        )
        with self._lock:
            self._tasks[task_id] = task
        self.task_updated.emit(task_id)

        android_root = self.get_install_root()
        logger.info(f"{TAG} Queued store install for {app.name!r} ({app.package_name}) -> root={android_root}")

        def _run(is_cancelled) -> dict:
            t0 = time.monotonic()
            runtime = self.get_active_runtime()
            if not runtime.installed:
                self._update_task(
                    task_id,
                    status=AndroidTaskStatus.PREPARING_RUNTIME,
                    status_text="Đang tải Android Runtime lần đầu...",
                )
                runtime = self._ensure_runtime_provisioned(
                    runtime,
                    android_root,
                    progress_cb=lambda pct, msg: self._update_task(
                        task_id, progress=max(2, int(pct * 0.35)), status_text=msg
                    ),
                    is_cancelled=is_cancelled,
                )

            base_pct = 35 if runtime.kind == RUNTIME_PORTABLE_SDK else 5
            self._update_task(
                task_id,
                status=AndroidTaskStatus.DOWNLOADING,
                progress=base_pct,
                status_text="Đang lấy link tải tốc độ cao...",
            )

            resolved_app, candidates = self.store.resolve_download_plan(app)
            self._update_task(task_id, package_name=resolved_app.package_name)

            app_pkg_dir = os.path.join(
                get_apps_dir(android_root),
                sanitize_package_dir_name(resolved_app.package_name),
            )
            staging_dir = os.path.join(app_pkg_dir, f"_staging_{task_id}")
            os.makedirs(staging_dir, exist_ok=True)

            try:
                installed_result: tuple[str, str, str] | None = None
                last_err = ""
                logged_milestones: set[int] = set()
                extra_obbs: list[tuple[str, str]] | None = None

                for cand_idx, (src_label, url) in enumerate(candidates):
                    if is_cancelled():
                        raise AndroidError("Đã hủy cài đặt.")
                    candidate_file = os.path.join(staging_dir, f"package_{cand_idx}_{src_label}.apk")

                    def _dl_prog(done_b: int, tot_b: int, spd: int, _src=src_label):
                        total_eff = tot_b or resolved_app.size_bytes or 0
                        frac = min(1.0, done_b / total_eff) if total_eff > 0 else 0.5
                        ui_pct = base_pct + int(frac * (70 - base_pct))
                        self._update_task(
                            task_id,
                            progress=ui_pct,
                            downloaded_bytes=done_b,
                            total_bytes=total_eff,
                            speed_bps=spd,
                            status_text=f"Đang tải {resolved_app.name} ({_src})...",
                        )
                        if total_eff > 0:
                            bucket = (int(frac * 100) // 25) * 25
                            if bucket in (25, 50, 75, 100) and bucket not in logged_milestones:
                                logged_milestones.add(bucket)
                                logger.info(f"{TAG} Download {resolved_app.package_name} milestone: {bucket}%")

                    try:
                        self._update_task(task_id, status=AndroidTaskStatus.DOWNLOADING)
                        self.installer.download_to_file(
                            url, candidate_file, progress_cb=_dl_prog, is_cancelled=is_cancelled
                        )
                        if not zipfile.is_zipfile(candidate_file):
                            raise AndroidError("Máy chủ trả về tệp không phải APK/XAPK")
                    except Exception as exc:
                        last_err = str(exc)
                        logger.warning(f"{TAG} Candidate {src_label} ({url}) failed: {exc}")
                        try:
                            if os.path.isfile(candidate_file):
                                os.remove(candidate_file)
                        except OSError:
                            pass
                        continue

                    extra_splits: list[str] = []
                    if src_label == "aptoide":
                        for idx, sp_url in enumerate(resolved_app.split_urls):
                            sp_dest = os.path.join(staging_dir, f"split_{idx}.apk")
                            self.installer.download_to_file(sp_url, sp_dest, is_cancelled=is_cancelled)
                            if zipfile.is_zipfile(sp_dest):
                                extra_splits.append(sp_dest)

                    if extra_obbs is None:
                        extra_obbs = []
                        for obb_name, obb_url in resolved_app.obb_urls.items():
                            obb_dest = os.path.join(staging_dir, obb_name)
                            self.installer.download_to_file(obb_url, obb_dest, is_cancelled=is_cancelled)
                            extra_obbs.append((obb_dest, obb_name))

                    self._update_task(
                        task_id,
                        status=AndroidTaskStatus.INSTALLING,
                        progress=72,
                        status_text="Đang cài đặt vào Android Runtime...",
                    )
                    def _install_into(rt: RuntimeInfo, _archive=candidate_file, _splits=extra_splits):
                        return self.installer.install_archive_into_runtime(
                            archive_path=_archive,
                            runtime=rt,
                            app=resolved_app,
                            android_root=android_root,
                            extra_split_files=_splits,
                            extra_obb_files=extra_obbs,
                            progress_cb=lambda p, msg: self._update_task(task_id, progress=p, status_text=msg),
                            is_cancelled=is_cancelled,
                        )

                    try:
                        installed_result, runtime = self._install_routed(
                            runtime,
                            android_root,
                            _install_into,
                            progress_cb=lambda p, msg: self._update_task(task_id, progress=p, status_text=msg),
                            is_cancelled=is_cancelled,
                        )
                        break
                    except AndroidError as exc:
                        last_err = str(exc)
                        try:
                            if os.path.isfile(candidate_file):
                                os.remove(candidate_file)
                        except OSError:
                            pass
                        if (
                            (
                                "INSTALL_FAILED_NO_MATCHING_ABIS" in last_err
                                or "Đã chặn gói cài đặt nghi ngờ giả mạo" in last_err
                            )
                            and cand_idx + 1 < len(candidates)
                        ):
                            logger.warning(
                                f"{TAG} Candidate {src_label} rejected for {resolved_app.package_name} ({last_err}); "
                                "trying next store CDN candidate"
                            )
                            continue
                        raise

                if installed_result is None:
                    raise AndroidError(f"Mọi nguồn tải đều thất bại: {last_err}")
                pkg, app_dir, launcher_path = installed_result
            finally:
                shutil.rmtree(staging_dir, ignore_errors=True)
                try:
                    if os.path.isdir(app_pkg_dir):
                        for entry in os.listdir(app_pkg_dir):
                            if entry.startswith("_staging"):
                                shutil.rmtree(os.path.join(app_pkg_dir, entry), ignore_errors=True)
                        if not os.listdir(app_pkg_dir):
                            os.rmdir(app_pkg_dir)
                except OSError:
                    pass

            logger.info(
                f"{TAG} Store install finished for {resolved_app.name!r} ({pkg}) in {time.monotonic() - t0:.2f}s"
            )
            return {
                "name": resolved_app.name,
                "package_name": pkg,
                "exe_path": launcher_path,
                "install_location": app_dir,
                "poster_url": resolved_app.poster_url,
                "kind": resolved_app.kind,
                "source": "android",
            }

        self._spawn_task_worker(task_id, _run)
        return task_id

    def start_local_file_install(self, file_path: str) -> str:
        """Install a user-selected local .apk / .xapk / .apks file."""
        if not file_path or not os.path.isfile(file_path):
            raise AndroidError("Tệp APK/XAPK đã chọn không tồn tại.")

        title = os.path.splitext(os.path.basename(file_path))[0]
        task_id = uuid.uuid4().hex[:10]
        task = AndroidInstallTask(
            task_id=task_id,
            package_name=f"local.{sanitize_package_dir_name(title).lower()}",
            app_name=title,
            kind=CATEGORY_GAMES,
            source=SOURCE_LOCAL,
            status=AndroidTaskStatus.INSTALLING,
            progress=10,
            status_text="Đang chuẩn bị cài tệp cục bộ...",
        )
        with self._lock:
            self._tasks[task_id] = task
        self.task_updated.emit(task_id)

        android_root = self.get_install_root()
        logger.info(f"{TAG} Starting local package install from {file_path}")

        def _run(is_cancelled) -> dict:
            runtime = self.get_active_runtime()
            if not runtime.installed:
                self._update_task(
                    task_id,
                    status=AndroidTaskStatus.PREPARING_RUNTIME,
                    status_text="Đang tải Android Runtime lần đầu...",
                )
                runtime = self._ensure_runtime_provisioned(
                    runtime,
                    android_root,
                    progress_cb=lambda pct, msg: self._update_task(
                        task_id, progress=max(5, int(pct * 0.65)), status_text=msg
                    ),
                    is_cancelled=is_cancelled,
                )

            local_app = AndroidApp(package_name="", name=title, kind=CATEGORY_GAMES, source=SOURCE_LOCAL)
            (pkg, app_dir, launcher_path), runtime = self._install_routed(
                runtime,
                android_root,
                lambda rt: self.installer.install_archive_into_runtime(
                    archive_path=file_path,
                    runtime=rt,
                    app=local_app,
                    android_root=android_root,
                    progress_cb=lambda p, msg: self._update_task(task_id, progress=p, status_text=msg),
                    is_cancelled=is_cancelled,
                ),
                progress_cb=lambda p, msg: self._update_task(task_id, progress=p, status_text=msg),
                is_cancelled=is_cancelled,
            )
            # Re-read actual app name if manifest.json provided a cleaner title
            meta_p = os.path.join(app_dir, "android_app.json")
            final_name = title
            if os.path.isfile(meta_p):
                try:
                    with open(meta_p, "r", encoding="utf-8") as f:
                        final_name = str(json.load(f).get("name") or title)
                except Exception:
                    pass
            return {
                "name": final_name,
                "package_name": pkg,
                "exe_path": launcher_path,
                "install_location": app_dir,
                "poster_url": "",
                "kind": CATEGORY_GAMES,
                "source": "android",
            }

        self._spawn_task_worker(task_id, _run)
        return task_id

    def _spawn_task_worker(self, task_id: str, fn) -> None:
        worker = _AndroidWorkerThread(fn, f"install-{task_id}")
        with self._lock:
            self._task_workers[task_id] = worker

        def _on_done(payload, err: str):
            with self._lock:
                self._task_workers.pop(task_id, None)
                cur = self._tasks.get(task_id)
                was_cancelled = bool(cur and cur.status == AndroidTaskStatus.CANCELLED)

            if was_cancelled:
                return
            if err or not isinstance(payload, dict):
                msg = err or "Cài đặt ứng dụng Android thất bại."
                self._update_task(
                    task_id,
                    status=AndroidTaskStatus.FAILED,
                    error_message=msg,
                    status_text=msg,
                )
                self.task_failed.emit(task_id, msg)
                return

            self._update_task(
                task_id,
                package_name=payload["package_name"],
                app_name=payload["name"],
                status=AndroidTaskStatus.COMPLETED,
                progress=100,
                install_dir=payload["install_location"],
                launcher_path=payload["exe_path"],
                status_text="Đã cài đặt",
            )
            self.task_completed.emit(task_id, payload)

        worker.done.connect(_on_done)
        worker.start_tracked()

    # ------------------------------------------------------------------ Synchronous Worker Helpers (called off-UI-thread)

    def _reinstall_missing_package(self, ready: RuntimeInfo, package_name: str, android_root: str) -> RuntimeInfo:
        """Auto-reinstall a Library Android app (including splits & OBBs) if missing or incomplete.

        Returns the runtime the app ended up in (Android 11 when the package is 32-bit ARM only).
        """
        app_dir = os.path.join(get_apps_dir(android_root), sanitize_package_dir_name(package_name))
        meta_p = os.path.join(app_dir, "android_app.json")
        meta: dict = {}
        if os.path.isfile(meta_p):
            try:
                with open(meta_p, "r", encoding="utf-8") as f:
                    meta = json.load(f)
            except Exception:
                meta = {}
        app_obj = AndroidApp(
            package_name=package_name,
            name=str(meta.get("name") or package_name),
            kind=str(meta.get("kind") or CATEGORY_GAMES),
            icon_url=str(meta.get("icon_url") or ""),
        )
        resolved_app, candidates = self.store.resolve_download_plan(app_obj)
        staging_dir = os.path.join(app_dir, "_staging_reinstall")
        os.makedirs(staging_dir, exist_ok=True)
        try:
            extra_obbs: list[tuple[str, str]] | None = None
            last_err = ""
            for idx, (src_label, url) in enumerate(candidates):
                dest = os.path.join(staging_dir, f"reinstall_{idx}_{src_label}.apk")
                try:
                    self.installer.download_to_file(url, dest)
                    if not zipfile.is_zipfile(dest):
                        continue
                    extra_splits: list[str] = []
                    if src_label == "aptoide":
                        for sp_idx, sp_url in enumerate(resolved_app.split_urls):
                            sp_dest = os.path.join(staging_dir, f"split_{sp_idx}.apk")
                            self.installer.download_to_file(sp_url, sp_dest)
                            if zipfile.is_zipfile(sp_dest):
                                extra_splits.append(sp_dest)
                    if extra_obbs is None:
                        extra_obbs = []
                        for obb_name, obb_url in resolved_app.obb_urls.items():
                            obb_dest = os.path.join(staging_dir, obb_name)
                            self.installer.download_to_file(obb_url, obb_dest)
                            extra_obbs.append((obb_dest, obb_name))
                    _res, used = self._install_routed(
                        ready,
                        android_root,
                        lambda rt, _archive=dest, _splits=extra_splits: self.installer.install_archive_into_runtime(
                            archive_path=_archive,
                            runtime=rt,
                            app=resolved_app,
                            android_root=android_root,
                            extra_split_files=_splits,
                            extra_obb_files=extra_obbs,
                        ),
                    )
                    logger.info(f"{TAG} Auto-reinstalled {package_name} into {used.label}")
                    return used
                except Exception as exc:
                    last_err = str(exc)
            raise AndroidError(last_err or f"Không thể tự cài lại {package_name} vào {ready.label}.")
        finally:
            shutil.rmtree(staging_dir, ignore_errors=True)

    def _read_app_meta(self, package_name: str) -> dict:
        meta_p = os.path.join(
            get_apps_dir(self.get_install_root()), sanitize_package_dir_name(package_name), "android_app.json"
        )
        if not os.path.isfile(meta_p):
            return {}
        try:
            with open(meta_p, "r", encoding="utf-8") as f:
                doc = json.load(f)
            return doc if isinstance(doc, dict) else {}
        except Exception as exc:  # noqa: BLE001
            logger.warning(f"{TAG} Could not read Android app metadata {meta_p}: {exc}")
            return {}

    def runtime_for_app(self, package_name: str) -> RuntimeInfo:
        """The runtime an installed app lives in (from its metadata), else the user's preferred runtime."""
        rt_id = str(self._read_app_meta(package_name).get("runtime_id") or "")
        rt = self.find_runtime(rt_id)
        if rt is not None:
            return rt
        return self.get_active_runtime()

    def launch_installed_app(self, package_name: str, app_name: str = "") -> None:
        android_root = self.get_install_root()
        app_dir = os.path.join(get_apps_dir(android_root), sanitize_package_dir_name(package_name))
        meta_p = os.path.join(app_dir, "android_app.json")
        expected_obbs: list[str] = []
        title = (app_name or "").strip()
        if os.path.isfile(meta_p):
            try:
                with open(meta_p, "r", encoding="utf-8") as f:
                    meta_doc = json.load(f)
                    raw_obbs = meta_doc.get("obb_files")
                    if isinstance(raw_obbs, list):
                        expected_obbs = [str(x) for x in raw_obbs if x]
                    if not title:
                        title = str(meta_doc.get("name") or "").strip()
            except Exception:
                expected_obbs = []
        title = title or package_name
        pkg_low = (package_name or "").strip().lower()
        with self._lock:
            if not self._launching_packages:
                self._launch_cancel_event.clear()
            self._launching_packages.add(pkg_low)

        is_cancelled = self._launch_cancel_event.is_set

        def prog_cb(pct: int, msg: str) -> None:
            self.runtime_progress.emit(int(pct), str(msg))
        self.app_launch_started.emit(package_name, title)
        prog_cb(8, f'Đang chuẩn bị khởi động máy ảo Android cho "{title}"...')
        err_out = ""
        try:
            runtime = self.runtime_for_app(package_name)
            logger.info(f"{TAG} Launching {package_name} on {runtime.label}")
            if not runtime.installed:
                if runtime.kind != RUNTIME_PORTABLE_SDK:
                    raise AndroidError(
                        "Android Runtime chưa được cài đặt. Hãy mở mục Kho Game Android để tải Runtime trước."
                    )
                try:
                    runtime = self.runtime_mgr.provision_portable_runtime(
                        android_root, progress_cb=prog_cb, is_cancelled=is_cancelled, runtime_id=runtime.runtime_id
                    )
                except TypeError:
                    runtime = self.runtime_mgr.provision_portable_runtime(android_root)
            try:
                ready = self.runtime_mgr.ensure_running(runtime, is_cancelled=is_cancelled, progress_cb=prog_cb)
            except TypeError:
                ready = self.runtime_mgr.ensure_running(runtime)
            self.runtime_launched.emit(ready)
            pkg_ok = self.runtime_mgr.is_package_installed(ready, package_name)
            obb_ok = self.runtime_mgr.has_obb_files(ready, package_name, expected_obbs) if pkg_ok else False
            if not pkg_ok or not obb_ok:
                logger.info(
                    f"{TAG} Package {package_name} incomplete on {ready.label} (pkg_ok={pkg_ok}, obb_ok={obb_ok}); "
                    "auto-reinstalling..."
                )
                prog_cb(90, f'Đang đồng bộ dữ liệu "{title}" vào máy ảo Android...')
                used = self._reinstall_missing_package(ready, package_name, android_root)
                if isinstance(used, RuntimeInfo) and used.runtime_id != ready.runtime_id:
                    ready = self.runtime_mgr.ensure_running(used, is_cancelled=is_cancelled, progress_cb=prog_cb)
            prog_cb(97, f'Đang mở "{title}" trên màn hình Android...')
            self.runtime_mgr.launch_package(ready, package_name)
            self.runtime_launched.emit(ready)
        except Exception as exc:
            err_out = str(exc) or exc.__class__.__name__
            raise
        finally:
            with self._lock:
                self._launching_packages.discard(pkg_low)
            self.app_launch_finished.emit(package_name, title, err_out)

    def uninstall_installed_app(self, package_name: str, install_dir: str = "") -> None:
        runtime = self.runtime_for_app(package_name)
        if runtime.installed:
            try:
                self.runtime_mgr.uninstall_package(runtime, package_name)
            except Exception as exc:
                logger.warning(f"{TAG} Runtime uninstall warning for {package_name}: {exc}")

        target_dir = install_dir
        if not target_dir and package_name:
            target_dir = os.path.join(get_apps_dir(self.get_install_root()), sanitize_package_dir_name(package_name))
        if target_dir and os.path.isdir(target_dir) and is_valid_android_root(os.path.dirname(os.path.dirname(target_dir))):
            shutil.rmtree(target_dir, ignore_errors=True)
            logger.info(f"{TAG} Removed Android app wrapper directory: {target_dir}")

    def shutdown(self) -> None:
        """Cancel any active runtime boot and cleanly stop Bob-spawned Android Emulator instances."""
        self.cancel_runtime_operation()
        self.runtime_mgr.shutdown_spawned_runtimes()


def get_android_manager() -> AndroidManager:
    global _manager_instance
    with _manager_lock:
        if _manager_instance is None:
            _manager_instance = AndroidManager()
        return _manager_instance
