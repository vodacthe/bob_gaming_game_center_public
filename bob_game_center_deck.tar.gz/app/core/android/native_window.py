"""Zero-copy Android display: embeds the emulator's own GPU window into Bob Gaming (Windows).

The scrcpy path encodes every frame with a software H.264 encoder inside the guest and decodes it again on the
host, which tops out well below 120 FPS. The emulator already presents each guest frame straight from the host
GPU in its own window, so re-parenting that window into Bob Gaming shows the display at the guest's real refresh
rate with native mouse / keyboard input and no encode or decode at all.

The emulator window becomes a borderless popup *owned* by the player's top-level window and is laid over a
plain placeholder widget (`set_area`). Owned windows stay directly above their owner, hide / minimise with it
and stay off the taskbar. Two things that look simpler do not work in Bob Gaming's frameless translucent
(layered) main window:

* a child window: the layered window is composed from Qt's own bitmap, so a GPU-rendered child is never shown
  on screen (PrintWindow still captures it, which hides the problem in screenshots);
* a native Qt placeholder (`WA_NativeWindow` / `winId()` on a child widget): Qt makes its ancestors and
  siblings native too, and whole screens then paint twice at stale positions.

`EmulatorWindowEmbedder` owns the Win32 side (UI thread only). `GuestDisplayMonitor` owns the adb side on a
worker thread: measured FPS, key events, and keeping the emulated device's physical rotation in step with the
orientation the foreground game asked for (the emulator window only follows the *physical* rotation, so a game
that forces landscape would otherwise be drawn sideways).
"""

from __future__ import annotations

from collections import deque
import ctypes
import logging
import os
import re
import sys
import threading
import time

from PySide6.QtCore import QObject, Signal

from app.core.android.models import RuntimeInfo
from app.core.android.runtime import AndroidRuntimeManager, native_embed_enabled

logger = logging.getLogger(__name__)
TAG = "[Android/NativeWin]"

_GWL_STYLE = -16
_GWLP_HWNDPARENT = -8  # on a top-level window: its owner
_WS_CHILD = 0x40000000
_WS_VISIBLE = 0x10000000
_WS_POPUP = 0x80000000
_WS_CAPTION = 0x00C00000
_WS_THICKFRAME = 0x00040000
_WS_SYSMENU = 0x00080000
_WS_MINIMIZEBOX = 0x00020000
_WS_MAXIMIZEBOX = 0x00010000
_SWP_NOSIZE = 0x0001
_SWP_NOZORDER = 0x0004
_SWP_NOACTIVATE = 0x0010
_SWP_FRAMECHANGED = 0x0020
_SWP_SHOWWINDOW = 0x0040
# RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW
_RDW_REPAINT_ALL = 0x0001 | 0x0004 | 0x0400 | 0x0080 | 0x0100
_SW_HIDE = 0
_SW_SHOW = 5

_MAIN_CLASS_MARK = "QWindowIcon"
_TOOL_CLASS_MARK = "QWindowTool"
_MAIN_TITLE_PREFIX = "Android Emulator - "
_GEOMETRY_TOLERANCE_PX = 3
_DEFAULT_ASPECT = 720.0 / 1280.0

MONITOR_POLL_SECONDS = 2.0
_MAX_ROTATE_STEPS = 3
# Display rotation (Surface.ROTATION_*) -> the accelerometer axis that must read +g / -g for the emulator
# window to show that rotation upright: (axis index, sign).
_ROTATION_TO_GRAVITY: dict[int, tuple[int, int]] = {0: (1, 1), 1: (0, 1), 2: (1, -1), 3: (0, -1)}


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def fit_rect(host_w: int, host_h: int, aspect: float) -> tuple[int, int, int, int]:
    """Return the centred `(x, y, w, h)` of the largest `aspect` (= width / height) box inside the host area."""
    hw = max(1, int(host_w))
    hh = max(1, int(host_h))
    asp = aspect if aspect > 0 else _DEFAULT_ASPECT
    w = hw
    h = int(round(w / asp))
    if h > hh:
        h = hh
        w = int(round(h * asp))
    w = max(1, min(hw, w))
    h = max(1, min(hh, h))
    return (hw - w) // 2, (hh - h) // 2, w, h


def gravity_matches_rotation(rotation: int, accel: tuple[float, float, float]) -> bool:
    """True when the emulated device is physically held the way display `rotation` needs to look upright."""
    axis, sign = _ROTATION_TO_GRAVITY.get(int(rotation) % 4, (1, 1))
    dominant = max(range(2), key=lambda i: abs(accel[i]))
    return dominant == axis and (accel[axis] > 0) == (sign > 0)


def parse_acceleration(text: str) -> tuple[float, float, float] | None:
    """Parse `adb emu sensor get acceleration` output (`acceleration = x:y:z`)."""
    m = re.search(r"acceleration\s*=\s*([-+0-9.eE]+):([-+0-9.eE]+):([-+0-9.eE]+)", text or "")
    if not m:
        return None
    try:
        return float(m.group(1)), float(m.group(2)), float(m.group(3))
    except ValueError:
        return None


def parse_display_state(text: str) -> tuple[int, int, int] | None:
    """Parse `(logical_w, logical_h, rotation)` out of a `dumpsys window displays` excerpt."""
    cur = re.search(r"cur=(\d+)x(\d+)", text or "")
    rot = re.search(r"mRotation=(\d)", text or "")
    if not cur or not rot:
        return None
    return int(cur.group(1)), int(cur.group(2)), int(rot.group(1))


class EmulatorWindowEmbedder:
    """Finds the emulator's Qt window and re-parents it into a host HWND. Call from the UI thread only."""

    def __init__(self) -> None:
        self._main_hwnd = 0
        self._orig_style = 0
        self._tool_hwnds: list[int] = []
        self._parent_hwnd = 0
        self._aspect = _DEFAULT_ASPECT
        self._last_target: tuple[int, int, int, int] | None = None
        # Placeholder rect in the parent's client pixels, and whether the placeholder is on screen.
        self._area: tuple[int, int, int, int] | None = None
        self._area_visible = False
        self._user32 = None
        if sys.platform == "win32":
            try:
                u = ctypes.windll.user32
                u.SetParent.restype = ctypes.c_void_p
                u.SetParent.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
                u.GetWindowLongPtrW.restype = ctypes.c_ssize_t
                u.GetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int]
                u.SetWindowLongPtrW.restype = ctypes.c_ssize_t
                u.SetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t]
                u.SetWindowPos.argtypes = [
                    ctypes.c_void_p,
                    ctypes.c_void_p,
                    ctypes.c_int,
                    ctypes.c_int,
                    ctypes.c_int,
                    ctypes.c_int,
                    ctypes.c_uint,
                ]
                u.IsWindow.argtypes = [ctypes.c_void_p]
                u.IsWindowVisible.argtypes = [ctypes.c_void_p]
                u.ShowWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
                u.GetWindowRect.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
                u.GetClientRect.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
                u.GetParent.restype = ctypes.c_void_p
                u.GetParent.argtypes = [ctypes.c_void_p]
                u.SetForegroundWindow.argtypes = [ctypes.c_void_p]
                u.RedrawWindow.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint]
                u.MapWindowPoints.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint]
                u.ClientToScreen.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
                self._user32 = u
            except Exception as exc:  # noqa: BLE001
                logger.warning(f"{TAG} Win32 window API unavailable, native display disabled: {exc}")

    # ------------------------------------------------------------------ State

    @property
    def supported(self) -> bool:
        return self._user32 is not None and native_embed_enabled()

    @property
    def is_embedded(self) -> bool:
        return bool(self._main_hwnd and self._parent_hwnd)

    @property
    def parent_hwnd(self) -> int:
        return self._parent_hwnd

    def set_area(self, x: int, y: int, w: int, h: int, visible: bool) -> None:
        """Where the display belongs inside the parent window (client pixels), and whether it should show."""
        self._area = (int(x), int(y), int(w), int(h))
        self._area_visible = bool(visible) and w >= 8 and h >= 8

    @property
    def has_window(self) -> bool:
        return bool(self._main_hwnd)

    def is_alive(self) -> bool:
        return bool(self._user32 and self._main_hwnd and self._user32.IsWindow(self._main_hwnd))

    def is_landscape(self) -> bool:
        return self._aspect > 1.0

    # ------------------------------------------------------------------ Discovery

    def _enum_emulator_windows(self, avd_name: str) -> tuple[int, int, list[int]]:
        """Return `(main_hwnd, owner_pid, tool_hwnds)` for the running emulator of `avd_name`."""
        u = self._user32
        if u is None:
            return 0, 0, []
        wanted = f"{_MAIN_TITLE_PREFIX}{avd_name}:" if avd_name else _MAIN_TITLE_PREFIX
        tops: list[tuple[int, int, str, str]] = []
        enum_proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

        def _cb(hwnd, _lparam):
            cbuf = ctypes.create_unicode_buffer(96)
            u.GetClassNameW(ctypes.c_void_p(hwnd), cbuf, 96)
            cls = cbuf.value
            if _MAIN_CLASS_MARK not in cls and _TOOL_CLASS_MARK not in cls:
                return True
            tbuf = ctypes.create_unicode_buffer(160)
            u.GetWindowTextW(ctypes.c_void_p(hwnd), tbuf, 160)
            pid = ctypes.c_ulong(0)
            u.GetWindowThreadProcessId(ctypes.c_void_p(hwnd), ctypes.byref(pid))
            tops.append((int(hwnd), int(pid.value), cls, tbuf.value))
            return True

        cb_ref = enum_proc_t(_cb)
        u.EnumWindows(cb_ref, 0)
        main = next(
            ((h, pid) for h, pid, cls, title in tops if _MAIN_CLASS_MARK in cls and title.startswith(wanted)),
            (0, 0),
        )
        if not main[0]:
            return 0, 0, []
        tools = [h for h, pid, cls, _t in tops if pid == main[1] and _TOOL_CLASS_MARK in cls]
        return main[0], main[1], tools

    def _window_size(self, hwnd: int) -> tuple[int, int]:
        rc = _RECT()
        if not self._user32 or not self._user32.GetWindowRect(hwnd, ctypes.byref(rc)):
            return 0, 0
        return rc.right - rc.left, rc.bottom - rc.top

    def _client_to_screen(self, hwnd: int, x: int, y: int) -> tuple[int, int]:
        pt = _POINT(int(x), int(y))
        if self._user32 is not None:
            self._user32.ClientToScreen(hwnd, ctypes.byref(pt))
        return pt.x, pt.y

    def _rect_in_parent(self, hwnd: int, parent_hwnd: int) -> tuple[int, int, int, int]:
        """Return `(x, y, w, h)` of `hwnd` in the owner window's client coordinates."""
        rc = _RECT()
        if not self._user32 or not self._user32.GetWindowRect(hwnd, ctypes.byref(rc)):
            return 0, 0, 0, 0
        w, h = rc.right - rc.left, rc.bottom - rc.top
        self._user32.MapWindowPoints(None, parent_hwnd, ctypes.byref(rc), 2)
        return rc.left, rc.top, w, h

    def set_display_size(self, width: int, height: int) -> None:
        """Adopt the guest's exact logical display shape (the window's own size is only approximate)."""
        if width > 0 and height > 0 and (width > height) == (self._aspect > 1.0):
            self._aspect = width / height

    def _client_size(self, hwnd: int) -> tuple[int, int]:
        rc = _RECT()
        if not self._user32 or not self._user32.GetClientRect(hwnd, ctypes.byref(rc)):
            return 0, 0
        return rc.right - rc.left, rc.bottom - rc.top

    # ------------------------------------------------------------------ Embed / release

    def embed(self, parent_hwnd: int, avd_name: str) -> bool:
        """Turn the emulator window of `avd_name` into a borderless popup owned by the top-level `parent_hwnd`.

        Returns False if the emulator has no window yet. Call `set_area` first so it lands in the right place.
        """
        u = self._user32
        if u is None or not parent_hwnd or not self.supported:
            return False
        try:
            if self._main_hwnd and not u.IsWindow(self._main_hwnd):
                self.forget()
            if not self._main_hwnd:
                main, pid, tools = self._enum_emulator_windows(avd_name)
                if not main:
                    return False
                # The client area is the guest display itself, so its shape is the device aspect ratio.
                cw, ch = self._client_size(main)
                if cw > 8 and ch > 8:
                    self._aspect = cw / ch
                self._main_hwnd = main
                self._tool_hwnds = tools
                self._orig_style = int(u.GetWindowLongPtrW(main, _GWL_STYLE))
                logger.info(
                    f"{TAG} Found emulator window for {avd_name or 'AVD'} (pid={pid}, client={cw}x{ch}, "
                    f"{len(tools)} tool window(s))"
                )
            for tool in self._tool_hwnds:
                u.ShowWindow(tool, _SW_HIDE)
            style = self._orig_style & ~(
                _WS_CHILD
                | _WS_CAPTION
                | _WS_THICKFRAME
                | _WS_SYSMENU
                | _WS_MINIMIZEBOX
                | _WS_MAXIMIZEBOX
                | _WS_VISIBLE
            )
            # Stay hidden until sync_geometry has put it over the placeholder (no flash at a stale position);
            # changing the owner while hidden also takes it off the taskbar.
            u.ShowWindow(self._main_hwnd, _SW_HIDE)
            u.SetWindowLongPtrW(self._main_hwnd, _GWL_STYLE, style | _WS_POPUP)
            u.SetWindowLongPtrW(self._main_hwnd, _GWLP_HWNDPARENT, int(parent_hwnd))
            self._parent_hwnd = int(parent_hwnd)
            self._last_target = None
            self.sync_geometry(force=True)
            logger.info(f"{TAG} Embedded emulator GPU window into the player (aspect={self._aspect:.3f})")
            return True
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Embedding the emulator window failed")
            self.forget()
            return False

    def sync_geometry(self, force: bool = False) -> bool:
        """Keep the embedded window centred and aspect-fitted over the placeholder. Returns True if it was moved.

        Called on every layout change (including moves of the main window) and on a short timer: about a second
        after any resize the emulator snaps its own window to the device aspect ratio and may move itself. Only
        the position is pulled back then; resizing it again would make it snap (and move) again.
        """
        u = self._user32
        if u is None or not self.is_embedded:
            return False
        try:
            if not u.IsWindow(self._main_hwnd):
                logger.warning(f"{TAG} Embedded emulator window is gone (emulator exited)")
                self.forget()
                return False
            for tool in self._tool_hwnds:
                if u.IsWindowVisible(tool):
                    u.ShowWindow(tool, _SW_HIDE)
            cur_x, cur_y, cur_w, cur_h = self._rect_in_parent(self._main_hwnd, self._parent_hwnd)
            # The emulator resizes its own window when the device rotates: adopt the new orientation.
            if cur_w > 8 and cur_h > 8 and (cur_w > cur_h) != (self._aspect > 1.0):
                self._aspect = 1.0 / self._aspect
                force = True
                logger.info(f"{TAG} Emulator display rotated; refitting to aspect={self._aspect:.3f}")
            visible_now = bool(u.IsWindowVisible(self._main_hwnd))
            if self._area is None or not self._area_visible:
                if visible_now:
                    u.ShowWindow(self._main_hwnd, _SW_HIDE)
                return False
            ax, ay, aw, ah = self._area
            fx, fy, fw, fh = fit_rect(aw, ah, self._aspect)
            target = (ax + fx, ay + fy, fw, fh)
            size_off = abs(cur_w - fw) > _GEOMETRY_TOLERANCE_PX or abs(cur_h - fh) > _GEOMETRY_TOLERANCE_PX
            if force or size_off or target != self._last_target:
                sx, sy = self._client_to_screen(self._parent_hwnd, target[0], target[1])
                u.SetWindowPos(
                    self._main_hwnd,
                    None,
                    sx,
                    sy,
                    target[2],
                    target[3],
                    _SWP_NOZORDER | _SWP_NOACTIVATE | _SWP_FRAMECHANGED | _SWP_SHOWWINDOW,
                )
                self._last_target = target
                self._repaint()
                return True
            # Same size (within the emulator's own 1-3 px aspect snapping): re-centre that size if it moved.
            want_x = ax + (aw - cur_w) // 2
            want_y = ay + (ah - cur_h) // 2
            if (
                abs(cur_x - want_x) > _GEOMETRY_TOLERANCE_PX
                or abs(cur_y - want_y) > _GEOMETRY_TOLERANCE_PX
                or not visible_now
            ):
                sx, sy = self._client_to_screen(self._parent_hwnd, want_x, want_y)
                u.SetWindowPos(
                    self._main_hwnd,
                    None,
                    sx,
                    sy,
                    0,
                    0,
                    _SWP_NOZORDER | _SWP_NOACTIVATE | _SWP_NOSIZE | _SWP_SHOWWINDOW,
                )
                if not visible_now:
                    self._repaint()
                return True
            return False
        except Exception as exc:  # noqa: BLE001
            logger.warning(f"{TAG} Could not refit embedded emulator window: {exc}")
            return False

    def _repaint(self) -> None:
        """Make the emulator present its last frame again: a static guest screen sends no new frames after the
        window is re-parented, shown or resized, which otherwise leaves a stale / partial picture."""
        if self._user32 is not None and self._main_hwnd:
            self._user32.RedrawWindow(self._main_hwnd, None, None, _RDW_REPAINT_ALL)

    def release(self, show: bool) -> bool:
        """Detach the emulator window from the player. `show=True` restores it as a normal desktop window."""
        u = self._user32
        if u is None or not self._main_hwnd:
            return False
        try:
            if not u.IsWindow(self._main_hwnd):
                self.forget()
                return False
            u.ShowWindow(self._main_hwnd, _SW_HIDE)
            u.SetWindowLongPtrW(self._main_hwnd, _GWLP_HWNDPARENT, 0)
            u.SetWindowLongPtrW(self._main_hwnd, _GWL_STYLE, self._orig_style & ~_WS_VISIBLE)
            self._parent_hwnd = 0
            self._last_target = None
            self._area_visible = False
            if show:
                h = 820
                w = int(h * self._aspect)
                if self._aspect > 1.0:
                    w = 1100
                    h = int(w / self._aspect)
                u.SetWindowPos(self._main_hwnd, None, 120, 80, w, h, _SWP_NOZORDER | _SWP_FRAMECHANGED | _SWP_SHOWWINDOW)
                for tool in self._tool_hwnds:
                    u.ShowWindow(tool, _SW_SHOW)
                u.SetForegroundWindow(self._main_hwnd)
            logger.info(f"{TAG} Released emulator window from the player (shown={show})")
            return True
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Releasing the emulator window failed")
            return False

    def forget(self) -> None:
        """Drop all window handles (the emulator exited or is being shut down)."""
        self._main_hwnd = 0
        self._parent_hwnd = 0
        self._tool_hwnds = []
        self._orig_style = 0
        self._last_target = None
        self._area_visible = False


class GuestDisplayMonitor(QObject):
    """Worker-thread adb companion for the embedded display: FPS, key events and rotation sync."""

    stats_ready = Signal(int, int, int)  # composited FPS, logical width, logical height

    _POLL_SCRIPT = (
        "dumpsys window displays 2>/dev/null | grep -oE 'cur=[0-9]+x[0-9]+|mRotation=[0-9]' | head -2 ; "
        "dumpsys SurfaceFlinger --timestats -dump | grep -m1 totalFrames ; "
        "dumpsys SurfaceFlinger --timestats -clear >/dev/null"
    )

    def __init__(self, runtime_mgr: AndroidRuntimeManager, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._runtime_mgr = runtime_mgr
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._gen = 0
        self._running = False
        self._commands: deque[tuple[str, int]] = deque()

    @property
    def is_running(self) -> bool:
        with self._lock:
            return self._running

    def start(self, runtime: RuntimeInfo) -> None:
        adb_p = runtime.adb_path or ""
        serial = runtime.adb_serial or ""
        if not adb_p or not serial or not os.path.isfile(adb_p):
            logger.warning(f"{TAG} Display monitor not started: no ADB endpoint for {runtime.label}")
            return
        with self._lock:
            if self._running:
                return
            self._gen += 1
            gen = self._gen
            self._running = True
            self._commands.clear()
        self._wake.clear()
        threading.Thread(
            target=self._worker_loop, args=(gen, adb_p, serial), name=f"android-display-monitor-{gen}", daemon=True
        ).start()

    def stop(self) -> None:
        with self._lock:
            was_running = self._running
            self._running = False
            self._gen += 1
            self._commands.clear()
        self._wake.set()
        if was_running:
            logger.info(f"{TAG} Stopped guest display monitor")

    def send_keyevent(self, keycode: int) -> None:
        self._enqueue("key", int(keycode))

    def rotate_device(self) -> None:
        self._enqueue("rotate", 0)

    def _enqueue(self, kind: str, arg: int) -> None:
        with self._lock:
            if not self._running:
                return
            self._commands.append((kind, arg))
        self._wake.set()

    def _is_current(self, gen: int) -> bool:
        with self._lock:
            return self._running and self._gen == gen

    # ------------------------------------------------------------------ Worker thread

    def _adb(self, adb_p: str, serial: str, args: list[str], timeout: float = 8.0) -> str:
        res = self._runtime_mgr.run_adb(adb_p, args, serial=serial, timeout=timeout)
        return res.stdout or ""

    def _read_acceleration(self, adb_p: str, serial: str) -> tuple[float, float, float] | None:
        return parse_acceleration(self._adb(adb_p, serial, ["emu", "sensor", "get", "acceleration"], timeout=5.0))

    def _sync_rotation(self, gen: int, adb_p: str, serial: str, rotation: int) -> int:
        """Turn the emulated device until `rotation` is upright. Returns the number of 90-degree steps taken."""
        steps = 0
        while steps < _MAX_ROTATE_STEPS and self._is_current(gen):
            accel = self._read_acceleration(adb_p, serial)
            if accel is None or gravity_matches_rotation(rotation, accel):
                break
            self._adb(adb_p, serial, ["emu", "rotate"], timeout=5.0)
            steps += 1
            time.sleep(0.6)
        return steps

    def _worker_loop(self, gen: int, adb_p: str, serial: str) -> None:
        t0 = time.monotonic()
        failing = False
        last_rotation = -1
        last_poll = 0.0
        try:
            self._adb(adb_p, serial, ["shell", "dumpsys SurfaceFlinger --timestats -clear -enable >/dev/null"])
            last_poll = time.monotonic()
            logger.info(f"{TAG} Guest display monitor started on {serial}")
        except Exception as exc:  # noqa: BLE001
            failing = True
            logger.warning(f"{TAG} Could not enable frame statistics on {serial}: {exc}")

        while self._is_current(gen):
            self._wake.wait(MONITOR_POLL_SECONDS)
            self._wake.clear()
            if not self._is_current(gen):
                break
            try:
                while True:
                    with self._lock:
                        cmd = self._commands.popleft() if self._commands else None
                    if cmd is None:
                        break
                    if cmd[0] == "key":
                        self._adb(adb_p, serial, ["shell", "input", "keyevent", str(cmd[1])])
                    elif cmd[0] == "rotate":
                        self._adb(adb_p, serial, ["emu", "rotate"], timeout=5.0)
                        logger.info(f"{TAG} User rotated the emulated device on {serial}")

                now = time.monotonic()
                elapsed = now - last_poll
                if elapsed < MONITOR_POLL_SECONDS * 0.9:
                    continue
                out = self._adb(adb_p, serial, ["shell", self._POLL_SCRIPT])
                last_poll = now
                state = parse_display_state(out)
                frames = re.search(r"totalFrames\s*=\s*(\d+)", out)
                if state is None:
                    raise RuntimeError(f"unexpected display state output: {out.strip()[:120]!r}")
                fps = int(round(int(frames.group(1)) / elapsed)) if frames and elapsed > 0 else 0
                self.stats_ready.emit(fps, state[0], state[1])
                steps = self._sync_rotation(gen, adb_p, serial, state[2])
                if steps and state[2] != last_rotation:
                    logger.info(
                        f"{TAG} Rotated emulated device {steps} step(s) to match display rotation {state[2]} on {serial}"
                    )
                last_rotation = state[2]
                if failing:
                    failing = False
                    logger.info(f"{TAG} Guest display monitor recovered on {serial}")
            except Exception as exc:  # noqa: BLE001
                # One warning per failure streak: this loop runs every couple of seconds.
                if not failing:
                    failing = True
                    logger.warning(f"{TAG} Guest display monitor poll failed on {serial}: {exc}")

        try:
            self._adb(adb_p, serial, ["shell", "dumpsys SurfaceFlinger --timestats -disable >/dev/null"], timeout=4.0)
        except Exception as exc:  # noqa: BLE001
            logger.debug(f"{TAG} Could not disable frame statistics on {serial}: {exc}")
        logger.debug(f"{TAG} Display monitor thread for {serial} exited after {time.monotonic() - t0:.1f}s")
