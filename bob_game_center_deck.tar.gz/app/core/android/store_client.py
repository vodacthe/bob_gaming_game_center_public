"""Multi-source Android App & Game Store client (Aptoide v7, Uptodown, F-Droid, APKPure CDN)."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import html as html_lib
import json
import logging
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request

import app.config as _app_config
from app.core.android.models import (
    CATEGORY_ALL,
    CATEGORY_APPS,
    CATEGORY_GAMES,
    SOURCE_APKPURE,
    SOURCE_APTOIDE,
    SOURCE_FDROID,
    SOURCE_UPTODOWN,
    AndroidApp,
    AndroidError,
    is_valid_package_name,
)

logger = logging.getLogger(__name__)
TAG = "[Android/Store]"

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
}

APTOIDE_API_BASE = "https://ws75.aptoide.com/api/7"
GOOGLE_PLAY_SEARCH_URL = "https://play.google.com/store/search"
FDROID_SEARCH_URL = "https://search.f-droid.org/api/search_apps"
FDROID_PACKAGE_URL = "https://f-droid.org/api/v1/packages"
FDROID_REPO_BASE = "https://f-droid.org/repo"
UPTODOWN_GAMES_URL = "https://en.uptodown.com/android/games"
UPTODOWN_APPS_URL = "https://en.uptodown.com/android/apps"
APKPURE_CDN_BASE = "https://d.apkpure.com/b"

_FDROID_PKG_RE = re.compile(r"/packages/([a-zA-Z0-9_.]+)/?")
_PLAY_PKG_RE = re.compile(r"details\?id=([a-zA-Z][a-zA-Z0-9_]*(?:\.[a-zA-Z0-9_]+)+)")
_AF_INIT_RE = re.compile(r"AF_initDataCallback\(\{[^<]*?data:(\[.*?\]),\s*sideChannel:", re.DOTALL)
_UPTODOWN_ITEM_RE = re.compile(
    r'<figure[^>]*>\s*<a[^>]+href="(https://[a-z0-9\-]+\.en\.uptodown\.com/android)"[^>]*>(.*?)</a>.*?'
    r'<div[^>]*class="name"[^>]*>\s*<a[^>]*>([^<]+)</a>\s*</div>\s*'
    r'(?:<div[^>]*class="description"[^>]*>([^<]*)</div>)?',
    re.IGNORECASE | re.DOTALL,
)
_IMG_SRC_RE = re.compile(r'(?:data-src|src)="(https://[^"]+)"', re.IGNORECASE)

_GAME_KEYWORDS = (
    "game", "game_", "rpg", "arcade", "action", "puzzle", "racing", "shooter", "strategy",
    "simulation", "adventure", "survivor", "battle", "arena", "craft", "chess", "voxel", "moba",
    "hành động", "chiến thuật", "nhập vai", "đua xe", "mô phỏng", "phiêu lưu", "giải đố",
    "trò chơi", "bắn súng", "sinh tồn", "thể thao", "dạng bảng", "sòng bạc", "thông thường",
)

_TRUSTED_APTOIDE_STORES = frozenset({"apps", "catappult"})
_SPOOFED_VERSIONS = frozenset({"999", "999.0", "999.9", "9999", "9999.0"})

_SKIP_SYSTEM_PACKAGES = frozenset(
    {
        "com.google.android.as",
        "com.google.android.odad",
        "com.google.android.tts",
        "com.google.android.webview",
        "com.google.mainline.telemetry",
        "com.google.mainline.adservices",
        "com.android.vending",
        "com.google.android.gms",
        "com.google.android.gsf",
    }
)

# Popular baseline packages hydrated via live APIs / APKPure CDN so initial browse is never empty
_CURATED_SEEDS: tuple[tuple[str, str, str, str], ...] = (
    ("com.kiloo.subwaysurf", "Subway Surfers", CATEGORY_GAMES, "Chạy vô tận tốc độ cao trên đường ray"),
    ("com.tencent.ig", "PUBG MOBILE", CATEGORY_GAMES, "Sinh tồn bắn súng chiến thuật 100 người"),
    ("com.dts.freefireth", "Free Fire", CATEGORY_GAMES, "Bắn súng sinh tồn nhịp độ nhanh 10 phút"),
    ("com.roblox.client", "Roblox", CATEGORY_GAMES, "Vũ trụ trò chơi sáng tạo đa nền tảng"),
    ("com.mobile.legends", "Mobile Legends: Bang Bang", CATEGORY_GAMES, "Đấu trường MOBA 5v5 kinh điển"),
    ("com.supercell.clashofclans", "Clash of Clans", CATEGORY_GAMES, "Xây dựng căn cứ và chiến thuật bang hội"),
    ("net.minetest.minetest", "Luanti (Minetest)", CATEGORY_GAMES, "Thế giới khối vuông sandbox mã nguồn mở"),
    ("com.discord", "Discord", CATEGORY_APPS, "Trò chuyện thoại, video và cộng đồng game thủ"),
    ("org.telegram.messenger", "Telegram", CATEGORY_APPS, "Nhắn tin đám mây tốc độ cao, bảo mật"),
    ("org.videolan.vlc", "VLC for Android", CATEGORY_APPS, "Trình phát đa phương tiện hỗ trợ mọi định dạng"),
    ("com.zhiliaoapp.musically", "TikTok", CATEGORY_APPS, "Nền tảng video ngắn giải trí"),
    ("org.fdroid.fdroid", "F-Droid", CATEGORY_APPS, "Kho ứng dụng mã nguồn mở tự do cho Android"),
)


def _guess_kind(name: str, summary: str = "", default: str = CATEGORY_GAMES) -> str:
    hay = f"{name} {summary}".lower()
    if any(k in hay for k in _GAME_KEYWORDS):
        return CATEGORY_GAMES
    return default


class AndroidStoreClient:
    """Fetches, searches, and resolves Android APK/XAPK download URLs across free stores."""

    def __init__(self, timeout: float = 12.0):
        self.timeout = timeout

    def _http_get_bytes(self, url: str, extra_headers: dict[str, str] | None = None) -> bytes:
        t0 = time.monotonic()
        headers = dict(DEFAULT_HEADERS)
        if extra_headers:
            headers.update(extra_headers)
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                status = getattr(resp, "status", 200)
                data = resp.read()
                if status >= 400:
                    elapsed = time.monotonic() - t0
                    logger.warning(f"{TAG} HTTP {status} from {url} in {elapsed:.2f}s")
                    raise AndroidError(f"Máy chủ trả về mã lỗi HTTP {status}")
                return data
        except urllib.error.HTTPError as exc:
            elapsed = time.monotonic() - t0
            logger.warning(f"{TAG} HTTP {exc.code} failure for {url} in {elapsed:.2f}s: {exc.reason}")
            raise AndroidError(f"Không tải được dữ liệu cửa hàng (HTTP {exc.code})") from exc
        except Exception as exc:
            elapsed = time.monotonic() - t0
            logger.warning(f"{TAG} Network error for {url} in {elapsed:.2f}s: {exc}")
            raise AndroidError(f"Lỗi kết nối mạng: {exc}") from exc

    def _http_get_json(self, url: str) -> dict:
        raw = self._http_get_bytes(url)
        try:
            data = json.loads(raw.decode("utf-8", errors="replace"))
            return data if isinstance(data, dict) else {}
        except json.JSONDecodeError as exc:
            logger.warning(f"{TAG} Invalid JSON from {url}: {exc}")
            raise AndroidError("Dữ liệu trả về từ cửa hàng không hợp lệ.") from exc

    # ------------------------------------------------------------------ Google Play Catalog & Aptoide v7

    def _parse_aptoide_item(self, item: dict, default_kind: str = CATEGORY_GAMES) -> AndroidApp | None:
        if not isinstance(item, dict):
            return None
        pkg = str(item.get("package") or "").strip()
        name = str(item.get("name") or "").strip()
        if not pkg or not name or not is_valid_package_name(pkg):
            return None

        file_node = item.get("file") if isinstance(item.get("file"), dict) else {}
        dl_url = str(file_node.get("path") or file_node.get("path_alt") or "").strip()
        ver = str(file_node.get("vername") or "").strip()
        size_bytes = int(item.get("size") or file_node.get("filesize") or 0)

        if ver in _SPOOFED_VERSIONS:
            logger.warning(f"{TAG} Blocked spoofed version {ver!r} for {pkg}")
            return None

        malware = file_node.get("malware") if isinstance(file_node.get("malware"), dict) else (
            item.get("malware") if isinstance(item.get("malware"), dict) else {}
        )
        if malware:
            rank = str(malware.get("rank") or "").strip().upper()
            reason = malware.get("reason") if isinstance(malware.get("reason"), dict) else {}
            sig_node = reason.get("signature_validated") if isinstance(reason.get("signature_validated"), dict) else {}
            sig_status = str(sig_node.get("status") or "").strip().lower()
            if (rank and rank != "TRUSTED") or sig_status == "failed":
                logger.warning(f"{TAG} Blocked untrusted Aptoide package {pkg} (rank={rank!r}, sig={sig_status!r})")
                return None

        store_node = item.get("store") if isinstance(item.get("store"), dict) else {}
        store_name = str(store_node.get("name") or "").strip().lower()
        if store_name and store_name not in _TRUSTED_APTOIDE_STORES:
            logger.warning(f"{TAG} Blocked third-party Aptoide uploader store {store_name!r} for {pkg}")
            return None

        splits: list[str] = []
        aab = item.get("aab")
        if isinstance(aab, dict):
            for sp in aab.get("splits") or []:
                if isinstance(sp, dict) and sp.get("path"):
                    splits.append(str(sp["path"]).strip())

        obb_urls: dict[str, str] = {}
        obb = item.get("obb")
        if isinstance(obb, dict):
            for slot in ("main", "patch"):
                part = obb.get(slot)
                if isinstance(part, dict) and part.get("path"):
                    fname = str(part.get("filename") or f"{slot}.{pkg}.obb").strip()
                    obb_urls[fname] = str(part["path"]).strip()

        stats = item.get("stats") if isinstance(item.get("stats"), dict) else {}
        prating = stats.get("prating") if isinstance(stats.get("prating"), dict) else {}
        rating = float(prating.get("avg") or 0.0)

        return AndroidApp(
            package_name=pkg,
            name=name,
            kind=default_kind,
            version=ver,
            size_bytes=size_bytes,
            icon_url=str(item.get("icon") or "").strip(),
            banner_url=str(item.get("graphic") or "").strip(),
            summary="",
            source=SOURCE_APTOIDE,
            download_url=dl_url,
            split_urls=splits,
            obb_urls=obb_urls,
            rating=rating,
        )

    def search_google_play(
        self,
        query: str,
        default_kind: str = CATEGORY_GAMES,
        limit: int = 24,
    ) -> list[AndroidApp]:
        """Search official Google Play Store catalog (hl=vi, gl=VN) and map to verified APKPure XAPK CDN."""
        q = urllib.parse.quote(query.strip())
        url = f"{GOOGLE_PLAY_SEARCH_URL}?q={q}&c=apps&hl=vi&gl=VN"
        raw_html = self._http_get_bytes(url).decode("utf-8", errors="replace")
        raw_rows: list[tuple[str, str, str, str, str, float, str]] = []

        def _walk(node) -> None:
            if not isinstance(node, list):
                return
            if (
                len(node) >= 16
                and isinstance(node[0], list)
                and len(node[0]) == 2
                and isinstance(node[0][0], str)
                and "." in node[0][0]
                and node[0][1] == 7
                and isinstance(node[3], str)
            ):
                pkg = node[0][0].strip()
                title = html_lib.unescape(node[3].strip())
                icon = ""
                if (
                    isinstance(node[1], list)
                    and len(node[1]) > 3
                    and isinstance(node[1][3], list)
                    and len(node[1][3]) > 2
                    and isinstance(node[1][3][2], str)
                ):
                    icon = node[1][3][2].strip()
                rating = 0.0
                if isinstance(node[4], list) and len(node[4]) > 1 and isinstance(node[4][1], (int, float)):
                    rating = float(node[4][1])
                genre_label = str(node[5]).strip() if isinstance(node[5], str) else ""
                dev = str(node[14]).strip() if isinstance(node[14], str) else ""
                raw_rows.append((pkg, title, icon, genre_label, genre_label, rating, dev))
                return

            if len(node) >= 96 and isinstance(node[0], list) and len(node[0]) == 1 and isinstance(node[0][0], str):
                dumped = json.dumps(node, ensure_ascii=False)
                m = _PLAY_PKG_RE.search(dumped)
                if m:
                    pkg = m.group(1).strip()
                    title = html_lib.unescape(node[0][0].strip())
                    icon = ""
                    if (
                        isinstance(node[95], list)
                        and node[95]
                        and isinstance(node[95][0], list)
                        and len(node[95][0]) > 3
                        and isinstance(node[95][0][3], list)
                        and len(node[95][0][3]) > 2
                        and isinstance(node[95][0][3][2], str)
                    ):
                        icon = node[95][0][3][2].strip()
                    genre_label, genre_code = "", ""
                    if (
                        isinstance(node[79], list)
                        and node[79]
                        and isinstance(node[79][0], list)
                        and node[79][0]
                        and isinstance(node[79][0][0], list)
                    ):
                        g_entry = node[79][0][0]
                        if len(g_entry) > 0 and isinstance(g_entry[0], str):
                            genre_label = g_entry[0].strip()
                        if len(g_entry) > 2 and isinstance(g_entry[2], str):
                            genre_code = g_entry[2].strip()
                    rating = 0.0
                    if (
                        isinstance(node[51], list)
                        and node[51]
                        and isinstance(node[51][0], list)
                        and len(node[51][0]) > 1
                        and isinstance(node[51][0][1], (int, float))
                    ):
                        rating = float(node[51][0][1])
                    dev = ""
                    if isinstance(node[68], list) and node[68] and isinstance(node[68][0], str):
                        dev = node[68][0].strip()
                    raw_rows.append((pkg, title, icon, genre_label, genre_code, rating, dev))
                    return

            for child in node:
                if isinstance(child, list):
                    _walk(child)

        for block in _AF_INIT_RE.findall(raw_html):
            try:
                _walk(json.loads(block))
            except Exception:
                continue

        out: list[AndroidApp] = []
        seen: set[str] = set()
        for pkg, title, icon, genre_label, genre_code, rating, dev in raw_rows:
            pkg_low = pkg.lower()
            if not title or not is_valid_package_name(pkg) or pkg_low in seen or pkg_low in _SKIP_SYSTEM_PACKAGES:
                continue
            seen.add(pkg_low)
            if genre_code.upper().startswith("GAME_"):
                kind = CATEGORY_GAMES
            elif genre_code:
                kind = CATEGORY_APPS
            else:
                kind = _guess_kind(title, genre_label, default=default_kind if not genre_label else CATEGORY_APPS)
            summary_parts = [p for p in (dev, genre_label) if p]
            out.append(
                AndroidApp(
                    package_name=pkg,
                    name=title,
                    kind=kind,
                    icon_url=icon,
                    summary=" · ".join(summary_parts),
                    source=SOURCE_APKPURE,
                    download_url=f"{APKPURE_CDN_BASE}/XAPK/{pkg}?version=latest",
                    rating=rating,
                    page_url=f"https://play.google.com/store/apps/details?id={pkg}",
                )
            )
            if len(out) >= limit:
                break
        return out

    def search_aptoide(
        self,
        query: str,
        default_kind: str = CATEGORY_GAMES,
        limit: int = 20,
        page: int = 1,
    ) -> list[AndroidApp]:
        q = urllib.parse.quote(query.strip())
        lim = max(1, int(limit))
        offset = max(0, (max(1, int(page)) - 1) * lim)
        url = f"{APTOIDE_API_BASE}/apps/search/query={q}/limit={lim}"
        if offset > 0:
            url += f"/offset={offset}"
        url += "/trusted=true"
        data = self._http_get_json(url)
        raw_list = ((data.get("datalist") or {}).get("list")) or []
        out: list[AndroidApp] = []
        for item in raw_list:
            parsed = self._parse_aptoide_item(item, default_kind=_guess_kind(str(item.get("name") or ""), default=default_kind))
            if parsed and parsed.package_name.lower() not in _SKIP_SYSTEM_PACKAGES:
                out.append(parsed)
        return out

    def list_aptoide_group(
        self,
        group_name: str = "games",
        page: int = 1,
        limit: int = 36,
    ) -> list[AndroidApp]:
        """Fetch paginated popular Android games or applications from Aptoide v7 listApps (trusted only)."""
        grp = urllib.parse.quote(group_name.strip() or "games")
        lim = max(1, int(limit))
        offset = max(0, (max(1, int(page)) - 1) * lim)
        url = f"{APTOIDE_API_BASE}/listApps/group_name={grp}/sort=downloads7d/limit={lim}/offset={offset}/trusted=true"
        data = self._http_get_json(url)
        raw_list = ((data.get("datalist") or {}).get("list")) or []
        default_kind = CATEGORY_GAMES if group_name == "games" else CATEGORY_APPS
        out: list[AndroidApp] = []
        for item in raw_list:
            parsed = self._parse_aptoide_item(item, default_kind=default_kind)
            if parsed and parsed.package_name.lower() not in _SKIP_SYSTEM_PACKAGES:
                out.append(parsed)
        return out

    def get_aptoide_app_meta(self, package_name: str) -> AndroidApp | None:
        pkg = urllib.parse.quote(package_name.strip())
        url = f"{APTOIDE_API_BASE}/app/get/package_name={pkg}/trusted=true"
        data = self._http_get_json(url)
        meta = (((data.get("nodes") or {}).get("meta") or {}).get("data")) or {}
        return self._parse_aptoide_item(meta)

    # ------------------------------------------------------------------ F-Droid

    def search_fdroid(self, query: str, limit: int = 16) -> list[AndroidApp]:
        q = urllib.parse.quote(query.strip())
        url = f"{FDROID_SEARCH_URL}?q={q}"
        data = self._http_get_json(url)
        out: list[AndroidApp] = []
        for item in (data.get("apps") or [])[:limit]:
            if not isinstance(item, dict):
                continue
            page_url = str(item.get("url") or "").strip()
            m = _FDROID_PKG_RE.search(page_url)
            if not m:
                continue
            pkg = m.group(1)
            if not is_valid_package_name(pkg):
                continue
            name = html_lib.unescape(str(item.get("name") or pkg).strip())
            summary = html_lib.unescape(str(item.get("summary") or "").strip())
            out.append(
                AndroidApp(
                    package_name=pkg,
                    name=name,
                    kind=_guess_kind(name, summary, default=CATEGORY_APPS),
                    icon_url=str(item.get("icon") or "").strip(),
                    summary=summary,
                    source=SOURCE_FDROID,
                    page_url=page_url,
                )
            )
        return out

    def resolve_fdroid_apk_url(self, package_name: str) -> tuple[str, str]:
        """Return (download_url, version_str) from F-Droid package index API."""
        url = f"{FDROID_PACKAGE_URL}/{urllib.parse.quote(package_name.strip())}"
        data = self._http_get_json(url)
        suggested = data.get("suggestedVersionCode")
        packages = data.get("packages") or []
        chosen = None
        for entry in packages:
            if isinstance(entry, dict) and suggested and entry.get("versionCode") == suggested:
                chosen = entry
                break
        if chosen is None and packages and isinstance(packages[0], dict):
            chosen = packages[0]
        if not chosen:
            raise AndroidError(f"Không tìm thấy gói APK F-Droid cho {package_name}")
        ver_code = chosen.get("versionCode")
        ver_name = str(chosen.get("versionName") or ver_code or "")
        return f"{FDROID_REPO_BASE}/{package_name}_{ver_code}.apk", ver_name

    # ------------------------------------------------------------------ Uptodown

    def fetch_uptodown_section(self, kind: str = CATEGORY_GAMES, limit: int = 18) -> list[AndroidApp]:
        url = UPTODOWN_GAMES_URL if kind == CATEGORY_GAMES else UPTODOWN_APPS_URL
        raw = self._http_get_bytes(url).decode("utf-8", errors="replace")
        out: list[AndroidApp] = []
        seen: set[str] = set()
        for m in _UPTODOWN_ITEM_RE.finditer(raw):
            page_url = m.group(1).strip()
            fig_inner = m.group(2) or ""
            title = html_lib.unescape(m.group(3).strip())
            desc = html_lib.unescape((m.group(4) or "").strip())
            slug_host = urllib.parse.urlparse(page_url).hostname or ""
            slug = slug_host.split(".")[0].strip("-")
            if not slug or slug in seen:
                continue
            seen.add(slug)
            img_m = _IMG_SRC_RE.search(fig_inner)
            icon_url = img_m.group(1) if img_m else ""
            pseudo_pkg = f"uptodown.{slug.replace('-', '_')}"
            out.append(
                AndroidApp(
                    package_name=pseudo_pkg,
                    name=title,
                    kind=kind,
                    icon_url=icon_url,
                    summary=desc,
                    source=SOURCE_UPTODOWN,
                    page_url=page_url,
                )
            )
            if len(out) >= limit:
                break
        return out

    def resolve_uptodown_package_name(self, page_url: str) -> str:
        """Extract real Android package ID from an Uptodown app download page."""
        dl_page = page_url.rstrip("/") + "/download"
        raw = self._http_get_bytes(dl_page).decode("utf-8", errors="replace")
        m = _PLAY_PKG_RE.search(raw)
        if m and is_valid_package_name(m.group(1)):
            return m.group(1)
        raise AndroidError("Không xác định được Package ID từ trang Uptodown.")

    # ------------------------------------------------------------------ Unified Browse & Search

    def _curated_apps(self, category: str = CATEGORY_ALL) -> list[AndroidApp]:
        items: list[AndroidApp] = []
        for pkg, name, kind, summary in _CURATED_SEEDS:
            if category in (CATEGORY_ALL, kind):
                source = SOURCE_FDROID if pkg in ("net.minetest.minetest", "org.fdroid.fdroid") else SOURCE_APKPURE
                dl_url = "" if source == SOURCE_FDROID else f"{APKPURE_CDN_BASE}/XAPK/{pkg}?version=latest"
                items.append(
                    AndroidApp(
                        package_name=pkg,
                        name=name,
                        kind=kind,
                        summary=summary,
                        source=source,
                        download_url=dl_url,
                    )
                )
        return items

    def get_featured(self, category: str = CATEGORY_ALL) -> list[AndroidApp]:
        """Load featured Android games & apps with disk cache fallback."""
        t0 = time.monotonic()
        merged: dict[str, AndroidApp] = {}

        def _add(app_obj: AndroidApp):
            key = app_obj.package_name.lower()
            existing = merged.get(key)
            if existing is None:
                merged[key] = app_obj
            else:
                if not existing.icon_url and app_obj.icon_url:
                    existing.icon_url = app_obj.icon_url
                if not existing.download_url and app_obj.download_url:
                    existing.download_url = app_obj.download_url
                if not existing.version and app_obj.version:
                    existing.version = app_obj.version
                if not existing.size_bytes and app_obj.size_bytes:
                    existing.size_bytes = app_obj.size_bytes

        for seed in self._curated_apps(category):
            _add(seed)

        tasks: list[tuple[str, object]] = []
        if category in (CATEGORY_ALL, CATEGORY_GAMES):
            tasks.append(("aptoide_top_games", lambda: self.list_aptoide_group("games", page=1, limit=24)))
            tasks.append(("uptodown_games", lambda: self.fetch_uptodown_section(CATEGORY_GAMES, limit=12)))
        if category in (CATEGORY_ALL, CATEGORY_APPS):
            tasks.append(("aptoide_top_apps", lambda: self.list_aptoide_group("applications", page=1, limit=18)))
            tasks.append(("fdroid_apps", lambda: self.search_fdroid("player", limit=10)))

        with ThreadPoolExecutor(max_workers=max(1, len(tasks))) as pool:
            futures = [(label, pool.submit(fn)) for label, fn in tasks]
            for label, fut in futures:
                try:
                    for item in fut.result():
                        if category == CATEGORY_ALL or item.kind == category:
                            _add(item)
                except Exception as exc:
                    logger.warning(f"{TAG} Featured source '{label}' skipped: {exc}")

        results = list(merged.values())
        self._save_cache(category, results)
        logger.info(f"{TAG} Loaded {len(results)} featured items (category={category}) in {time.monotonic() - t0:.2f}s")
        return results

    def get_catalog_page(
        self,
        category: str = CATEGORY_ALL,
        page: int = 1,
        per_page: int = 36,
    ) -> list[AndroidApp]:
        """Fetch page `page` (1-indexed) of the Android catalog for multi-page buffering."""
        p = max(1, int(page))
        if p == 1:
            return self.get_featured(category)

        t0 = time.monotonic()
        lim = max(8, int(per_page))
        merged: dict[str, AndroidApp] = {}

        def _push(items: list[AndroidApp]):
            for item in items:
                key = item.package_name.lower()
                if key not in merged:
                    merged[key] = item

        if category == CATEGORY_GAMES:
            _push(self.list_aptoide_group("games", page=p, limit=lim))
        elif category == CATEGORY_APPS:
            _push(self.list_aptoide_group("applications", page=p, limit=lim))
        else:
            games_lim = max(12, (lim * 2) // 3)
            apps_lim = max(8, lim - games_lim + 6)
            with ThreadPoolExecutor(max_workers=2) as pool:
                f_g = pool.submit(self.list_aptoide_group, "games", p, games_lim)
                f_a = pool.submit(self.list_aptoide_group, "applications", p, apps_lim)
                g_items: list[AndroidApp] = []
                a_items: list[AndroidApp] = []
                try:
                    g_items = f_g.result()
                except Exception as exc:
                    logger.warning(f"{TAG} Catalog page {p} games source failed: {exc}")
                try:
                    a_items = f_a.result()
                except Exception as exc:
                    logger.warning(f"{TAG} Catalog page {p} apps source failed: {exc}")
            # Interleave popular games + apps cleanly across pages
            max_len = max(len(g_items), len(a_items))
            for idx in range(max_len):
                if idx < len(g_items):
                    _push([g_items[idx]])
                if idx < len(a_items):
                    _push([a_items[idx]])

        results = list(merged.values())
        logger.info(
            f"{TAG} Loaded catalog page {p} (category={category}): {len(results)} items in {time.monotonic() - t0:.2f}s"
        )
        return results

    def search(
        self,
        query: str,
        category: str = CATEGORY_ALL,
        limit: int = 28,
        page: int = 1,
    ) -> list[AndroidApp]:
        """Search across official Google Play catalog, F-Droid, and trusted Aptoide v7, with pagination."""
        q = (query or "").strip()
        p = max(1, int(page))
        if not q:
            return self.get_catalog_page(category, page=p, per_page=limit)

        t0 = time.monotonic()
        merged: dict[str, AndroidApp] = {}

        if p == 1 and is_valid_package_name(q):
            icon_url, title, ver, sz = "", q, "", 0
            try:
                meta = self.get_aptoide_app_meta(q)
                if meta:
                    title = meta.name or q
                    icon_url = meta.icon_url
                    ver = meta.version
                    sz = meta.size_bytes
            except AndroidError:
                pass
            merged[q.lower()] = AndroidApp(
                package_name=q,
                name=title,
                kind=CATEGORY_APPS if category == CATEGORY_APPS else CATEGORY_GAMES,
                version=ver,
                size_bytes=sz,
                icon_url=icon_url,
                source=SOURCE_APKPURE,
                download_url=f"{APKPURE_CDN_BASE}/XAPK/{q}?version=latest",
                summary="Tải trực tiếp theo Package ID từ nguồn chính thức",
            )

        default_kind = CATEGORY_APPS if category == CATEGORY_APPS else CATEGORY_GAMES
        if p == 1:
            with ThreadPoolExecutor(max_workers=3) as pool:
                f_gp = pool.submit(self.search_google_play, q, default_kind, limit)
                f_fdr = pool.submit(self.search_fdroid, q, min(16, limit))
                f_apt = pool.submit(self.search_aptoide, q, default_kind, limit, 1)
                sources = [("google_play", f_gp), ("fdroid", f_fdr), ("aptoide", f_apt)]
                for label, fut in sources:
                    try:
                        for app_obj in fut.result():
                            key = app_obj.package_name.lower()
                            existing = merged.get(key)
                            if existing is None:
                                merged[key] = app_obj
                            else:
                                if not existing.version and app_obj.version:
                                    existing.version = app_obj.version
                                if not existing.size_bytes and app_obj.size_bytes:
                                    existing.size_bytes = app_obj.size_bytes
                                if not existing.icon_url and app_obj.icon_url:
                                    existing.icon_url = app_obj.icon_url
                                if not existing.split_urls and app_obj.split_urls:
                                    existing.split_urls = list(app_obj.split_urls)
                                if not existing.obb_urls and app_obj.obb_urls:
                                    existing.obb_urls = dict(app_obj.obb_urls)
                    except Exception as exc:
                        logger.warning(f"{TAG} Search source '{label}' failed for {q!r}: {exc}")
        else:
            try:
                for app_obj in self.search_aptoide(q, default_kind, limit, p):
                    key = app_obj.package_name.lower()
                    if key not in merged:
                        merged[key] = app_obj
            except Exception as exc:
                logger.warning(f"{TAG} Search page {p} failed for {q!r}: {exc}")

        results = list(merged.values())[:limit]
        logger.info(f"{TAG} Search {q!r} page {p} returned {len(results)} apps in {time.monotonic() - t0:.2f}s")
        return results

    def resolve_download_plan(self, app: AndroidApp) -> tuple[AndroidApp, list[tuple[str, str]]]:
        """
        Resolve real package_name (if Uptodown slug) and return ordered [(source_name, direct_url)] candidates.
        Official developer-signed packages (F-Droid / APKPure Google-Play mirrors) always precede Aptoide.
        """
        resolved_pkg = app.package_name.strip()
        if resolved_pkg.startswith("uptodown.") and app.page_url:
            resolved_pkg = self.resolve_uptodown_package_name(app.page_url)
            logger.info(f"{TAG} Resolved Uptodown slug {app.package_name} -> {resolved_pkg}")
            app = AndroidApp(
                package_name=resolved_pkg,
                name=app.name,
                kind=app.kind,
                version=app.version,
                size_bytes=app.size_bytes,
                icon_url=app.icon_url,
                banner_url=app.banner_url,
                summary=app.summary,
                source=app.source,
                download_url=app.download_url,
                split_urls=list(app.split_urls),
                obb_urls=dict(app.obb_urls),
                rating=app.rating,
                page_url=app.page_url,
            )

        candidates: list[tuple[str, str]] = []
        seen_urls: set[str] = set()

        def _push(src_name: str, url: str):
            u = (url or "").strip()
            if u and u not in seen_urls:
                seen_urls.add(u)
                candidates.append((src_name, u))

        if app.source == SOURCE_FDROID and not app.download_url and is_valid_package_name(resolved_pkg):
            try:
                fdr_url, fdr_ver = self.resolve_fdroid_apk_url(resolved_pkg)
                _push(SOURCE_FDROID, fdr_url)
                if not app.version and fdr_ver:
                    app.version = fdr_ver
            except AndroidError as exc:
                logger.warning(f"{TAG} F-Droid direct URL lookup failed for {resolved_pkg}: {exc}")

        if app.download_url and app.source != SOURCE_APTOIDE:
            _push(app.source, app.download_url)

        if is_valid_package_name(resolved_pkg):
            # Official Google-Play-signed XAPK/APK CDN first (bundles splits + OBB cleanly)
            _push(SOURCE_APKPURE, f"{APKPURE_CDN_BASE}/XAPK/{resolved_pkg}?version=latest")
            _push(SOURCE_APKPURE, f"{APKPURE_CDN_BASE}/APK/{resolved_pkg}?version=latest")

        if app.download_url and app.source == SOURCE_APTOIDE:
            _push(SOURCE_APTOIDE, app.download_url)

        if is_valid_package_name(resolved_pkg) and (not app.download_url or app.source != SOURCE_APTOIDE):
            try:
                meta = self.get_aptoide_app_meta(resolved_pkg)
                if meta and meta.download_url:
                    _push(SOURCE_APTOIDE, meta.download_url)
                    if not app.split_urls and meta.split_urls:
                        app.split_urls = list(meta.split_urls)
                    if not app.obb_urls and meta.obb_urls:
                        app.obb_urls = dict(meta.obb_urls)
            except AndroidError:
                pass

        if not candidates:
            raise AndroidError(f"Không tìm thấy nguồn tải hợp lệ cho {app.name} ({resolved_pkg}).")

        return app, candidates

    def _cache_file(self) -> str:
        cache_dir = getattr(_app_config, "CACHE_DIR", "")
        os.makedirs(cache_dir, exist_ok=True)
        legacy = os.path.join(cache_dir, "android_store_cache.json")
        if os.path.isfile(legacy):
            try:
                os.remove(legacy)
            except OSError:
                pass
        return os.path.join(cache_dir, "android_store_cache_v2.json")

    def _save_cache(self, category: str, apps: list[AndroidApp]) -> None:
        if not apps:
            return
        path = self._cache_file()
        try:
            payload: dict = {}
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    if isinstance(loaded, dict):
                        payload = loaded
            payload[category] = [
                {
                    "package_name": a.package_name,
                    "name": a.name,
                    "kind": a.kind,
                    "version": a.version,
                    "size_bytes": a.size_bytes,
                    "icon_url": a.icon_url,
                    "banner_url": a.banner_url,
                    "summary": a.summary,
                    "source": a.source,
                    "download_url": a.download_url,
                    "rating": a.rating,
                    "page_url": a.page_url,
                }
                for a in apps[:300]
            ]
            with open(path, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
        except Exception as exc:
            logger.debug(f"{TAG} Could not write catalog cache: {exc}")

    def load_cached_featured(self, category: str = CATEGORY_ALL) -> list[AndroidApp]:
        path = self._cache_file()
        if not os.path.isfile(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            rows = data.get(category) or []
            return [
                AndroidApp(
                    package_name=str(r.get("package_name") or ""),
                    name=str(r.get("name") or ""),
                    kind=str(r.get("kind") or CATEGORY_GAMES),
                    version=str(r.get("version") or ""),
                    size_bytes=int(r.get("size_bytes") or 0),
                    icon_url=str(r.get("icon_url") or ""),
                    banner_url=str(r.get("banner_url") or ""),
                    summary=str(r.get("summary") or ""),
                    source=str(r.get("source") or SOURCE_APTOIDE),
                    download_url=str(r.get("download_url") or ""),
                    rating=float(r.get("rating") or 0.0),
                    page_url=str(r.get("page_url") or ""),
                )
                for r in rows
                if isinstance(r, dict) and r.get("package_name") and r.get("name")
            ]
        except Exception:
            return []
