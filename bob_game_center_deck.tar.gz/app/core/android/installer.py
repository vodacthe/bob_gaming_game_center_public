"""Android package (.apk / .xapk / .apks + OBB) downloader, inspector, and ADB/Waydroid installer."""

from __future__ import annotations

import base64
import json
import logging
import os
import re
import shlex
import shutil
import stat
import subprocess
import sys
import time
from typing import Callable
import urllib.request
import zipfile

from app.core.android.models import (
    CATEGORY_GAMES,
    RUNTIME_PORTABLE_SDK,
    RUNTIME_WAYDROID,
    SOURCE_LOCAL,
    AndroidAbiMismatchError,
    AndroidApp,
    AndroidError,
    RuntimeInfo,
    get_apps_dir,
    is_valid_package_name,
    sanitize_package_dir_name,
)
from app.core.android.runtime import (
    AndroidRuntimeManager,
    DEFAULT_AVD_NAME,
    _subprocess_kwargs,
    get_portable_profile,
    run_aria2_http_download,
)
from app.core.android.store_client import DEFAULT_HEADERS
from app.core.binary_finder import find_aria2c

logger = logging.getLogger(__name__)
TAG = "[Android/Install]"

_ABI_TOKENS = {
    "x86_64": ("x86_64", "x86-64"),
    "x86": ("x86",),
    "arm64-v8a": ("arm64_v8a", "arm64-v8a", "arm64"),
    "armeabi-v7a": ("armeabi_v7a", "armeabi-v7a", "armv7"),
}


def inspect_package_bundle(archive_path: str, unpack_dir: str) -> dict:
    """
    Inspect an .apk / .xapk / .apks / .apkm file.
    Returns {
        "is_bundle": bool,
        "apk_files": list[str],
        "obb_files": list[tuple[str, str]],   # (local_path, remote_rel_ under /sdcard/Android/obb/<pkg>/)
        "package_name": str,
        "app_name": str,
        "version": str,
    }
    """
    if not os.path.isfile(archive_path) or os.path.getsize(archive_path) < 64:
        raise AndroidError("Tệp gói cài đặt Android rỗng hoặc không tồn tại.")
    if not zipfile.is_zipfile(archive_path):
        raise AndroidError("Tệp tải về không phải gói APK/XAPK hợp lệ (có thể link tải bị chặn).")

    with zipfile.ZipFile(archive_path, "r") as zf:
        names = zf.namelist()
        top_set = {n.strip("/") for n in names if "/" not in n.strip("/")}

        # Standard single APK always contains AndroidManifest.xml at root; otherwise extract bundle members
        if "AndroidManifest.xml" not in top_set:
            apk_members = [n for n in names if n.lower().endswith(".apk") and not n.endswith("/")]
            if not apk_members:
                raise AndroidError("Không tìm thấy tệp .apk nào bên trong gói nén.")

            os.makedirs(unpack_dir, exist_ok=True)
            unpack_real = os.path.realpath(unpack_dir)

            meta_pkg = ""
            meta_name = ""
            meta_ver = ""
            for meta_candidate in ("manifest.json", "info.json"):
                if meta_candidate in top_set:
                    try:
                        raw_meta = json.loads(zf.read(meta_candidate).decode("utf-8", errors="replace"))
                        if isinstance(raw_meta, dict):
                            meta_pkg = str(raw_meta.get("package_name") or raw_meta.get("pname") or "").strip()
                            meta_name = str(raw_meta.get("name") or raw_meta.get("label") or "").strip()
                            meta_ver = str(raw_meta.get("version_name") or raw_meta.get("version") or "").strip()
                    except Exception:
                        pass

            extracted_apks: list[str] = []
            extracted_obbs: list[tuple[str, str]] = []

            for member in names:
                if member.endswith("/"):
                    continue
                low = member.lower()
                if not (low.endswith(".apk") or low.endswith(".obb")):
                    continue
                target = os.path.realpath(os.path.join(unpack_real, member))
                if os.path.commonpath([unpack_real, target]) != unpack_real:
                    raise AndroidError(f"Phát hiện đường dẫn giải nén không an toàn trong XAPK: {member}")
                zf.extract(member, unpack_real)
                if low.endswith(".apk"):
                    extracted_apks.append(target)
                elif low.endswith(".obb"):
                    extracted_obbs.append((target, os.path.basename(member)))

            # Sort so base.apk / main package apk comes first for `adb install-multiple`
            extracted_apks.sort(
                key=lambda p: (
                    0 if os.path.basename(p).lower() in ("base.apk", f"{meta_pkg.lower()}.apk") else 1,
                    len(os.path.basename(p)),
                )
            )
            return {
                "is_bundle": True,
                "apk_files": extracted_apks,
                "obb_files": extracted_obbs,
                "package_name": meta_pkg if is_valid_package_name(meta_pkg) else "",
                "app_name": meta_name,
                "version": meta_ver,
            }

    # `adb install` rejects filenames not ending in `.apk` or `.apex`; normalize into unpack_dir without mutating caller's file
    apk_target = archive_path
    if not apk_target.lower().endswith((".apk", ".apex")):
        os.makedirs(unpack_dir, exist_ok=True)
        apk_target = os.path.join(unpack_dir, "base.apk")
        if os.path.exists(apk_target):
            os.remove(apk_target)
        try:
            os.link(archive_path, apk_target)
        except OSError:
            shutil.copy2(archive_path, apk_target)
    return {
        "is_bundle": False,
        "apk_files": [apk_target],
        "obb_files": [],
        "package_name": "",
        "app_name": "",
        "version": "",
    }


def select_compatible_apks(apk_files: list[str], supported_abis: list[str]) -> list[str]:
    """
    Filter split APKs so incompatible CPU architecture splits do not cause INSTALL_FAILED_INVALID_APK,
    keeping non-ABI splits plus the best ABI match for the active runtime.
    """
    if len(apk_files) <= 1:
        return list(apk_files)

    non_abi: list[str] = []
    by_abi: dict[str, list[str]] = {abi: [] for abi in _ABI_TOKENS}

    for path in apk_files:
        bname = os.path.splitext(os.path.basename(path).lower())[0]
        matched_abi = ""
        for canonical_abi, tokens in _ABI_TOKENS.items():
            if any(
                bname.endswith(f".{tok}")
                or bname.endswith(f"-{tok}")
                or f"config.{tok}" in bname
                or f"split_config.{tok}" in bname
                for tok in tokens
            ):
                matched_abi = canonical_abi
                break
        if matched_abi:
            by_abi[matched_abi].append(path)
        else:
            non_abi.append(path)

    if not any(by_abi.values()):
        return list(apk_files)

    # Pick the first ABI from runtime's preferred order that actually exists in the bundle
    chosen_abi = ""
    pref_order = [a.strip() for a in supported_abis if a.strip()] or ["x86_64", "arm64-v8a", "x86", "armeabi-v7a"]
    for abi in pref_order:
        if by_abi.get(abi):
            chosen_abi = abi
            break
    if not chosen_abi:
        chosen_abi = next((abi for abi, items in by_abi.items() if items), "")

    selected = list(non_abi)
    if chosen_abi:
        selected.extend(by_abi[chosen_abi])
    return selected


def inspect_apk_native_abis(apk_files: list[str]) -> set[str]:
    """Return the set of `lib/<abi>/` native CPU architectures bundled inside `apk_files` (empty if pure DEX/Java)."""
    found: set[str] = set()
    for path in apk_files:
        if not os.path.isfile(path) or not zipfile.is_zipfile(path):
            continue
        try:
            with zipfile.ZipFile(path, "r") as zf:
                for entry in zf.namelist():
                    if entry.startswith("lib/") and entry.lower().endswith(".so"):
                        parts = entry.split("/")
                        if len(parts) >= 3 and parts[1]:
                            found.add(parts[1])
        except Exception:
            continue
    return found


_MALWARE_MARKERS: tuple[bytes, ...] = (
    b"verify that you're not a robot",
    b"verify that you\xe2\x80\x99re not a robot",
    b"pick one app below",
    b"install it from google play",
    b"open the app & use it for ~30 seconds",
    b"open the app &amp; use it for ~30 seconds",
    b"cpabuild",
    b"adbluemedia",
    b"ogads.com",
    b"cpagrip.com",
    b"lockedcontent",
)
_MALWARE_SCAN_EXTS = (".dex", ".html", ".htm", ".js", ".json", ".xml", ".txt")


def verify_apk_safety(apk_files: list[str], app_title: str = "") -> None:
    """Block fake CPA offerwall / human-verification trojan APKs before ADB install."""
    for apk_path in apk_files:
        if not os.path.isfile(apk_path):
            continue
        try:
            if os.path.getsize(apk_path) > 40 * 1024 * 1024 or not zipfile.is_zipfile(apk_path):
                continue
            with zipfile.ZipFile(apk_path, "r") as zf:
                for info in zf.infolist():
                    if info.is_dir() or info.file_size <= 0 or info.file_size > 8 * 1024 * 1024:
                        continue
                    low_name = info.filename.lower()
                    if not (
                        low_name.endswith(_MALWARE_SCAN_EXTS)
                        or low_name.startswith(("assets/", "res/"))
                    ):
                        continue
                    raw_low = zf.read(info).lower()
                    for marker in _MALWARE_MARKERS:
                        utf16_marker = marker.decode("utf-8", errors="ignore").encode("utf-16-le")
                        if marker in raw_low or (utf16_marker and utf16_marker in raw_low):
                            marker_str = marker.decode("utf-8", errors="replace")
                            logger.warning(
                                f"{TAG} Blocked suspected CPA/offerwall trojan APK for {app_title!r}: "
                                f"marker={marker_str!r} in {info.filename}"
                            )
                            raise AndroidError(
                                f"Đã chặn gói cài đặt nghi ngờ giả mạo / quảng cáo độc hại ({marker_str}). "
                                "Bob Gaming không cho phép cài APK yêu cầu tải ứng dụng bên thứ ba."
                            )
        except AndroidError:
            raise
        except Exception as exc:
            logger.debug(f"{TAG} Static safety scan skipped entry in {apk_path}: {exc}")


def write_app_launcher_wrapper(
    app_dir: str,
    package_name: str,
    app_name: str,
    runtime_dir: str,
    metadata: dict,
    platform_name: str = sys.platform,
    avd_name: str = DEFAULT_AVD_NAME,
) -> str:
    """Create per-app metadata + cross-platform launcher script so Library & Steam shortcuts work natively."""
    os.makedirs(app_dir, exist_ok=True)
    meta_path = os.path.join(app_dir, "android_app.json")
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)

    avd = (avd_name or DEFAULT_AVD_NAME).strip() or DEFAULT_AVD_NAME
    emu_flags = (
        "-gpu host -feature GLESDynamicVersion -feature -WiFiPacketStream -feature -GLPipeChecksum "
        "-feature Vulkan -feature GLDirectMem -feature AsyncComposeSupport "
        "-dns-server 8.8.8.8,1.1.1.1 -netdelay none -netspeed full -no-snapshot -no-metrics -crash-report-mode never"
    )
    if platform_name == "win32":
        script_path = os.path.join(app_dir, "launch_android.cmd")
        adb_exe = os.path.join(runtime_dir, "platform-tools", "adb.exe")
        emu_exe = os.path.join(runtime_dir, "emulator", "emulator.exe")
        avd_home = os.path.join(runtime_dir, "avd")
        content = (
            "@echo off\r\n"
            f"REM Bob Gaming Android Launcher - {app_name} ({package_name})\r\n"
            f'set "ADB_EXE={adb_exe}"\r\n'
            f'if not exist "%ADB_EXE%" set "ADB_EXE=adb"\r\n'
            f'"%ADB_EXE%" get-state >nul 2>&1\r\n'
            "if errorlevel 1 (\r\n"
            f'  if exist "{emu_exe}" (\r\n'
            f'    set "ANDROID_SDK_ROOT={runtime_dir}"\r\n'
            f'    if exist "{avd_home}" set "ANDROID_AVD_HOME={avd_home}"\r\n'
            f'    start "" "{emu_exe}" -avd "{avd}" {emu_flags}\r\n'
            '    "%ADB_EXE%" wait-for-device\r\n'
            "    timeout /t 8 /nobreak >nul\r\n"
            "  )\r\n"
            ")\r\n"
            f'"%ADB_EXE%" shell monkey -p {package_name} -c android.intent.category.LAUNCHER 1 >nul 2>&1\r\n'
        )
        with open(script_path, "w", encoding="utf-8", newline="\r\n") as f:
            f.write(content)
        return script_path

    script_path = os.path.join(app_dir, "launch_android.sh")
    adb_bin = os.path.join(runtime_dir, "platform-tools", "adb")
    emu_bin = os.path.join(runtime_dir, "emulator", "emulator")
    avd_home = os.path.join(runtime_dir, "avd")
    content = (
        "#!/usr/bin/env bash\n"
        f"# Bob Gaming Android Launcher - {app_name} ({package_name})\n"
        "if command -v waydroid >/dev/null 2>&1 && [ -d /var/lib/waydroid ]; then\n"
        f"  exec waydroid app launch '{package_name}'\n"
        "fi\n"
        f'ADB_BIN="{adb_bin}"\n'
        '[ -x "$ADB_BIN" ] || ADB_BIN="adb"\n'
        'if ! "$ADB_BIN" get-state >/dev/null 2>&1; then\n'
        f'  if [ -x "{emu_bin}" ]; then\n'
        f'    export ANDROID_SDK_ROOT="{runtime_dir}"\n'
        f'    [ -d "{avd_home}" ] && export ANDROID_AVD_HOME="{avd_home}"\n'
        f'    "{emu_bin}" -avd "{avd}" {emu_flags} >/dev/null 2>&1 &\n'
        '    "$ADB_BIN" wait-for-device\n'
        "    sleep 8\n"
        "  fi\n"
        "fi\n"
        f'exec "$ADB_BIN" shell monkey -p "{package_name}" -c android.intent.category.LAUNCHER 1\n'
    )
    with open(script_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)
    try:
        os.chmod(script_path, 0o755 | stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass
    return script_path


class AndroidPackageInstaller:
    """Downloads, unpacks, and installs .apk / .xapk / .apks + OBB packages into an Android runtime."""

    def __init__(self, runtime_mgr: AndroidRuntimeManager):
        self.runtime_mgr = runtime_mgr

    def download_to_file(
        self,
        url: str,
        dest_path: str,
        progress_cb: Callable[[int, int, int], None] | None = None,
        is_cancelled: Callable[[], bool] | None = None,
    ) -> str:
        """Download a single file to dest_path using aria2c (or urllib Range/stream fallback)."""
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
        t0 = time.monotonic()

        aria2 = find_aria2c()
        if aria2 and "apkpure.com" not in url.lower():
            if run_aria2_http_download(
                aria2_bin=aria2,
                url=url,
                dest_file=dest_path,
                user_agent=DEFAULT_HEADERS["User-Agent"],
                progress_cb=progress_cb,
                is_cancelled=is_cancelled,
                cancel_message="Đã hủy tải gói Android.",
                log_tag=TAG,
            ):
                return dest_path
            logger.warning(f"{TAG} aria2c could not fetch {url}, trying urllib stream fallback")

        req = urllib.request.Request(url, headers=DEFAULT_HEADERS)
        try:
            with urllib.request.urlopen(req, timeout=25.0) as resp:
                status = getattr(resp, "status", 200)
                if status >= 400:
                    raise AndroidError(f"HTTP {status}")
                total = int(resp.headers.get("Content-Length") or 0)
                done = 0
                t_dl = time.monotonic()
                with open(dest_path, "wb") as out_f:
                    while True:
                        if is_cancelled and is_cancelled():
                            raise AndroidError("Đã hủy tải gói Android.")
                        chunk = resp.read(256 * 1024)
                        if not chunk:
                            break
                        out_f.write(chunk)
                        done += len(chunk)
                        if progress_cb:
                            spd = int(done / max(0.05, time.monotonic() - t_dl))
                            progress_cb(done, total, spd)
        except AndroidError:
            raise
        except Exception as exc:
            logger.warning(f"{TAG} Download failed for {url} in {time.monotonic() - t0:.2f}s: {exc}")
            raise AndroidError(f"Không thể tải gói cài đặt: {exc}") from exc

        return dest_path

    def _query_third_party_packages(self, runtime: RuntimeInfo) -> set[str]:
        if not runtime.adb_path or not runtime.adb_serial:
            return set()
        try:
            res = self.runtime_mgr.run_adb(
                runtime.adb_path, ["shell", "pm", "list", "packages", "-3"], serial=runtime.adb_serial, timeout=10.0
            )
            pkgs = set()
            for line in (res.stdout or "").splitlines():
                line = line.strip()
                if line.startswith("package:"):
                    pkgs.add(line.split("package:", 1)[1].strip())
            return pkgs
        except Exception:
            return set()

    def _query_supported_abis(self, runtime: RuntimeInfo) -> list[str]:
        if not runtime.adb_path or not runtime.adb_serial:
            return ["x86_64", "x86", "arm64-v8a", "armeabi-v7a"]
        try:
            res = self.runtime_mgr.run_adb(
                runtime.adb_path, ["shell", "getprop", "ro.product.cpu.abilist"], serial=runtime.adb_serial, timeout=6.0
            )
            raw = (res.stdout or "").strip()
            if raw:
                return [x.strip() for x in raw.split(",") if x.strip()]
        except Exception:
            pass
        return ["x86_64", "x86", "arm64-v8a", "armeabi-v7a"]

    def _push_obb_files(
        self,
        ready: RuntimeInfo,
        pkg: str,
        obb_list: list[tuple[str, str]],
        is_cancelled: Callable[[], bool] | None = None,
    ) -> None:
        """
        Copy `.obb` expansion files into Android's OBB directory.
        On Android 11+ (API 30+ Scoped Storage), `/sdcard/Android/obb/<pkg>` is owned `2770 u0_aXXX:ext_obb_rw`
        and blocks `adbd` (`uid=2000 shell`) `secure_mkdirs`; staging to `/data/local/tmp` and moving via `su 0`
        bypasses FUSE overhead and sets exact package UID + `ext_obb_rw` + SELinux context in O(1) rename time.
        """
        t_obb = time.monotonic()
        q_pkg = shlex.quote(pkg)
        su_res = self.runtime_mgr.run_adb(
            ready.adb_path, ["shell", "su", "0", "id"], serial=ready.adb_serial, timeout=8.0
        )
        has_su = su_res.returncode == 0 and "uid=0" in (su_res.stdout or "")

        if has_su:
            for idx, (local_obb, obb_name) in enumerate(obb_list):
                if is_cancelled and is_cancelled():
                    raise AndroidError("Đã hủy chép tệp OBB.")
                obb_base = os.path.basename(obb_name)
                size_mb = (os.path.getsize(local_obb) / (1024 * 1024)) if os.path.isfile(local_obb) else 0.0
                push_timeout = max(300.0, size_mb * 2.5)
                stage_remote = f"/data/local/tmp/_bob_obb_{os.getpid()}_{idx}.tmp"
                q_stage = shlex.quote(stage_remote)
                q_obb_base = shlex.quote(obb_base)
                try:
                    push_res = self.runtime_mgr.run_adb(
                        ready.adb_path,
                        ["push", local_obb, stage_remote],
                        serial=ready.adb_serial,
                        timeout=push_timeout,
                    )
                    if push_res.returncode != 0:
                        raise AndroidError(
                            f"Không thể chép tệp OBB {obb_base}: {(push_res.stderr or push_res.stdout or '').strip()}"
                        )
                    root_script = "\n".join(
                        [
                            "set -e",
                            f"APP_UID=$(stat -c %u /data/data/{q_pkg} 2>/dev/null || true)",
                            f"if [ -d /data/media/0 ]; then OBB_DIR=/data/media/0/Android/obb/{q_pkg}; "
                            f"else OBB_DIR=/sdcard/Android/obb/{q_pkg}; fi",
                            'DEST="$OBB_DIR/"' + q_obb_base,
                            'mkdir -p "$OBB_DIR"',
                            f'mv -f {q_stage} "$DEST" 2>/dev/null || cp -f {q_stage} "$DEST"',
                            f"rm -f {q_stage}",
                            'OWNER="${APP_UID:-media_rw}"',
                            'chown "$OWNER:ext_obb_rw" "$OBB_DIR" "$DEST" 2>/dev/null || '
                            'chown "${APP_UID:-1023}:1079" "$OBB_DIR" "$DEST" 2>/dev/null || true',
                            'chmod 2770 "$OBB_DIR"',
                            'chmod 0664 "$DEST"',
                            'restorecon -FR "$OBB_DIR" >/dev/null 2>&1 || true',
                            'test -s "$DEST"',
                        ]
                    )
                    b64_script = base64.b64encode(root_script.encode("utf-8")).decode("ascii")
                    mv_res = self.runtime_mgr.run_adb(
                        ready.adb_path,
                        ["shell", f"echo {b64_script} | base64 -d | su 0 sh"],
                        serial=ready.adb_serial,
                        timeout=60.0,
                    )
                    if mv_res.returncode != 0:
                        raise AndroidError(
                            f"Không thể gắn quyền OBB {obb_base} cho {pkg}: {(mv_res.stderr or mv_res.stdout or '').strip()}"
                        )
                finally:
                    try:
                        self.runtime_mgr.run_adb(
                            ready.adb_path, ["shell", "rm", "-f", stage_remote], serial=ready.adb_serial, timeout=8.0
                        )
                    except Exception:
                        pass
            logger.info(
                f"{TAG} Installed {len(obb_list)} OBB file(s) for {pkg} via root media staging in {time.monotonic() - t_obb:.2f}s"
            )
            return

        remote_obb_dir = f"/sdcard/Android/obb/{pkg}"
        self.runtime_mgr.run_adb(
            ready.adb_path,
            [
                "shell",
                "cmd appops set com.android.shell MANAGE_EXTERNAL_STORAGE allow >/dev/null 2>&1 ; "
                "cmd appops set com.android.shell LEGACY_STORAGE allow >/dev/null 2>&1 ; "
                f"mkdir -p {shlex.quote(remote_obb_dir)}",
            ],
            serial=ready.adb_serial,
            timeout=15.0,
        )
        for local_obb, obb_name in obb_list:
            if is_cancelled and is_cancelled():
                raise AndroidError("Đã hủy chép tệp OBB.")
            obb_base = os.path.basename(obb_name)
            size_mb = (os.path.getsize(local_obb) / (1024 * 1024)) if os.path.isfile(local_obb) else 0.0
            push_res = self.runtime_mgr.run_adb(
                ready.adb_path,
                ["push", local_obb, f"{remote_obb_dir}/{obb_base}"],
                serial=ready.adb_serial,
                timeout=max(300.0, size_mb * 2.5),
            )
            if push_res.returncode != 0:
                raise AndroidError(
                    f"Không thể chép tệp OBB {obb_base}: {(push_res.stderr or push_res.stdout or '').strip()}"
                )
        logger.info(f"{TAG} Installed {len(obb_list)} OBB file(s) for {pkg} via direct push in {time.monotonic() - t_obb:.2f}s")

    def install_archive_into_runtime(
        self,
        archive_path: str,
        runtime: RuntimeInfo,
        app: AndroidApp,
        android_root: str,
        extra_split_files: list[str] | None = None,
        extra_obb_files: list[tuple[str, str]] | None = None,
        progress_cb: Callable[[int, str], None] | None = None,
        is_cancelled: Callable[[], bool] | None = None,
    ) -> tuple[str, str, str]:
        """
        Install a downloaded or local .apk/.xapk/.apks archive into `runtime`, push any OBBs,
        write launcher wrapper, and return (resolved_package_name, app_dir, launcher_script_path).
        """
        t0 = time.monotonic()
        temp_unpack = os.path.join(
            get_apps_dir(android_root),
            "_unpack_" + sanitize_package_dir_name(app.package_name or os.path.basename(archive_path)),
        )
        try:
            if progress_cb:
                progress_cb(72, "Đang kiểm tra cấu trúc gói APK / XAPK...")
            bundle = inspect_package_bundle(archive_path, temp_unpack)
            pkg = bundle["package_name"] or (app.package_name if is_valid_package_name(app.package_name) else "")
            app_title = app.name or bundle["app_name"] or os.path.splitext(os.path.basename(archive_path))[0]
            version = app.version or bundle["version"]

            apk_list = list(bundle["apk_files"])
            if extra_split_files:
                apk_list.extend(extra_split_files)

            obb_list = list(bundle["obb_files"])
            if extra_obb_files:
                obb_list.extend(extra_obb_files)

            verify_apk_safety(apk_list, app_title)

            if runtime.kind == RUNTIME_PORTABLE_SDK:
                # Managed runtimes have fixed ABIs: refuse before a ~40 s boot (the caller may route the
                # package to the Android 11 ARM32 runtime instead).
                static_abis = list(get_portable_profile(runtime.runtime_id).abis)
                pre_abis = inspect_apk_native_abis(select_compatible_apks(apk_list, static_abis))
                if pre_abis and pre_abis.isdisjoint(static_abis):
                    logger.warning(
                        f"{TAG} Package {app_title!r} requires ABI [{', '.join(sorted(pre_abis))}] which "
                        f"{runtime.label!r} cannot run; refusing before boot"
                    )
                    raise AndroidAbiMismatchError(
                        f"Game/ứng dụng '{app_title}' chỉ có mã CPU ({', '.join(sorted(pre_abis))}) mà "
                        f"{runtime.label} không chạy được. Hãy chọn 'Bob Android 11 (ARM64/ARM32)' để chạy game 32-bit.",
                        package_abis=pre_abis,
                        app_title=app_title,
                    )

            if progress_cb:
                progress_cb(76, f"Đang khởi động {runtime.label}...")
            ready = self.runtime_mgr.ensure_running(
                runtime,
                is_cancelled=is_cancelled,
                progress_cb=(lambda p, m: progress_cb(76 + int(p * 0.08), m)) if progress_cb else None,
            )

            before_pkgs = self._query_third_party_packages(ready) if not pkg else set()

            if progress_cb:
                progress_cb(85, f"Đang cài đặt {app_title} vào máy...")

            if ready.kind == RUNTIME_WAYDROID and len(apk_list) == 1 and not obb_list and not ready.adb_serial:
                waydroid_bin = ready.emulator_path or shutil.which("waydroid") or "waydroid"
                res = subprocess.run(
                    [waydroid_bin, "app", "install", apk_list[0]],
                    capture_output=True,
                    text=True,
                    timeout=180.0,
                    **_subprocess_kwargs(),
                )
                if res.returncode != 0:
                    raise AndroidError(f"Waydroid cài đặt thất bại: {(res.stderr or res.stdout or '').strip()}")
            else:
                abis = self._query_supported_abis(ready)
                compat_apks = select_compatible_apks(apk_list, abis)
                pkg_abis = inspect_apk_native_abis(compat_apks)
                if pkg_abis and pkg_abis.isdisjoint(abis):
                    abi_need = ", ".join(sorted(pkg_abis))
                    abi_have = ", ".join(abis)
                    logger.warning(
                        f"{TAG} Package {app_title!r} requires ABI [{abi_need}] but runtime {ready.label!r} only supports [{abi_have}]"
                    )
                    raise AndroidAbiMismatchError(
                        f"Game/ứng dụng yêu cầu kiến trúc CPU ({abi_need}) nhưng Engine hiện tại chỉ hỗ trợ ({abi_have}) "
                        "[INSTALL_FAILED_NO_MATCHING_ABIS]. Hãy chọn 'Bob Android 11 (ARM64/ARM32)' để chạy game 32-bit.",
                        package_abis=pkg_abis,
                        app_title=app_title,
                    )
                adb_cmd = (
                    ["install", "-r", "-g", compat_apks[0]]
                    if len(compat_apks) == 1
                    else ["install-multiple", "-r", "-g", *compat_apks]
                )
                res = self.runtime_mgr.run_adb(ready.adb_path, adb_cmd, serial=ready.adb_serial, timeout=300.0)
                combined = f"{res.stdout or ''}\n{res.stderr or ''}".strip()
                if "INSTALL_FAILED_DEPRECATED_SDK_VERSION" in combined:
                    adb_cmd = [adb_cmd[0], "--bypass-low-target-sdk-block", *adb_cmd[1:]]
                    res = self.runtime_mgr.run_adb(ready.adb_path, adb_cmd, serial=ready.adb_serial, timeout=300.0)
                    combined = f"{res.stdout or ''}\n{res.stderr or ''}".strip()
                if res.returncode != 0 or "Success" not in combined:
                    # Extract short ADB failure token (e.g. INSTALL_FAILED_INSUFFICIENT_STORAGE)
                    fail_m = re.search(r"INSTALL_FAILED_[A-Z0-9_]+", combined)
                    reason = fail_m.group(0) if fail_m else (combined[:180] or f"exit={res.returncode}")
                    logger.error(f"{TAG} ADB install failed for {app_title!r}: {reason}")
                    if reason == "INSTALL_FAILED_NO_MATCHING_ABIS":
                        raise AndroidAbiMismatchError(
                            f"Engine '{ready.label}' thiếu bộ dịch kiến trúc CPU của '{app_title}' ({reason}). "
                            "Hãy chọn 'Bob Android 11 (ARM64/ARM32)' để chạy game 32-bit.",
                            package_abis=pkg_abis,
                            app_title=app_title,
                        )
                    raise AndroidError(f"Cài đặt gói Android thất bại ({reason}).")

            if not pkg:
                after_pkgs = self._query_third_party_packages(ready)
                diff = sorted(after_pkgs - before_pkgs)
                if diff:
                    pkg = diff[0]
                else:
                    stem = re.sub(r"[^a-zA-Z0-9_.]", "", os.path.splitext(os.path.basename(archive_path))[0]).lower()
                    pkg = next((p for p in after_pkgs if stem and stem in p.lower()), "")
                if not is_valid_package_name(pkg):
                    pkg = f"local.app.{sanitize_package_dir_name(app_title).lower()}"

            if obb_list and ready.adb_path and ready.adb_serial:
                if progress_cb:
                    progress_cb(93, "Đang chép dữ liệu OBB vào bộ nhớ Android...")
                try:
                    self._push_obb_files(ready, pkg, obb_list, is_cancelled=is_cancelled)
                except Exception:
                    logger.warning(f"{TAG} Rolling back APK {pkg} because OBB installation failed")
                    try:
                        self.runtime_mgr.uninstall_package(ready, pkg)
                    except Exception:
                        pass
                    raise

            app_dir = os.path.join(get_apps_dir(android_root), sanitize_package_dir_name(pkg))
            metadata = {
                "package_name": pkg,
                "name": app_title,
                "version": version,
                "kind": app.kind or CATEGORY_GAMES,
                "source": app.source or SOURCE_LOCAL,
                "icon_url": app.icon_url,
                "obb_files": [os.path.basename(n) for _, n in obb_list],
                "installed_at": time.time(),
                "runtime_id": ready.runtime_id,
            }
            launcher_path = write_app_launcher_wrapper(
                app_dir=app_dir,
                package_name=pkg,
                app_name=app_title,
                runtime_dir=ready.root_dir or os.path.join(android_root, "AndroidRuntime"),
                metadata=metadata,
                avd_name=ready.avd_name or DEFAULT_AVD_NAME,
            )
            logger.info(
                f"{TAG} Installed {app_title!r} ({pkg}) on {ready.label} in {time.monotonic() - t0:.2f}s -> {launcher_path}"
            )
            return pkg, app_dir, launcher_path
        finally:
            shutil.rmtree(temp_unpack, ignore_errors=True)
