"""Low-latency embedded Android display & input stream via scrcpy-server v3.1 + FFmpeg H.264."""

from __future__ import annotations

from collections import deque
import ctypes
import glob
import logging
import os
import secrets
import socket
import struct
import subprocess
import sys
import threading
import time

from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QImage

from app.core.android.models import AndroidError, RuntimeInfo
from app.core.android.runtime import (
    AndroidRuntimeManager,
    DEFAULT_AVD_NAME,
    _subprocess_kwargs,
    get_emulator_settings,
)
from app.core.remote.stream.video import ffmpeg_api as ff

logger = logging.getLogger(__name__)
TAG = "[Android/Stream]"

SCRCPY_FLAG_CONFIG = 1 << 63
SCRCPY_FLAG_KEY_FRAME = 1 << 62

AMOTION_EVENT_ACTION_DOWN = 0
AMOTION_EVENT_ACTION_UP = 1
AMOTION_EVENT_ACTION_MOVE = 2

AKEY_EVENT_ACTION_DOWN = 0
AKEY_EVENT_ACTION_UP = 1


def pack_inject_keycode(action: int, keycode: int, repeat: int = 0, meta_state: int = 0) -> bytes:
    """Build scrcpy v3.1 TYPE_INJECT_KEYCODE (0) binary control packet (14 bytes)."""
    return struct.pack(">BBiii", 0, action & 0xFF, int(keycode), int(repeat), int(meta_state))


def pack_inject_text(text: str) -> bytes:
    """Build scrcpy v3.1 TYPE_INJECT_TEXT (1) binary control packet."""
    raw = (text or "").encode("utf-8")[:300]
    return b"\x01" + struct.pack(">I", len(raw)) + raw


def pack_inject_touch(
    action: int,
    x: int,
    y: int,
    width: int,
    height: int,
    pointer_id: int = -2,
) -> bytes:
    """Build scrcpy v3.1 TYPE_INJECT_TOUCH_EVENT (2) binary control packet (32 bytes)."""
    w = max(1, int(width))
    h = max(1, int(height))
    cx = max(0, min(w - 1, int(x)))
    cy = max(0, min(h - 1, int(y)))
    is_pressed = action in (AMOTION_EVENT_ACTION_DOWN, AMOTION_EVENT_ACTION_MOVE)
    pressure = 0xFFFF if is_pressed else 0
    action_btn = 1 if action in (AMOTION_EVENT_ACTION_DOWN, AMOTION_EVENT_ACTION_UP) else 0
    buttons = 1 if is_pressed else 0
    return struct.pack(
        ">BBqiiHHHII",
        2,
        action & 0xFF,
        int(pointer_id),
        cx,
        cy,
        w & 0xFFFF,
        h & 0xFFFF,
        pressure,
        action_btn,
        buttons,
    )


def pack_inject_scroll(
    x: int,
    y: int,
    width: int,
    height: int,
    hscroll: float,
    vscroll: float,
    buttons: int = 0,
) -> bytes:
    """Build scrcpy v3.1 TYPE_INJECT_SCROLL_EVENT (3) binary control packet (21 bytes)."""
    w = max(1, int(width))
    h = max(1, int(height))
    cx = max(0, min(w - 1, int(x)))
    cy = max(0, min(h - 1, int(y)))
    hs = max(-32768, min(32767, int(round(hscroll * 2048.0))))
    vs = max(-32768, min(32767, int(round(vscroll * 2048.0))))
    return struct.pack(">BiiHHhhI", 3, cx, cy, w & 0xFFFF, h & 0xFFFF, hs, vs, int(buttons))


def pack_rotate_device() -> bytes:
    """Build scrcpy v3.1 TYPE_ROTATE_DEVICE (11) binary control packet."""
    return b"\x0b"


def _recv_exact(sock: socket.socket, size: int) -> bytes:
    buf = bytearray()
    while len(buf) < size:
        chunk = sock.recv(size - len(buf))
        if not chunk:
            raise EOFError("scrcpy socket closed")
        buf.extend(chunk)
    return bytes(buf)


def _pick_free_tcp_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


class EmulatorWindowController:
    """Hides or restores external QEMU/Qt emulator windows on Windows when docked/popped out."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._hidden_hwnds: set[int] = set()

    @staticmethod
    def _find_emulator_pids(avd_name: str, adb_serial: str) -> set[int]:
        pids: set[int] = set()
        if sys.platform != "win32":
            return pids
        port_str = adb_serial.split("-")[-1] if adb_serial.startswith("emulator-") else ""
        local_app = os.environ.get("LOCALAPPDATA") or ""
        run_dir = os.path.join(local_app, "Temp", "avd", "running")
        if os.path.isdir(run_dir):
            for ini_p in glob.glob(os.path.join(run_dir, "pid_*.ini")):
                base = os.path.basename(ini_p)
                pid_part = base.removeprefix("pid_").removesuffix(".ini")
                if not pid_part.isdigit():
                    continue
                try:
                    txt = open(ini_p, "r", encoding="utf-8", errors="replace").read()
                except OSError:
                    continue
                ini_lines = {ln.strip() for ln in txt.splitlines()}
                # Exact line match: "avd.id=BobAndroid" must not match the "BobAndroid11" runtime.
                if (port_str and f"port.serial={port_str}" in ini_lines) or (
                    avd_name and f"avd.id={avd_name}" in ini_lines
                ):
                    pids.add(int(pid_part))
        return pids

    def hide_external_windows(self, avd_name: str = DEFAULT_AVD_NAME, adb_serial: str = "") -> int:
        """Hide visible top-level QEMU windows and remember exact HWNDs for clean pop-out restore."""
        if sys.platform != "win32":
            return 0
        try:
            user32 = ctypes.windll.user32
            pids = self._find_emulator_pids(avd_name, adb_serial)
            port_suffix = f":{adb_serial.split('-')[-1]}" if adb_serial.startswith("emulator-") else ""
            newly_hidden: list[int] = []

            class _RECT(ctypes.Structure):
                _fields_ = [
                    ("left", ctypes.c_long),
                    ("top", ctypes.c_long),
                    ("right", ctypes.c_long),
                    ("bottom", ctypes.c_long),
                ]

            enum_proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

            def _cb(hwnd, _lparam):
                if not hwnd or not user32.IsWindowVisible(hwnd):
                    return True
                pid = ctypes.c_ulong(0)
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                length = user32.GetWindowTextLengthW(hwnd)
                title = ""
                if length > 0:
                    tbuf = ctypes.create_unicode_buffer(length + 1)
                    user32.GetWindowTextW(hwnd, tbuf, length + 1)
                    title = tbuf.value
                matched_pid = pid.value in pids
                matched_title = bool(
                    title
                    and "Android Emulator" in title
                    and ((avd_name and f"{avd_name}:" in title) or (port_suffix and port_suffix in title))
                )
                if not (matched_pid or matched_title):
                    return True
                if title in ("MSCTFIME UI", "Default IME"):
                    return True
                rc = _RECT()
                user32.GetWindowRect(hwnd, ctypes.byref(rc))
                w = rc.right - rc.left
                h = rc.bottom - rc.top
                if w < 24 or h < 24:
                    return True
                user32.ShowWindow(hwnd, 0)  # SW_HIDE
                newly_hidden.append(int(hwnd))
                return True

            cb_ref = enum_proc_t(_cb)
            user32.EnumWindows(cb_ref, 0)
            with self._lock:
                self._hidden_hwnds.update(newly_hidden)
            if newly_hidden:
                logger.info(f"{TAG} Docked emulator window(s) into Bob Gaming (hid {len(newly_hidden)} HWND(s))")
            return len(newly_hidden)
        except Exception as exc:
            logger.debug(f"{TAG} Could not hide external emulator window: {exc}")
            return 0

    def clear_tracked_windows(self) -> None:
        """Forget tracked HWNDs on shutdown without unhiding dying emulator windows."""
        with self._lock:
            self._hidden_hwnds.clear()

    def show_external_windows(self, avd_name: str = DEFAULT_AVD_NAME, adb_serial: str = "") -> int:
        """Pop out QEMU window(s), including instances started hidden via `-qt-hide-window`."""
        if sys.platform != "win32":
            return 0
        with self._lock:
            hwnds = list(self._hidden_hwnds)
            self._hidden_hwnds.clear()
        restored = 0
        try:
            user32 = ctypes.windll.user32
            if not hwnds:
                pids = self._find_emulator_pids(avd_name, adb_serial)
                port_suffix = f":{adb_serial.split('-')[-1]}" if adb_serial.startswith("emulator-") else ""
                found: list[int] = []
                enum_proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

                def _discover_cb(hwnd, _lparam):
                    if not hwnd:
                        return True
                    pid = ctypes.c_ulong(0)
                    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                    length = user32.GetWindowTextLengthW(hwnd)
                    title = ""
                    if length > 0:
                        tbuf = ctypes.create_unicode_buffer(length + 1)
                        user32.GetWindowTextW(hwnd, tbuf, length + 1)
                        title = tbuf.value
                    cbuf = ctypes.create_unicode_buffer(128)
                    user32.GetClassNameW(hwnd, cbuf, 128)
                    cls_name = cbuf.value
                    matched_title = bool(
                        title
                        and "Android Emulator" in title
                        and ((avd_name and f"{avd_name}:" in title) or (port_suffix and port_suffix in title))
                    )
                    matched_qt_pid = pid.value in pids and "QWindowIcon" in cls_name and bool(title)
                    if matched_title or matched_qt_pid:
                        found.append(int(hwnd))
                    return True

                cb_ref = enum_proc_t(_discover_cb)
                user32.EnumWindows(cb_ref, 0)
                hwnds = found

            main_hwnd = 0
            for hwnd in hwnds:
                if user32.IsWindow(hwnd):
                    user32.ShowWindow(hwnd, 5)  # SW_SHOW
                    restored += 1
                    if not main_hwnd:
                        main_hwnd = hwnd
            if main_hwnd:
                user32.SetForegroundWindow(main_hwnd)
            if restored:
                logger.info(f"{TAG} Popped out external emulator window ({restored} HWND(s) shown)")
        except Exception as exc:
            logger.debug(f"{TAG} Could not show external emulator window: {exc}")
        return restored


class _H264StreamDecoder:
    """Zero-copy-padded FFmpeg H.264 slice decoder outputting RGB32 QImages."""

    def __init__(self) -> None:
        ff.ensure_ffmpeg_loaded()
        try:
            ff.av_log_set_level(-8)
        except Exception:
            pass
        codec = ff.avcodec_find_decoder_by_name(b"h264")
        if not codec:
            raise AndroidError("Không tìm thấy bộ giải mã H.264 (FFmpeg avcodec).")
        self._ctx = ff.avcodec_alloc_context3(codec)
        if not self._ctx:
            raise AndroidError("Không thể khởi tạo ngữ cảnh giải mã H.264.")
        ff.configure_codec_context(self._ctx, hardware=False, strict_err_detect=False)
        rc = ff.avcodec_open2(self._ctx, codec, None)
        if rc < 0:
            ctx_ptr = ctypes.c_void_p(self._ctx)
            ff.avcodec_free_context(ctypes.byref(ctx_ptr))
            self._ctx = 0
            raise AndroidError(f"Không thể mở bộ giải mã H.264: {ff.av_strerror_str(rc)}")
        self._pkt = ff.av_packet_alloc()
        self._frame = ff.av_frame_alloc()
        self._sws_ctx: int = 0
        self._sws_key: tuple[int, int, int] = (0, 0, -1)

    def decode(self, payload: bytes, is_key: bool) -> QImage | None:
        if not self._ctx or not payload:
            return None
        padded_len = len(payload) + ff.AV_INPUT_BUFFER_PADDING_SIZE
        in_buf = (ctypes.c_char * padded_len)()
        ctypes.memmove(in_buf, payload, len(payload))
        ff.packet_set_data(self._pkt, ctypes.addressof(in_buf), len(payload), is_key)
        send_rc = ff.avcodec_send_packet(self._ctx, self._pkt)
        if send_rc < 0 and send_rc != ff.AVERROR_EAGAIN:
            return None

        latest_img: QImage | None = None
        while True:
            recv_rc = ff.avcodec_receive_frame(self._ctx, self._frame)
            if recv_rc < 0:
                break
            w, h = ff.frame_get_dimensions(self._frame)
            pix_fmt = ff.frame_get_format(self._frame)
            if w <= 0 or h <= 0:
                ff.av_frame_unref(self._frame)
                continue
            key = (w, h, pix_fmt)
            if key != self._sws_key or not self._sws_ctx:
                if self._sws_ctx:
                    ff.sws_freeContext(self._sws_ctx)
                self._sws_ctx = ff.sws_getContext(
                    w, h, pix_fmt, w, h, ff.PIX_FMT_BGR0, ff.SWS_FAST_BILINEAR, None, None, None
                )
                self._sws_key = key

            img = QImage(w, h, QImage.Format.Format_RGB32)
            planes, strides = ff.frame_get_planes(self._frame)
            src_data = (ctypes.c_void_p * 8)(*planes)
            src_stride = (ctypes.c_int * 8)(*strides)
            dst_ptr = ctypes.addressof(ctypes.c_ubyte.from_buffer(img.bits()))
            dst_stride = img.bytesPerLine()
            dst_data = (ctypes.c_void_p * 8)(dst_ptr, 0, 0, 0, 0, 0, 0, 0)
            dst_lines = (ctypes.c_int * 8)(dst_stride, 0, 0, 0, 0, 0, 0, 0)
            ff.sws_scale(self._sws_ctx, src_data, src_stride, 0, h, dst_data, dst_lines)
            ff.av_frame_unref(self._frame)
            latest_img = img
        return latest_img

    def close(self) -> None:
        if self._sws_ctx:
            ff.sws_freeContext(self._sws_ctx)
            self._sws_ctx = 0
        if self._frame:
            fptr = ctypes.c_void_p(self._frame)
            ff.av_frame_free(ctypes.byref(fptr))
            self._frame = 0
        if self._pkt:
            pptr = ctypes.c_void_p(self._pkt)
            ff.av_packet_free(ctypes.byref(pptr))
            self._pkt = 0
        if self._ctx:
            cptr = ctypes.c_void_p(self._ctx)
            ff.avcodec_free_context(ctypes.byref(cptr))
            self._ctx = 0


class ScrcpyStreamClient(QObject):
    """Background scrcpy v3.1 video + touch/key client delivering coalesced QImage frames via Qt Signal."""

    frame_ready = Signal(object)
    stream_started = Signal(int, int)
    stream_stopped = Signal(str)
    stream_error = Signal(str)

    def __init__(self, runtime_mgr: AndroidRuntimeManager, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._runtime_mgr = runtime_mgr
        self._lock = threading.RLock()
        self._send_lock = threading.Lock()
        self._gen = 0
        self._running = False
        self._video_sock: socket.socket | None = None
        self._ctrl_sock: socket.socket | None = None
        self._server_proc: subprocess.Popen | None = None
        self._video_size: tuple[int, int] = (0, 0)
        self._latest_frame: QImage | None = None
        self._frame_pending = False
        self._active_serial: str = ""
        self._frame_samples: deque[tuple[float, float, int]] = deque(maxlen=240)
        self._dropped_frames: int = 0

    @property
    def is_streaming(self) -> bool:
        with self._lock:
            return self._running

    @property
    def video_size(self) -> tuple[int, int]:
        with self._lock:
            return self._video_size

    @property
    def active_serial(self) -> str:
        with self._lock:
            return self._active_serial

    def snapshot_stats(self) -> dict:
        """Return lock-safe rolling 1s FPS, decode latency (ms), bitrate (Mbps), and UI frame drops."""
        now = time.monotonic()
        cutoff = now - 1.0
        with self._lock:
            running = self._running
            w, h = self._video_size
            dropped = self._dropped_frames
            while self._frame_samples and self._frame_samples[0][0] < cutoff:
                self._frame_samples.popleft()
            samples = list(self._frame_samples)
        count = len(samples)
        if count > 0:
            avg_dec = sum(s[1] for s in samples) / count
            total_bytes = sum(s[2] for s in samples)
            bitrate_mbps = (total_bytes * 8.0) / 1_000_000.0
        else:
            avg_dec = 0.0
            bitrate_mbps = 0.0
        return {
            "streaming": running,
            "fps": count,
            "decode_ms": round(avg_dec, 1),
            "bitrate_mbps": round(bitrate_mbps, 2),
            "dropped": dropped,
            "width": w,
            "height": h,
        }

    def take_latest_frame(self) -> QImage | None:
        with self._lock:
            self._frame_pending = False
            return self._latest_frame

    def start_stream(self, runtime: RuntimeInfo) -> None:
        """Start or attach scrcpy stream to a booted Android runtime on a background worker thread."""
        with self._lock:
            if self._running and runtime.adb_serial and self._active_serial == runtime.adb_serial:
                return
            self._gen += 1
            gen = self._gen
            self._teardown_handles_locked()
            self._running = True
            self._active_serial = runtime.adb_serial or ""
            self._frame_pending = False
            self._frame_samples.clear()
            self._dropped_frames = 0

        worker = threading.Thread(
            target=self._worker_loop,
            args=(gen, runtime),
            name=f"android-scrcpy-{gen}",
            daemon=True,
        )
        worker.start()

    def stop_stream(self) -> None:
        with self._lock:
            self._gen += 1
            was_running = self._running
            self._running = False
            self._active_serial = ""
            self._frame_pending = False
            self._teardown_handles_locked()
        if was_running:
            logger.info(f"{TAG} Stopped embedded Android stream")

    def _teardown_handles_locked(self) -> None:
        for sock in (self._ctrl_sock, self._video_sock):
            if sock is not None:
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                try:
                    sock.close()
                except OSError:
                    pass
        self._ctrl_sock = None
        self._video_sock = None
        proc = self._server_proc
        self._server_proc = None
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except OSError:
                pass

    def _send_control_bytes(self, payload: bytes) -> bool:
        with self._lock:
            sock = self._ctrl_sock
        if sock is None or not payload:
            return False
        try:
            with self._send_lock:
                sock.sendall(payload)
            return True
        except OSError:
            return False

    def send_touch(self, action: int, x: int, y: int) -> None:
        w, h = self.video_size
        if w <= 0 or h <= 0:
            return
        self._send_control_bytes(pack_inject_touch(action, x, y, w, h))

    def send_scroll(self, x: int, y: int, hscroll: float, vscroll: float) -> None:
        w, h = self.video_size
        if w <= 0 or h <= 0:
            return
        self._send_control_bytes(pack_inject_scroll(x, y, w, h, hscroll, vscroll))

    def send_keycode(self, keycode: int, meta_state: int = 0) -> None:
        down = pack_inject_keycode(AKEY_EVENT_ACTION_DOWN, keycode, 0, meta_state)
        up = pack_inject_keycode(AKEY_EVENT_ACTION_UP, keycode, 0, meta_state)
        self._send_control_bytes(down + up)

    def send_key_event(self, action: int, keycode: int, repeat: int = 0, meta_state: int = 0) -> None:
        self._send_control_bytes(pack_inject_keycode(action, keycode, repeat, meta_state))

    def send_text(self, text: str) -> None:
        if text:
            self._send_control_bytes(pack_inject_text(text))

    def rotate_device(self) -> None:
        self._send_control_bytes(pack_rotate_device())

    def _is_current(self, gen: int) -> bool:
        with self._lock:
            return self._running and self._gen == gen

    def _worker_loop(self, gen: int, runtime: RuntimeInfo) -> None:
        t0 = time.monotonic()
        adb_p = runtime.adb_path or ""
        serial = runtime.adb_serial or ""
        port = 0
        decoder: _H264StreamDecoder | None = None
        stop_reason = "closed"

        try:
            if not adb_p or not os.path.isfile(adb_p):
                raise AndroidError("Không tìm thấy ADB để truyền hình ảnh Android.")
            if not serial:
                devs = self._runtime_mgr.list_adb_devices(adb_p)
                serial = next((s for s, st in devs if st == "device"), "")
            if not serial:
                raise AndroidError("Máy ảo Android chưa kết nối ADB.")
            with self._lock:
                if self._gen == gen:
                    self._active_serial = serial

            jar_path = self._runtime_mgr.ensure_scrcpy_server_jar(runtime.root_dir)
            if not self._is_current(gen):
                return

            push_res = self._runtime_mgr.run_adb(
                adb_p, ["push", jar_path, "/data/local/tmp/scrcpy-server.jar"], serial=serial, timeout=20.0
            )
            if push_res.returncode != 0:
                raise AndroidError(
                    f"Không thể nạp scrcpy-server vào Android: {(push_res.stderr or push_res.stdout or '').strip()}"
                )

            scid_hex = f"{secrets.randbits(31):08x}"
            port = _pick_free_tcp_port()
            fwd_res = self._runtime_mgr.run_adb(
                adb_p,
                ["forward", f"tcp:{port}", f"localabstract:scrcpy_{scid_hex}"],
                serial=serial,
                timeout=8.0,
            )
            if fwd_res.returncode != 0:
                raise AndroidError("Không thể mở cổng truyền hình ảnh ADB forward.")

            hw_cfg = get_emulator_settings()
            target_fps = int(hw_cfg.get("fps") or 60)
            # Keep max_size >= 1920 so 720p/900p/1080p guest displays render 1:1 via HWC HostComposition
            # without SurfaceFlinger GLES VirtualDisplay downscale; 28 Mbps prevents OMX.google.h264.encoder
            # VBV buffer-underflow frame skipping over localhost loopback.
            max_dim = max(1920, int(hw_cfg.get("width") or 720), int(hw_cfg.get("height") or 1280))
            srv_cmd = [
                adb_p,
                "-s",
                serial,
                "shell",
                "CLASSPATH=/data/local/tmp/scrcpy-server.jar",
                "app_process",
                "/",
                "com.genymobile.scrcpy.Server",
                "3.1",
                f"scid={scid_hex}",
                "log_level=warn",
                "tunnel_forward=true",
                "audio=false",
                "control=true",
                "cleanup=false",
                "video_codec=h264",
                f"max_size={max_dim}",
                f"max_fps={target_fps}",
                "video_bit_rate=28000000",
                "send_device_meta=true",
                "send_frame_meta=true",
                "send_dummy_byte=true",
            ]
            proc = subprocess.Popen(
                srv_cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                **_subprocess_kwargs(env=self._runtime_mgr._adb_sdk_env(adb_p)),
            )
            with self._lock:
                if not self._is_current(gen):
                    proc.terminate()
                    return
                self._server_proc = proc

            video_sock: socket.socket | None = None
            deadline = time.monotonic() + 8.0
            while time.monotonic() < deadline and self._is_current(gen):
                if proc.poll() is not None:
                    err_out = ""
                    if proc.stderr is not None:
                        try:
                            err_out = proc.stderr.read().decode("utf-8", errors="replace").strip()
                        except Exception:
                            pass
                    raise AndroidError(f"scrcpy-server dừng sớm: {err_out or proc.returncode}")
                cand = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                cand.settimeout(1.2)
                try:
                    cand.connect(("127.0.0.1", port))
                    dummy = cand.recv(1)
                    if dummy == b"\x00":
                        cand.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                        cand.settimeout(None)
                        video_sock = cand
                        break
                except OSError:
                    pass
                try:
                    cand.close()
                except OSError:
                    pass
                time.sleep(0.12)

            if video_sock is None:
                raise AndroidError("Quá thời gian kết nối luồng hình ảnh Android (scrcpy).")

            ctrl_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            ctrl_sock.settimeout(3.0)
            ctrl_sock.connect(("127.0.0.1", port))
            ctrl_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            ctrl_sock.settimeout(2.0)

            with self._lock:
                if not self._is_current(gen):
                    video_sock.close()
                    ctrl_sock.close()
                    return
                self._video_sock = video_sock
                self._ctrl_sock = ctrl_sock

            _device_name = _recv_exact(video_sock, 64)
            codec_raw, init_w, init_h = struct.unpack(">4sII", _recv_exact(video_sock, 12))
            with self._lock:
                self._video_size = (int(init_w), int(init_h))
            logger.info(
                f"{TAG} Connected scrcpy {codec_raw.decode('ascii', errors='ignore').strip()} stream on {serial} "
                f"({init_w}x{init_h}) in {time.monotonic() - t0:.2f}s"
            )
            self.stream_started.emit(int(init_w), int(init_h))

            decoder = _H264StreamDecoder()
            logged_first_frame = False

            while self._is_current(gen):
                pts_flags, pkt_size = struct.unpack(">QI", _recv_exact(video_sock, 12))
                if pkt_size <= 0 or pkt_size > 16 * 1024 * 1024:
                    continue
                nal_data = _recv_exact(video_sock, pkt_size)
                is_cfg = bool(pts_flags & SCRCPY_FLAG_CONFIG)
                is_key = bool(pts_flags & SCRCPY_FLAG_KEY_FRAME) or is_cfg
                dec_t0 = time.perf_counter()
                img = decoder.decode(nal_data, is_key=is_key)
                dec_ms = (time.perf_counter() - dec_t0) * 1000.0
                if img is None or img.isNull():
                    continue
                iw, ih = img.width(), img.height()
                emit_now = False
                resized = False
                now_mono = time.monotonic()
                with self._lock:
                    if (iw, ih) != self._video_size:
                        self._video_size = (iw, ih)
                        resized = True
                    self._frame_samples.append((now_mono, dec_ms, pkt_size))
                    self._latest_frame = img
                    if not self._frame_pending:
                        self._frame_pending = True
                        emit_now = True
                    else:
                        self._dropped_frames += 1
                if not logged_first_frame:
                    logged_first_frame = True
                    logger.info(f"{TAG} Decoded first H.264 frame ({iw}x{ih}) in {time.monotonic() - t0:.2f}s")
                if resized:
                    self.stream_started.emit(iw, ih)
                if emit_now:
                    self.frame_ready.emit(img)

        except EOFError:
            stop_reason = "eof"
        except AndroidError as exc:
            stop_reason = str(exc)
            if self._is_current(gen):
                logger.warning(f"{TAG} Stream error on {serial or 'android'}: {exc}")
                self.stream_error.emit(str(exc))
        except Exception as exc:  # noqa: BLE001
            stop_reason = str(exc)
            if self._is_current(gen):
                logger.exception(f"{TAG} Unexpected crash in scrcpy stream worker")
                self.stream_error.emit(f"Lỗi truyền hình ảnh Android: {exc}")
        finally:
            if decoder is not None:
                try:
                    decoder.close()
                except Exception:
                    pass
            if port and adb_p and os.path.isfile(adb_p) and serial:
                try:
                    self._runtime_mgr.run_adb(
                        adb_p, ["forward", "--remove", f"tcp:{port}"], serial=serial, timeout=4.0
                    )
                except Exception:
                    pass
            was_active = False
            with self._lock:
                if self._gen == gen:
                    was_active = self._running
                    self._running = False
                    self._active_serial = ""
                    self._frame_pending = False
                    self._teardown_handles_locked()
            if was_active:
                logger.info(f"{TAG} Android stream ended ({stop_reason})")
                self.stream_stopped.emit(stop_reason)
