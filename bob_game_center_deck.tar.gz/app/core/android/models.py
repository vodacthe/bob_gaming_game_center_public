"""Data models and path validation for the cross-platform Android App & Game Store."""

from __future__ import annotations

from dataclasses import dataclass, field
import logging
import os
import posixpath
import re
import sys

import app.config as _app_config

logger = logging.getLogger(__name__)
TAG = "[Android/Models]"

CATEGORY_ALL = "all"
CATEGORY_GAMES = "games"
CATEGORY_APPS = "apps"
CATEGORY_INSTALLED = "installed"

SOURCE_APTOIDE = "aptoide"
SOURCE_UPTODOWN = "uptodown"
SOURCE_FDROID = "fdroid"
SOURCE_APKPURE = "apkpure"
SOURCE_LOCAL = "local"

SOURCE_LABELS = {
    SOURCE_APTOIDE: "Aptoide",
    SOURCE_UPTODOWN: "Uptodown",
    SOURCE_FDROID: "F-Droid",
    SOURCE_APKPURE: "APKPure",
    SOURCE_LOCAL: "File cục bộ",
}

RUNTIME_PORTABLE_SDK = "portable_sdk"
RUNTIME_WAYDROID = "waydroid"
RUNTIME_SYSTEM_SDK = "system_sdk"
RUNTIME_EXTERNAL_ADB = "external_adb"

_PKG_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]*(?:\.[a-zA-Z0-9_]+)+$")
_SAFE_DIR_RE = re.compile(r"[^a-zA-Z0-9._-]+")


class AndroidError(Exception):
    """User-facing error raised by Android store, runtime, or installer operations."""


ARM32_ONLY_ABIS = frozenset({"armeabi-v7a", "armeabi"})


class AndroidAbiMismatchError(AndroidError):
    """The package's native code needs a CPU architecture the target runtime cannot run or translate."""

    def __init__(self, message: str, package_abis: set[str] | frozenset[str] = frozenset(), app_title: str = ""):
        super().__init__(message)
        self.package_abis = frozenset(package_abis)
        self.app_title = app_title

    @property
    def needs_arm32(self) -> bool:
        """True when only a runtime with 32-bit ARM translation can help (or the package ABIs are unknown)."""
        return not self.package_abis or bool(self.package_abis & ARM32_ONLY_ABIS)


class AndroidTaskStatus:
    QUEUED = "queued"
    PREPARING_RUNTIME = "preparing_runtime"
    DOWNLOADING = "downloading"
    INSTALLING = "installing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


ACTIVE_ANDROID_STATUSES = frozenset({
    AndroidTaskStatus.QUEUED,
    AndroidTaskStatus.PREPARING_RUNTIME,
    AndroidTaskStatus.DOWNLOADING,
    AndroidTaskStatus.INSTALLING,
})


@dataclass
class AndroidApp:
    package_name: str
    name: str
    kind: str = CATEGORY_GAMES
    version: str = ""
    size_bytes: int = 0
    icon_url: str = ""
    banner_url: str = ""
    summary: str = ""
    source: str = SOURCE_APTOIDE
    download_url: str = ""
    split_urls: list[str] = field(default_factory=list)
    obb_urls: dict[str, str] = field(default_factory=dict)
    rating: float = 0.0
    page_url: str = ""

    @property
    def poster_url(self) -> str:
        return self.icon_url or self.banner_url


@dataclass
class RuntimeInfo:
    runtime_id: str
    kind: str
    label: str
    installed: bool
    running: bool = False
    adb_path: str = ""
    adb_serial: str = ""
    emulator_path: str = ""
    avd_name: str = ""
    root_dir: str = ""
    detail: str = ""


@dataclass
class AndroidInstallTask:
    task_id: str
    package_name: str
    app_name: str
    kind: str = CATEGORY_GAMES
    source: str = SOURCE_APTOIDE
    icon_url: str = ""
    status: str = AndroidTaskStatus.QUEUED
    progress: int = 0
    downloaded_bytes: int = 0
    total_bytes: int = 0
    speed_bps: int = 0
    status_text: str = ""
    error_message: str = ""
    install_dir: str = ""
    launcher_path: str = ""


def is_valid_package_name(pkg: str) -> bool:
    return bool(pkg and _PKG_RE.match(pkg.strip()))


def sanitize_package_dir_name(pkg: str) -> str:
    cleaned = _SAFE_DIR_RE.sub("_", (pkg or "").strip()).strip("._")
    return cleaned or "android_app"


def _is_inside_config_dir(candidate: str, platform_name: str = sys.platform) -> bool:
    cfg_dir = getattr(_app_config, "CONFIG_DIR", "")
    if not cfg_dir:
        return False
    if platform_name != "win32" and candidate.startswith("/") and not str(cfg_dir).startswith("/"):
        return False
    try:
        cfg_norm = os.path.normcase(os.path.normpath(os.path.abspath(cfg_dir)))
        cand_norm = os.path.normcase(os.path.normpath(os.path.abspath(candidate)))
        return os.path.commonpath([cfg_norm, cand_norm]) == cfg_norm
    except ValueError:
        return False


def is_valid_android_root(root: str | None, platform_name: str | None = None) -> bool:
    """Validate that an Android install root is an absolute path outside CONFIG_DIR."""
    plat = platform_name or sys.platform
    if not root:
        return False
    raw = str(root).strip()
    if not raw:
        return False

    if plat == "win32":
        if not os.path.isabs(raw):
            return False
        norm = os.path.normpath(raw)
        drive = os.path.splitdrive(norm)[0]
        if not drive or not os.path.exists(drive + "\\"):
            return False
        if _is_inside_config_dir(norm, plat):
            logger.warning(f"{TAG} Rejected Android root inside CONFIG_DIR: {norm}")
            return False
        return True

    if not posixpath.isabs(raw) or ":" in raw:
        return False
    norm = posixpath.normpath(raw)
    if norm in ("/", "") or norm.rstrip("/") == "":
        return False
    if _is_inside_config_dir(norm, plat):
        logger.warning(f"{TAG} Rejected Android root inside CONFIG_DIR: {norm}")
        return False
    return True


def resolve_android_root(configured_root: str = "", fallback_games_root: str = "") -> str:
    """Pick the first valid Android installation root outside CONFIG_DIR."""
    for candidate in (configured_root, fallback_games_root):
        if is_valid_android_root(candidate):
            return os.path.normpath(str(candidate).strip())
    from app.core.system_actions import get_default_games_directory

    default_dir = get_default_games_directory()
    if is_valid_android_root(default_dir):
        return default_dir
    if sys.platform == "win32":
        return os.path.join(os.path.expanduser("~"), "Games")
    return posixpath.join(os.path.expanduser("~"), "Games")


def get_runtime_dir(android_root: str) -> str:
    return os.path.join(android_root, "AndroidRuntime")


def get_apps_dir(android_root: str) -> str:
    return os.path.join(android_root, "AndroidApps")
