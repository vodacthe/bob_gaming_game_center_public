"""Virtual Android gamepad: HID report descriptor, report packing and the scrcpy UHID control messages.

The guest sees an ordinary HID gamepad created through `/dev/uhid` (scrcpy-server's UHID messages). It reports
the Xbox 360 vendor / product id, so Android loads `Vendor_045e_Product_028e.kl` and games get the standard
layout: sticks on AXIS_X / AXIS_Y / AXIS_Z / AXIS_RZ, triggers on AXIS_LTRIGGER / AXIS_RTRIGGER, D-pad on
AXIS_HAT_X / AXIS_HAT_Y and BUTTON_A / B / X / Y / L1 / R1 / SELECT / START / MODE / THUMBL / THUMBR.

Everything here is pure (no I/O, no Qt), so it can be used from any thread.
"""

from __future__ import annotations

from dataclasses import dataclass
import struct
from typing import Sequence

GAMEPAD_VENDOR_ID = 0x045E
GAMEPAD_PRODUCT_ID = 0x028E
GAMEPAD_NAME = "Bob Gaming Virtual Gamepad"
MAX_PADS = 4

# Button bits of the 16-bit button field. HID button usage N becomes Linux BTN_GAMEPAD + (N - 1); the gaps are
# BTN_C / BTN_Z / BTN_TL2 / BTN_TR2, which the Xbox 360 key layout does not use.
BTN_A = 1 << 0
BTN_B = 1 << 1
BTN_X = 1 << 3
BTN_Y = 1 << 4
BTN_LB = 1 << 6
BTN_RB = 1 << 7
BTN_BACK = 1 << 10
BTN_START = 1 << 11
BTN_GUIDE = 1 << 12
BTN_L3 = 1 << 13
BTN_R3 = 1 << 14

# Hat switch values (0 = centred, then clockwise from north).
HAT_CENTERED = 0
_HAT_FROM_DIRECTION: dict[tuple[int, int], int] = {
    (0, -1): 1,
    (1, -1): 2,
    (1, 0): 3,
    (1, 1): 4,
    (0, 1): 5,
    (-1, 1): 6,
    (-1, 0): 7,
    (-1, -1): 8,
}

REPORT_SIZE = 15

# 4 x 16-bit sticks, 2 x 16-bit triggers, 16 buttons, 4-bit hat + 4 bits of padding = 15 bytes.
REPORT_DESCRIPTOR = bytes(
    [
        0x05, 0x01,                    # Usage Page (Generic Desktop)
        0x09, 0x05,                    # Usage (Gamepad)
        0xA1, 0x01,                    # Collection (Application)
        0x05, 0x01,                    # Usage Page (Generic Desktop)
        0x09, 0x30,                    # Usage (X)   left stick X
        0x09, 0x31,                    # Usage (Y)   left stick Y
        0x09, 0x33,                    # Usage (Rx)  right stick X
        0x09, 0x34,                    # Usage (Ry)  right stick Y
        0x15, 0x00,                    # Logical Minimum (0)
        0x27, 0xFF, 0xFF, 0x00, 0x00,  # Logical Maximum (65535)
        0x75, 0x10,                    # Report Size (16)
        0x95, 0x04,                    # Report Count (4)
        0x81, 0x02,                    # Input (Data, Variable, Absolute)
        0x09, 0x32,                    # Usage (Z)   left trigger
        0x09, 0x35,                    # Usage (Rz)  right trigger
        0x15, 0x00,                    # Logical Minimum (0)
        0x26, 0xFF, 0x7F,              # Logical Maximum (32767)
        0x75, 0x10,                    # Report Size (16)
        0x95, 0x02,                    # Report Count (2)
        0x81, 0x02,                    # Input (Data, Variable, Absolute)
        0x05, 0x09,                    # Usage Page (Button)
        0x19, 0x01,                    # Usage Minimum (1)
        0x29, 0x10,                    # Usage Maximum (16)
        0x15, 0x00,                    # Logical Minimum (0)
        0x25, 0x01,                    # Logical Maximum (1)
        0x75, 0x01,                    # Report Size (1)
        0x95, 0x10,                    # Report Count (16)
        0x81, 0x02,                    # Input (Data, Variable, Absolute)
        0x05, 0x01,                    # Usage Page (Generic Desktop)
        0x09, 0x39,                    # Usage (Hat switch)
        0x15, 0x01,                    # Logical Minimum (1)
        0x25, 0x08,                    # Logical Maximum (8)
        0x35, 0x00,                    # Physical Minimum (0)
        0x46, 0x3B, 0x01,              # Physical Maximum (315)
        0x65, 0x14,                    # Unit (degrees)
        0x75, 0x04,                    # Report Size (4)
        0x95, 0x01,                    # Report Count (1)
        0x81, 0x42,                    # Input (Data, Variable, Absolute, Null State)
        0x75, 0x04,                    # Report Size (4)
        0x95, 0x01,                    # Report Count (1)
        0x81, 0x03,                    # Input (Constant): padding
        0xC0,                          # End Collection
    ]
)

# scrcpy-server v3.x control message types.
_MSG_UHID_CREATE = 12
_MSG_UHID_INPUT = 13
_MSG_UHID_DESTROY = 14


def _clamp(value: float, low: float, high: float) -> float:
    return low if value < low else high if value > high else value


@dataclass(frozen=True)
class PadState:
    """One controller's state. Sticks are -1..1 (x: right is positive, y: DOWN is positive), triggers 0..1."""

    buttons: int = 0
    lx: float = 0.0
    ly: float = 0.0
    rx: float = 0.0
    ry: float = 0.0
    lt: float = 0.0
    rt: float = 0.0
    dpad_x: int = 0  # -1 left, 1 right
    dpad_y: int = 0  # -1 up, 1 down

    def is_neutral(self) -> bool:
        return self == NEUTRAL_PAD

    def holds(self, mask: int) -> bool:
        return (self.buttons & mask) == mask


NEUTRAL_PAD = PadState()


def hat_value(dpad_x: int, dpad_y: int) -> int:
    """HID hat switch value for a D-pad direction (0 when centred)."""
    dx = (dpad_x > 0) - (dpad_x < 0)
    dy = (dpad_y > 0) - (dpad_y < 0)
    return _HAT_FROM_DIRECTION.get((dx, dy), HAT_CENTERED)


def _stick_raw(value: float) -> int:
    return int((_clamp(float(value), -1.0, 1.0) + 1.0) * 32767.5 + 0.5) if value == value else 32768


def _trigger_raw(value: float) -> int:
    return int(_clamp(float(value), 0.0, 1.0) * 32767.0 + 0.5) if value == value else 0


def pack_report(state: PadState) -> bytes:
    """The 15-byte HID input report of `state` (NaN / out-of-range values are clamped, never raised)."""
    return struct.pack(
        "<HHHHHHHB",
        min(65535, _stick_raw(state.lx)),
        min(65535, _stick_raw(state.ly)),
        min(65535, _stick_raw(state.rx)),
        min(65535, _stick_raw(state.ry)),
        _trigger_raw(state.lt),
        _trigger_raw(state.rt),
        int(state.buttons) & 0xFFFF,
        hat_value(state.dpad_x, state.dpad_y),
    )


NEUTRAL_REPORT = pack_report(NEUTRAL_PAD)


def pack_uhid_create(
    device_id: int,
    name: str = GAMEPAD_NAME,
    vendor_id: int = GAMEPAD_VENDOR_ID,
    product_id: int = GAMEPAD_PRODUCT_ID,
    descriptor: bytes = REPORT_DESCRIPTOR,
) -> bytes:
    """scrcpy TYPE_UHID_CREATE: id, vendor, product (u16 BE), name (u8 length), descriptor (u16 BE length)."""
    raw_name = (name or GAMEPAD_NAME).encode("utf-8")[:127]
    return (
        struct.pack(">BHHHB", _MSG_UHID_CREATE, device_id & 0xFFFF, vendor_id & 0xFFFF, product_id & 0xFFFF, len(raw_name))
        + raw_name
        + struct.pack(">H", len(descriptor))
        + descriptor
    )


def pack_uhid_input(device_id: int, report: bytes) -> bytes:
    """scrcpy TYPE_UHID_INPUT: id, report size (u16 BE), report bytes."""
    return struct.pack(">BHH", _MSG_UHID_INPUT, device_id & 0xFFFF, len(report)) + report


def pack_uhid_destroy(device_id: int) -> bytes:
    """scrcpy TYPE_UHID_DESTROY: id (u16 BE)."""
    return struct.pack(">BH", _MSG_UHID_DESTROY, device_id & 0xFFFF)


# SDL_GameControllerButton order (SDL 2.0.14+): A B X Y Back Guide Start LS RS LB RB Up Down Left Right.
_SDL_BUTTON_BITS: tuple[int, ...] = (
    BTN_A, BTN_B, BTN_X, BTN_Y, BTN_BACK, BTN_GUIDE, BTN_START, BTN_L3, BTN_R3, BTN_LB, BTN_RB,
)
_SDL_DPAD_UP, _SDL_DPAD_DOWN, _SDL_DPAD_LEFT, _SDL_DPAD_RIGHT = 11, 12, 13, 14


def pad_state_from_sdl(buttons: Sequence[int], axes: Sequence[int]) -> PadState:
    """Build a PadState from SDL_GameController buttons (SDL order) and axes (LX LY RX RY LT RT, int16)."""
    mask = 0
    for idx, bit in enumerate(_SDL_BUTTON_BITS):
        if idx < len(buttons) and buttons[idx]:
            mask |= bit

    def pressed(idx: int) -> bool:
        return idx < len(buttons) and bool(buttons[idx])

    def stick(idx: int) -> float:
        raw = int(axes[idx]) if idx < len(axes) else 0
        return _clamp(raw / 32767.0, -1.0, 1.0)

    def trigger(idx: int) -> float:
        raw = int(axes[idx]) if idx < len(axes) else 0
        return _clamp(raw / 32767.0, 0.0, 1.0)

    return PadState(
        buttons=mask,
        lx=stick(0),
        ly=stick(1),
        rx=stick(2),
        ry=stick(3),
        lt=trigger(4),
        rt=trigger(5),
        dpad_x=int(pressed(_SDL_DPAD_RIGHT)) - int(pressed(_SDL_DPAD_LEFT)),
        dpad_y=int(pressed(_SDL_DPAD_DOWN)) - int(pressed(_SDL_DPAD_UP)),
    )
