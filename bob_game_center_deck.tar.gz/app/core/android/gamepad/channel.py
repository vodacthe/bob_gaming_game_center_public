"""Control-only scrcpy-server session: the transport the gamepad bridge uses to create UHID devices in Android.

It is independent of the video stream (own `scid`, no video, no audio), so it works the same whether the player
shows the emulator's native GPU window or the scrcpy stream. All calls block: use it from a worker thread.
"""

from __future__ import annotations

import logging
import os
import secrets
import socket
import subprocess
import threading
import time
from typing import Callable

from app.core.android.models import AndroidError, RuntimeInfo
from app.core.android.runtime import AndroidRuntimeManager, _subprocess_kwargs

logger = logging.getLogger(__name__)
TAG = "[Android/GamepadChannel]"

SERVER_VERSION = "3.1"
DEVICE_JAR_PATH = "/data/local/tmp/scrcpy-server.jar"
CONNECT_TIMEOUT_S = 8.0
SEND_TIMEOUT_S = 1.0


def _pick_free_tcp_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


class ScrcpyControlChannel:
    """One control socket to a scrcpy-server running inside the guest."""

    def __init__(self, runtime_mgr: AndroidRuntimeManager) -> None:
        self._runtime_mgr = runtime_mgr
        self._lock = threading.Lock()
        self._sock: socket.socket | None = None
        self._proc: subprocess.Popen | None = None
        self._port = 0
        self._adb_path = ""
        self._serial = ""
        self._alive = False

    @property
    def alive(self) -> bool:
        with self._lock:
            return self._alive

    @property
    def serial(self) -> str:
        return self._serial

    def open(self, runtime: RuntimeInfo, is_cancelled: Callable[[], bool] = lambda: False) -> None:
        """Start the server and connect. Raises AndroidError; leaves nothing behind when it fails."""
        t0 = time.monotonic()
        adb_p = runtime.adb_path or ""
        serial = runtime.adb_serial or ""
        if not adb_p or not os.path.isfile(adb_p):
            raise AndroidError("Không tìm thấy ADB để kết nối tay cầm vào Android.")
        if not serial:
            devices = self._runtime_mgr.list_adb_devices(adb_p)
            serial = next((s for s, state in devices if state == "device"), "")
        if not serial:
            raise AndroidError("Máy ảo Android chưa kết nối ADB.")
        self._adb_path, self._serial = adb_p, serial
        try:
            jar_path = self._runtime_mgr.ensure_scrcpy_server_jar(runtime.root_dir)
            push = self._runtime_mgr.run_adb(adb_p, ["push", jar_path, DEVICE_JAR_PATH], serial=serial, timeout=20.0)
            if push.returncode != 0:
                raise AndroidError(
                    f"Không thể nạp scrcpy-server vào Android: {(push.stderr or push.stdout or '').strip()[:200]}"
                )
            if is_cancelled():
                raise AndroidError("Đã huỷ kết nối tay cầm.")
            scid = f"{secrets.randbits(31):08x}"
            port = _pick_free_tcp_port()
            fwd = self._runtime_mgr.run_adb(
                adb_p, ["forward", f"tcp:{port}", f"localabstract:scrcpy_{scid}"], serial=serial, timeout=8.0
            )
            if fwd.returncode != 0:
                raise AndroidError(
                    f"Không thể mở cổng ADB forward cho tay cầm: {(fwd.stderr or fwd.stdout or '').strip()[:200]}"
                )
            self._port = port
            proc = subprocess.Popen(
                [
                    adb_p,
                    "-s",
                    serial,
                    "shell",
                    f"CLASSPATH={DEVICE_JAR_PATH}",
                    "app_process",
                    "/",
                    "com.genymobile.scrcpy.Server",
                    SERVER_VERSION,
                    f"scid={scid}",
                    "log_level=warn",
                    "tunnel_forward=true",
                    "video=false",
                    "audio=false",
                    "control=true",
                    "cleanup=false",
                    "power_on=false",
                    "clipboard_autosync=false",
                    "send_device_meta=false",
                    "send_dummy_byte=true",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                **_subprocess_kwargs(env=self._runtime_mgr._adb_sdk_env(adb_p)),
            )
            self._proc = proc
            sock = self._connect(proc, port, is_cancelled)
            with self._lock:
                self._sock = sock
                self._alive = True
            threading.Thread(target=self._drain, args=(sock,), name="android-gamepad-channel", daemon=True).start()
            logger.info(f"{TAG} Control channel to {serial} ready in {time.monotonic() - t0:.2f}s (port {port})")
        except AndroidError:
            self.close()
            raise
        except (OSError, subprocess.SubprocessError) as exc:
            self.close()
            raise AndroidError(f"Không thể mở kênh điều khiển tay cầm: {exc}") from exc

    def _connect(self, proc: subprocess.Popen, port: int, is_cancelled: Callable[[], bool]) -> socket.socket:
        deadline = time.monotonic() + CONNECT_TIMEOUT_S
        while time.monotonic() < deadline:
            if is_cancelled():
                raise AndroidError("Đã huỷ kết nối tay cầm.")
            if proc.poll() is not None:
                err_out = ""
                if proc.stderr is not None:
                    try:
                        err_out = proc.stderr.read().decode("utf-8", errors="replace").strip()
                    except (OSError, ValueError):
                        pass
                raise AndroidError(f"scrcpy-server dừng sớm: {err_out[:300] or proc.returncode}")
            cand = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            cand.settimeout(1.2)
            try:
                cand.connect(("127.0.0.1", port))
                # adb accepts the connection before the server listens: only the server sends this byte.
                if cand.recv(1) == b"\x00":
                    cand.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    # A bounded send: a server that stops reading must not hang the bridge thread.
                    cand.settimeout(SEND_TIMEOUT_S)
                    return cand
            except OSError:
                pass
            try:
                cand.close()
            except OSError:
                pass
            time.sleep(0.12)
        raise AndroidError("Quá thời gian kết nối kênh điều khiển tay cầm (scrcpy).")

    def _drain(self, sock: socket.socket) -> None:
        """Discard whatever the server sends back; its only job is to notice the session ending."""
        reason = "closed"
        while True:
            try:
                if not sock.recv(4096):
                    reason = "server closed the connection"
                    break
            except TimeoutError:
                continue  # nothing to read: the timeout only bounds sends
            except OSError as exc:
                reason = str(exc)
                break
        with self._lock:
            was_alive = self._alive and self._sock is sock
            if was_alive:
                self._alive = False
        if was_alive:
            logger.warning(f"{TAG} Control channel to {self._serial} ended: {reason}")

    def send(self, payload: bytes) -> bool:
        """Send control bytes. False when the channel is closed or the send failed (the channel is then dead)."""
        with self._lock:
            sock = self._sock if self._alive else None
            if sock is None or not payload:
                return False
            try:
                sock.sendall(payload)
                return True
            except OSError as exc:
                self._alive = False
                logger.warning(f"{TAG} Sending to {self._serial} failed: {exc}")
                return False

    def close(self) -> None:
        with self._lock:
            sock, proc, port = self._sock, self._proc, self._port
            was_open = self._alive
            self._sock = None
            self._proc = None
            self._port = 0
            self._alive = False
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
        if proc is not None:
            try:
                if proc.poll() is None:
                    proc.terminate()
                if proc.stderr is not None:
                    proc.stderr.close()
            except OSError:
                pass
        if port and self._adb_path and self._serial:
            try:
                self._runtime_mgr.run_adb(
                    self._adb_path, ["forward", "--remove", f"tcp:{port}"], serial=self._serial, timeout=4.0
                )
            except Exception as exc:  # noqa: BLE001 - the emulator may already be gone
                logger.debug(f"{TAG} Could not remove ADB forward tcp:{port}: {exc}")
        if was_open:
            logger.info(f"{TAG} Control channel to {self._serial} closed")
