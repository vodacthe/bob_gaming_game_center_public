"""Keyboard + mouse as a virtual gamepad.

`KbmMapper` is the pure part: held keys / mouse buttons and mouse movement in, a `PadState` out.

`WinKbmHook` is the Windows input side: low-level keyboard / mouse hooks on their own message-loop thread. The
hooks exist only while the emulator has the keyboard (`gate()`), and they swallow only what they translate, so
the rest of the system keeps its input. One key (F1 by default) switches "game mode" on and off: off, keyboard
and mouse reach Android as usual (typing, touching the screen); on, bound keys drive the virtual gamepad and,
with mouse look enabled, the cursor is held in place while mouse movement drives the right stick.
"""

from __future__ import annotations

import ctypes
import logging
import math
import sys
import threading
import time
from typing import Callable

from app.core.android.gamepad import hid
from app.core.android.gamepad.settings import (
    ACTION_IDS,
    GamepadSettings,
    normalize_vk,
    parse_token,
)

logger = logging.getLogger(__name__)
TAG = "[Android/KbmPad]"

_BUTTON_BITS: dict[str, int] = {
    "a": hid.BTN_A,
    "b": hid.BTN_B,
    "x": hid.BTN_X,
    "y": hid.BTN_Y,
    "lb": hid.BTN_LB,
    "rb": hid.BTN_RB,
    "l3": hid.BTN_L3,
    "r3": hid.BTN_R3,
    "back": hid.BTN_BACK,
    "start": hid.BTN_START,
    "guide": hid.BTN_GUIDE,
}

# Mouse look: pixels per second that push the right stick fully over at sensitivity 1.0.
FULL_DEFLECTION_PX_PER_S = 1500.0
# Faster movement than the stick can express is carried over to the next ticks, up to this many seconds' worth.
MAX_CARRY_SECONDS = 0.2
# Small movements must clear the game's own dead zone to be felt at all.
ANTI_DEADZONE = 0.12
SMOOTHING = 0.6
_SETTLE_EPSILON = 0.02


class KbmMapper:
    """Held inputs -> PadState. Thread-safe: the hook thread feeds it, the bridge thread reads it."""

    def __init__(self, settings: GamepadSettings | None = None) -> None:
        self._lock = threading.Lock()
        self._key_actions: dict[int, str] = {}
        self._mouse_actions: dict[str, str] = {}
        self._held: set[str] = set()
        self._sensitivity = 1.0
        self._acc_x = 0.0
        self._acc_y = 0.0
        self._look_x = 0.0
        self._look_y = 0.0
        self._last_tick = 0.0
        self.apply_settings(settings or GamepadSettings())

    def apply_settings(self, settings: GamepadSettings) -> None:
        key_actions: dict[int, str] = {}
        mouse_actions: dict[str, str] = {}
        for action in ACTION_IDS:
            parsed = parse_token(settings.bindings.get(action, ""))
            if parsed is None:
                continue
            if parsed[0] == "key":
                key_actions[int(parsed[1])] = action
            else:
                mouse_actions[str(parsed[1])] = action
        with self._lock:
            self._key_actions = key_actions
            self._mouse_actions = mouse_actions
            self._sensitivity = max(0.05, float(settings.mouse_sensitivity))
            self._held.clear()

    def key_event(self, vk: int, down: bool) -> bool:
        """Record a key press / release. True when the key is bound (the caller then swallows it)."""
        with self._lock:
            action = self._key_actions.get(normalize_vk(vk))
            if action is None:
                return False
            if down:
                self._held.add(action)
            else:
                self._held.discard(action)
            return True

    def mouse_button(self, button: str, down: bool) -> bool:
        with self._lock:
            action = self._mouse_actions.get(button)
            if action is None:
                return False
            if down:
                self._held.add(action)
            else:
                self._held.discard(action)
            return True

    def mouse_move(self, dx: float, dy: float) -> None:
        with self._lock:
            self._acc_x += dx
            self._acc_y += dy

    def release_all(self) -> None:
        """Let go of everything (game mode off, focus lost)."""
        with self._lock:
            self._held.clear()
            self._acc_x = self._acc_y = 0.0
            self._look_x = self._look_y = 0.0
            self._last_tick = 0.0

    def is_settled(self) -> bool:
        """True when no mouse movement is still being played out (the bridge can stop ticking fast)."""
        with self._lock:
            return (
                self._acc_x == 0.0
                and self._acc_y == 0.0
                and self._look_x == 0.0
                and self._look_y == 0.0
            )

    def _tick_look(self, now: float) -> tuple[float, float]:
        """Turn accumulated mouse movement into this tick's right-stick deflection. Call with the lock held."""
        dt = now - self._last_tick if self._last_tick else 0.008
        self._last_tick = now
        dt = min(0.05, max(0.002, dt))
        reach = FULL_DEFLECTION_PX_PER_S / self._sensitivity * dt  # pixels that mean "fully over" this tick
        mag = math.hypot(self._acc_x, self._acc_y)
        target_x = target_y = 0.0
        if mag > 0.0:
            used = min(mag, reach)
            scale = used / mag
            take_x, take_y = self._acc_x * scale, self._acc_y * scale
            self._acc_x -= take_x
            self._acc_y -= take_y
            carry_cap = FULL_DEFLECTION_PX_PER_S / self._sensitivity * MAX_CARRY_SECONDS
            left = math.hypot(self._acc_x, self._acc_y)
            if left > carry_cap:
                self._acc_x *= carry_cap / left
                self._acc_y *= carry_cap / left
            elif left < 0.01:
                self._acc_x = self._acc_y = 0.0
            deflect = ANTI_DEADZONE + (1.0 - ANTI_DEADZONE) * (used / reach)
            target_x = take_x / used * deflect
            target_y = take_y / used * deflect
        self._look_x += (target_x - self._look_x) * SMOOTHING
        self._look_y += (target_y - self._look_y) * SMOOTHING
        if mag == 0.0 and math.hypot(self._look_x, self._look_y) < _SETTLE_EPSILON:
            self._look_x = self._look_y = 0.0
        return self._look_x, self._look_y

    def snapshot(self, now: float | None = None) -> hid.PadState:
        """Current pad state; advances the mouse-look integration by one tick."""
        with self._lock:
            held = self._held
            buttons = 0
            for action, bit in _BUTTON_BITS.items():
                if action in held:
                    buttons |= bit
            lx = float("ls_right" in held) - float("ls_left" in held)
            ly = float("ls_down" in held) - float("ls_up" in held)
            rx = float("rs_right" in held) - float("rs_left" in held)
            ry = float("rs_down" in held) - float("rs_up" in held)
            look_x, look_y = self._tick_look(time.monotonic() if now is None else now)
            dpad_x = int("dpad_right" in held) - int("dpad_left" in held)
            dpad_y = int("dpad_down" in held) - int("dpad_up" in held)
            lt = 1.0 if "lt" in held else 0.0
            rt = 1.0 if "rt" in held else 0.0
        # A stick pushed diagonally stays on the unit circle, like a real one.
        l_mag = math.hypot(lx, ly)
        if l_mag > 1.0:
            lx, ly = lx / l_mag, ly / l_mag
        rx += look_x
        ry += look_y
        r_mag = math.hypot(rx, ry)
        if r_mag > 1.0:
            rx, ry = rx / r_mag, ry / r_mag
        return hid.PadState(buttons=buttons, lx=lx, ly=ly, rx=rx, ry=ry, lt=lt, rt=rt, dpad_x=dpad_x, dpad_y=dpad_y)


# ---------------------------------------------------------------------------------------------- Windows hooks

_WH_KEYBOARD_LL = 13
_WH_MOUSE_LL = 14
_HC_ACTION = 0
_WM_QUIT = 0x0012
_WM_TIMER = 0x0113
_WM_KEYDOWN, _WM_KEYUP, _WM_SYSKEYDOWN, _WM_SYSKEYUP = 0x0100, 0x0101, 0x0104, 0x0105
_WM_MOUSEMOVE = 0x0200
_MOUSE_BUTTON_MESSAGES: dict[int, tuple[str, bool]] = {
    0x0201: ("left", True),
    0x0202: ("left", False),
    0x0204: ("right", True),
    0x0205: ("right", False),
    0x0207: ("middle", True),
    0x0208: ("middle", False),
}
_WM_XBUTTONDOWN, _WM_XBUTTONUP = 0x020B, 0x020C
_WM_MOUSEWHEEL, _WM_MOUSEHWHEEL = 0x020A, 0x020E
_LLKHF_INJECTED = 0x10
_LLKHF_ALTDOWN = 0x20
_LLMHF_INJECTED = 0x01
GATE_POLL_MS = 150


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class _KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", ctypes.c_uint32),
        ("scanCode", ctypes.c_uint32),
        ("flags", ctypes.c_uint32),
        ("time", ctypes.c_uint32),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class _MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("pt", _POINT),
        ("mouseData", ctypes.c_uint32),
        ("flags", ctypes.c_uint32),
        ("time", ctypes.c_uint32),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class _MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", ctypes.c_void_p),
        ("message", ctypes.c_uint),
        ("wParam", ctypes.c_size_t),
        ("lParam", ctypes.c_ssize_t),
        ("time", ctypes.c_uint32),
        ("pt", _POINT),
    ]


def kbm_supported(platform_name: str = sys.platform) -> bool:
    """Keyboard + mouse capture needs the Windows low-level hooks."""
    return platform_name == "win32"


class WinKbmHook:
    """Feeds a `KbmMapper` from low-level Windows hooks while `gate()` is true.

    `gate` is polled on the hook thread a few times per second; `on_change` is called (hook thread) whenever
    the pad state may have changed; `on_engaged(bool)` when game mode is switched.
    """

    def __init__(
        self,
        mapper: KbmMapper,
        gate: Callable[[], bool],
        on_change: Callable[[], None],
        on_engaged: Callable[[bool], None] | None = None,
    ) -> None:
        self._mapper = mapper
        self._gate = gate
        self._on_change = on_change
        self._on_engaged = on_engaged
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._thread_id = 0
        self._ready = threading.Event()
        self._toggle_vk = 0x70
        self._mouse_look = True
        # Hook-thread state.
        self._engaged = False
        self._toggle_down = False
        self._swallowed: set[int] = set()  # keys whose press was consumed: their release is consumed too
        self._kbd_hook = None
        self._mouse_hook = None
        self._anchor = (0, 0)
        self._callback_failed = False
        self._user32 = None
        self._kernel32 = None
        self._kbd_proc_ref = None
        self._mouse_proc_ref = None

    # ------------------------------------------------------------------ Any thread

    @property
    def engaged(self) -> bool:
        return self._engaged

    def configure(self, settings: GamepadSettings) -> None:
        with self._lock:
            self._toggle_vk = normalize_vk(settings.toggle_vk)
            self._mouse_look = bool(settings.mouse_look)

    def start(self) -> bool:
        """Start the hook thread. False (with a warning) where low-level hooks do not exist."""
        if not kbm_supported():
            logger.warning(f"{TAG} Keyboard + mouse capture is only available on Windows")
            return False
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return True
            self._ready.clear()
            self._thread = threading.Thread(target=self._run, name="android-kbm-hook", daemon=True)
            self._thread.start()
        if not self._ready.wait(3.0):
            logger.error(f"{TAG} Keyboard + mouse hook thread did not start")
            return False
        return True

    def stop(self) -> None:
        with self._lock:
            thread, thread_id = self._thread, self._thread_id
            self._thread = None
        if thread is None:
            return
        try:
            if thread_id and self._user32 is not None:
                self._user32.PostThreadMessageW(thread_id, _WM_QUIT, 0, 0)
        except Exception as exc:  # noqa: BLE001
            logger.warning(f"{TAG} Could not signal the hook thread to stop: {exc}")
        if thread is not threading.current_thread():
            thread.join(2.0)
            if thread.is_alive():
                logger.warning(f"{TAG} Keyboard + mouse hook thread is still running after stop")

    # ------------------------------------------------------------------ Hook thread

    def _bind_api(self) -> None:
        # Private library objects: the prototypes set here must not leak into other modules' `windll.user32`.
        u = ctypes.WinDLL("user32", use_last_error=True)
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        lresult = ctypes.c_ssize_t
        self._hook_proc_t = ctypes.WINFUNCTYPE(lresult, ctypes.c_int, ctypes.c_size_t, ctypes.c_ssize_t)
        u.SetWindowsHookExW.restype = ctypes.c_void_p
        u.SetWindowsHookExW.argtypes = [ctypes.c_int, self._hook_proc_t, ctypes.c_void_p, ctypes.c_uint32]
        u.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
        u.CallNextHookEx.restype = lresult
        u.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t, ctypes.c_ssize_t]
        u.GetMessageW.argtypes = [ctypes.POINTER(_MSG), ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint]
        u.PostThreadMessageW.argtypes = [ctypes.c_uint32, ctypes.c_uint, ctypes.c_size_t, ctypes.c_ssize_t]
        u.SetTimer.restype = ctypes.c_size_t
        u.SetTimer.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint, ctypes.c_void_p]
        u.KillTimer.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
        u.GetCursorPos.argtypes = [ctypes.POINTER(_POINT)]
        k.GetModuleHandleW.restype = ctypes.c_void_p
        k.GetModuleHandleW.argtypes = [ctypes.c_wchar_p]
        k.GetCurrentThreadId.restype = ctypes.c_uint32
        self._user32, self._kernel32 = u, k
        # Keep the callback objects alive for as long as the hooks can call them.
        self._kbd_proc_ref = self._hook_proc_t(self._kbd_proc)
        self._mouse_proc_ref = self._hook_proc_t(self._mouse_proc)

    def _run(self) -> None:
        timer_id = 0
        try:
            self._bind_api()
            u = self._user32
            self._thread_id = int(self._kernel32.GetCurrentThreadId())
            timer_id = int(u.SetTimer(None, 0, GATE_POLL_MS, None))
            self._ready.set()
            logger.info(f"{TAG} Keyboard + mouse capture ready (hooks follow the emulator window's focus)")
            msg = _MSG()
            while u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == _WM_TIMER:
                    self._sync_hooks()
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Keyboard + mouse hook thread crashed")
        finally:
            self._ready.set()
            try:
                if timer_id and self._user32 is not None:
                    self._user32.KillTimer(None, timer_id)
                self._remove_hooks()
            except Exception:  # noqa: BLE001
                logger.exception(f"{TAG} Removing the keyboard + mouse hooks failed")
            self._thread_id = 0
            logger.info(f"{TAG} Keyboard + mouse capture stopped")

    def _sync_hooks(self) -> None:
        """Install the keyboard hook while the gate is open; drop everything the moment it closes."""
        try:
            wanted = bool(self._gate())
        except Exception:  # noqa: BLE001
            wanted = False
        if wanted and not self._kbd_hook:
            hmod = self._kernel32.GetModuleHandleW(None)
            self._kbd_hook = self._user32.SetWindowsHookExW(_WH_KEYBOARD_LL, self._kbd_proc_ref, hmod, 0)
            if not self._kbd_hook:
                logger.error(f"{TAG} Installing the keyboard hook failed (error {ctypes.get_last_error()})")
        elif not wanted and (self._kbd_hook or self._engaged):
            self._remove_hooks()

    def _remove_hooks(self) -> None:
        self._set_engaged(False)
        if self._kbd_hook and self._user32 is not None:
            self._user32.UnhookWindowsHookEx(self._kbd_hook)
        self._kbd_hook = None
        self._toggle_down = False

    def _set_engaged(self, engaged: bool) -> None:
        if engaged == self._engaged:
            return
        u = self._user32
        with self._lock:
            mouse_look = self._mouse_look
        if engaged:
            if mouse_look and u is not None:
                pt = _POINT()
                u.GetCursorPos(ctypes.byref(pt))
                self._anchor = (pt.x, pt.y)
                hmod = self._kernel32.GetModuleHandleW(None)
                self._mouse_hook = u.SetWindowsHookExW(_WH_MOUSE_LL, self._mouse_proc_ref, hmod, 0)
                if not self._mouse_hook:
                    logger.error(f"{TAG} Installing the mouse hook failed (error {ctypes.get_last_error()})")
        else:
            if self._mouse_hook and u is not None:
                u.UnhookWindowsHookEx(self._mouse_hook)
            self._mouse_hook = None
            self._swallowed.clear()
            self._mapper.release_all()
        self._engaged = engaged
        logger.info(f"{TAG} Game mode {'on' if engaged else 'off'} (mouse look={'on' if mouse_look else 'off'})")
        self._notify()
        if self._on_engaged is not None:
            try:
                self._on_engaged(engaged)
            except Exception:  # noqa: BLE001
                logger.exception(f"{TAG} Game mode listener failed")

    def _notify(self) -> None:
        try:
            self._on_change()
        except Exception:  # noqa: BLE001
            self._log_callback_failure()

    def _log_callback_failure(self) -> None:
        # Once per session: the hook procedures run for every key press and mouse movement.
        if not self._callback_failed:
            self._callback_failed = True
            logger.exception(f"{TAG} Input hook callback failed; the event was passed through")

    def _kbd_proc(self, n_code: int, w_param: int, l_param: int) -> int:
        try:
            if n_code == _HC_ACTION and self._handle_key(w_param, l_param):
                return 1
        except Exception:  # noqa: BLE001
            self._log_callback_failure()
        return self._user32.CallNextHookEx(None, n_code, w_param, l_param)

    def _handle_key(self, w_param: int, l_param: int) -> bool:
        """True when the key event is consumed."""
        info = ctypes.cast(l_param, ctypes.POINTER(_KBDLLHOOKSTRUCT)).contents
        if info.flags & _LLKHF_INJECTED:
            return False
        down = w_param in (_WM_KEYDOWN, _WM_SYSKEYDOWN)
        if not down and w_param not in (_WM_KEYUP, _WM_SYSKEYUP):
            return False
        vk = normalize_vk(int(info.vkCode))
        alt = bool(info.flags & _LLKHF_ALTDOWN)
        if vk == self._toggle_vk and not alt:
            if down and not self._toggle_down:
                self._toggle_down = True
                self._set_engaged(not self._engaged)
            elif not down:
                self._toggle_down = False
            return True
        if not self._engaged:
            return False
        if not down:
            # Only releases of keys this hook consumed are consumed: a key that was already held when game mode
            # came on must still be released in the emulator.
            if vk not in self._swallowed:
                return False
            self._swallowed.discard(vk)
            self._mapper.key_event(vk, False)
            self._notify()
            return True
        if alt:
            return False  # Alt+Tab and friends always reach Windows
        if self._mapper.key_event(vk, True):
            self._swallowed.add(vk)
            self._notify()
            return True
        return False

    def _mouse_proc(self, n_code: int, w_param: int, l_param: int) -> int:
        try:
            if n_code == _HC_ACTION and self._engaged and self._handle_mouse(w_param, l_param):
                return 1
        except Exception:  # noqa: BLE001
            self._log_callback_failure()
        return self._user32.CallNextHookEx(None, n_code, w_param, l_param)

    def _handle_mouse(self, w_param: int, l_param: int) -> bool:
        info = ctypes.cast(l_param, ctypes.POINTER(_MSLLHOOKSTRUCT)).contents
        if info.flags & _LLMHF_INJECTED:
            return False
        if w_param == _WM_MOUSEMOVE:
            # The move is swallowed, so the cursor stays on the anchor and `pt` is anchor + this movement.
            dx = info.pt.x - self._anchor[0]
            dy = info.pt.y - self._anchor[1]
            if dx or dy:
                self._mapper.mouse_move(dx, dy)
                self._notify()
            return True
        button = _MOUSE_BUTTON_MESSAGES.get(w_param)
        if button is None and w_param in (_WM_XBUTTONDOWN, _WM_XBUTTONUP):
            which = "x1" if ((info.mouseData >> 16) & 0xFFFF) == 1 else "x2"
            button = (which, w_param == _WM_XBUTTONDOWN)
        if button is not None:
            if self._mapper.mouse_button(button[0], button[1]):
                self._notify()
            return True  # while the cursor is held, a click must never touch the game screen
        return w_param in (_WM_MOUSEWHEEL, _WM_MOUSEHWHEEL)
