"""PC controller / keyboard + mouse -> virtual Android gamepad (UHID through a control-only scrcpy session).

Import the submodules directly (`bridge`, `hid`, `kbm`, `settings`): `hid` and `settings` stay free of Qt and of
the Android runtime so the gamepad thread can use them without pulling the whole Android stack in.
"""
