"""Settings of the Android gamepad bridge: mode, keyboard / mouse bindings, mouse sensitivity (config.json)."""

from __future__ import annotations

from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)
TAG = "[Android/GamepadSettings]"

CONFIG_KEY = "android_gamepad"

MODE_OFF = "off"
MODE_CONTROLLER = "controller"
MODE_KBM = "kbm"
MODES = (MODE_OFF, MODE_CONTROLLER, MODE_KBM)
MODE_LABELS = {
    MODE_OFF: "Tắt",
    MODE_CONTROLLER: "Tay cầm",
    MODE_KBM: "Phím + Chuột",
}

MIN_SENSITIVITY = 0.2
MAX_SENSITIVITY = 4.0

# Windows virtual-key codes (the low-level hook and Qt's nativeVirtualKey() both report these).
VK_BACK, VK_TAB, VK_RETURN, VK_SHIFT, VK_CONTROL, VK_MENU = 0x08, 0x09, 0x0D, 0x10, 0x11, 0x12
VK_ESCAPE, VK_SPACE, VK_LEFT, VK_UP, VK_RIGHT, VK_DOWN = 0x1B, 0x20, 0x25, 0x26, 0x27, 0x28
VK_DELETE = 0x2E
VK_F1 = 0x70
# Left / right variants reported by the low-level hook; bindings always store the generic code.
_SIDED_VK = {0xA0: VK_SHIFT, 0xA1: VK_SHIFT, 0xA2: VK_CONTROL, 0xA3: VK_CONTROL, 0xA4: VK_MENU, 0xA5: VK_MENU}

MOUSE_BUTTONS = ("left", "right", "middle", "x1", "x2")
_MOUSE_LABELS = {
    "left": "Chuột trái",
    "right": "Chuột phải",
    "middle": "Chuột giữa",
    "x1": "Chuột phụ 1",
    "x2": "Chuột phụ 2",
}

# (action id, label), in the order the settings dialog lists them.
ACTIONS: tuple[tuple[str, str], ...] = (
    ("ls_up", "Cần trái: lên"),
    ("ls_down", "Cần trái: xuống"),
    ("ls_left", "Cần trái: trái"),
    ("ls_right", "Cần trái: phải"),
    ("rs_up", "Cần phải: lên"),
    ("rs_down", "Cần phải: xuống"),
    ("rs_left", "Cần phải: trái"),
    ("rs_right", "Cần phải: phải"),
    ("dpad_up", "D-pad: lên"),
    ("dpad_down", "D-pad: xuống"),
    ("dpad_left", "D-pad: trái"),
    ("dpad_right", "D-pad: phải"),
    ("a", "Nút A"),
    ("b", "Nút B"),
    ("x", "Nút X"),
    ("y", "Nút Y"),
    ("lb", "LB / L1"),
    ("rb", "RB / R1"),
    ("lt", "LT / L2"),
    ("rt", "RT / R2"),
    ("l3", "Nhấn cần trái (L3)"),
    ("r3", "Nhấn cần phải (R3)"),
    ("back", "Back / Select"),
    ("start", "Start"),
    ("guide", "Guide / Home"),
)
ACTION_IDS = tuple(a for a, _ in ACTIONS)


def key_token(vk: int) -> str:
    return f"K:{int(vk)}"


def mouse_token(button: str) -> str:
    return f"M:{button}"


def normalize_vk(vk: int) -> int:
    """Fold left / right Shift, Ctrl and Alt into the generic key."""
    return _SIDED_VK.get(int(vk), int(vk))


DEFAULT_BINDINGS: dict[str, str] = {
    "ls_up": key_token(ord("W")),
    "ls_down": key_token(ord("S")),
    "ls_left": key_token(ord("A")),
    "ls_right": key_token(ord("D")),
    "rs_up": key_token(ord("I")),
    "rs_down": key_token(ord("K")),
    "rs_left": key_token(ord("J")),
    "rs_right": key_token(ord("L")),
    "dpad_up": key_token(VK_UP),
    "dpad_down": key_token(VK_DOWN),
    "dpad_left": key_token(VK_LEFT),
    "dpad_right": key_token(VK_RIGHT),
    "a": key_token(VK_SPACE),
    "b": key_token(VK_CONTROL),
    "x": key_token(ord("R")),
    "y": key_token(ord("F")),
    "lb": key_token(ord("Q")),
    "rb": key_token(ord("E")),
    "lt": mouse_token("right"),
    "rt": mouse_token("left"),
    "l3": key_token(VK_SHIFT),
    "r3": mouse_token("middle"),
    "back": key_token(VK_TAB),
    "start": key_token(VK_RETURN),
    "guide": "",
}

_VK_NAMES: dict[int, str] = {
    VK_BACK: "Backspace",
    VK_TAB: "Tab",
    VK_RETURN: "Enter",
    VK_SHIFT: "Shift",
    VK_CONTROL: "Ctrl",
    VK_MENU: "Alt",
    0x14: "Caps Lock",
    VK_ESCAPE: "Esc",
    VK_SPACE: "Space",
    0x21: "Page Up",
    0x22: "Page Down",
    0x23: "End",
    0x24: "Home",
    VK_LEFT: "Mũi tên trái",
    VK_UP: "Mũi tên lên",
    VK_RIGHT: "Mũi tên phải",
    VK_DOWN: "Mũi tên xuống",
    0x2D: "Insert",
    VK_DELETE: "Delete",
    0xBA: ";",
    0xBB: "=",
    0xBC: ",",
    0xBD: "-",
    0xBE: ".",
    0xBF: "/",
    0xC0: "`",
    0xDB: "[",
    0xDC: "\\",
    0xDD: "]",
    0xDE: "'",
}
for _c in range(ord("0"), ord("9") + 1):
    _VK_NAMES[_c] = chr(_c)
for _c in range(ord("A"), ord("Z") + 1):
    _VK_NAMES[_c] = chr(_c)
for _n in range(1, 13):
    _VK_NAMES[VK_F1 + _n - 1] = f"F{_n}"
for _n in range(10):
    _VK_NAMES[0x60 + _n] = f"Num {_n}"


def vk_name(vk: int) -> str:
    return _VK_NAMES.get(int(vk), f"Phím 0x{int(vk):02X}")


def parse_token(token: str) -> tuple[str, object] | None:
    """`("key", vk)` / `("mouse", button)` for a valid binding token, else None."""
    if not isinstance(token, str) or len(token) < 3 or token[1] != ":":
        return None
    kind, value = token[0], token[2:]
    if kind == "K":
        try:
            vk = int(value)
        except ValueError:
            return None
        return ("key", vk) if 0 < vk < 256 else None
    if kind == "M" and value in MOUSE_BUTTONS:
        return ("mouse", value)
    return None


def token_label(token: str) -> str:
    """What the settings dialog shows for a binding."""
    parsed = parse_token(token)
    if parsed is None:
        return "Chưa gán"
    kind, value = parsed
    return vk_name(int(value)) if kind == "key" else _MOUSE_LABELS[str(value)]


@dataclass
class GamepadSettings:
    mode: str = MODE_CONTROLLER
    mouse_look: bool = True
    mouse_sensitivity: float = 1.0
    toggle_vk: int = VK_F1
    bindings: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_BINDINGS))

    def copy(self) -> "GamepadSettings":
        return GamepadSettings(self.mode, self.mouse_look, self.mouse_sensitivity, self.toggle_vk, dict(self.bindings))

    def to_dict(self) -> dict:
        return {
            "mode": self.mode,
            "mouse_look": bool(self.mouse_look),
            "mouse_sensitivity": round(float(self.mouse_sensitivity), 2),
            "toggle_vk": int(self.toggle_vk),
            "bindings": dict(self.bindings),
        }

    @classmethod
    def from_dict(cls, raw: object) -> "GamepadSettings":
        """Validated settings; anything missing or malformed falls back to its default."""
        out = cls()
        if not isinstance(raw, dict):
            return out
        if raw.get("mode") in MODES:
            out.mode = raw["mode"]
        if isinstance(raw.get("mouse_look"), bool):
            out.mouse_look = raw["mouse_look"]
        try:
            sens = float(raw.get("mouse_sensitivity", 1.0))
            if sens == sens:
                out.mouse_sensitivity = min(MAX_SENSITIVITY, max(MIN_SENSITIVITY, sens))
        except (TypeError, ValueError):
            pass
        try:
            vk = int(raw.get("toggle_vk", VK_F1))
            if 0 < vk < 256:
                out.toggle_vk = vk
        except (TypeError, ValueError):
            pass
        stored = raw.get("bindings")
        if isinstance(stored, dict):
            for action in ACTION_IDS:
                if action not in stored:
                    continue
                token = stored[action]
                if token == "" or parse_token(token) is not None:
                    out.bindings[action] = token
        return out

    def bind(self, action: str, token: str) -> None:
        """Assign `token` to `action`; an input drives one action only, so it is taken off any other."""
        if action not in ACTION_IDS:
            return
        if token:
            for other, current in self.bindings.items():
                if other != action and current == token:
                    self.bindings[other] = ""
        self.bindings[action] = token


def load_gamepad_settings(cfg: dict | None = None) -> GamepadSettings:
    try:
        if cfg is None:
            from app.config import load_config

            cfg = load_config()
        return GamepadSettings.from_dict(cfg.get(CONFIG_KEY))
    except Exception:  # noqa: BLE001 - a broken config must never stop the player
        logger.exception(f"{TAG} Could not read gamepad settings, using defaults")
        return GamepadSettings()


def save_gamepad_settings(settings: GamepadSettings) -> bool:
    try:
        from app.config import load_config, save_config

        cfg = load_config()
        cfg[CONFIG_KEY] = settings.to_dict()
        ok = bool(save_config(cfg))
    except Exception:  # noqa: BLE001
        logger.exception(f"{TAG} Could not save gamepad settings")
        return False
    if ok:
        bound = sum(1 for t in settings.bindings.values() if t)
        logger.info(
            f"{TAG} Saved gamepad settings: mode={settings.mode}, mouse_look={settings.mouse_look}, "
            f"sensitivity={settings.mouse_sensitivity:.2f}, {bound} binding(s)"
        )
    else:
        logger.warning(f"{TAG} Gamepad settings were not written to the config file")
    return ok
