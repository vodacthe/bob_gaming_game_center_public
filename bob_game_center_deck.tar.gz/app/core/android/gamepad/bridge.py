"""PC input -> Android gamepad bridge.

Physical controllers (read by the app's GamepadMonitor through SDL) or keyboard + mouse (`kbm.py`) become
virtual HID gamepads inside the running Android runtime (`hid.py` over `channel.py`). One worker thread owns
the channel and the virtual devices; the UI thread only flips flags, the GamepadMonitor thread only hands over
controller snapshots.

Input is forwarded only while the player is the thing in front of the user:

* controllers: the emulator window has focus, or Bob Gaming has focus and the Android player is on screen.
  Holding Back + Start for a second hands the controller back to Bob Gaming's own UI (and back again);
* keyboard + mouse: the emulator window (or the scrcpy canvas) has keyboard focus, and game mode is on.

Away from that the virtual gamepads stay connected but neutral, so a game never sees a controller drop out.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
import os
import sys
import threading
import time
import weakref

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QApplication

from app.core.android.gamepad import hid
from app.core.android.gamepad.channel import ScrcpyControlChannel
from app.core.android.gamepad.kbm import KbmMapper, WinKbmHook, kbm_supported
from app.core.android.gamepad.settings import (
    MODE_CONTROLLER,
    MODE_KBM,
    MODE_OFF,
    GamepadSettings,
    vk_name,
)
from app.core.android.models import AndroidError, RuntimeInfo
from app.core.android.runtime import AndroidRuntimeManager

logger = logging.getLogger(__name__)
TAG = "[Android/Gamepad]"

FOREGROUND_OWN = "own"
FOREGROUND_EMULATOR = "emulator"
FOREGROUND_OTHER = "other"
_EMULATOR_TITLE_PREFIX = "Android Emulator"

STATE_OFF = "off"
STATE_IDLE = "idle"
STATE_CONNECTING = "connecting"
STATE_READY = "ready"
STATE_ACTIVE = "active"
STATE_ERROR = "error"

FOREGROUND_POLL_S = 0.2
FEED_STALE_S = 0.5
RELEASE_COMBO = hid.BTN_BACK | hid.BTN_START
RELEASE_COMBO_HOLD_S = 1.0
RECONNECT_MIN_S = 1.0
RECONNECT_MAX_S = 15.0
IDLE_WAIT_S = 0.1
MOUSE_TICK_S = 0.006
DISABLE_ENV = "BOBGAMING_ANDROID_GAMEPAD_DISABLE"  # "1": never start the bridge (test-suite, troubleshooting)


@dataclass(frozen=True)
class BridgeStatus:
    state: str = STATE_OFF
    text: str = "Điều khiển Android bằng tay cầm đang tắt"
    pads: int = 0


class ForegroundProbe:
    """Whose window has the keyboard: Bob Gaming's, the Android emulator's, or another program's."""

    def __init__(self) -> None:
        self._user32 = None
        self._app_active = True
        if sys.platform == "win32":
            try:
                import ctypes

                u = ctypes.WinDLL("user32")
                u.GetForegroundWindow.restype = ctypes.c_void_p
                u.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
                u.GetWindowTextW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_int]
                self._ctypes = ctypes
                self._user32 = u
            except Exception as exc:  # noqa: BLE001
                logger.warning(f"{TAG} Foreground window API unavailable, falling back to app focus: {exc}")

    def set_app_active(self, active: bool) -> None:
        """Qt's own idea of focus: the only signal there is where the Win32 API is not available."""
        self._app_active = bool(active)

    def classify(self) -> str:
        u = self._user32
        if u is None:
            return FOREGROUND_OWN if self._app_active else FOREGROUND_OTHER
        try:
            hwnd = u.GetForegroundWindow()
            if not hwnd:
                return FOREGROUND_OTHER
            pid = self._ctypes.c_ulong(0)
            u.GetWindowThreadProcessId(hwnd, self._ctypes.byref(pid))
            if pid.value == os.getpid():
                return FOREGROUND_OWN
            buf = self._ctypes.create_unicode_buffer(64)
            u.GetWindowTextW(hwnd, buf, 64)
            return FOREGROUND_EMULATOR if buf.value.startswith(_EMULATOR_TITLE_PREFIX) else FOREGROUND_OTHER
        except Exception:  # noqa: BLE001 - polled several times a second: never raise, never log per call
            return FOREGROUND_OTHER


@dataclass
class _Device:
    device_id: int
    name: str
    last_report: bytes = b""


_bridges: "weakref.WeakSet[AndroidGamepadBridge]" = weakref.WeakSet()
_bridges_lock = threading.Lock()
_quit_hooked = False


def _shutdown_all_on_quit() -> None:
    with _bridges_lock:
        bridges = list(_bridges)
    for bridge in bridges:
        try:
            bridge.shutdown()
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Stopping a gamepad bridge at exit failed")


class AndroidGamepadBridge(QObject):
    """Owns the worker thread that mirrors PC input into virtual Android gamepads."""

    status_changed = Signal(object)  # BridgeStatus

    def __init__(
        self,
        runtime_mgr: AndroidRuntimeManager,
        parent: QObject | None = None,
        *,
        channel_factory=None,
        probe: ForegroundProbe | None = None,
        hook_factory=None,
    ) -> None:
        super().__init__(parent)
        self._runtime_mgr = runtime_mgr
        self._channel_factory = channel_factory or (lambda: ScrcpyControlChannel(runtime_mgr))
        self._probe = probe or ForegroundProbe()
        self._hook_factory = hook_factory or WinKbmHook
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._gen = 0
        self._thread: threading.Thread | None = None
        self._thread_target: tuple[str, str] = ("", "")  # (adb path, serial) the running worker feeds
        self._settings = GamepadSettings()
        self._runtime: RuntimeInfo | None = None
        self._player_active = False
        self._canvas_focused = False
        self._fed: list[tuple[int, str, hid.PadState]] = []
        self._fed_at = 0.0
        # Written by the worker, read lock-free by the GamepadMonitor thread on every poll.
        self._pads_wanted = False
        self._forwarding = False
        self._kbm_channel_ready = False
        self._status = BridgeStatus()
        self._mapper = KbmMapper(self._settings)
        self._register_for_quit()

    def _register_for_quit(self) -> None:
        global _quit_hooked
        with _bridges_lock:
            _bridges.add(self)
            app = QApplication.instance()
            if app is not None and not _quit_hooked:
                app.aboutToQuit.connect(_shutdown_all_on_quit)
                _quit_hooked = True

    # ------------------------------------------------------------------ UI thread

    @property
    def status(self) -> BridgeStatus:
        with self._lock:
            return self._status

    @property
    def settings(self) -> GamepadSettings:
        with self._lock:
            return self._settings.copy()

    def set_settings(self, settings: GamepadSettings) -> None:
        fresh = settings.copy()
        with self._lock:
            previous_mode = self._settings.mode
            self._settings = fresh
        self._mapper.apply_settings(fresh)
        if fresh.mode != previous_mode:
            logger.info(f"{TAG} Input mode changed: {previous_mode} -> {fresh.mode}")
        self._reconcile()

    def set_runtime(self, runtime: RuntimeInfo | None) -> None:
        """The running Android runtime to feed, or None when there is none."""
        with self._lock:
            self._runtime = runtime if runtime is not None and runtime.running else None
        self._reconcile()

    def set_player_active(self, active: bool) -> None:
        """Whether the Android display is in front of the user (docked and visible, fullscreen or popped out)."""
        with self._lock:
            self._player_active = bool(active)
        self._wake.set()

    def set_canvas_focused(self, focused: bool) -> None:
        """Whether Bob Gaming's own Android canvas (scrcpy path) has keyboard focus."""
        with self._lock:
            self._canvas_focused = bool(focused)
        self._wake.set()

    def set_app_active(self, active: bool) -> None:
        self._probe.set_app_active(active)
        self._wake.set()

    def shutdown(self) -> None:
        """Stop the worker and remove the virtual gamepads. Safe to call more than once."""
        with self._lock:
            self._runtime = None
        self._stop_worker(join=True)

    def _reconcile(self) -> None:
        with self._lock:
            runtime = self._runtime
            mode = self._settings.mode
            thread = self._thread
            target = self._thread_target
        wanted = runtime is not None and mode != MODE_OFF and os.environ.get(DISABLE_ENV) != "1"
        running = thread is not None and thread.is_alive()
        if wanted and running and target != (runtime.adb_path or "", runtime.adb_serial or ""):
            logger.info(f"{TAG} Android runtime changed; restarting the gamepad bridge")
            self._stop_worker(join=False)
            running = False
        if wanted and not running:
            self._start_worker(runtime)
        elif not wanted:
            self._stop_worker(join=False)
            if mode == MODE_OFF:
                self._set_status(BridgeStatus())
            else:
                self._set_status(BridgeStatus(STATE_IDLE, "Chờ máy ảo Android khởi động"))
        else:
            self._wake.set()

    def _start_worker(self, runtime: RuntimeInfo) -> None:
        with self._lock:
            self._gen += 1
            gen = self._gen
            thread = threading.Thread(
                target=self._worker, args=(gen, runtime), name=f"android-gamepad-{gen}", daemon=True
            )
            self._thread = thread
            self._thread_target = (runtime.adb_path or "", runtime.adb_serial or "")
        logger.info(f"{TAG} Starting gamepad bridge for {runtime.label} ({runtime.adb_serial or 'adb'})")
        thread.start()

    def _stop_worker(self, join: bool) -> None:
        with self._lock:
            thread = self._thread
            self._thread = None
            self._thread_target = ("", "")
            self._gen += 1
        self._pads_wanted = False
        self._forwarding = False
        self._wake.set()
        if thread is not None and join and thread is not threading.current_thread():
            thread.join(3.0)
            if thread.is_alive():
                logger.warning(f"{TAG} Gamepad bridge thread is still running after stop")

    # ------------------------------------------------------------------ GamepadMonitor thread

    def wants_pads(self) -> bool:
        """True while controller snapshots are worth reading (called on every monitor poll: keep it trivial)."""
        return self._pads_wanted

    def feed_pads(self, pads: list[tuple[int, str, hid.PadState]]) -> bool:
        """Latest state of every attached controller. Returns True when the input is being sent to Android,
        i.e. the app must not also act on it (UI navigation)."""
        with self._lock:
            self._fed = pads
            self._fed_at = time.monotonic()
        self._wake.set()
        return self._forwarding

    # ------------------------------------------------------------------ Hook thread

    def _kbm_gate(self) -> bool:
        if not self._kbm_channel_ready:
            return False
        with self._lock:
            if self._settings.mode != MODE_KBM:
                return False
            canvas_focused = self._canvas_focused
        where = self._probe.classify()
        return where == FOREGROUND_EMULATOR or (where == FOREGROUND_OWN and canvas_focused)

    # ------------------------------------------------------------------ Worker thread

    def _is_current(self, gen: int) -> bool:
        with self._lock:
            return self._gen == gen

    def _set_status(self, status: BridgeStatus, gen: int | None = None) -> None:
        """Publish a status. A worker passes its generation so a stopped one can never overwrite newer state."""
        with self._lock:
            if (gen is not None and gen != self._gen) or status == self._status:
                return
            self._status = status
        try:
            self.status_changed.emit(status)
        except RuntimeError:
            pass  # the Qt object is already deleted (app exit); nobody is listening

    def _worker(self, gen: int, runtime: RuntimeInfo) -> None:
        try:
            self._worker_loop(gen, runtime)
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Gamepad bridge thread crashed")
            self._set_status(
                BridgeStatus(STATE_ERROR, "Lỗi bộ chuyển tay cầm, xem nhật ký để biết chi tiết"), gen
            )

    def _worker_loop(self, gen: int, runtime: RuntimeInfo) -> None:
        channel: ScrcpyControlChannel | None = None
        devices: dict[tuple[str, int], _Device] = {}
        hook = None
        hook_broken = False
        next_connect = 0.0
        backoff = RECONNECT_MIN_S
        connect_failures = 0
        last_error = ""
        foreground = FOREGROUND_OTHER
        last_foreground = 0.0
        released = False  # the user handed the controller back to Bob Gaming's UI
        combo_since = 0.0
        combo_fired = False
        slots_full_logged = False
        t_start = time.monotonic()
        try:
            while self._is_current(gen):
                self._wake.clear()
                now = time.monotonic()
                with self._lock:
                    settings = self._settings
                    player_active = self._player_active
                    fed = self._fed
                    fed_fresh = (now - self._fed_at) < FEED_STALE_S
                mode = settings.mode

                if now - last_foreground >= FOREGROUND_POLL_S:
                    foreground = self._probe.classify()
                    last_foreground = now

                # ---- channel
                if channel is not None and not channel.alive:
                    logger.warning(f"{TAG} Lost the control channel to {channel.serial}; reconnecting")
                    channel.close()
                    channel = None
                    devices.clear()
                    next_connect = now + RECONNECT_MIN_S
                if channel is None and now >= next_connect:
                    if not last_error:
                        self._set_status(BridgeStatus(STATE_CONNECTING, "Đang kết nối tay cầm vào Android..."), gen)
                    candidate = self._channel_factory()
                    try:
                        candidate.open(runtime, lambda: not self._is_current(gen))
                        channel = candidate
                        if connect_failures:
                            logger.info(f"{TAG} Control channel restored after {connect_failures} failed attempt(s)")
                        connect_failures = 0
                        backoff = RECONNECT_MIN_S
                        last_error = ""
                    except AndroidError as exc:
                        connect_failures += 1
                        last_error = str(exc)
                        if connect_failures == 1:  # one warning per failure streak, retries stay quiet
                            logger.warning(f"{TAG} Could not open the control channel: {exc}")
                        next_connect = time.monotonic() + backoff
                        backoff = min(RECONNECT_MAX_S, backoff * 2.0)
                connected = channel is not None

                # ---- desired virtual devices
                desired: dict[tuple[str, int], tuple[str, hid.PadState]] = {}
                engaged = False
                kbm_unavailable = False
                if mode == MODE_CONTROLLER:
                    if hook is not None:
                        hook.stop()
                        hook = None
                    self._kbm_channel_ready = False
                    in_front = foreground == FOREGROUND_EMULATOR or (foreground == FOREGROUND_OWN and player_active)
                    if in_front and fed_fresh and fed:
                        if any(state.holds(RELEASE_COMBO) for _i, _n, state in fed):
                            if not combo_since:
                                combo_since = now
                            elif not combo_fired and now - combo_since >= RELEASE_COMBO_HOLD_S:
                                combo_fired = True
                                released = not released
                                logger.info(
                                    f"{TAG} Back + Start held: controller now drives "
                                    f"{'Bob Gaming' if released else 'Android'}"
                                )
                        else:
                            combo_since = 0.0
                            combo_fired = False
                    else:
                        combo_since = 0.0
                        combo_fired = False
                    forwarding = connected and in_front and not released
                    self._pads_wanted = connected and in_front
                    self._forwarding = forwarding and fed_fresh and bool(fed)
                    if fed_fresh:
                        for instance_id, name, state in fed:
                            desired[("pad", int(instance_id))] = (name, state if forwarding else hid.NEUTRAL_PAD)
                    else:
                        # No news from the monitor (it is paused or not started): keep what exists, at rest.
                        for key, dev in devices.items():
                            if key[0] == "pad":
                                desired[key] = (dev.name, hid.NEUTRAL_PAD)
                elif mode == MODE_KBM:
                    self._pads_wanted = False
                    self._forwarding = False
                    released = False
                    if hook_broken or not kbm_supported():
                        kbm_unavailable = True
                    else:
                        self._kbm_channel_ready = connected
                        if hook is None:
                            hook = self._hook_factory(self._mapper, self._kbm_gate, self._wake.set)
                            if not hook.start():
                                hook = None
                                hook_broken = True  # reported once by the hook; do not retry every tick
                                kbm_unavailable = True
                        if hook is not None:
                            hook.configure(settings)
                            engaged = bool(hook.engaged)
                            state = self._mapper.snapshot(now) if engaged else hid.NEUTRAL_PAD
                            desired[("kbm", 0)] = (hid.GAMEPAD_NAME, state)
                else:
                    self._pads_wanted = False
                    self._forwarding = False
                    self._kbm_channel_ready = False

                # ---- push to Android
                if channel is not None:
                    skipped = self._sync_devices(channel, devices, desired)
                    if skipped and not slots_full_logged:
                        slots_full_logged = True
                        logger.warning(f"{TAG} More than {hid.MAX_PADS} controllers: {skipped} extra one(s) ignored")
                    elif not skipped:
                        slots_full_logged = False

                self._set_status(
                    self._describe(
                        mode, connected, last_error, len(devices), self._forwarding, released, engaged,
                        kbm_unavailable, settings,
                    ),
                    gen,
                )

                if mode == MODE_KBM and engaged and not self._mapper.is_settled():
                    time.sleep(MOUSE_TICK_S)  # mouse look is integrated over time: tick while it plays out
                else:
                    self._wake.wait(IDLE_WAIT_S)
        finally:
            self._pads_wanted = False
            self._forwarding = False
            self._kbm_channel_ready = False
            if hook is not None:
                try:
                    hook.stop()
                except Exception:  # noqa: BLE001
                    logger.exception(f"{TAG} Stopping keyboard + mouse capture failed")
            if channel is not None:
                try:
                    for dev in devices.values():
                        channel.send(hid.pack_uhid_destroy(dev.device_id))
                    channel.close()
                except Exception:  # noqa: BLE001
                    logger.exception(f"{TAG} Closing the control channel failed")
            devices.clear()
            logger.info(f"{TAG} Gamepad bridge stopped after {time.monotonic() - t_start:.1f}s")

    def _sync_devices(
        self,
        channel: ScrcpyControlChannel,
        devices: dict[tuple[str, int], _Device],
        desired: dict[tuple[str, int], tuple[str, hid.PadState]],
    ) -> int:
        """Create / remove virtual gamepads and send the reports that changed. Returns how many controllers
        did not get a slot."""
        for key in [k for k in devices if k not in desired]:
            dev = devices.pop(key)
            channel.send(hid.pack_uhid_destroy(dev.device_id))
            logger.info(f"{TAG} Removed Android gamepad #{dev.device_id} ({dev.name})")
        skipped = 0
        for key, (name, state) in desired.items():
            dev = devices.get(key)
            if dev is None:
                used = {d.device_id for d in devices.values()}
                device_id = next((i for i in range(1, hid.MAX_PADS + 1) if i not in used), 0)
                if not device_id:
                    skipped += 1
                    continue
                if not channel.send(hid.pack_uhid_create(device_id, name=name)):
                    return skipped
                dev = _Device(device_id, name)
                devices[key] = dev
                logger.info(f"{TAG} Created Android gamepad #{device_id} for {name}")
            report = hid.pack_report(state)
            if report != dev.last_report:
                if not channel.send(hid.pack_uhid_input(dev.device_id, report)):
                    return skipped
                dev.last_report = report
        return skipped

    @staticmethod
    def _describe(
        mode: str,
        connected: bool,
        last_error: str,
        pads: int,
        forwarding: bool,
        released: bool,
        engaged: bool,
        kbm_unavailable: bool,
        settings: GamepadSettings,
    ) -> BridgeStatus:
        if mode == MODE_OFF:
            return BridgeStatus()
        if mode == MODE_KBM and kbm_unavailable:
            return BridgeStatus(STATE_ERROR, "Phím + chuột giả tay cầm chỉ dùng được trên Windows")
        if not connected:
            if last_error:
                return BridgeStatus(STATE_ERROR, f"Chưa kết nối được tay cầm vào Android: {last_error}")
            return BridgeStatus(STATE_CONNECTING, "Đang kết nối tay cầm vào Android...")
        if mode == MODE_KBM:
            key = vk_name(settings.toggle_vk)
            if engaged:
                return BridgeStatus(STATE_ACTIVE, f"Phím + chuột đang giả lập tay cầm (bấm {key} để tắt)", pads)
            return BridgeStatus(
                STATE_READY, f"Bấm vào màn hình Android rồi bấm {key} để bật phím + chuột giả tay cầm", pads
            )
        if pads == 0:
            return BridgeStatus(STATE_READY, "Chưa thấy tay cầm nào cắm vào máy tính")
        if released:
            return BridgeStatus(
                STATE_READY, "Tay cầm đang điều khiển Bob Gaming (giữ Back + Start 1 giây để trả về Android)", pads
            )
        if forwarding:
            return BridgeStatus(
                STATE_ACTIVE, f"Đang chuyển {pads} tay cầm vào Android (giữ Back + Start 1 giây để tạm nhả)", pads
            )
        return BridgeStatus(STATE_READY, f"{pads} tay cầm sẵn sàng, mở màn hình Android để chơi", pads)
