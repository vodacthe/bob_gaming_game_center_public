"""Cross-platform Android Runtime discovery, on-demand Google SDK provisioning, and ADB/Waydroid control."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import hashlib
import json
import logging
import os
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import threading
import time
from typing import Callable
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

from app.core.android.models import (
    RUNTIME_EXTERNAL_ADB,
    RUNTIME_PORTABLE_SDK,
    RUNTIME_SYSTEM_SDK,
    RUNTIME_WAYDROID,
    AndroidError,
    RuntimeInfo,
    get_runtime_dir,
    is_valid_package_name,
)
from app.core.binary_finder import ensure_executable_permission, find_aria2c
from app.core.online_fix.aria2_downloader import PROGRESS_REGEX, parse_size_to_bytes
from app.core.online_fix.extractor import clean_subprocess_env

logger = logging.getLogger(__name__)
TAG = "[Android/Runtime]"

GOOGLE_REPO_BASE = "https://dl.google.com/android/repository/"
GOOGLE_REPO_XML = GOOGLE_REPO_BASE + "repository2-3.xml"
GOOGLE_AEHD_URL = GOOGLE_REPO_BASE + "aehd-windows_v2.2.zip"
GOOGLE_APIS_SYSIMG_BASE = GOOGLE_REPO_BASE + "sys-img/google_apis/"
GOOGLE_APIS_SYSIMG_XML = GOOGLE_APIS_SYSIMG_BASE + "sys-img2-3.xml"

MICROG_RELEASES_API = "https://api.github.com/repos/ReVanced/GmsCore/releases/latest"
MICROG_NONROOT_FALLBACK_URL = (
    "https://github.com/ReVanced/GmsCore/releases/download/v0.3.13.2.250932/"
    "app.revanced.android.gms-250932004-signed.apk"
)
MICROG_GMSCORE_FALLBACK_URL = (
    "https://github.com/microg/GmsCore/releases/download/v0.3.17.252432/com.google.android.gms-252432034.apk"
)
MICROG_VENDING_FALLBACK_URL = (
    "https://github.com/microg/GmsCore/releases/download/v0.3.17.252432/com.android.vending-84022634.apk"
)
MICROG_PACKAGE_ID = "app.revanced.android.gms"
SLIM_PROFILE_MARKER = ".bob_slim_microg_v5"
SCRCPY_SERVER_URL = "https://github.com/Genymobile/scrcpy/releases/download/v3.1/scrcpy-server-v3.1"
SCRCPY_SERVER_SHA256 = "958f0944a62f23b1f33a16e9eb14844c1a04b882ca175a738c16d23cb22b86c0"

TARGET_SYSIMG_TAG = "google_apis"


@dataclass(frozen=True)
class PortableProfile:
    """One managed Google system image + AVD that Bob Gaming downloads, boots and controls itself."""

    runtime_id: str
    api_level: str
    avd_name: str
    display_name: str
    abi_label: str
    purpose: str
    size_hint: str
    supports_arm32: bool
    abis: tuple[str, ...]

    @property
    def platform_pkg(self) -> str:
        return f"platforms;android-{self.api_level}"

    @property
    def sysimg_pkg(self) -> str:
        return f"system-images;android-{self.api_level};{TARGET_SYSIMG_TAG};x86_64"

    @property
    def sysdir_rel(self) -> str:
        return f"system-images/android-{self.api_level}/{TARGET_SYSIMG_TAG}/x86_64/"

    def label(self, accel_label: str) -> str:
        return f"{self.display_name} (microG + {self.abi_label}, {accel_label})"


# Android 14 (API 34) ships Google's current ARM64 -> x86_64 translator. Measured on the same host with the same
# ARM64 Unity game (Ryzen 9 5950X, WHPX): API 30 rendered 21-26 FPS with the game's main thread pinned at ~90% CPU
# (82% of it inside libndk_translation's translated code), API 34 holds the game's 60 FPS cap at ~30% CPU and
# composites 120 FPS. API 31+ x86_64 images are 64-bit only, though, so Android 11 (API 30), the last official
# Google image that also translates 32-bit ARM (armeabi-v7a), stays available as a second runtime for older games.
PROFILE_ANDROID_14 = PortableProfile(
    runtime_id=RUNTIME_PORTABLE_SDK,
    api_level="34",
    avd_name="BobAndroid",
    display_name="Bob Android 14",
    abi_label="ARM64",
    purpose="hiệu năng cao, game ARM64",
    size_hint="~1.6 GB",
    supports_arm32=False,
    abis=("x86_64", "arm64-v8a"),
)
PROFILE_ANDROID_11 = PortableProfile(
    runtime_id="portable_sdk_arm32",
    api_level="30",
    avd_name="BobAndroid11",
    display_name="Bob Android 11",
    abi_label="ARM64/ARM32",
    purpose="chạy được game ARM 32-bit đời cũ",
    size_hint="~1.5 GB",
    supports_arm32=True,
    abis=("x86_64", "x86", "arm64-v8a", "armeabi-v7a", "armeabi"),
)
PORTABLE_PROFILES: tuple[PortableProfile, ...] = (PROFILE_ANDROID_14, PROFILE_ANDROID_11)
ARM32_RUNTIME_ID = PROFILE_ANDROID_11.runtime_id

# Default (Android 14) profile, kept as module constants for callers that predate the second runtime.
TARGET_API_LEVEL = PROFILE_ANDROID_14.api_level
RUNTIME_DISPLAY_NAME = PROFILE_ANDROID_14.display_name
TARGET_PLATFORM_PKG = PROFILE_ANDROID_14.platform_pkg
TARGET_SYSIMG_PKG = PROFILE_ANDROID_14.sysimg_pkg
DEFAULT_AVD_NAME = PROFILE_ANDROID_14.avd_name


def get_portable_profile(key: str = "") -> PortableProfile:
    """Return the managed profile whose runtime id or AVD name is `key` (Android 14 when unknown)."""
    for prof in PORTABLE_PROFILES:
        if key and key in (prof.runtime_id, prof.avd_name):
            return prof
    return PROFILE_ANDROID_14


def is_portable_runtime_id(runtime_id: str) -> bool:
    return any(runtime_id == prof.runtime_id for prof in PORTABLE_PROFILES)
WAYDROID_DEFAULT_ADB = "192.168.240.112:5555"

_CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def native_embed_enabled(platform_name: str = sys.platform) -> bool:
    """True when the player shows the emulator's own GPU window (Windows) instead of a scrcpy video stream.

    `BOBGAMING_ANDROID_DISPLAY=scrcpy` forces the encoded-stream path (also used by the test-suite).
    """
    if platform_name != "win32":
        return False
    return os.environ.get("BOBGAMING_ANDROID_DISPLAY", "").strip().lower() != "scrcpy"


def run_aria2_http_download(
    aria2_bin: str,
    url: str,
    dest_file: str,
    user_agent: str = "Mozilla/5.0",
    expected_size: int = 0,
    progress_cb: Callable[[int, int, int], None] | None = None,
    is_cancelled: Callable[[], bool] | None = None,
    cancel_message: str = "Đã hủy tải xuống.",
    log_tag: str = TAG,
) -> bool:
    """Run aria2c for a single HTTP(S) file while draining stdout to prevent pipe deadlocks."""
    os.makedirs(os.path.dirname(dest_file), exist_ok=True)
    cmd = [
        aria2_bin,
        "--allow-overwrite=true",
        "--auto-file-renaming=false",
        "--file-allocation=none",
        "--continue=true",
        "-x", "8",
        "-s", "8",
        "--connect-timeout=15",
        "--timeout=20",
        "--max-tries=3",
        "--retry-wait=2",
        "--summary-interval=1",
        "--console-log-level=warn",
        f"--user-agent={user_agent}",
        "-d", os.path.dirname(dest_file),
        "-o", os.path.basename(dest_file),
        url,
    ]
    t0 = time.monotonic()
    tail: deque[str] = deque(maxlen=6)
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
        **_subprocess_kwargs(),
    )

    def _drain_stdout() -> None:
        if proc.stdout is None:
            return
        try:
            for raw in proc.stdout:
                line = raw.strip()
                if not line:
                    continue
                m = PROGRESS_REGEX.search(line)
                if m:
                    if progress_cb:
                        done_b = parse_size_to_bytes(m.group(1))
                        tot_b = parse_size_to_bytes(m.group(2)) or expected_size
                        spd_b = parse_size_to_bytes(m.group(4).removesuffix("/s"))
                        progress_cb(done_b, max(done_b, tot_b), spd_b)
                elif not line.startswith(("---", "===", "Status Legend:", "(OK):", "gid|")):
                    tail.append(line)
        except Exception:
            pass

    reader = threading.Thread(target=_drain_stdout, name="android-aria2-stdout", daemon=True)
    reader.start()
    try:
        while proc.poll() is None:
            if is_cancelled and is_cancelled():
                proc.kill()
                raise AndroidError(cancel_message)
            time.sleep(0.25)
        rc = proc.wait(timeout=5)
        reader.join(timeout=2.0)
    finally:
        if proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass

    if rc == 0 and os.path.isfile(dest_file) and not os.path.exists(dest_file + ".aria2"):
        final_sz = os.path.getsize(dest_file)
        if final_sz > 64:
            if progress_cb:
                progress_cb(final_sz, max(final_sz, expected_size), 0)
            return True

    detail = "; ".join(tail) or f"exit={rc}"
    logger.warning(f"{log_tag} aria2c failed for {url} in {time.monotonic() - t0:.2f}s ({detail})")
    return False


def _clean_android_env(overrides: dict[str, str] | None = None) -> dict[str, str]:
    """Return a child environment stripped of PyInstaller/PySide6 DLL & Qt plugin paths."""
    base = clean_subprocess_env()
    for var in (
        "QT_QPA_PLATFORM",
        "QT_QPA_PLATFORM_PLUGIN_PATH",
        "QT_STYLE_OVERRIDE",
        "QML_IMPORT_PATH",
    ):
        base.pop(var, None)
    if sys.platform != "win32" and "LD_LIBRARY_PATH_ORIG" in base:
        orig = base.pop("LD_LIBRARY_PATH_ORIG")
        if orig:
            base["LD_LIBRARY_PATH"] = orig
        else:
            base.pop("LD_LIBRARY_PATH", None)
    if overrides:
        for k, v in overrides.items():
            if k in (
                "_MEIPASS",
                "_MEIPASS2",
                "QT_PLUGIN_PATH",
                "QT_QPA_PLATFORM",
                "QT_QPA_PLATFORM_PLUGIN_PATH",
                "QML2_IMPORT_PATH",
                "QML_IMPORT_PATH",
                "PYTHONHOME",
                "PYTHONPATH",
            ):
                continue
            if k == "PATH":
                continue
            base[k] = v
        sdk_root = overrides.get("ANDROID_SDK_ROOT") or overrides.get("ANDROID_HOME") or ""
        if sdk_root and os.path.isdir(sdk_root):
            pt_dir = os.path.join(sdk_root, "platform-tools")
            em_dir = os.path.join(sdk_root, "emulator")
            raw_parts = (base.get("PATH") or "").split(os.pathsep)
            kept_parts = [
                p
                for p in raw_parts
                if p and "platform-tools" not in os.path.normcase(p)
            ]
            prefix = [d for d in (pt_dir, em_dir) if os.path.isdir(d)]
            base["PATH"] = os.pathsep.join([*prefix, *kept_parts])
    return base


def _subprocess_kwargs(env: dict[str, str] | None = None, cwd: str | None = None) -> dict:
    kw: dict = {"stdin": subprocess.DEVNULL, "env": _clean_android_env(env)}
    if cwd is not None:
        kw["cwd"] = cwd
    if sys.platform == "win32":
        kw["creationflags"] = _CREATE_NO_WINDOW
    return kw


def _exe_name(base: str, platform_name: str = sys.platform) -> str:
    return f"{base}.exe" if platform_name == "win32" else base


def _host_os_tag(platform_name: str = sys.platform) -> str:
    if platform_name == "win32":
        return "windows"
    if platform_name.startswith("linux"):
        return "linux"
    if platform_name == "darwin":
        return "macosx"
    raise AndroidError(f"Hệ điều hành chưa được hỗ trợ cho Android Runtime: {platform_name}")


def is_firmware_virtualization_enabled(platform_name: str = sys.platform) -> bool:
    """Return True if CPU hardware virtualization (AMD SVM / Intel VT-x / Linux KVM) is enabled in BIOS."""
    if platform_name == "win32":
        try:
            import ctypes

            # Win32 PF_VIRT_FIRMWARE_ENABLED = 21 (True whether Hyper-V is active or not; False if disabled in BIOS)
            return bool(ctypes.windll.kernel32.IsProcessorFeaturePresent(21))
        except Exception:
            return True
    if platform_name.startswith("linux"):
        return os.path.exists("/dev/kvm")
    return True


def check_virtualization_hint(platform_name: str = sys.platform) -> str:
    """Return a non-empty Vietnamese guidance message if host hardware acceleration is disabled in BIOS/OS."""
    if platform_name == "win32":
        if not is_firmware_virtualization_enabled("win32"):
            return (
                "CPU đang tắt ảo hóa phần cứng trong BIOS (SVM Mode trên AMD Ryzen / Intel VT-x trên Intel).\n\n"
                "Cách bật trong 30 giây:\n"
                "1. Khởi động lại máy, bấm phím Del hoặc F2 để vào BIOS.\n"
                "2. Trên CPU AMD: vào OC / Tweaker -> Advanced CPU Configuration -> chuyển 'SVM Mode' sang Enabled.\n"
                "   Trên CPU Intel: bật 'Intel Virtualization Technology (VT-x)' sang Enabled.\n"
                "3. Bấm F10 để Lưu & Khởi động lại — sau đó mở lại Bob Gaming Game Center, ứng dụng sẽ tự cài đặt trình tăng tốc phần cứng tự động!"
            )
        return ""
    if platform_name.startswith("linux"):
        if not os.path.exists("/dev/kvm"):
            return "Máy Linux chưa bật KVM (/dev/kvm không tồn tại) — hãy bật Intel VT-x / AMD SVM trong BIOS."
        if not os.access("/dev/kvm", os.R_OK | os.W_OK):
            return "Tài khoản hiện tại chưa có quyền truy cập /dev/kvm (thêm user vào nhóm kvm để tăng tốc GPU/CPU)."
    return ""


def parse_sdk_archive_from_xml(
    xml_bytes: bytes,
    package_path: str,
    base_url: str,
    host_os: str,
    host_arch: str = "x64",
) -> tuple[str, int, str, str]:
    """
    Parse Google repository XML and return (download_url, size_bytes, checksum_hex, checksum_type)
    for the latest non-preview archive matching package_path and host_os.
    """
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as exc:
        raise AndroidError(f"Không đọc được manifest SDK từ Google: {exc}") from exc

    best: tuple[tuple[int, ...], str, int, str, str] | None = None
    for pkg in root.iter("remotePackage"):
        if pkg.attrib.get("path") != package_path:
            continue
        ch_ref = pkg.find("channelRef")
        if ch_ref is not None and ch_ref.attrib.get("ref") not in (None, "", "channel-0"):
            # Skip canary/beta channels when stable channel-0 exists
            continue
        rev_node = pkg.find("revision")
        rev_tuple = (0, 0, 0)
        if rev_node is not None:
            rev_tuple = (
                int(rev_node.findtext("major") or 0),
                int(rev_node.findtext("minor") or 0),
                int(rev_node.findtext("micro") or 0),
            )
        for arch in pkg.iter("archive"):
            a_os = (arch.findtext("host-os") or "any").strip()
            a_arch = (arch.findtext("host-arch") or "any").strip()
            if a_os not in ("any", host_os):
                continue
            if a_arch not in ("any", host_arch, "x86_64"):
                continue
            comp = arch.find("complete")
            if comp is None:
                continue
            rel_url = (comp.findtext("url") or "").strip()
            if not rel_url:
                continue
            size_b = int(comp.findtext("size") or 0)
            csum_el = comp.find("checksum")
            csum = (csum_el.text or "").strip().lower() if csum_el is not None else ""
            csum_type = (csum_el.attrib.get("type") or "sha1").lower() if csum_el is not None else ""
            full_url = rel_url if rel_url.startswith("http") else base_url.rstrip("/") + "/" + rel_url.lstrip("/")
            cand = (rev_tuple, full_url, size_b, csum, csum_type)
            if best is None or cand[0] >= best[0]:
                best = cand

    if best is None:
        raise AndroidError(f"Không tìm thấy gói SDK '{package_path}' cho hệ điều hành '{host_os}'.")
    return best[1], best[2], best[3], best[4]


def extract_zip_preserving_perms(zip_path: str, dest_dir: str) -> None:
    """Extract a ZIP archive while preserving POSIX executable permissions stored in external_attr."""
    os.makedirs(dest_dir, exist_ok=True)
    dest_real = os.path.realpath(dest_dir)
    with zipfile.ZipFile(zip_path, "r") as zf:
        for info in zf.infolist():
            out_path = os.path.realpath(os.path.join(dest_real, info.filename))
            if os.path.commonpath([dest_real, out_path]) != dest_real:
                raise AndroidError(f"Tệp nén chứa đường dẫn không an toàn: {info.filename}")
            zf.extract(info, dest_real)
            if sys.platform != "win32" and not info.is_dir():
                unix_mode = (info.external_attr >> 16) & 0o777
                if unix_mode & 0o111:
                    try:
                        os.chmod(out_path, unix_mode | stat.S_IRUSR | stat.S_IWUSR)
                    except OSError:
                        pass


def get_host_hardware_specs() -> tuple[int, int]:
    """Return `(host_logical_cores, host_ram_mb)` detected from the current machine."""
    logical = max(2, int(os.cpu_count() or 4))
    host_ram_mb = 16384
    if sys.platform == "win32":
        try:
            import ctypes

            class _MEMSTAT(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            ms = _MEMSTAT()
            ms.dwLength = ctypes.sizeof(_MEMSTAT)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms)):
                host_ram_mb = max(2048, int(ms.ullTotalPhys // (1024 * 1024)))
        except Exception:
            pass
    elif os.path.isfile("/proc/meminfo"):
        try:
            with open("/proc/meminfo", "r", encoding="utf-8", errors="replace") as f:
                for ln in f:
                    if ln.startswith("MemTotal:"):
                        host_ram_mb = max(2048, int(ln.split()[1]) // 1024)
                        break
        except Exception:
            pass
    return logical, host_ram_mb


def _optimal_avd_resources() -> tuple[int, int, int]:
    """Return (cpu_cores, ram_mb, vm_heap_mb) tuned for zero-stutter gaming based on host hardware."""
    logical, host_ram_mb = get_host_hardware_specs()
    cores = min(6, max(4, logical // 2))
    if host_ram_mb >= 20000:
        return cores, 6144, 768
    if host_ram_mb >= 11000:
        return cores, 4096, 512
    return cores, 3072, 384


def get_emulator_hardware_options() -> tuple[list[tuple[str, int]], list[tuple[str, int]]]:
    """Return `(cpu_options, ram_options)` dynamically populated up to the host machine's CPU cores and RAM."""
    host_cores, host_ram_mb = get_host_hardware_specs()
    auto_cores, auto_ram, _ = _optimal_avd_resources()
    host_ram_gb = max(4, int(round(host_ram_mb / 1024.0)))

    cpu_counts = sorted({c for c in range(1, host_cores + 1) if c <= 8 or c % 2 == 0 or c == host_cores})
    cpu_options: list[tuple[str, int]] = [(f"Tự động tối ưu ({auto_cores} nhân / {host_cores} luồng)", 0)]
    for c in cpu_counts:
        suffix = " (Tối đa máy)" if c == host_cores else ""
        cpu_options.append((f"{c} nhân{suffix}", c))

    ram_gb_steps = sorted(
        {
            g
            for g in (2, 3, 4, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80, 96, 112, 128, host_ram_gb)
            if 2 <= g <= host_ram_gb
        }
    )
    ram_options: list[tuple[str, int]] = [(f"Tự động tối ưu ({auto_ram // 1024} GB / {host_ram_gb} GB)", 0)]
    for g in ram_gb_steps:
        mb = g * 1024
        suffix = " (Tối đa máy)" if g == host_ram_gb else ""
        ram_options.append((f"{g} GB ({mb} MB){suffix}", mb))

    return cpu_options, ram_options


def get_emulator_settings(cfg: dict | None = None) -> dict:
    """Return validated Android Emulator hardware/display settings merged with auto-tuned host defaults."""
    from app.config import load_config

    raw = cfg if isinstance(cfg, dict) else load_config()
    host_cores, host_ram_mb = get_host_hardware_specs()
    max_ram_mb = max(4096, int(round(host_ram_mb / 1024.0)) * 1024)
    auto_cores, auto_ram, _auto_heap = _optimal_avd_resources()

    try:
        req_cores = int(raw.get("android_cpu_cores") or 0)
    except (TypeError, ValueError):
        req_cores = 0
    cpu_valid = 1 <= req_cores <= host_cores
    cores = req_cores if cpu_valid else auto_cores

    try:
        req_ram = int(raw.get("android_ram_mb") or 0)
    except (TypeError, ValueError):
        req_ram = 0
    ram_valid = 1024 <= req_ram <= max_ram_mb
    ram_mb = req_ram if ram_valid else auto_ram
    heap_mb = max(384, min(1536, ram_mb // 8))

    res_presets = {
        "720x1280": (720, 1280, 240),
        "900x1600": (900, 1600, 280),
        "1080x1920": (1080, 1920, 320),
    }
    legacy_aliases = {
        "1280x720": "720x1280",
        "1600x900": "900x1600",
        "1920x1080": "1080x1920",
    }
    res_key = str(raw.get("android_resolution") or "720x1280").strip()
    res_key = legacy_aliases.get(res_key, res_key)
    if res_key not in res_presets:
        res_key = "720x1280"
    width, height, density = res_presets[res_key]

    try:
        req_fps = int(raw.get("android_fps") or 60)
    except (TypeError, ValueError):
        req_fps = 60
    fps = req_fps if req_fps in (60, 90, 120) else 60

    return {
        "cpu_cores": cores,
        "cpu_auto": not cpu_valid,
        "ram_mb": ram_mb,
        "ram_auto": not ram_valid,
        "heap_mb": heap_mb,
        "resolution": res_key,
        "width": width,
        "height": height,
        "density": density,
        "fps": fps,
        "host_cores": host_cores,
        "host_ram_mb": host_ram_mb,
    }


def sync_avd_hardware_settings(
    runtime_dir: str,
    avd_name: str = DEFAULT_AVD_NAME,
    cfg: dict | None = None,
) -> bool:
    """Update CPU, RAM, resolution, DPI, Wi-Fi, and vsync keys in an existing AVD config.ini."""
    cfg_path = os.path.join(runtime_dir, "avd", f"{avd_name}.avd", "config.ini")
    if not os.path.isfile(cfg_path):
        return False
    hw = get_emulator_settings(cfg)
    updates = {
        "hw.cpu.ncore": str(hw["cpu_cores"]),
        "hw.ramSize": str(hw["ram_mb"]),
        "vm.heapSize": str(hw["heap_mb"]),
        "hw.lcd.width": str(hw["width"]),
        "hw.lcd.height": str(hw["height"]),
        "hw.lcd.density": str(hw["density"]),
        "hw.lcd.vsync": str(hw["fps"]),
        "hw.initialOrientation": "portrait",
        "hw.gltransport": "asg",
        "hw.gltransport.asg.writeBufferSize": "2097152",
        "hw.gltransport.asg.writeStepSize": "8192",
        "hw.gltransport.asg.dataRingSize": "524288",
        "hw.gltransport.drawFlushInterval": "10000",
        "hw.wifi": "yes",
    }
    try:
        lines = open(cfg_path, "r", encoding="utf-8", errors="replace").read().splitlines()
        seen: set[str] = set()
        out: list[str] = []
        for ln in lines:
            key = ln.split("=", 1)[0].strip() if "=" in ln else ""
            if key in updates:
                out.append(f"{key}={updates[key]}")
                seen.add(key)
            else:
                out.append(ln)
        for k, v in updates.items():
            if k not in seen:
                out.append(f"{k}={v}")
        with open(cfg_path, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(out) + "\n")
        return True
    except OSError as exc:
        logger.warning(f"{TAG} Could not update AVD config {cfg_path}: {exc}")
        return False


def _write_avd_ini(runtime_dir: str, profile: PortableProfile) -> str:
    avd_root = os.path.join(runtime_dir, "avd")
    os.makedirs(avd_root, exist_ok=True)
    ini_path = os.path.join(avd_root, f"{profile.avd_name}.ini")
    avd_abs_fwd = os.path.abspath(os.path.join(avd_root, f"{profile.avd_name}.avd")).replace("\\", "/")
    with open(ini_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(
            "avd.ini.encoding=UTF-8\n"
            f"path={avd_abs_fwd}\n"
            f"path.rel=avd/{profile.avd_name}.avd\n"
            f"target=android-{profile.api_level}\n"
        )
    return ini_path


def adopt_avd_as(runtime_dir: str, src_avd_dir: str, profile: PortableProfile) -> bool:
    """Move an existing AVD folder (with its installed apps and saves) under `profile`'s AVD name.

    Used when an Android 11 AVD from an older Bob Gaming build sits where the Android 14 AVD now lives: it becomes
    the Android 11 (ARM32) runtime instead of being wiped. Disk overlays reference their backing images by
    relative name, so a folder rename is enough. Returns False (and leaves everything in place) on failure.
    """
    t0 = time.monotonic()
    dst_dir = os.path.join(runtime_dir, "avd", f"{profile.avd_name}.avd")
    cfg_path = os.path.join(dst_dir, "config.ini")
    if os.path.exists(dst_dir) or not os.path.isdir(src_avd_dir):
        logger.warning(
            f"{TAG} Not adopting {src_avd_dir} as {profile.avd_name}: "
            f"{'target already exists' if os.path.exists(dst_dir) else 'source missing'}"
        )
        return False
    try:
        os.replace(src_avd_dir, dst_dir)
    except OSError as exc:
        logger.warning(f"{TAG} Could not move {src_avd_dir} to {dst_dir}: {exc}")
        return False
    try:
        for entry in os.listdir(dst_dir):
            # Locks and the generated hardware profile carry the old folder path; the emulator rewrites them.
            if entry.endswith(".lock") or entry in ("hardware-qemu.ini", "emu-launch-params.txt"):
                stale = os.path.join(dst_dir, entry)
                if os.path.isdir(stale):
                    shutil.rmtree(stale, ignore_errors=True)
                else:
                    os.remove(stale)
        lines = []
        if os.path.isfile(cfg_path):
            lines = open(cfg_path, "r", encoding="utf-8", errors="replace").read().splitlines()
        overrides = {
            "AvdId": profile.avd_name,
            "avd.ini.displayname": f"{profile.display_name} (microG)",
        }
        out = [ln for ln in lines if ln.split("=", 1)[0].strip() not in overrides]
        out.extend(f"{k}={v}" for k, v in overrides.items())
        with open(cfg_path, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(out) + "\n")
        _write_avd_ini(runtime_dir, profile)
    except OSError as exc:
        logger.warning(f"{TAG} Adopted AVD {dst_dir} but could not rewrite its config: {exc}")
    logger.info(
        f"{TAG} Kept existing Android {profile.api_level} AVD as {profile.avd_name} "
        f"(installed apps preserved) in {time.monotonic() - t0:.2f}s"
    )
    return True


def write_portable_avd_files(runtime_dir: str, avd_name: str = DEFAULT_AVD_NAME) -> tuple[str, str]:
    """Generate slim high-performance avd/<Name>.ini and avd/<Name>.avd/config.ini (Direct Host GPU, zero bloat)."""
    profile = get_portable_profile(avd_name)
    avd_name = profile.avd_name
    avd_root = os.path.join(runtime_dir, "avd")
    avd_dir = os.path.join(avd_root, f"{avd_name}.avd")
    cfg_path = os.path.join(avd_dir, "config.ini")
    sysdir_rel = profile.sysdir_rel

    # If migrating from an older API level or heavy Play Store AVD, wipe stale userdata so multi-ABI slim image boots clean
    if os.path.isfile(cfg_path):
        try:
            old_cfg = open(cfg_path, "r", encoding="utf-8", errors="replace").read()
            if (
                "google_apis_playstore" in old_cfg
                or "PlayStore.enabled=true" in old_cfg
                or sysdir_rel not in old_cfg
            ):
                adopted = False
                for other in PORTABLE_PROFILES:
                    if (
                        other is not profile
                        and "google_apis_playstore" not in old_cfg
                        and other.sysdir_rel in old_cfg
                        and not os.path.exists(os.path.join(avd_root, f"{other.avd_name}.avd"))
                    ):
                        adopted = adopt_avd_as(runtime_dir, avd_dir, other)
                        break
                if not adopted:
                    logger.info(
                        f"{TAG} AVD {avd_name} was built for another system image; wiping its userdata to boot "
                        f"android-{profile.api_level} clean (Library apps reinstall automatically on next launch)"
                    )
                    shutil.rmtree(avd_dir, ignore_errors=True)
            elif "fastboot.forceFastBoot=yes" in old_cfg:
                shutil.rmtree(os.path.join(avd_dir, "snapshots"), ignore_errors=True)
                os.remove(cfg_path)
        except OSError:
            pass

    os.makedirs(avd_dir, exist_ok=True)
    ini_path = _write_avd_ini(runtime_dir, profile)

    if not os.path.isfile(cfg_path):
        hw = get_emulator_settings()
        cfg_lines = [
            f"AvdId={avd_name}",
            "PlayStore.enabled=false",
            "abi.type=x86_64",
            f"avd.ini.displayname={profile.display_name} (microG)",
            "avd.ini.encoding=UTF-8",
            "disk.dataPartition.size=16G",
            "fastboot.forceColdBoot=yes",
            "fastboot.forceFastBoot=no",
            "hw.accelerometer=yes",
            "hw.audioInput=no",
            "hw.battery=yes",
            "hw.camera.back=none",
            "hw.camera.front=none",
            "hw.cpu.arch=x86_64",
            f"hw.cpu.ncore={hw['cpu_cores']}",
            "hw.dPad=yes",
            "hw.gltransport=asg",
            "hw.gltransport.asg.writeBufferSize=2097152",
            "hw.gltransport.asg.writeStepSize=8192",
            "hw.gltransport.asg.dataRingSize=524288",
            "hw.gltransport.drawFlushInterval=10000",
            "hw.gps=no",
            "hw.gpu.enabled=yes",
            "hw.gpu.mode=host",
            "hw.initialOrientation=portrait",
            "hw.keyboard=yes",
            f"hw.lcd.density={hw['density']}",
            f"hw.lcd.height={hw['height']}",
            f"hw.lcd.vsync={hw['fps']}",
            f"hw.lcd.width={hw['width']}",
            "hw.mainKeys=no",
            f"hw.ramSize={hw['ram_mb']}",
            "hw.sdCard=yes",
            "hw.sensors.humidity=no",
            "hw.sensors.light=no",
            "hw.sensors.magnetic_field=no",
            "hw.sensors.orientation=yes",
            "hw.sensors.pressure=no",
            "hw.sensors.proximity=no",
            "hw.wifi=yes",
            "image.sysdir.1=" + sysdir_rel,
            "showDeviceFrame=no",
            "tag.display=Google APIs",
            f"tag.id={TARGET_SYSIMG_TAG}",
            f"vm.heapSize={hw['heap_mb']}",
        ]
        with open(cfg_path, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(cfg_lines) + "\n")
    else:
        sync_avd_hardware_settings(runtime_dir, avd_name)
    return ini_path, cfg_path


class AndroidRuntimeManager:
    """Discovers, provisions, boots, and controls Android runtimes across Windows and Linux."""

    def __init__(self, timeout: float = 20.0):
        self.timeout = timeout
        self._started_adb_daemons: set[str] = set()
        self._spawned_avds: set[tuple[str, str]] = set()
        self._boot_lock = threading.RLock()

    # ------------------------------------------------------------------ ADB & Emulator Probes

    @staticmethod
    def _adb_sdk_env(adb_path: str) -> dict[str, str] | None:
        parent = os.path.dirname(os.path.abspath(adb_path))
        if os.path.basename(parent).lower() == "platform-tools":
            sdk_root = os.path.dirname(parent)
            if os.path.isdir(sdk_root):
                return {"ANDROID_SDK_ROOT": sdk_root, "ANDROID_HOME": sdk_root}
        return None

    def _ensure_adb_daemon(self, adb_path: str) -> None:
        norm = os.path.normcase(os.path.abspath(adb_path))
        if norm in self._started_adb_daemons or not os.path.isfile(adb_path):
            return
        self._started_adb_daemons.add(norm)
        try:
            subprocess.run(
                [adb_path, "start-server"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=8.0,
                **_subprocess_kwargs(env=self._adb_sdk_env(adb_path)),
            )
        except Exception as exc:
            logger.debug(f"{TAG} adb start-server preflight warning ({adb_path}): {exc}")

    def run_adb(self, adb_path: str, args: list[str], serial: str = "", timeout: float = 60.0) -> subprocess.CompletedProcess:
        if not adb_path or not os.path.isfile(adb_path):
            sys_adb = shutil.which("adb")
            if not sys_adb:
                raise AndroidError("Không tìm thấy công cụ ADB để giao tiếp với Android Runtime.")
            adb_path = sys_adb
        ensure_executable_permission(adb_path)
        if args != ["start-server"]:
            self._ensure_adb_daemon(adb_path)
        cmd = [adb_path]
        if serial:
            cmd.extend(["-s", serial])
        cmd.extend(args)
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            **_subprocess_kwargs(env=self._adb_sdk_env(adb_path)),
        )

    def probe_emulator_accel(self, emulator_path: str, env: dict[str, str] | None = None) -> tuple[bool, str]:
        """Run `emulator -accel-check` and return (is_hw_accel_ready, status_detail)."""
        if not emulator_path or not os.path.isfile(emulator_path):
            return True, ""
        try:
            res = subprocess.run(
                [emulator_path, "-accel-check"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=6.0,
                **_subprocess_kwargs(env=env),
            )
            lines = [
                ln.strip()
                for ln in (res.stdout or "").splitlines()
                if ln.strip() and not ln.strip().startswith("accel")
            ]
            if res.returncode == 0 and (not lines or lines[0] == "0"):
                return True, ""
            code = lines[0] if lines else str(res.returncode)
            reason = lines[1] if len(lines) > 1 else (res.stderr or "").strip() or f"accel_code={code}"
            return False, reason
        except Exception as exc:
            logger.debug(f"{TAG} emulator -accel-check probe failed: {exc}")
            return True, ""

    def list_adb_devices(self, adb_path: str) -> list[tuple[str, str]]:
        """Return [(serial, state)] from `adb devices`."""
        if not adb_path or not os.path.isfile(adb_path):
            return []
        try:
            res = self.run_adb(adb_path, ["devices"], timeout=8.0)
        except Exception as exc:
            logger.debug(f"{TAG} adb devices probe failed ({adb_path}): {exc}")
            return []
        out: list[tuple[str, str]] = []
        for line in (res.stdout or "").splitlines():
            line = line.strip()
            if not line or line.startswith("List of devices") or line.startswith("*"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                out.append((parts[0], parts[1]))
        return out

    # ------------------------------------------------------------------ Discovery

    def _portable_paths(
        self,
        runtime_dir: str,
        platform_name: str = sys.platform,
        profile: PortableProfile = PROFILE_ANDROID_14,
    ) -> tuple[str, str, str, str]:
        adb_p = os.path.join(runtime_dir, "platform-tools", _exe_name("adb", platform_name))
        emu_p = os.path.join(runtime_dir, "emulator", _exe_name("emulator", platform_name))
        sysimg_prop = os.path.join(
            runtime_dir,
            "system-images",
            f"android-{profile.api_level}",
            TARGET_SYSIMG_TAG,
            "x86_64",
            "build.prop",
        )
        avd_cfg = os.path.join(runtime_dir, "avd", f"{profile.avd_name}.avd", "config.ini")
        return adb_p, emu_p, sysimg_prop, avd_cfg

    def _microg_paths(self, runtime_dir: str) -> tuple[str, str]:
        mg_dir = os.path.join(runtime_dir, "microg")
        return os.path.join(mg_dir, "gmscore.apk"), os.path.join(mg_dir, "vending.apk")

    def has_legacy_portable_tools(self, runtime_dir: str, platform_name: str = sys.platform) -> bool:
        adb_p, emu_p, _sysimg_prop, _avd_cfg = self._portable_paths(runtime_dir, platform_name)
        return os.path.isfile(adb_p) and os.path.isfile(emu_p)

    def is_portable_runtime_installed(
        self,
        runtime_dir: str,
        platform_name: str = sys.platform,
        profile: PortableProfile = PROFILE_ANDROID_14,
    ) -> bool:
        adb_p, emu_p, sysimg_prop, avd_cfg = self._portable_paths(runtime_dir, platform_name, profile)
        gms_apk, vend_apk = self._microg_paths(runtime_dir)
        if not all(os.path.isfile(p) for p in (adb_p, emu_p, sysimg_prop, avd_cfg, gms_apk, vend_apk)):
            return False
        try:
            cfg_txt = open(avd_cfg, "r", encoding="utf-8", errors="replace").read()
            return f"android-{profile.api_level}/" in cfg_txt
        except OSError:
            return False

    def _get_emulator_avd_name(self, adb_path: str, serial: str) -> str:
        """Return the exact AVD name running on `emulator-*` serial, or '' if indeterminate."""
        for args in (
            ["shell", "getprop", "ro.boot.qemu.avd_name"],
            ["shell", "getprop", "qemu.avd_name"],
            ["emu", "avd", "name"],
        ):
            try:
                res = self.run_adb(adb_path, args, serial=serial, timeout=3.0)
                for ln in (res.stdout or "").splitlines():
                    val = ln.strip()
                    if val and val != "OK" and not val.startswith("KO:"):
                        return val
            except Exception:
                pass
        return ""

    def _map_running_emulator_avds(self, adb_path: str, adb_devs: list[tuple[str, str]]) -> tuple[dict[str, str], list[str]]:
        """Return ({avd_name: serial}, [unnamed_emulator_serials]) for online `emulator-*` devices."""
        by_avd: dict[str, str] = {}
        unnamed: list[str] = []
        for serial, state in adb_devs:
            if not serial.startswith("emulator-") or state != "device":
                continue
            name = self._get_emulator_avd_name(adb_path, serial)
            if name:
                by_avd[name] = serial
            else:
                unnamed.append(serial)
        return by_avd, unnamed

    def _detect_waydroid(self, fallback_adb: str = "") -> RuntimeInfo | None:
        if not sys.platform.startswith("linux"):
            return None
        waydroid_bin = shutil.which("waydroid")
        if not waydroid_bin:
            return None
        has_img = os.path.isdir("/var/lib/waydroid")
        running = False
        try:
            res = subprocess.run(
                [waydroid_bin, "status"],
                capture_output=True,
                text=True,
                timeout=4.0,
                **_subprocess_kwargs(),
            )
            txt = (res.stdout or "").upper()
            running = "RUNNING" in txt
            if "STOPPED" in txt or "RUNNING" in txt:
                has_img = True
        except Exception:
            pass
        if not has_img:
            return None
        adb_bin = shutil.which("adb") or fallback_adb
        return RuntimeInfo(
            runtime_id="waydroid",
            kind=RUNTIME_WAYDROID,
            label="Waydroid (Linux Container)",
            installed=True,
            running=running,
            adb_path=adb_bin or "",
            adb_serial=WAYDROID_DEFAULT_ADB if adb_bin else "",
            emulator_path=waydroid_bin,
            detail="Chạy trực tiếp qua nhân Linux + Mesa GPU",
        )

    def _detect_system_sdk(
        self,
        portable_dir: str,
        platform_name: str = sys.platform,
        running_avds: dict[str, str] | None = None,
    ) -> RuntimeInfo | None:
        candidates: list[str] = []
        for env_key in ("ANDROID_SDK_ROOT", "ANDROID_HOME"):
            val = os.environ.get(env_key, "").strip()
            if val:
                candidates.append(val)
        if platform_name == "win32":
            local_app = os.environ.get("LOCALAPPDATA", "")
            if local_app:
                candidates.append(os.path.join(local_app, "Android", "Sdk"))
        else:
            candidates.append(os.path.expanduser("~/Android/Sdk"))
            candidates.append("/opt/android-sdk")

        port_norm = os.path.normcase(os.path.abspath(portable_dir))
        for sdk in candidates:
            if not sdk or not os.path.isdir(sdk):
                continue
            if os.path.normcase(os.path.abspath(sdk)) == port_norm:
                continue
            adb_p = os.path.join(sdk, "platform-tools", _exe_name("adb", platform_name))
            emu_p = os.path.join(sdk, "emulator", _exe_name("emulator", platform_name))
            if os.path.isfile(adb_p) and os.path.isfile(emu_p):
                try:
                    res = subprocess.run(
                        [emu_p, "-list-avds"],
                        capture_output=True,
                        text=True,
                        timeout=5.0,
                        **_subprocess_kwargs(),
                    )
                    avds = [ln.strip() for ln in (res.stdout or "").splitlines() if ln.strip() and not ln.startswith("INFO")]
                except Exception:
                    avds = []
                if avds:
                    if running_avds is None:
                        devs = self.list_adb_devices(adb_p)
                        avd_map, _unnamed = self._map_running_emulator_avds(adb_p, devs)
                    else:
                        avd_map = running_avds
                    chosen_avd = next((a for a in avds if a in avd_map), avds[0])
                    emu_serial = avd_map.get(chosen_avd, "")
                    return RuntimeInfo(
                        runtime_id=f"system_sdk:{chosen_avd}",
                        kind=RUNTIME_SYSTEM_SDK,
                        label=f"Android SDK ({chosen_avd})",
                        installed=True,
                        running=bool(emu_serial),
                        adb_path=adb_p,
                        adb_serial=emu_serial,
                        emulator_path=emu_p,
                        avd_name=chosen_avd,
                        root_dir=sdk,
                        detail=sdk,
                    )
        return None

    def _detect_windows_emulators(self, fallback_adb: str = "") -> list[RuntimeInfo]:
        if sys.platform != "win32":
            return []
        found: list[RuntimeInfo] = []
        pf = os.environ.get("PROGRAMFILES", r"C:\Program Files")
        pf86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
        local_app = os.environ.get("LOCALAPPDATA", "")

        known = [
            (
                "mumu12",
                "MuMu Player 12",
                [
                    os.path.join(pf, "Netease", "MuMuPlayerGlobal-12.0", "shell", "MuMuPlayer.exe"),
                    os.path.join(pf, "Netease", "MuMuPlayer-12.0", "shell", "MuMuPlayer.exe"),
                ],
                "adb.exe",
                "127.0.0.1:16384",
            ),
            (
                "ldplayer9",
                "LDPlayer 9",
                [
                    r"C:\LDPlayer\LDPlayer9\dnplayer.exe",
                    r"D:\LDPlayer\LDPlayer9\dnplayer.exe",
                ],
                "adb.exe",
                "emulator-5554",
            ),
            (
                "bluestacks5",
                "BlueStacks 5",
                [
                    os.path.join(pf, "BlueStacks_nxt", "HD-Player.exe"),
                    os.path.join(pf86, "BlueStacks_nxt", "HD-Player.exe"),
                ],
                "HD-Adb.exe",
                "127.0.0.1:5555",
            ),
            (
                "wsa",
                "Windows Subsystem for Android (WSA)",
                [os.path.join(local_app, "Microsoft", "WindowsApps", "WsaClient.exe")] if local_app else [],
                "",
                "127.0.0.1:58526",
            ),
        ]

        for rid, label, exe_candidates, adb_name, default_serial in known:
            exe = next((p for p in exe_candidates if p and os.path.isfile(p)), "")
            if not exe:
                continue
            exe_dir = os.path.dirname(exe)
            adb_p = os.path.join(exe_dir, adb_name) if adb_name else ""
            if not adb_p or not os.path.isfile(adb_p):
                adb_p = fallback_adb or shutil.which("adb") or ""
            found.append(
                RuntimeInfo(
                    runtime_id=rid,
                    kind=RUNTIME_EXTERNAL_ADB,
                    label=label,
                    installed=True,
                    running=False,
                    adb_path=adb_p,
                    adb_serial=default_serial,
                    emulator_path=exe,
                    root_dir=exe_dir,
                    detail=exe,
                )
            )
        return found

    def discover_runtimes(self, android_root: str, preferred_id: str = "") -> list[RuntimeInfo]:
        """Discover all available Android runtimes plus the managed Slim microG SDK option."""
        runtime_dir = get_runtime_dir(android_root)
        adb_p, emu_p, _prop, _cfg = self._portable_paths(runtime_dir)
        has_legacy_tools = self.has_legacy_portable_tools(runtime_dir)
        active_adb = adb_p if os.path.isfile(adb_p) else (shutil.which("adb") or "")

        adb_devs = self.list_adb_devices(active_adb) if active_adb else []
        running_avds, unnamed_serials = self._map_running_emulator_avds(active_adb, adb_devs) if active_adb else ({}, [])

        runtimes: list[RuntimeInfo] = []

        waydroid = self._detect_waydroid(fallback_adb=active_adb)
        if waydroid:
            runtimes.append(waydroid)

        accel_label = "AEHD/WHPX" if sys.platform == "win32" else "KVM"
        for prof in PORTABLE_PROFILES:
            installed = self.is_portable_runtime_installed(runtime_dir, profile=prof)
            serial = running_avds.get(prof.avd_name, "")
            if not serial and prof is PROFILE_ANDROID_14 and installed and unnamed_serials and not running_avds:
                serial = unnamed_serials[0]
            if installed:
                detail = runtime_dir
            elif has_legacy_tools:
                detail = (
                    f"Tải {prof.display_name} ({prof.purpose}) vào {runtime_dir} "
                    "(tái sử dụng Emulator, ADB & microG sẵn có)"
                )
            else:
                detail = f"Tải tự động vào {runtime_dir} ({prof.size_hint}, {prof.purpose})"
            runtimes.append(
                RuntimeInfo(
                    runtime_id=prof.runtime_id,
                    kind=RUNTIME_PORTABLE_SDK,
                    label=prof.label(accel_label),
                    installed=installed,
                    running=bool(installed and serial),
                    adb_path=adb_p,
                    adb_serial=serial,
                    emulator_path=emu_p,
                    avd_name=prof.avd_name,
                    root_dir=runtime_dir,
                    detail=detail,
                )
            )

        sys_sdk = self._detect_system_sdk(runtime_dir, running_avds=running_avds)
        if sys_sdk:
            runtimes.append(sys_sdk)

        runtimes.extend(self._detect_windows_emulators(fallback_adb=active_adb))

        if preferred_id and any(r.runtime_id == preferred_id for r in runtimes):
            runtimes.sort(key=lambda r: (0 if r.runtime_id == preferred_id else 1))
        else:
            # Prefer native Waydroid on Linux, then Android 14, then the Android 11 (ARM32) runtime
            order = {prof.runtime_id: idx + 1 for idx, prof in enumerate(PORTABLE_PROFILES)}
            runtimes.sort(
                key=lambda r: 0 if r.kind == RUNTIME_WAYDROID else order.get(r.runtime_id, len(order) + 1)
            )

        return runtimes

    # ------------------------------------------------------------------ Provisioning Portable SDK

    def _fetch_xml(self, url: str) -> bytes:
        t0 = time.monotonic()
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return resp.read()
        except Exception as exc:
            logger.warning(f"{TAG} Failed fetching SDK manifest {url} in {time.monotonic() - t0:.2f}s: {exc}")
            raise AndroidError(f"Không thể tải danh sách gói Android SDK từ Google: {exc}") from exc

    def _download_archive(
        self,
        url: str,
        dest_file: str,
        expected_size: int = 0,
        checksum: str = "",
        checksum_type: str = "",
        progress_cb: Callable[[int, int, int], None] | None = None,
        is_cancelled: Callable[[], bool] | None = None,
    ) -> None:
        os.makedirs(os.path.dirname(dest_file), exist_ok=True)
        t0 = time.monotonic()
        aria2 = find_aria2c()
        aria2_ok = False
        if aria2 and not (is_cancelled and is_cancelled()):
            try:
                aria2_ok = run_aria2_http_download(
                    aria2_bin=aria2,
                    url=url,
                    dest_file=dest_file,
                    expected_size=expected_size,
                    progress_cb=progress_cb,
                    is_cancelled=is_cancelled,
                    cancel_message="Đã hủy tải Android Runtime.",
                    log_tag=TAG,
                )
            except AndroidError:
                raise
            except Exception as exc:
                logger.warning(f"{TAG} aria2c download interrupted ({exc}), falling back to urllib")

        if not aria2_ok and (
            not os.path.isfile(dest_file)
            or os.path.exists(dest_file + ".aria2")
            or (expected_size > 0 and os.path.getsize(dest_file) < expected_size)
        ):
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    total = int(resp.headers.get("Content-Length") or expected_size or 0)
                    done = 0
                    t_start = time.monotonic()
                    with open(dest_file, "wb") as out_f:
                        while True:
                            if is_cancelled and is_cancelled():
                                raise AndroidError("Đã hủy tải Android Runtime.")
                            chunk = resp.read(256 * 1024)
                            if not chunk:
                                break
                            out_f.write(chunk)
                            done += len(chunk)
                            if progress_cb:
                                elapsed = max(0.05, time.monotonic() - t_start)
                                progress_cb(done, total, int(done / elapsed))
            except AndroidError:
                raise
            except Exception as exc:
                logger.warning(f"{TAG} Download failed for {url} in {time.monotonic() - t0:.2f}s: {exc}")
                raise AndroidError(f"Tải gói Android SDK thất bại: {exc}") from exc

        if checksum and checksum_type in ("sha1", "sha256"):
            h = hashlib.sha256() if checksum_type == "sha256" else hashlib.sha1()
            with open(dest_file, "rb") as f:
                while chunk := f.read(1024 * 1024):
                    h.update(chunk)
            got = h.hexdigest().lower()
            if got != checksum.lower():
                try:
                    os.remove(dest_file)
                except OSError:
                    pass
                raise AndroidError("Mã kiểm tra toàn vẹn (checksum) của gói Android SDK không khớp.")

    def _resolve_microg_urls(self) -> tuple[tuple[str, int], tuple[str, int]]:
        """Resolve latest non-root microG GmsCore & Companion APK URLs (with pinned fallback)."""
        gms_url, gms_sz = MICROG_NONROOT_FALLBACK_URL, 105_561_934
        vend_url, vend_sz = MICROG_VENDING_FALLBACK_URL, 4_210_169
        req = urllib.request.Request(
            MICROG_RELEASES_API,
            headers={"User-Agent": "BobGamingGameCenter/1.0", "Accept": "application/vnd.github+json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=10.0) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="replace"))
            nonroot_cand: tuple[str, int] | None = None
            std_cand: tuple[str, int] | None = None
            for asset in data.get("assets") or []:
                name = str(asset.get("name") or "")
                dl = str(asset.get("browser_download_url") or "")
                sz = int(asset.get("size") or 0)
                if not dl or not name.endswith(".apk") or "-hw" in name:
                    continue
                if name.startswith("app.revanced.android.gms-"):
                    nonroot_cand = (dl, sz)
                elif name.startswith("com.google.android.gms-") and "-user.apk" not in name:
                    std_cand = (dl, sz)
                elif name.startswith("com.android.vending-"):
                    vend_url, vend_sz = dl, sz
            if nonroot_cand:
                gms_url, gms_sz = nonroot_cand
            elif std_cand:
                gms_url, gms_sz = std_cand
        except Exception as exc:
            logger.debug(f"{TAG} Using pinned microG release URLs ({exc})")
        return (gms_url, gms_sz), (vend_url, vend_sz)

    def _stop_running_avd(self, adb_p: str, avd_name: str = DEFAULT_AVD_NAME) -> None:
        """Cleanly shut down any running emulator instance for `avd_name` so AVD/image files are unlocked."""
        if not adb_p or not os.path.isfile(adb_p):
            return
        try:
            devs = self.list_adb_devices(adb_p)
            by_avd, unnamed = self._map_running_emulator_avds(adb_p, devs)
            serial = by_avd.get(avd_name, "") or (unnamed[0] if unnamed and not by_avd else "")
            if not serial:
                return
            logger.info(f"{TAG} Stopping running emulator {serial} ({avd_name})...")
            self.run_adb(adb_p, ["emu", "kill"], serial=serial, timeout=8.0)
            deadline = time.monotonic() + 12.0
            while time.monotonic() < deadline:
                if not any(s == serial for s, _st in self.list_adb_devices(adb_p)):
                    time.sleep(0.5)
                    return
                time.sleep(0.5)
        except Exception as exc:
            logger.debug(f"{TAG} _stop_running_avd warning ({avd_name}): {exc}")

    def provision_portable_runtime(
        self,
        android_root: str,
        progress_cb: Callable[[int, str], None] | None = None,
        is_cancelled: Callable[[], bool] | None = None,
        runtime_id: str = "",
    ) -> RuntimeInfo:
        """Download and configure a managed runtime (Android 14 by default, or the Android 11 ARM32 profile)."""
        t0 = time.monotonic()
        profile = get_portable_profile(runtime_id)
        runtime_dir = get_runtime_dir(android_root)
        host_os = _host_os_tag()
        logger.info(
            f"{TAG} Provisioning {profile.display_name} (API {profile.api_level}) at {runtime_dir} (host_os={host_os})"
        )

        if self.is_portable_runtime_installed(runtime_dir, profile=profile):
            logger.info(f"{TAG} {profile.display_name} already installed at {runtime_dir}")
            return self.discover_runtimes(android_root, preferred_id=profile.runtime_id)[0]

        if progress_cb:
            progress_cb(2, f"Đang đọc manifest {profile.display_name} ({profile.abi_label}) & microG...")

        adb_p, emu_p, sysimg_prop, _avd_cfg = self._portable_paths(runtime_dir, profile=profile)
        self._stop_running_avd(adb_p, profile.avd_name)
        plat_dir = os.path.join(runtime_dir, "platforms", f"android-{profile.api_level}")
        gms_apk, vend_apk = self._microg_paths(runtime_dir)

        need_pt = not os.path.isfile(adb_p)
        need_emu = not os.path.isfile(emu_p)
        need_plat = not os.path.isdir(plat_dir)
        need_sysimg = not os.path.isfile(sysimg_prop)

        components: list[tuple[str, str, int, str, str, str | None, str | None, str | None]] = []

        if need_pt or need_emu or need_plat:
            repo_xml = self._fetch_xml(GOOGLE_REPO_XML)
            if need_pt:
                pt_url, pt_sz, pt_csum, pt_ctype = parse_sdk_archive_from_xml(
                    repo_xml, "platform-tools", GOOGLE_REPO_BASE, host_os
                )
                components.append(("Android Platform Tools (ADB)", pt_url, pt_sz, pt_csum, pt_ctype, runtime_dir, None, None))
            if need_emu:
                em_url, em_sz, em_csum, em_ctype = parse_sdk_archive_from_xml(
                    repo_xml, "emulator", GOOGLE_REPO_BASE, host_os
                )
                components.append(("Android Emulator Engine", em_url, em_sz, em_csum, em_ctype, runtime_dir, None, None))
            if need_plat:
                pl_url, pl_sz, pl_csum, pl_ctype = parse_sdk_archive_from_xml(
                    repo_xml, profile.platform_pkg, GOOGLE_REPO_BASE, host_os
                )
                components.append(
                    (
                        f"Android {profile.api_level} Platform",
                        pl_url,
                        pl_sz,
                        pl_csum,
                        pl_ctype,
                        os.path.join(runtime_dir, "_tmp_platform"),
                        plat_dir,
                        None,
                    )
                )

        if need_sysimg:
            sysimg_xml = self._fetch_xml(GOOGLE_APIS_SYSIMG_XML)
            si_url, si_sz, si_csum, si_ctype = parse_sdk_archive_from_xml(
                sysimg_xml, profile.sysimg_pkg, GOOGLE_APIS_SYSIMG_BASE, host_os
            )
            components.append(
                (
                    f"Android API {profile.api_level} Image ({profile.abi_label})",
                    si_url,
                    si_sz,
                    si_csum,
                    si_ctype,
                    os.path.join(runtime_dir, "system-images", f"android-{profile.api_level}", TARGET_SYSIMG_TAG),
                    None,
                    None,
                )
            )

        if not (os.path.isfile(gms_apk) and os.path.isfile(vend_apk)):
            (gms_url, gms_sz), (vend_url, vend_sz) = self._resolve_microg_urls()
            if not os.path.isfile(gms_apk):
                components.append(("microG Services Core", gms_url, gms_sz, "", "", None, None, gms_apk))
            if not os.path.isfile(vend_apk):
                components.append(("microG Companion (FakeStore)", vend_url, vend_sz, "", "", None, None, vend_apk))

        dl_dir = os.path.join(runtime_dir, "_downloads")
        os.makedirs(dl_dir, exist_ok=True)

        total_all = max(1, sum(c[2] for c in components))
        completed_bytes = 0
        last_logged_milestone = -1

        try:
            for label, url, sz, csum, ctype, extract_target, move_single_root_to, direct_dest in components:
                if is_cancelled and is_cancelled():
                    raise AndroidError("Đã hủy cài đặt Android Runtime.")
                dest_file = direct_dest or os.path.join(dl_dir, os.path.basename(url))

                def _sub_progress(done_b: int, _tot_b: int, _spd: int, base=completed_bytes, lbl=label):
                    pct = min(92, int(((base + done_b) * 90) / total_all) + 3)
                    if progress_cb:
                        progress_cb(pct, f"Đang tải {lbl}...")
                    nonlocal last_logged_milestone
                    bucket = (pct // 25) * 25
                    if bucket > last_logged_milestone and bucket in (25, 50, 75):
                        last_logged_milestone = bucket
                        logger.info(f"{TAG} Runtime provisioning download milestone: {bucket}%")

                self._download_archive(
                    url,
                    dest_file,
                    expected_size=sz,
                    checksum=csum,
                    checksum_type=ctype,
                    progress_cb=_sub_progress,
                    is_cancelled=is_cancelled,
                )
                completed_bytes += sz

                if direct_dest:
                    continue

                if progress_cb:
                    progress_cb(min(95, int((completed_bytes * 90) / total_all) + 5), f"Đang giải nén {label}...")

                if move_single_root_to:
                    shutil.rmtree(extract_target, ignore_errors=True)
                    extract_zip_preserving_perms(dest_file, extract_target)
                    entries = os.listdir(extract_target)
                    src_root = (
                        os.path.join(extract_target, entries[0])
                        if len(entries) == 1 and os.path.isdir(os.path.join(extract_target, entries[0]))
                        else extract_target
                    )
                    os.makedirs(os.path.dirname(move_single_root_to), exist_ok=True)
                    shutil.rmtree(move_single_root_to, ignore_errors=True)
                    shutil.move(src_root, move_single_root_to)
                    shutil.rmtree(extract_target, ignore_errors=True)
                elif extract_target:
                    extract_zip_preserving_perms(dest_file, extract_target)

                try:
                    os.remove(dest_file)
                except OSError:
                    pass

            # Write AVD files first: an Android 11 AVD from an older build is adopted as the ARM32 runtime here,
            # which decides whether its system image is still in use below.
            write_portable_avd_files(runtime_dir, profile.avd_name)

            # Reclaim disk space from API levels no managed AVD uses any more, and from heavy Play Store images
            keep_api_dirs = {f"android-{profile.api_level}"}
            for other in PORTABLE_PROFILES:
                other_cfg = os.path.join(runtime_dir, "avd", f"{other.avd_name}.avd", "config.ini")
                try:
                    if other.sysdir_rel in open(other_cfg, "r", encoding="utf-8", errors="replace").read():
                        keep_api_dirs.add(f"android-{other.api_level}")
                except OSError:
                    pass
            sysimgs_root = os.path.join(runtime_dir, "system-images")
            if os.path.isdir(sysimgs_root):
                for entry in os.listdir(sysimgs_root):
                    entry_p = os.path.join(sysimgs_root, entry)
                    if not os.path.isdir(entry_p):
                        continue
                    if entry not in keep_api_dirs:
                        logger.info(f"{TAG} Removing superseded system image dir: {entry_p}")
                        shutil.rmtree(entry_p, ignore_errors=True)
                    else:
                        ps_dir = os.path.join(entry_p, "google_apis_playstore")
                        if os.path.isdir(ps_dir):
                            logger.info(f"{TAG} Removing legacy heavy Play Store image dir: {ps_dir}")
                            shutil.rmtree(ps_dir, ignore_errors=True)

            plats_root = os.path.join(runtime_dir, "platforms")
            if os.path.isdir(plats_root):
                for entry in os.listdir(plats_root):
                    entry_p = os.path.join(plats_root, entry)
                    if os.path.isdir(entry_p) and entry not in keep_api_dirs:
                        shutil.rmtree(entry_p, ignore_errors=True)

            # Write package.xml marker expected by modern emulator builds inside system-images dir
            sysimg_dir = os.path.join(
                runtime_dir, "system-images", f"android-{profile.api_level}", TARGET_SYSIMG_TAG, "x86_64"
            )
            pkg_xml_path = os.path.join(sysimg_dir, "package.xml")
            if os.path.isdir(sysimg_dir) and not os.path.isfile(pkg_xml_path):
                with open(pkg_xml_path, "w", encoding="utf-8", newline="\n") as f:
                    f.write(
                        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                        '<ns2:repository xmlns:ns2="http://schemas.android.com/repository/android/common/02" '
                        'xmlns:ns5="http://schemas.android.com/sdk/android/repo/sys-img2/03" '
                        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
                        f'<localPackage path="{profile.sysimg_pkg}" obsolete="false">'
                        '<type-details xsi:type="ns5:sysImgDetailsType">'
                        f"<api-level>{profile.api_level}</api-level>"
                        f"<tag><id>{TARGET_SYSIMG_TAG}</id><display>Google APIs</display></tag>"
                        "<abi>x86_64</abi>"
                        "</type-details><revision><major>16</major></revision>"
                        "<display-name>Google APIs Intel x86_64 Atom System Image</display-name>"
                        "</localPackage></ns2:repository>\n"
                    )
        finally:
            shutil.rmtree(dl_dir, ignore_errors=True)

        if not self.is_portable_runtime_installed(runtime_dir, profile=profile):
            raise AndroidError("Giải nén Android Runtime hoàn tất nhưng thiếu tệp khởi chạy thiết yếu.")

        if progress_cb:
            progress_cb(100, f"{profile.display_name} đã sẵn sàng!")
        logger.info(f"{TAG} {profile.display_name} provisioned successfully in {time.monotonic() - t0:.2f}s")
        return self.discover_runtimes(android_root, preferred_id=profile.runtime_id)[0]

    # ------------------------------------------------------------------ Boot, Launch & Uninstall

    def _install_windows_hypervisor_driver(
        self,
        runtime_dir: str,
        progress_cb: Callable[[int, str], None] | None = None,
    ) -> None:
        """Auto-download & silently install Google's signed AEHD driver (or enable WHPX) when BIOS SVM/VT-x is ON."""
        if sys.platform != "win32":
            return
        aehd_dir = os.path.join(runtime_dir or tempfile.gettempdir(), "extras", "aehd")
        os.makedirs(aehd_dir, exist_ok=True)
        zip_path = os.path.join(aehd_dir, "aehd-windows.zip")
        bat_path = os.path.join(aehd_dir, "silent_install_safe.bat")

        if not os.path.isfile(bat_path):
            if progress_cb:
                progress_cb(8, "Đang tải trình tăng tốc phần cứng Google AEHD (175 KB)...")
            logger.info(f"{TAG} Downloading Google AEHD hypervisor driver from {GOOGLE_AEHD_URL}")
            self._download_archive(GOOGLE_AEHD_URL, zip_path)
            extract_zip_preserving_perms(zip_path, aehd_dir)
            try:
                os.remove(zip_path)
            except OSError:
                pass

        if os.path.isfile(bat_path):
            if progress_cb:
                progress_cb(12, "Đang kích hoạt trình tăng tốc phần cứng Android (AEHD)...")
            res = subprocess.run(
                ["cmd.exe", "/c", bat_path],
                cwd=aehd_dir,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=30.0,
                **_subprocess_kwargs(),
            )
            logger.info(f"{TAG} AEHD installer finished with rc={res.returncode}")
            if res.returncode == 0:
                return

        # If AEHD could not start (e.g. Hyper-V / VBS hypervisor is active), enable Windows Hypervisor Platform (WHPX)
        if progress_cb:
            progress_cb(14, "Đang bật Windows Hypervisor Platform (WHPX)...")
        dism_res = subprocess.run(
            [
                "dism.exe",
                "/Online",
                "/Enable-Feature",
                "/FeatureName:HypervisorPlatform",
                "/All",
                "/NoRestart",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=90.0,
            **_subprocess_kwargs(),
        )
        if dism_res.returncode in (0, 3010):
            logger.info(f"{TAG} Enabled Windows HypervisorPlatform via DISM (rc={dism_res.returncode})")
            raise AndroidError(
                "Đã tự động bật tính năng tăng tốc phần cứng 'Windows Hypervisor Platform (WHPX)'.\n"
                "Hãy khởi động lại Windows 1 lần để hoàn tất kích hoạt rồi mở lại ứng dụng!"
            )
        logger.warning(f"{TAG} DISM HypervisorPlatform returned rc={dism_res.returncode}")

    def _clean_stale_avd_locks(self, runtime: RuntimeInfo, avd: str, adb_p: str = "") -> None:
        if adb_p and any(s.startswith("emulator-") for s, _ in self.list_adb_devices(adb_p)):
            return
        candidates = []
        if runtime.root_dir:
            candidates.append(os.path.join(runtime.root_dir, "avd", f"{avd}.avd"))
        candidates.append(os.path.join(os.path.expanduser("~"), ".android", "avd", f"{avd}.avd"))
        for avd_dir in candidates:
            if not os.path.isdir(avd_dir):
                continue
            try:
                for entry in os.listdir(avd_dir):
                    if entry.endswith(".lock"):
                        lock_p = os.path.join(avd_dir, entry)
                        if os.path.isdir(lock_p):
                            shutil.rmtree(lock_p, ignore_errors=True)
                        else:
                            try:
                                os.remove(lock_p)
                            except OSError:
                                pass
            except OSError:
                pass

    def _ensure_microg_user_apk(self, runtime_dir: str) -> str:
        """
        Return path to the non-root user-installable microG GmsCore APK (`app.revanced.android.gms`),
        which installs cleanly into `/data/app` without duplicate C2DM permission conflicts,
        without `-writable-system`, and without `adb remount` (preserving verified boot).
        """
        mg_dir = os.path.join(runtime_dir, "microg")
        nonroot_apk = os.path.join(mg_dir, "microg_gmscore.apk")
        if os.path.isfile(nonroot_apk) and os.path.getsize(nonroot_apk) > 0:
            return nonroot_apk
        gms_apk, _ = self._microg_paths(runtime_dir)
        if os.path.isfile(gms_apk):
            sz = os.path.getsize(gms_apk)
            # Unit tests write small synthetic payloads; newly provisioned gmscore.apk matches ~105.5 MB
            if 0 < sz < 1_000_000 or abs(sz - 105_561_934) < 500_000:
                return gms_apk
            logger.info(f"{TAG} Downloading non-root microG Services APK ({MICROG_PACKAGE_ID})...")
            try:
                self._download_archive(MICROG_NONROOT_FALLBACK_URL, nonroot_apk)
                if os.path.isfile(nonroot_apk) and os.path.getsize(nonroot_apk) > 64:
                    return nonroot_apk
            except Exception as exc:
                logger.warning(f"{TAG} Could not fetch non-root microG APK ({exc})")
        return ""

    def _install_apk_with_sdk_bypass(self, adb_p: str, serial: str, apk_path: str) -> bool:
        if not apk_path or not os.path.isfile(apk_path):
            return False
        res = self.run_adb(adb_p, ["install", "-r", "-g", apk_path], serial=serial, timeout=180.0)
        combined = f"{res.stdout or ''}\n{res.stderr or ''}".strip()
        if "INSTALL_FAILED_DEPRECATED_SDK_VERSION" in combined:
            res = self.run_adb(
                adb_p,
                ["install", "--bypass-low-target-sdk-block", "-r", "-g", apk_path],
                serial=serial,
                timeout=180.0,
            )
            combined = f"{res.stdout or ''}\n{res.stderr or ''}".strip()
        if res.returncode != 0 or "Success" not in combined:
            logger.warning(f"{TAG} microG APK install warning ({os.path.basename(apk_path)}): {combined[:180]}")
            return False
        logger.info(f"{TAG} Installed microG component: {os.path.basename(apk_path)}")
        return True

    def _apply_slim_microg_profile(
        self,
        adb_p: str,
        serial: str,
        runtime: RuntimeInfo,
        progress_cb: Callable[[int, str], None] | None = None,
        is_cancelled: Callable[[], bool] | None = None,
    ) -> None:
        """
        One-time zero-remount, zero-reboot Slim + microG optimization on first boot:
        1. Uninstalls 18 heavy Google bloatware apps for `--user 0` and locks stock GMS/GSF out of
           background CPU/wakelocks/sync (keeps `/system` & `vbmeta` 100% read-only so verified boot,
           Quickboot snapshots, Pixel Launcher, and game Play-Services checks never break).
        2. Installs lightweight `microG Services` (`app.revanced.android.gms`) into `/data/app` and disables animations.
        """
        if runtime.kind != RUNTIME_PORTABLE_SDK or not runtime.root_dir:
            return
        if is_cancelled and is_cancelled():
            raise AndroidError("Đã hủy tối ưu hóa Android Runtime.")
        avd = runtime.avd_name or DEFAULT_AVD_NAME
        avd_dir = os.path.join(runtime.root_dir, "avd", f"{avd}.avd")
        marker = os.path.join(avd_dir, SLIM_PROFILE_MARKER)
        if os.path.isfile(marker):
            return
        gms_to_install = self._ensure_microg_user_apk(runtime.root_dir)
        if not gms_to_install:
            return

        t0 = time.monotonic()
        if progress_cb:
            progress_cb(94, "Đang gỡ ứng dụng Google nền & kích hoạt microG siêu nhẹ...")

        bloat_pkgs = (
            "com.android.chrome",
            "com.google.android.youtube",
            "com.google.android.apps.youtube.music",
            "com.google.android.apps.maps",
            "com.google.android.gm",
            "com.google.android.apps.docs",
            "com.google.android.apps.photos",
            "com.google.android.videos",
            "com.google.android.googlequicksearchbox",
            "com.google.android.apps.wellbeing",
            "com.google.android.projection.gearhead",
            "com.google.android.apps.messaging",
            "com.google.android.calendar",
            "com.google.android.apps.restore",
            "com.google.android.feedback",
            "com.google.android.partnersetup",
            "com.google.android.syncadapters.contacts",
            "com.google.android.tts",
        )
        uninstall_cmds = " ; ".join(f"pm uninstall -k --user 0 {p} >/dev/null 2>&1" for p in bloat_pkgs)
        throttle_gms_cmds = (
            "cmd appops set com.google.android.gms RUN_IN_BACKGROUND ignore >/dev/null 2>&1 ; "
            "cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1 ; "
            "cmd appops set com.google.android.gms WAKE_LOCK ignore >/dev/null 2>&1 ; "
            "cmd appops set com.google.android.gsf RUN_IN_BACKGROUND ignore >/dev/null 2>&1 ; "
            "cmd appops set com.google.android.gsf RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1 ; "
            "am set-standby-bucket com.google.android.gms restricted >/dev/null 2>&1 ; "
            "content insert --uri content://settings/sync --bind name:s:master_sync_enabled --bind value:b:false >/dev/null 2>&1"
        )
        self.run_adb(adb_p, ["shell", f"{uninstall_cmds} ; {throttle_gms_cmds}"], serial=serial, timeout=35.0)

        microg_ok = self._install_apk_with_sdk_bypass(adb_p, serial, gms_to_install)

        tune_script = (
            "settings put global window_animation_scale 0.0 ; "
            "settings put global transition_animation_scale 0.0 ; "
            "settings put global animator_duration_scale 0.0 ; "
            "settings put global verifier_verify_adb_installs 0 ; "
            "settings put global package_verifier_enable 0 ; "
            f"dumpsys deviceidle whitelist +{MICROG_PACKAGE_ID} >/dev/null 2>&1 ; "
            f"appops set {MICROG_PACKAGE_ID} SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1"
        )
        self.run_adb(adb_p, ["shell", tune_script], serial=serial, timeout=20.0)

        if microg_ok:
            try:
                os.makedirs(avd_dir, exist_ok=True)
                for m_path in (marker, os.path.join(avd_dir, ".bob_microg_ready")):
                    with open(m_path, "w", encoding="utf-8") as f:
                        f.write("microg-slim-v4\n")
            except OSError:
                pass
        logger.info(f"{TAG} Slim microG APK & zero-lag profile applied in {time.monotonic() - t0:.2f}s (ok={microg_ok})")

    def ensure_scrcpy_server_jar(self, runtime_dir: str) -> str:
        """Ensure scrcpy-server v3.1 JAR is cached locally for low-latency embedded streaming."""
        target_dir = os.path.join(runtime_dir or tempfile.gettempdir(), "scrcpy")
        jar_path = os.path.join(target_dir, "scrcpy-server-v3.1.jar")
        if os.path.isfile(jar_path) and os.path.getsize(jar_path) > 32768:
            return jar_path
        self._download_archive(
            SCRCPY_SERVER_URL,
            jar_path,
            expected_size=90640,
            checksum=SCRCPY_SERVER_SHA256,
            checksum_type="sha256",
        )
        logger.info(f"{TAG} Cached scrcpy-server v3.1 jar at {jar_path}")
        return jar_path

    def _apply_guest_boot_tweaks(self, adb_p: str, serial: str) -> None:
        """Keep Android 14 system dialogs from covering a game right after boot.

        The emulator's Bluetooth stack has no host radio and aborts while starting its HCI HAL, which raises a
        "Bluetooth keeps stopping" dialog over the first launched game; Android 14 also shows a one-time
        "Viewing full screen" banner on every immersive app. Both settings persist in userdata.
        """
        script = (
            "cmd bluetooth_manager disable >/dev/null 2>&1 ; "
            "settings put global bluetooth_on 0 ; "
            "settings put global hide_error_dialogs 1 ; "
            "settings put secure immersive_mode_confirmations confirmed"
        )
        try:
            res = self.run_adb(adb_p, ["shell", script], serial=serial, timeout=15.0)
            if res.returncode != 0:
                logger.warning(
                    f"{TAG} Guest boot tweaks returned rc={res.returncode} on {serial}: "
                    f"{(res.stderr or res.stdout or '').strip()[:160]}"
                )
        except Exception as exc:
            logger.warning(f"{TAG} Guest boot tweaks failed on {serial}: {exc}")

    def _dismiss_guest_system_dialogs(self, adb_p: str, serial: str) -> None:
        """Close any crash / ANR dialog a guest system service raised during boot (never a game's own UI)."""
        try:
            self.run_adb(
                adb_p,
                ["shell", "am broadcast -a android.intent.action.CLOSE_SYSTEM_DIALOGS >/dev/null 2>&1"],
                serial=serial,
                timeout=8.0,
            )
        except Exception as exc:
            logger.debug(f"{TAG} Could not dismiss guest system dialogs on {serial}: {exc}")

    def _ensure_guest_wifi_connected(self, adb_p: str, serial: str) -> None:
        """Bridge Android guest Wi-Fi ('AndroidWifi') to the host PC network with fast DNS & IPv4 routing."""
        disable_v6_cmd = (
            'su 0 sh -c "'
            "sysctl -w net.ipv6.conf.all.disable_ipv6=1 "
            "net.ipv6.conf.default.disable_ipv6=1 "
            "net.ipv6.conf.wlan0.disable_ipv6=1 "
            "net.ipv6.conf.eth0.disable_ipv6=1 >/dev/null 2>&1 ; "
            "ip -6 addr flush dev wlan0 >/dev/null 2>&1 ; "
            "ip -6 route flush dev wlan0 >/dev/null 2>&1 || true"
            '"'
        )
        target_hz = float(get_emulator_settings().get("fps") or 60)
        try:
            net_prep = (
                f"{disable_v6_cmd} ; "
                f"settings put system peak_refresh_rate {target_hz:.1f} >/dev/null 2>&1 ; "
                f"settings put system min_refresh_rate {target_hz:.1f} >/dev/null 2>&1 ; "
                "settings put global private_dns_mode off >/dev/null 2>&1 ; "
                "settings put global captive_portal_mode 0 >/dev/null 2>&1 ; "
                "svc wifi enable >/dev/null 2>&1 ; "
                "cmd wifi status"
            )
            res = self.run_adb(adb_p, ["shell", net_prep], serial=serial, timeout=10.0)
            connected = "Wifi is connected" in (res.stdout or "")
            if not connected:
                self.run_adb(
                    adb_p,
                    ["shell", "cmd wifi connect-network AndroidWifi open >/dev/null 2>&1 || true"],
                    serial=serial,
                    timeout=8.0,
                )
                for _ in range(5):
                    time.sleep(0.8)
                    st = self.run_adb(adb_p, ["shell", "cmd", "wifi", "status"], serial=serial, timeout=5.0)
                    if "Wifi is connected" in (st.stdout or ""):
                        connected = True
                        logger.info(f"{TAG} Connected guest Wi-Fi ('AndroidWifi') to host network on {serial}")
                        break
            if connected:
                # Re-apply after IpClient finishes associating wlan0 so broken SLIRP fec0:: IPv6 RA stays off
                self.run_adb(adb_p, ["shell", disable_v6_cmd], serial=serial, timeout=6.0)
        except Exception as exc:
            logger.debug(f"{TAG} Guest Wi-Fi bridge setup warning on {serial}: {exc}")

    def _stop_other_portable_avds(self, adb_p: str, keep_avd: str) -> None:
        """Shut down the other managed profile's emulator so only one Android screen (and RAM budget) is live."""
        try:
            by_avd, _unnamed = self._map_running_emulator_avds(adb_p, self.list_adb_devices(adb_p))
        except Exception as exc:  # noqa: BLE001
            logger.debug(f"{TAG} Could not list running AVDs before boot: {exc}")
            return
        for prof in PORTABLE_PROFILES:
            if prof.avd_name != keep_avd and prof.avd_name in by_avd:
                logger.info(f"{TAG} Stopping {prof.display_name} ({by_avd[prof.avd_name]}) before booting {keep_avd}")
                self._stop_running_avd(adb_p, prof.avd_name)

    def ensure_running(
        self,
        runtime: RuntimeInfo,
        boot_timeout: float = 180.0,
        is_cancelled: Callable[[], bool] | None = None,
        progress_cb: Callable[[int, str], None] | None = None,
    ) -> RuntimeInfo:
        """Boot the selected Android runtime if not already running and wait until Android finishes booting."""
        with self._boot_lock:
            return self._ensure_running_locked(
                runtime,
                boot_timeout=boot_timeout,
                is_cancelled=is_cancelled,
                progress_cb=progress_cb,
            )

    def _ensure_running_locked(
        self,
        runtime: RuntimeInfo,
        boot_timeout: float = 180.0,
        is_cancelled: Callable[[], bool] | None = None,
        progress_cb: Callable[[int, str], None] | None = None,
    ) -> RuntimeInfo:
        t0 = time.monotonic()
        if not runtime.installed:
            raise AndroidError("Android Runtime chưa được cài đặt.")

        if runtime.kind == RUNTIME_WAYDROID:
            waydroid_bin = runtime.emulator_path or shutil.which("waydroid") or "waydroid"
            if not runtime.running:
                logger.info(f"{TAG} Starting Waydroid session...")
                if progress_cb:
                    progress_cb(15, "Đang khởi động phiên Waydroid...")
                subprocess.Popen(
                    [waydroid_bin, "session", "start"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    **_subprocess_kwargs(),
                )
                deadline = time.monotonic() + min(boot_timeout, 60.0)
                while time.monotonic() < deadline:
                    if is_cancelled and is_cancelled():
                        raise AndroidError("Đã hủy khởi động Waydroid.")
                    res = subprocess.run(
                        [waydroid_bin, "status"], capture_output=True, text=True, timeout=5.0, **_subprocess_kwargs()
                    )
                    if "RUNNING" in (res.stdout or "").upper():
                        runtime.running = True
                        break
                    time.sleep(1.5)
                if not runtime.running:
                    raise AndroidError("Waydroid không phản hồi sau khi khởi động session.")
            if runtime.adb_path:
                try:
                    self.run_adb(runtime.adb_path, ["connect", WAYDROID_DEFAULT_ADB], timeout=6.0)
                    runtime.adb_serial = WAYDROID_DEFAULT_ADB
                except Exception:
                    pass
            if progress_cb:
                progress_cb(100, "Waydroid đã sẵn sàng!")
            logger.info(f"{TAG} Waydroid ready in {time.monotonic() - t0:.2f}s")
            return runtime

        adb_p = runtime.adb_path
        if not adb_p or not os.path.isfile(adb_p):
            adb_p = shutil.which("adb") or ""
        if not adb_p:
            raise AndroidError("Không tìm thấy ADB cho Android Runtime đã chọn.")

        ensure_executable_permission(adb_p)
        self._ensure_adb_daemon(adb_p)

        emu_proc: subprocess.Popen | None = None
        boot_log_path = ""
        spawn_emu_fn: Callable[[str], subprocess.Popen] | None = None
        gpu_fallbacks: deque[str] = deque(["auto", "swangle", "swiftshader"])
        current_gpu = "host"
        target_avd = runtime.avd_name or DEFAULT_AVD_NAME

        def _resolve_target_serial(devs_list: list[tuple[str, str]]) -> str:
            if runtime.kind == RUNTIME_EXTERNAL_ADB:
                if runtime.adb_serial and any(s == runtime.adb_serial and st == "device" for s, st in devs_list):
                    return runtime.adb_serial
                return next((s for s, st in devs_list if st == "device"), "")
            by_avd, unnamed = self._map_running_emulator_avds(adb_p, devs_list)
            if target_avd in by_avd:
                return by_avd[target_avd]
            if unnamed and not by_avd:
                return unnamed[0]
            return ""

        if runtime.kind == RUNTIME_EXTERNAL_ADB:
            if runtime.adb_serial and ":" in runtime.adb_serial:
                try:
                    self.run_adb(adb_p, ["connect", runtime.adb_serial], timeout=6.0)
                except Exception:
                    pass
            devs = dict(self.list_adb_devices(adb_p))
            if devs.get(runtime.adb_serial) != "device" and runtime.emulator_path and os.path.isfile(runtime.emulator_path):
                logger.info(f"{TAG} Launching external emulator {runtime.label}: {runtime.emulator_path}")
                if progress_cb:
                    progress_cb(15, f"Đang mở {runtime.label}...")
                emu_proc = subprocess.Popen(
                    [runtime.emulator_path],
                    cwd=os.path.dirname(runtime.emulator_path),
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    **_subprocess_kwargs(),
                )
        else:
            devs = self.list_adb_devices(adb_p)
            existing_serial = _resolve_target_serial(devs)
            already_booting = next((s for s, st in devs if s.startswith("emulator-") and st != "device"), "")
            if existing_serial and runtime.kind == RUNTIME_PORTABLE_SDK:
                try:
                    sdk_res = self.run_adb(
                        adb_p, ["shell", "getprop", "ro.build.version.sdk"], serial=existing_serial, timeout=4.0
                    )
                    sdk_val = (sdk_res.stdout or "").strip()
                    gles_res = self.run_adb(
                        adb_p, ["shell", "getprop", "ro.opengles.version"], serial=existing_serial, timeout=4.0
                    )
                    gles_val = (gles_res.stdout or "").strip()
                    glt_res = self.run_adb(
                        adb_p, ["shell", "getprop", "ro.boot.qemu.gltransport.name"], serial=existing_serial, timeout=4.0
                    )
                    glt_val = (glt_res.stdout or "").strip()
                    if not glt_val:
                        glt2 = self.run_adb(
                            adb_p, ["shell", "getprop", "ro.kernel.qemu.gltransport"], serial=existing_serial, timeout=4.0
                        )
                        glt_val = (glt2.stdout or "").strip()
                    hw_cfg = get_emulator_settings()
                    wm_res = self.run_adb(adb_p, ["shell", "wm", "size"], serial=existing_serial, timeout=4.0)
                    wm_txt = (wm_res.stdout or "").strip()
                    expected_sz = f"{hw_cfg['width']}x{hw_cfg['height']}"
                    size_mismatch = "Physical size:" in wm_txt and expected_sz not in wm_txt
                    if (
                        (sdk_val.isdigit() and sdk_val != get_portable_profile(runtime.runtime_id).api_level)
                        or gles_val == "131072"
                        or glt_val == "pipe"
                        or size_mismatch
                    ):
                        logger.info(
                            f"{TAG} Restarting {existing_serial} (API={sdk_val}, GLES={gles_val}, "
                            f"gltransport={glt_val}, size_mismatch={size_mismatch}) "
                            f"to apply {expected_sz} Portrait + API {get_portable_profile(runtime.runtime_id).api_level}"
                        )
                        self._stop_running_avd(adb_p, target_avd)
                        existing_serial = ""
                except Exception:
                    pass
            if existing_serial:
                runtime.adb_serial = existing_serial
                runtime.running = True
            elif already_booting:
                logger.info(f"{TAG} Joining already-booting Android Emulator ({already_booting})...")
            else:
                hint = check_virtualization_hint()
                if hint:
                    logger.warning(f"{TAG} Refusing emulator boot — firmware virtualization disabled")
                    raise AndroidError(hint)
                if runtime.kind == RUNTIME_PORTABLE_SDK:
                    self._stop_other_portable_avds(adb_p, target_avd)

                sdk_env: dict[str, str] = {}
                if runtime.root_dir:
                    sdk_env["ANDROID_SDK_ROOT"] = runtime.root_dir
                    sdk_env["ANDROID_HOME"] = runtime.root_dir
                    avd_home = os.path.join(runtime.root_dir, "avd")
                    if os.path.isdir(avd_home):
                        sdk_env["ANDROID_AVD_HOME"] = avd_home
                ensure_executable_permission(runtime.emulator_path)
                self._clean_stale_avd_locks(runtime, target_avd, adb_p)

                accel_ok, accel_reason = self.probe_emulator_accel(runtime.emulator_path, env=sdk_env)
                if not accel_ok and sys.platform == "win32":
                    self._install_windows_hypervisor_driver(runtime.root_dir, progress_cb=progress_cb)
                    accel_ok, accel_reason = self.probe_emulator_accel(runtime.emulator_path, env=sdk_env)

                if not accel_ok:
                    logger.warning(f"{TAG} Hardware acceleration still unavailable after driver setup: {accel_reason}")
                    raise AndroidError(
                        f"Chưa kích hoạt được trình tăng tốc ảo hóa phần cứng cho Android ({accel_reason}).\n"
                        "Hãy kiểm tra mục 'SVM Mode' / 'Intel VT-x' trong BIOS và bật 'Windows Hypervisor Platform' trong Windows Features."
                    )

                if runtime.kind == RUNTIME_PORTABLE_SDK and runtime.root_dir:
                    avd_dir = os.path.join(runtime.root_dir, "avd", f"{target_avd}.avd")
                    slim_marker = os.path.join(avd_dir, SLIM_PROFILE_MARKER)
                    poisoned_qcow2 = os.path.join(avd_dir, "system.img.qcow2")
                    if not os.path.isfile(slim_marker) or os.path.isfile(poisoned_qcow2):
                        logger.info(f"{TAG} Preparing clean verified-boot AVD state for {target_avd}...")
                        shutil.rmtree(avd_dir, ignore_errors=True)
                        write_portable_avd_files(runtime.root_dir, target_avd)
                    else:
                        shutil.rmtree(os.path.join(avd_dir, "snapshots"), ignore_errors=True)
                        write_portable_avd_files(runtime.root_dir, target_avd)
                    # Pre-fetch user-installable microG APK before opening window so first-boot apply is instant
                    self._ensure_microg_user_apk(runtime.root_dir)

                if runtime.root_dir:
                    avd_home = os.path.join(runtime.root_dir, "avd")
                    if os.path.isdir(avd_home):
                        sdk_env["ANDROID_AVD_HOME"] = avd_home
                    sync_avd_hardware_settings(runtime.root_dir, target_avd)

                # `-no-snapshot` prevents WHPX + gfxstream partial Quickboot snapshots (`RAM not mapped as shared`)
                # from restoring into a black SurfaceFlinger framebuffer on subsequent launches.
                # `-qt-hide-window` starts Host GPU / Qt display context completely hidden so no external QEMU window
                # pops out over Bob Gaming during boot or shutdown. It also means the emulator never creates a
                # display window at all, so it is omitted when the player embeds that window (native 120 FPS path).
                hw_boot = get_emulator_settings()
                base_cmd = [
                    runtime.emulator_path,
                    "-avd",
                    target_avd,
                    "-vsync-rate",
                    str(hw_boot["fps"]),
                    "-no-snapshot",
                    "-no-metrics",
                    "-crash-report-mode",
                    "never",
                ]
                if os.environ.get("BOBGAMING_ANDROID_HEADLESS") == "1":
                    base_cmd.append("-no-window")
                elif os.environ.get("BOBGAMING_ANDROID_EXTERNAL_WIN") != "1" and not native_embed_enabled():
                    base_cmd.append("-qt-hide-window")
                boot_log_path = os.path.join(tempfile.gettempdir(), f"bob_android_emu_{target_avd}.log")

                def _spawn_emu(gpu_mode: str) -> subprocess.Popen:
                    self._clean_stale_avd_locks(runtime, target_avd, adb_p)
                    feat_flags = [
                        "-feature",
                        "GLESDynamicVersion",
                        "-feature",
                        "-WiFiPacketStream",
                        "-feature",
                        "-GLPipeChecksum",
                    ]
                    if gpu_mode in ("host", "auto"):
                        feat_flags.extend(
                            [
                                "-feature",
                                "Vulkan",
                                "-feature",
                                "GLDirectMem",
                                "-feature",
                                "AsyncComposeSupport",
                                "-feature",
                                "VulkanBatchedDescriptorSetUpdate",
                            ]
                        )
                    full_cmd = [
                        *base_cmd,
                        "-gpu",
                        gpu_mode,
                        *feat_flags,
                        "-dns-server",
                        "8.8.8.8,1.1.1.1",
                        "-netdelay",
                        "none",
                        "-netspeed",
                        "full",
                    ]
                    logger.info(f"{TAG} Spawning Android Emulator ({target_avd}, gpu={gpu_mode})...")
                    self._spawned_avds.add((adb_p, target_avd))
                    log_fh = None
                    try:
                        log_fh = open(boot_log_path, "w", encoding="utf-8", errors="replace")
                        return subprocess.Popen(
                            full_cmd,
                            cwd=os.path.dirname(runtime.emulator_path),
                            stdout=log_fh,
                            stderr=subprocess.STDOUT,
                            **_subprocess_kwargs(env=sdk_env),
                        )
                    finally:
                        if log_fh is not None:
                            try:
                                log_fh.close()
                            except OSError:
                                pass

                if progress_cb:
                    progress_cb(18, f"Đang mở cửa sổ {runtime.label} (GPU Direct)...")

                spawn_emu_fn = _spawn_emu
                emu_proc = spawn_emu_fn(current_gpu)
                t0 = time.monotonic()

        logger.info(f"{TAG} Waiting for Android Runtime '{runtime.label}' to finish booting...")
        deadline = time.monotonic() + boot_timeout
        while time.monotonic() < deadline:
            if is_cancelled and is_cancelled():
                if emu_proc is not None and emu_proc.poll() is None:
                    try:
                        emu_proc.terminate()
                    except OSError:
                        pass
                raise AndroidError("Đã hủy chờ khởi động Android Runtime.")
            try:
                if runtime.kind == RUNTIME_EXTERNAL_ADB and runtime.adb_serial and ":" in runtime.adb_serial:
                    self.run_adb(adb_p, ["connect", runtime.adb_serial], timeout=5.0)
                devs = self.list_adb_devices(adb_p)
                serial = _resolve_target_serial(devs)
                booting_emu = next((s for s, st in devs if s.startswith("emulator-") and st != "device"), "")

                if emu_proc is not None and emu_proc.poll() is not None and not serial and not booting_emu:
                    err_lines: list[str] = []
                    if boot_log_path and os.path.isfile(boot_log_path):
                        try:
                            with open(boot_log_path, "r", encoding="utf-8", errors="replace") as lf:
                                for ln in lf:
                                    s = ln.strip()
                                    if s and ("ERROR" in s or "FATAL" in s or "PANIC" in s):
                                        err_lines.append(s)
                        except OSError:
                            pass
                    if gpu_fallbacks and spawn_emu_fn is not None and not err_lines:
                        next_gpu = gpu_fallbacks.popleft()
                        logger.warning(
                            f"{TAG} Emulator exited with rc={emu_proc.returncode} under gpu={current_gpu}; "
                            f"retrying with gpu={next_gpu}"
                        )
                        current_gpu = next_gpu
                        emu_proc = spawn_emu_fn(current_gpu)
                        time.sleep(1.5)
                        continue
                    detail = err_lines[-1] if err_lines else f"mã thoát {emu_proc.returncode}"
                    logger.error(f"{TAG} Emulator exited early ({emu_proc.returncode}): {detail}")
                    raise AndroidError(f"Máy ảo Android không thể khởi chạy ({detail}).")

                elapsed = int(time.monotonic() - t0)
                if serial:
                    prop = self.run_adb(adb_p, ["shell", "getprop", "sys.boot_completed"], serial=serial, timeout=6.0)
                    if (prop.stdout or "").strip() == "1":
                        if emu_proc is not None and runtime.kind != RUNTIME_EXTERNAL_ADB:
                            self._apply_guest_boot_tweaks(adb_p, serial)
                        self._apply_slim_microg_profile(
                            adb_p, serial, runtime, progress_cb=progress_cb, is_cancelled=is_cancelled
                        )
                        self._ensure_guest_wifi_connected(adb_p, serial)
                        if emu_proc is not None and runtime.kind != RUNTIME_EXTERNAL_ADB:
                            self._dismiss_guest_system_dialogs(adb_p, serial)
                        runtime.adb_serial = serial
                        runtime.running = True
                        if progress_cb:
                            progress_cb(100, f"{get_portable_profile(runtime.runtime_id).display_name} (microG) đã sẵn sàng!")
                        logger.info(f"{TAG} Runtime '{runtime.label}' ({serial}) booted in {time.monotonic() - t0:.2f}s")
                        return runtime
                    if progress_cb:
                        pct = min(92, 55 + int(elapsed * 0.8))
                        progress_cb(pct, f"Cửa sổ Android đã mở — đang khởi động hệ điều hành ({elapsed}s)...")
                elif booting_emu:
                    if progress_cb:
                        pct = min(54, 30 + int(elapsed * 0.5))
                        progress_cb(pct, f"Đã mở cửa sổ máy ảo ({booting_emu}) — đang nạp nhân Android ({elapsed}s)...")
                elif progress_cb:
                    pct = min(28, 18 + elapsed * 2)
                    progress_cb(pct, f"Đang mở cửa sổ {runtime.label} ({elapsed}s)...")
            except AndroidError:
                raise
            except (subprocess.TimeoutExpired, OSError) as exc:
                logger.debug(f"{TAG} Boot poll transient error: {exc}")
            time.sleep(1.5)

        hint = check_virtualization_hint()
        extra = f" ({hint})" if hint else ""
        raise AndroidError(f"Android Runtime khởi động quá thời gian chờ{extra}.")

    def is_package_installed(self, runtime: RuntimeInfo, package_name: str) -> bool:
        """Return True if `package_name` is currently installed inside the running `runtime`."""
        if not is_valid_package_name(package_name):
            return False
        if runtime.kind == RUNTIME_WAYDROID and not runtime.adb_serial:
            return True
        if not runtime.adb_path or not runtime.adb_serial:
            return True
        try:
            res = self.run_adb(runtime.adb_path, ["shell", "pm", "path", package_name], serial=runtime.adb_serial, timeout=6.0)
            return "package:" in (res.stdout or "")
        except Exception:
            return True

    def launch_package(self, runtime: RuntimeInfo, package_name: str) -> None:
        """Boot runtime if needed and launch the main LAUNCHER activity of package_name."""
        if not is_valid_package_name(package_name):
            raise AndroidError(f"Package ID không hợp lệ: {package_name!r}")
        t0 = time.monotonic()
        ready = self.ensure_running(runtime)
        if ready.kind == RUNTIME_WAYDROID:
            waydroid_bin = ready.emulator_path or shutil.which("waydroid") or "waydroid"
            subprocess.Popen(
                [waydroid_bin, "app", "launch", package_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                **_subprocess_kwargs(),
            )
            logger.info(f"{TAG} Launched {package_name} via Waydroid in {time.monotonic() - t0:.2f}s")
            return

        # Resolve main launcher component for clean direct start without monkey noise
        res = self.run_adb(
            ready.adb_path,
            ["shell", "cmd", "package", "resolve-activity", "--brief", "-c", "android.intent.category.LAUNCHER", package_name],
            serial=ready.adb_serial,
            timeout=10.0,
        )
        lines = [ln.strip() for ln in (res.stdout or "").splitlines() if "/" in ln and not ln.startswith("priority")]
        if lines:
            component = lines[-1]
            start_res = self.run_adb(
                ready.adb_path,
                ["shell", "am", "start", "-n", component],
                serial=ready.adb_serial,
                timeout=10.0,
            )
            if start_res.returncode == 0 and "Error:" not in (start_res.stdout or ""):
                logger.info(f"{TAG} Launched {package_name} ({component}) in {time.monotonic() - t0:.2f}s")
                return

        monkey_res = self.run_adb(
            ready.adb_path,
            ["shell", "monkey", "-p", package_name, "-c", "android.intent.category.LAUNCHER", "1"],
            serial=ready.adb_serial,
            timeout=12.0,
        )
        if monkey_res.returncode != 0 or "No activities found" in (monkey_res.stdout or "") + (monkey_res.stderr or ""):
            raise AndroidError(f"Không thể mở ứng dụng '{package_name}' trong Android Runtime.")
        logger.info(f"{TAG} Launched {package_name} via monkey fallback in {time.monotonic() - t0:.2f}s")

    def uninstall_package(self, runtime: RuntimeInfo, package_name: str) -> None:
        """Uninstall package_name from the Android runtime if it is running or reachable."""
        if not is_valid_package_name(package_name):
            return
        if runtime.kind == RUNTIME_WAYDROID and runtime.running:
            waydroid_bin = runtime.emulator_path or shutil.which("waydroid") or "waydroid"
            subprocess.run([waydroid_bin, "app", "remove", package_name], timeout=25.0, **_subprocess_kwargs())
            logger.info(f"{TAG} Uninstalled {package_name} from Waydroid")
            return
        if runtime.adb_path and os.path.isfile(runtime.adb_path):
            devs = self.list_adb_devices(runtime.adb_path)
            serial = runtime.adb_serial if any(s == runtime.adb_serial and st == "device" for s, st in devs) else ""
            if not serial:
                serial = next((s for s, st in devs if st == "device"), "")
            if serial:
                self.run_adb(runtime.adb_path, ["uninstall", package_name], serial=serial, timeout=25.0)
                logger.info(f"{TAG} Uninstalled {package_name} via ADB ({serial})")

    def has_obb_files(self, runtime: RuntimeInfo, package_name: str, expected_obbs: list[str]) -> bool:
        """Return True if all expected `.obb` expansion bundles exist inside the guest Android storage."""
        clean_obbs = [os.path.basename(f) for f in (expected_obbs or []) if f]
        if not clean_obbs or not is_valid_package_name(package_name):
            return True
        if not runtime.adb_path or not runtime.adb_serial:
            return True
        try:
            checks = " && ".join(
                f"(test -s {shlex.quote(f'/sdcard/Android/obb/{package_name}/{obb}')} || "
                f"su 0 test -s {shlex.quote(f'/data/media/0/Android/obb/{package_name}/{obb}')})"
                for obb in clean_obbs
            )
            res = self.run_adb(
                runtime.adb_path,
                ["shell", f"({checks}) && echo OBB_OK"],
                serial=runtime.adb_serial,
                timeout=8.0,
            )
            return "OBB_OK" in (res.stdout or "")
        except Exception:
            return True

    @staticmethod
    def _terminate_lingering_avd_pids(avd_name: str, adb_serial: str = "") -> None:
        if sys.platform != "win32":
            return
        local_app = os.environ.get("LOCALAPPDATA") or ""
        run_dir = os.path.join(local_app, "Temp", "avd", "running")
        if not os.path.isdir(run_dir):
            return
        port_str = adb_serial.split("-")[-1] if adb_serial.startswith("emulator-") else ""
        for entry in os.listdir(run_dir):
            if not (entry.startswith("pid_") and entry.endswith(".ini")):
                continue
            pid_part = entry.removeprefix("pid_").removesuffix(".ini")
            if not pid_part.isdigit():
                continue
            ini_p = os.path.join(run_dir, entry)
            try:
                txt = open(ini_p, "r", encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            if (port_str and f"port.serial={port_str}" in txt) or (avd_name and f"avd.id={avd_name}" in txt):
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", pid_part],
                    capture_output=True,
                    timeout=5.0,
                    **_subprocess_kwargs(),
                )

    def stop_runtime(self, runtime: RuntimeInfo) -> None:
        """Cleanly stop the specified running Android runtime."""
        if runtime.kind == RUNTIME_WAYDROID:
            waydroid_bin = runtime.emulator_path or shutil.which("waydroid") or "waydroid"
            subprocess.run([waydroid_bin, "session", "stop"], timeout=15.0, **_subprocess_kwargs())
            logger.info(f"{TAG} Stopped Waydroid session")
            return
        target_avd = runtime.avd_name or DEFAULT_AVD_NAME
        adb_p = runtime.adb_path or shutil.which("adb") or ""
        if adb_p and os.path.isfile(adb_p):
            if runtime.adb_serial:
                try:
                    self.run_adb(adb_p, ["emu", "kill"], serial=runtime.adb_serial, timeout=8.0)
                    for _ in range(10):
                        if not any(s == runtime.adb_serial for s, _st in self.list_adb_devices(adb_p)):
                            break
                        time.sleep(0.4)
                    self._terminate_lingering_avd_pids(target_avd, runtime.adb_serial)
                    logger.info(f"{TAG} Stopped Android Runtime {runtime.label} ({runtime.adb_serial})")
                    return
                except Exception as exc:
                    logger.debug(f"{TAG} stop_runtime serial kill fallback ({runtime.adb_serial}): {exc}")
            self._stop_running_avd(adb_p, target_avd)
        self._terminate_lingering_avd_pids(target_avd, runtime.adb_serial)

    def shutdown_spawned_runtimes(self) -> None:
        """Cleanly stop any Android Emulator AVDs spawned by this Bob Gaming session."""
        targets = list(self._spawned_avds)
        self._spawned_avds.clear()
        for adb_p, avd_name in targets:
            try:
                self._stop_running_avd(adb_p, avd_name)
            except Exception as exc:
                logger.debug(f"{TAG} Shutdown warning for {avd_name}: {exc}")
