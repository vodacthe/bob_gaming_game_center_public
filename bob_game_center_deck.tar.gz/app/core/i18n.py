"""Application internationalization (i18n) engine for English and Vietnamese."""

from __future__ import annotations

import functools
import inspect
import json
import logging
import os
import re
import threading
import time
import weakref
from typing import Callable

logger = logging.getLogger(__name__)
TAG = "[I18n]"

LANG_EN = "en"
LANG_VI = "vi"
SUPPORTED_LANGUAGES = (LANG_EN, LANG_VI)
LANGUAGE_LABELS = {
    LANG_EN: "English",
    LANG_VI: "Tiếng Việt",
}
LANGUAGE_FLAGS = {
    LANG_EN: "flag_gb",
    LANG_VI: "flag_vn",
}

_VN_CHARS_RE = re.compile(
    r"[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđĐ"
    r"ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸ]"
)
_URL_RE = re.compile(r"^(?:https?|ftp|mailto|steam)://\S+$", re.IGNORECASE)
_WIN_PATH_RE = re.compile(r"^[A-Za-z]:[/\\][^\n]*$")
_POSIX_PATH_RE = re.compile(r"^/(?:[^/\s]+/)*[^/\s]*$")
_HTML_TAG_SPLIT_RE = re.compile(r"(<[^>]+>|&nbsp;|&#\d+;)")
_PLACEHOLDER_SPLIT_RE = re.compile(r"(\{\d+\})")
_PLACEHOLDER_SUB_RE = re.compile(r"\{(\d+)\}")
_PAREN_SUFFIX_RE = re.compile(r"^(.+?)\s+\(([^()]+)\)$")

_UI_PREFIXES = ("← ", "◀ ", "▶ ", "● ", "○ ", "☁ ", "  • ", "• ", "- ", "+ ", "* ", "✅ ", "↩ ")
_TRAILING_PUNCT = ("...", "…", ":")
_SEGMENT_SEPARATORS = ("\n", "  ·  ", " · ", " — ", " | ", "; ")

_lock = threading.RLock()
_current_lang: str = LANG_EN
_listeners: list[Callable[[str], None] | weakref.WeakMethod] = []

_catalog_loaded: bool = False
_exact_map: dict[str, str] = {}
_compiled_templates: list[tuple[re.Pattern[str], list[str], str]] = []
_custom_locale_path: str | None = None


def has_vietnamese_chars(text: str) -> bool:
    """Return True when text contains Vietnamese diacritics or đ/Đ."""
    return bool(text and _VN_CHARS_RE.search(text))


def normalize_language(lang: str | None, default: str = LANG_EN) -> str:
    """Normalize a language code to 'en' or 'vi', warning on unknown non-empty values."""
    if lang is None:
        return default
    raw = str(lang).strip()
    if not raw:
        return default
    low = raw.lower().replace("_", "-")
    if low == "en" or low.startswith("en-") or low == "english":
        return LANG_EN
    if low in ("vi", "vn", "vietnamese") or low.startswith("vi-"):
        return LANG_VI
    logger.warning(f"{TAG} Unknown language code {lang!r}; falling back to {default!r}")
    return default


def current_language() -> str:
    """Return the active runtime language code ('en' or 'vi')."""
    with _lock:
        return _current_lang


def is_english() -> bool:
    """Return True when the active runtime language is English."""
    return current_language() == LANG_EN


def _locale_file_path() -> str:
    if _custom_locale_path:
        return _custom_locale_path
    from app.config import get_app_dir

    return os.path.join(get_app_dir(), "app", "data", "locales", "en.json")


def _compile_template(src_template: str) -> tuple[re.Pattern[str], list[str], tuple[int, int, int]] | None:
    parts = _PLACEHOLDER_SPLIT_RE.split(src_template)
    placeholder_keys: list[str] = []
    regex_parts: list[str] = ["^"]
    literal_len = 0
    literal_count = 0

    for idx, part in enumerate(parts):
        if not part:
            continue
        if len(part) >= 3 and part[0] == "{" and part[-1] == "}" and part[1:-1].isdigit():
            key = part[1:-1]
            grp_name = f"p_{len(placeholder_keys)}"
            placeholder_keys.append(key)
            # Use greedy match at the end of template when no literal follows
            has_trailing_literal = any(bool(p) for p in parts[idx + 1 :])
            quant = ".+?" if has_trailing_literal else ".+"
            regex_parts.append(f"(?P<{grp_name}>{quant})")
        else:
            literal_len += len(part)
            literal_count += 1
            regex_parts.append(re.escape(part))

    if not placeholder_keys:
        return None

    regex_parts.append("$")
    try:
        pattern = re.compile("".join(regex_parts), re.DOTALL)
    except re.error as exc:
        logger.warning(f"{TAG} Invalid template regex for {src_template!r}: {exc}")
        return None
    sort_key = (literal_len, literal_count, -len(placeholder_keys))
    return pattern, placeholder_keys, sort_key


def _ensure_catalog_loaded() -> None:
    global _catalog_loaded, _exact_map, _compiled_templates
    with _lock:
        if _catalog_loaded:
            return
        started = time.perf_counter()
        path = _locale_file_path()
        exact: dict[str, str] = {}
        compiled: list[tuple[tuple[int, int, int], re.Pattern[str], list[str], str]] = []
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                raise ValueError("Locale JSON root must be an object")
            raw_exact = data.get("exact") or {}
            raw_templates = data.get("templates") or {}
            if isinstance(raw_exact, dict):
                exact = {str(k): str(v) for k, v in raw_exact.items() if isinstance(k, str) and isinstance(v, str)}
                for k, v in list(exact.items()):
                    ks = k.strip()
                    if ks and ("\n" in k or k != ks) and ks not in exact:
                        exact[ks] = v.strip()
            if isinstance(raw_templates, dict):
                for src_tmpl, en_tmpl in raw_templates.items():
                    if not isinstance(src_tmpl, str) or not isinstance(en_tmpl, str):
                        continue
                    built = _compile_template(src_tmpl)
                    if built is not None:
                        pattern, keys, sort_key = built
                        compiled.append((sort_key, pattern, keys, en_tmpl))
            compiled.sort(key=lambda item: item[0], reverse=True)
            _exact_map = exact
            _compiled_templates = [(p, keys, en) for _, p, keys, en in compiled]
            _catalog_loaded = True
            elapsed = time.perf_counter() - started
            logger.info(
                f"{TAG} Loaded 'en' locale catalog "
                f"({len(_exact_map)} exact, {len(_compiled_templates)} templates) in {elapsed:.3f}s"
            )
        except Exception as exc:
            _exact_map = {}
            _compiled_templates = []
            _catalog_loaded = True
            logger.error(f"{TAG} Failed to load locale catalog from {path}: {exc}", exc_info=True)


def reload_catalog(locale_path: str | None = None) -> None:
    """Force reload of the English locale catalog (primarily for tests)."""
    global _catalog_loaded, _custom_locale_path
    with _lock:
        if locale_path is not None:
            _custom_locale_path = locale_path
        _catalog_loaded = False
        translate_vi_to_en.cache_clear()
    _ensure_catalog_loaded()


def reset_catalog_path() -> None:
    """Reset custom locale path override back to default bundled path."""
    global _catalog_loaded, _custom_locale_path
    with _lock:
        _custom_locale_path = None
        _catalog_loaded = False
        translate_vi_to_en.cache_clear()


def set_language(lang: str) -> str:
    """Switch active runtime language and notify registered listeners."""
    global _current_lang
    target = normalize_language(lang, default=LANG_EN)
    with _lock:
        previous = _current_lang
        if previous == target:
            if target == LANG_EN:
                _ensure_catalog_loaded()
            return target
        _current_lang = target
        if target == LANG_EN:
            _ensure_catalog_loaded()
        listeners_snapshot = list(_listeners)

    logger.info(f"{TAG} Language changed: {previous} -> {target}")

    dead_refs: list[weakref.WeakMethod] = []

    for ref in listeners_snapshot:
        cb = ref() if isinstance(ref, weakref.WeakMethod) else ref
        if cb is None:
            if isinstance(ref, weakref.WeakMethod):
                dead_refs.append(ref)
            continue
        try:
            cb(target)
        except Exception as exc:
            logger.error(f"{TAG} Language listener {cb!r} failed: {exc}", exc_info=True)

    if dead_refs:
        with _lock:
            for dead in dead_refs:
                while dead in _listeners:
                    _listeners.remove(dead)

    return target


def on_language_changed(callback: Callable[[str], None]) -> Callable[[], None]:
    """Register a callback invoked on language changes; returns an unsubscribe callable."""
    ref: Callable[[str], None] | weakref.WeakMethod
    if inspect.ismethod(callback):
        ref = weakref.WeakMethod(callback)
    else:
        ref = callback

    with _lock:
        if ref not in _listeners:
            _listeners.append(ref)

    def _unsubscribe() -> None:
        with _lock:
            while ref in _listeners:
                _listeners.remove(ref)

    return _unsubscribe


def _should_skip_lookup(text: str) -> bool:
    stripped = text.strip()
    if not stripped:
        return True
    if _URL_RE.match(stripped):
        return True
    if not has_vietnamese_chars(stripped):
        if _WIN_PATH_RE.match(stripped) or _POSIX_PATH_RE.match(stripped):
            return True
    return False


def _lookup_exact_or_template(text: str, depth: int) -> str | None:
    if text in _exact_map:
        return _exact_map[text]

    for pattern, keys, en_template in _compiled_templates:
        match = pattern.match(text)
        if not match:
            continue
        values: dict[str, str] = {}
        for idx, key in enumerate(keys):
            raw_val = match.group(f"p_{idx}")
            if depth < 2 and raw_val:
                values[key] = _translate_internal(raw_val, depth + 1)
            else:
                values[key] = raw_val
        return _PLACEHOLDER_SUB_RE.sub(lambda m: values.get(m.group(1), m.group(0)), en_template)

    return None


def _translate_core(text: str, depth: int) -> str | None:
    direct = _lookup_exact_or_template(text, depth)
    if direct is not None:
        return direct

    # Try stripping common UI icon/bullet prefixes and trailing punctuation
    prefix = ""
    core = text
    for p in _UI_PREFIXES:
        if core.startswith(p):
            prefix = p
            core = core[len(p) :]
            break

    suffix = ""
    if core:
        for s in _TRAILING_PUNCT:
            if core.endswith(s) and len(core) > len(s):
                suffix = s
                core = core[: -len(s)]
                break

    if (prefix or suffix) and core:
        # First try with suffix kept (e.g. "Đang tải...")
        if prefix and not suffix:
            matched = _lookup_exact_or_template(core, depth)
            if matched is not None:
                return f"{prefix}{matched}"
        else:
            with_suffix = core + suffix
            matched = _lookup_exact_or_template(with_suffix, depth)
            if matched is not None:
                return f"{prefix}{matched}"
            matched_core = _lookup_exact_or_template(core, depth)
            if matched_core is not None:
                return f"{prefix}{matched_core}{suffix}"

    if depth < 2:
        if "&&" in text:
            unesc = text.replace("&&", "&")
            unesc_tr = _translate_core(unesc, depth + 1)
            if unesc_tr is not None and unesc_tr != unesc:
                return unesc_tr.replace("&&", "\x00").replace("&", "&&").replace("\x00", "&&")

        m = _PAREN_SUFFIX_RE.match(core)
        if m:
            lhs_raw, rhs_raw = m.group(1), m.group(2)
            lhs_tr = _translate_core(lhs_raw, depth + 1)
            rhs_tr = _translate_internal(rhs_raw, depth + 1)
            if (lhs_tr is not None and lhs_tr != lhs_raw) or (rhs_tr != rhs_raw):
                lhs_out = lhs_tr if lhs_tr is not None else lhs_raw
                return f"{prefix}{lhs_out} ({rhs_tr}){suffix}"

        if ": " in core and not _URL_RE.match(core):
            lhs_raw, rhs_raw = core.split(": ", 1)
            lhs_tr = _translate_core(lhs_raw, depth + 1)
            if lhs_tr is not None and lhs_tr != lhs_raw:
                rhs_tr = _translate_internal(rhs_raw, depth + 1)
                return f"{prefix}{lhs_tr}: {rhs_tr}{suffix}"

    return None


def _translate_html(text: str, depth: int) -> str | None:
    if "<" not in text or ">" not in text:
        return None
    tokens = _HTML_TAG_SPLIT_RE.split(text)
    changed = False
    out: list[str] = []
    for tok in tokens:
        if not tok or tok.startswith("<") or tok == "&nbsp;" or (tok.startswith("&#") and tok.endswith(";")):
            out.append(tok)
            continue
        lead_len = len(tok) - len(tok.lstrip())
        trail_len = len(tok) - len(tok.rstrip())
        lead = tok[:lead_len]
        trail = tok[len(tok) - trail_len :] if trail_len else ""
        mid = tok[lead_len : len(tok) - trail_len if trail_len else len(tok)]
        if not mid:
            out.append(tok)
            continue
        translated = _translate_internal(mid, depth + 1) if depth < 2 else mid
        if translated != mid:
            changed = True
        out.append(f"{lead}{translated}{trail}")
    return "".join(out) if changed else None


def _translate_internal(text: str, depth: int = 0) -> str:
    if not isinstance(text, str) or not text:
        return text
    if _should_skip_lookup(text):
        return text

    _ensure_catalog_loaded()

    # Exact / template lookup on full string first
    direct = _translate_core(text, depth)
    if direct is not None:
        return direct

    # Preserve outer whitespace
    lead_len = len(text) - len(text.lstrip())
    trail_len = len(text) - len(text.rstrip())
    lead = text[:lead_len]
    trail = text[len(text) - trail_len :] if trail_len else ""
    stripped = text[lead_len : len(text) - trail_len if trail_len else len(text)]
    if lead or trail:
        core_match = _translate_core(stripped, depth)
        if core_match is not None:
            return f"{lead}{core_match}{trail}"

    # HTML-aware translation (only text nodes)
    if "<" in stripped and ">" in stripped:
        html_match = _translate_html(stripped, depth)
        if html_match is not None:
            return f"{lead}{html_match}{trail}"

    # Segment splitting for multi-line / dot-separated text
    if depth < 2:
        for sep in _SEGMENT_SEPARATORS:
            if sep in stripped:
                parts = stripped.split(sep)
                translated_parts = []
                any_changed = False
                for part in parts:
                    t_part = _translate_internal(part, depth + 1)
                    if t_part != part:
                        any_changed = True
                    translated_parts.append(t_part)
                if any_changed:
                    return f"{lead}{sep.join(translated_parts)}{trail}"

    return text


@functools.lru_cache(maxsize=8192)
def translate_vi_to_en(text: str) -> str:
    """Translate a Vietnamese UI string or template into English (cached)."""
    return _translate_internal(text, 0)


def tr(text: str) -> str:
    """Translate text to the active application language."""
    if not isinstance(text, str) or not text:
        return text
    if current_language() == LANG_VI:
        return text
    return translate_vi_to_en(text)
