"""
Steam artwork fetcher and deployer for Bob Gaming Game Center.
Downloads Poster, Grid, Hero, Logo, and Icon from SteamGridDB and Steam CDN,
and applies them to all Steam user profiles.
"""

import json
import logging
import os
import re
import time
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote_plus

import requests

from app.config import STEAMGRIDB_API_KEY
from app.core.online_fix.store_cache import _CLEAN_EDITION_RE, clean_lookup_title, titles_match_strict
from app.core.steam_manager import find_steam_path, get_grid_dir, get_steam_user_ids

logger = logging.getLogger(__name__)
TAG = "[SteamArtwork]"

USER_AGENT = "BobGamingGameCenter/1.0 (Windows)"
_STEAM_SHARED_ASSET_BASE = "https://shared.akamai.steamstatic.com/store_item_assets/"
_STEAM_COMMUNITY_ICON_BASE = "https://shared.akamai.steamstatic.com/community_assets/images/apps"


def _append_unique(target: list[str], url: str) -> None:
    u = (url or "").strip()
    if u and u not in target:
        target.append(u)


def _pick_matching_sgdb_game(game_name: str, results: list):
    """Return the first SteamGridDB search result that strictly matches `game_name` (never a different game/year)."""
    if not results:
        return None
    lookup = clean_lookup_title(game_name)
    for cand in results:
        cand_name = str(getattr(cand, "name", "") or "")
        if titles_match_strict(game_name, cand_name) or (lookup and titles_match_strict(lookup, cand_name)):
            return cand
    top_name = str(getattr(results[0], "name", "") or "")
    logger.warning(
        f"{TAG} Rejected {len(results)} non-matching SteamGridDB result(s) for {game_name!r} (top={top_name!r})"
    )
    return None


def resolve_steam_store_appid(game_name: str, timeout: float = 10.0) -> tuple[int | None, str]:
    """
    Resolve official Steam Store AppID for `game_name` using strict title matching.
    Never falls back to `items[0]` when the store returns a different sequel/edition.
    """
    lookup = clean_lookup_title(game_name) or (game_name or "").strip()
    if not lookup:
        return None, ""

    stripped_lookup = _CLEAN_EDITION_RE.sub("", lookup).strip().rstrip(".-_:/|–— ") or lookup
    de_dotted = " ".join(re.sub(r"[\-–—:]+", " ", stripped_lookup.replace(".", "")).split())
    camel_split = re.sub(r"([a-z])([A-Z])", r"\1 \2", stripped_lookup).strip()
    query_variants = [q for q in dict.fromkeys((lookup, stripped_lookup, de_dotted, camel_split)) if q]

    last_non_matching: list[dict] = []
    for query_term in query_variants:
        search_url = f"https://store.steampowered.com/api/storesearch/?term={quote_plus(query_term)}&l=english&cc=US"
        t0 = time.monotonic()
        try:
            resp = requests.get(search_url, timeout=timeout, headers={"User-Agent": USER_AGENT})
            elapsed = time.monotonic() - t0
            if resp.status_code != 200:
                logger.warning(
                    f"{TAG} Steam storesearch failed for {game_name!r}: HTTP {resp.status_code} ({search_url}) in {elapsed:.2f}s"
                )
                continue
            items = (resp.json() or {}).get("items") or []
        except Exception as e:
            logger.warning(
                f"{TAG} Steam storesearch failed for {game_name!r}: {e} ({search_url}) in {time.monotonic() - t0:.2f}s"
            )
            continue

        if not items:
            continue

        for it in items:
            cand_name = str(it.get("name") or "")
            if titles_match_strict(game_name, cand_name) or titles_match_strict(lookup, cand_name):
                try:
                    appid = int(it["id"])
                    if appid > 0:
                        return appid, cand_name
                except (KeyError, TypeError, ValueError):
                    continue
        last_non_matching = items

    if last_non_matching:
        top_name = str(last_non_matching[0].get("name") or "")
        logger.warning(
            f"{TAG} Rejected {len(last_non_matching)} non-matching Steam Store result(s) for {game_name!r} (top={top_name!r})"
        )
    return None, ""


def resolve_steam_cdn_asset_urls(
    appid: int,
    needed_types: list[str] | None = None,
    timeout: float = 8.0,
) -> dict[str, list[str]]:
    """
    Build prioritized Steam CDN URLs (modern hashed store_item_assets + legacy /steam/apps/{appid}/ fallback)
    for poster, grid, hero, logo, and icon.
    """
    wanted = set(needed_types or ("poster", "grid", "hero", "logo", "icon"))
    cdn_map: dict[str, list[str]] = {k: [] for k in ("poster", "grid", "hero", "logo", "icon")}

    # 1. Query IStoreBrowseService/GetItems/v1 for hashed store/library asset filenames (2024+ Steam games)
    if wanted & {"poster", "grid", "hero", "icon"}:
        browse_url = "https://api.steampowered.com/IStoreBrowseService/GetItems/v1/"
        payload = json.dumps(
            {
                "ids": [{"appid": int(appid)}],
                "context": {"language": "english", "country_code": "US"},
                "data_request": {"include_assets": True},
            },
            separators=(",", ":"),
        )
        t0 = time.monotonic()
        try:
            resp = requests.get(
                browse_url,
                params={"input_json": payload},
                timeout=timeout,
                headers={"User-Agent": USER_AGENT},
            )
            if resp.status_code == 200:
                store_items = ((resp.json() or {}).get("response") or {}).get("store_items") or []
                assets = (store_items[0].get("assets") or {}) if store_items and isinstance(store_items[0], dict) else {}
                fmt = str(assets.get("asset_url_format") or f"steam/apps/{appid}/${{FILENAME}}").split("?", 1)[0]
                if "${FILENAME}" not in fmt:
                    fmt = f"steam/apps/{appid}/${{FILENAME}}"

                def _asset_url(rel: str) -> str:
                    clean_rel = (rel or "").strip().lstrip("/")
                    if not clean_rel:
                        return ""
                    if clean_rel.startswith(("http://", "https://")):
                        return clean_rel
                    return _STEAM_SHARED_ASSET_BASE + fmt.replace("${FILENAME}", clean_rel).lstrip("/")

                for key in ("library_capsule_2x", "library_capsule"):
                    if assets.get(key):
                        _append_unique(cdn_map["poster"], _asset_url(str(assets[key])))

                for key in ("header_2x", "header", "main_capsule_2x", "main_capsule"):
                    if assets.get(key):
                        _append_unique(cdn_map["grid"], _asset_url(str(assets[key])))

                for key in (
                    "library_hero_2x",
                    "library_hero",
                    "hero_capsule_2x",
                    "hero_capsule",
                    "raw_page_background",
                    "page_background",
                ):
                    if assets.get(key):
                        _append_unique(cdn_map["hero"], _asset_url(str(assets[key])))

                comm_icon = str(assets.get("community_icon") or "").strip()
                if comm_icon:
                    if comm_icon.endswith((".ico", ".jpg", ".png")):
                        _append_unique(cdn_map["icon"], f"{_STEAM_COMMUNITY_ICON_BASE}/{appid}/{comm_icon}")
                    else:
                        _append_unique(cdn_map["icon"], f"{_STEAM_COMMUNITY_ICON_BASE}/{appid}/{comm_icon}.ico")
                        _append_unique(cdn_map["icon"], f"{_STEAM_COMMUNITY_ICON_BASE}/{appid}/{comm_icon}.jpg")
            else:
                logger.debug(
                    f"{TAG} IStoreBrowseService HTTP {resp.status_code} for appid={appid} in {time.monotonic() - t0:.2f}s"
                )
        except Exception as e:
            logger.debug(f"{TAG} IStoreBrowseService lookup skipped for appid={appid}: {e}")

    # 2. Query api.steamcmd.net/v1/info/{appid} when logo is needed or primary hashed assets were missing
    need_appinfo = ("logo" in wanted and not cdn_map["logo"]) or any(
        k in wanted and not cdn_map[k] for k in ("poster", "grid", "hero", "icon")
    )
    if need_appinfo:
        info_url = f"https://api.steamcmd.net/v1/info/{int(appid)}"
        t0 = time.monotonic()
        try:
            resp = requests.get(info_url, timeout=min(timeout, 6.0), headers={"User-Agent": USER_AGENT})
            if resp.status_code == 200:
                app_data = ((resp.json() or {}).get("data") or {}).get(str(appid)) or {}
                common = app_data.get("common") if isinstance(app_data, dict) else None
                if isinstance(common, dict):
                    lib_full = common.get("library_assets_full") or {}

                    def _extract_lib_paths(section_name: str) -> list[str]:
                        sec = lib_full.get(section_name)
                        if not isinstance(sec, dict):
                            return []
                        paths: list[str] = []
                        for field in ("image2x", "image"):
                            val = sec.get(field)
                            if isinstance(val, dict):
                                rel = val.get("english") or next((v for v in val.values() if isinstance(v, str) and v), "")
                                if rel:
                                    paths.append(f"{_STEAM_SHARED_ASSET_BASE}steam/apps/{appid}/{rel.lstrip('/')}")
                            elif isinstance(val, str) and val:
                                paths.append(f"{_STEAM_SHARED_ASSET_BASE}steam/apps/{appid}/{val.lstrip('/')}")
                        return paths

                    for u in _extract_lib_paths("library_logo"):
                        _append_unique(cdn_map["logo"], u)
                    for u in _extract_lib_paths("library_capsule"):
                        _append_unique(cdn_map["poster"], u)
                    for u in _extract_lib_paths("library_header"):
                        _append_unique(cdn_map["grid"], u)
                    for u in _extract_lib_paths("library_hero"):
                        _append_unique(cdn_map["hero"], u)

                    for icon_key in ("clienticon", "icon"):
                        ic_hash = str(common.get(icon_key) or "").strip()
                        if ic_hash:
                            ext = ".ico" if icon_key == "clienticon" else ".jpg"
                            _append_unique(cdn_map["icon"], f"{_STEAM_COMMUNITY_ICON_BASE}/{appid}/{ic_hash}{ext}")
        except Exception as e:
            logger.debug(f"{TAG} Steam appinfo lookup skipped for appid={appid}: {e}")

    # 3. Append legacy unhashed Steam CDN paths as fallback
    for u in (
        f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_600x900_2x.jpg",
        f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_600x900.jpg",
    ):
        _append_unique(cdn_map["poster"], u)
    _append_unique(cdn_map["grid"], f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/header.jpg")
    _append_unique(cdn_map["hero"], f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_hero.jpg")
    _append_unique(cdn_map["logo"], f"https://cdn.akamai.steamstatic.com/steam/apps/{appid}/logo.png")

    return cdn_map


class SteamArtworkDownloader:
    """Fetches high quality artworks from SteamGridDB and Steam CDN."""

    def __init__(self, api_key: str = STEAMGRIDB_API_KEY):
        self.api_key = api_key
        self.sgdb = None
        if self.api_key:
            try:
                from steamgrid import SteamGridDB
                self.sgdb = SteamGridDB(self.api_key)
            except Exception as e:
                logger.warning(f"Could not initialize SteamGridDB: {e}")

    def fetch_artworks(
        self,
        game_name: str,
        progress_cb: Callable[[str, str], None] | None = None,
    ) -> dict[str, tuple[bytes, str] | None]:
        """
        Fetch all 5 Steam asset types for a given game.

        Returns:
            Dict mapping asset_type ('poster', 'grid', 'hero', 'logo', 'icon')
            to (bytes_content, extension_str) or None.
        """
        assets: dict[str, tuple | None] = {
            "poster": None,
            "grid": None,
            "hero": None,
            "logo": None,
            "icon": None,
        }

        # 1. Try SteamGridDB first (strict title match only — never accept a different sequel/edition)
        if self.sgdb:
            try:
                if progress_cb:
                    progress_cb("search", f"Searching SteamGridDB for '{game_name}'...")
                sgdb_game = None
                lookup_name = clean_lookup_title(game_name) or game_name
                stripped_lookup = _CLEAN_EDITION_RE.sub("", lookup_name).strip().rstrip(".-_:/|–— ") or lookup_name
                camel_split = re.sub(r"([a-z])([A-Z])", r"\1 \2", stripped_lookup).strip()
                for q in dict.fromkeys((game_name, lookup_name, stripped_lookup, camel_split)):
                    if not q:
                        continue
                    results = self.sgdb.search_game(q)
                    sgdb_game = _pick_matching_sgdb_game(game_name, results or [])
                    if sgdb_game is not None:
                        break

                if sgdb_game is not None:
                    gid = sgdb_game.id
                    logger.info(f"{TAG} Found SteamGridDB game: {sgdb_game.name} (id={gid}) for {game_name!r}")

                    def _fetch_grids():
                        res = {}
                        try:
                            grids = self.sgdb.get_grids_by_gameid(game_ids=[gid])
                            if grids:
                                portraits = [g for g in grids if getattr(g, "height", 0) > getattr(g, "width", 0)]
                                landscapes = [g for g in grids if getattr(g, "width", 0) > getattr(g, "height", 0)]
                                if portraits:
                                    res["poster"] = self._download_best_asset(portraits, "poster", progress_cb)
                                if landscapes:
                                    res["grid"] = self._download_best_asset(landscapes, "grid", progress_cb)
                        except Exception as e:
                            logger.warning(f"{TAG} Error fetching grids: {e}")
                        return res

                    def _fetch_heroes():
                        res = {}
                        try:
                            heroes = self.sgdb.get_heroes_by_gameid(game_ids=[gid])
                            if heroes:
                                res["hero"] = self._download_best_asset(heroes, "hero", progress_cb)
                        except Exception as e:
                            logger.warning(f"{TAG} Error fetching heroes: {e}")
                        return res

                    def _fetch_logos():
                        res = {}
                        try:
                            logos = self.sgdb.get_logos_by_gameid(game_ids=[gid])
                            if logos:
                                res["logo"] = self._download_best_asset(logos, "logo", progress_cb)
                        except Exception as e:
                            logger.warning(f"{TAG} Error fetching logos: {e}")
                        return res

                    def _fetch_icons():
                        res = {}
                        try:
                            icons = self.sgdb.get_icons_by_gameid(game_ids=[gid])
                            if icons:
                                res["icon"] = self._download_best_asset(icons, "icon", progress_cb)
                        except Exception as e:
                            logger.warning(f"{TAG} Error fetching icons: {e}")
                        return res

                    # Run all 4 asset category fetches in parallel
                    with ThreadPoolExecutor(max_workers=4) as sgdb_pool:
                        fetch_tasks = [
                            sgdb_pool.submit(_fetch_grids),
                            sgdb_pool.submit(_fetch_heroes),
                            sgdb_pool.submit(_fetch_logos),
                            sgdb_pool.submit(_fetch_icons),
                        ]
                        for f in as_completed(fetch_tasks):
                            try:
                                partial = f.result()
                                assets.update(partial)
                            except Exception as e:
                                logger.error(f"{TAG} Concurrent fetch error: {e}")

            except Exception as e:
                logger.warning(f"{TAG} SteamGridDB search error: {e}")

        # 2. Fallback to Steam CDN for any missing assets
        missing = [k for k, v in assets.items() if v is None]
        if missing:
            try:
                cdn_assets = self._fetch_from_steam_cdn(game_name, missing, progress_cb)
                for k, v in cdn_assets.items():
                    if assets.get(k) is None and v is not None:
                        assets[k] = v
            except Exception as e:
                logger.warning(f"{TAG} Steam CDN fallback error: {e}")

        return assets

    def _download_best_asset(
        self,
        candidates: list,
        asset_type: str,
        progress_cb: Callable[[str, str], None] | None = None,
    ) -> tuple | None:
        """Download the first static candidate image."""
        for item in candidates:
            url = getattr(item, "url", "")
            if not url or url.endswith(".webm") or url.endswith(".gif"):
                continue

            try:
                if progress_cb:
                    progress_cb(asset_type, f"Downloading {asset_type}...")
                resp = requests.get(url, timeout=12, headers={"User-Agent": USER_AGENT})
                if resp.status_code == 200 and len(resp.content) > 500:
                    content_type = resp.headers.get("content-type", "")
                    ext = ".png" if "png" in content_type else ".ico" if "icon" in content_type else ".jpg"
                    if url.endswith(".ico"):
                        ext = ".ico"
                    return resp.content, ext
            except Exception as e:
                logger.warning(f"{TAG} Download failed for {url}: {e}")
                continue
        return None

    def _fetch_from_steam_cdn(
        self,
        game_name: str,
        needed_types: list[str],
        progress_cb: Callable[[str, str], None] | None = None,
    ) -> dict[str, tuple | None]:
        """Fetch missing assets using official Steam Store search and hashed/legacy CDN concurrently."""
        res: dict[str, tuple | None] = {}
        try:
            appid, matched_name = resolve_steam_store_appid(game_name)
            if not appid:
                return res

            logger.info(f"{TAG} Resolved Steam Store AppID for {game_name!r}: {appid} ({matched_name})")
            cdn_map = resolve_steam_cdn_asset_urls(appid, needed_types=needed_types)

            def _fetch_cdn_type(asset_type: str):
                urls = cdn_map.get(asset_type, [])
                for url in urls:
                    try:
                        if progress_cb:
                            progress_cb(asset_type, f"Downloading official {asset_type}...")
                        r = requests.get(url, timeout=10, headers={"User-Agent": USER_AGENT})
                        if r.status_code == 200 and len(r.content) > 500:
                            content_type = r.headers.get("content-type", "").lower()
                            clean_url = url.split("?", 1)[0].lower()
                            if clean_url.endswith(".ico") or "icon" in content_type:
                                ext = ".ico"
                            elif clean_url.endswith(".png") or "png" in content_type:
                                ext = ".png"
                            else:
                                ext = ".jpg"
                            return asset_type, (r.content, ext)
                    except Exception:
                        continue
                return asset_type, None

            with ThreadPoolExecutor(max_workers=min(4, max(1, len(needed_types)))) as pool:
                for k, v in pool.map(_fetch_cdn_type, needed_types):
                    if v is not None:
                        res[k] = v

        except Exception as e:
            logger.warning(f"{TAG} Steam CDN search error for {game_name}: {e}")

        return res


def download_and_apply_steam_artworks(
    game_name: str,
    uint_appid: int,
    steam_path: str | None = None,
    target_user_ids: list[str] | None = None,
    api_key: str = STEAMGRIDB_API_KEY,
    progress_callback: Callable[[str, str], None] | None = None,
) -> dict:
    """
    Download and deploy all 5 Steam artwork assets to all specified Steam profiles.

    Filenames written to Steam's grid folder:
      - Poster: <appid>p.png / .jpg
      - Grid:   <appid>.png / .jpg
      - Hero:   <appid>_hero.png / .jpg
      - Logo:   <appid>_logo.png
      - Icon:   <appid>_icon.png / .ico

    Returns summary dict.
    """
    if not steam_path:
        steam_path = find_steam_path()
    if not steam_path:
        return {"success": False, "message": "Steam directory not found."}

    user_ids = target_user_ids or get_steam_user_ids(steam_path)
    if not user_ids:
        return {"success": False, "message": "No Steam user accounts found."}

    downloader = SteamArtworkDownloader(api_key=api_key)
    artworks = downloader.fetch_artworks(game_name, progress_cb=progress_callback)

    sid = str(uint_appid)
    downloaded_status = {k: bool(v) for k, v in artworks.items()}
    has_any_artwork = any(downloaded_status.values())
    deployed_count = 0

    suffix_map = {
        "poster": "p",
        "grid": "",
        "hero": "_hero",
        "logo": "_logo",
        "icon": "_icon",
    }
    alt_exts = [".jpg", ".png", ".ico", ".jpeg"]

    for uid in user_ids:
        grid_dir = get_grid_dir(steam_path, uid)

        for asset_type, asset_data in artworks.items():
            suffix = suffix_map[asset_type]
            if not asset_data:
                # If we refreshed artworks for this shortcut and an asset type is unavailable,
                # purge stale files from a previous mismatched sync so wrong logos/heroes don't linger.
                if has_any_artwork:
                    for alt in alt_exts:
                        stale_path = os.path.join(grid_dir, f"{sid}{suffix}{alt}")
                        if os.path.exists(stale_path):
                            try:
                                os.remove(stale_path)
                            except OSError:
                                pass
                continue

            content, ext = asset_data
            target_filename = f"{sid}{suffix}{ext}"
            target_path = os.path.join(grid_dir, target_filename)

            # Remove conflicting opposite extension file (e.g. remove old .jpg if writing .png)
            for alt in alt_exts:
                if alt != ext:
                    old_path = os.path.join(grid_dir, f"{sid}{suffix}{alt}")
                    if os.path.exists(old_path):
                        try:
                            os.remove(old_path)
                        except OSError:
                            pass

            try:
                with open(target_path, "wb") as f:
                    f.write(content)
                deployed_count += 1
            except OSError as e:
                logger.error(f"{TAG} Failed to write artwork {target_path}: {e}")

    if progress_callback:
        progress_callback("complete", "All artworks processed.")

    return {
        "success": has_any_artwork,
        "game_name": game_name,
        "uint_appid": uint_appid,
        "downloaded": downloaded_status,
        "affected_users": user_ids,
        "deployed_files_count": deployed_count,
    }
