"""Cross-platform OS sleep / idle inhibitor while downloading or installing games.

Prevents Windows, SteamOS (Desktop Mode and Game Mode / Gamescope), generic Linux,
and macOS from suspending or turning off the system before queued downloads,
extractions, repack installers, Android installs, or localizations finish.

All OS calls run on a single dedicated worker thread so:
- The Qt UI thread is never blocked by D-Bus, X11, or subprocess setup.
- Per-thread kernel locks (Win32 SetThreadExecutionState, X11 Display*) are
  acquired, refreshed, and released from the exact same OS thread.
"""

from __future__ import annotations

import ctypes
import itertools
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
from typing import Any

logger = logging.getLogger(__name__)
TAG = "[SleepInhibitor]"

DISABLE_ENV_VAR = "BOBGAMING_SLEEP_INHIBIT_DISABLE"
KEEPALIVE_INTERVAL_S = 45.0
APP_INHIBIT_NAME = "Bob Gaming Game Center"
DEFAULT_INHIBIT_REASON = "Downloading and installing games"

ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002
ES_ACTIVE_FLAGS = ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED

_CONN_SEQ = itertools.count(1)


def _sanitize_reason(reason: str) -> str:
    cleaned = " ".join(str(reason or "").split()).strip()
    return cleaned[:160] if cleaned else DEFAULT_INHIBIT_REASON


class _Win32SleepBackend:
    """Windows sleep/display idle inhibitor using SetThreadExecutionState."""

    def __init__(self, kernel32: Any = None):
        self._kernel32 = kernel32
        self._configured = False

    def _resolve_kernel32(self):
        if self._kernel32 is not None:
            return self._kernel32
        if sys.platform != "win32" or not hasattr(ctypes, "windll"):
            return None
        try:
            self._kernel32 = ctypes.windll.kernel32
        except Exception as exc:
            logger.warning(f"{TAG} Could not access kernel32.dll: {exc}")
            return None
        return self._kernel32

    def _ensure_signature(self, k32) -> None:
        if self._configured:
            return
        fn = getattr(k32, "SetThreadExecutionState", None)
        if fn is not None:
            try:
                fn.argtypes = [ctypes.c_uint32]
                fn.restype = ctypes.c_uint32
            except Exception:
                pass
        self._configured = True

    def acquire(self, _reason: str) -> list[str]:
        k32 = self._resolve_kernel32()
        if k32 is None:
            return []
        self._ensure_signature(k32)
        try:
            prev = int(k32.SetThreadExecutionState(ES_ACTIVE_FLAGS) or 0)
            if prev == 0:
                logger.warning(f"{TAG} SetThreadExecutionState returned 0 (failed to set execution state)")
                return []
            return ["win32:SetThreadExecutionState"]
        except Exception as exc:
            logger.warning(f"{TAG} SetThreadExecutionState acquire failed: {exc}")
            return []

    def keepalive(self, _reason: str) -> None:
        k32 = self._resolve_kernel32()
        if k32 is None:
            return
        self._ensure_signature(k32)
        try:
            k32.SetThreadExecutionState(ES_ACTIVE_FLAGS)
        except Exception:
            pass

    def release(self) -> None:
        k32 = self._resolve_kernel32()
        if k32 is None:
            return
        self._ensure_signature(k32)
        try:
            k32.SetThreadExecutionState(ES_CONTINUOUS)
        except Exception as exc:
            logger.warning(f"{TAG} SetThreadExecutionState release failed: {exc}")


class _LinuxSleepBackend:
    """SteamOS (Desktop + Game Mode) and Linux sleep/idle inhibitor.

    Stacks three complementary layers so both Desktop Mode (KDE PowerDevil / logind)
    and Game Mode (Gamescope / XWayland / systemd-logind) stay awake:
    1. `systemd-inhibit --what=idle:sleep --mode=block cat` (stdin pipe prevents zombie locks)
       with fallback to `org.freedesktop.login1.Manager.Inhibit` D-Bus FD.
    2. Session D-Bus `org.freedesktop.ScreenSaver` and `org.freedesktop.PowerManagement.Inhibit`.
    3. X11 / XWayland `libX11` + `libXss` (`XScreenSaverSuspend` + `XResetScreenSaver`).
    """

    def __init__(self):
        self._inhibit_proc: subprocess.Popen | None = None
        self._login1_fd: int = -1
        self._session_conn_name: str = ""
        self._session_cookies: list[tuple[str, str, str, int]] = []
        self._x11_state: tuple[Any, Any, int] | None = None  # (x11_lib, xss_lib_or_none, display_ptr)

    def acquire(self, reason: str) -> list[str]:
        safe_reason = _sanitize_reason(reason)
        active: list[str] = []

        sys_tag = self._acquire_systemd_or_login1(safe_reason)
        if sys_tag:
            active.append(sys_tag)

        dbus_tags = self._acquire_session_dbus(safe_reason)
        active.extend(dbus_tags)

        x11_tag = self._acquire_x11()
        if x11_tag:
            active.append(x11_tag)

        return active

    def keepalive(self, reason: str) -> None:
        if self._inhibit_proc is not None:
            rc = self._inhibit_proc.poll()
            if rc is not None:
                logger.warning(f"{TAG} systemd-inhibit exited unexpectedly (code={rc}); re-acquiring system lock")
                self._close_inhibit_proc()
                self._acquire_systemd_or_login1(_sanitize_reason(reason))

        if self._x11_state is not None:
            x11, _xss, dpy = self._x11_state
            try:
                x11.XResetScreenSaver(dpy)
                x11.XFlush(dpy)
            except Exception:
                pass

    def release(self) -> None:
        self._release_x11()
        self._release_session_dbus()
        self._close_inhibit_proc()
        self._close_login1_fd()

    # ------------------------------------------------------------------ Layer A: systemd-inhibit / login1 FD

    def _acquire_systemd_or_login1(self, safe_reason: str) -> str:
        inhibit_bin = shutil.which("systemd-inhibit")
        if inhibit_bin:
            try:
                proc = subprocess.Popen(
                    [
                        inhibit_bin,
                        "--what=idle:sleep",
                        f"--who={APP_INHIBIT_NAME}",
                        f"--why={safe_reason}",
                        "--mode=block",
                        "cat",
                    ],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                )
                time.sleep(0.03)
                if proc.poll() is None:
                    self._inhibit_proc = proc
                    return "linux:systemd-inhibit"
                err_out = b""
                if proc.stderr is not None:
                    try:
                        err_out = proc.stderr.read() or b""
                    except OSError:
                        pass
                self._dispose_proc_pipes(proc)
                logger.debug(
                    f"{TAG} systemd-inhibit exited immediately (code={proc.returncode}): "
                    f"{err_out.decode('utf-8', errors='replace').strip()}"
                )
            except Exception as exc:
                logger.debug(f"{TAG} systemd-inhibit spawn failed: {exc}")

        if self._acquire_login1_dbus_fd(safe_reason):
            return "linux:login1-dbus"
        return ""

    def _acquire_login1_dbus_fd(self, safe_reason: str) -> bool:
        try:
            from PySide6.QtDBus import QDBusConnection, QDBusInterface, QDBusMessage
        except Exception as exc:
            logger.debug(f"{TAG} PySide6.QtDBus unavailable for login1 fallback: {exc}")
            return False

        conn_name = f"bob_sleep_login1_{next(_CONN_SEQ)}"
        conn = None
        iface = None
        try:
            conn = QDBusConnection.connectToBus(QDBusConnection.BusType.SystemBus, conn_name)
            if not conn.isConnected():
                return False
            iface = QDBusInterface(
                "org.freedesktop.login1",
                "/org/freedesktop/login1",
                "org.freedesktop.login1.Manager",
                conn,
            )
            if not iface.isValid():
                return False
            reply = iface.call("Inhibit", "idle:sleep", APP_INHIBIT_NAME, safe_reason, "block")
            if reply.type() != QDBusMessage.MessageType.ReplyMessage or not reply.arguments():
                logger.debug(f"{TAG} login1 Inhibit D-Bus error: {reply.errorMessage()}")
                return False
            fd_arg = reply.arguments()[0]
            raw_fd = fd_arg.fileDescriptor() if hasattr(fd_arg, "fileDescriptor") else -1
            is_valid = fd_arg.isValid() if hasattr(fd_arg, "isValid") else (raw_fd >= 0)
            if is_valid and raw_fd >= 0:
                self._login1_fd = os.dup(raw_fd)
                return True
            return False
        except Exception as exc:
            logger.debug(f"{TAG} login1 D-Bus Inhibit failed: {exc}")
            return False
        finally:
            iface = None
            conn = None
            try:
                QDBusConnection.disconnectFromBus(conn_name)
            except Exception:
                pass

    @staticmethod
    def _dispose_proc_pipes(proc: subprocess.Popen) -> None:
        for pipe in (proc.stdin, proc.stdout, proc.stderr):
            if pipe is not None:
                try:
                    pipe.close()
                except OSError:
                    pass

    def _close_inhibit_proc(self) -> None:
        proc = self._inhibit_proc
        if proc is None:
            return
        self._inhibit_proc = None
        try:
            if proc.stdin is not None:
                try:
                    proc.stdin.close()
                except OSError:
                    pass
            try:
                proc.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=1.0)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=0.5)
        except Exception as exc:
            logger.warning(f"{TAG} Error stopping systemd-inhibit process: {exc}")
        finally:
            for pipe in (proc.stdout, proc.stderr):
                if pipe is not None:
                    try:
                        pipe.close()
                    except OSError:
                        pass

    def _close_login1_fd(self) -> None:
        fd = self._login1_fd
        if fd >= 0:
            self._login1_fd = -1
            try:
                os.close(fd)
            except OSError as exc:
                logger.warning(f"{TAG} Error closing login1 inhibit fd {fd}: {exc}")

    # ------------------------------------------------------------------ Layer B: Session D-Bus ScreenSaver/PowerManagement

    def _acquire_session_dbus(self, safe_reason: str) -> list[str]:
        try:
            from PySide6.QtDBus import QDBusConnection, QDBusInterface, QDBusMessage
        except Exception as exc:
            logger.debug(f"{TAG} PySide6.QtDBus unavailable for session inhibit: {exc}")
            return []

        conn_name = f"bob_sleep_session_{next(_CONN_SEQ)}"
        conn = None
        acquired_tags: list[str] = []
        acquired_services: set[str] = set()
        candidates = (
            ("org.freedesktop.ScreenSaver", "/org/freedesktop/ScreenSaver", "org.freedesktop.ScreenSaver"),
            ("org.freedesktop.ScreenSaver", "/ScreenSaver", "org.freedesktop.ScreenSaver"),
            (
                "org.freedesktop.PowerManagement.Inhibit",
                "/org/freedesktop/PowerManagement/Inhibit",
                "org.freedesktop.PowerManagement.Inhibit",
            ),
        )
        try:
            conn = QDBusConnection.connectToBus(QDBusConnection.BusType.SessionBus, conn_name)
            if conn.isConnected():
                for service, path, iface_name in candidates:
                    if service in acquired_services:
                        continue
                    iface = None
                    try:
                        iface = QDBusInterface(service, path, iface_name, conn)
                        if not iface.isValid():
                            continue
                        reply = iface.call("Inhibit", APP_INHIBIT_NAME, safe_reason)
                        if reply.type() == QDBusMessage.MessageType.ReplyMessage and reply.arguments():
                            cookie = int(reply.arguments()[0])
                            self._session_cookies.append((service, path, iface_name, cookie))
                            acquired_services.add(service)
                            acquired_tags.append(f"dbus:{service}")
                    except Exception as exc:
                        logger.debug(f"{TAG} Session D-Bus {service}{path} failed: {exc}")
                    finally:
                        iface = None
        except Exception as exc:
            logger.debug(f"{TAG} Session D-Bus connect failed: {exc}")
        finally:
            conn = None

        if acquired_tags:
            self._session_conn_name = conn_name
        else:
            try:
                QDBusConnection.disconnectFromBus(conn_name)
            except Exception:
                pass
        return acquired_tags

    def _release_session_dbus(self) -> None:
        conn_name = self._session_conn_name
        cookies = list(self._session_cookies)
        self._session_conn_name = ""
        self._session_cookies.clear()
        if not conn_name:
            return
        try:
            from PySide6.QtDBus import QDBusConnection, QDBusInterface

            conn = QDBusConnection(conn_name)
            try:
                if conn.isConnected():
                    for service, path, iface_name, cookie in cookies:
                        iface = None
                        try:
                            iface = QDBusInterface(service, path, iface_name, conn)
                            if iface.isValid():
                                iface.call("UnInhibit", int(cookie))
                        except Exception as exc:
                            logger.warning(f"{TAG} Failed D-Bus UnInhibit on {service}: {exc}")
                        finally:
                            iface = None
            finally:
                conn = None
                QDBusConnection.disconnectFromBus(conn_name)
        except Exception as exc:
            logger.warning(f"{TAG} Error releasing session D-Bus inhibit: {exc}")

    # ------------------------------------------------------------------ Layer C: X11 / XWayland (Gamescope)

    def _acquire_x11(self) -> str:
        display_name = os.environ.get("DISPLAY", "").strip()
        if not display_name:
            return ""
        try:
            x11 = ctypes.CDLL("libX11.so.6")
        except OSError as exc:
            logger.debug(f"{TAG} libX11.so.6 unavailable ({exc}); skipping X11 idle inhibit")
            return ""

        x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
        x11.XOpenDisplay.restype = ctypes.c_void_p
        x11.XCloseDisplay.argtypes = [ctypes.c_void_p]
        x11.XCloseDisplay.restype = ctypes.c_int
        x11.XFlush.argtypes = [ctypes.c_void_p]
        x11.XFlush.restype = ctypes.c_int
        x11.XResetScreenSaver.argtypes = [ctypes.c_void_p]
        x11.XResetScreenSaver.restype = ctypes.c_int

        dpy = x11.XOpenDisplay(display_name.encode("utf-8"))
        if not dpy:
            logger.debug(f"{TAG} XOpenDisplay({display_name!r}) returned NULL")
            return ""

        xss = None
        try:
            xss = ctypes.CDLL("libXss.so.1")
            xss.XScreenSaverQueryExtension.argtypes = [
                ctypes.c_void_p,
                ctypes.POINTER(ctypes.c_int),
                ctypes.POINTER(ctypes.c_int),
            ]
            xss.XScreenSaverQueryExtension.restype = ctypes.c_int
            xss.XScreenSaverSuspend.argtypes = [ctypes.c_void_p, ctypes.c_int]
            xss.XScreenSaverSuspend.restype = None

            ev_base = ctypes.c_int()
            err_base = ctypes.c_int()
            if xss.XScreenSaverQueryExtension(dpy, ctypes.byref(ev_base), ctypes.byref(err_base)):
                xss.XScreenSaverSuspend(dpy, 1)
            else:
                xss = None
        except OSError as exc:
            logger.debug(f"{TAG} libXss.so.1 unavailable ({exc}); using XResetScreenSaver keepalive")
            xss = None
        except Exception as exc:
            logger.debug(f"{TAG} XScreenSaverSuspend setup skipped: {exc}")
            xss = None

        try:
            x11.XResetScreenSaver(dpy)
            x11.XFlush(dpy)
        except Exception as exc:
            logger.debug(f"{TAG} XResetScreenSaver failed: {exc}")
            try:
                x11.XCloseDisplay(dpy)
            except Exception:
                pass
            return ""

        self._x11_state = (x11, xss, dpy)
        return "x11:XScreenSaverSuspend" if xss is not None else "x11:XResetScreenSaver"

    def _release_x11(self) -> None:
        state = self._x11_state
        if state is None:
            return
        self._x11_state = None
        x11, xss, dpy = state
        try:
            if xss is not None:
                xss.XScreenSaverSuspend(dpy, 0)
            x11.XFlush(dpy)
        except Exception as exc:
            logger.warning(f"{TAG} Error releasing X11 screensaver suspend: {exc}")
        finally:
            try:
                x11.XCloseDisplay(dpy)
            except Exception as exc:
                logger.warning(f"{TAG} Error closing X11 display: {exc}")


class _MacOSSleepBackend:
    """macOS sleep inhibitor backed by caffeinate."""

    def __init__(self):
        self._proc: subprocess.Popen | None = None

    def acquire(self, _reason: str) -> list[str]:
        caffeinate = shutil.which("caffeinate")
        if not caffeinate:
            return []
        try:
            self._proc = subprocess.Popen(
                [caffeinate, "-di", "-w", str(os.getpid())],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return ["macos:caffeinate"]
        except Exception as exc:
            logger.warning(f"{TAG} Failed starting caffeinate: {exc}")
            return []

    def keepalive(self, _reason: str) -> None:
        pass

    def release(self) -> None:
        proc = self._proc
        if proc is None:
            return
        self._proc = None
        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=1.0)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=0.5)
        except Exception as exc:
            logger.warning(f"{TAG} Error stopping caffeinate: {exc}")


class _NoopSleepBackend:
    def acquire(self, _reason: str) -> list[str]:
        return []

    def keepalive(self, _reason: str) -> None:
        pass

    def release(self) -> None:
        pass


def _default_backend():
    if sys.platform == "win32":
        return _Win32SleepBackend()
    if sys.platform.startswith("linux"):
        return _LinuxSleepBackend()
    if sys.platform == "darwin":
        return _MacOSSleepBackend()
    return _NoopSleepBackend()


class SleepInhibitor:
    """Thread-safe coordinator keeping the OS awake while >= 1 download/install task is active."""

    def __init__(
        self,
        backend=None,
        keepalive_interval: float = KEEPALIVE_INTERVAL_S,
        disabled: bool | None = None,
    ):
        self._disabled = (os.environ.get(DISABLE_ENV_VAR) == "1") if disabled is None else bool(disabled)
        self._backend = backend if backend is not None else _default_backend()
        self._keepalive_interval = max(0.05, float(keepalive_interval))

        self._cond = threading.Condition()
        self._enabled = True
        self._active_tasks = 0
        self._reason = ""
        self._desired_gen = 0
        self._applied_gen = 0
        self._stopping = False
        self._is_inhibiting = False
        self._active_backends: tuple[str, ...] = ()
        self._acquired_at = 0.0
        self._release_reason = "all tasks finished"
        self._thread: threading.Thread | None = None

    @property
    def is_inhibiting(self) -> bool:
        with self._cond:
            return self._is_inhibiting

    @property
    def active_backends(self) -> tuple[str, ...]:
        with self._cond:
            return self._active_backends

    def update(self, enabled: bool, active_tasks: int, reason: str = "") -> None:
        """Update desired inhibition state without blocking the caller thread."""
        if self._disabled:
            return
        count = max(0, int(active_tasks))
        en = bool(enabled)
        want = en and count > 0
        with self._cond:
            if self._stopping:
                return
            self._enabled = en
            self._active_tasks = count
            self._reason = reason
            if not want and self._is_inhibiting:
                self._release_reason = "setting disabled" if not en else "all tasks finished"
            if want == self._is_inhibiting and self._desired_gen == self._applied_gen:
                return
            self._desired_gen += 1
            if self._thread is None:
                self._thread = threading.Thread(
                    target=self._worker_loop,
                    daemon=True,
                    name="bob-sleep-inhibitor",
                )
                self._thread.start()
            self._cond.notify_all()

    def wait_for_idle(self, timeout: float = 2.0) -> bool:
        """Wait until all pending state transitions have finished applying (useful for tests/shutdown)."""
        if self._disabled:
            return True
        deadline = time.monotonic() + max(0.0, float(timeout))
        with self._cond:
            while self._applied_gen < self._desired_gen:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                self._cond.wait(timeout=remaining)
            return True

    def shutdown(self, timeout: float = 2.0) -> None:
        """Release any held OS sleep lock and stop the dedicated background worker."""
        if self._disabled:
            return
        with self._cond:
            self._stopping = True
            self._enabled = False
            self._active_tasks = 0
            if self._is_inhibiting:
                self._release_reason = "shutdown"
            self._desired_gen += 1
            thread = self._thread
            self._cond.notify_all()
        if thread is not None and thread.is_alive() and threading.current_thread() is not thread:
            thread.join(timeout=max(0.1, float(timeout)))

    def _worker_loop(self) -> None:
        while True:
            with self._cond:
                is_keepalive = False
                while not self._stopping and self._desired_gen == self._applied_gen:
                    timeout = self._keepalive_interval if self._is_inhibiting else None
                    self._cond.wait(timeout=timeout)
                    if not self._stopping and self._desired_gen == self._applied_gen and self._is_inhibiting:
                        is_keepalive = True
                        break

                if self._stopping:
                    should_release = self._is_inhibiting
                    release_reason = self._release_reason or "shutdown"
                    target_gen = self._desired_gen
                    break_after = True
                else:
                    break_after = False
                    target_gen = self._desired_gen
                    want = self._enabled and self._active_tasks > 0
                    active_tasks = self._active_tasks
                    reason = self._reason or DEFAULT_INHIBIT_REASON
                    currently_inhibiting = self._is_inhibiting
                    release_reason = self._release_reason

            if break_after:
                if should_release:
                    self._do_release(release_reason)
                with self._cond:
                    self._applied_gen = max(self._applied_gen, target_gen)
                    self._cond.notify_all()
                return

            if want and not currently_inhibiting:
                self._do_acquire(active_tasks, reason)
            elif not want and currently_inhibiting:
                self._do_release(release_reason)
            elif want and currently_inhibiting and is_keepalive:
                self._do_keepalive(reason)

            with self._cond:
                self._applied_gen = max(self._applied_gen, target_gen)
                self._cond.notify_all()

    def _do_acquire(self, active_tasks: int, reason: str) -> None:
        t0 = time.monotonic()
        try:
            backends = list(self._backend.acquire(reason) or [])
        except Exception as exc:
            logger.error(f"{TAG} Unexpected error acquiring sleep inhibitor: {exc}", exc_info=True)
            backends = []

        elapsed_ms = (time.monotonic() - t0) * 1000.0
        if backends:
            with self._cond:
                self._is_inhibiting = True
                self._active_backends = tuple(backends)
                self._acquired_at = time.monotonic()
            logger.info(
                f"{TAG} Sleep inhibited ({', '.join(backends)}) — {active_tasks} active task(s) "
                f"({reason}) in {elapsed_ms:.1f}ms"
            )
        else:
            with self._cond:
                self._is_inhibiting = False
                self._active_backends = ()
                self._acquired_at = 0.0
            logger.warning(
                f"{TAG} Could not acquire any OS sleep inhibitor backend for {active_tasks} active task(s) "
                f"({reason}) after {elapsed_ms:.1f}ms"
            )

    def _do_keepalive(self, reason: str) -> None:
        try:
            self._backend.keepalive(reason)
        except Exception as exc:
            logger.warning(f"{TAG} Keepalive check failed: {exc}")

    def _do_release(self, release_reason: str) -> None:
        t0 = time.monotonic()
        with self._cond:
            prev_backends = self._active_backends
            acquired_at = self._acquired_at
        held_s = max(0.0, time.monotonic() - acquired_at) if acquired_at > 0 else 0.0
        try:
            self._backend.release()
        except Exception as exc:
            logger.error(f"{TAG} Unexpected error releasing sleep inhibitor: {exc}", exc_info=True)
        finally:
            with self._cond:
                self._is_inhibiting = False
                self._active_backends = ()
                self._acquired_at = 0.0
        elapsed_ms = (time.monotonic() - t0) * 1000.0
        logger.info(
            f"{TAG} Sleep inhibitor released ({release_reason}; held {held_s:.1f}s; "
            f"backends={', '.join(prev_backends) or 'none'}) in {elapsed_ms:.1f}ms"
        )
