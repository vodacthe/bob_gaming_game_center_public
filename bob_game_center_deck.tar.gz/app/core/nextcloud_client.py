"""
Nextcloud WebDAV client for Bob Gaming Game Center.
Handles all cloud storage operations via WebDAV protocol.
"""

import os
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from webdav3.client import Client
from webdav3.exceptions import WebDavException

from app.config import BOBIGNORE_FILENAME, CLOUD_ROOT_FOLDER, SAVE_LOCATION_FILENAME, make_app_temp_file
from app.core.cloud_provider import CloudProvider
from app.core.transfer_tracker import TransferProgressTracker

logger = logging.getLogger(__name__)


class NextcloudClient(CloudProvider):
    """Client for Nextcloud WebDAV operations."""

    def __init__(self, cloud_url: str, username: str, password: str):
        """
        Initialize Nextcloud WebDAV client.

        Args:
            cloud_url: Base URL of the Nextcloud instance (e.g., https://cloud.example.com)
            username: Nextcloud username
            password: Nextcloud password or app password
        """
        self.cloud_url = cloud_url.rstrip("/")
        self.username = username
        self.password = password

        # Build WebDAV URL
        webdav_url = f"{self.cloud_url}/remote.php/dav/files/{self.username}/"

        self.options = {
            "webdav_hostname": webdav_url,
            "webdav_login": username,
            "webdav_password": password,
            "webdav_timeout": 30,
        }
        self.client = Client(self.options)
        self.root = CLOUD_ROOT_FOLDER
        self._thread_local = threading.local()

    def _get_thread_client(self) -> Client:
        """Get or initialize thread-local WebDAV client for concurrent transfers."""
        if not hasattr(self._thread_local, "client") or self._thread_local.client is None:
            self._thread_local.client = Client(self.options)
        return self._thread_local.client

    def test_connection(self) -> bool:
        """Test if the WebDAV connection works."""
        try:
            self.client.list("/")
            return True
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return False

    def _ensure_root(self):
        """Ensure the root BobGamingGameCenter folder exists."""
        try:
            if not self.client.check(self.root):
                self.client.mkdir(self.root)
        except WebDavException as e:
            logger.error(f"Failed to create root folder: {e}")
            raise

    def _mkdir_recursive(self, path: str):
        """Create nested directories on the server."""
        parts = path.strip("/").split("/")
        current = ""
        for part in parts:
            current = f"{current}/{part}" if current else part
            try:
                if not self.client.check(current):
                    self.client.mkdir(current)
            except WebDavException:
                try:
                    self.client.mkdir(current)
                except WebDavException:
                    pass  # May already exist

    def _game_path(self, game_name: str) -> str:
        """Get the remote path for a game folder."""
        return f"{self.root}/{game_name}"

    def _saves_path(self, game_name: str) -> str:
        """Get the remote path for a game's saves folder."""
        return f"{self.root}/{game_name}/saves"

    def get_saves_path(self, game_name: str) -> str:
        """CloudProvider interface: get the remote path for a game's saves folder."""
        return self._saves_path(game_name)

    def check_game_exists(self, game_name: str) -> bool:
        """Check if a game folder exists on the cloud."""
        try:
            return self.client.check(self._game_path(game_name))
        except WebDavException:
            return False

    def create_game_folder(self, game_name: str):
        """Create the game folder structure on the cloud."""
        self._ensure_root()
        self._mkdir_recursive(self._game_path(game_name))
        self._mkdir_recursive(self._saves_path(game_name))

    def _parse_time(self, time_str: str) -> float:
        """Parse WebDAV timestamp to float."""
        if not time_str:
            return 0.0
        try:
            import email.utils
            parsed = email.utils.parsedate_tz(time_str)
            if parsed:
                return email.utils.mktime_tz(parsed)
        except Exception:
            pass
        return 0.0

    def list_directory_recursive(self, remote_path: str) -> dict:
        """
        Recursively list a remote directory and return a dict of:
        relative_path -> {"mtime": float, "size": int}
        """
        state = {}
        try:
            if not self.client.check(remote_path):
                return state
        except WebDavException:
            return state

        def walk(current_path):
            try:
                items = self.client.list(current_path, get_info=True)
            except WebDavException:
                return
            
            # The first item is the directory itself
            for item in items[1:]:
                # webdav3 get_info returns paths like '/remote.php/dav/files/user/BobGamingGameCenter/Game/saves/file.txt'
                # We need to extract the relative path from `remote_path`
                raw_path = item.get("path", "")
                
                # Unquote URL encoding
                import urllib.parse
                unquoted_path = urllib.parse.unquote(raw_path)
                
                # Find the relative part
                idx = unquoted_path.find(remote_path)
                if idx >= 0:
                    rel_path = unquoted_path[idx + len(remote_path):].lstrip("/")
                else:
                    # Fallback if path parsing is weird
                    continue
                    
                if not rel_path:
                    continue

                if item.get("isdir"):
                    walk(f"{remote_path}/{rel_path}")
                else:
                    size_str = item.get("size", "0")
                    try:
                        size = int(size_str) if size_str else 0
                    except ValueError:
                        size = 0
                        
                    state[rel_path] = {
                        "mtime": self._parse_time(item.get("modified")),
                        "size": size
                    }
                    
        walk(remote_path)
        return state

    def delete_remote_files(self, remote_base: str, rel_paths: list[str]):
        """Delete specific files from the cloud."""
        for rel_path in rel_paths:
            remote_file = f"{remote_base}/{rel_path}"
            try:
                self.client.clean(remote_file)
                logger.info(f"Deleted remote file: {rel_path}")
            except WebDavException as e:
                logger.error(f"Failed to delete {rel_path}: {e}")

    def upload_delta(self, local_base: str, remote_base: str, files_to_upload: list[str], progress_callback=None):
        """Upload specific files to the cloud concurrently with real-time progress and speed."""
        self._mkdir_recursive(remote_base)
        created_dirs = {remote_base}
        total = len(files_to_upload)
        if total == 0:
            return

        # 1. Pre-create all parent directories sequentially
        for rel_path in files_to_upload:
            remote_file = f"{remote_base}/{rel_path.replace(os.sep, '/')}"
            parent_dir = "/".join(remote_file.split("/")[:-1])
            if parent_dir not in created_dirs:
                self._mkdir_recursive_cached(parent_dir, created_dirs)

        # 2. Measure local file sizes and setup tracker
        file_sizes = {}
        for rel_path in files_to_upload:
            local_file = os.path.join(local_base, rel_path)
            try:
                file_sizes[rel_path] = os.path.getsize(local_file) if os.path.exists(local_file) else 0
            except OSError:
                file_sizes[rel_path] = 0

        tracker = TransferProgressTracker(
            total_files=total,
            file_sizes=file_sizes,
            callback=progress_callback,
        )

        def _upload_file(rel_path: str):
            local_file = os.path.join(local_base, rel_path)
            if not os.path.exists(local_file):
                tracker.file_completed(rel_path)
                return
            remote_file = f"{remote_base}/{rel_path.replace(os.sep, '/')}"
            client = self._get_thread_client()

            def _chunk_cb(current, total_file_bytes=None, *args):
                tracker.update_file_chunk(rel_path, current)

            try:
                client.upload_sync(
                    remote_path=remote_file,
                    local_path=local_file,
                    progress=_chunk_cb,
                )
                tracker.file_completed(rel_path)
                logger.info(f"[Nextcloud] Uploaded (parallel): {rel_path}")
            except WebDavException as e:
                logger.error(f"[Nextcloud] Failed to upload {rel_path}: {e}")
                raise e

        workers = min(4, total)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(_upload_file, p) for p in files_to_upload]
            for f in as_completed(futures):
                f.result()

    def _mkdir_recursive_cached(self, path: str, created_dirs: set):
        """Create nested directories using a cache to minimize network calls."""
        parts = path.strip("/").split("/")
        current = ""
        for part in parts:
            current = f"{current}/{part}" if current else part
            if current in created_dirs:
                continue
            try:
                if not self.client.check(current):
                    self.client.mkdir(current)
                created_dirs.add(current)
            except WebDavException:
                try:
                    self.client.mkdir(current)
                    created_dirs.add(current)
                except WebDavException:
                    pass  # May already exist

    def download_delta(self, remote_base: str, local_base: str, files_to_download: list[str], progress_callback=None, file_sizes: dict[str, int] = None):
        """Download specific files from the cloud concurrently with real-time progress and speed."""
        total = len(files_to_download)
        if total == 0:
            return

        tracker = TransferProgressTracker(
            total_files=total,
            file_sizes=file_sizes,
            callback=progress_callback,
        )

        def _download_file(rel_path: str):
            local_file = os.path.join(local_base, rel_path)
            remote_file = f"{remote_base}/{rel_path.replace(os.sep, '/')}"
            client = self._get_thread_client()

            def _chunk_cb(current, total_file_bytes=None, *args):
                if total_file_bytes:
                    tracker.set_file_size_if_unknown(rel_path, total_file_bytes)
                tracker.update_file_chunk(rel_path, current)

            try:
                os.makedirs(os.path.dirname(local_file), exist_ok=True)
                client.download_sync(
                    remote_path=remote_file,
                    local_path=local_file,
                    progress=_chunk_cb,
                )
                if os.path.exists(local_file):
                    tracker.set_file_size_if_unknown(rel_path, os.path.getsize(local_file))
                tracker.file_completed(rel_path)
                logger.info(f"[Nextcloud] Downloaded (parallel): {rel_path}")
            except WebDavException as e:
                logger.error(f"[Nextcloud] Failed to download {rel_path}: {e}")
                raise e

        workers = min(4, total)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(_download_file, p) for p in files_to_download]
            for f in as_completed(futures):
                f.result()

    def upload_saves(self, game_name: str, local_save_path: str, progress_callback=None):
        """Fallback for full upload (legacy, now handled via delta in SyncManager)."""
        self.create_game_folder(game_name)
        remote_saves = self._saves_path(game_name)
        
        # Fast clear fallback
        try:
            if self.client.check(remote_saves):
                self.client.clean(remote_saves)
        except WebDavException:
            pass
            
        # Re-upload using delta logic with all files
        files_to_upload = []
        for root, dirs, files in os.walk(local_save_path):
            for f in files:
                files_to_upload.append(os.path.relpath(os.path.join(root, f), local_save_path))
        
        self.upload_delta(local_save_path, remote_saves, files_to_upload, progress_callback)

    def download_saves(self, game_name: str, local_save_path: str, progress_callback=None):
        """
        Download all save files from cloud to local path.

        Args:
            game_name: Name of the game
            local_save_path: Local path to download saves to
            progress_callback: Optional callback(current, total) for progress
        """
        remote_saves = self._saves_path(game_name)

        if not self.client.check(remote_saves):
            raise FileNotFoundError(f"No saves found on cloud for: {game_name}")

        os.makedirs(local_save_path, exist_ok=True)
        self._download_directory(remote_saves, local_save_path, progress_callback)

    def _download_directory(self, remote_path: str, local_path: str, progress_callback=None):
        """Recursively download a remote directory to local path."""
        try:
            items = self.client.list(remote_path)
        except WebDavException as e:
            logger.error(f"Failed to list {remote_path}: {e}")
            return

        # Count files for progress
        file_items = [item for item in items[1:] if not item.endswith("/")]
        dir_items = [item for item in items[1:] if item.endswith("/")]
        total = len(file_items)
        current = 0

        for item in items[1:]:  # Skip the directory itself
            if not item or item.strip() == "":
                continue

            remote_item = f"{remote_path}/{item}".rstrip("/")
            local_item = os.path.join(local_path, item.rstrip("/"))

            if item.endswith("/"):
                # It's a directory
                os.makedirs(local_item, exist_ok=True)
                self._download_directory(remote_item, local_item)
            else:
                # It's a file
                try:
                    os.makedirs(os.path.dirname(local_item), exist_ok=True)
                    self.client.download_sync(
                        remote_path=remote_item,
                        local_path=local_item
                    )
                    current += 1
                    logger.info(f"Downloaded: {item}")
                except WebDavException as e:
                    logger.error(f"Failed to download {item}: {e}")

                if progress_callback and total > 0:
                    progress_callback(current, total)

    def upload_save_location(self, game_name: str, local_save_path: str):
        """Upload OS-specific save_location file with the local save path."""
        self.create_game_folder(game_name)

        # Write to temp file first
        tmp_fd, tmp_path = make_app_temp_file(prefix="nc_", suffix=".txt")
        try:
            with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
                f.write(local_save_path)

            remote_path = f"{self._game_path(game_name)}/{SAVE_LOCATION_FILENAME}"
            self.client.upload_sync(
                remote_path=remote_path,
                local_path=tmp_path
            )
            logger.info(f"Uploaded {SAVE_LOCATION_FILENAME} for {game_name}")
        finally:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)

    def get_save_location(self, game_name: str) -> str | None:
        """Read OS-specific save_location file from cloud. Falls back to generic."""
        game_path = self._game_path(game_name)

        # Try OS-specific file first
        remote_path = f"{game_path}/{SAVE_LOCATION_FILENAME}"
        try:
            if not self.client.check(remote_path):
                # Fallback to generic save_location.txt
                remote_path = f"{game_path}/save_location.txt"
                if not self.client.check(remote_path):
                    return None

            tmp_fd, tmp_path = make_app_temp_file(prefix="nc_", suffix=".txt")
            os.close(tmp_fd)
            try:
                self.client.download_sync(
                    remote_path=remote_path,
                    local_path=tmp_path
                )
                with open(tmp_path, "r", encoding="utf-8") as f:
                    return f.read().strip()
            finally:
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)
        except WebDavException as e:
            logger.error(f"Failed to read save_location for {game_name}: {e}")
            return None

    def upload_bobignore(self, game_name: str, content: str):
        """Upload .bobignore to game root folder on Nextcloud (alongside save_location_<platform>.txt)."""
        self.create_game_folder(game_name)
        game_path = self._game_path(game_name)

        # 1. Clean up legacy .bobignore inside saves/ folder if present
        legacy_path = f"{game_path}/saves/{BOBIGNORE_FILENAME}"
        try:
            if self.client.check(legacy_path):
                self.client.clean(legacy_path)
                logger.info(f"Cleaned up legacy {BOBIGNORE_FILENAME} in saves/ for {game_name}")
        except Exception:
            pass

        # 2. Upload .bobignore to game root folder
        tmp_fd, tmp_path = make_app_temp_file(prefix="nc_", suffix=".txt")
        try:
            with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
                f.write(content)
            remote_path = f"{game_path}/{BOBIGNORE_FILENAME}"
            self.client.upload_sync(
                remote_path=remote_path,
                local_path=tmp_path
            )
            logger.info(f"Uploaded {BOBIGNORE_FILENAME} for {game_name} to game root folder (alongside {SAVE_LOCATION_FILENAME})")
        finally:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)

    def get_bobignore(self, game_name: str) -> str | None:
        """Read .bobignore from cloud game root folder. Falls back to saves/ folder."""
        game_path = self._game_path(game_name)
        remote_path = f"{game_path}/{BOBIGNORE_FILENAME}"
        try:
            if not self.client.check(remote_path):
                # Fallback to legacy in saves/
                remote_path = f"{game_path}/saves/{BOBIGNORE_FILENAME}"
                if not self.client.check(remote_path):
                    return None

            tmp_fd, tmp_path = make_app_temp_file(prefix="nc_", suffix=".txt")
            os.close(tmp_fd)
            try:
                self.client.download_sync(
                    remote_path=remote_path,
                    local_path=tmp_path
                )
                with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                    return f.read()
            finally:
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)
        except WebDavException as e:
            logger.error(f"Failed to read {BOBIGNORE_FILENAME} for {game_name}: {e}")
            return None

    def delete_bobignore(self, game_name: str):
        """Delete .bobignore from Nextcloud game folder."""
        game_path = self._game_path(game_name)
        try:
            remote_path = f"{game_path}/{BOBIGNORE_FILENAME}"
            if self.client.check(remote_path):
                self.client.clean(remote_path)
            legacy = f"{game_path}/saves/{BOBIGNORE_FILENAME}"
            if self.client.check(legacy):
                self.client.clean(legacy)
        except Exception as e:
            logger.error(f"Failed to delete {BOBIGNORE_FILENAME} for {game_name}: {e}")

    def list_synced_games(self) -> list[str]:
        """List all game folders under the BobGamingGameCenter root."""
        try:
            self._ensure_root()
            items = self.client.list(self.root)
            # Filter for directories (ending with /) and skip the root itself
            games = []
            for item in items[1:]:
                if item.endswith("/"):
                    game_name = item.rstrip("/")
                    if game_name:
                        games.append(game_name)
            return games
        except WebDavException as e:
            logger.error(f"Failed to list synced games: {e}")
            return []

    def get_remote_modified_time(self, game_name: str) -> float | None:
        """Get the remote modification time of a game's saves folder."""
        try:
            remote_saves = self._saves_path(game_name)
            if not self.client.check(remote_saves):
                return None
            info = self.client.info(remote_saves)
            if info and "modified" in info:
                try:
                    import email.utils
                    parsed_tuple = email.utils.parsedate_tz(info["modified"])
                    if parsed_tuple:
                        return email.utils.mktime_tz(parsed_tuple)
                except Exception as e:
                    logger.error(f"Failed to parse remote modified time: {e}")
            return None
        except Exception as e:
            logger.error(f"Failed to fetch remote modified time for {game_name}: {e}")
            return None

    def check_saves_exist(self, game_name: str) -> bool:
        """Check if saves folder exists for a game on cloud."""
        try:
            return self.client.check(self._saves_path(game_name))
        except WebDavException:
            return False

    def delete_game_folder(self, game_name: str) -> bool:
        """Delete an entire game's folder from Nextcloud."""
        try:
            remote_folder = f"{CLOUD_ROOT_FOLDER}/{game_name}"
            if self.client.check(remote_folder):
                self.client.clean(remote_folder)
                logger.info(f"Deleted remote game folder for {game_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete game folder for {game_name}: {e}")
            return False

