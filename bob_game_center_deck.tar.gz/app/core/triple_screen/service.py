"""Triple Screen service: preset storage, Steam exe discovery, and background window-span watcher."""

from __future__ import annotations

import logging
import os
import re
import threading
import time
import uuid
from typing import Callable

from PySide6.QtCore import QObject, QThread, Signal
from PySide6.QtWidgets import QApplication

from app.config import save_config
from app.core.triple_screen import lossless, win32

logger = logging.getLogger(__name__)
TAG = "[TripleScreen/Service]"

ETS2_APPID = 227300
ATS_APPID = 270880

BUILTIN_PRESETS: tuple[dict, ...] = (
    {
        "id": "ets2",
        "name": "Euro Truck Simulator 2",
        "exe_path": "",
        "process_name": "eurotrucks2.exe",
        "steam_appid": ETS2_APPID,
        "enabled": True,
        "builtin": True,
    },
    {
        "id": "ats",
        "name": "American Truck Simulator",
        "exe_path": "",
        "process_name": "amtrucks.exe",
        "steam_appid": ATS_APPID,
        "enabled": True,
        "builtin": True,
    },
)

BUILTIN_EXE_CANDIDATES: dict[str, tuple[str, ...]] = {
    "ets2": ("bin/win_x64/eurotrucks2.exe", "bin/win_x86/eurotrucks2.exe", "eurotrucks2.exe"),
    "ats": ("bin/win_x64/amtrucks.exe", "bin/win_x86/amtrucks.exe", "amtrucks.exe"),
}

_SESSION_STARTUP_TIMEOUT_SEC = 90.0
_SESSION_RESPAWN_GRACE_SEC = 15.0
_GENERIC_EXE_STEMS = frozenset({"game", "launcher", "start", "client", "main", "shipping"})

_running_watchers: set["_WatcherThread"] = set()
_watchers_lock = threading.Lock()
_quit_hooked = False


def _stop_all_watchers_on_quit() -> None:
    with _watchers_lock:
        watchers = list(_running_watchers)
    for w in watchers:
        w.request_stop()
    for w in watchers:
        if not w.wait(2000):
            logger.warning(f"{TAG} Watcher thread still running at exit")


def _hook_quit() -> None:
    global _quit_hooked
    app = QApplication.instance()
    if app is not None and not _quit_hooked:
        app.aboutToQuit.connect(_stop_all_watchers_on_quit)
        _quit_hooked = True


def _derive_display_name(exe_path: str) -> str:
    stem = os.path.splitext(os.path.basename(exe_path))[0].strip()
    cleaned = re.sub(r"[-_. ]?(?:Win64|Win32|x64|x86)[-_.]?Shipping$", "", stem, flags=re.IGNORECASE).strip(" -_")
    candidate = cleaned or stem
    if candidate.lower() in _GENERIC_EXE_STEMS or len(candidate) <= 2:
        parent = os.path.basename(os.path.dirname(exe_path)).strip()
        if parent and parent.lower() not in {"bin", "win64", "win32", "win_x64", "win_x86", "x64", "binaries"}:
            return parent
    return candidate or os.path.basename(exe_path)


def _probe_candidates(root_dir: str, rel_candidates: tuple[str, ...]) -> str:
    if not root_dir or not os.path.isdir(root_dir):
        return ""
    for rel in rel_candidates:
        cand = os.path.normpath(os.path.join(root_dir, rel))
        if os.path.isfile(cand):
            return cand
    return ""


def discover_builtin_executables(
    config_games: dict | None = None,
    library_games: list[dict] | None = None,
) -> dict[str, str]:
    """Discover ETS 2 / ATS .exe paths from library entries, config, or Steam libraries (call off UI thread)."""
    t0 = time.monotonic()
    found: dict[str, str] = {}
    entries: list[dict] = []
    if isinstance(library_games, list):
        entries.extend(g for g in library_games if isinstance(g, dict))
    if isinstance(config_games, dict):
        for name, data in config_games.items():
            if isinstance(data, dict):
                entries.append({"name": name, **data})

    for preset in BUILTIN_PRESETS:
        gid = preset["id"]
        target_name = preset["name"].lower()
        target_proc = preset["process_name"].lower()
        target_appid = int(preset["steam_appid"])
        candidates = BUILTIN_EXE_CANDIDATES.get(gid, (target_proc,))

        # 1. Check existing Library / config entries
        for g in entries:
            g_name = str(g.get("name") or "").strip().lower()
            g_appid = g.get("steam_appid") or g.get("appid")
            g_exe = str(g.get("exe_path") or "").strip().strip('"')
            g_dir = str(g.get("install_location") or "").strip().strip('"')

            matches_game = (
                g_name == target_name
                or (g_appid is not None and str(g_appid).isdigit() and int(g_appid) == target_appid)
                or os.path.basename(g_exe).lower() == target_proc
            )
            if not matches_game:
                continue

            if g_exe and os.path.isfile(g_exe):
                found[gid] = os.path.normpath(g_exe)
                break
            if g_dir and os.path.isdir(g_dir):
                probed = _probe_candidates(g_dir, candidates)
                if probed:
                    found[gid] = probed
                    break

        if gid in found:
            continue

        # 2. Discover via Steam libraryfolders.vdf / Registry
        try:
            from app.core.viethoa.installer import discover_installed_game_dir

            install_dir = discover_installed_game_dir(preset["name"], steam_appid=target_appid)
            if install_dir:
                probed = _probe_candidates(install_dir, candidates)
                if probed:
                    found[gid] = probed
        except Exception:
            logger.debug(f"{TAG} Steam discovery failed for {preset['name']!r}", exc_info=True)

    elapsed = time.monotonic() - t0
    logger.info(f"{TAG} Discovered {len(found)} built-in executables in {elapsed:.2f}s")
    return found


class _WatcherThread(QThread):
    """Background monitor polling running game processes and snapping their windows to target span bounds."""

    game_detected = Signal(str, int)
    game_snapped = Signal(str, object)
    snap_resisted = Signal(str, object)
    game_closed = Signal(str, int)
    session_idle = Signal()

    def __init__(self, service: "TripleScreenService"):
        super().__init__(None)
        self._service = service
        self._stop_event = threading.Event()
        self._stop_requested = False
        self.setObjectName("triple-screen-watcher")

    @property
    def stop_requested(self) -> bool:
        return self._stop_requested

    def request_stop(self) -> None:
        self._stop_requested = True
        self._stop_event.set()

    def start_tracked(self) -> None:
        _hook_quit()
        with _watchers_lock:
            _running_watchers.add(self)
        self.finished.connect(self._forget)
        self.start()

    def _forget(self) -> None:
        with _watchers_lock:
            _running_watchers.discard(self)

    def _find_matching_process(
        self,
        entry: dict,
        procs: list[win32.RunningProcess],
        is_session_target: bool,
    ) -> win32.RunningProcess | None:
        target_proc = str(entry.get("process_name") or "").strip().lower()
        if not target_proc and entry.get("exe_path"):
            target_proc = os.path.basename(str(entry["exe_path"])).lower()

        if target_proc:
            for p in procs:
                if p.exe_name == target_proc:
                    return p

        # Fallback for session-launched wrappers/launchers that spawn the real game binary in the same folder
        exe_path = str(entry.get("exe_path") or "").strip()
        if is_session_target and exe_path:
            target_dir = os.path.normcase(os.path.normpath(os.path.dirname(exe_path)))
            if target_dir and os.path.isdir(target_dir):
                for p in procs:
                    if p.pid <= 4:
                        continue
                    img = win32.query_process_image_path(p.pid)
                    if not img:
                        continue
                    img_dir = os.path.normcase(os.path.normpath(os.path.dirname(img)))
                    if img_dir == target_dir or img_dir.startswith(target_dir + os.sep):
                        return p
        return None

    def run(self) -> None:
        win32.set_thread_per_monitor_dpi()
        win32.ensure_default_desktop()
        logger.info(f"{TAG} Watcher thread started")

        active_pids: dict[str, int] = {}
        active_hwnds: dict[str, int] = {}
        snap_attempts: dict[int, int] = {}
        resisted_rect: dict[int, win32.SpanBounds] = {}

        try:
            while not self._stop_requested:
                try:
                    now = time.monotonic()
                    auto_watch, games, selected_monitors, session_ids = self._service._snapshot_watch_state()

                    watch_entries = [
                        g
                        for g in games
                        if (auto_watch and g.get("enabled", True)) or (g["id"] in session_ids)
                    ]

                    if not watch_entries and not auto_watch:
                        expired_any = self._service._prune_expired_sessions(now)
                        if expired_any or not self._service._has_session_targets():
                            self.session_idle.emit()
                            break

                    procs = win32.list_running_processes() if watch_entries else []
                    monitors = win32.enumerate_monitors() if watch_entries else []
                    bounds, chosen = win32.compute_span_bounds(monitors, selected_monitors) if watch_entries else (win32.SpanBounds(0, 0, 0, 0), [])

                    for g in watch_entries:
                        if self._stop_requested:
                            break
                        gid = g["id"]
                        is_sess = gid in session_ids
                        proc = self._find_matching_process(g, procs, is_sess)

                        if proc is not None:
                            self._service._mark_session_seen(gid)
                            if active_pids.get(gid) != proc.pid:
                                active_pids[gid] = proc.pid
                                logger.info(
                                    f"{TAG} Game detected: {g['name']!r} (PID={proc.pid}, exe={proc.exe_name})"
                                )
                                self.game_detected.emit(g["name"], proc.pid)

                            hwnd = win32.find_game_window(proc.pid, title_hints=(g["name"],))
                            if hwnd:
                                active_hwnds[gid] = hwnd
                                cur = win32.get_window_rect(hwnd)
                                has_borders = win32.window_has_borders(hwnd)
                                if cur is not None and bounds.width > 0 and bounds.height > 0:
                                    if cur != bounds and lossless.is_lossless_overlay_spanning(bounds):
                                        continue
                                    if cur == bounds and not has_borders:
                                        snap_attempts.pop(hwnd, None)
                                        resisted_rect.pop(hwnd, None)
                                    else:
                                        if hwnd in resisted_rect:
                                            if cur == resisted_rect[hwnd]:
                                                continue
                                            resisted_rect.pop(hwnd, None)
                                            snap_attempts[hwnd] = 0

                                        attempts = snap_attempts.get(hwnd, 0)
                                        t0 = time.monotonic()
                                        ok = win32.apply_borderless_span(
                                            hwnd, bounds, bring_to_front=(attempts == 0)
                                        )
                                        elapsed = time.monotonic() - t0
                                        if ok:
                                            new_attempts = attempts + 1
                                            snap_attempts[hwnd] = new_attempts
                                            if new_attempts == 1:
                                                logger.info(
                                                    f"{TAG} Snapped {g['name']!r} hwnd=0x{hwnd:X} "
                                                    f"from ({cur.x}, {cur.y}, {cur.width}, {cur.height}) "
                                                    f"to ({bounds.x}, {bounds.y}, {bounds.width}, {bounds.height}) "
                                                    f"in {elapsed:.3f}s"
                                                )
                                                self.game_snapped.emit(g["name"], bounds)
                                            else:
                                                logger.debug(
                                                    f"{TAG} Re-snapped {g['name']!r} hwnd=0x{hwnd:X} "
                                                    f"(attempt {new_attempts}) from ({cur.x}, {cur.y}, {cur.width}, {cur.height}) "
                                                    f"to ({bounds.x}, {bounds.y}, {bounds.width}, {bounds.height}) "
                                                    f"in {elapsed:.3f}s"
                                                )
                                            if new_attempts >= 3:
                                                resisted_rect[hwnd] = cur
                                                logger.warning(
                                                    f"{TAG} {g['name']!r} (hwnd=0x{hwnd:X}) bounced back to "
                                                    f"({cur.x}, {cur.y}, {cur.width}x{cur.height}) after 3 snap attempts; "
                                                    f"likely locked by Fullscreen/Borderless in-game mode"
                                                )
                                                self.snap_resisted.emit(g["name"], cur)
                                        else:
                                            logger.warning(f"{TAG} Failed to snap {g['name']!r} hwnd=0x{hwnd:X}")
                        else:
                            if gid in active_pids:
                                old_pid = active_pids.pop(gid)
                                old_hwnd = active_hwnds.pop(gid, 0)
                                if old_hwnd:
                                    snap_attempts.pop(old_hwnd, None)
                                    resisted_rect.pop(old_hwnd, None)
                                logger.info(f"{TAG} Game closed: {g['name']!r} (PID={old_pid})")
                                self.game_closed.emit(g["name"], old_pid)
                                self._service._mark_session_exited(gid, now)

                    tracked_hwnd = next(iter(active_hwnds.values()), 0)
                    ls_enabled = bool(watch_entries) and len(chosen) >= 2
                    self._service._lossless.sync(procs, bounds, enabled=ls_enabled, tracked_hwnd=tracked_hwnd)

                    if self._service._prune_expired_sessions(now) and not auto_watch and not self._service._has_session_targets():
                        self.session_idle.emit()
                        break

                except Exception:
                    logger.exception(f"{TAG} Unexpected watcher loop error")

                wait_sec = 1.0 if active_pids else 0.5
                self._stop_event.wait(wait_sec)
        finally:
            if self._stop_requested or not self._service.is_auto_watch_enabled():
                self._service._lossless.unhook_all()
            logger.info(f"{TAG} Watcher thread stopped")


class TripleScreenService(QObject):
    """Coordinates Triple Screen presets, monitor selection, immediate snap, and background watching."""

    status_changed = Signal(bool, str)
    games_changed = Signal()
    game_snapped = Signal(str, object)
    snap_resisted = Signal(str, object)

    def __init__(self, config: dict, save_cb: Callable[[], None] | None = None, parent: QObject | None = None):
        super().__init__(parent)
        self._config = config
        self._save_cb = save_cb
        self._lock = threading.RLock()
        self._session_targets: dict[str, dict] = {}
        self._watcher_thread: _WatcherThread | None = None
        self._lossless = lossless.LosslessSpanHookManager()
        self._ensure_config()

    def _persist(self) -> None:
        if self._save_cb is not None:
            self._save_cb()
        else:
            save_config(self._config)

    def _ensure_config(self) -> dict:
        with self._lock:
            raw = self._config.get("triple_screen")
            if not isinstance(raw, dict):
                raw = {}
                self._config["triple_screen"] = raw

            raw["auto_watch_enabled"] = bool(raw.get("auto_watch_enabled", False))
            raw_mons = raw.get("selected_monitors")
            raw["selected_monitors"] = [str(m) for m in raw_mons if m] if isinstance(raw_mons, list) else []

            existing_by_id: dict[str, dict] = {}
            custom_entries: list[dict] = []
            seen_ids: set[str] = set()
            seen_exes: set[str] = set()

            raw_games = raw.get("games")
            if isinstance(raw_games, list):
                for item in raw_games:
                    if not isinstance(item, dict):
                        continue
                    gid = str(item.get("id") or "").strip()
                    if not gid or gid in seen_ids:
                        continue
                    seen_ids.add(gid)
                    if gid in {"ets2", "ats"}:
                        existing_by_id[gid] = item
                    else:
                        exe = str(item.get("exe_path") or "").strip().strip('"')
                        if not exe:
                            continue
                        norm_exe = os.path.normcase(os.path.normpath(exe))
                        if norm_exe in seen_exes:
                            continue
                        seen_exes.add(norm_exe)
                        proc_name = str(item.get("process_name") or os.path.basename(exe)).strip().lower()
                        custom_entries.append(
                            {
                                "id": gid,
                                "name": str(item.get("name") or _derive_display_name(exe)).strip(),
                                "exe_path": os.path.normpath(exe),
                                "process_name": proc_name,
                                "steam_appid": item.get("steam_appid"),
                                "enabled": bool(item.get("enabled", True)),
                                "builtin": False,
                            }
                        )

            normalized_games: list[dict] = []
            for preset in BUILTIN_PRESETS:
                gid = preset["id"]
                saved = existing_by_id.get(gid, {})
                exe = str(saved.get("exe_path") or "").strip().strip('"')
                proc_name = str(saved.get("process_name") or preset["process_name"]).strip().lower()
                if exe and not proc_name:
                    proc_name = os.path.basename(exe).lower()
                normalized_games.append(
                    {
                        "id": gid,
                        "name": preset["name"],
                        "exe_path": os.path.normpath(exe) if exe else "",
                        "process_name": proc_name or preset["process_name"],
                        "steam_appid": preset["steam_appid"],
                        "enabled": bool(saved.get("enabled", True)),
                        "builtin": True,
                    }
                )
            normalized_games.extend(custom_entries)
            raw["games"] = normalized_games
            return raw

    def start_if_enabled(self) -> None:
        """Start the background watcher at app boot if auto_watch_enabled is True."""
        if self.is_auto_watch_enabled():
            self._ensure_watcher_running()
            self.status_changed.emit(True, "auto_watch")

    def is_auto_watch_enabled(self) -> bool:
        with self._lock:
            return bool(self._ensure_config().get("auto_watch_enabled", False))

    def is_watching(self) -> bool:
        with self._lock:
            auto = bool(self._ensure_config().get("auto_watch_enabled", False))
            has_session = bool(self._session_targets)
            running = self._watcher_thread is not None and self._watcher_thread.isRunning()
            return auto or (has_session and running)

    def get_selected_monitors(self) -> list[str]:
        with self._lock:
            return list(self._ensure_config().get("selected_monitors") or [])

    def set_selected_monitors(self, devices: list[str]) -> None:
        with self._lock:
            ts = self._ensure_config()
            cleaned = [str(d) for d in (devices or []) if d]
            ts["selected_monitors"] = cleaned
            self._persist()
            logger.info(f"{TAG} Selected monitors updated: {cleaned or ['auto']}")

    def get_games(self) -> list[dict]:
        with self._lock:
            return [dict(g) for g in self._ensure_config()["games"]]

    def get_game(self, game_id: str) -> dict | None:
        with self._lock:
            for g in self._ensure_config()["games"]:
                if g["id"] == game_id:
                    return dict(g)
        return None

    def set_auto_watch(self, enabled: bool) -> None:
        enabled_bool = bool(enabled)
        with self._lock:
            ts = self._ensure_config()
            ts["auto_watch_enabled"] = enabled_bool
            self._persist()
            logger.info(f"{TAG} Auto-watch background monitor {'enabled' if enabled_bool else 'disabled'}")
            if enabled_bool:
                self._ensure_watcher_running()
            elif not self._session_targets:
                self._stop_watcher_async()
        self.status_changed.emit(self.is_watching(), "auto_watch_changed")

    def apply_discovered_executables(self, found: dict[str, str]) -> bool:
        """Populate empty exe_path entries for built-in presets from discovery results."""
        if not found:
            return False
        changed = False
        with self._lock:
            games = self._ensure_config()["games"]
            for g in games:
                gid = g["id"]
                discovered_path = found.get(gid, "")
                if not discovered_path or not os.path.isfile(discovered_path):
                    continue
                current = str(g.get("exe_path") or "").strip()
                if not current or not os.path.isfile(current):
                    g["exe_path"] = os.path.normpath(discovered_path)
                    g["process_name"] = os.path.basename(discovered_path).lower()
                    changed = True
            if changed:
                self._persist()
                logger.info(f"{TAG} Applied discovered .exe paths for built-in games")
        if changed:
            self.games_changed.emit()
        return changed

    def set_game_exe(self, game_id: str, exe_path: str) -> dict | None:
        clean_exe = os.path.normpath(str(exe_path or "").strip().strip('"'))
        if not clean_exe:
            raise ValueError("Đường dẫn file .exe không hợp lệ.")
        updated = None
        with self._lock:
            games = self._ensure_config()["games"]
            for g in games:
                if g["id"] == game_id:
                    g["exe_path"] = clean_exe
                    g["process_name"] = os.path.basename(clean_exe).lower()
                    updated = dict(g)
                    break
            if updated is not None:
                self._persist()
                logger.info(f"{TAG} Updated executable for {updated['name']!r}: {clean_exe}")
        if updated is not None:
            self.games_changed.emit()
        return updated

    def set_game_enabled(self, game_id: str, enabled: bool) -> bool:
        updated = False
        with self._lock:
            games = self._ensure_config()["games"]
            for g in games:
                if g["id"] == game_id:
                    g["enabled"] = bool(enabled)
                    updated = True
                    logger.info(f"{TAG} Game {g['name']!r} enabled={g['enabled']}")
                    break
            if updated:
                self._persist()
        if updated:
            self.games_changed.emit()
        return updated

    def add_custom_game(self, exe_path: str, name: str = "") -> dict:
        clean_exe = os.path.normpath(str(exe_path or "").strip().strip('"'))
        if not clean_exe or clean_exe == ".":
            raise ValueError("Vui lòng chọn file .exe hợp lệ.")
        proc_name = os.path.basename(clean_exe).lower()
        norm_target = os.path.normcase(clean_exe)

        with self._lock:
            games = self._ensure_config()["games"]
            for g in games:
                existing_exe = str(g.get("exe_path") or "").strip()
                if existing_exe and os.path.normcase(os.path.normpath(existing_exe)) == norm_target:
                    g["enabled"] = True
                    self._persist()
                    logger.info(f"{TAG} Re-enabled existing game entry {g['name']!r} ({clean_exe})")
                    res = dict(g)
                    break
            else:
                # Reuse matching built-in preset if its exe_path is not set yet
                matched_builtin = next(
                    (
                        g for g in games
                        if g.get("builtin")
                        and g.get("process_name", "").lower() == proc_name
                        and not str(g.get("exe_path") or "").strip()
                    ),
                    None,
                )
                if matched_builtin is not None:
                    matched_builtin["exe_path"] = clean_exe
                    matched_builtin["enabled"] = True
                    self._persist()
                    logger.info(f"{TAG} Linked {clean_exe} to built-in preset {matched_builtin['name']!r}")
                    res = dict(matched_builtin)
                else:
                    display_name = str(name or "").strip() or _derive_display_name(clean_exe)
                    entry = {
                        "id": f"custom_{uuid.uuid4().hex[:8]}",
                        "name": display_name,
                        "exe_path": clean_exe,
                        "process_name": proc_name,
                        "steam_appid": None,
                        "enabled": True,
                        "builtin": False,
                    }
                    games.append(entry)
                    self._persist()
                    logger.info(f"{TAG} Added custom game {display_name!r} (exe={clean_exe})")
                    res = dict(entry)

        self.games_changed.emit()
        return res

    def remove_game(self, game_id: str) -> bool:
        with self._lock:
            games = self._ensure_config()["games"]
            target = next((g for g in games if g["id"] == game_id), None)
            if target is None:
                return False
            if target.get("builtin"):
                logger.warning(f"{TAG} Refused removing built-in preset {target['name']!r}")
                return False
            games.remove(target)
            self._session_targets.pop(game_id, None)
            self._persist()
            logger.info(f"{TAG} Removed custom game {target['name']!r}")
        self.games_changed.emit()
        return True

    def arm_session_target(self, game_id: str) -> None:
        """Arm temporary triple-screen watching for a game launched from the UI."""
        now = time.monotonic()
        with self._lock:
            target = next((g for g in self._ensure_config()["games"] if g["id"] == game_id), None)
            if target is None:
                logger.warning(f"{TAG} Cannot arm unknown game_id={game_id!r}")
                return
            self._session_targets[game_id] = {
                "game_id": game_id,
                "armed_at": now,
                "startup_deadline": now + _SESSION_STARTUP_TIMEOUT_SEC,
                "seen_pid": False,
                "respawn_deadline": 0.0,
            }
            logger.info(f"{TAG} Armed session watcher for {target['name']!r}")
            self._ensure_watcher_running()
        self.status_changed.emit(self.is_watching(), "session_armed")

    def snap_now(self) -> tuple[bool, str, win32.SpanBounds | None]:
        """Immediately find a running target game window and span it across selected monitors (off UI thread)."""
        t0 = time.monotonic()
        with self._lock:
            ts = self._ensure_config()
            games = [dict(g) for g in ts["games"]]
            selected_monitors = list(ts["selected_monitors"])

        monitors = win32.enumerate_monitors()
        if not monitors:
            msg = "Không phát hiện thấy màn hình hiển thị nào."
            logger.warning(f"{TAG} snap_now aborted: no monitors detected")
            return False, msg, None

        bounds, chosen = win32.compute_span_bounds(monitors, selected_monitors)
        if bounds.width <= 0 or bounds.height <= 0:
            msg = "Kích thước cụm màn hình không hợp lệ."
            logger.warning(f"{TAG} snap_now aborted: invalid bounds {bounds}")
            return False, msg, None

        procs = win32.list_running_processes()
        ordered_games = [g for g in games if g.get("enabled", True)] + [g for g in games if not g.get("enabled", True)]

        for g in ordered_games:
            proc_name = str(g.get("process_name") or "").strip().lower()
            if not proc_name:
                continue
            for p in procs:
                if p.exe_name != proc_name:
                    continue
                hwnd = win32.find_game_window(p.pid, title_hints=(g["name"],))
                if hwnd:
                    ok = win32.apply_borderless_span(hwnd, bounds, bring_to_front=True)
                    elapsed = time.monotonic() - t0
                    if ok:
                        self._lossless.sync(procs, bounds, enabled=(len(chosen) >= 2), tracked_hwnd=hwnd)
                        logger.info(
                            f"{TAG} Manual snap succeeded for {g['name']!r} "
                            f"(hwnd=0x{hwnd:X}, monitors={len(chosen)}, "
                            f"bounds=({bounds.x}, {bounds.y}, {bounds.width}, {bounds.height})) in {elapsed:.3f}s"
                        )
                        return True, f"Đã ghép {g['name']} lên {len(chosen)} màn hình ({bounds.width}x{bounds.height}).", bounds
                    msg = f"Không thể thay đổi kích thước cửa sổ của {g['name']} (có thể game chạy quyền cao hơn)."
                    logger.warning(f"{TAG} Manual snap failed for {g['name']!r} hwnd=0x{hwnd:X} in {elapsed:.3f}s")
                    return False, msg, bounds

        elapsed = time.monotonic() - t0
        msg = "Không tìm thấy cửa sổ game nào trong danh sách đang chạy."
        logger.warning(f"{TAG} snap_now found no running target window in {elapsed:.3f}s")
        return False, msg, bounds

    def _snapshot_watch_state(self) -> tuple[bool, list[dict], list[str], set[str]]:
        with self._lock:
            ts = self._ensure_config()
            return (
                bool(ts.get("auto_watch_enabled", False)),
                [dict(g) for g in ts["games"]],
                list(ts.get("selected_monitors") or []),
                set(self._session_targets.keys()),
            )

    def _has_session_targets(self) -> bool:
        with self._lock:
            return bool(self._session_targets)

    def _mark_session_seen(self, game_id: str) -> None:
        with self._lock:
            sess = self._session_targets.get(game_id)
            if sess is not None:
                sess["seen_pid"] = True
                sess["respawn_deadline"] = 0.0

    def _mark_session_exited(self, game_id: str, now: float) -> None:
        with self._lock:
            sess = self._session_targets.get(game_id)
            if sess is not None and sess.get("seen_pid"):
                sess["respawn_deadline"] = now + _SESSION_RESPAWN_GRACE_SEC

    def _prune_expired_sessions(self, now: float) -> bool:
        removed: list[str] = []
        with self._lock:
            for gid, sess in list(self._session_targets.items()):
                if not sess.get("seen_pid"):
                    if now >= sess["startup_deadline"]:
                        removed.append(gid)
                        self._session_targets.pop(gid, None)
                else:
                    deadline = sess.get("respawn_deadline", 0.0)
                    if deadline > 0.0 and now >= deadline:
                        removed.append(gid)
                        self._session_targets.pop(gid, None)
        if removed:
            logger.info(f"{TAG} Session watcher expired for {removed}")
        return bool(removed)

    def _ensure_watcher_running(self) -> None:
        with self._lock:
            cur = self._watcher_thread
            if cur is not None and cur.isRunning() and not cur.stop_requested:
                return
            if cur is not None and cur.isRunning():
                cur.wait(1000)
            thread = _WatcherThread(self)
            thread.game_snapped.connect(self._on_watcher_snapped)
            thread.snap_resisted.connect(self._on_watcher_snap_resisted)
            thread.session_idle.connect(self._on_watcher_idle)
            thread.finished.connect(self._on_watcher_finished)
            self._watcher_thread = thread
            thread.start_tracked()

    def _stop_watcher_async(self) -> None:
        with self._lock:
            cur = self._watcher_thread
            if cur is not None:
                cur.request_stop()

    def _on_watcher_snapped(self, game_name: str, bounds: object) -> None:
        self.game_snapped.emit(game_name, bounds)

    def _on_watcher_snap_resisted(self, game_name: str, cur_bounds: object) -> None:
        self.snap_resisted.emit(game_name, cur_bounds)

    def _on_watcher_idle(self) -> None:
        self.status_changed.emit(self.is_watching(), "session_idle")

    def _on_watcher_finished(self) -> None:
        with self._lock:
            if self._watcher_thread is not None and not self._watcher_thread.isRunning():
                self._watcher_thread = None
        self.status_changed.emit(self.is_watching(), "stopped")

    def sync_lossless_hook(self) -> bool:
        """Synchronize Lossless Scaling hook bounds with the current monitor selection (call off UI thread)."""
        with self._lock:
            selected_monitors = list(self._ensure_config().get("selected_monitors") or [])
        monitors = win32.enumerate_monitors()
        bounds, chosen = win32.compute_span_bounds(monitors, selected_monitors)
        enabled = self.is_watching() and len(chosen) >= 2 and bounds.width > 0 and bounds.height > 0
        return self._lossless.sync(None, bounds, enabled=enabled)

    def shutdown(self) -> None:
        """Stop background watcher cleanly without changing persisted auto-watch setting."""
        with self._lock:
            self._session_targets.clear()
            cur = self._watcher_thread
            if cur is not None:
                cur.request_stop()
        if cur is not None and cur.isRunning():
            if not cur.wait(2000):
                logger.warning(f"{TAG} Watcher thread did not exit within 2s on shutdown")
        self._lossless.unhook_all()
        with self._lock:
            self._watcher_thread = None
        self.status_changed.emit(False, "shutdown")
