"""Triple Screen (multi-monitor borderless span) core package."""

from app.core.triple_screen.lossless import LosslessSpanHookManager
from app.core.triple_screen.service import (
    BUILTIN_PRESETS,
    TripleScreenService,
    discover_builtin_executables,
)
from app.core.triple_screen.win32 import (
    MonitorInfo,
    RunningProcess,
    SpanBounds,
    auto_select_horizontal_monitors,
    compute_span_bounds,
    enumerate_monitors,
)

__all__ = [
    "BUILTIN_PRESETS",
    "LosslessSpanHookManager",
    "MonitorInfo",
    "RunningProcess",
    "SpanBounds",
    "TripleScreenService",
    "auto_select_horizontal_monitors",
    "compute_span_bounds",
    "discover_builtin_executables",
    "enumerate_monitors",
]
