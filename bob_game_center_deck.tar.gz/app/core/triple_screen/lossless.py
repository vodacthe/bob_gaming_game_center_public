"""In-memory Lossless Scaling (`Lossless.dll`) IAT hook for multi-monitor Triple Screen output.

Lossless Scaling resolves its target output monitor via `USER32.dll!GetMonitorInfoW` (using a single
`HMONITOR`, which forces output back to one display when Eyefinity / NVIDIA Surround is off).
When Ghép màn hình is active, `LosslessSpanHookManager` installs an in-memory W^X IAT hook on
`Lossless.dll!GetMonitorInfoW` inside running `LosslessScaling.exe` processes so spanned games
(and `ResizeBeforeScaling`) scale across the combined monitor bounds, while 1-monitor games and
DXGI duplication coordinate helpers remain untouched. Zero files are written to disk.
"""

from __future__ import annotations

import logging
import os
import struct
import sys
import threading
import time
from dataclasses import dataclass
from typing import Callable

from app.core.triple_screen import win32

logger = logging.getLogger(__name__)
TAG = "[TripleScreen/Lossless]"

_IS_WIN = sys.platform == "win32"

HOOK_MAGIC = 0x424F4254534C5331  # "BOBTSLS1"
_CODE_ENTRY_OFFSET = 0x10
_PAGE_SIZE = 4096

# SpanHookData offsets (total 92 bytes on RW data page)
# <QQQQQQQQiiiiiI
_DATA_STRUCT = struct.Struct("<QQQQQQQQiiiiiI")
_OFFSET_TRACKED_HWND = 0x38
_OFFSET_ENABLED = 0x40
_OFFSET_SPAN_RECT = 0x44
_OFFSET_TRIGGER_COUNT = 0x54
_STATE_TAIL_STRUCT = struct.Struct("<Qiiiii")

_TH32CS_SNAPMODULE = 0x00000008
_TH32CS_SNAPMODULE32 = 0x00000010
_PROCESS_HOOK_ACCESS = 0x0438  # PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_QUERY_INFORMATION
_MEM_COMMIT = 0x1000
_MEM_RESERVE = 0x2000
_MEM_RELEASE = 0x8000
_PAGE_READWRITE = 0x04
_PAGE_EXECUTE_READ = 0x20
_MAX_TEXT_SCAN = 512 * 1024

_kernel32 = None
_user32 = None

if _IS_WIN:
    import ctypes
    from ctypes import wintypes

    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _user32 = ctypes.WinDLL("user32", use_last_error=True)
    _INVALID_HANDLE = ctypes.c_void_p(-1).value

    class _MODULEENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("th32ModuleID", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("GlblcntUsage", wintypes.DWORD),
            ("ProccntUsage", wintypes.DWORD),
            ("modBaseAddr", ctypes.c_void_p),
            ("modBaseSize", wintypes.DWORD),
            ("hModule", wintypes.HMODULE),
            ("szModule", wintypes.WCHAR * 256),
            ("szExePath", wintypes.WCHAR * 260),
        ]

    _kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    _kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    _kernel32.Module32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(_MODULEENTRY32W)]
    _kernel32.Module32FirstW.restype = wintypes.BOOL
    _kernel32.Module32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(_MODULEENTRY32W)]
    _kernel32.Module32NextW.restype = wintypes.BOOL
    _kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    _kernel32.OpenProcess.restype = wintypes.HANDLE
    _kernel32.ReadProcessMemory.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)
    ]
    _kernel32.ReadProcessMemory.restype = wintypes.BOOL
    _kernel32.WriteProcessMemory.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)
    ]
    _kernel32.WriteProcessMemory.restype = wintypes.BOOL
    _kernel32.VirtualAllocEx.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD
    ]
    _kernel32.VirtualAllocEx.restype = ctypes.c_void_p
    _kernel32.VirtualFreeEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD]
    _kernel32.VirtualFreeEx.restype = wintypes.BOOL
    _kernel32.VirtualProtectEx.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)
    ]
    _kernel32.VirtualProtectEx.restype = wintypes.BOOL
    _kernel32.FlushInstructionCache.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t]
    _kernel32.FlushInstructionCache.restype = wintypes.BOOL
    _kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    _kernel32.CloseHandle.restype = wintypes.BOOL
    _kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    _kernel32.GetModuleHandleW.restype = ctypes.c_void_p
    _kernel32.GetProcAddress.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    _kernel32.GetProcAddress.restype = ctypes.c_void_p

    _user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    _user32.FindWindowW.restype = wintypes.HWND
    _user32.IsWindowVisible.argtypes = [wintypes.HWND]
    _user32.IsWindowVisible.restype = wintypes.BOOL


@dataclass
class _HookState:
    pid: int
    dll_base: int
    iat_addr: int
    orig_fn: int
    data_addr: int
    code_page: int
    hook_entry: int
    bounds: win32.SpanBounds
    tracked_hwnd: int
    enabled: bool
    last_trigger_count: int = 0


def build_hook_code_page(data_addr: int) -> bytes:
    """Build the x64 W^X-safe GetMonitorInfoW IAT detour page (`[0x00]=magic, [0x08]=data_addr, [0x10]=entry`)."""
    code = bytearray()
    code += struct.pack("<QQ", HOOK_MAGIC, int(data_addr) & 0xFFFFFFFFFFFFFFFF)

    # Entry (+0x10): Win64 ABI args rcx=hMonitor, rdx=lpmi
    code += b"\x4c\x8b\x04\x24"          # mov r8, [rsp]
    code += b"\x53"                      # push rbx
    code += b"\x56"                      # push rsi
    code += b"\x57"                      # push rdi
    code += b"\x48\x83\xec\x40"          # sub rsp, 0x40
    code += b"\x4c\x89\x44\x24\x30"      # mov [rsp+0x30], r8  (caller ret_addr)
    code += b"\x48\x89\xd6"              # mov rsi, rdx        (lpmi)
    disp_data = 0x08 - (len(code) + 7)
    code += b"\x48\x8b\x1d" + struct.pack("<i", disp_data)  # mov rbx, [rip + disp_data]
    code += b"\xff\x53\x08"              # call [rbx + 0x08]   (orig_GetMonitorInfoW)
    code += b"\x89\xc7"                  # mov edi, eax

    jccs: list[int] = []

    def _jcc_done(op2: bytes) -> None:
        code.extend(op2 + b"\x00\x00\x00\x00")
        jccs.append(len(code) - 4)

    code += b"\x85\xff"                  # test edi, edi
    _jcc_done(b"\x0f\x84")               # jz .done
    code += b"\x48\x85\xf6"              # test rsi, rsi
    _jcc_done(b"\x0f\x84")               # jz .done
    code += b"\x83\x7b\x40\x00"          # cmp dword [rbx + 0x40], 0 (enabled)
    _jcc_done(b"\x0f\x84")               # je .done

    # Skip override when called from the legacy DXGI duplication coordinate helper
    code += b"\x48\x8b\x44\x24\x30"      # mov rax, [rsp + 0x30]
    code += b"\x48\x2b\x43\x20"          # sub rax, [rbx + 0x20] (dll_base)
    code += b"\x48\x3b\x43\x28"          # cmp rax, [rbx + 0x28] (skip_rva_lo)
    code += b"\x72\x0a"                  # jb .check_fg
    code += b"\x48\x3b\x43\x30"          # cmp rax, [rbx + 0x30] (skip_rva_hi)
    _jcc_done(b"\x0f\x82")               # jb .done

    # .check_fg: override when foreground is tracked_hwnd or already spans wider than 1 monitor
    code += b"\xff\x53\x10"              # call [rbx + 0x10]   (GetForegroundWindow)
    code += b"\x48\x85\xc0"              # test rax, rax
    _jcc_done(b"\x0f\x84")               # jz .done
    code += b"\x48\x3b\x43\x38"          # cmp rax, [rbx + 0x38] (tracked_hwnd)
    je_apply_pos = len(code) + 2
    code += b"\x0f\x84\x00\x00\x00\x00"  # je .apply

    code += b"\x48\x89\xc1"              # mov rcx, rax
    code += b"\x48\x8d\x54\x24\x20"      # lea rdx, [rsp + 0x20]
    code += b"\xff\x53\x18"              # call [rbx + 0x18]   (GetWindowRect)
    code += b"\x85\xc0"                  # test eax, eax
    _jcc_done(b"\x0f\x84")               # jz .done
    code += b"\x8b\x44\x24\x28"          # mov eax, [rsp + 0x28] (rc.right)
    code += b"\x2b\x44\x24\x20"          # sub eax, [rsp + 0x20] (rc.left)
    code += b"\x8b\x4e\x0c"              # mov ecx, [rsi + 0x0c] (rcMonitor.right)
    code += b"\x2b\x4e\x04"              # sub ecx, [rsi + 0x04] (rcMonitor.left)
    code += b"\x83\xc1\x64"              # add ecx, 100
    code += b"\x39\xc8"                  # cmp eax, ecx
    _jcc_done(b"\x0f\x8e")               # jle .done

    # .apply: overwrite lpmi->rcMonitor & lpmi->rcWork with target span bounds
    apply_off = len(code)
    struct.pack_into("<i", code, je_apply_pos, apply_off - (je_apply_pos + 4))
    for src_disp, m_disp, w_disp in ((0x44, 0x04, 0x14), (0x48, 0x08, 0x18), (0x4C, 0x0C, 0x1C), (0x50, 0x10, 0x20)):
        code += b"\x8b\x43" + bytes((src_disp,))
        code += b"\x89\x46" + bytes((m_disp,))
        code += b"\x89\x46" + bytes((w_disp,))
    code += b"\xf0\xff\x43\x54"          # lock inc dword [rbx + 0x54]

    # .done:
    done_off = len(code)
    for pos in jccs:
        struct.pack_into("<i", code, pos, done_off - (pos + 4))

    code += b"\x89\xf8"                  # mov eax, edi
    code += b"\x48\x83\xc4\x40"          # add rsp, 0x40
    code += b"\x5f"                      # pop rdi
    code += b"\x5e"                      # pop rsi
    code += b"\x5b"                      # pop rbx
    code += b"\xc3"                      # ret
    return bytes(code)


def _read_cstr(read_at: Callable[[int, int], bytes], addr: int, max_len: int = 128) -> str:
    raw = read_at(addr, max_len)
    if not raw:
        return ""
    return raw.split(b"\x00", 1)[0].decode("ascii", errors="ignore")


def find_iat_slot(
    read_at: Callable[[int, int], bytes],
    module_base: int,
    dll_name: str,
    func_name: str,
) -> int:
    """Walk a loaded PE32+ image's import directory to find the IAT slot address for `dll_name!func_name`."""
    if not module_base:
        return 0
    dos = read_at(module_base, 0x40)
    if len(dos) < 0x40 or dos[:2] != b"MZ":
        return 0
    (e_lfanew,) = struct.unpack_from("<I", dos, 0x3C)
    if e_lfanew <= 0 or e_lfanew > 0x4000:
        return 0
    nt = read_at(module_base + e_lfanew, 0xA0)
    if len(nt) < 0x90 or nt[:4] != b"PE\x00\x00":
        return 0
    (opt_magic,) = struct.unpack_from("<H", nt, 24)
    if opt_magic != 0x20B:  # PE32+ x64 only
        return 0
    imp_rva, imp_size = struct.unpack_from("<II", nt, 24 + 112 + 8)
    if not imp_rva or not imp_size:
        return 0

    want_dll = dll_name.lower()
    desc_addr = module_base + imp_rva
    for idx_desc in range(256):
        desc = read_at(desc_addr + idx_desc * 20, 20)
        if len(desc) < 20:
            break
        oft, _ts, _fc, name_rva, ft = struct.unpack("<IIIII", desc)
        if oft == 0 and ft == 0:
            break
        if not name_rva or not ft:
            continue
        cur_dll = _read_cstr(read_at, module_base + name_rva)
        if cur_dll.lower() != want_dll:
            continue
        lookup_rva = oft or ft
        for idx_fn in range(4096):
            thunk = read_at(module_base + lookup_rva + idx_fn * 8, 8)
            if len(thunk) < 8:
                break
            (val,) = struct.unpack("<Q", thunk)
            if val == 0:
                break
            if val & (1 << 63):  # ordinal import
                continue
            hint_name_rva = val & 0x7FFFFFFF
            if _read_cstr(read_at, module_base + hint_name_rva + 2) == func_name:
                return module_base + ft + idx_fn * 8
    return 0


def find_dxgi_dup_skip_range(
    read_at: Callable[[int, int], bytes],
    module_base: int,
    gmi_iat_addr: int,
    gwi_iat_addr: int,
) -> tuple[int, int]:
    """Locate the DXGI duplication `GetMonitorInfoW` call site (followed shortly by `GetWindowInfo`)."""
    if not module_base or not gmi_iat_addr or not gwi_iat_addr:
        return 0, 0
    dos = read_at(module_base, 0x40)
    if len(dos) < 0x40 or dos[:2] != b"MZ":
        return 0, 0
    (e_lfanew,) = struct.unpack_from("<I", dos, 0x3C)
    nt = read_at(module_base + e_lfanew, 24)
    if len(nt) < 24 or nt[:4] != b"PE\x00\x00":
        return 0, 0
    num_sec, = struct.unpack_from("<H", nt, 6)
    size_opt, = struct.unpack_from("<H", nt, 20)
    sec_bytes = read_at(module_base + e_lfanew + 24 + size_opt, min(num_sec, 16) * 40)
    text_rva = 0
    text_size = 0
    for i in range(min(num_sec, len(sec_bytes) // 40)):
        sec_hdr = sec_bytes[i * 40 : (i + 1) * 40]
        vsize, vrva = struct.unpack_from("<II", sec_hdr, 8)
        if sec_hdr[:5] == b".text":
            text_rva, text_size = vrva, min(vsize, _MAX_TEXT_SCAN)
            break
    if not text_rva or text_size < 16:
        return 0, 0

    text = read_at(module_base + text_rva, text_size)
    if len(text) < 16:
        return 0, 0
    gmi_rel = gmi_iat_addr - module_base
    gwi_rel = gwi_iat_addr - module_base

    for i in range(len(text) - 6):
        if text[i] == 0xFF and text[i + 1] == 0x15:
            (disp,) = struct.unpack_from("<i", text, i + 2)
            call_rva = text_rva + i
            if call_rva + 6 + disp != gmi_rel:
                continue
            limit = min(len(text) - 6, i + 120)
            for j in range(i + 6, limit):
                if text[j] == 0xFF and text[j + 1] == 0x15:
                    (d2,) = struct.unpack_from("<i", text, j + 2)
                    if (text_rva + j + 6 + d2) == gwi_rel:
                        return call_rva, call_rva + 12
    return 0, 0


def find_remote_module(pid: int, module_name: str) -> tuple[int, int]:
    """Return `(base_addr, image_size)` of `module_name` inside `pid`, or `(0, 0)`."""
    if not _IS_WIN or _kernel32 is None or pid <= 0:
        return 0, 0
    snap = _kernel32.CreateToolhelp32Snapshot(_TH32CS_SNAPMODULE | _TH32CS_SNAPMODULE32, int(pid))
    if not snap or snap == _INVALID_HANDLE:
        return 0, 0
    target = module_name.lower()
    try:
        me = _MODULEENTRY32W()
        me.dwSize = ctypes.sizeof(_MODULEENTRY32W)
        if not _kernel32.Module32FirstW(snap, ctypes.byref(me)):
            return 0, 0
        while True:
            if str(me.szModule or "").lower() == target:
                base = int(me.modBaseAddr or 0)
                return base, int(me.modBaseSize or 0)
            if not _kernel32.Module32NextW(snap, ctypes.byref(me)):
                break
    except Exception:
        logger.debug(f"{TAG} Module enumeration failed for pid={pid}", exc_info=True)
    finally:
        _kernel32.CloseHandle(snap)
    return 0, 0


def resolve_remote_user32_funcs(pid: int) -> tuple[int, int, int]:
    """Resolve `(GetMonitorInfoW, GetForegroundWindow, GetWindowRect)` addresses inside `pid`."""
    if not _IS_WIN or _kernel32 is None:
        return 0, 0, 0
    local_u32 = int(_kernel32.GetModuleHandleW("user32.dll") or 0)
    if not local_u32:
        return 0, 0, 0
    fn_gmi = int(_kernel32.GetProcAddress(local_u32, b"GetMonitorInfoW") or 0)
    fn_fg = int(_kernel32.GetProcAddress(local_u32, b"GetForegroundWindow") or 0)
    fn_rect = int(_kernel32.GetProcAddress(local_u32, b"GetWindowRect") or 0)
    if not (fn_gmi and fn_fg and fn_rect):
        return 0, 0, 0
    rem_u32, _ = find_remote_module(pid, "user32.dll")
    delta = (rem_u32 - local_u32) if rem_u32 else 0
    return fn_gmi + delta, fn_fg + delta, fn_rect + delta


def is_lossless_overlay_spanning(bounds: win32.SpanBounds, tolerance: int = 32) -> bool:
    """Return True while Lossless Scaling's output overlay window is visible across `bounds`."""
    if not _IS_WIN or _user32 is None or bounds.width <= 0 or bounds.height <= 0:
        return False
    try:
        hwnd = int(_user32.FindWindowW("LosslessScaling", None) or 0)
        if not hwnd or not _user32.IsWindowVisible(hwnd):
            return False
        rc = win32.get_window_rect(hwnd)
        if rc is None:
            return False
        return (
            abs(rc.width - bounds.width) <= tolerance
            and abs(rc.height - bounds.height) <= tolerance
        )
    except Exception:
        return False


def _read_remote(hproc: int, addr: int, size: int) -> bytes:
    buf = (ctypes.c_ubyte * size)()
    n_read = ctypes.c_size_t(0)
    if not _kernel32.ReadProcessMemory(hproc, ctypes.c_void_p(addr), buf, size, ctypes.byref(n_read)):
        return b""
    return bytes(buf[: n_read.value])


def _write_remote(hproc: int, addr: int, data: bytes) -> bool:
    buf = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    n_written = ctypes.c_size_t(0)
    return bool(
        _kernel32.WriteProcessMemory(hproc, ctypes.c_void_p(addr), buf, len(data), ctypes.byref(n_written))
    ) and int(n_written.value) == len(data)


def _patch_qword_ro(hproc: int, addr: int, value: int) -> bool:
    old_prot = wintypes.DWORD(0)
    if not _kernel32.VirtualProtectEx(hproc, ctypes.c_void_p(addr), 8, _PAGE_READWRITE, ctypes.byref(old_prot)):
        return False
    try:
        return _write_remote(hproc, addr, struct.pack("<Q", value))
    finally:
        tmp = wintypes.DWORD(0)
        _kernel32.VirtualProtectEx(hproc, ctypes.c_void_p(addr), 8, old_prot.value, ctypes.byref(tmp))


class LosslessSpanHookManager:
    """Manages W^X IAT hooks on running `LosslessScaling.exe` instances for multi-monitor output."""

    def __init__(self, allow_in_tests: bool = False):
        self._allow_in_tests = allow_in_tests
        self._lock = threading.RLock()
        self._hooked: dict[int, _HookState] = {}
        self._failed_pids: set[int] = set()

    def _disabled(self) -> bool:
        if not _IS_WIN or _kernel32 is None:
            return True
        if not self._allow_in_tests and os.environ.get("BOBGAMING_TRIPLESCREEN_DISABLE") == "1":
            return True
        return False

    def sync(
        self,
        procs: list[win32.RunningProcess] | None,
        bounds: win32.SpanBounds | None,
        enabled: bool,
        tracked_hwnd: int = 0,
    ) -> bool:
        """Install/update hooks while active, or restore original IAT pointers when disabled/idle."""
        if self._disabled():
            return False

        if not enabled or bounds is None or bounds.width <= 0 or bounds.height <= 0:
            self.unhook_all()
            return False

        proc_list = win32.list_running_processes() if procs is None else procs
        ls_pids = {p.pid for p in proc_list if p.exe_name == "losslessscaling.exe" and p.pid > 0}

        with self._lock:
            for dead in set(self._hooked) - ls_pids:
                self._hooked.pop(dead, None)
            self._failed_pids.intersection_update(ls_pids)

            any_ok = False
            for pid in sorted(ls_pids):
                if pid in self._hooked:
                    if self._update_hook(pid, bounds, tracked_hwnd):
                        any_ok = True
                elif pid not in self._failed_pids:
                    if self._install_hook(pid, bounds, tracked_hwnd):
                        any_ok = True
            return any_ok

    def unhook_all(self) -> None:
        """Disable all installed hooks and restore original `GetMonitorInfoW` IAT pointers."""
        if _kernel32 is None or not _IS_WIN:
            return
        with self._lock:
            items = list(self._hooked.items())
            self._hooked.clear()
        for pid, st in items:
            hproc = _kernel32.OpenProcess(_PROCESS_HOOK_ACCESS, False, int(pid))
            if not hproc:
                continue
            try:
                _write_remote(hproc, st.data_addr + _OFFSET_ENABLED, struct.pack("<i", 0))
                cur_bytes = _read_remote(hproc, st.iat_addr, 8)
                if len(cur_bytes) == 8 and struct.unpack("<Q", cur_bytes)[0] == st.hook_entry:
                    _patch_qword_ro(hproc, st.iat_addr, st.orig_fn)
                logger.info(f"{TAG} Restored LosslessScaling.exe (PID={pid})")
            except Exception:
                logger.warning(f"{TAG} Failed restoring LosslessScaling.exe (PID={pid})", exc_info=True)
            finally:
                _kernel32.CloseHandle(hproc)

    def _update_hook(self, pid: int, bounds: win32.SpanBounds, tracked_hwnd: int) -> bool:
        st = self._hooked.get(pid)
        if st is None:
            return False
        hproc = _kernel32.OpenProcess(_PROCESS_HOOK_ACCESS, False, int(pid))
        if not hproc:
            self._hooked.pop(pid, None)
            return False
        try:
            trig_bytes = _read_remote(hproc, st.data_addr + _OFFSET_TRIGGER_COUNT, 4)
            if len(trig_bytes) != 4:
                self._hooked.pop(pid, None)
                return False
            (trig,) = struct.unpack("<I", trig_bytes)
            if trig > st.last_trigger_count:
                st.last_trigger_count = trig
                logger.info(
                    f"{TAG} LosslessScaling.exe (PID={pid}) scaled across multi-monitor span "
                    f"({bounds.x}, {bounds.y}, {bounds.width}, {bounds.height}) (triggers={trig})"
                )

            want_hwnd = int(tracked_hwnd or 0)
            if st.bounds != bounds or st.tracked_hwnd != want_hwnd or not st.enabled:
                tail = _STATE_TAIL_STRUCT.pack(
                    want_hwnd,
                    1,
                    bounds.x,
                    bounds.y,
                    bounds.x + bounds.width,
                    bounds.y + bounds.height,
                )
                if not _write_remote(hproc, st.data_addr + _OFFSET_TRACKED_HWND, tail):
                    self._hooked.pop(pid, None)
                    return False
                st.bounds = bounds
                st.tracked_hwnd = want_hwnd
                st.enabled = True
            return True
        finally:
            _kernel32.CloseHandle(hproc)

    def _install_hook(self, pid: int, bounds: win32.SpanBounds, tracked_hwnd: int) -> bool:
        t0 = time.monotonic()
        dll_base, _mod_size = find_remote_module(pid, "Lossless.dll")
        if not dll_base:
            return False

        hproc = _kernel32.OpenProcess(_PROCESS_HOOK_ACCESS, False, int(pid))
        if not hproc:
            err = ctypes.get_last_error()
            self._failed_pids.add(pid)
            logger.warning(f"{TAG} Cannot open LosslessScaling.exe PID={pid} (win32_error={err})")
            return False

        alloc_pages: list[int] = []
        try:
            read_at = lambda a, n: _read_remote(hproc, a, n)
            iat_addr = find_iat_slot(read_at, dll_base, "USER32.dll", "GetMonitorInfoW")
            if not iat_addr:
                self._failed_pids.add(pid)
                logger.warning(f"{TAG} GetMonitorInfoW IAT slot not found in Lossless.dll (PID={pid})")
                return False

            iat_bytes = _read_remote(hproc, iat_addr, 8)
            if len(iat_bytes) != 8:
                self._failed_pids.add(pid)
                return False
            (cur_iat,) = struct.unpack("<Q", iat_bytes)
            if not cur_iat:
                return False

            want_hwnd = int(tracked_hwnd or 0)
            right = bounds.x + bounds.width
            bottom = bounds.y + bounds.height

            # Re-attach cleanly if an earlier Bob session already hooked this process
            hdr = _read_remote(hproc, cur_iat - _CODE_ENTRY_OFFSET, 16) if cur_iat > 0x10000 else b""
            if len(hdr) == 16:
                magic, existing_data = struct.unpack("<QQ", hdr)
                if magic == HOOK_MAGIC and existing_data > 0x10000:
                    orig_b = _read_remote(hproc, existing_data + 8, 8)
                    trig_b = _read_remote(hproc, existing_data + _OFFSET_TRIGGER_COUNT, 4)
                    if len(orig_b) == 8 and len(trig_b) == 4:
                        (orig_fn,) = struct.unpack("<Q", orig_b)
                        (trig,) = struct.unpack("<I", trig_b)
                        tail = _STATE_TAIL_STRUCT.pack(want_hwnd, 1, bounds.x, bounds.y, right, bottom)
                        if _write_remote(hproc, existing_data + _OFFSET_TRACKED_HWND, tail):
                            self._hooked[pid] = _HookState(
                                pid=pid,
                                dll_base=dll_base,
                                iat_addr=iat_addr,
                                orig_fn=orig_fn,
                                data_addr=existing_data,
                                code_page=cur_iat - _CODE_ENTRY_OFFSET,
                                hook_entry=cur_iat,
                                bounds=bounds,
                                tracked_hwnd=want_hwnd,
                                enabled=True,
                                last_trigger_count=trig,
                            )
                            logger.info(
                                f"{TAG} Re-attached hook on LosslessScaling.exe (PID={pid}, iat=0x{iat_addr:X}) "
                                f"in {time.monotonic() - t0:.3f}s"
                            )
                            return True

            fn_gmi, fn_fg, fn_rect = resolve_remote_user32_funcs(pid)
            if not (fn_fg and fn_rect):
                self._failed_pids.add(pid)
                logger.warning(f"{TAG} Failed resolving user32 functions for PID={pid}")
                return False
            orig_fn = cur_iat or fn_gmi

            gwi_iat = find_iat_slot(read_at, dll_base, "USER32.dll", "GetWindowInfo")
            skip_lo, skip_hi = find_dxgi_dup_skip_range(read_at, dll_base, iat_addr, gwi_iat)

            data_page = int(
                _kernel32.VirtualAllocEx(hproc, None, _PAGE_SIZE, _MEM_COMMIT | _MEM_RESERVE, _PAGE_READWRITE) or 0
            )
            if data_page:
                alloc_pages.append(data_page)
            code_page = int(
                _kernel32.VirtualAllocEx(hproc, None, _PAGE_SIZE, _MEM_COMMIT | _MEM_RESERVE, _PAGE_READWRITE) or 0
            )
            if code_page:
                alloc_pages.append(code_page)
            if not (data_page and code_page):
                self._failed_pids.add(pid)
                logger.warning(f"{TAG} VirtualAllocEx failed for PID={pid} (win32_error={ctypes.get_last_error()})")
                return False

            data_blob = _DATA_STRUCT.pack(
                HOOK_MAGIC, orig_fn, fn_fg, fn_rect, dll_base, skip_lo, skip_hi,
                want_hwnd, 1, bounds.x, bounds.y, right, bottom, 0,
            )
            code_blob = build_hook_code_page(data_page)
            if not _write_remote(hproc, data_page, data_blob) or not _write_remote(hproc, code_page, code_blob):
                self._failed_pids.add(pid)
                return False
            _kernel32.FlushInstructionCache(hproc, ctypes.c_void_p(code_page), len(code_blob))

            old_code_prot = wintypes.DWORD(0)
            if not _kernel32.VirtualProtectEx(
                hproc, ctypes.c_void_p(code_page), _PAGE_SIZE, _PAGE_EXECUTE_READ, ctypes.byref(old_code_prot)
            ):
                self._failed_pids.add(pid)
                return False

            hook_entry = code_page + _CODE_ENTRY_OFFSET
            if not _patch_qword_ro(hproc, iat_addr, hook_entry):
                self._failed_pids.add(pid)
                logger.warning(f"{TAG} Failed patching GetMonitorInfoW IAT for PID={pid}")
                return False

            alloc_pages.clear()
            self._hooked[pid] = _HookState(
                pid=pid,
                dll_base=dll_base,
                iat_addr=iat_addr,
                orig_fn=orig_fn,
                data_addr=data_page,
                code_page=code_page,
                hook_entry=hook_entry,
                bounds=bounds,
                tracked_hwnd=want_hwnd,
                enabled=True,
                last_trigger_count=0,
            )
            logger.info(
                f"{TAG} Hooked LosslessScaling.exe (PID={pid}, iat=0x{iat_addr:X}, "
                f"span=({bounds.x}, {bounds.y}, {bounds.width}, {bounds.height}), "
                f"skip=0x{skip_lo:X}..0x{skip_hi:X}) in {time.monotonic() - t0:.3f}s"
            )
            return True
        except Exception:
            self._failed_pids.add(pid)
            logger.exception(f"{TAG} Unexpected error hooking LosslessScaling.exe PID={pid}")
            return False
        finally:
            for page in alloc_pages:
                _kernel32.VirtualFreeEx(hproc, ctypes.c_void_p(page), 0, _MEM_RELEASE)
            _kernel32.CloseHandle(hproc)
