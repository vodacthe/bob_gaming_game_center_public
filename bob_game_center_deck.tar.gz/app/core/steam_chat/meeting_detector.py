"""Detect active online meetings and screen sharing on Windows.

Runs snapshots off the GUI thread via `MeetingMonitor` (`QThread`) and emits `state_changed(bool, str)`
only on transitions. Gaming / streaming tools (`Discord.exe`, `Steam.exe`, `OBS`, `LosslessScaling.exe`,
game `.exe`s) are excluded so co-op voice chat never hides the overlay while playing.
"""

from __future__ import annotations

import logging
import os
import re
import sys
import threading
import time
from dataclasses import dataclass

from PySide6.QtCore import QCoreApplication, QThread, Signal

logger = logging.getLogger(__name__)
TAG = "[SteamChat/Meeting]"

QUNS_PRESENTATION_MODE = 4

_ACTIVE_CALL_PROCESSES = frozenset({
    "cpthost.exe",
    "airhost.exe",
    "atmgr.exe",
    "g2mcomm.exe",
    "g2mlauncher.exe",
    "bluejeanshelper.exe",
})

_BROWSER_EXES = frozenset({
    "chrome.exe",
    "msedge.exe",
    "firefox.exe",
    "brave.exe",
    "coccoc.exe",
    "browser.exe",
    "opera.exe",
    "vivaldi.exe",
    "arc.exe",
    "zen.exe",
    "waterfox.exe",
})

_MEETING_APP_EXES = frozenset({
    "zoom.exe",
    "zhumu.exe",
    "cpthost.exe",
    "ms-teams.exe",
    "teams.exe",
    "msteams.exe",
    "zalocall.exe",
    "zalo.exe",
    "viber.exe",
    "slack.exe",
    "skype.exe",
    "skypeapp.exe",
    "webexmta.exe",
    "webexhost.exe",
    "ptoneclk.exe",
    "atmgr.exe",
    "ciscowebexstart.exe",
    "lark.exe",
    "feishu.exe",
    "dingtalk.exe",
    "weixin.exe",
    "wechat.exe",
    "gotomeeting.exe",
    "g2mcomm.exe",
    "bluejeans.exe",
    "ringcentral.exe",
    "chime.exe",
    "gather.exe",
})

_MEETING_OR_BROWSER_EXES = _MEETING_APP_EXES | _BROWSER_EXES

# Explicitly never treated as a work/online meeting (co-op gaming voice, game overlays, upscalers, OS shells).
_EXCLUDED_EXES = frozenset({
    "discord.exe",
    "discordptb.exe",
    "discordcanary.exe",
    "steam.exe",
    "steamwebhelper.exe",
    "gameoverlayui.exe",
    "obs64.exe",
    "obs32.exe",
    "losslessscaling.exe",
    "bobgaminggamecenter.exe",
    "gamebar.exe",
    "gamebarftserver.exe",
    "nvidia share.exe",
    "nvidia overlay.exe",
    "nvcontainer.exe",
    "amddvr.exe",
    "radeonsoftware.exe",
    "snippingtool.exe",
    "screensketch.exe",
    "svchost.exe",
    "explorer.exe",
    "lghub_agent.exe",
    "logioptionsplus.exe",
    "logioptionsplus_agent.exe",
})

# Subfolder tokens for helper binaries (e.g. Viber\QtWebEngineProcess.exe, Zalo\...\ZaloCall.exe).
_MEETING_PATH_TOKENS = (
    "#zoom#",
    "#zalo#",
    "#viber#",
    "#teams#",
    "#msteams#",
    "#slack#",
    "#webex#",
    "#skype#",
    "#lark#",
    "#feishu#",
    "#dingtalk#",
    "#weixin#",
    "#wechat#",
)

# UWP / MSIX ConsentStore package prefix -> candidate host executables in snapshot.processes.
_PACKAGE_PROCESS_MAP: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("msteams", ("ms-teams.exe", "teams.exe", "msteams.exe")),
    ("microsoft.microsoftteams", ("ms-teams.exe", "teams.exe", "msteams.exe")),
    ("zoom", ("zoom.exe", "cpthost.exe")),
    ("microsoft.skypeapp", ("skype.exe", "skypeapp.exe")),
    ("skype", ("skype.exe", "skypeapp.exe")),
    ("ciscowebex", ("atmgr.exe", "webexhost.exe", "ptoneclk.exe", "ciscowebexstart.exe")),
    ("webex", ("atmgr.exe", "webexhost.exe", "ptoneclk.exe", "ciscowebexstart.exe")),
    ("slack", ("slack.exe",)),
    ("viber", ("viber.exe", "qtwebengineprocess.exe")),
)

_WINDOW_INSPECT_EXES = _BROWSER_EXES | frozenset({
    "zalocall.exe",
    "zoom.exe",
    "zhumu.exe",
    "ms-teams.exe",
    "teams.exe",
    "msteams.exe",
    "slack.exe",
    "powerpnt.exe",
    "wpp.exe",
})

_BROWSER_SHARE_PHRASES = (
    "is sharing your screen",
    "is sharing a window",
    "is sharing a tab",
    "đang chia sẻ màn hình",
    "đang chia sẻ một cửa sổ",
    "đang chia sẻ cửa sổ",
    "đang chia sẻ một thẻ",
    "đang chia sẻ thẻ",
    "sharing indicator",
    "trình chỉ báo chia sẻ",
)

# Active Google Meet room title: "Meet - abc-defg-hij" (landing page "Google Meet" does not match).
_GOOGLE_MEET_TITLE_RE = re.compile(r"\bMeet\s*[-–—]\s*[a-z]{3}-[a-z]{4}-[a-z]{3}\b")

_ZOOM_MEETING_CLASSES = frozenset({
    "zpcontentviewwndclass",
    "confmultitabcontentwndclass",
    "zpfloattoolbarclass",
    "zpftewndclass",
    "zpsharebarwndclass",
    "zpbannerwndclass",
})

_ZOOM_MEETING_TITLES = (
    "zoom meeting",
    "zoom cuộc họp",
    "zoom webinar",
)

_TEAMS_SHARE_TITLES = (
    "sharing control bar",
    "thanh điều khiển chia sẻ",
    "screen sharing",
    "meeting compact view",
)

_CONSENT_BASE = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore"


@dataclass(frozen=True)
class WindowEntry:
    hwnd: int
    pid: int
    exe: str
    cls: str = ""
    title: str = ""
    iconic: bool = False
    topmost: bool = False


@dataclass(frozen=True)
class SystemSnapshot:
    processes: frozenset[str] = frozenset()
    windows: tuple[WindowEntry, ...] = ()
    active_webcam: tuple[str, ...] = ()
    active_mic: tuple[str, ...] = ()
    active_capture: tuple[str, ...] = ()
    notification_state: int = 0


def _match_capability(entries: tuple[str, ...], processes: frozenset[str]) -> str:
    """Return matched running app/exe name from active ConsentStore entries, or '' if none qualify."""
    if not entries or not processes:
        return ""
    for raw in entries:
        key = raw.strip().lower().replace("\\", "#")
        if not key:
            continue
        if key.endswith(".exe"):
            exe = key.rsplit("#", 1)[-1]
            if exe in _EXCLUDED_EXES or exe not in processes:
                continue
            if exe in _MEETING_OR_BROWSER_EXES:
                return exe
            if any(tok in key for tok in _MEETING_PATH_TOKENS):
                return exe
        else:
            for prefix, candidate_exes in _PACKAGE_PROCESS_MAP:
                if key.startswith(prefix):
                    running = next((c for c in candidate_exes if c in processes), "")
                    if running:
                        return running
    return ""


def detect_meeting_activity(snapshot: SystemSnapshot) -> str:
    """Evaluate `snapshot` and return a concise reason string when a meeting/screen-share is active, else ''."""
    for proc in _ACTIVE_CALL_PROCESSES:
        if proc in snapshot.processes:
            return f"process:{proc}"

    if snapshot.notification_state == QUNS_PRESENTATION_MODE:
        return "presentation_mode"

    for w in snapshot.windows:
        exe = w.exe.lower()
        if not exe or exe in _EXCLUDED_EXES:
            continue
        cls = w.cls.lower()
        title_low = w.title.lower()

        if exe in ("powerpnt.exe", "wpp.exe") and cls == "screenclass" and not w.iconic:
            return f"window:slideshow:{exe}"

        if exe in _BROWSER_EXES:
            if w.topmost and not w.iconic and any(p in title_low for p in _BROWSER_SHARE_PHRASES):
                return f"window:browser_share:{exe}"
            if _GOOGLE_MEET_TITLE_RE.search(w.title):
                return f"window:google_meet:{exe}"

        elif exe in ("zoom.exe", "zhumu.exe"):
            if cls in _ZOOM_MEETING_CLASSES or any(p in title_low for p in _ZOOM_MEETING_TITLES):
                return "window:zoom_meeting"

        elif exe in ("ms-teams.exe", "teams.exe", "msteams.exe") and not w.iconic:
            if any(p in title_low for p in _TEAMS_SHARE_TITLES):
                return f"window:teams_share:{exe}"

        elif exe == "slack.exe" and not w.iconic:
            if "slack | huddle" in title_low or "slack - huddle" in title_low or (
                w.topmost and "is sharing your screen" in title_low
            ):
                return "window:slack_huddle"

        elif exe == "zalocall.exe" and w.title.strip():
            return "window:zalo_call"

    for kind, items in (
        ("capture", snapshot.active_capture),
        ("webcam", snapshot.active_webcam),
        ("mic", snapshot.active_mic),
    ):
        matched = _match_capability(items, snapshot.processes)
        if matched:
            return f"{kind}:{matched}"

    return ""


# ---- Win32 / Registry snapshot collection (runs off UI thread) -----------------------------------

_IS_WIN = sys.platform == "win32"

if _IS_WIN:
    import ctypes
    import winreg
    from ctypes import wintypes

    _TH32CS_SNAPPROCESS = 0x00000002
    _INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
    _GWL_EXSTYLE = -20
    _WS_EX_TOPMOST = 0x00000008

    class _PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.c_size_t),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", wintypes.LONG),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", wintypes.WCHAR * 260),
        ]

    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    _kernel32.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
    _kernel32.Process32FirstW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_PROCESSENTRY32W)]
    _kernel32.Process32FirstW.restype = wintypes.BOOL
    _kernel32.Process32NextW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_PROCESSENTRY32W)]
    _kernel32.Process32NextW.restype = wintypes.BOOL
    _kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    _kernel32.CloseHandle.restype = wintypes.BOOL

    _WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    _user32 = ctypes.WinDLL("user32", use_last_error=True)
    _user32.EnumWindows.argtypes = [_WNDENUMPROC, wintypes.LPARAM]
    _user32.EnumWindows.restype = wintypes.BOOL
    _user32.IsWindowVisible.argtypes = [wintypes.HWND]
    _user32.IsWindowVisible.restype = wintypes.BOOL
    _user32.IsIconic.argtypes = [wintypes.HWND]
    _user32.IsIconic.restype = wintypes.BOOL
    _user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    _user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    _user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    _user32.GetClassNameW.restype = ctypes.c_int
    _user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    _user32.GetWindowTextW.restype = ctypes.c_int
    _user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
    _user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t

    _shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    _shell32.SHQueryUserNotificationState.argtypes = [ctypes.POINTER(ctypes.c_int)]
    _shell32.SHQueryUserNotificationState.restype = ctypes.c_long


def _snapshot_processes() -> dict[int, str]:
    if not _IS_WIN:
        return {}
    snap = _kernel32.CreateToolhelp32Snapshot(_TH32CS_SNAPPROCESS, 0)
    if not snap or snap == _INVALID_HANDLE_VALUE:
        return {}
    out: dict[int, str] = {}
    try:
        entry = _PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(_PROCESSENTRY32W)
        if _kernel32.Process32FirstW(snap, ctypes.byref(entry)):
            out[int(entry.th32ProcessID)] = entry.szExeFile.lower()
            while _kernel32.Process32NextW(snap, ctypes.byref(entry)):
                out[int(entry.th32ProcessID)] = entry.szExeFile.lower()
    finally:
        _kernel32.CloseHandle(snap)
    return out


def _snapshot_windows(pid_to_exe: dict[int, str]) -> tuple[WindowEntry, ...]:
    if not _IS_WIN or not pid_to_exe:
        return ()
    own_pid = os.getpid()
    found: list[WindowEntry] = []
    cls_buf = ctypes.create_unicode_buffer(256)
    title_buf = ctypes.create_unicode_buffer(512)

    def _cb(hwnd, _lparam) -> bool:
        try:
            if not _user32.IsWindowVisible(hwnd):
                return True
            pid = wintypes.DWORD()
            _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            pid_val = int(pid.value)
            if pid_val == own_pid:
                return True
            exe = pid_to_exe.get(pid_val, "")
            if exe not in _WINDOW_INSPECT_EXES:
                return True
            cls_buf[0] = "\0"
            title_buf[0] = "\0"
            _user32.GetClassNameW(hwnd, cls_buf, 256)
            _user32.GetWindowTextW(hwnd, title_buf, 512)
            ex_style = _user32.GetWindowLongPtrW(hwnd, _GWL_EXSTYLE)
            found.append(
                WindowEntry(
                    hwnd=int(hwnd),
                    pid=pid_val,
                    exe=exe,
                    cls=cls_buf.value,
                    title=title_buf.value,
                    iconic=bool(_user32.IsIconic(hwnd)),
                    topmost=bool(ex_style & _WS_EX_TOPMOST),
                )
            )
        except Exception:
            pass
        return True

    proc = _WNDENUMPROC(_cb)
    _user32.EnumWindows(proc, 0)
    return tuple(found)


def _is_key_currently_active(subkey) -> bool:
    try:
        start, _ = winreg.QueryValueEx(subkey, "LastUsedTimeStart")
        stop, _ = winreg.QueryValueEx(subkey, "LastUsedTimeStop")
        return int(start) > 0 and int(stop) == 0
    except OSError:
        return False


def _snapshot_consent_capability(capability: str) -> tuple[str, ...]:
    if not _IS_WIN:
        return ()
    active: list[str] = []
    cap_path = f"{_CONSENT_BASE}\\{capability}"
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, cap_path) as root:
            idx = 0
            while True:
                try:
                    name = winreg.EnumKey(root, idx)
                    idx += 1
                except OSError:
                    break
                if name.lower() == "nonpackaged":
                    continue
                try:
                    with winreg.OpenKey(root, name) as sub:
                        if _is_key_currently_active(sub):
                            active.append(name.lower())
                except OSError:
                    pass
    except OSError:
        return ()

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, f"{cap_path}\\NonPackaged") as non_pkg:
            idx = 0
            while True:
                try:
                    name = winreg.EnumKey(non_pkg, idx)
                    idx += 1
                except OSError:
                    break
                try:
                    with winreg.OpenKey(non_pkg, name) as sub:
                        if _is_key_currently_active(sub):
                            active.append(name.lower())
                except OSError:
                    pass
    except OSError:
        pass
    return tuple(active)


def _snapshot_notification_state() -> int:
    if not _IS_WIN:
        return 0
    state = ctypes.c_int(0)
    try:
        if _shell32.SHQueryUserNotificationState(ctypes.byref(state)) == 0:
            return int(state.value)
    except Exception:
        pass
    return 0


def collect_system_snapshot() -> SystemSnapshot:
    """Gather process, window, ConsentStore, and presentation-mode signals on Windows."""
    if not _IS_WIN:
        return SystemSnapshot()
    pid_to_exe = _snapshot_processes()
    processes = frozenset(pid_to_exe.values())
    windows = _snapshot_windows(pid_to_exe)
    capture = (
        *_snapshot_consent_capability("graphicsCaptureProgrammatic"),
        *_snapshot_consent_capability("graphicsCaptureWithoutBorder"),
    )
    webcam = _snapshot_consent_capability("webcam")
    mic = _snapshot_consent_capability("microphone")
    notif = _snapshot_notification_state()
    return SystemSnapshot(
        processes=processes,
        windows=windows,
        active_webcam=webcam,
        active_mic=mic,
        active_capture=capture,
        notification_state=notif,
    )


# ---- Background worker registry (CLAUDE.md Rule #2: unparented QThreads stopped on aboutToQuit) --

_REGISTRY_LOCK = threading.Lock()
_ACTIVE_MONITORS: set["MeetingMonitor"] = set()
_QUIT_HOOKED = False


def _stop_all_monitors() -> None:
    with _REGISTRY_LOCK:
        monitors = list(_ACTIVE_MONITORS)
    for m in monitors:
        m.stop_monitoring()


def _register_monitor(monitor: "MeetingMonitor") -> None:
    global _QUIT_HOOKED
    with _REGISTRY_LOCK:
        _ACTIVE_MONITORS.add(monitor)
        hook_needed = not _QUIT_HOOKED
        if hook_needed:
            app = QCoreApplication.instance()
            if app is not None:
                app.aboutToQuit.connect(_stop_all_monitors)
                _QUIT_HOOKED = True


def _unregister_monitor(monitor: "MeetingMonitor") -> None:
    with _REGISTRY_LOCK:
        _ACTIVE_MONITORS.discard(monitor)


class MeetingMonitor(QThread):
    """Polls meeting / screen-sharing signals off the UI thread and emits transitions only."""

    state_changed = Signal(bool, str)  # (suppressed, reason)

    def __init__(self, snapshot_fn=collect_system_snapshot, poll_seconds: float = 1.5):
        super().__init__(None)
        self.setObjectName("SteamChat-MeetingMonitor")
        self._snapshot_fn = snapshot_fn
        self._poll_seconds = max(0.05, float(poll_seconds))
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._suppressed = False
        self._reason = ""
        self._started_at = 0.0
        self._err_logged = False

    @property
    def suppressed(self) -> bool:
        with self._lock:
            return self._suppressed

    @property
    def reason(self) -> str:
        with self._lock:
            return self._reason

    def start_monitoring(self) -> None:
        if self.isRunning():
            return
        if self._snapshot_fn is collect_system_snapshot and os.environ.get("BOBGAMING_STEAMCHAT_DISABLE") == "1":
            return
        self._stop_event.clear()
        with self._lock:
            self._suppressed = False
            self._reason = ""
        self._err_logged = False
        self._started_at = time.monotonic()
        _register_monitor(self)
        self.start()
        logger.info(f"{TAG} Monitor started (interval={self._poll_seconds:.2f}s)")

    def stop_monitoring(self) -> None:
        self._stop_event.set()
        was_running = self.isRunning()
        if was_running and QThread.currentThread() is not self:
            if not self.wait(3000):
                logger.warning(f"{TAG} Monitor did not exit within 3.0s")
        _unregister_monitor(self)
        with self._lock:
            self._suppressed = False
            self._reason = ""
        if was_running:
            elapsed = max(0.0, time.monotonic() - self._started_at)
            logger.info(f"{TAG} Monitor stopped after {elapsed:.2f}s")

    def run(self) -> None:
        try:
            while not self._stop_event.is_set():
                try:
                    snapshot = self._snapshot_fn()
                    reason = detect_meeting_activity(snapshot)
                    suppressed = bool(reason)
                    self._err_logged = False
                except Exception:
                    if not self._err_logged:
                        self._err_logged = True
                        logger.exception(f"{TAG} Snapshot check failed")
                    suppressed, reason = False, ""

                changed = False
                with self._lock:
                    if suppressed != self._suppressed:
                        self._suppressed = suppressed
                        self._reason = reason
                        changed = True
                if changed:
                    logger.info(
                        f"{TAG} State changed: suppressed={suppressed}"
                        + (f" ({reason})" if reason else "")
                    )
                    self.state_changed.emit(suppressed, reason)

                self._stop_event.wait(self._poll_seconds)
        except Exception:
            logger.exception(f"{TAG} Monitor thread crashed unexpectedly")
        finally:
            _unregister_monitor(self)
