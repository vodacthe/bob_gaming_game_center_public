"""Classic Yahoo! Messenger emoticons (119 animated GIFs, Y!M 5-11 + hidden shortcuts).

Messages sent to Steam keep their plain ASCII Yahoo shortcuts (`=))`, `:))`, `>:D<`, ...);
only the local overlay renders whitespace-delimited Yahoo tokens as animated inline GIFs and
offers live shortcut / `:keyword` suggestions in the chat input bar.
"""

from __future__ import annotations

import logging
import os
import re
import time
from dataclasses import dataclass

from app.core.steam_chat.emoticons import MAX_SUGGESTIONS, EmoticonCandidate

logger = logging.getLogger(__name__)
TAG = "[SteamChat/Yahoo]"

YAHOO_SCHEME = "yahoo://"
MIN_CODE_QUERY = 2
MAX_CODE_QUERY = 12


@dataclass(frozen=True)
class YahooEmoticon:
    emo_id: str
    code: str
    aliases: tuple[str, ...]
    detail: str
    keywords: tuple[str, ...]


def _e(emo_id: str, codes: tuple[str, ...], detail: str, keywords: str) -> YahooEmoticon:
    return YahooEmoticon(
        emo_id=emo_id,
        code=codes[0],
        aliases=codes,
        detail=detail,
        keywords=tuple(k for k in keywords.split() if k),
    )


# Complete 119-emoticon classic Yahoo! Messenger set (1..79, 100..115, 120..141, pirate, transformer).
YAHOO_EMOTICONS: tuple[YahooEmoticon, ...] = (
    _e("1", (":)", ":-)"), "Cười mỉm (Happy)", "happy smile cuoi mim vui yahoo"),
    _e("2", (":(", ":-("), "Buồn (Sad)", "sad buon rau"),
    _e("3", (";)", ";-)"), "Nháy mắt (Winking)", "wink winking nhaymat nhay"),
    _e("4", (":D", ":-D"), "Cười tươi (Big grin)", "grin biggrin cuoituoi nhe"),
    _e("5", (";;)",), "Chớp mắt (Batting eyelashes)", "batting eyelashes chopmat dieu"),
    _e("6", (">:D<",), "Ôm chặt (Big hug)", "hug bighug om omchat thuong"),
    _e("7", (":-/", ":-\\"), "Bối rối (Confused)", "confused boiroi phanvan"),
    _e("8", (":x", ":-x"), "Yêu quá (Love struck)", "love heart yeu tim me"),
    _e("9", (":\">",), "Đỏ mặt ngại ngùng (Blushing)", "blush blushing shy domat ngai macco"),
    _e("10", (":P", ":-P"), "Lè lưỡi (Tongue)", "tongue bleh leluoi treu"),
    _e("11", (":-*", ":*"), "Hôn gió (Kiss)", "kiss smooch hon thom"),
    _e("12", ("=((",), "Tan nát cõi lòng (Broken heart)", "brokenheart heartbreak tannat thattinh"),
    _e("13", (":-O", ":O"), "Ngạc nhiên (Surprised)", "surprised shock wow ngacnhien ha"),
    _e("14", ("X(", "X-("), "Tức giận (Angry)", "angry mad rage tuc gian nong"),
    _e("15", (":>", ":->"), "Tự mãn (Smug)", "smug proud tuman venh"),
    _e("16", ("B-)",), "Ngầu (Cool)", "cool sunglasses ngau kinhden"),
    _e("17", (":-S",), "Lo lắng (Worried)", "worried nervous lolang so"),
    _e("18", ("#:-S",), "Hú hồn (Whew!)", "whew phew relief huhon toatmoihoi"),
    _e("19", (">:)", ">:-)"), "Ác quỷ (Devil)", "devil evil acquy gianmanh"),
    _e("20", (":((", ":-(("), "Khóc nức nở (Crying)", "cry crying sob khoc huhu"),
    _e("21", (":))", ":-))"), "Cười lớn (Laughing)", "laugh laughing haha hihi cuoilon"),
    _e("22", (":|", ":-|"), "Mặt đơ (Straight face)", "straightface neutral pokerface matdo cang"),
    _e("23", ("/:)",), "Nhướng mày (Raised eyebrows)", "eyebrow skeptical nhuongmay nghi"),
    _e("24", ("=))",), "Cười lăn lộn (ROFL)", "rofl rolling lmao cuoi cuoilan haha"),
    _e("25", ("O:-)", "0:-)", "O:)", "0:)"), "Thiên thần (Angel)", "angel innocent thienthan ngoan"),
    _e("26", (":-B",), "Mọt sách (Nerd)", "nerd geek glasses motsach can"),
    _e("27", ("=;",), "Khoan đã (Talk to the hand)", "talkhand stop hand khoan dungtay"),
    _e("28", ("I-)", "|-)"), "Buồn ngủ (Sleepy)", "sleep sleepy zzz buonngu ngu"),
    _e("29", ("8-|",), "Đảo mắt (Rolling eyes)", "rolleyes rollingeyes daomat chan"),
    _e("30", ("L-)",), "Kẻ thua cuộc (Loser)", "loser ga thuacuoc"),
    _e("31", (":-&",), "Ốm / Buồn nôn (Sick)", "sick ill nauseous om benh"),
    _e("32", (":-$",), "Suỵt bí mật (Don't tell)", "shh secret donttell suyt bimat"),
    _e("33", ("[-(",), "Giận không thèm nói (No talking)", "notalking silent hmph gian doi"),
    _e("34", (":O)",), "Chú hề (Clown)", "clown chuhe he"),
    _e("35", ("8-}",), "Ngớ ngẩn (Silly)", "silly goofy ngongan nham"),
    _e("36", ("<:-P",), "Tiệc tùng (Party)", "party celebrate tiectung chucmung"),
    _e("37", ("(:|",), "Ngáp dài (Yawn)", "yawn bored ngap met"),
    _e("38", ("=P~",), "Chảy nước miếng (Drooling)", "drool drooling hungry yummy them chaynuocmieng"),
    _e("39", (":-?",), "Suy nghĩ (Thinking)", "think thinking hmm suynghi ngam"),
    _e("40", ("#-o",), "Trời đất quên mất (D'oh)", "doh facepalm quen troioi"),
    _e("41", ("=D>",), "Vỗ tay (Applause)", "clap applause bravo votay khen"),
    _e("42", (":-SS",), "Cắn móng tay hồi hộp (Nail biting)", "nailbiting anxious scared hoihop run"),
    _e("43", ("@-)",), "Thôi miên (Hypnotized)", "hypnotized dizzy thoimien hoa"),
    _e("44", (":^o",), "Nói xạo (Liar)", "liar pinocchio noixao xao bocphet"),
    _e("45", (":-w",), "Đợi lâu quá (Waiting)", "wait waiting doi cho"),
    _e("46", (":-<",), "Thở dài (Sigh)", "sigh thodai haiz"),
    _e("47", (">:P",), "Trêu tức (Phbbbbt)", "phbbt raspberry tease treutuc"),
    _e("48", ("<):)",), "Cao bồi (Cowboy)", "cowboy caoboi"),
    _e("49", (":@)",), "Heo con (Pig)", "pig piggy heo lon"),
    _e("50", ("3:-O",), "Bò sữa (Cow)", "cow moo bo"),
    _e("51", (":(|)",), "Khỉ con (Monkey)", "monkey khi"),
    _e("52", ("~:>",), "Con gà (Chicken)", "chicken hen ga"),
    _e("53", ("@};-",), "Hoa hồng (Rose)", "rose flower hoahong hoa"),
    _e("54", ("%%-",), "Chúc may mắn (Good luck)", "goodluck clover luck mayman"),
    _e("55", ("**==",), "Lá cờ (Flag)", "flag co"),
    _e("56", ("(~~)",), "Bí ngô Halloween (Pumpkin)", "pumpkin halloween bingo"),
    _e("57", ("~O)",), "Ly cà phê (Coffee)", "coffee tea cafe caphe"),
    _e("58", ("*-:)",), "Nảy ra ý tưởng (Idea)", "idea lightbulb ytuong sangkien"),
    _e("59", ("8-X",), "Đầu lâu (Skull)", "skull danger dead daulau xuong"),
    _e("60", ("=:)",), "Con bọ (Bug)", "bug alienbug bo sau"),
    _e("61", (">-)",), "Người ngoài hành tinh (Alien)", "alien ufo nguoingoaianhtinh"),
    _e("62", (":-L",), "Bực bội (Frustrated)", "frustrated annoyed bucboi uc"),
    _e("63", ("[-O<",), "Cầu nguyện (Praying)", "pray praying please caunguyen xin vai"),
    _e("64", ("$-)",), "Mắt sáng thấy tiền (Money eyes)", "money rich dollar tien giau"),
    _e("65", (":-\"",), "Huýt sáo (Whistling)", "whistle whistling huytsao lor"),
    _e("66", ("b-(",), "Bầm dập (Beat up)", "beatup bruised punch bamdap andon"),
    _e("67", (":)>-",), "Hoà bình / Victory (Peace sign)", "peace victory v hoabinh yeah"),
    _e("68", ("[-X",), "Không được đâu (Shame on you)", "shame nono finger khongduoc cam"),
    _e("69", ("\\:D/",), "Nhảy múa ăn mừng (Dancing)", "dance dancing mung nhay nhaymua"),
    _e("70", (">:/",), "Ngon nhào vô (Bring it on)", "bringit comeon nhaovo thach"),
    _e("71", (";))",), "Cười khúc khích (Hee hee)", "heehee giggle hehe hihi khuckhich"),
    _e("72", ("o->",), "Võ sĩ Hiro (Hiro)", "hiro ninja fighter"),
    _e("73", ("o=>",), "Võ sĩ Billy (Billy)", "billy fighter"),
    _e("74", ("o-+",), "Nữ hiệp April (April)", "april fighter"),
    _e("75", ("(%)",), "Âm dương (Yin yang)", "yinyang balance amduong"),
    _e("76", (":-@",), "Nói liên thoắng (Chatterbox)", "chatterbox talkative laubau noinhieu"),
    _e("77", ("^:)^",), "Bái phục sát đất (Not worthy)", "bow notworthy respect baiphuc lay"),
    _e("78", (":-j",), "Thôi đi ông ơi (Oh go on)", "ohgoon yeahright thoidi xaoqua"),
    _e("79", ("(*)",), "Ngôi sao (Star)", "star ngoisao sao"),
    _e("100", (":)]",), "Đang nghe điện thoại (On the phone)", "phone call dienthoai alo"),
    _e("101", (":-c",), "Gọi cho mình nhé (Call me)", "callme alo goicho"),
    _e("102", ("~X(",), "Điên đầu hết cách (At wit's end)", "witsend crazy stressed diendau dauoc"),
    _e("103", (":-h",), "Vẫy tay tạm biệt (Wave)", "wave bye goodbye tambiet chao"),
    _e("104", (":-t",), "Tạm dừng nhé (Timeout)", "timeout pause tamdung ngung"),
    _e("105", ("8->",), "Mơ màng (Daydreaming)", "daydream dreamy momang mongmo"),
    _e("106", (":-??",), "Không biết nữa (I don't know)", "idk dontknow shrug khongbiet chiu"),
    _e("107", ("%-(",), "Không thèm nghe (Not listening)", "notlistening lalala bitai khongnghe"),
    _e("108", (":o3",), "Cún con (Puppy)", "puppy dog cute cun cho cuncon"),
    _e("109", ("X_X",), "Xỉu / Không dám nhìn (Don't want to see)", "dead fainted dontsee xiu chet"),
    _e("110", (":!!",), "Nhanh lên nào (Hurry up)", "hurry hurryup fast nhanh khan"),
    _e("111", ("\\m/",), "Cháy hết mình (Rock on)", "rock rockon metal chay"),
    _e("112", (":-q",), "Chê / Không thích (Thumbs down)", "thumbsdown thumbdown dislike boo che"),
    _e("113", (":-bd",), "Tuyệt vời / Like (Thumbs up)", "thumbsup thumbup like good ok tuyet chuan"),
    _e("114", ("^#(^",), "Không phải tại tôi (It wasn't me!)", "wasntme innocent khongphaitoi oan"),
    _e("115", (":bz",), "Con ong (Bee)", "bee buzz ong"),
    _e("120", ("~^o^~",), "Cổ vũ (Cheer)", "cheer hooray yay covu hoanho"),
    _e("121", ("'@^@|||",), "Chóng mặt (Dizzy)", "dizzy faint chongmat quay"),
    _e("122", ("[]---",), "Nấu ăn (Cook)", "cook chef cooking nauan bep"),
    _e("123", ("^o^||3",), "Ăn ngon lành (Eat)", "eat food hungry an com"),
    _e("124", (":-(||>",), "Đầu hàng bỏ cuộc (Give up)", "giveup surrender whiteflag dauhang bocuoc"),
    _e("125", ("'+_+",), "Lạnh cóng (Cold)", "cold freeze shivering lanh ret"),
    _e("126", (":::^^:::",), "Nóng bức (Hot)", "hot sweat nong oi"),
    _e("127", ("o|^_^|o",), "Nghe nhạc (Music)", "music headphones nghenhac nhac"),
    _e("128", (":puke!",), "Nôn mửa (Vomit)", "puke vomit oi non"),
    _e("129", ("o|\\~",), "Ca hát (Sing)", "sing singing karaoke cahat hat"),
    _e("130", ("o|:-)",), "Bắt bóng (Catch)", "catch baseball batbong"),
    _e("131", ("[]==[]",), "Tập tạ (Exercise)", "exercise gym workout tapta theduc"),
    _e("132", (":-)/\\:-)",), "Đập tay ăn mừng (High five)", "highfive daptay yeah"),
    _e("133", (":(game)",), "Chơi game (Gaming)", "game gaming gamer choigame"),
    _e("134", ("'@-@",), "Chịu thua không hiểu (Search me)", "searchme clueless khonghieu"),
    _e("135", (":->~~",), "Ma quái doạ dẫm (Spooky)", "spooky ghost scary ma doa"),
    _e("136", ("?@_@?",), "Học bài căng thẳng (Studying)", "study studying exam hoc hocbai"),
    _e("137", (":(tv)",), "Xem TV (TV)", "tv television xemtv"),
    _e("138", ("&[]",), "Hộp quà (Gift)", "gift present hopqua qua"),
    _e("139", ("%||:-{",), "Xui xẻo quá (Unlucky)", "unlucky badluck xuixeo xui den"),
    _e("140", ("%*-{",), "Đen đủi tơi tả (Down on luck)", "downonluck unlucky dendui tham"),
    _e("141", (":(fight)",), "Đánh nhau (Fight)", "fight brawl danhnhau solo pk"),
    _e("pirate", (":ar!",), "Cướp biển (Pirate)", "pirate arrr cuopbien"),
    _e("transformer", ("[..]",), "Robot biến hình (Transformer)", "transformer robot autobots bienhinh"),
)

BY_ID: dict[str, YahooEmoticon] = {e.emo_id: e for e in YAHOO_EMOTICONS}
CODE_TO_EMOTICON: dict[str, YahooEmoticon] = {}
for _emo in YAHOO_EMOTICONS:
    for _alias in _emo.aliases:
        CODE_TO_EMOTICON[_alias.lower()] = _emo

# Longest-first raw regex body so `:))` is tried before `:)` and scoped case-insensitively via (?i:...).
_ESCAPED_CODES = sorted((re.escape(c) for c in CODE_TO_EMOTICON), key=len, reverse=True)
INLINE_PATTERN = r"(?<!\S)(?i:" + "|".join(_ESCAPED_CODES) + r")(?!\S)"
NAMED_TOKEN_PATTERN = f"(?P<yahoo>{INLINE_PATTERN})"
TOKEN_RE = re.compile(INLINE_PATTERN)

_verified_dirs: set[str] = set()


def yahoo_url(emo_id: str) -> str:
    return f"{YAHOO_SCHEME}{emo_id}"


def is_yahoo_url(url: str) -> bool:
    return url.startswith(YAHOO_SCHEME)


def yahoo_id_from_url(url: str) -> str:
    return url[len(YAHOO_SCHEME):] if url.startswith(YAHOO_SCHEME) else ""


def yahoo_assets_dir() -> str:
    import app.config as config
    folder = os.path.join(config.get_app_dir(), "assets", "yahoo_emoticons")
    if folder not in _verified_dirs:
        verify_assets(folder)
    return folder


def yahoo_asset_path(emo_id: str, assets_dir: str | None = None) -> str:
    base = assets_dir if assets_dir is not None else yahoo_assets_dir()
    return os.path.join(base, f"{emo_id}.gif")


def verify_assets(assets_dir: str | None = None) -> int:
    """Check bundled GIF presence once per folder and log a summary with duration and count."""
    t0 = time.perf_counter()
    folder = assets_dir if assets_dir is not None else os.path.join(
        __import__("app.config", fromlist=["get_app_dir"]).get_app_dir(), "assets", "yahoo_emoticons"
    )
    _verified_dirs.add(folder)
    try:
        present = {entry.name for entry in os.scandir(folder) if entry.is_file()}
    except OSError as e:
        dt_ms = (time.perf_counter() - t0) * 1000
        logger.warning("%s Emoticon assets folder unavailable (%s) after %.1fms: %s", TAG, folder, dt_ms, e)
        return 0
    found = sum(1 for emo in YAHOO_EMOTICONS if f"{emo.emo_id}.gif" in present)
    missing = len(YAHOO_EMOTICONS) - found
    dt_ms = (time.perf_counter() - t0) * 1000
    if missing:
        logger.warning(
            "%s Emoticon catalog incomplete: %d/%d GIFs found (%d missing) in %s (%.1fms)",
            TAG, found, len(YAHOO_EMOTICONS), missing, folder, dt_ms,
        )
    else:
        logger.info(
            "%s Loaded Yahoo emoticon catalog: %d GIFs (%d shortcuts) in %.1fms",
            TAG, found, len(CODE_TO_EMOTICON), dt_ms,
        )
    return found


def lookup_code(token: str) -> YahooEmoticon | None:
    return CODE_TO_EMOTICON.get(token.lower())


def active_code_query(text: str, cursor: int) -> tuple[int, str] | None:
    """(start_index, typed_token) when the cursor ends a whitespace-delimited symbolic Yahoo prefix."""
    if cursor < MIN_CODE_QUERY or cursor > len(text):
        return None
    if cursor < len(text) and not text[cursor].isspace():
        return None
    before = text[:cursor]
    idx = len(before)
    while idx > 0 and not before[idx - 1].isspace():
        idx -= 1
    token = before[idx:]
    if not (MIN_CODE_QUERY <= len(token) <= MAX_CODE_QUERY):
        return None
    if token.isalnum():
        return None
    return idx, token


def suggest_by_code(query: str, limit: int = MAX_SUGGESTIONS) -> list[EmoticonCandidate]:
    """Yahoo shortcuts starting with symbolic `query` (exact match first, then shorter codes first)."""
    q = query.lower()
    if not q or q.isalnum():
        return []
    scored: list[tuple[int, int, int, str, YahooEmoticon]] = []
    for order, emo in enumerate(YAHOO_EMOTICONS):
        matched_alias = ""
        best_rank = 99
        for alias in emo.aliases:
            low = alias.lower()
            if low == q:
                matched_alias = alias
                best_rank = 0
                break
            if low.startswith(q) and best_rank > 1:
                matched_alias = alias
                best_rank = 1
        if matched_alias:
            scored.append((best_rank, len(matched_alias), order, matched_alias, emo))
    scored.sort(key=lambda item: (item[0], item[1], item[2]))
    return [
        EmoticonCandidate(
            insert=alias,
            label=alias,
            detail=emo.detail,
            emoticon=yahoo_url(emo.emo_id),
            raw=True,
        )
        for _rank, _alen, _order, alias, emo in scored[:max(0, limit)]
    ]


def suggest_by_keyword(query: str, limit: int = MAX_SUGGESTIONS) -> list[EmoticonCandidate]:
    """Yahoo emoticons matching `:query` (exact `:code` first, then keyword prefix, then substring)."""
    q = query.lower().strip()
    if len(q) < 2:
        return []
    colon_q = ":" + q
    scored: list[tuple[int, int, str, YahooEmoticon]] = []
    for order, emo in enumerate(YAHOO_EMOTICONS):
        rank = 99
        chosen = emo.code
        for alias in emo.aliases:
            low = alias.lower()
            if low == colon_q:
                rank, chosen = 0, alias
                break
            if low.startswith(colon_q) and rank > 1:
                rank, chosen = 1, alias
        if rank > 2:
            if any(kw == q for kw in emo.keywords):
                rank = 2
            elif any(kw.startswith(q) for kw in emo.keywords):
                rank = 3
            elif any(q in kw for kw in emo.keywords):
                rank = 4
        if rank < 99:
            scored.append((rank, order, chosen, emo))
    scored.sort(key=lambda item: (item[0], item[1]))
    return [
        EmoticonCandidate(
            insert=chosen,
            label=chosen,
            detail=emo.detail,
            emoticon=yahoo_url(emo.emo_id),
            raw=True,
        )
        for _rank, _order, chosen, emo in scored[:max(0, limit)]
    ]
