"""Steam Chat Overlay preferences (<CONFIG_DIR>/steam_chat.json)."""

from __future__ import annotations

import json
import logging
import os
import threading
from dataclasses import dataclass, field, fields

logger = logging.getLogger(__name__)

SETTINGS_FILENAME = "steam_chat.json"

SHOW_MODE_GAME = "game"       # only while a fullscreen / borderless window is in the foreground
SHOW_MODE_ALWAYS = "always"   # always on top of whatever is in the foreground
SHOW_MODES = (SHOW_MODE_GAME, SHOW_MODE_ALWAYS)

FILTER_ALL = "all"            # every new message pops up
FILTER_MENTIONS = "mentions"  # only messages that mention you pop up (the rest wait in the history)
DISPLAY_FILTERS = (FILTER_ALL, FILTER_MENTIONS)

SOUND_OFF = "off"
SOUND_MENTION = "mention"     # a sound when someone mentions you (or @all / @online)
SOUND_ALL = "all"             # a sound for every new message from someone else
SOUND_MODES = (SOUND_OFF, SOUND_MENTION, SOUND_ALL)


@dataclass
class ChatOverlaySettings:
    enabled: bool = False
    group_id: str = ""
    chat_id: str = ""
    group_name: str = ""             # display cache, refreshed on connect
    chat_name: str = ""
    hotkey_chat: str = "Ctrl+Return"       # open the input box (QKeySequence portable text)
    hotkey_toggle: str = "Ctrl+Shift+Return"  # show / hide the overlay
    gamepad_chat: list = field(default_factory=list)    # controller combo (GamepadMonitor input keys, e.g. "btn:4")
    gamepad_toggle: list = field(default_factory=list)
    show_mode: str = SHOW_MODE_GAME
    fade_seconds: int = 12
    max_lines: int = 8
    font_size: int = 12
    width: int = 460
    pos_x: float = 0.012             # top-left of the chat box as a fraction of the monitor
    pos_y: float = 0.50
    screen_name: str = ""            # monitor the box lives on in "always" mode (QScreen.name); "" = primary
    history_lines: int = 30          # backlog loaded on (re)connect; older ones load when scrolling up
    display_filter: str = FILTER_ALL
    sound_mode: str = SOUND_MENTION
    alert_keywords: list = field(default_factory=list)   # words that count like a mention (/alert)
    auto_copy_codes: bool = True     # copy game / lobby / OTP codes from incoming messages to the clipboard
    yahoo_emoticons: bool = True     # render animated Yahoo! Messenger emoticons and suggest shortcuts while typing
    hide_in_meetings: bool = True    # hide overlay, mute sounds & release hotkeys during meetings / screen share
    created_debug_marker: bool = False  # we created .cef-enable-remote-debugging (undo on factory reset)

    def normalized(self) -> "ChatOverlaySettings":
        self.show_mode = self.show_mode if self.show_mode in SHOW_MODES else SHOW_MODE_GAME
        self.display_filter = self.display_filter if self.display_filter in DISPLAY_FILTERS else FILTER_ALL
        self.sound_mode = self.sound_mode if self.sound_mode in SOUND_MODES else SOUND_MENTION
        from app.core.steam_chat.gametools import normalize_keywords
        self.alert_keywords = normalize_keywords(self.alert_keywords)
        self.auto_copy_codes = bool(self.auto_copy_codes)
        self.yahoo_emoticons = bool(self.yahoo_emoticons)
        self.hide_in_meetings = bool(self.hide_in_meetings)
        self.fade_seconds = min(max(int(self.fade_seconds), 3), 120)
        self.max_lines = min(max(int(self.max_lines), 1), 30)
        self.font_size = min(max(int(self.font_size), 8), 28)
        self.width = min(max(int(self.width), 240), 1200)
        self.history_lines = min(max(int(self.history_lines), 0), 100)
        self.gamepad_chat = sorted({str(k) for k in self.gamepad_chat if isinstance(k, str) and k})
        self.gamepad_toggle = sorted({str(k) for k in self.gamepad_toggle if isinstance(k, str) and k})
        self.pos_x = min(max(float(self.pos_x), 0.0), 0.95)
        self.pos_y = min(max(float(self.pos_y), 0.0), 0.95)
        return self


def default_path() -> str:
    import app.config as config   # read at call time so tests can redirect CONFIG_DIR
    return os.path.join(config.CONFIG_DIR, SETTINGS_FILENAME)


class SettingsStore:
    """Thread-safe load/save with atomic replace. Unknown keys are ignored, wrong types defaulted."""

    def __init__(self, path: str | None = None):
        self.path = path or default_path()
        self._lock = threading.RLock()
        self.data = ChatOverlaySettings()
        self.load()

    def load(self) -> ChatOverlaySettings:
        with self._lock:
            data = ChatOverlaySettings()
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                if isinstance(raw, dict):
                    for fld in fields(ChatOverlaySettings):
                        if fld.name not in raw:
                            continue
                        value, default = raw[fld.name], getattr(data, fld.name)
                        if isinstance(default, float) and isinstance(value, int) and not isinstance(value, bool):
                            value = float(value)
                        if type(value) is type(default):
                            setattr(data, fld.name, value)
            except FileNotFoundError:
                pass
            except (OSError, ValueError) as e:
                logger.warning(f"[SteamChat] Could not read settings ({e}); using defaults")
            self.data = data.normalized()
            return self.data

    def save(self) -> bool:
        with self._lock:
            self.data.normalized()
            try:
                os.makedirs(os.path.dirname(self.path), exist_ok=True)
                tmp = self.path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.data.__dict__, f, indent=2, ensure_ascii=False)
                os.replace(tmp, self.path)
                return True
            except OSError as e:
                logger.error(f"[SteamChat] Failed to save settings: {e}")
                return False

    def delete(self) -> None:
        with self._lock:
            for p in (self.path, self.path + ".tmp"):
                try:
                    os.remove(p)
                except OSError:
                    pass
            self.data = ChatOverlaySettings()
