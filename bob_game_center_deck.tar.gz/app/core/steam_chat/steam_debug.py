"""Steam client remote-debugging switch (`<Steam>/.cef-enable-remote-debugging`) and connection probing."""

from __future__ import annotations

import logging
import os
import re
import socket
import subprocess
import sys
import time

from app.core import steam_manager
from app.core.steam_chat.cdp import DEFAULT_PORT, CdpUnavailable, find_target, list_targets
from app.core.steam_chat.models import BridgeState

logger = logging.getLogger(__name__)

MARKER_NAME = ".cef-enable-remote-debugging"
TARGET_TITLE = "SharedJSContext"
_STEAM_UI_HOST = "steamloopback.host"
FALLBACK_PORTS = (27062, 27063, 38080, 48080)
_DEVTOOLS_PORT_RE = re.compile(r"--remote-debugging-port=(\d+)")
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0
_active_debug_port: int | None = None


def marker_path(steam_path: str | None = None) -> str | None:
    steam_path = steam_path or steam_manager.find_steam_path()
    return os.path.join(steam_path, MARKER_NAME) if steam_path else None


def is_debug_marker_present(steam_path: str | None = None) -> bool:
    path = marker_path(steam_path)
    return bool(path and os.path.isfile(path))


def set_debug_marker(enabled: bool, steam_path: str | None = None) -> bool:
    """Create/remove the marker file. Takes effect on the next Steam start. Returns True on success."""
    path = marker_path(steam_path)
    if not path:
        logger.warning("[SteamChat] Steam installation not found; cannot toggle remote debugging")
        return False
    try:
        if enabled:
            if not os.path.isfile(path):
                with open(path, "w", encoding="utf-8"):
                    pass
                logger.info(f"[SteamChat] Created {path}")
        elif os.path.isfile(path):
            os.remove(path)
            logger.info(f"[SteamChat] Removed {path}")
        return True
    except OSError as e:
        logger.error(f"[SteamChat] Could not {'create' if enabled else 'remove'} {path}: {e}")
        return False


def is_port_bindable(port: int = DEFAULT_PORT) -> bool:
    """True when 127.0.0.1:<port> can be bound (not excluded by Windows TCP ranges or already in use)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            if sys.platform == "win32" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            sock.bind(("127.0.0.1", port))
        return True
    except OSError:
        return False


def _is_loopback_port_listening(port: int) -> bool:
    """Fast (<0.1ms on Windows) check whether something is bound to 127.0.0.1:<port>."""
    if sys.platform == "win32" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                sock.bind(("127.0.0.1", port))
            return False
        except OSError as e:
            # 10048 (WSAEADDRINUSE) = active listener; 10013 (WSAEACCES) = excluded/reserved port range
            return getattr(e, "winerror", None) == 10048
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.1):
            return True
    except OSError:
        return False


def detect_logged_devtools_port(steam_path: str | None = None) -> int | None:
    """Return the most recent --remote-debugging-port in Steam's logs/webhelper.txt, if present."""
    steam_path = steam_path or steam_manager.find_steam_path()
    if not steam_path:
        return None
    log_path = os.path.join(steam_path, "logs", "webhelper.txt")
    if not os.path.isfile(log_path):
        return None
    try:
        with open(log_path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - 65536))
            tail = f.read().decode("utf-8", errors="replace")
    except OSError:
        return None
    matches = _DEVTOOLS_PORT_RE.findall(tail)
    if not matches:
        return None
    try:
        port = int(matches[-1])
        return port if 1 <= port <= 65535 else None
    except ValueError:
        return None


def pick_debug_port() -> int:
    """Pick DEFAULT_PORT if bindable, else the first bindable fallback port."""
    if is_port_bindable(DEFAULT_PORT):
        return DEFAULT_PORT
    logger.warning(f"[SteamChat] Port {DEFAULT_PORT} is unavailable/reserved; selecting fallback port")
    for candidate in FALLBACK_PORTS:
        if is_port_bindable(candidate):
            return candidate
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            return int(sock.getsockname()[1])
    except OSError:
        return FALLBACK_PORTS[0]


def _candidate_fallback_ports() -> list[int]:
    ports: list[int] = []
    for candidate in (_active_debug_port, detect_logged_devtools_port(), *FALLBACK_PORTS):
        if candidate and candidate != DEFAULT_PORT and candidate not in ports:
            ports.append(candidate)
    return ports


def find_steam_target(port: int = DEFAULT_PORT) -> dict | None:
    """The SharedJSContext target, or None when the port answers but is not the Steam client."""
    target = find_target(list_targets(port), TARGET_TITLE)
    if target and _STEAM_UI_HOST in str(target.get("url", "")):
        return target
    return None


def _try_find_target_on_port(port: int) -> tuple[bool, dict | None]:
    try:
        return True, find_steam_target(port)
    except CdpUnavailable:
        return False, None


def probe(port: int = DEFAULT_PORT) -> tuple[BridgeState, dict | None]:
    """Classify why we can or cannot attach. Returns (state, target-or-None); CONNECTING means attachable."""
    global _active_debug_port
    if port == DEFAULT_PORT and _active_debug_port and _active_debug_port != DEFAULT_PORT:
        if _is_loopback_port_listening(_active_debug_port):
            _, cached_target = _try_find_target_on_port(_active_debug_port)
            if cached_target is not None:
                return BridgeState.CONNECTING, cached_target

    reachable, target = _try_find_target_on_port(port)
    if target is not None:
        _active_debug_port = port
        return BridgeState.CONNECTING, target

    if port == DEFAULT_PORT:
        for fallback_port in _candidate_fallback_ports():
            if not _is_loopback_port_listening(fallback_port):
                continue
            _, fb_target = _try_find_target_on_port(fallback_port)
            if fb_target is not None:
                if _active_debug_port != fallback_port:
                    logger.info(f"[SteamChat] Found Steam CEF debugger on fallback port {fallback_port}")
                _active_debug_port = fallback_port
                return BridgeState.CONNECTING, fb_target

    if not steam_manager.is_steam_running():
        return BridgeState.STEAM_NOT_RUNNING, None
    if reachable:
        return BridgeState.PORT_CONFLICT, None
    if is_debug_marker_present():
        return BridgeState.RESTART_REQUIRED, None
    return BridgeState.DEBUG_DISABLED, None


def _has_steamwebhelper() -> bool:
    if sys.platform != "win32":
        return False
    try:
        res = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq steamwebhelper.exe", "/NH"],
            capture_output=True,
            text=True,
            timeout=5,
            creationflags=_NO_WINDOW,
        )
        return "steamwebhelper.exe" in (res.stdout or "").lower()
    except Exception:
        return False


def _wait_steamwebhelper_exit(wait_seconds: float = 5.0) -> None:
    """Wait briefly for child steamwebhelper.exe processes to exit after Steam quits, then clean up stragglers."""
    deadline = time.monotonic() + wait_seconds
    while time.monotonic() < deadline:
        if not _has_steamwebhelper():
            return
        time.sleep(0.25)
    logger.warning("[SteamChat] steamwebhelper.exe still running after Steam exit; force-terminating")
    try:
        subprocess.run(
            ["taskkill", "/F", "/IM", "steamwebhelper.exe", "/T"],
            capture_output=True,
            timeout=5,
            creationflags=_NO_WINDOW,
        )
    except Exception as e:
        logger.debug(f"[SteamChat] taskkill steamwebhelper.exe failed: {e}")


def restart_steam(timeout: int = 20, wait_ready: float = 15.0) -> bool:
    """Shut Steam down gracefully and start it again (picks up marker and fallback port if 8080 is blocked). Blocking."""
    global _active_debug_port
    t0 = time.monotonic()
    steam_path = steam_manager.find_steam_path()
    if not steam_path:
        return False
    if not steam_manager.close_steam(timeout=timeout, steam_path=steam_path):
        logger.warning("[SteamChat] Steam did not exit in time; not restarting")
        return False
    steam_cmd = steam_manager.get_steam_executable(steam_path)
    if not steam_cmd:
        logger.error("[SteamChat] Steam executable not found; cannot restart")
        return False

    is_win_steam = (
        sys.platform == "win32"
        and steam_cmd != "flatpak"
        and os.path.isfile(steam_cmd)
    )
    args: list[str] = []
    chosen_port = DEFAULT_PORT
    if is_win_steam:
        _wait_steamwebhelper_exit()
        chosen_port = pick_debug_port()
        if chosen_port != DEFAULT_PORT:
            args = ["-cef-enable-debugging", "-devtools-port", str(chosen_port)]
            logger.info(
                f"[SteamChat] Port {DEFAULT_PORT} unavailable; launching Steam with -devtools-port {chosen_port}"
            )
        _active_debug_port = chosen_port

    cmd = (
        ["flatpak", "run", "com.valvesoftware.Steam"]
        if steam_cmd == "flatpak"
        else [steam_cmd, *args]
    )
    try:
        from app.core.online_fix.extractor import clean_subprocess_env
        env = clean_subprocess_env()
        cwd = steam_path if os.path.isdir(steam_path) else (os.path.dirname(steam_cmd) if is_win_steam else None)

        launched = False
        if is_win_steam:
            try:
                from app.core.triple_screen import win32 as triple_win32
                if triple_win32._is_elevated():
                    launched = triple_win32._spawn_via_desktop_shell(steam_cmd, cwd or steam_path, env, args=args)
                    if launched:
                        logger.info("[SteamChat] Launched non-elevated Steam via desktop shell")
            except Exception as e:
                logger.debug(f"[SteamChat] Desktop shell launch fallback to Popen: {e}")

        if not launched:
            creationflags = (
                getattr(subprocess, "DETACHED_PROCESS", 0)
                if sys.platform == "win32"
                else 0
            )
            subprocess.Popen(
                cmd,
                cwd=cwd,
                env=env,
                close_fds=True,
                creationflags=creationflags,
            )

        if is_win_steam and wait_ready > 0:
            deadline = time.monotonic() + wait_ready
            ready_port: int | None = None
            while time.monotonic() < deadline:
                for candidate in (chosen_port, detect_logged_devtools_port(steam_path)):
                    if not candidate or not _is_loopback_port_listening(candidate):
                        continue
                    _, target = _try_find_target_on_port(candidate)
                    if target is not None:
                        ready_port = candidate
                        break
                if ready_port is not None:
                    break
                time.sleep(0.5)
            if ready_port is not None:
                _active_debug_port = ready_port
                logger.info(
                    f"[SteamChat] Steam restarted and CEF ready on port {ready_port} ({time.monotonic() - t0:.1f}s)"
                )
            else:
                logger.info(
                    f"[SteamChat] Steam restarted on port {chosen_port} (CEF still initializing after {time.monotonic() - t0:.1f}s)"
                )
        else:
            logger.info("[SteamChat] Steam restarted")
        return True
    except OSError as e:
        logger.error(f"[SteamChat] Could not start Steam ({steam_cmd}): {e}")
        return False
