"""In-game chat overlay windows.

ChatOverlayWindow  - click-through, never takes focus. Passive mode: recent lines fade out like an
                     MMO chat box. Expanded mode (while typing): dark panel with the backlog.
ChatInputBar       - small activatable bar under the box; only shown while the user types.

Two windows instead of toggling WindowTransparentForInput at runtime: changing that flag makes Qt
re-create the native window (flicker, focus loss), while showing/hiding a second window is cheap.
"""

from __future__ import annotations

import html
import re
import time
from dataclasses import dataclass, field

from PySide6.QtCore import QEvent, QPoint, QPointF, QRectF, QSizeF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QKeyEvent, QLinearGradient, QPainter, QPainterPath, QPolygonF, QTextDocument
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QLineEdit, QWidget

from app.core.steam_chat import commands as command_lib
from app.core.steam_chat import emoticons as emoticon_lib
from app.core.steam_chat import mentions as mention_lib
from app.core.steam_chat import yahoo_emoticons as yahoo_lib
from app.core.steam_chat.models import EMBED_OG, EMBED_YOUTUBE, ChatEmbed, ChatMember
from app.ui.steam_chat import win32
from app.ui.steam_chat.embeds import EmbedCache, EmbedMetadata
from app.ui.steam_chat.images import FAILED, ImageCache, default_disk_dir, emoticon_url, is_emoticon_url
from app.ui.steam_chat.keyhook import VK_BACK, VK_PACKET, KeyStroke

# no yellow/gold here: that colour is reserved for your own messages
_NAME_COLORS = ("#7dd3fc", "#a5b4fc", "#f9a8d4", "#86efac", "#fdba74",
                "#c4b5fd", "#67e8f9", "#fca5a5", "#bef264", "#5eead4")
_SELF_COLOR = "#f5d061"
_TEXT_COLOR = "#f1f5f9"
_TIME_COLOR = "#64748b"
_SYSTEM_COLOR = "#94a3b8"
_ERROR_COLOR = "#ff6b6b"
_NOTICE_COLOR = "#4ade80"           # "copied" notices
_MENTION_COLOR = "#93c5fd"          # @Name inside a message
_MENTIONED_BG = "#6d28d9"           # @Name when the line mentions you (the pill behind it turns violet too)
_MENTIONED_PILL = (76, 29, 149, 170)

_PAD = 8            # window inner padding
_HPAD = 6           # horizontal padding inside a line pill
_LINE_GAP = 3
_FADE_OUT = 1.5     # seconds of fade at the end of a line's life
_IMG_GAP = 4        # space above each image thumbnail
_IMG_MAX_W = 240    # thumbnail size on screen (Steam-like small preview)
_IMG_MAX_H = 160
_IMG_MAX_SHARE = 0.55   # a thumbnail never takes more than this share of the box height
# :steamhappy: style tokens (the bridge turns [emoticon]x[/emoticon] into :x:); unknown names stay as text
_EMOTICON = re.compile(r":([A-Za-z][\w-]{1,39}):")
_STEAM_EMO_GROUP = r"(?P<emo>:(?P<emo_name>[A-Za-z][\w-]{1,39}):)"
_BODY_EMO_AND_YAHOO = re.compile(f"{_STEAM_EMO_GROUP}|{yahoo_lib.NAMED_TOKEN_PATTERN}")
_BODY_EMO_ONLY = re.compile(_STEAM_EMO_GROUP)
_BODY_YAHOO_ONLY = re.compile(yahoo_lib.NAMED_TOKEN_PATTERN)
_TICK_MS = 80
_ANIM_MS = 40       # repaint rate while an animated sticker / GIF is on screen
_EXPANDED_LINES = 22   # the panel grows to at least this many text lines while typing (history view)
_HOLD_SECONDS = 1.5  # a new line waits this long at most for its pictures, so it never shows as text first


def name_color(account_id: int, is_self: bool = False) -> str:
    if is_self:
        return _SELF_COLOR
    return _NAME_COLORS[(account_id * 2654435761) % len(_NAME_COLORS)]


@dataclass
class OverlayLine:
    text: str
    sender: str = ""
    color: str = _SYSTEM_COLOR
    timestamp: int = 0              # unix seconds (shown in expanded mode)
    system: bool = False
    error: bool = False
    notice: bool = False            # a system line reporting something done for the user (code copied)
    images: tuple = ()              # image URLs, drawn as thumbnails under the text
    embeds: tuple = ()              # ChatEmbed cards (YouTube / Steam Store), drawn below text/images
    mentions: tuple = ()            # "@Name" texts inside `text`, drawn highlighted
    mentioned: bool = False         # the line mentions you (or everyone)
    action: bool = False            # a "/me ..." message: shown as "* Name does something"
    arrived: float = field(default_factory=time.monotonic)
    _docs: dict = field(default_factory=dict, repr=False)

    def __post_init__(self):
        if not self.system and self.sender and not self.action:
            self.action, self.text = command_lib.split_action(self.text)

    def picture_urls(self) -> list[str]:
        """Everything this line draws as a picture: attached images / stickers and :emoticon: candidates."""
        if self.system:
            return []
        return list(self.images) + [emoticon_url(name) for name in _EMOTICON.findall(self.text)]

    def _render_body(self, emoticon=None, yahoo=None) -> str:
        if self.system or (not self.mentions and emoticon is None and yahoo is None):
            return html.escape(self.text).replace("\n", "<br>")
        mention_names = sorted({n for n in self.mentions if n}, key=len, reverse=True) if self.mentions else []
        if mention_names:
            branches = ["(?P<mention>" + "|".join(re.escape(n) for n in mention_names) + ")"]
            if emoticon is not None:
                branches.append(_STEAM_EMO_GROUP)
            if yahoo is not None:
                branches.append(yahoo_lib.NAMED_TOKEN_PATTERN)
            pattern = re.compile("|".join(branches))
        elif emoticon is not None and yahoo is not None:
            pattern = _BODY_EMO_AND_YAHOO
        elif emoticon is not None:
            pattern = _BODY_EMO_ONLY
        else:
            pattern = _BODY_YAHOO_ONLY

        mention_style = (f"background-color:{_MENTIONED_BG};color:#ffffff" if self.mentioned
                         else f"color:{_MENTION_COLOR}")
        out: list[str] = []
        pos = 0
        raw = self.text
        for m in pattern.finditer(raw):
            start, end = m.span()
            if start > pos:
                out.append(html.escape(raw[pos:start]).replace("\n", "<br>"))
            gd = m.groupdict()
            if gd.get("mention") is not None:
                out.append(f'<b style="{mention_style}">{html.escape(m.group(0))}</b>')
            elif gd.get("emo") is not None:
                tag = emoticon(gd["emo_name"])
                out.append(tag if tag else html.escape(m.group(0)))
            else:
                y_emo = yahoo_lib.lookup_code(m.group(0))
                tag = yahoo(y_emo.emo_id) if y_emo is not None else None
                out.append(tag if tag else html.escape(m.group(0)))
            pos = end
        if pos < len(raw):
            out.append(html.escape(raw[pos:]).replace("\n", "<br>"))
        return "".join(out)

    def html(self, with_time: bool, emoticon=None, yahoo=None) -> str:
        """`emoticon(name)` / `yahoo(emo_id)` return an <img> tag, or None to keep the plain text token."""
        parts = []
        if with_time and self.timestamp:
            when = time.localtime(self.timestamp)
            fmt = "%H:%M" if when[:3] == time.localtime()[:3] else "%d/%m %H:%M"   # older days show the date
            parts.append(f'<span style="color:{_TIME_COLOR}">{time.strftime(fmt, when)} </span>')
        body = self._render_body(emoticon=emoticon, yahoo=yahoo)
        if self.system:
            color = _ERROR_COLOR if self.error else _NOTICE_COLOR if self.notice else _SYSTEM_COLOR
            parts.append(f'<i style="color:{color}">{body}</i>')
        elif self.action:
            parts.append(f'<i><b style="color:{self.color}">* {html.escape(self.sender)}</b>'
                         f'<span style="color:{_TEXT_COLOR}"> {body}</span></i>')
        else:
            parts.append(f'<b style="color:{self.color}">{html.escape(self.sender)}</b>'
                         + ("" if (not body and self.embeds and not self.images) else f'<span style="color:{_TEXT_COLOR}">: {body}</span>'))
        return "".join(parts)


class ChatOverlayWindow(QWidget):
    """Click-through chat box. Emits `faded_out` when passive mode has nothing left to show."""

    faded_out = Signal()
    older_requested = Signal()      # the user scrolled to the top of the history: load older messages
    size_changed = Signal()         # height changes between passive and expanded mode
    embed_clicked = Signal(object)  # ChatEmbed clicked while interactive (expanded mode)

    MAX_BACKLOG = 1000

    HISTORY_MORE = "more"
    HISTORY_LOADING = "loading"
    HISTORY_END = "end"

    def __init__(self, parent=None, images: ImageCache | None = None, embeds: EmbedCache | None = None):
        super().__init__(parent)
        self.images = images or ImageCache(self, disk_dir=default_disk_dir())
        self.images.loaded.connect(self._on_image_loaded)
        self.embeds = embeds or EmbedCache(self, disk_dir=default_disk_dir())
        self.embeds.loaded.connect(self._on_embed_loaded)
        self._embed_hits: list[tuple[QRectF, ChatEmbed]] = []
        self._hovered_embed: ChatEmbed | None = None
        self._held: list[tuple[OverlayLine, float]] = []     # new lines waiting for their pictures
        flags = (Qt.WindowType.FramelessWindowHint
                 | Qt.WindowType.Tool
                 | Qt.WindowType.WindowStaysOnTopHint
                 | Qt.WindowType.WindowDoesNotAcceptFocus
                 | Qt.WindowType.NoDropShadowWindowHint)
        # Click-through is a native style on Windows so it can be lifted while typing (mouse wheel scrolls
        # the history). Qt's WindowTransparentForInput would make Qt drop mouse events for good.
        if not win32.NATIVE_CLICK_THROUGH:
            flags |= Qt.WindowType.WindowTransparentForInput
        self.setWindowFlags(flags)
        self._interactive = False
        self._exclude_capture = False
        self._yahoo_emoticons = True
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setWindowTitle("Steam Chat Overlay")
        self.setMouseTracking(True)

        self._lines: list[OverlayLine] = []
        self._expanded = False
        self._expanded_at: float | None = None
        self._live_on_open: list[OverlayLine] = []
        self._sync_live_on_close = False
        self._scroll = 0
        self._fade_seconds = 12
        self._max_lines = 8
        self._font = QFont("Segoe UI", 12)
        self._font.setWeight(QFont.Weight.Medium)

        self._timer = QTimer(self)
        self._timer.setInterval(_TICK_MS)
        self._timer.timeout.connect(self._on_tick)
        self._drew_animated = False
        self._embed_hits.clear()
        self._at_top = False                    # last expanded paint reached the oldest loaded line
        self._history = self.HISTORY_MORE
        self._passive_h = self._expanded_h = 0
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(_ANIM_MS)
        self._anim_timer.timeout.connect(self._on_anim_tick)
        self.configure(font_size=12, width=460, max_lines=8, fade_seconds=12)

    # ---- configuration ------------------------------------------------------------------------
    def configure(self, font_size: int, width: int, max_lines: int, fade_seconds: int) -> None:
        self._font.setPointSize(font_size)
        self._max_lines = max_lines
        self._fade_seconds = fade_seconds
        line_h = QFontMetrics(self._font).lineSpacing()
        self._passive_h = int(line_h * (max_lines + 3) + 2 * _PAD)
        self._expanded_h = max(self._passive_h, int(line_h * (_EXPANDED_LINES + 1) + 2 * _PAD))
        self._apply_height(width)
        for line in self._lines:
            line._docs.clear()
        self.update()

    def _apply_height(self, width: int | None = None) -> None:
        height = self._expanded_h if self._expanded else self._passive_h
        if width is None:
            width = self.width()
        if (width, height) != (self.width(), self.height()):
            self.setFixedSize(width, height)
            self.size_changed.emit()

    @property
    def expanded(self) -> bool:
        return self._expanded

    @property
    def interactive(self) -> bool:
        return self._interactive

    def set_interactive(self, interactive: bool) -> None:
        """Receive the mouse wheel (while typing) or let every click fall through to the game."""
        self._interactive = bool(interactive)
        if not self._interactive and self._hovered_embed is not None:
            self._hovered_embed = None
            self.unsetCursor()
            self.update()
        if self.testAttribute(Qt.WidgetAttribute.WA_WState_Created):
            win32.set_click_through(int(self.winId()), not self._interactive)

    def set_exclude_from_capture(self, enabled: bool) -> None:
        self._exclude_capture = bool(enabled)
        if self.testAttribute(Qt.WidgetAttribute.WA_WState_Created):
            win32.set_exclude_from_capture(int(self.winId()), self._exclude_capture)

    def set_yahoo_emoticons(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if enabled == self._yahoo_emoticons:
            return
        self._yahoo_emoticons = enabled
        for line in self._lines:
            line._docs.clear()
        for line, _deadline in self._held:
            line._docs.clear()
        self.update()

    def showEvent(self, event):
        super().showEvent(event)
        hwnd = int(self.winId())
        win32.set_click_through(hwnd, not self._interactive)
        win32.set_exclude_from_capture(hwnd, self._exclude_capture)

    def hide(self) -> None:
        self._anim_timer.stop()
        if self.isVisible() and self.testAttribute(Qt.WidgetAttribute.WA_WState_Created):
            win32.hide_no_activate(int(self.winId()))
        super().hide()

    def nativeEvent(self, eventType, message):
        res = _filter_noactivate_native_event(eventType, message, block_cursor=not self._interactive)
        return res if res is not None else super().nativeEvent(eventType, message)

    @property
    def passive_height(self) -> int:
        return self._passive_h

    @property
    def history_state(self) -> str:
        return self._history

    # ---- content -------------------------------------------------------------------------------
    def add_line(self, line: OverlayLine, quiet: bool = False) -> None:
        """Show a new line. One with pictures is held back until they are loaded (at most _HOLD_SECONDS).

        A `quiet` line goes straight into the history without popping up (it is already faded).
        """
        urls = line.picture_urls()
        for emb in line.embeds:
            meta = self.embeds.metadata(emb)
            if meta.thumb_url:
                self.images.pixmap(meta.thumb_url)
        for url in urls:
            self.images.pixmap(url)                 # start loading
        if quiet:
            line.arrived = time.monotonic() - 3600
            self._append(line)
            return
        if self._held or not self._line_settled(line):
            self._held.append((line, time.monotonic() + _HOLD_SECONDS))
            QTimer.singleShot(int(_HOLD_SECONDS * 1000) + 50, self._release_held)
            self._ensure_ticking()
            return
        self._append(line)

    def _release_held(self) -> None:
        """Show held lines in order, as soon as the oldest one is ready or has waited long enough."""
        now = time.monotonic()
        released = False
        while self._held:
            line, deadline = self._held[0]
            if now < deadline and not self._line_settled(line):
                break
            self._held.pop(0)
            line.arrived = now
            line._docs.clear()
            self._append(line)
            released = True
        if released:
            self.update()

    def _append(self, line: OverlayLine) -> None:
        self._lines.append(line)
        del self._lines[:-self.MAX_BACKLOG]
        if self._expanded:
            self._scroll = 0
        self._ensure_ticking()
        self.update()

    def set_backlog(self, lines: list[OverlayLine]) -> None:
        """Replace everything with history; history lines never pop up in passive mode."""
        stale = time.monotonic() - 3600
        for line in lines:
            line.arrived = stale
        live = [ln for ln in self._lines if ln.system]
        self._live_on_open = [ln for ln in self._live_on_open if ln.system]
        self._lines = (lines + live)[-self.MAX_BACKLOG:]
        self._history = self.HISTORY_MORE
        for line in self._lines[-30:]:              # preload so opening the chat shows pictures at once
            for emb in line.embeds:
                meta = self.embeds.metadata(emb)
                if meta.thumb_url:
                    self.images.pixmap(meta.thumb_url)
            for url in line.picture_urls():
                self.images.pixmap(url)
        self._scroll = 0
        self.update()

    def prepend_history(self, lines: list[OverlayLine], more: bool) -> None:
        """Older messages loaded from Steam go above the backlog; the view stays where it was."""
        room = self.MAX_BACKLOG - len(self._lines)
        lines = lines[-room:] if room > 0 else []
        stale = time.monotonic() - 3600
        for line in lines:
            line.arrived = stale
        self._lines = lines + self._lines
        self._history = self.HISTORY_MORE if more and room > len(lines) else self.HISTORY_END
        self.update()

    def history_unavailable(self) -> None:
        """Older messages could not be loaded (not connected): stop asking until the next backlog."""
        self._history = self.HISTORY_END
        self.update()

    def _request_older(self) -> None:
        if self._expanded and self._history == self.HISTORY_MORE:
            self._history = self.HISTORY_LOADING
            self.update()
            self.older_requested.emit()

    def clear(self) -> None:
        self._lines.clear()
        self._held.clear()
        self._live_on_open.clear()
        if self._expanded:
            self._expanded_at = time.monotonic()
            self._sync_live_on_close = False
        self._embed_hits.clear()
        self._hovered_embed = None
        self._history = self.HISTORY_MORE
        self._scroll = 0
        self.update()

    def keep_live_together(self) -> None:
        """Keep messages that were visible when typing started (or arrived while typing) on the new reply's fade timer."""
        if self._expanded:
            self._sync_live_on_close = True

    def set_expanded(self, expanded: bool) -> None:
        was_expanded = self._expanded
        self._expanded = bool(expanded)
        self._scroll = 0
        self._at_top = False
        self._apply_height()
        now = time.monotonic()
        if self._expanded and not was_expanded:
            self._expanded_at = now
            self._sync_live_on_close = False
            self._live_on_open = [
                line for line in self._lines[-self._max_lines:]
                if now - line.arrived < self._fade_seconds
            ]
        elif not self._expanded and was_expanded:
            opened_at = self._expanded_at
            live_ids = {id(line) for line in self._live_on_open}
            if self._sync_live_on_close:
                for line in self._lines[-self._max_lines:]:
                    if id(line) in live_ids or (opened_at is not None and line.arrived >= opened_at):
                        line.arrived = now
            else:
                paused = max(0.0, now - opened_at) if opened_at is not None else 0.0
                for line in self._lines[-self._max_lines:]:
                    if id(line) in live_ids:
                        line.arrived += paused
                    elif opened_at is not None and line.arrived >= opened_at:
                        line.arrived = now
            self._expanded_at = None
            self._live_on_open = []
            self._sync_live_on_close = False
        self._ensure_ticking()
        self.update()

    def scroll_by(self, lines: int) -> None:
        if not self._expanded:
            return
        if lines > 0 and self._at_top:
            self._request_older()
            return
        self._scroll = max(0, min(self._scroll + lines, max(0, len(self._lines) - 1)))
        self.update()

    def has_visible_content(self) -> bool:
        if self._expanded or self._held:
            return True
        now = time.monotonic()
        return any(self._alpha(line, now) > 0 for line in self._lines[-self._max_lines:])

    # ---- painting --------------------------------------------------------------------------------
    def _alpha(self, line: OverlayLine, now: float) -> float:
        if self._expanded:
            return 1.0
        age = now - line.arrived
        if age >= self._fade_seconds:
            return 0.0
        remaining = self._fade_seconds - age
        return 1.0 if remaining >= _FADE_OUT else max(0.0, remaining / _FADE_OUT)

    def _doc(self, line: OverlayLine, text_width: int) -> QTextDocument:
        key = (self._expanded, text_width, self._font.pointSize(), self._yahoo_emoticons)
        cached = line._docs.get(key)
        if cached is None:
            doc = QTextDocument()
            doc.setDocumentMargin(0)
            doc.setDefaultFont(self._font)
            doc.setTextWidth(text_width)
            size = QFontMetrics(self._font).height()
            anim_urls: list[str] = []
            seen_anim: set[str] = set()

            def _inline_img(url: str, keep_aspect: bool) -> str | None:
                pm = self.images.pixmap(url)
                if pm is None or pm.isNull():
                    return None
                doc.addResource(QTextDocument.ResourceType.ImageResource, QUrl(url), pm)
                if self.images.is_animated(url) and url not in seen_anim:
                    seen_anim.add(url)
                    anim_urls.append(url)
                width = max(1, round(size * pm.width() / max(1, pm.height()))) if keep_aspect else size
                return f'<img src="{html.escape(url)}" width="{width}" height="{size}" align="middle">'

            yahoo_cb = (lambda emo_id: _inline_img(yahoo_lib.yahoo_url(emo_id), True)) if self._yahoo_emoticons else None
            doc.setHtml(line.html(
                with_time=self._expanded,
                emoticon=lambda name: _inline_img(emoticon_url(name), False),
                yahoo=yahoo_cb,
            ))
            cached = (doc, tuple(anim_urls))
            line._docs.clear()
            line._docs[key] = cached
            if anim_urls:
                self._drew_animated = True
            return doc
        doc, anim_urls = cached
        if anim_urls:
            for url in anim_urls:
                pm = self.images.pixmap(url)
                if pm is not None and not pm.isNull():
                    doc.addResource(QTextDocument.ResourceType.ImageResource, QUrl(url), pm)
            self._drew_animated = True
        return doc

    def _thumbs(self, line: OverlayLine, text_width: int) -> list[tuple[str, object, QSizeF]]:
        """(url, pixmap or None, on-screen size) for each image of the line; starts loading missing ones."""
        if not line.images:
            return []
        max_w = min(_IMG_MAX_W, text_width)
        max_h = min(_IMG_MAX_H, int(self.height() * _IMG_MAX_SHARE))
        placeholder_h = QFontMetrics(self._font).lineSpacing()
        out = []
        for url in line.images:
            pm = self.images.pixmap(url)
            if pm is None or pm.isNull():
                out.append((url, None, QSizeF(max_w, placeholder_h)))
                continue
            self._drew_animated = self._drew_animated or self.images.is_animated(url)
            scale = min(1.0, max_w / max(1, pm.width()), max_h / max(1, pm.height()))
            out.append((url, pm, QSizeF(pm.width() * scale, pm.height() * scale)))
        return out

    def _draw_thumbs(self, painter: QPainter, thumbs, x: float, y: float) -> None:
        for url, pm, size in thumbs:
            y += _IMG_GAP
            rect = QRectF(x, y, size.width(), size.height())
            if pm is not None:
                painter.drawPixmap(rect, pm, QRectF(pm.rect()))
            else:
                failed = self.images.state(url) == FAILED
                painter.setPen(QColor(_SYSTEM_COLOR))
                font = QFont(self._font)
                font.setItalic(True)
                painter.setFont(font)
                painter.drawText(rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                                 "(hình ảnh)" if failed else "đang tải ảnh…")
            y += size.height()

    def wheelEvent(self, event):
        """Only reaches us while typing (the controller lifts click-through for the history view)."""
        steps = event.angleDelta().y() // 120
        if steps:
            self.scroll_by(int(steps) * 3)
        event.accept()

    def _history_hint(self) -> str:
        if self._history == self.HISTORY_LOADING:
            return "Đang tải tin cũ hơn…"
        if self._at_top and self._history == self.HISTORY_END:
            return "— Hết lịch sử —"
        return "PageUp / lăn chuột: xem tin cũ hơn"

    def _line_settled(self, line: OverlayLine) -> bool:
        if not all(self.images.settled(u) for u in line.picture_urls()):
            return False
        for emb in line.embeds:
            if not self.embeds.settled(emb):
                return False
            meta = self.embeds.metadata(emb)
            if meta.thumb_url and not self.images.settled(meta.thumb_url):
                return False
        return True

    def _on_embed_loaded(self, kind: str, item_id: str) -> None:
        for line in [ln for ln, _d in self._held] + self._lines:
            for emb in line.embeds:
                if emb.kind == kind and emb.item_id == item_id:
                    meta = self.embeds.metadata(emb)
                    if meta.thumb_url:
                        self.images.pixmap(meta.thumb_url)
        if self._held:
            self._release_held()
        self.update()

    def _embed_cards(self, line: OverlayLine, text_width: int) -> list[tuple[ChatEmbed, EmbedMetadata, object, QSizeF, bool]]:
        if not line.embeds:
            return []
        fm = QFontMetrics(self._font)
        line_h = float(fm.lineSpacing())
        small_font = QFont(self._font)
        small_font.setPointSize(max(8, self._font.pointSize() - 2))
        sfm = QFontMetrics(small_font)
        small_h = float(sfm.lineSpacing())
        avail_h = max(92.0, (self.height() * 0.40) if self._expanded else (self.height() - 2 * _PAD - line_h - 14.0))
        out = []
        for emb in line.embeds:
            meta = self.embeds.metadata(emb)
            pm = self.images.pixmap(meta.thumb_url) if meta.thumb_url else None
            if pm is not None and pm.isNull():
                pm = None
            if emb.kind == EMBED_YOUTUBE:
                footer_h = line_h + 10.0
                w = min(272.0, float(text_width))
                thumb_h = round(w * 9.0 / 16.0)
                if thumb_h + footer_h > avail_h:
                    thumb_h = max(58.0, avail_h - footer_h)
                    w = min(float(text_width), max(120.0, round(thumb_h * 16.0 / 9.0)))
                out.append((emb, meta, pm, QSizeF(w, thumb_h + footer_h), False))
            elif emb.kind == EMBED_OG:
                w = min(280.0, float(text_width))
                has_img = bool(meta.thumb_url) and self.images.state(meta.thumb_url) != FAILED
                footer_h = small_h + 8.0
                desc_n = len(self._wrap_two_lines(sfm, meta.subtitle, int(w - 18.0)))
                info_h = 6.0 + line_h + (2.0 + desc_n * small_h if desc_n else 0.0) + 6.0 + footer_h
                if not has_img:
                    out.append((emb, meta, None, QSizeF(w, info_h + 2.0), False))
                else:
                    img_h = round(w / 1.91)
                    if img_h + info_h <= avail_h:
                        out.append((emb, meta, pm, QSizeF(w, img_h + info_h), False))
                    elif avail_h - info_h >= 78.0:
                        out.append((emb, meta, pm, QSizeF(w, avail_h), False))
                    else:
                        compact_h = max(78.0, min(avail_h, 58.0 + footer_h + 12.0))
                        out.append((emb, meta, pm, QSizeF(w, compact_h), True))
            else:
                w = min(280.0, float(text_width))
                cap_h = round(w * 215.0 / 460.0)
                footer_h = small_h + 10.0
                desc_n = len(self._wrap_two_lines(sfm, meta.subtitle, int(w - 16.0)))
                full_info_h = 5.0 + line_h + (2.0 + desc_n * small_h if desc_n else 0.0) + 6.0 + footer_h
                if cap_h + full_info_h <= avail_h:
                    out.append((emb, meta, pm, QSizeF(w, cap_h + full_info_h), False))
                elif avail_h - full_info_h >= 78.0:
                    out.append((emb, meta, pm, QSizeF(w, avail_h), False))
                else:
                    compact_h = max(82.0, min(avail_h, 62.0 + footer_h + 12.0))
                    out.append((emb, meta, pm, QSizeF(w, compact_h), True))
        return out

    @staticmethod
    def _draw_cropped_pixmap(painter: QPainter, target: QRectF, pm, top_radius: float = 0.0, all_radius: float = 0.0) -> None:
        if pm is None or pm.isNull() or target.width() <= 1 or target.height() <= 1:
            return
        pw, ph = float(pm.width()), float(pm.height())
        tw, th = target.width(), target.height()
        target_ratio = tw / th
        src_ratio = pw / ph
        if src_ratio > target_ratio:
            sw = ph * target_ratio
            src = QRectF((pw - sw) * 0.5, 0.0, sw, ph)
        else:
            sh = pw / target_ratio
            src = QRectF(0.0, (ph - sh) * 0.5, pw, sh)
        painter.save()
        if all_radius > 0:
            clip = QPainterPath()
            clip.addRoundedRect(target, all_radius, all_radius)
            painter.setClipPath(clip)
        elif top_radius > 0:
            clip = QPainterPath()
            clip.addRoundedRect(target.adjusted(0, 0, 0, top_radius), top_radius, top_radius)
            box = QPainterPath()
            box.addRect(target)
            painter.setClipPath(clip.intersected(box))
        painter.drawPixmap(target, pm, src)
        painter.restore()

    @staticmethod
    def _wrap_two_lines(fm: QFontMetrics, text: str, width: int) -> list[str]:
        words = (text or "").split()
        if not words or width <= 16:
            return []
        first: list[str] = []
        rest_idx = len(words)
        for i, word in enumerate(words):
            cand = " ".join(first + [word])
            if first and fm.horizontalAdvance(cand) > width:
                rest_idx = i
                break
            first.append(word)
        line1 = fm.elidedText(" ".join(first), Qt.TextElideMode.ElideRight, width)
        if rest_idx >= len(words):
            return [line1]
        line2 = fm.elidedText(" ".join(words[rest_idx:]), Qt.TextElideMode.ElideRight, width)
        return [line1, line2]

    def _draw_youtube_card(self, painter: QPainter, rect: QRectF, emb: ChatEmbed, meta: EmbedMetadata, pm, hovered: bool) -> None:
        fm = QFontMetrics(self._font)
        line_h = float(fm.lineSpacing())
        footer_h = line_h + 10.0
        thumb_rect = QRectF(rect.left(), rect.top(), rect.width(), max(40.0, rect.height() - footer_h))
        footer_rect = QRectF(rect.left(), thumb_rect.bottom(), rect.width(), footer_h)

        painter.setPen(QColor("#66c0f4") if hovered else QColor(255, 255, 255, 28))
        painter.setBrush(QColor(22, 26, 34, 240))
        painter.drawRoundedRect(rect.adjusted(0.5, 0.5, -0.5, -0.5), 6, 6)

        inner_thumb = thumb_rect.adjusted(1.0, 1.0, -1.0, 0.0)
        if pm is not None:
            self._draw_cropped_pixmap(painter, inner_thumb, pm, top_radius=5.5)
        else:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(13, 17, 24, 245))
            painter.drawRoundedRect(inner_thumb, 5.5, 5.5)

        grad_h = min(56.0, inner_thumb.height() * 0.55)
        top_grad = QLinearGradient(inner_thumb.left(), inner_thumb.top(), inner_thumb.left(), inner_thumb.top() + grad_h)
        top_grad.setColorAt(0.0, QColor(0, 0, 0, 200))
        top_grad.setColorAt(1.0, QColor(0, 0, 0, 0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(top_grad)
        painter.drawRoundedRect(QRectF(inner_thumb.left(), inner_thumb.top(), inner_thumb.width(), grad_h), 5.5, 5.5)

        if inner_thumb.height() >= 86:
            title_font = QFont(self._font)
            title_font.setPointSize(max(8, self._font.pointSize() - 1))
            title_font.setBold(True)
            tfm = QFontMetrics(title_font)
            painter.setFont(title_font)
            painter.setPen(QColor("#ffffff"))
            tw_avail = max(20, int(inner_thumb.width() - 18))
            painter.drawText(
                QRectF(inner_thumb.left() + 9, inner_thumb.top() + 6, tw_avail, tfm.lineSpacing()),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                tfm.elidedText(meta.title, Qt.TextElideMode.ElideRight, tw_avail),
            )
            if meta.subtitle:
                sub_font = QFont(self._font)
                sub_font.setPointSize(max(7, self._font.pointSize() - 3))
                sfm = QFontMetrics(sub_font)
                painter.setFont(sub_font)
                painter.setPen(QColor("#cbd5e1"))
                painter.drawText(
                    QRectF(inner_thumb.left() + 9, inner_thumb.top() + 6 + tfm.lineSpacing(), tw_avail, sfm.lineSpacing()),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    sfm.elidedText(meta.subtitle, Qt.TextElideMode.ElideRight, tw_avail),
                )

        # Centered vector YouTube Play button
        btn_w, btn_h = (50.0, 35.0) if inner_thumb.height() >= 95 else (40.0, 28.0)
        cx, cy = inner_thumb.center().x(), inner_thumb.center().y()
        btn_rect = QRectF(cx - btn_w * 0.5, cy - btn_h * 0.5, btn_w, btn_h)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(0, 0, 0, 95))
        painter.drawRoundedRect(btn_rect.translated(0, 1.5), 8.5, 8.5)
        painter.setBrush(QColor("#ff1a1a") if hovered else QColor("#e62117"))
        painter.drawRoundedRect(btn_rect, 8.5, 8.5)
        tri = QPolygonF([
            QPointF(cx - btn_w * 0.11, cy - btn_h * 0.21),
            QPointF(cx - btn_w * 0.11, cy + btn_h * 0.21),
            QPointF(cx + btn_w * 0.17, cy),
        ])
        painter.setBrush(QColor("#ffffff"))
        painter.drawPolygon(tri)

        # Bottom-right "Watch on YouTube" badge (matching official Steam Chat)
        if inner_thumb.width() >= 200 and inner_thumb.height() >= 95:
            badge_font = QFont(self._font)
            badge_font.setPointSize(max(7, self._font.pointSize() - 3))
            badge_font.setBold(True)
            bfm = QFontMetrics(badge_font)
            label_txt = "Watch on YouTube"
            bw = bfm.horizontalAdvance(label_txt) + 28.0
            bh = max(20.0, bfm.lineSpacing() + 4.0)
            brect = QRectF(inner_thumb.right() - bw - 6.0, inner_thumb.bottom() - bh - 6.0, bw, bh)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(12, 14, 18, 210))
            painter.drawRoundedRect(brect, 4.0, 4.0)
            icon_r = QRectF(brect.left() + 6.0, brect.center().y() - 5.0, 14.0, 10.0)
            painter.setBrush(QColor("#ffffff"))
            painter.drawRoundedRect(icon_r, 2.5, 2.5)
            mini_tri = QPolygonF([
                QPointF(icon_r.center().x() - 2.0, icon_r.center().y() - 2.6),
                QPointF(icon_r.center().x() - 2.0, icon_r.center().y() + 2.6),
                QPointF(icon_r.center().x() + 3.0, icon_r.center().y()),
            ])
            painter.setBrush(QColor("#121418"))
            painter.drawPolygon(mini_tri)
            painter.setFont(badge_font)
            painter.setPen(QColor("#f8fafc"))
            painter.drawText(
                QRectF(icon_r.right() + 4.0, brect.top(), brect.width() - 24.0, brect.height()),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                label_txt,
            )

        # Clickable Steam-blue title footer
        link_font = QFont(self._font)
        link_font.setUnderline(hovered)
        painter.setFont(link_font)
        painter.setPen(QColor("#93d5ff") if hovered else QColor("#66c0f4"))
        fw_avail = max(20, int(footer_rect.width() - 16))
        painter.drawText(
            footer_rect.adjusted(8.0, 0.0, -8.0, 0.0),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            QFontMetrics(link_font).elidedText(meta.title, Qt.TextElideMode.ElideRight, fw_avail),
        )

    def _draw_store_footer(self, painter: QPainter, footer_rect: QRectF, meta: EmbedMetadata, small_font: QFont) -> None:
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(13, 20, 29, 235))
        clip = QPainterPath()
        clip.addRoundedRect(footer_rect.adjusted(0, -4, 0, 0), 5.5, 5.5)
        box = QPainterPath()
        box.addRect(footer_rect)
        painter.save()
        painter.setClipPath(clip.intersected(box))
        painter.drawRect(footer_rect)
        painter.restore()

        left_x = footer_rect.left() + 8.0
        right_x = footer_rect.right() - 9.0
        cy = footer_rect.center().y()

        if meta.price_text:
            price_font = QFont(small_font)
            price_font.setBold(True)
            pfm = QFontMetrics(price_font)
            final_w = max(pfm.horizontalAdvance(meta.price_text), pfm.boundingRect(meta.price_text).width())
            final_color = "#beee11" if meta.discount_percent > 0 else ("#a4d007" if meta.price_text == "Miễn phí" else "#c6d4df")
            painter.setFont(price_font)
            painter.setPen(QColor(final_color))
            painter.drawText(
                QRectF(left_x, footer_rect.top(), max(10.0, right_x - left_x), footer_rect.height()),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                meta.price_text,
            )
            right_x -= final_w + 7.0

            disc_txt = f"-{meta.discount_percent}%" if meta.discount_percent > 0 else ""
            dw = (pfm.horizontalAdvance(disc_txt) + 10.0) if disc_txt else 0.0

            if meta.discount_percent > 0 and meta.original_price_text:
                orig_font = QFont(small_font)
                orig_font.setPointSize(max(7, small_font.pointSize() - 1))
                orig_font.setStrikeOut(True)
                ofm = QFontMetrics(orig_font)
                orig_w = max(ofm.horizontalAdvance(meta.original_price_text), ofm.boundingRect(meta.original_price_text).width())
                needed = orig_w + (7.0 + dw if dw else 0.0)
                if right_x - needed >= left_x:
                    painter.setFont(orig_font)
                    painter.setPen(QColor("#738895"))
                    painter.drawText(
                        QRectF(left_x, footer_rect.top(), max(10.0, right_x - left_x), footer_rect.height()),
                        Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                        meta.original_price_text,
                    )
                    right_x -= orig_w + 7.0

            if disc_txt and right_x - dw >= left_x:
                dh = max(16.0, footer_rect.height() - 6.0)
                drect = QRectF(right_x - dw, cy - dh * 0.5, dw, dh)
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor("#4c6b22"))
                painter.drawRoundedRect(drect, 3.0, 3.0)
                painter.setFont(price_font)
                painter.setPen(QColor("#beee11"))
                painter.drawText(drect, Qt.AlignmentFlag.AlignCenter, disc_txt)
                right_x = drect.left() - 8.0

        left_avail = int(right_x - left_x)
        if left_avail >= 28:
            tag_font = QFont(small_font)
            tag_font.setPointSize(max(7, small_font.pointSize() - 1))
            tag_font.setBold(True)
            tag_fm = QFontMetrics(tag_font)
            label = ""
            for cand in ("STEAM STORE", "STEAM"):
                if tag_fm.horizontalAdvance(cand) <= left_avail:
                    label = cand
                    break
            if label:
                painter.setFont(tag_font)
                painter.setPen(QColor("#66c0f4"))
                painter.drawText(
                    QRectF(left_x, footer_rect.top(), left_avail, footer_rect.height()),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    label,
                )

    def _draw_store_card(self, painter: QPainter, rect: QRectF, meta: EmbedMetadata, pm, compact: bool, hovered: bool) -> None:
        bg = QLinearGradient(rect.left(), rect.top(), rect.left(), rect.bottom())
        bg.setColorAt(0.0, QColor(27, 40, 56, 245))
        bg.setColorAt(1.0, QColor(20, 30, 43, 245))
        painter.setPen(QColor("#66c0f4") if hovered else QColor("#2a475e"))
        painter.setBrush(bg)
        painter.drawRoundedRect(rect.adjusted(0.5, 0.5, -0.5, -0.5), 6, 6)

        title_font = QFont(self._font)
        title_font.setBold(True)
        tfm = QFontMetrics(title_font)
        small_font = QFont(self._font)
        small_font.setPointSize(max(8, self._font.pointSize() - 2))
        sfm = QFontMetrics(small_font)
        footer_h = float(sfm.lineSpacing()) + 10.0
        footer_rect = QRectF(rect.left() + 1.0, rect.bottom() - footer_h - 0.5, rect.width() - 2.0, footer_h)

        if compact:
            body_h = max(36.0, footer_rect.top() - rect.top() - 10.0)
            cap_h = min(56.0, body_h)
            cap_w = round(cap_h * 460.0 / 215.0)
            cap_rect = QRectF(rect.left() + 7.0, rect.top() + 6.0, cap_w, cap_h)
            if pm is not None:
                self._draw_cropped_pixmap(painter, cap_rect, pm, all_radius=4.0)
            else:
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(14, 22, 33, 235))
                painter.drawRoundedRect(cap_rect, 4.0, 4.0)
            tx = cap_rect.right() + 8.0
            tw = max(20, int(rect.right() - tx - 8.0))
            painter.setFont(title_font)
            painter.setPen(QColor("#93d5ff") if hovered else QColor("#ffffff"))
            painter.drawText(
                QRectF(tx, cap_rect.top(), tw, tfm.lineSpacing()),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                tfm.elidedText(meta.title, Qt.TextElideMode.ElideRight, tw),
            )
            if meta.subtitle:
                painter.setFont(small_font)
                painter.setPen(QColor("#8f98a0"))
                painter.drawText(
                    QRectF(tx, cap_rect.top() + tfm.lineSpacing() + 2.0, tw, sfm.lineSpacing()),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    sfm.elidedText(meta.subtitle, Qt.TextElideMode.ElideRight, tw),
                )
        else:
            desc_lines = self._wrap_two_lines(sfm, meta.subtitle, max(20, int(rect.width() - 16.0)))
            info_h = 5.0 + float(tfm.lineSpacing()) + (2.0 + len(desc_lines) * float(sfm.lineSpacing()) if desc_lines else 0.0) + 6.0 + footer_h
            cap_h = max(56.0, rect.height() - info_h)
            cap_rect = QRectF(rect.left() + 1.0, rect.top() + 1.0, rect.width() - 2.0, cap_h)
            if pm is not None:
                self._draw_cropped_pixmap(painter, cap_rect, pm, top_radius=5.5)
            else:
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(14, 22, 33, 240))
                painter.drawRoundedRect(cap_rect, 5.5, 5.5)
                painter.setFont(small_font)
                painter.setPen(QColor("#64748b"))
                painter.drawText(cap_rect, Qt.AlignmentFlag.AlignCenter, "Steam Store")

            tw = max(20, int(rect.width() - 16.0))
            ty = cap_rect.bottom() + 5.0
            painter.setFont(title_font)
            painter.setPen(QColor("#93d5ff") if hovered else QColor("#ffffff"))
            painter.drawText(
                QRectF(rect.left() + 8.0, ty, tw, tfm.lineSpacing()),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                tfm.elidedText(meta.title, Qt.TextElideMode.ElideRight, tw),
            )
            ty += tfm.lineSpacing() + 2.0
            painter.setFont(small_font)
            painter.setPen(QColor("#8f98a0"))
            for dline in desc_lines:
                if ty + sfm.lineSpacing() > footer_rect.top() - 1.0:
                    break
                painter.drawText(
                    QRectF(rect.left() + 8.0, ty, tw, sfm.lineSpacing()),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    dline,
                )
                ty += sfm.lineSpacing()

        self._draw_store_footer(painter, footer_rect, meta, small_font)

    def _draw_og_card(self, painter: QPainter, rect: QRectF, meta: EmbedMetadata, pm, compact: bool, hovered: bool) -> None:
        bg = QLinearGradient(rect.left(), rect.top(), rect.left(), rect.bottom())
        bg.setColorAt(0.0, QColor(29, 34, 43, 245))
        bg.setColorAt(1.0, QColor(22, 26, 34, 245))
        painter.setPen(QColor("#66c0f4") if hovered else QColor(255, 255, 255, 34))
        painter.setBrush(bg)
        painter.drawRoundedRect(rect.adjusted(0.5, 0.5, -0.5, -0.5), 6, 6)

        title_font = QFont(self._font)
        title_font.setBold(True)
        title_font.setUnderline(hovered)
        tfm = QFontMetrics(title_font)
        small_font = QFont(self._font)
        small_font.setPointSize(max(8, self._font.pointSize() - 2))
        sfm = QFontMetrics(small_font)
        footer_h = float(sfm.lineSpacing()) + 8.0
        footer_rect = QRectF(rect.left() + 1.0, rect.bottom() - footer_h - 0.5, rect.width() - 2.0, footer_h)

        has_img = bool(meta.thumb_url) and self.images.state(meta.thumb_url) != FAILED
        desc_lines = self._wrap_two_lines(sfm, meta.subtitle, max(20, int(rect.width() - 18.0)))
        info_h = 6.0 + float(tfm.lineSpacing()) + (2.0 + len(desc_lines) * float(sfm.lineSpacing()) if desc_lines else 0.0) + 6.0 + footer_h

        if compact and has_img:
            body_h = max(34.0, footer_rect.top() - rect.top() - 10.0)
            th = min(54.0, body_h)
            tw_img = round(th * 1.6)
            img_rect = QRectF(rect.left() + 7.0, rect.top() + 6.0, tw_img, th)
            if pm is not None:
                self._draw_cropped_pixmap(painter, img_rect, pm, all_radius=4.0)
            else:
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(15, 19, 26, 235))
                painter.drawRoundedRect(img_rect, 4.0, 4.0)
            tx = img_rect.right() + 8.0
            tw = max(20, int(rect.right() - tx - 8.0))
            painter.setFont(title_font)
            painter.setPen(QColor("#93d5ff") if hovered else QColor("#66c0f4"))
            painter.drawText(
                QRectF(tx, img_rect.top(), tw, tfm.lineSpacing()),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                tfm.elidedText(meta.title, Qt.TextElideMode.ElideRight, tw),
            )
            if meta.subtitle:
                painter.setFont(small_font)
                painter.setPen(QColor("#9aa5b1"))
                painter.drawText(
                    QRectF(tx, img_rect.top() + tfm.lineSpacing() + 2.0, tw, sfm.lineSpacing()),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    sfm.elidedText(meta.subtitle, Qt.TextElideMode.ElideRight, tw),
                )
        else:
            ty = rect.top() + 7.0
            if has_img:
                img_h = max(56.0, rect.height() - info_h)
                img_rect = QRectF(rect.left() + 1.0, rect.top() + 1.0, rect.width() - 2.0, img_h)
                if pm is not None:
                    self._draw_cropped_pixmap(painter, img_rect, pm, top_radius=5.5)
                else:
                    painter.setPen(Qt.PenStyle.NoPen)
                    painter.setBrush(QColor(15, 19, 26, 240))
                    painter.drawRoundedRect(img_rect, 5.5, 5.5)
                ty = img_rect.bottom() + 6.0

            tw = max(20, int(rect.width() - 18.0))
            painter.setFont(title_font)
            painter.setPen(QColor("#93d5ff") if hovered else QColor("#66c0f4"))
            painter.drawText(
                QRectF(rect.left() + 9.0, ty, tw, tfm.lineSpacing()),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                tfm.elidedText(meta.title, Qt.TextElideMode.ElideRight, tw),
            )
            ty += tfm.lineSpacing() + 2.0
            painter.setFont(small_font)
            painter.setPen(QColor("#9aa5b1"))
            for dline in desc_lines:
                if ty + sfm.lineSpacing() > footer_rect.top() - 1.0:
                    break
                painter.drawText(
                    QRectF(rect.left() + 9.0, ty, tw, sfm.lineSpacing()),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    dline,
                )
                ty += sfm.lineSpacing()

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(15, 19, 25, 235))
        clip = QPainterPath()
        clip.addRoundedRect(footer_rect.adjusted(0, -4, 0, 0), 5.5, 5.5)
        box = QPainterPath()
        box.addRect(footer_rect)
        painter.save()
        painter.setClipPath(clip.intersected(box))
        painter.drawRect(footer_rect)
        painter.restore()

        dom_font = QFont(small_font)
        dom_font.setPointSize(max(7, small_font.pointSize() - 1))
        dom_font.setBold(True)
        dfm = QFontMetrics(dom_font)
        painter.setFont(dom_font)
        painter.setPen(QColor("#7c8a99"))
        dom_w = max(20, int(footer_rect.width() - 18.0))
        painter.drawText(
            footer_rect.adjusted(9.0, 0.0, -9.0, 0.0),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            dfm.elidedText(meta.domain or meta.title.upper(), Qt.TextElideMode.ElideRight, dom_w),
        )

    def _draw_embeds(self, painter: QPainter, cards, x: float, y: float) -> None:
        for emb, meta, pm, size, compact in cards:
            y += _IMG_GAP
            rect = QRectF(x, y, size.width(), size.height())
            self._embed_hits.append((rect, emb))
            hovered = self._interactive and self._hovered_embed == emb
            if emb.kind == EMBED_YOUTUBE:
                self._draw_youtube_card(painter, rect, emb, meta, pm, hovered)
            elif emb.kind == EMBED_OG:
                self._draw_og_card(painter, rect, meta, pm, compact, hovered)
            else:
                self._draw_store_card(painter, rect, meta, pm, compact, hovered)
            y += size.height()

    def _embed_at(self, pos: QPointF) -> ChatEmbed | None:
        for rect, emb in reversed(self._embed_hits):
            if rect.contains(pos):
                return emb
        return None

    def mouseMoveEvent(self, event):
        if self._interactive:
            hit = self._embed_at(event.position())
            if hit != self._hovered_embed:
                self._hovered_embed = hit
                if hit is not None:
                    self.setCursor(Qt.CursorShape.PointingHandCursor)
                else:
                    self.unsetCursor()
                self.update()
        super().mouseMoveEvent(event)

    def leaveEvent(self, event):
        if self._hovered_embed is not None:
            self._hovered_embed = None
            self.unsetCursor()
            self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if self._interactive and event.button() == Qt.MouseButton.LeftButton:
            hit = self._embed_at(event.position())
            if hit is not None:
                self.embed_clicked.emit(hit)
                event.accept()
                return
        super().mousePressEvent(event)

    def _on_image_loaded(self, url: str) -> None:
        if self._held:
            self._release_held()
        if is_emoticon_url(url):
            for line in self._lines:     # rebuild text layouts so `:name:` turns into the picture
                line._docs.clear()
        self.update()

    def paintEvent(self, event):
        self._drew_animated = False
        self._embed_hits.clear()
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)   # emoticons are drawn downscaled
        rect = self.rect()
        if self._expanded:
            painter.setPen(QColor(255, 255, 255, 30))
            painter.setBrush(QColor(10, 12, 19, 200))
            painter.drawRoundedRect(QRectF(rect).adjusted(0.5, 0.5, -0.5, -0.5), 8, 8)

        now = time.monotonic()
        text_width = max(50, rect.width() - 2 * _PAD - 2 * _HPAD)
        y = rect.height() - _PAD
        top = _PAD + (QFontMetrics(self._font).lineSpacing() if self._expanded else 0)   # history header
        shown = 0
        lines = self._lines[: len(self._lines) - self._scroll] if self._scroll else self._lines
        if not self._expanded:
            lines = lines[-self._max_lines:]
        drawn_all = True
        for line in reversed(lines):
            alpha = self._alpha(line, now)
            if alpha <= 0:
                continue            # skip faded / quiet lines while drawing live ones in the passive window
            doc = self._doc(line, text_width)
            thumbs = self._thumbs(line, text_width)
            cards = self._embed_cards(line, text_width)
            text_h = doc.size().height()
            thumbs_h = sum(_IMG_GAP + size.height() for _u, _p, size in thumbs)
            embeds_h = sum(_IMG_GAP + size.height() for _e, _m, _p, size, _c in cards)
            height = text_h + thumbs_h + embeds_h
            if y - height < top:
                drawn_all = False
                break
            y -= height
            if not self._expanded:
                width = max([doc.idealWidth()] + [size.width() for _u, _p, size in thumbs] + [size.width() for _e, _m, _p, size, _c in cards])
                pill = QRectF(_PAD, y - 2, width + 2 * _HPAD, height + 4)
                painter.setPen(Qt.PenStyle.NoPen)
                if line.mentioned:
                    r, g, b, a = _MENTIONED_PILL
                    painter.setBrush(QColor(r, g, b, int(a * alpha)))
                else:
                    painter.setBrush(QColor(0, 0, 0, int(140 * alpha)))
                painter.drawRoundedRect(pill, 5, 5)
            painter.save()
            painter.setOpacity(alpha)
            painter.translate(_PAD + _HPAD, y)
            doc.drawContents(painter)
            painter.restore()
            if thumbs:
                painter.save()
                painter.setOpacity(alpha)
                self._draw_thumbs(painter, thumbs, _PAD + _HPAD, y + text_h)
                painter.restore()
            if cards:
                painter.save()
                painter.setOpacity(alpha)
                self._draw_embeds(painter, cards, _PAD + _HPAD, y + text_h + thumbs_h)
                painter.restore()
            y -= _LINE_GAP + 4
            shown += 1
            if not self._expanded and shown >= self._max_lines:
                break
        if self._expanded:
            self._at_top = drawn_all
            if drawn_all and not self._scroll and self._history == self.HISTORY_MORE:
                QTimer.singleShot(0, self._request_older)       # panel not full yet: fetch more
            painter.setPen(QColor(_TIME_COLOR))
            painter.setFont(self._font)
            header = rect.adjusted(_PAD + _HPAD, 4, -_PAD, 0)
            if self._scroll:
                painter.drawText(header, Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignRight, f"▲ {self._scroll}")
            painter.drawText(header, Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft, self._history_hint())
        painter.end()
        if self._drew_animated and not self._anim_timer.isActive():
            self._anim_timer.start()

    # ---- fade timer ----------------------------------------------------------------------------
    def _ensure_ticking(self) -> None:
        if not self._expanded and not self._timer.isActive():
            self._timer.start()
        elif self._expanded:
            self._timer.stop()

    def _on_anim_tick(self) -> None:
        if self._drew_animated and self.isVisible():
            self.update()
        else:
            self._anim_timer.stop()

    def _on_tick(self) -> None:
        self.update()
        if not self.has_visible_content():
            self._timer.stop()
            self.faded_out.emit()


class _LineEdit(QLineEdit):
    """Line edit that reports the overlay's special keys and draws a blinking caret in no-focus mode."""

    special_key = Signal(int)
    channel_step = Signal(int)      # Ctrl+Tab (+1) / Ctrl+Shift+Tab (-1): next / previous channel

    _SPECIAL = {Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Escape, Qt.Key.Key_Tab,
                Qt.Key.Key_PageUp, Qt.Key.Key_PageDown, Qt.Key.Key_Up, Qt.Key.Key_Down}

    def __init__(self, parent=None):
        super().__init__(parent)
        self._virtual_caret = False
        self._caret_on = True
        self._caret_timer = QTimer(self)
        self._caret_timer.setInterval(530)
        self._caret_timer.timeout.connect(self._blink_caret)
        self.textChanged.connect(self._reset_caret)
        self.cursorPositionChanged.connect(self._reset_caret)

    def set_virtual_caret(self, enabled: bool) -> None:
        self._virtual_caret = bool(enabled)
        self._caret_on = True
        if self._virtual_caret and self.isVisible():
            self._caret_timer.start()
        else:
            self._caret_timer.stop()
        self.update()

    def _blink_caret(self) -> None:
        self._caret_on = not self._caret_on
        self.update()

    def _reset_caret(self, *_args) -> None:
        if self._virtual_caret:
            self._caret_on = True
            if self.isVisible():
                self._caret_timer.start()
            self.update()

    def showEvent(self, event):
        super().showEvent(event)
        if self._virtual_caret:
            self._caret_on = True
            self._caret_timer.start()

    def hideEvent(self, event):
        self._caret_timer.stop()
        super().hideEvent(event)

    def paintEvent(self, event):
        super().paintEvent(event)
        if self._virtual_caret and not self.hasFocus() and self._caret_on and not self.hasSelectedText():
            cr = self.cursorRect()
            painter = QPainter(self)
            painter.fillRect(cr.center().x(), cr.top() + 2, 1, max(2, cr.height() - 4), QColor(_TEXT_COLOR))
            painter.end()

    def event(self, event):
        if (event.type() == QEvent.Type.KeyPress and event.key() in (Qt.Key.Key_Tab, Qt.Key.Key_Backtab)
                and event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            backwards = event.key() == Qt.Key.Key_Backtab or bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier)
            self.channel_step.emit(-1 if backwards else 1)
            event.accept()
            return True
        if event.type() == QEvent.Type.KeyPress and event.key() == Qt.Key.Key_Tab:   # never moves the focus
            self.special_key.emit(Qt.Key.Key_Tab)
            event.accept()
            return True
        return super().event(event)

    def keyPressEvent(self, event):
        if event.key() in self._SPECIAL:
            self.special_key.emit(event.key())
            event.accept()
            return
        super().keyPressEvent(event)


class _ChannelLabel(QLabel):
    """The "# channel ▾" label. A focus target for the controller (GamepadNavigator: D-pad left from the input,
    A opens the channel menu); Enter / Space do the same from the keyboard."""

    activated = Signal()

    def __init__(self, parent=None):
        super().__init__("", parent)
        self.setFocusPolicy(Qt.FocusPolicy.TabFocus)

    def gamepad_activate(self) -> None:
        self.activated.emit()

    def gamepad_hints(self) -> list[tuple[str, str]]:
        return [("A", "Chuyển kênh")]

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Space):
            self.activated.emit()
            event.accept()
            return
        super().keyPressEvent(event)


# what a suggestion list holds (first item of its key)
_KIND_SLASH, _KIND_ARG, _KIND_EMOTICON, _KIND_YAHOO_CODE, _KIND_MENTION = (
    "slash", "argument", "emoticon", "yahoo_code", "mention"
)


class MentionPopup(QWidget):
    """Suggestion list shown above the input bar while an @-mention or a /command is being typed. Never takes focus."""

    picked = Signal(int)

    _PAD = 4
    _ROW_PAD = 3
    MAX_ROWS = 9            # longer lists scroll with the selection

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint
                            | Qt.WindowType.Tool
                            | Qt.WindowType.WindowStaysOnTopHint
                            | Qt.WindowType.WindowDoesNotAcceptFocus
                            | Qt.WindowType.NoDropShadowWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setWindowTitle("Steam Chat mentions")
        self._items: list[mention_lib.MentionCandidate] = []
        self._selected = 0
        self._font = QFont("Segoe UI", 12)
        self._images: ImageCache | None = None      # draws the picture of an :emoticon: / Yahoo row
        self._offset = 0                            # first visible row of a list longer than MAX_ROWS
        self._click_through = False
        self._exclude_capture = False
        self._drew_animated = False
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(_ANIM_MS)
        self._anim_timer.timeout.connect(self._on_anim_tick)

    def configure(self, font_size: int) -> None:
        self._font = QFont("Segoe UI", font_size)

    def set_images(self, images: ImageCache | None) -> None:
        if images is self._images:
            return
        self._images = images
        if images is not None:
            images.loaded.connect(lambda _url: self.update() if self.isVisible() else None)

    @property
    def items(self) -> list:
        return list(self._items)

    @property
    def selected(self) -> int:
        return self._selected

    def _row_height(self) -> int:
        return QFontMetrics(self._font).lineSpacing() + 2 * self._ROW_PAD

    def set_items(self, items: list, selected: int) -> None:
        self._items = list(items)
        self._selected = selected
        self._offset = min(self._offset, max(0, len(self._items) - self.MAX_ROWS))
        if selected < self._offset:                 # keep the selection inside the visible window
            self._offset = selected
        elif selected >= self._offset + self.MAX_ROWS:
            self._offset = selected - self.MAX_ROWS + 1
        self.update()

    @property
    def visible_rows(self) -> int:
        return min(len(self._items), self.MAX_ROWS)

    def set_exclude_from_capture(self, enabled: bool) -> None:
        self._exclude_capture = bool(enabled)
        if self.testAttribute(Qt.WidgetAttribute.WA_WState_Created):
            win32.set_exclude_from_capture(int(self.winId()), self._exclude_capture)

    def show_above(self, bar: QWidget) -> None:
        """Sit right above `bar`, as wide as it is."""
        height = self.visible_rows * self._row_height() + 2 * self._PAD
        self.setFixedSize(bar.width(), height)
        self.move(bar.x(), bar.y() - height - 2)
        self._click_through = bool(getattr(bar, "captured", False))
        hwnd = int(self.winId())
        win32.set_click_through(hwnd, self._click_through)
        win32.set_no_activate(hwnd, True)
        win32.set_exclude_from_capture(hwnd, self._exclude_capture)
        if not self.isVisible():
            self.show()
            hwnd = int(self.winId())
            win32.set_click_through(hwnd, self._click_through)
            win32.set_no_activate(hwnd, True)
            win32.set_exclude_from_capture(hwnd, self._exclude_capture)
            win32.keep_topmost(hwnd)
        self.update()

    def hide(self) -> None:
        self._anim_timer.stop()
        if self.isVisible() and self.testAttribute(Qt.WidgetAttribute.WA_WState_Created):
            win32.hide_no_activate(int(self.winId()))
        super().hide()

    def hideEvent(self, event):
        self._anim_timer.stop()
        super().hideEvent(event)

    def _on_anim_tick(self) -> None:
        if self._drew_animated and self.isVisible():
            self.update()
        else:
            self._anim_timer.stop()

    def nativeEvent(self, eventType, message):
        res = _filter_noactivate_native_event(eventType, message, block_cursor=self._click_through)
        return res if res is not None else super().nativeEvent(eventType, message)

    def _row_at(self, y: float) -> int:
        row = int((y - self._PAD) // self._row_height()) + self._offset
        return row if self._offset <= row < min(len(self._items), self._offset + self.MAX_ROWS) else -1

    def mousePressEvent(self, event):
        row = self._row_at(event.position().y())
        if row >= 0:
            self.picked.emit(row)
        event.accept()

    def paintEvent(self, event):
        self._drew_animated = False
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        painter.setPen(QColor(139, 92, 246, 165))
        painter.setBrush(QColor(10, 12, 19, 235))
        painter.drawRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 8, 8)
        row_h = self._row_height()
        detail_font = QFont(self._font)
        detail_font.setPointSize(max(6, self._font.pointSize() - 2))
        name_font = QFont(self._font)
        name_font.setBold(True)
        for i, item in enumerate(self._items):
            if not self._offset <= i < self._offset + self.MAX_ROWS:
                continue
            row = QRectF(self._PAD, self._PAD + (i - self._offset) * row_h, self.width() - 2 * self._PAD, row_h)
            if i == self._selected:
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(124, 58, 237, 110))
                painter.drawRoundedRect(row, 5, 5)
            text_rect = row.adjusted(8, 0, -8, 0)
            emoticon = getattr(item, "emoticon", "")
            if emoticon:                            # the picture first, then ":name:" or Yahoo shortcut
                side = row_h - 2 * self._ROW_PAD
                is_yahoo = yahoo_lib.is_yahoo_url(emoticon)
                url = emoticon if is_yahoo else emoticon_url(emoticon)
                draw_w = side
                if self._images is not None:
                    pm = self._images.pixmap(url)
                    if pm is not None and not pm.isNull():
                        if is_yahoo:
                            actual_w = max(1, min(round(side * 2.6), round(side * pm.width() / max(1, pm.height()))))
                            draw_w = max(side, actual_w)
                            x_off = text_rect.left() + (draw_w - actual_w) * 0.5
                            painter.drawPixmap(QRectF(x_off, row.top() + self._ROW_PAD, actual_w, side), pm,
                                               QRectF(pm.rect()))
                        else:
                            painter.drawPixmap(QRectF(text_rect.left(), row.top() + self._ROW_PAD, side, side), pm,
                                               QRectF(pm.rect()))
                        if self._images.is_animated(url):
                            self._drew_animated = True
                text_rect = text_rect.adjusted(draw_w + 8, 0, 0, 0)
            color = _SYSTEM_COLOR if not item.account_id else name_color(item.account_id)
            painter.setFont(name_font)
            painter.setPen(QColor(color))
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, item.label)
            if item.detail:
                shift = QFontMetrics(name_font).horizontalAdvance(item.label) + 10
                painter.setFont(detail_font)
                painter.setPen(QColor(_TIME_COLOR))
                painter.drawText(text_rect.adjusted(shift, 0, 0, 0),
                                 Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, item.detail)
        painter.end()
        if self._drew_animated and self.isVisible() and not self._anim_timer.isActive():
            self._anim_timer.start()


_QT_KEYS = {
    VK_BACK: Qt.Key.Key_Backspace,
    0x09: Qt.Key.Key_Tab,
    0x0D: Qt.Key.Key_Return,
    0x1B: Qt.Key.Key_Escape,
    0x21: Qt.Key.Key_PageUp,
    0x22: Qt.Key.Key_PageDown,
    0x23: Qt.Key.Key_End,
    0x24: Qt.Key.Key_Home,
    0x25: Qt.Key.Key_Left,
    0x26: Qt.Key.Key_Up,
    0x27: Qt.Key.Key_Right,
    0x28: Qt.Key.Key_Down,
    0x2D: Qt.Key.Key_Insert,
    0x2E: Qt.Key.Key_Delete,
}


def _filter_noactivate_native_event(event_type, message, block_cursor: bool) -> tuple[bool, int] | None:
    """Block Win32 mouse activation (WM_MOUSEACTIVATE) and OS cursor reveal (WM_SETCURSOR) over click-through windows."""
    if win32.NATIVE_CLICK_THROUGH and event_type == b"windows_generic_MSG" and message:
        msg_id = win32.peek_msg_id(int(message))
        if msg_id == 0x0021:  # WM_MOUSEACTIVATE -> MA_NOACTIVATE (3)
            return True, 3
        if block_cursor and msg_id == 0x0020:  # WM_SETCURSOR
            win32.suppress_cursor()
            return True, 1
    return None


class ChatInputBar(QWidget):
    """The text box shown under the chat while typing. Drag the grip to move the whole overlay."""

    submitted = Signal(str)
    cancelled = Signal()
    deactivated = Signal()
    scroll_requested = Signal(int)
    channel_step = Signal(int)       # Ctrl+Tab / Ctrl+Shift+Tab while typing
    channel_clicked = Signal(QPoint)  # the "# channel" label was clicked: global top-left of the bar (menu goes above)
    drag_moved = Signal(QPoint)      # global cursor position delta
    drag_finished = Signal()

    _HISTORY = 30

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Tool
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.NoDropShadowWindowHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setWindowTitle("Steam Chat")
        self._captured = False
        self._exclude_capture = False
        self._yahoo_emoticons = True
        self._sent: list[str] = []
        self._recall = -1
        self._drag_origin: QPoint | None = None
        self._members: list[ChatMember] = []        # @-mention suggestions come from these
        self._can_mention_all = False
        self._candidates: list[mention_lib.MentionCandidate] = []
        self._mention_key: tuple | None = None               # (kind, position of "@" / ":" / argument, typed text)
        self._dismissed: tuple | None = None                 # Esc closed the list for this key
        self._kind = _KIND_MENTION                                # what the open list holds
        self._emoticons: list[tuple[str, int]] = []          # (name, times used): ":name:" suggestions
        self._room_options: list[tuple[str, str]] = []       # (name, detail) for "/room"
        self._group_options: list[tuple[str, str]] = []      # (name, detail) for "/group"
        self._join_options: list[tuple[str, str]] = []       # (friend, game) for "/join"
        self._invite_options: list[tuple[str, str]] = []     # (friend, status) for "/invite"
        self._chat_options: list[tuple[str, str]] = []       # (friend, online / offline) for "/chat"

        frame = QFrame(self)
        frame.setObjectName("chatInputFrame")
        frame.setStyleSheet("""
            #chatInputFrame { background-color: rgba(10, 12, 19, 225); border: 1px solid rgba(139, 92, 246, 0.65);
                              border-radius: 8px; }
            QLabel { color: #a78bfa; background: transparent; border: none; font-weight: bold; }
            QLabel#grip { color: #64748b; }
            QLabel#channel:hover, QLabel#channel:focus { color: #c4b5fd; text-decoration: underline; }
            QLineEdit { background: transparent; border: none; color: #f1f5f9; selection-background-color: #7c3aed;
                        padding: 2px 0px; }
        """)
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(frame)
        row = QHBoxLayout(frame)
        row.setContentsMargins(8, 4, 10, 4)
        row.setSpacing(8)

        self._grip = QLabel("⠿")
        self._grip.setObjectName("grip")
        self._grip.setCursor(Qt.CursorShape.SizeAllCursor)
        self._grip.setToolTip("Kéo để di chuyển khung chat")
        self._grip.installEventFilter(self)
        row.addWidget(self._grip)

        self._channel = _ChannelLabel()
        self._channel.setObjectName("channel")
        self._channel.activated.connect(lambda: self.channel_clicked.emit(self.mapToGlobal(QPoint(0, 0))))
        self._channel.setCursor(Qt.CursorShape.PointingHandCursor)
        self._channel.setToolTip("Bấm để chuyển kênh / nhóm / chat riêng")
        self._channel.installEventFilter(self)
        self._holding = False                         # a menu of ours is open: losing activation must not close the bar
        row.addWidget(self._channel)

        self.edit = _LineEdit()
        self.edit.setMaxLength(2000)
        self.edit.special_key.connect(self._on_special_key)
        self.edit.channel_step.connect(self.channel_step)
        self.edit.textChanged.connect(self._refresh_mentions)
        self.edit.cursorPositionChanged.connect(self._refresh_mentions)
        row.addWidget(self.edit, 1)

        self._popup = MentionPopup(self)
        self._popup.picked.connect(self._pick_mention)

    def configure(self, font_size: int, width: int) -> None:
        font = QFont("Segoe UI", font_size)
        self._channel.setFont(font)
        self.edit.setFont(font)
        self._popup.configure(font_size)
        self.setFixedSize(width, QFontMetrics(font).lineSpacing() + 18)

    def set_channel(self, name: str, connected: bool) -> None:
        """`name` of the channel ("# name ▾"), or "@ friend" for a private chat (shown as is)."""
        shown = name if name.startswith("@") else (f"# {name}" if name else "#")
        self._channel.setText(f"{shown} ▾")
        self.edit.setPlaceholderText("Nhập tin nhắn…  (Enter gửi · Esc đóng)" if connected
                                     else "Chưa kết nối Steam")

    def set_members(self, members: list, can_mention_all: bool = False) -> None:
        """The room's members, offered after "@". Empty (not loaded / unsupported) switches the feature off."""
        self._members = list(members)
        self._can_mention_all = bool(can_mention_all)
        self._refresh_mentions()

    def set_emoticons(self, emoticons: list) -> None:
        """(name, times used) of the emoticons the account owns, offered after ":"."""
        self._emoticons = [(str(n), int(u)) for n, u in emoticons]
        self._refresh_mentions()

    def set_switch_options(self, rooms: list, groups: list) -> None:
        """(name, detail) of the other channels of the group / the chat groups, offered after /room and /group."""
        self._room_options = list(rooms)
        self._group_options = list(groups)
        self._refresh_mentions()

    def set_join_options(self, friends: list) -> None:
        """(friend, game) pairs of the friends that can be joined right now, offered after /join."""
        self._join_options = list(friends)
        self._refresh_mentions()

    def set_chat_options(self, friends: list) -> None:
        """(friend, status) pairs of every friend, offered after /chat."""
        self._chat_options = list(friends)
        self._refresh_mentions()

    def set_invite_options(self, friends: list) -> None:
        """(friend, status) pairs of the online friends (and "all"), offered after /invite."""
        self._invite_options = list(friends)
        self._refresh_mentions()

    def set_images(self, images: ImageCache | None) -> None:
        self._popup.set_images(images)

    @property
    def mention_candidates(self) -> list:
        return list(self._candidates)

    @property
    def mention_selected(self) -> int:
        return self._popup.selected

    def keep_topmost(self) -> None:
        win32.keep_topmost(int(self.winId()))
        if self._popup.isVisible():
            win32.keep_topmost(int(self._popup.winId()))

    @property
    def captured(self) -> bool:
        return self._captured

    def set_exclude_from_capture(self, enabled: bool) -> None:
        self._exclude_capture = bool(enabled)
        self._popup.set_exclude_from_capture(self._exclude_capture)
        if self.testAttribute(Qt.WidgetAttribute.WA_WState_Created):
            win32.set_exclude_from_capture(int(self.winId()), self._exclude_capture)

    def set_yahoo_emoticons(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if enabled == self._yahoo_emoticons:
            return
        self._yahoo_emoticons = enabled
        self._refresh_mentions()

    def open(self, captured: bool = False) -> None:
        self._captured = bool(captured)
        self.edit.set_virtual_caret(self._captured)
        self.edit.setFocusPolicy(Qt.FocusPolicy.NoFocus if self._captured else Qt.FocusPolicy.StrongFocus)
        self._channel.setFocusPolicy(Qt.FocusPolicy.NoFocus if self._captured else Qt.FocusPolicy.TabFocus)
        if self._captured:
            blank = Qt.CursorShape.BlankCursor
            self.setCursor(blank)
            self._grip.setCursor(blank)
            self._channel.setCursor(blank)
            self.edit.setCursor(blank)
        else:
            self.unsetCursor()
            self._grip.setCursor(Qt.CursorShape.SizeAllCursor)
            self._channel.setCursor(Qt.CursorShape.PointingHandCursor)
            self.edit.setCursor(Qt.CursorShape.IBeamCursor)
        self._recall = -1
        self._dismissed = None
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, self._captured)
        hwnd = int(self.winId())
        win32.set_click_through(hwnd, self._captured)
        win32.set_no_activate(hwnd, self._captured)
        win32.set_exclude_from_capture(hwnd, self._exclude_capture)
        self.show()
        hwnd = int(self.winId())
        win32.set_click_through(hwnd, self._captured)
        win32.set_no_activate(hwnd, self._captured)
        win32.set_exclude_from_capture(hwnd, self._exclude_capture)
        if self._captured:
            self.keep_topmost()
        else:
            self.raise_()
            self.activateWindow()
            self.edit.setFocus(Qt.FocusReason.ActiveWindowFocusReason)
        self._refresh_mentions()
        self.edit.update()

    def hide(self) -> None:
        if self._popup.isVisible():
            self._popup.hide()
        if self.isVisible() and self.testAttribute(Qt.WidgetAttribute.WA_WState_Created):
            win32.hide_no_activate(int(self.winId()))
        super().hide()

    def nativeEvent(self, eventType, message):
        if self._captured:
            res = _filter_noactivate_native_event(eventType, message, block_cursor=True)
            if res is not None:
                return res
        return super().nativeEvent(eventType, message)

    def feed_key(self, stroke: KeyStroke) -> None:
        """Apply a captured low-level keystroke while open in no-activate fullscreen mode."""
        if stroke.injected:
            if stroke.vk == VK_PACKET:
                if stroke.text:
                    self.edit.insert(stroke.text)
                    self.edit.update()
                return
            if stroke.vk == VK_BACK:
                self.edit.backspace()
                self.edit.update()
                return
            if (stroke.ctrl and stroke.vk == ord("V")) or (stroke.shift and stroke.vk == 0x2D):
                self.edit.paste()
                self.edit.update()
                return
            if stroke.text:
                self.edit.insert(stroke.text)
                self.edit.update()
            return
        mods = Qt.KeyboardModifier.NoModifier
        if stroke.ctrl:
            mods |= Qt.KeyboardModifier.ControlModifier
        if stroke.shift:
            mods |= Qt.KeyboardModifier.ShiftModifier
        key = _QT_KEYS.get(stroke.vk)
        if key is None and stroke.ctrl and 0x41 <= stroke.vk <= 0x5A:
            key = Qt.Key(stroke.vk)
        if key is not None:
            QApplication.sendEvent(self.edit, QKeyEvent(QEvent.Type.KeyPress, key, mods, ""))
            self.edit.update()
            return
        if not stroke.ctrl and stroke.text:
            self.edit.insert(stroke.text)
            self.edit.update()

    def remember_sent(self, text: str) -> None:
        if text and (not self._sent or self._sent[-1] != text):
            self._sent.append(text)
            del self._sent[:-self._HISTORY]

    # ---- @-mention / emoticon / command suggestions --------------------------------------------
    def _find_candidates(self) -> tuple[tuple | None, str, list]:
        """((kind, position, typed text) of the open list, kind, suggestions) for what is being typed."""
        edit = self.edit
        text, cursor = edit.text(), edit.cursorPosition()
        query = command_lib.active_query(text, cursor)
        if query is not None:
            cmds = command_lib.suggest(query)
            if cmds:
                return (_KIND_SLASH, 0, query), _KIND_SLASH, cmds
            if not (self._yahoo_emoticons and query.startswith(":")):
                return None, _KIND_SLASH, []
        arg = command_lib.active_argument(text, cursor)
        if arg is not None:
            command, start, typed = arg
            options = {command_lib.ROOM: self._room_options, command_lib.GROUP: self._group_options,
                       command_lib.INVITE: self._invite_options,
                       command_lib.CHAT: self._chat_options}.get(command, self._join_options)
            marker = "# " if command in (command_lib.ROOM, command_lib.GROUP) else ""
            return (_KIND_ARG, start, typed), _KIND_ARG, command_lib.suggest_names(options, typed, marker=marker)
        found = emoticon_lib.active_query(text, cursor)
        if found is not None:
            steam_items = emoticon_lib.suggest(self._emoticons, found[1]) if self._emoticons else []
            yahoo_items = yahoo_lib.suggest_by_keyword(found[1]) if self._yahoo_emoticons else []
            exact_code = ":" + found[1].lower()
            if yahoo_items and yahoo_items[0].insert.lower() == exact_code:
                combined = [yahoo_items[0]] + steam_items + yahoo_items[1:]
            else:
                combined = steam_items + yahoo_items
            if combined:
                return (_KIND_EMOTICON, *found), _KIND_EMOTICON, combined[:emoticon_lib.MAX_SUGGESTIONS]
        if self._members or self._can_mention_all:
            found = mention_lib.active_query(text, cursor)
            if found is not None:
                mentions = mention_lib.suggest(self._members, found[1], self._can_mention_all)
                if mentions:
                    return (_KIND_MENTION, *found), _KIND_MENTION, mentions
        if self._yahoo_emoticons:
            y_found = yahoo_lib.active_code_query(text, cursor)
            if y_found is not None:
                y_items = yahoo_lib.suggest_by_code(y_found[1])
                if y_items:
                    return (_KIND_YAHOO_CODE, *y_found), _KIND_YAHOO_CODE, y_items
        return None, _KIND_MENTION, []

    def _refresh_mentions(self, *_args) -> None:
        found, kind, candidates = self._find_candidates() if self.isVisible() else (None, _KIND_MENTION, [])
        if found is None or found == self._dismissed:
            candidates = []
        if not candidates:
            self._candidates = []
            self._mention_key = None
            self._popup.hide()
            return
        selected = self._popup.selected if found == self._mention_key else 0
        self._mention_key = found
        self._kind = kind
        self._candidates = candidates
        self._popup.set_items(candidates, min(selected, len(candidates) - 1))
        self._popup.show_above(self)

    def _move_mention(self, step: int) -> None:
        count = len(self._candidates)
        self._popup.set_items(self._candidates, (self._popup.selected + step) % count)

    def _picked_text(self, index: int) -> tuple[str, int] | None:
        """(text, cursor) the input would have after picking suggestion `index`; None when there is nothing to pick."""
        if not 0 <= index < len(self._candidates) or self._mention_key is None:
            return None
        edit = self.edit
        candidate, position = self._candidates[index], self._mention_key[1]
        if self._kind == _KIND_SLASH:
            return command_lib.replace_command(edit.text(), edit.cursorPosition(), candidate)
        if self._kind == _KIND_ARG:
            return command_lib.replace_argument(edit.text(), position, candidate)
        if self._kind in (_KIND_EMOTICON, _KIND_YAHOO_CODE):
            return emoticon_lib.replace_query(edit.text(), position, edit.cursorPosition(), candidate)
        return mention_lib.replace_query(edit.text(), position, edit.cursorPosition(), candidate)

    def _pick_mention(self, index: int) -> None:
        picked = self._picked_text(index)
        if picked is None:
            return
        text, cursor = picked
        self.edit.setText(text)
        self.edit.setCursorPosition(cursor)
        self.edit.update()

    def _enter_would_only_repeat_the_pick(self) -> bool:
        """True when Enter on the open command / argument / emoticon list would change nothing (e.g. "/invite all" or
        "haha =))" when a complete shortcut is already typed). Enter then sends the message immediately."""
        if self._kind not in (_KIND_SLASH, _KIND_ARG, _KIND_EMOTICON, _KIND_YAHOO_CODE):
            return False
        picked = self._picked_text(self._popup.selected)
        return picked is not None and picked[0].strip().casefold() == self.edit.text().strip().casefold()

    def _send_current(self) -> None:
        text = self.edit.text().strip()
        self.edit.clear()
        self.submitted.emit(text)

    def _on_special_key(self, key: int) -> None:
        if self._candidates:
            if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Tab):
                if key != Qt.Key.Key_Tab and self._enter_would_only_repeat_the_pick():
                    self._send_current()
                    return
                self._pick_mention(self._popup.selected)
                return
            if key in (Qt.Key.Key_Up, Qt.Key.Key_Down):
                self._move_mention(-1 if key == Qt.Key.Key_Up else 1)
                return
            if key == Qt.Key.Key_Escape:
                self._dismissed = self._mention_key
                self._refresh_mentions()
                return
        elif key == Qt.Key.Key_Tab:
            return
        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self._send_current()
        elif key == Qt.Key.Key_Escape:
            self.edit.clear()
            self.cancelled.emit()
        elif key == Qt.Key.Key_PageUp:
            self.scroll_requested.emit(3)
        elif key == Qt.Key.Key_PageDown:
            self.scroll_requested.emit(-3)
        elif key == Qt.Key.Key_Up and self._sent:
            self._recall = len(self._sent) - 1 if self._recall < 0 else max(0, self._recall - 1)
            self.edit.setText(self._sent[self._recall])
        elif key == Qt.Key.Key_Down and self._recall >= 0:
            self._recall += 1
            if self._recall >= len(self._sent):
                self._recall = -1
                self.edit.clear()
            else:
                self.edit.setText(self._sent[self._recall])

    def wheelEvent(self, event):
        steps = event.angleDelta().y() // 120
        if steps:
            self.scroll_requested.emit(int(steps) * 3)
        event.accept()

    def hold_open(self, hold: bool) -> None:
        """While a menu opened from the bar is up, losing activation to it does not close the bar."""
        self._holding = bool(hold)

    @property
    def holding(self) -> bool:
        """A menu opened from the bar is up: nothing of ours may be raised over it."""
        return self._holding

    @property
    def channel_text(self) -> str:
        return self._channel.text()

    def eventFilter(self, obj, event):
        if obj is getattr(self, "_channel", None) and event.type() == event.Type.MouseButtonPress \
                and event.button() == Qt.MouseButton.LeftButton:
            self.channel_clicked.emit(self.mapToGlobal(QPoint(0, 0)))
            return True
        if obj is self._grip:
            et = event.type()
            if et == event.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                self._drag_origin = event.globalPosition().toPoint()
                return True
            if et == event.Type.MouseMove and self._drag_origin is not None:
                pos = event.globalPosition().toPoint()
                self.drag_moved.emit(pos - self._drag_origin)
                self._drag_origin = pos
                return True
            if et == event.Type.MouseButtonRelease and self._drag_origin is not None:
                self._drag_origin = None
                self.drag_finished.emit()
                if not self._captured:
                    self.edit.setFocus()
                return True
        return super().eventFilter(obj, event)

    def hideEvent(self, event):
        self._candidates = []
        self._popup.hide()
        super().hideEvent(event)

    def changeEvent(self, event):
        if event.type() == event.Type.ActivationChange and not self.isActiveWindow() and self.isVisible() \
                and not self._captured and not getattr(self, "_holding", False):
            self.deactivated.emit()
        super().changeEvent(event)
