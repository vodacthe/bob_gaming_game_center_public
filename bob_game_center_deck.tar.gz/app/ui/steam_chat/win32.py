"""Small Win32 helpers for the chat overlay: foreground/fullscreen detection, topmost, focus hand-off.

Every function is a safe no-op (or returns a neutral value) off Windows or when a call fails.
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass

logger = logging.getLogger(__name__)

_IS_WIN = sys.platform == "win32"
NATIVE_CLICK_THROUGH = _IS_WIN      # set_click_through works (otherwise Qt's WindowTransparentForInput is used)

if _IS_WIN:
    import ctypes
    from ctypes import wintypes

    _user32 = ctypes.WinDLL("user32", use_last_error=True)
    _user32.GetForegroundWindow.restype = wintypes.HWND
    _user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    _user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    _user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    _user32.MonitorFromWindow.restype = wintypes.HMONITOR
    _user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
    _user32.IsWindow.argtypes = [wintypes.HWND]
    _user32.IsWindowVisible.argtypes = [wintypes.HWND]
    _user32.IsIconic.argtypes = [wintypes.HWND]
    _user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    _user32.BringWindowToTop.argtypes = [wintypes.HWND]
    _user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    _user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
    _user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
    _user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
    _user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                     ctypes.c_int, ctypes.c_int, ctypes.c_uint]

    class _MONITORINFOEXW(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD),
            ("rcMonitor", wintypes.RECT),
            ("rcWork", wintypes.RECT),
            ("dwFlags", wintypes.DWORD),
            ("szDevice", wintypes.WCHAR * 32),
        ]

    class _CURSORINFO(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD),
            ("flags", wintypes.DWORD),
            ("hCursor", wintypes.HANDLE),
            ("ptScreenPos", wintypes.POINT),
        ]

    _user32.GetMonitorInfoW.argtypes = [wintypes.HMONITOR, ctypes.POINTER(_MONITORINFOEXW)]
    _user32.GetCursorInfo.argtypes = [ctypes.POINTER(_CURSORINFO)]
    _user32.GetCursorInfo.restype = wintypes.BOOL
    _user32.GetClipCursor.argtypes = [ctypes.POINTER(wintypes.RECT)]
    _user32.GetClipCursor.restype = wintypes.BOOL
    _user32.GetSystemMetrics.argtypes = [ctypes.c_int]
    _user32.GetSystemMetrics.restype = ctypes.c_int
    _user32.SetCursor.argtypes = [wintypes.HANDLE]
    _user32.SetCursor.restype = wintypes.HANDLE
    _user32.SetWindowDisplayAffinity.argtypes = [wintypes.HWND, wintypes.DWORD]
    _user32.SetWindowDisplayAffinity.restype = wintypes.BOOL

_MONITOR_DEFAULTTONEAREST = 2
_HWND_TOPMOST = -1
_SWP_NOSIZE, _SWP_NOMOVE, _SWP_NOZORDER, _SWP_NOACTIVATE = 0x0001, 0x0002, 0x0004, 0x0010
_SWP_HIDEWINDOW, _SWP_NOOWNERZORDER = 0x0080, 0x0200
_GWL_EXSTYLE = -20
_WS_EX_TRANSPARENT, _WS_EX_LAYERED, _WS_EX_NOACTIVATE = 0x00000020, 0x00080000, 0x08000000
_CURSOR_SHOWING = 0x00000001
_SM_XVIRTUALSCREEN, _SM_YVIRTUALSCREEN, _SM_CXVIRTUALSCREEN, _SM_CYVIRTUALSCREEN = 76, 77, 78, 79
_WDA_NONE, _WDA_EXCLUDEFROMCAPTURE = 0x00000000, 0x00000011
_affinity_warned = False

# Desktop, taskbar, start menu, alt-tab & co. are never "a game"
_SHELL_CLASSES = {
    "progman", "workerw", "shell_traywnd", "shell_secondarytraywnd", "windows.ui.core.corewindow",
    "multitaskingviewframe", "xamlexplorerhostislandwindow", "foregroundstaging", "#32769",
}


@dataclass(frozen=True)
class ForegroundInfo:
    hwnd: int = 0
    own: bool = False            # belongs to this process (our overlay, input bar or main window)
    fullscreen: bool = False     # covers its whole monitor (borderless / fullscreen game)
    monitor: str = ""            # GDI device name, e.g. DISPLAY2; identifies the monitor
    monitor_origin: tuple[int, int] | None = None   # native top-left; Qt keeps it as QScreen.geometry().topLeft()
    cursor_visible: bool = True  # False when the foreground game hides the OS cursor (raw/captured mouse)
    cursor_clipped: bool = False # True when the foreground game confines the cursor via ClipCursor


def foreground_info() -> ForegroundInfo:
    if not _IS_WIN:
        return ForegroundInfo()
    try:
        hwnd = _user32.GetForegroundWindow()
        if not hwnd:
            return ForegroundInfo()
        pid = wintypes.DWORD()
        _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        own = pid.value == os.getpid()

        buf = ctypes.create_unicode_buffer(256)
        _user32.GetClassNameW(hwnd, buf, 256)
        shell = buf.value.lower() in _SHELL_CLASSES
        iconic = bool(_user32.IsIconic(hwnd))

        monitor = _user32.MonitorFromWindow(hwnd, _MONITOR_DEFAULTTONEAREST)
        info = _MONITORINFOEXW()
        info.cbSize = ctypes.sizeof(_MONITORINFOEXW)
        device, origin, fullscreen = "", None, False
        if monitor and _user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
            device = info.szDevice
            origin = (info.rcMonitor.left, info.rcMonitor.top)
            rect = wintypes.RECT()
            if not shell and not iconic and _user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                m = info.rcMonitor
                fullscreen = (rect.left <= m.left and rect.top <= m.top
                              and rect.right >= m.right and rect.bottom >= m.bottom)

        cursor_visible = True
        ci = _CURSORINFO()
        ci.cbSize = ctypes.sizeof(_CURSORINFO)
        if _user32.GetCursorInfo(ctypes.byref(ci)):
            cursor_visible = bool((ci.flags & _CURSOR_SHOWING) and ci.hCursor)

        cursor_clipped = False
        if not shell and not iconic:
            clip = wintypes.RECT()
            vw = _user32.GetSystemMetrics(_SM_CXVIRTUALSCREEN)
            vh = _user32.GetSystemMetrics(_SM_CYVIRTUALSCREEN)
            if vw > 0 and vh > 0 and _user32.GetClipCursor(ctypes.byref(clip)):
                vx = _user32.GetSystemMetrics(_SM_XVIRTUALSCREEN)
                vy = _user32.GetSystemMetrics(_SM_YVIRTUALSCREEN)
                cursor_clipped = (
                    clip.left > vx + 2
                    or clip.top > vy + 2
                    or clip.right < vx + vw - 2
                    or clip.bottom < vy + vh - 2
                )

        return ForegroundInfo(
            hwnd=int(hwnd),
            own=own,
            fullscreen=fullscreen,
            monitor=device,
            monitor_origin=origin,
            cursor_visible=cursor_visible,
            cursor_clipped=cursor_clipped,
        )
    except Exception as e:
        logger.debug(f"[SteamChat] foreground_info failed: {e}")
        return ForegroundInfo()


def is_window(hwnd: int) -> bool:
    return bool(_IS_WIN and hwnd and _user32.IsWindow(hwnd))


def is_own_window(hwnd: int) -> bool:
    """True when `hwnd` belongs to this process."""
    if not (_IS_WIN and hwnd):
        return False
    try:
        pid = wintypes.DWORD()
        _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return pid.value == os.getpid()
    except Exception:
        return False


def set_foreground(hwnd: int) -> bool:
    """Bring `hwnd` to the foreground. A global hotkey grants that right; a controller combo does not, so
    fall back to attaching to the foreground thread's input queue (Windows foreground-lock rules)."""
    if not is_window(hwnd):
        return False
    try:
        if _user32.SetForegroundWindow(hwnd) and _user32.GetForegroundWindow() == hwnd:
            return True
        current = _user32.GetForegroundWindow()
        fg_thread = _user32.GetWindowThreadProcessId(current, None) if current else 0
        me = _kernel32.GetCurrentThreadId()
        attached = bool(fg_thread and fg_thread != me and _user32.AttachThreadInput(me, fg_thread, True))
        try:
            _user32.BringWindowToTop(hwnd)
            _user32.SetForegroundWindow(hwnd)
        finally:
            if attached:
                _user32.AttachThreadInput(me, fg_thread, False)
        return _user32.GetForegroundWindow() == hwnd
    except Exception:
        return False


def keep_topmost(hwnd: int) -> None:
    """Re-assert HWND_TOPMOST without moving, resizing or activating (games may push themselves on top)."""
    if not (_IS_WIN and hwnd):
        return
    try:
        _user32.SetWindowPos(
            hwnd,
            _HWND_TOPMOST,
            0,
            0,
            0,
            0,
            _SWP_NOMOVE | _SWP_NOSIZE | _SWP_NOACTIVATE | _SWP_NOOWNERZORDER,
        )
    except Exception:
        pass


def hide_no_activate(hwnd: int) -> bool:
    """Hide `hwnd` with SWP_NOACTIVATE so Win32 never activates another visible window of our process."""
    if not (_IS_WIN and hwnd):
        return False
    try:
        return bool(
            _user32.SetWindowPos(
                hwnd,
                0,
                0,
                0,
                0,
                0,
                _SWP_HIDEWINDOW | _SWP_NOACTIVATE | _SWP_NOMOVE | _SWP_NOSIZE | _SWP_NOZORDER | _SWP_NOOWNERZORDER,
            )
        )
    except Exception:
        return False


def peek_msg_id(addr: int) -> int:
    """Read `MSG.message` from a Qt nativeEvent pointer on Windows (0 elsewhere)."""
    if not (_IS_WIN and addr):
        return 0
    try:
        return int(wintypes.MSG.from_address(addr).message)
    except Exception:
        return 0


def suppress_cursor() -> None:
    """Hide the Win32 cursor immediately when handling WM_SETCURSOR over a click-through overlay."""
    if _IS_WIN:
        try:
            _user32.SetCursor(0)
        except Exception:
            pass


def set_no_activate(hwnd: int, enabled: bool) -> bool:
    """Toggle WS_EX_NOACTIVATE so clicking an overlay window never steals focus from a fullscreen game."""
    if not (_IS_WIN and hwnd):
        return False
    try:
        style = _user32.GetWindowLongPtrW(hwnd, _GWL_EXSTYLE)
        new = (style | _WS_EX_NOACTIVATE) if enabled else (style & ~_WS_EX_NOACTIVATE)
        if new != style:
            _user32.SetWindowLongPtrW(hwnd, _GWL_EXSTYLE, new)
        return True
    except Exception:
        return False


def set_click_through(hwnd: int, enabled: bool) -> bool:
    """Let mouse input fall through the window (enabled) or let it receive the wheel / clicks without ever
    being activated. Flips the native style directly: changing Qt's WindowTransparentForInput flag would
    re-create the window (flicker, focus loss)."""
    if not (_IS_WIN and hwnd):
        return False
    try:
        style = _user32.GetWindowLongPtrW(hwnd, _GWL_EXSTYLE)
        if enabled:
            new = style | _WS_EX_TRANSPARENT | _WS_EX_LAYERED
        else:
            new = (style & ~_WS_EX_TRANSPARENT) | _WS_EX_NOACTIVATE
        if new != style:
            _user32.SetWindowLongPtrW(hwnd, _GWL_EXSTYLE, new)
        return True
    except Exception:
        return False


def set_exclude_from_capture(hwnd: int, enabled: bool) -> bool:
    """Hide `hwnd` from Windows screen-capture APIs (WDA_EXCLUDEFROMCAPTURE on Win10 2004+ / Win11)."""
    global _affinity_warned
    if not (_IS_WIN and hwnd):
        return False
    try:
        flag = _WDA_EXCLUDEFROMCAPTURE if enabled else _WDA_NONE
        ok = bool(_user32.SetWindowDisplayAffinity(hwnd, flag))
        if not ok and enabled and not _affinity_warned:
            _affinity_warned = True
            logger.warning(
                f"[SteamChat] SetWindowDisplayAffinity(WDA_EXCLUDEFROMCAPTURE) unsupported "
                f"(win32_error={ctypes.get_last_error()})"
            )
        return ok
    except Exception as e:
        if not _affinity_warned:
            _affinity_warned = True
            logger.warning(f"[SteamChat] SetWindowDisplayAffinity failed: {e}")
        return False
