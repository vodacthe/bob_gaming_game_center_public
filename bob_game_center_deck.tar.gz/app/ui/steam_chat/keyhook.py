"""Low-level keyboard capture for no-focus Steam Chat Overlay typing over fullscreen games.

Taking Win32 foreground focus away from an Exclusive Fullscreen game (DXGI SetFullscreenState / Unity /
D3D12) sends WM_ACTIVATEAPP(FALSE) to the game, which immediately exits fullscreen and minimizes the
game window to the desktop.

Instead, while the chat input bar is open over a fullscreen window, a dedicated daemon thread installs
`WH_KEYBOARD_LL` (`SetWindowsHookExW`) for the duration of typing only:
- Physical typing/editing keys are first passed down `CallNextHookEx` so external Vietnamese IMEs
  (Unikey / EVKey) inspect the syllable buffer and, when composing, swallow the raw key (`!= 0`) and
  emit `VK_BACK` + `VK_PACKET` (`LLKHF_INJECTED`) via `SendInput`.
- Injected IME events (`LLKHF_INJECTED`) and unconsumed physical keys are emitted to the GUI thread via
  Qt `Signal` and return `1` from the hook so the fullscreen game never receives the keystrokes and
  never loses foreground focus.
"""

from __future__ import annotations

import logging
import sys
import threading
import time
from dataclasses import dataclass

from PySide6.QtCore import QObject, Signal

from app.ui.steam_chat import win32

logger = logging.getLogger(__name__)
TAG = "[SteamChat/KeyHook]"

_IS_WIN = sys.platform == "win32"

VK_BACK, VK_TAB, VK_RETURN, VK_ESCAPE = 0x08, 0x09, 0x0D, 0x1B
VK_SHIFT, VK_CONTROL, VK_MENU, VK_CAPITAL = 0x10, 0x11, 0x12, 0x14
VK_LWIN, VK_RWIN, VK_NUMLOCK, VK_PACKET = 0x5B, 0x5C, 0x90, 0xE7
_SHIFT_VKS = {VK_SHIFT, 0xA0, 0xA1}
_CTRL_VKS = {VK_CONTROL, 0xA2, 0xA3}
_ALT_VKS = {VK_MENU, 0xA4, 0xA5}
_MODIFIERS = _SHIFT_VKS | _CTRL_VKS | _ALT_VKS | {VK_LWIN, VK_RWIN, VK_CAPITAL, VK_NUMLOCK, 0x91}


@dataclass(frozen=True)
class KeyStroke:
    vk: int
    text: str = ""
    ctrl: bool = False
    shift: bool = False
    injected: bool = False


class KeyFilter:
    """State machine deciding which physical keyboard events are intercepted vs passed to the game/OS."""

    def __init__(self, hotkeys=(), held=()):
        self.hotkeys = set(hotkeys)          # (MOD_* flags, vk) combos left to RegisterHotKey
        self.held = set(held)                # down before capture started: game keeps their release
        self.swallowed: set[int] = set()     # downs captured by us: swallow their releases too
        self.capturing = True

    def decide(self, vk: int, down: bool, ctrl: bool, shift: bool, alt: bool, win: bool) -> bool:
        """Return True to intercept the event (preventing it from reaching the foreground game)."""
        if not down:
            if vk in self.swallowed:
                self.swallowed.discard(vk)
                return True
            self.held.discard(vk)
            return False
        if not self.capturing or vk in _MODIFIERS or alt or win or vk in self.held:
            return False
        mods = (0x2 if ctrl else 0) | (0x4 if shift else 0)
        if (mods, vk) in self.hotkeys:
            return False
        self.swallowed.add(vk)
        return True

    @property
    def drained(self) -> bool:
        return not self.capturing and not self.swallowed


if _IS_WIN:
    import ctypes
    from ctypes import wintypes

    _user32 = ctypes.WinDLL("user32", use_last_error=True)
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    class _KBDLLHOOKSTRUCT(ctypes.Structure):
        _fields_ = [
            ("vkCode", wintypes.DWORD),
            ("scanCode", wintypes.DWORD),
            ("flags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.c_size_t),
        ]

    _HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
    _user32.SetWindowsHookExW.restype = wintypes.HHOOK
    _user32.SetWindowsHookExW.argtypes = [ctypes.c_int, _HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
    _user32.CallNextHookEx.restype = ctypes.c_ssize_t
    _user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
    _user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
    _user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
    _user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    _user32.GetAsyncKeyState.restype = ctypes.c_short
    _user32.GetKeyState.restype = ctypes.c_short
    _user32.GetForegroundWindow.restype = wintypes.HWND
    _user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    _user32.GetKeyboardLayout.restype = ctypes.c_void_p
    _user32.MapVirtualKeyExW.restype = wintypes.UINT
    _user32.MapVirtualKeyExW.argtypes = [wintypes.UINT, wintypes.UINT, ctypes.c_void_p]
    _user32.ToUnicodeEx.argtypes = [
        wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_ubyte),
        wintypes.LPWSTR, ctypes.c_int, wintypes.UINT, ctypes.c_void_p,
    ]
    _user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
    _kernel32.GetModuleHandleW.restype = wintypes.HMODULE
    _kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]

_WH_KEYBOARD_LL = 13
_WM_KEYDOWN, _WM_KEYUP, _WM_SYSKEYDOWN, _WM_SYSKEYUP, _WM_QUIT = 0x0100, 0x0101, 0x0104, 0x0105, 0x0012
_LLKHF_INJECTED = 0x10
_DRAIN_SECONDS = 2.0


def _pressed(vk: int) -> bool:
    return bool(_user32.GetAsyncKeyState(vk) & 0x8000)


class KeyboardCapture(QObject):
    """Installs `WH_KEYBOARD_LL` on a worker thread and delivers `KeyStroke` events to the GUI thread."""

    key = Signal(object)        # KeyStroke
    target_lost = Signal()      # foreground left `target_hwnd` (e.g. Alt+Tab) while capturing

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lock = threading.RLock()
        self._thread: threading.Thread | None = None
        self._thread_id = 0
        self._filter: KeyFilter | None = None
        self._target_hwnd = 0
        self._caps = False
        self._numlock = True
        self._layout = None
        self._inj_shift = False
        self._inj_ctrl = False
        self._high_surrogate = 0
        self._hook_err_logged = False
        self._quitting = False
        self._started_at = 0.0

    @property
    def available(self) -> bool:
        return _IS_WIN

    @property
    def capturing(self) -> bool:
        with self._lock:
            return self._filter is not None and self._filter.capturing

    def start(self, hotkeys=(), target_hwnd: int = 0) -> bool:
        """Install a fresh `WH_KEYBOARD_LL` hook at the head of the chain so Unikey/EVKey sits downstream."""
        if not _IS_WIN:
            return False
        t0 = time.monotonic()
        try:
            # Always recreate the hook on open so our hook stays ahead of Unikey/EVKey in LIFO hook order.
            if self._thread is not None and self._thread.is_alive():
                self._quit()
                self._thread.join(0.5)
            held = {vk for vk in range(1, 255) if vk not in _MODIFIERS and _pressed(vk)}
            self._layout, self._caps, self._numlock = self._foreground_keyboard_state()
            with self._lock:
                self._filter = KeyFilter(hotkeys, held)
                self._target_hwnd = int(target_hwnd or 0)
                self._inj_shift = False
                self._inj_ctrl = False
                self._high_surrogate = 0
                self._hook_err_logged = False
                self._quitting = False
            ready = threading.Event()
            result = {"ok": False}
            self._thread = threading.Thread(
                target=self._run, args=(ready, result), name="SteamChat-KeyHook", daemon=True
            )
            self._thread.start()
            ready.wait(2.0)
            if not result["ok"]:
                with self._lock:
                    self._filter = None
                logger.warning(
                    f"{TAG} Keyboard capture failed to start in {(time.monotonic() - t0) * 1000:.1f}ms"
                )
                return False
            self._started_at = t0
            logger.info(
                f"{TAG} Keyboard capture started in {(time.monotonic() - t0) * 1000:.1f}ms "
                f"(target={self._target_hwnd:#x}, held={len(held)})"
            )
            return True
        except Exception:
            with self._lock:
                self._filter = None
            logger.exception(f"{TAG} Unexpected error starting keyboard capture")
            return False

    def stop(self) -> None:
        """Stop capturing; linger up to `_DRAIN_SECONDS` only if swallowed keys (e.g. Enter/Esc) are still down."""
        with self._lock:
            if self._filter is None or not self._filter.capturing:
                return
            self._filter.capturing = False
            self._target_hwnd = 0
            drained = self._filter.drained
            pending = len(self._filter.swallowed)
        elapsed = (time.monotonic() - self._started_at) if self._started_at else 0.0
        if drained:
            self._quit()
        else:
            timer = threading.Timer(_DRAIN_SECONDS, self._quit_if_idle)
            timer.daemon = True
            timer.start()
        logger.info(f"{TAG} Keyboard capture stopped after {elapsed:.2f}s (draining={pending})")

    def shutdown(self) -> None:
        with self._lock:
            self._filter = None
            self._target_hwnd = 0
        self._quit()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(1.0)

    def _quit_if_idle(self) -> None:
        try:
            with self._lock:
                if self._filter is not None and self._filter.capturing:
                    return
            self._quit()
        except Exception:
            logger.exception(f"{TAG} Error while draining keyboard capture")

    def _quit(self) -> None:
        self._quitting = True
        tid = self._thread_id
        if tid and _IS_WIN:
            _user32.PostThreadMessageW(tid, _WM_QUIT, 0, 0)

    def _run(self, ready: threading.Event, result: dict) -> None:
        hook = None
        try:
            self._thread_id = _kernel32.GetCurrentThreadId()
            proc = _HOOKPROC(self._hook)        # keep ctypes callback alive while installed
            hook = _user32.SetWindowsHookExW(_WH_KEYBOARD_LL, proc, _kernel32.GetModuleHandleW(None), 0)
            if not hook:
                err = ctypes.get_last_error()
                logger.warning(f"{TAG} SetWindowsHookExW(WH_KEYBOARD_LL) failed (win32_error={err})")
                ready.set()
                return
            result["ok"] = True
            ready.set()
            msg = wintypes.MSG()
            while _user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                pass
        except Exception:
            logger.exception(f"{TAG} Keyboard hook thread crashed")
            ready.set()
        finally:
            if hook:
                _user32.UnhookWindowsHookEx(hook)
            with self._lock:
                if self._filter is not None and not self._filter.capturing:
                    self._filter = None
            self._thread_id = 0

    def _hook(self, code: int, wparam: int, lparam: int) -> int:
        if code != 0 or wparam not in (_WM_KEYDOWN, _WM_KEYUP, _WM_SYSKEYDOWN, _WM_SYSKEYUP):
            return _user32.CallNextHookEx(None, code, wparam, lparam)
        try:
            info = _KBDLLHOOKSTRUCT.from_address(lparam)
            down = wparam in (_WM_KEYDOWN, _WM_SYSKEYDOWN)
            if bool(info.flags & _LLKHF_INJECTED):
                if self._handle_injected(int(info.vkCode), int(info.scanCode), down):
                    return 1
                return _user32.CallNextHookEx(None, code, wparam, lparam)
            return self._handle_physical(code, wparam, lparam, int(info.vkCode), int(info.scanCode), down)
        except Exception:
            if not self._hook_err_logged:
                self._hook_err_logged = True
                logger.exception(f"{TAG} Keyboard hook callback failed")
            return _user32.CallNextHookEx(None, code, wparam, lparam)

    def _handle_injected(self, vk: int, scan: int, down: bool) -> bool:
        """Capture keystrokes synthesized via SendInput by Unikey/EVKey (`VK_BACK`, `VK_PACKET`, clipboard)."""
        with self._lock:
            flt = self._filter
            if flt is None or not flt.capturing:
                return False
        if vk in _SHIFT_VKS:
            self._inj_shift = down
            return True
        if vk in _CTRL_VKS:
            self._inj_ctrl = down
            return True
        if vk in _MODIFIERS:
            return True
        if not down:
            return True
        if vk == VK_PACKET:
            text = self._decode_packet(scan)
            if text:
                self.key.emit(KeyStroke(vk=VK_PACKET, text=text, injected=True))
            return True
        if vk == VK_BACK:
            self.key.emit(KeyStroke(vk=VK_BACK, injected=True))
            return True
        ctrl = self._inj_ctrl
        shift = self._inj_shift or _pressed(VK_SHIFT)
        text = "" if ctrl else self._to_text(vk, scan, shift)
        self.key.emit(KeyStroke(vk=vk, text=text, ctrl=ctrl, shift=shift, injected=True))
        return True

    def _handle_physical(self, code: int, wparam: int, lparam: int, vk: int, scan: int, down: bool) -> int:
        if not down:
            if vk in _SHIFT_VKS:
                self._inj_shift = False
            elif vk in _CTRL_VKS:
                self._inj_ctrl = False

        if down and self._target_hwnd:
            fg = int(_user32.GetForegroundWindow() or 0)
            if fg and fg != self._target_hwnd and not win32.is_own_window(fg):
                lost = False
                with self._lock:
                    if self._filter is not None and self._filter.capturing:
                        self._filter.capturing = False
                        self._target_hwnd = 0
                        lost = True
                        if self._filter.drained:
                            self._quit()
                if lost:
                    logger.warning(f"{TAG} Foreground changed to {fg:#x} while capturing; closing chat input")
                    self.target_lost.emit()
                return _user32.CallNextHookEx(None, code, wparam, lparam)

        if vk == VK_CAPITAL and down:
            self._caps = not self._caps
        elif vk == VK_NUMLOCK and down:
            self._numlock = not self._numlock

        ctrl, shift = _pressed(VK_CONTROL), _pressed(VK_SHIFT)
        alt, win = _pressed(VK_MENU), _pressed(VK_LWIN) or _pressed(VK_RWIN)

        with self._lock:
            flt = self._filter
            if flt is None:
                return _user32.CallNextHookEx(None, code, wparam, lparam)
            swallow = flt.decide(vk, down, ctrl, shift, alt, win)
            capturing = flt.capturing
            if flt.drained:
                self._quit()

        if not swallow:
            return _user32.CallNextHookEx(None, code, wparam, lparam)

        # Let Unikey / EVKey inspect non-Ctrl physical keys so it updates its syllable buffer and
        # synthesizes Vietnamese characters via SendInput (`_handle_injected`), then return 1 so
        # the foreground game never receives the raw keystroke.
        ime_consumed = False
        if not ctrl:
            ime_consumed = bool(_user32.CallNextHookEx(None, code, wparam, lparam))

        if down and capturing and not ime_consumed:
            text = "" if ctrl else self._to_text(vk, scan, shift)
            self.key.emit(KeyStroke(vk=vk, text=text, ctrl=ctrl, shift=shift, injected=False))
        return 1

    def _decode_packet(self, code_unit: int) -> str:
        """Decode UTF-16 `VK_PACKET` scanCode (BMP Vietnamese characters + surrogate-pair emojis)."""
        if 0xD800 <= code_unit <= 0xDBFF:
            self._high_surrogate = code_unit
            return ""
        if 0xDC00 <= code_unit <= 0xDFFF:
            hi, self._high_surrogate = self._high_surrogate, 0
            if hi:
                return chr(0x10000 + ((hi - 0xD800) << 10) + (code_unit - 0xDC00))
            return ""
        self._high_surrogate = 0
        if code_unit < 0x20 or code_unit == 0x7F:
            return ""
        return chr(code_unit)

    def _to_text(self, vk: int, scan: int, shift: bool) -> str:
        if vk in (VK_BACK, VK_TAB, VK_RETURN, VK_ESCAPE):
            return ""
        scan = scan or int(_user32.MapVirtualKeyExW(vk, 0, self._layout))
        state = (ctypes.c_ubyte * 256)()
        if shift:
            state[VK_SHIFT] = 0x80
        if self._caps:
            state[VK_CAPITAL] = 0x01
        if self._numlock:
            state[VK_NUMLOCK] = 0x01
        buf = ctypes.create_unicode_buffer(8)
        # flag 4: do not alter kernel/thread dead-key state
        n = _user32.ToUnicodeEx(vk, scan, state, buf, 8, 4, self._layout)
        text = buf.value[:n] if n > 0 else ""
        return "".join(ch for ch in text if ord(ch) >= 0x20 and ord(ch) != 0x7F)

    @staticmethod
    def _foreground_keyboard_state():
        hwnd = _user32.GetForegroundWindow()
        thread = _user32.GetWindowThreadProcessId(hwnd, None) if hwnd else 0
        layout = _user32.GetKeyboardLayout(thread)
        caps = bool(_user32.GetKeyState(VK_CAPITAL) & 1)
        numlock = bool(_user32.GetKeyState(VK_NUMLOCK) & 1)
        return layout, caps, numlock
