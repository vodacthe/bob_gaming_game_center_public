"""System-wide hotkeys via RegisterHotKey (thread message queue) + a Qt native event filter.

RegisterHotKey works for games running in the foreground without hooks or injection. The key
combination is consumed system-wide while registered, so defaults avoid plain keys like Enter.
"""

from __future__ import annotations

import logging
import sys
import threading
import time

from PySide6.QtCore import QAbstractNativeEventFilter, QCoreApplication, QObject, QTimer, Qt, Signal
from PySide6.QtGui import QKeySequence

logger = logging.getLogger(__name__)

_IS_WIN = sys.platform == "win32"
if _IS_WIN:
    import ctypes
    from ctypes import wintypes

    _user32 = ctypes.WinDLL("user32", use_last_error=True)
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    class _KBDLLHOOKSTRUCT(ctypes.Structure):
        _fields_ = [
            ("vkCode", wintypes.DWORD),
            ("scanCode", wintypes.DWORD),
            ("flags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.c_size_t),
        ]

    _HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
    _user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_uint, ctypes.c_uint]
    _user32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
    _user32.SetWindowsHookExW.restype = wintypes.HHOOK
    _user32.SetWindowsHookExW.argtypes = [ctypes.c_int, _HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
    _user32.CallNextHookEx.restype = ctypes.c_ssize_t
    _user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
    _user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
    _user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
    _user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    _user32.GetAsyncKeyState.restype = ctypes.c_short
    _user32.GetForegroundWindow.restype = wintypes.HWND
    _kernel32.GetCurrentThreadId.restype = wintypes.DWORD
    _kernel32.GetModuleHandleW.restype = wintypes.HMODULE
    _kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]

WM_HOTKEY = 0x0312
MOD_ALT, MOD_CONTROL, MOD_SHIFT, MOD_WIN, MOD_NOREPEAT = 0x1, 0x2, 0x4, 0x8, 0x4000

_WH_KEYBOARD_LL = 13
_WM_KEYDOWN, _WM_KEYUP, _WM_SYSKEYDOWN, _WM_SYSKEYUP, _WM_QUIT = 0x0100, 0x0101, 0x0104, 0x0105, 0x0012
_LLKHF_INJECTED, _LLKHF_ALTDOWN = 0x10, 0x20

_SHIFT_VKS = frozenset({0x10, 0xA0, 0xA1})
_CTRL_VKS = frozenset({0x11, 0xA2, 0xA3})
_ALT_VKS = frozenset({0x12, 0xA4, 0xA5})
_WIN_VKS = frozenset({0x5B, 0x5C})
_MOD_GROUPS = (
    (0x10, _SHIFT_VKS),
    (0x11, _CTRL_VKS),
    (0x12, _ALT_VKS),
)
_ALL_MOD_VKS = _SHIFT_VKS | _CTRL_VKS | _ALT_VKS | _WIN_VKS
_DEDUP_SECONDS = 0.08
_WM_HOTKEY_GRACE_MS = 40


def _pressed(vk: int) -> bool:
    if not _IS_WIN:
        return False
    return bool(_user32.GetAsyncKeyState(vk) & 0x8000)

_K = Qt.Key
_VK_BY_QT_KEY = {
    _K.Key_Return: 0x0D, _K.Key_Enter: 0x0D, _K.Key_Space: 0x20, _K.Key_Tab: 0x09,
    _K.Key_Backspace: 0x08, _K.Key_Escape: 0x1B, _K.Key_Insert: 0x2D, _K.Key_Delete: 0x2E,
    _K.Key_Home: 0x24, _K.Key_End: 0x23, _K.Key_PageUp: 0x21, _K.Key_PageDown: 0x22,
    _K.Key_Left: 0x25, _K.Key_Up: 0x26, _K.Key_Right: 0x27, _K.Key_Down: 0x28,
    _K.Key_Pause: 0x13, _K.Key_ScrollLock: 0x91,
    _K.Key_QuoteLeft: 0xC0, _K.Key_AsciiTilde: 0xC0, _K.Key_Minus: 0xBD, _K.Key_Equal: 0xBB,
    _K.Key_BracketLeft: 0xDB, _K.Key_BracketRight: 0xDD, _K.Key_Backslash: 0xDC,
    _K.Key_Semicolon: 0xBA, _K.Key_Apostrophe: 0xDE, _K.Key_Comma: 0xBC, _K.Key_Period: 0xBE,
    _K.Key_Slash: 0xBF,
}


def parse_hotkey(text: str) -> tuple[int, int] | None:
    """'Ctrl+Return' (QKeySequence portable text) -> (MOD_* flags, virtual-key). None if unsupported."""
    if not text:
        return None
    seq = QKeySequence.fromString(text, QKeySequence.SequenceFormat.PortableText)
    if seq.count() != 1:
        return None
    combo = seq[0]
    key, mods = combo.key(), combo.keyboardModifiers()
    value = int(key.value) if hasattr(key, "value") else int(key)
    if int(_K.Key_A.value) <= value <= int(_K.Key_Z.value) or int(_K.Key_0.value) <= value <= int(_K.Key_9.value):
        vk = value
    elif int(_K.Key_F1.value) <= value <= int(_K.Key_F24.value):
        vk = 0x70 + value - int(_K.Key_F1.value)
    else:
        vk = _VK_BY_QT_KEY.get(key)
    if vk is None:
        return None
    flags = 0
    if mods & Qt.KeyboardModifier.ControlModifier:
        flags |= MOD_CONTROL
    if mods & Qt.KeyboardModifier.AltModifier:
        flags |= MOD_ALT
    if mods & Qt.KeyboardModifier.ShiftModifier:
        flags |= MOD_SHIFT
    if mods & Qt.KeyboardModifier.MetaModifier:
        flags |= MOD_WIN
    return flags, vk


def display_hotkey(text: str) -> str:
    seq = QKeySequence.fromString(text or "", QKeySequence.SequenceFormat.PortableText)
    return seq.toString(QKeySequence.SequenceFormat.NativeText) or "—"


class _Filter(QAbstractNativeEventFilter):
    def __init__(self, manager: "GlobalHotkeys"):
        super().__init__()
        self._manager = manager

    def nativeEventFilter(self, event_type, message):
        if event_type == b"windows_generic_MSG" or event_type == "windows_generic_MSG":
            try:
                msg = wintypes.MSG.from_address(int(message))
                if msg.message == WM_HOTKEY and not msg.hWnd:
                    self._manager._dispatch(int(msg.wParam))
            except Exception:
                pass
        return False, 0


def _discard_mod_vk(mods: set[int], vk: int) -> None:
    mods.discard(vk)
    for generic, group in _MOD_GROUPS:
        if vk == generic:
            mods.difference_update(group)
        elif vk in group:
            mods.discard(generic)


class GlobalHotkeys(QObject):
    """Named hotkeys. `triggered(name)` fires on the GUI thread. Must be used from the GUI thread."""

    triggered = Signal(str)
    _ll_hotkey = Signal(str, bool)

    _BASE_ID = 0xB0B0

    def __init__(self, parent=None):
        super().__init__(parent)
        self._ids: dict[str, int] = {}
        self._names: dict[int, str] = {}
        self._next_id = self._BASE_ID
        self._filter = None

        self._lock = threading.RLock()
        self._combos: dict[tuple[int, int], str] = {}
        self._combo_by_name: dict[str, tuple[int, int]] = {}
        self._watched_vks: frozenset[int] = frozenset()
        self._swallow_mode = False
        self._mod_vks_down: set[int] = set()
        self._mod_fg_hwnd = 0
        self._active_vks: set[int] = set()
        self._swallowed_vks: set[int] = set()
        self._last_fired: dict[str, float] = {}

        self._hook_thread: threading.Thread | None = None
        self._hook_tid = 0
        self._hook_quitting = False
        self._hook_err_logged = False

        self._ll_hotkey.connect(self._on_ll_hotkey)
        if _IS_WIN:
            app = QCoreApplication.instance()
            if app is not None:
                self._filter = _Filter(self)
                app.installNativeEventFilter(self._filter)

    def register(self, name: str, hotkey: str) -> bool:
        """(Re)bind `name`. Returns False when the combination is invalid or taken by another app."""
        self.unregister(name)
        parsed = parse_hotkey(hotkey)
        if parsed is None or not _IS_WIN:
            return False
        flags, vk = parsed
        hotkey_id = self._next_id
        self._next_id += 1
        if not _user32.RegisterHotKey(None, hotkey_id, flags | MOD_NOREPEAT, vk):
            logger.warning(f"[SteamChat] Hotkey {hotkey!r} for {name} is unavailable "
                           f"(error {ctypes.get_last_error()})")
            return False
        self._ids[name] = hotkey_id
        self._names[hotkey_id] = name
        with self._lock:
            self._combo_by_name[name] = (flags, vk)
            self._combos[(flags, vk)] = name
            self._watched_vks = frozenset(k for _, k in self._combos)
        self._ensure_hook()
        logger.info(f"[SteamChat] Hotkey {hotkey} -> {name}")
        return True

    def unregister(self, name: str) -> None:
        hotkey_id = self._ids.pop(name, None)
        with self._lock:
            combo = self._combo_by_name.pop(name, None)
            if combo is not None and self._combos.get(combo) == name:
                self._combos.pop(combo, None)
            self._watched_vks = frozenset(k for _, k in self._combos)
            has_combos = bool(self._combos)
        if hotkey_id is not None:
            self._names.pop(hotkey_id, None)
            if _IS_WIN:
                _user32.UnregisterHotKey(None, hotkey_id)
        if not has_combos:
            self._stop_hook()

    def unregister_all(self) -> None:
        for name in list(self._ids):
            self.unregister(name)
        self._stop_hook()

    def sync_foreground_capture(self, swallow: bool, reassert: bool = False) -> None:
        """Enable direct LL-hook hotkey consumption over fullscreen / captured-cursor games."""
        with self._lock:
            self._swallow_mode = bool(swallow)
            has_combos = bool(self._combos)
        if reassert and has_combos:
            self.reassert_hook()

    def reassert_hook(self) -> None:
        """Reinstall the WH_KEYBOARD_LL hook so it stays ahead of game DirectInput8 hooks."""
        if not _IS_WIN:
            return
        with self._lock:
            if not self._combos:
                return
        self._stop_hook()
        self._ensure_hook()

    def snapshot_held_state(self) -> tuple[set[int], set[int]]:
        """Return currently depressed (hotkey_vks, modifier_vks) for handing off to KeyboardCapture."""
        with self._lock:
            return set(self._active_vks), set(self._mod_vks_down)

    def close(self) -> None:
        self.unregister_all()
        self._stop_hook()
        app = QCoreApplication.instance()
        if self._filter is not None and app is not None:
            app.removeNativeEventFilter(self._filter)
            self._filter = None

    def _fire(self, name: str) -> bool:
        if not name or name not in self._ids:
            return False
        now = time.monotonic()
        if now - self._last_fired.get(name, 0.0) < _DEDUP_SECONDS:
            return False
        self._last_fired[name] = now
        self.triggered.emit(name)
        return True

    def _dispatch(self, hotkey_id: int) -> None:
        name = self._names.get(hotkey_id)
        if name:
            self._fire(name)

    def _on_ll_hotkey(self, name: str, immediate: bool) -> None:
        try:
            if name not in self._ids:
                return
            if immediate:
                self._fire(name)
                return
            t0 = time.monotonic()
            QTimer.singleShot(_WM_HOTKEY_GRACE_MS, lambda n=name, ts=t0: self._check_deferred_ll(n, ts))
        except Exception:
            logger.exception("[SteamChat] Failed handling low-level hotkey event")

    def _check_deferred_ll(self, name: str, t0: float) -> None:
        try:
            if name not in self._ids:
                return
            if self._last_fired.get(name, 0.0) >= t0 - 0.01:
                return
            logger.info(f"[SteamChat] Hotkey {name} recovered via low-level hook fallback; reasserting hook order")
            self.reassert_hook()
            self._fire(name)
        except Exception:
            logger.exception("[SteamChat] Deferred hotkey recovery failed")

    def _ensure_hook(self) -> None:
        if not _IS_WIN:
            return
        with self._lock:
            if not self._combos:
                return
            if self._hook_thread is not None and self._hook_thread.is_alive():
                return
            self._hook_quitting = False
            self._hook_err_logged = False
        ready = threading.Event()
        result = {"ok": False}
        thread = threading.Thread(target=self._run_hook, args=(ready, result), name="SteamChat-HotkeyHook", daemon=True)
        with self._lock:
            self._hook_thread = thread
        thread.start()
        ready.wait(2.0)

    def _stop_hook(self) -> None:
        with self._lock:
            self._hook_quitting = True
            tid = self._hook_tid
            thread = self._hook_thread
            self._hook_tid = 0
            self._hook_thread = None
            self._active_vks.clear()
            self._swallowed_vks.clear()
        if tid and _IS_WIN:
            _user32.PostThreadMessageW(tid, _WM_QUIT, 0, 0)
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(0.5)

    def _run_hook(self, ready: threading.Event, result: dict) -> None:
        hook = None
        my_tid = 0
        try:
            my_tid = int(_kernel32.GetCurrentThreadId())
            with self._lock:
                if self._hook_quitting:
                    ready.set()
                    return
                self._hook_tid = my_tid
            proc = _HOOKPROC(self._hook)        # keep ctypes callback alive while installed
            hook = _user32.SetWindowsHookExW(_WH_KEYBOARD_LL, proc, _kernel32.GetModuleHandleW(None), 0)
            if not hook:
                err = ctypes.get_last_error()
                logger.warning(f"[SteamChat] Low-level hotkey hook failed (win32_error={err})")
                ready.set()
                return
            result["ok"] = True
            ready.set()
            msg = wintypes.MSG()
            while _user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                pass
        except Exception:
            logger.exception("[SteamChat] Low-level hotkey hook thread crashed")
            ready.set()
        finally:
            if hook:
                _user32.UnhookWindowsHookEx(hook)
            with self._lock:
                if self._hook_tid == my_tid:
                    self._hook_tid = 0

    def _sync_fg_mods(self, fg: int) -> None:
        old_fg = self._mod_fg_hwnd
        if fg != old_fg:
            if old_fg and self._mod_vks_down:
                self._mod_vks_down = {m for m in self._mod_vks_down if _pressed(m)}
            self._mod_fg_hwnd = fg

    def _hook(self, code: int, wparam: int, lparam: int) -> int:
        if code != 0 or wparam not in (_WM_KEYDOWN, _WM_KEYUP, _WM_SYSKEYDOWN, _WM_SYSKEYUP):
            return _user32.CallNextHookEx(None, code, wparam, lparam)
        try:
            info = _KBDLLHOOKSTRUCT.from_address(lparam)
            if info.flags & _LLKHF_INJECTED:
                return _user32.CallNextHookEx(None, code, wparam, lparam)
            vk = int(info.vkCode)
            down = wparam in (_WM_KEYDOWN, _WM_SYSKEYDOWN)

            if vk in _ALL_MOD_VKS:
                fg = int(_user32.GetForegroundWindow() or 0) if down else 0
                with self._lock:
                    if down:
                        self._sync_fg_mods(fg)
                        self._mod_vks_down.add(vk)
                    else:
                        _discard_mod_vk(self._mod_vks_down, vk)
                return _user32.CallNextHookEx(None, code, wparam, lparam)

            if vk not in self._watched_vks:
                return _user32.CallNextHookEx(None, code, wparam, lparam)

            if not down:
                swallow_up = False
                with self._lock:
                    self._active_vks.discard(vk)
                    if vk in self._swallowed_vks:
                        self._swallowed_vks.discard(vk)
                        swallow_up = True
                return 1 if swallow_up else _user32.CallNextHookEx(None, code, wparam, lparam)

            fg = int(_user32.GetForegroundWindow() or 0)
            with self._lock:
                self._sync_fg_mods(fg)
                ctrl = bool(self._mod_vks_down & _CTRL_VKS) or _pressed(0x11)
                shift = bool(self._mod_vks_down & _SHIFT_VKS) or _pressed(0x10)
                alt = bool(self._mod_vks_down & _ALT_VKS) or bool(info.flags & _LLKHF_ALTDOWN) or _pressed(0x12)
                win = bool(self._mod_vks_down & _WIN_VKS) or _pressed(0x5B) or _pressed(0x5C)
                mods = (
                    (MOD_ALT if alt else 0)
                    | (MOD_CONTROL if ctrl else 0)
                    | (MOD_SHIFT if shift else 0)
                    | (MOD_WIN if win else 0)
                )
                name = self._combos.get((mods, vk))
                if not name:
                    return _user32.CallNextHookEx(None, code, wparam, lparam)
                already_down = vk in self._active_vks
                self._active_vks.add(vk)
                swallow = self._swallow_mode
                if swallow:
                    self._swallowed_vks.add(vk)

            if swallow:
                if not already_down:
                    self._ll_hotkey.emit(name, True)
                return 1

            next_res = _user32.CallNextHookEx(None, code, wparam, lparam)
            if not already_down:
                self._ll_hotkey.emit(name, bool(next_res != 0))
            return next_res
        except Exception:
            if not self._hook_err_logged:
                self._hook_err_logged = True
                logger.exception("[SteamChat] Hotkey hook callback failed")
            return _user32.CallNextHookEx(None, code, wparam, lparam)
