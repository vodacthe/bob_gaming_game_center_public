"""In-app Android App & Game Store screen for Bob Gaming Game Center (Windows + Linux)."""

from __future__ import annotations

from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
import logging
import os
import time
import urllib.request

from PySide6.QtCore import QEvent, QObject, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QImage, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from app.core.android.manager import AndroidManager, get_android_manager
from app.core.android.models import (
    ACTIVE_ANDROID_STATUSES,
    CATEGORY_ALL,
    CATEGORY_APPS,
    CATEGORY_GAMES,
    CATEGORY_INSTALLED,
    RUNTIME_PORTABLE_SDK,
    RUNTIME_SYSTEM_SDK,
    SOURCE_LABELS,
    AndroidApp,
    AndroidError,
    AndroidTaskStatus,
    RuntimeInfo,
    is_valid_android_root,
)
from app.core.android.runtime import check_virtualization_hint, get_emulator_settings
from app.core.android.store_client import DEFAULT_HEADERS
from app.core.online_fix.aria2_downloader import format_bytes
from app.ui.android_player_widget import AndroidPlayerPanel, ElidedTextLabel
from app.ui.flow_layout import FlowLayout
from app.ui.game_card import DARK_BTN_STYLE, GREEN_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.online_fix.common import Task, safe_slot
from app.ui.screen_header import CONTENT_MARGINS, CONTENT_SPACING, ScreenHeader

logger = logging.getLogger(__name__)
TAG = "[Android/UI]"

ICON_SIZE = 44
ICON_RADIUS = 10
CARD_WIDTH = 228
CARD_HEIGHT = 126

UI_PAGE_SIZE = 24
INITIAL_POOL_PAGES = 5
EXTEND_BATCH_PAGES = 3
PREFETCH_AHEAD_PAGES = 2
SOURCE_PER_PAGE = 36

_PAGE_NUM_ACTIVE = """
    QPushButton {
        background-color: rgba(139, 92, 246, 0.30);
        border: 1px solid rgba(168, 85, 247, 0.88);
        border-radius: 8px;
        color: #ffffff;
        font-weight: 700;
        font-size: 12px;
        min-width: 34px;
        padding: 0 8px;
    }
"""

_PAGE_NUM_IDLE = """
    QPushButton {
        background-color: rgba(18, 24, 38, 0.78);
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 8px;
        color: #cbd5e1;
        font-weight: 600;
        font-size: 12px;
        min-width: 34px;
        padding: 0 8px;
    }
    QPushButton:hover {
        background-color: rgba(30, 41, 59, 0.92);
        border-color: rgba(139, 92, 246, 0.50);
        color: #ffffff;
    }
"""


def _merge_unique_apps(existing: list[AndroidApp], incoming: list[AndroidApp]) -> tuple[list[AndroidApp], int]:
    """Merge `incoming` into `existing` deduplicated by lowercase package_name; returns (merged, added_count)."""
    out = list(existing)
    by_pkg = {a.package_name.lower(): a for a in out}
    added = 0
    for item in incoming:
        key = item.package_name.lower()
        cur = by_pkg.get(key)
        if cur is None:
            by_pkg[key] = item
            out.append(item)
            added += 1
        else:
            if not cur.icon_url and item.icon_url:
                cur.icon_url = item.icon_url
            if not cur.download_url and item.download_url:
                cur.download_url = item.download_url
            if not cur.version and item.version:
                cur.version = item.version
            if not cur.size_bytes and item.size_bytes:
                cur.size_bytes = item.size_bytes
    return out, added

_CHIP_ACTIVE = """
    QPushButton {
        background-color: rgba(139, 92, 246, 0.24);
        border: 1px solid rgba(168, 85, 247, 0.78);
        border-radius: 8px;
        color: #ffffff;
        font-weight: 700;
        font-size: 12px;
        padding: 0 14px;
    }
    QPushButton:hover { background-color: rgba(139, 92, 246, 0.34); }
"""

_CHIP_IDLE = """
    QPushButton {
        background-color: rgba(18, 24, 38, 0.78);
        border: 1px solid rgba(255, 255, 255, 0.09);
        border-radius: 8px;
        color: #cbd5e1;
        font-weight: 600;
        font-size: 12px;
        padding: 0 14px;
    }
    QPushButton:hover {
        background-color: rgba(30, 41, 59, 0.90);
        border-color: rgba(139, 92, 246, 0.45);
        color: #ffffff;
    }
"""

_PANEL_STYLE = """
    #androidRuntimePanel {
        background-color: rgba(16, 21, 34, 0.82);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
    }
    #androidCard {
        background-color: rgba(17, 22, 35, 0.86);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 14px;
    }
    #androidCard:hover {
        border: 1px solid rgba(139, 92, 246, 0.50);
        background-color: rgba(22, 28, 45, 0.94);
    }
"""

_SEARCH_STYLE = """
    QLineEdit {
        background-color: rgba(18, 24, 38, 0.92);
        border: 1px solid rgba(139, 92, 246, 0.45);
        border-radius: 8px;
        padding: 0 12px;
        color: #ffffff;
        font-size: 12px;
    }
    QLineEdit:focus { border: 1px solid #a855f7; }
"""

_COMBO_STYLE = """
    QComboBox {
        background-color: rgba(22, 28, 44, 0.92);
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 8px;
        padding: 4px 10px;
        color: #f1f5f9;
        font-size: 12px;
        min-height: 26px;
    }
    QComboBox QAbstractItemView {
        background-color: #131826;
        color: #f1f5f9;
        selection-background-color: #6d28d9;
    }
"""

_PROGRESS_STYLE = """
    QProgressBar {
        background-color: rgba(255, 255, 255, 0.07);
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 6px;
        text-align: center;
        color: #ffffff;
        font-size: 11px;
        font-weight: 700;
        min-height: 18px;
        max-height: 18px;
    }
    QProgressBar::chunk {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8b5cf6, stop:1 #10b981);
        border-radius: 5px;
    }
"""


class _IconLoader(QObject):
    """Off-UI-thread rounded icon loader emitting raw PNG/ARGB bytes via queued signal."""

    loaded = Signal(str, object)

    def __init__(self):
        super().__init__(None)
        self._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="android-icon")
        self._pix_cache: OrderedDict[str, QPixmap] = OrderedDict()
        self._inflight: set[str] = set()

    def get_cached(self, url: str) -> QPixmap | None:
        return self._pix_cache.get(url)

    def store_pixmap(self, url: str, qimg: QImage) -> QPixmap:
        pix = QPixmap.fromImage(qimg)
        self._pix_cache[url] = pix
        while len(self._pix_cache) > 250:
            self._pix_cache.popitem(last=False)
        return pix

    def request(self, url: str) -> None:
        u = (url or "").strip()
        if not u or u in self._pix_cache or u in self._inflight:
            return
        if os.environ.get("BOBGAMING_ANDROID_DISABLE") == "1":
            return
        self._inflight.add(u)

        def _fetch():
            try:
                req = urllib.request.Request(u, headers=DEFAULT_HEADERS)
                with urllib.request.urlopen(req, timeout=10.0) as r:
                    raw = r.read()
                src = QImage.fromData(raw)
                if src.isNull():
                    return
                scaled = src.scaled(
                    ICON_SIZE,
                    ICON_SIZE,
                    Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                    Qt.TransformationMode.SmoothTransformation,
                )
                out = QImage(ICON_SIZE, ICON_SIZE, QImage.Format.Format_ARGB32_Premultiplied)
                out.fill(Qt.GlobalColor.transparent)
                p = QPainter(out)
                p.setRenderHint(QPainter.RenderHint.Antialiasing)
                path = QPainterPath()
                path.addRoundedRect(QRectF(0, 0, ICON_SIZE, ICON_SIZE), ICON_RADIUS, ICON_RADIUS)
                p.setClipPath(path)
                ox = max(0, (scaled.width() - ICON_SIZE) // 2)
                oy = max(0, (scaled.height() - ICON_SIZE) // 2)
                p.drawImage(0, 0, scaled, ox, oy, ICON_SIZE, ICON_SIZE)
                p.end()
                self.loaded.emit(u, out)
            except Exception:
                pass
            finally:
                self._inflight.discard(u)

        self._pool.submit(_fetch)


_icon_loader = _IconLoader()


class AndroidAppCard(QFrame):
    """Compact glass card representing one Android game or app."""

    install_clicked = Signal(object)
    launch_clicked = Signal(str, str, str)
    uninstall_clicked = Signal(str, str, str)

    def __init__(
        self,
        app: AndroidApp,
        installed_meta: dict | None = None,
        active_progress: int | None = None,
        is_launching: bool = False,
        parent=None,
    ):
        super().__init__(parent)
        self.app_data = app
        self._installed_meta = installed_meta
        self.setObjectName("androidCard")
        self.setFixedSize(CARD_WIDTH, CARD_HEIGHT)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 9, 10, 9)
        root.setSpacing(5)

        top = QHBoxLayout()
        top.setSpacing(9)

        self.icon_lbl = QLabel()
        self.icon_lbl.setFixedSize(ICON_SIZE, ICON_SIZE)
        self.icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.icon_lbl.setStyleSheet(
            "background-color: rgba(139, 92, 246, 0.14); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px;"
        )
        fallback_icon = "gamepad" if app.kind == CATEGORY_GAMES else "android"
        self.icon_lbl.setPixmap(make_svg_pixmap(fallback_icon, size=22, color="#a855f7"))
        if app.poster_url:
            cached = _icon_loader.get_cached(app.poster_url)
            if cached is not None and not cached.isNull():
                self.icon_lbl.setPixmap(cached)
            else:
                _icon_loader.request(app.poster_url)
        top.addWidget(self.icon_lbl)

        meta_col = QVBoxLayout()
        meta_col.setSpacing(1)

        title_lbl = QLabel()
        title_font = QFont("Segoe UI", 10, QFont.Weight.Bold)
        title_lbl.setFont(title_font)
        title_lbl.setStyleSheet("color: #f8fafc; background: transparent; border: none;")
        fm = QFontMetrics(title_font)
        title_lbl.setText(fm.elidedText(app.name, Qt.TextElideMode.ElideRight, 152))
        title_lbl.setToolTip(f"{app.name} ({app.package_name})")
        meta_col.addWidget(title_lbl)

        src_name = SOURCE_LABELS.get(app.source, app.source.upper())
        kind_label = "Trò chơi" if app.kind == CATEGORY_GAMES else "Ứng dụng"
        parts = [kind_label, src_name]
        if app.version:
            parts.append(f"v{app.version}")
        if app.size_bytes > 0:
            parts.append(format_bytes(app.size_bytes))
        sub_lbl = QLabel(fm.elidedText(" · ".join(parts), Qt.TextElideMode.ElideRight, 152))
        sub_lbl.setStyleSheet("color: #94a3b8; font-size: 10px; background: transparent; border: none;")
        meta_col.addWidget(sub_lbl)

        pkg_lbl = QLabel(fm.elidedText(app.package_name, Qt.TextElideMode.ElideRight, 152))
        pkg_lbl.setStyleSheet("color: #64748b; font-size: 9px; background: transparent; border: none;")
        meta_col.addWidget(pkg_lbl)
        meta_col.addStretch()

        top.addLayout(meta_col, 1)
        root.addLayout(top)

        desc_text = (app.summary or "Tải về và tự động cài vào Android Runtime trên máy.").strip()
        desc_font = QFont("Segoe UI", 9)
        desc_fm = QFontMetrics(desc_font)
        desc_lbl = QLabel(desc_fm.elidedText(desc_text, Qt.TextElideMode.ElideRight, 206))
        desc_lbl.setFont(desc_font)
        desc_lbl.setFixedHeight(16)
        desc_lbl.setToolTip(desc_text)
        desc_lbl.setStyleSheet("color: #cbd5e1; font-size: 10px; background: transparent; border: none;")
        root.addWidget(desc_lbl)

        root.addStretch()

        btn_row = QHBoxLayout()
        btn_row.setSpacing(6)

        self.primary_btn = QPushButton()
        self.primary_btn.setFixedHeight(28)
        self.primary_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.uninstall_btn = QPushButton("Gỡ")
        self.uninstall_btn.setFixedHeight(28)
        self.uninstall_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.uninstall_btn.setStyleSheet(DARK_BTN_STYLE)
        self.uninstall_btn.setFixedWidth(48)
        self.uninstall_btn.hide()

        btn_row.addWidget(self.primary_btn, 1)
        btn_row.addWidget(self.uninstall_btn)
        root.addLayout(btn_row)

        self.primary_btn.clicked.connect(self._on_primary)
        self.uninstall_btn.clicked.connect(self._on_uninstall)
        self.refresh_state(installed_meta, active_progress, is_launching=is_launching)

    def _on_primary(self) -> None:
        if self._installed_meta:
            self.launch_clicked.emit(
                self.app_data.package_name,
                self.app_data.name,
                str(self._installed_meta.get("launcher_path") or ""),
            )
        else:
            self.install_clicked.emit(self.app_data)

    def _on_uninstall(self) -> None:
        if self._installed_meta:
            self.uninstall_clicked.emit(
                self.app_data.package_name,
                self.app_data.name,
                str(self._installed_meta.get("install_dir") or ""),
            )

    def refresh_state(
        self,
        installed_meta: dict | None,
        active_progress: int | None,
        is_launching: bool = False,
    ) -> None:
        self._installed_meta = installed_meta
        if active_progress is not None:
            self.primary_btn.setEnabled(False)
            self.primary_btn.setStyleSheet(DARK_BTN_STYLE)
            self.primary_btn.setIcon(make_svg_icon("download", size=14, color="#94a3b8"))
            self.primary_btn.setText(f"Đang cài ({active_progress}%)")
            self.uninstall_btn.hide()
        elif is_launching:
            self.primary_btn.setEnabled(False)
            self.primary_btn.setStyleSheet(DARK_BTN_STYLE)
            self.primary_btn.setIcon(make_svg_icon("play", size=14, color="#fbbf24"))
            self.primary_btn.setText("Đang mở...")
            self.uninstall_btn.setVisible(bool(installed_meta))
        elif installed_meta:
            self.primary_btn.setEnabled(True)
            self.primary_btn.setStyleSheet(GREEN_BTN_STYLE)
            self.primary_btn.setIcon(make_svg_icon("play", size=14, color="#042612"))
            self.primary_btn.setText("Chơi ngay")
            self.uninstall_btn.show()
        else:
            self.primary_btn.setEnabled(True)
            self.primary_btn.setStyleSheet(PURPLE_BTN_STYLE)
            self.primary_btn.setIcon(make_svg_icon("download", size=14, color="#ffffff"))
            self.primary_btn.setText("Tải && Cài đặt")
            self.uninstall_btn.hide()


class _ChipButton(QPushButton):
    """Category filter chip with accurate bold text measurement so labels never clip."""

    def __init__(self, text: str, parent: QWidget | None = None) -> None:
        super().__init__(text, parent)
        self.setFixedHeight(32)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

    def sizeHint(self) -> QSize:
        f = QFont("Segoe UI")
        f.setPixelSize(12)
        f.setBold(True)
        return QSize(QFontMetrics(f).horizontalAdvance(self.text().replace("&&", "&")) + 28, 32)

    def minimumSizeHint(self) -> QSize:
        return self.sizeHint()


class _FlowContainer(QWidget):
    """QWidget hosting a FlowLayout whose vertical height stays synchronized with heightForWidth()."""

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        lay = self.layout()
        if lay is not None and lay.hasHeightForWidth():
            h = max(32, lay.heightForWidth(max(120, self.width())))
            if self.minimumHeight() != h or self.maximumHeight() != h:
                self.setMinimumHeight(h)
                self.setMaximumHeight(h)


class AndroidStoreScreen(QWidget):
    """Full-screen Android App & Game Store with Center Emulator View and Right Catalog."""

    back_requested = Signal()
    settings_requested = Signal()
    launch_game_requested = Signal(dict)
    uninstall_android_requested = Signal(str, str, str)

    def __init__(self, manager: AndroidManager | None = None, parent=None):
        super().__init__(parent)
        self.manager = manager or get_android_manager()
        self._current_category = CATEGORY_ALL
        self._current_query: str = ""
        self._runtimes: list[RuntimeInfo] = []
        self._pool_apps: list[AndroidApp] = []
        self._apps: list[AndroidApp] = []
        self._cards_by_pkg: dict[str, AndroidAppCard] = {}
        self._active_task_id: str = ""
        self._request_id: int = 0
        self._current_page: int = 1
        self._next_source_page: int = 2
        self._pool_loading: bool = False
        self._pool_exhausted: bool = False
        self._wait_extend_page: bool = False
        self._page_num_btns: list[QWidget] = []
        self._user_collapsed_player: bool = False
        self._compact_catalog: bool = False
        self._compact_header: bool = False

        self.setStyleSheet(_PANEL_STYLE)
        self._build_ui()
        self._connect_signals()

        if os.environ.get("BOBGAMING_ANDROID_DISABLE") != "1":
            self.refresh_runtimes()
            self.load_catalog()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.header = ScreenHeader(
            "Kho Game & Ứng dụng Android",
            "android",
            subtitle="Chạy trực tiếp trên Windows & Linux · Tự tải và cài đặt APK / XAPK / OBB",
        )
        self.header.back_requested.connect(self.back_requested.emit)
        self.runtime_badge = self.header.add_badge("CHƯA KIỂM TRA", "off")
        self.runtime_badge.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.folder_btn = self.header.add_button("Thư mục", "secondary", icon="folder")
        self.folder_btn.setToolTip("Chọn thư mục lưu máy ảo & game Android")
        self.settings_btn = self.header.add_button("Cài đặt", "secondary", icon="settings")
        self.settings_btn.setToolTip("Mở cài đặt cấu hình máy ảo Android")
        self.refresh_btn = self.header.add_button("Làm mới", "secondary", icon="refresh")
        self.refresh_btn.setToolTip("Làm mới danh sách Engine & kho game")
        for hbtn in (self.folder_btn, self.settings_btn, self.refresh_btn):
            hbtn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        outer.addWidget(self.header)

        body = QWidget()
        self.body_widget = body
        self.body_widget.installEventFilter(self)
        body_layout = QVBoxLayout(body)
        self._body_layout = body_layout
        body_layout.setContentsMargins(*CONTENT_MARGINS)
        body_layout.setSpacing(12)

        # ---- Runtime & Transfer Panel ----
        rt_panel = QFrame()
        rt_panel.setObjectName("androidRuntimePanel")
        rt_layout = QVBoxLayout(rt_panel)
        rt_layout.setContentsMargins(14, 10, 14, 10)
        rt_layout.setSpacing(6)

        rt_row = QHBoxLayout()
        rt_row.setSpacing(8)

        self.rt_lbl = QLabel("Engine:")
        self.rt_lbl.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        self.rt_lbl.setStyleSheet(
            "color: #cbd5e1; font-size: 12px; font-weight: 700; background: transparent; border: none;"
        )
        rt_row.addWidget(self.rt_lbl)

        self.runtime_combo = QComboBox()
        self.runtime_combo.setStyleSheet(_COMBO_STYLE)
        self.runtime_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.runtime_combo.setMinimumContentsLength(4)
        self.runtime_combo.setMinimumWidth(110)
        self.runtime_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        rt_row.addWidget(self.runtime_combo, 1)

        self.runtime_action_btn = QPushButton("Cài đặt Runtime")
        self.runtime_action_btn.setFixedHeight(32)
        self.runtime_action_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.runtime_action_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.runtime_action_btn.setStyleSheet(PURPLE_BTN_STYLE)
        rt_row.addWidget(self.runtime_action_btn)

        self.player_toggle_btn = QPushButton("Màn hình Android")
        self.player_toggle_btn.setFixedHeight(32)
        self.player_toggle_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.player_toggle_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.player_toggle_btn.setStyleSheet(DARK_BTN_STYLE)
        self.player_toggle_btn.setIcon(make_svg_icon("remote", size=14, color="#cbd5e1"))
        self.player_toggle_btn.setToolTip("Ẩn / hiện màn hình Android tích hợp")
        rt_row.addWidget(self.player_toggle_btn)

        self.install_file_btn = QPushButton("Cài APK/XAPK")
        self.install_file_btn.setFixedHeight(32)
        self.install_file_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.install_file_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.install_file_btn.setStyleSheet(DARK_BTN_STYLE)
        self.install_file_btn.setIcon(make_svg_icon("package", size=14, color="#cbd5e1"))
        self.install_file_btn.setToolTip("Cài đặt tệp APK / XAPK / APKM từ máy tính")
        rt_row.addWidget(self.install_file_btn)

        rt_layout.addLayout(rt_row)

        self.root_info_lbl = ElidedTextLabel()
        self.root_info_lbl.setStyleSheet("color: #94a3b8; font-size: 11px; background: transparent; border: none;")
        rt_layout.addWidget(self.root_info_lbl)

        self.progress_widget = QWidget()
        prog_col = QVBoxLayout(self.progress_widget)
        prog_col.setContentsMargins(0, 2, 0, 0)
        prog_col.setSpacing(5)

        self.progress_lbl = ElidedTextLabel("Đang xử lý...")
        self.progress_lbl.setStyleSheet("color: #e2e8f0; font-size: 11px; background: transparent; border: none;")
        prog_col.addWidget(self.progress_lbl)

        prog_bar_row = QHBoxLayout()
        prog_bar_row.setContentsMargins(0, 0, 0, 0)
        prog_bar_row.setSpacing(8)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setMinimumWidth(100)
        self.progress_bar.setStyleSheet(_PROGRESS_STYLE)
        prog_bar_row.addWidget(self.progress_bar, 1)

        self.cancel_task_btn = QPushButton("Hủy")
        self.cancel_task_btn.setStyleSheet(DARK_BTN_STYLE)
        self.cancel_task_btn.setFixedWidth(68)
        prog_bar_row.addWidget(self.cancel_task_btn)
        prog_col.addLayout(prog_bar_row)

        self.progress_widget.hide()
        rt_layout.addWidget(self.progress_widget)
        body_layout.addWidget(rt_panel)

        # ---- Search Row (Dedicated full-width row so it never collides with category chips) ----
        search_row = QHBoxLayout()
        search_row.setSpacing(8)

        self.search_input = QLineEdit()
        self.search_input.setClearButtonEnabled(True)
        self.search_input.setPlaceholderText("Tìm game, ứng dụng hoặc nhập Package ID (vd: com.kiloo.subwaysurf)...")
        self.search_input.setFixedHeight(34)
        self.search_input.setMinimumWidth(120)
        self.search_input.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.search_input.setStyleSheet(_SEARCH_STYLE)
        search_row.addWidget(self.search_input, 1)

        self.search_btn = QPushButton("Tìm kiếm")
        self.search_btn.setFixedHeight(34)
        self.search_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.search_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.search_btn.setStyleSheet(PURPLE_BTN_STYLE)
        self.search_btn.setIcon(make_svg_icon("search", size=14, color="#ffffff"))
        search_row.addWidget(self.search_btn)

        body_layout.addLayout(search_row)

        # ---- Category Chips Row (FlowLayout wraps cleanly instead of clipping text) ----
        self.chips_host = _FlowContainer()
        self.chips_host.setStyleSheet("background: transparent;")
        self.chips_host.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.chips_flow = FlowLayout(self.chips_host, margin=0, spacing=8)

        self._chip_buttons: dict[str, QPushButton] = {}
        for cat_key, label in (
            (CATEGORY_ALL, "Tất cả"),
            (CATEGORY_GAMES, "Trò chơi Android"),
            (CATEGORY_APPS, "Ứng dụng Android"),
            (CATEGORY_INSTALLED, "Đã cài trên máy"),
        ):
            chip = _ChipButton(label, self.chips_host)
            chip.setCursor(Qt.CursorShape.PointingHandCursor)
            chip.clicked.connect(lambda _c=False, k=cat_key: self._on_select_category(k))
            self._chip_buttons[cat_key] = chip
            self.chips_flow.addWidget(chip)

        body_layout.addWidget(self.chips_host)

        # ---- Status Line & Card Grid ----
        self.status_lbl = ElidedTextLabel("Sẵn sàng.")
        self.status_lbl.setStyleSheet("color: #94a3b8; font-size: 12px; background: transparent; border: none;")
        body_layout.addWidget(self.status_lbl)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        self.grid_container = QWidget()
        self.grid_container.setStyleSheet("background: transparent;")
        self.flow_layout = FlowLayout(self.grid_container, margin=0, spacing=10)
        self.scroll.setWidget(self.grid_container)
        body_layout.addWidget(self.scroll, 1)

        # ---- Pagination Bar (Direct Page Select + Prev/Next) ----
        self.pagination_bar = QWidget()
        page_row = QHBoxLayout(self.pagination_bar)
        page_row.setContentsMargins(0, 4, 0, 0)
        page_row.setSpacing(6)
        page_row.addStretch()

        self.prev_page_btn = QPushButton("Trang trước")
        self.prev_page_btn.setFixedHeight(32)
        self.prev_page_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.prev_page_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.prev_page_btn.setStyleSheet(DARK_BTN_STYLE)
        self.prev_page_btn.setIcon(make_svg_icon("chevron_left", size=14, color="#cbd5e1"))
        self.prev_page_btn.setToolTip("Trang trước")
        page_row.addWidget(self.prev_page_btn)

        self.page_numbers_host = QWidget()
        self.page_numbers_layout = QHBoxLayout(self.page_numbers_host)
        self.page_numbers_layout.setContentsMargins(2, 0, 2, 0)
        self.page_numbers_layout.setSpacing(5)
        page_row.addWidget(self.page_numbers_host)

        self.page_info_lbl = QLabel("Trang 1 / 1")
        self.page_info_lbl.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        self.page_info_lbl.setStyleSheet(
            "color: #94a3b8; font-size: 12px; font-weight: 700; padding: 0 6px; background: transparent; border: none;"
        )
        page_row.addWidget(self.page_info_lbl)

        self.next_page_btn = QPushButton("Trang sau")
        self.next_page_btn.setFixedHeight(32)
        self.next_page_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.next_page_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.next_page_btn.setStyleSheet(DARK_BTN_STYLE)
        self.next_page_btn.setIcon(make_svg_icon("chevron_right", size=14, color="#cbd5e1"))
        self.next_page_btn.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.next_page_btn.setToolTip("Trang sau")
        page_row.addWidget(self.next_page_btn)

        page_row.addStretch()
        body_layout.addWidget(self.pagination_bar)

        # ---- Horizontal Split View: Center = Android Player (idx 0), Right = Store Catalog (idx 1) ----
        self.split_view = QSplitter(Qt.Orientation.Horizontal)
        self.split_view.setChildrenCollapsible(False)
        self.split_view.setHandleWidth(6)
        self.split_view.setStyleSheet(
            "QSplitter::handle { background-color: #141926; } "
            "QSplitter::handle:hover { background-color: #38bdf8; }"
        )

        self.player_container = QWidget()
        self._player_wrap_layout = QVBoxLayout(self.player_container)
        self._player_wrap_layout.setContentsMargins(CONTENT_MARGINS[0], 16, 8, 18)
        self._player_wrap_layout.setSpacing(0)
        self.player_panel = AndroidPlayerPanel(self.manager.runtime_mgr, self.player_container)
        self._player_wrap_layout.addWidget(self.player_panel, 1)
        self.player_container.hide()
        self.split_view.addWidget(self.player_container)

        body.setMinimumWidth(380)
        self.split_view.addWidget(body)
        self.split_view.setStretchFactor(0, 0)
        self.split_view.setStretchFactor(1, 1)

        outer.addWidget(self.split_view, 1)
        self._update_chip_styles()
        self.refresh_storage_and_hw_summary()
        self._sync_pagination_bar()

    def _connect_signals(self) -> None:
        self.player_toggle_btn.clicked.connect(self.toggle_player_pane)
        self.install_file_btn.clicked.connect(self._on_pick_local_package)
        self.folder_btn.clicked.connect(self._on_pick_install_root)
        self.settings_btn.clicked.connect(self.settings_requested.emit)
        self.refresh_btn.clicked.connect(self._on_refresh_all)
        self.runtime_combo.currentIndexChanged.connect(self._on_runtime_combo_changed)
        self.runtime_action_btn.clicked.connect(self._on_runtime_action)
        self.search_btn.clicked.connect(self._on_search_submitted)
        self.search_input.returnPressed.connect(self._on_search_submitted)
        self.cancel_task_btn.clicked.connect(self._on_cancel_active_task)
        self.prev_page_btn.clicked.connect(self._on_prev_page)
        self.next_page_btn.clicked.connect(self._on_next_page)
        self.split_view.splitterMoved.connect(self._on_splitter_moved)

        self.player_panel.boot_runtime_requested.connect(self._on_runtime_action)
        self.player_panel.stop_runtime_requested.connect(self._on_stop_runtime_requested)
        self.player_panel.collapse_requested.connect(self._on_player_collapse_requested)

        self.manager.task_updated.connect(self._on_manager_task_updated)
        self.manager.task_completed.connect(self._on_manager_task_completed)
        self.manager.task_failed.connect(self._on_manager_task_failed)
        self.manager.runtime_progress.connect(self._on_runtime_progress)
        self.manager.runtime_ready.connect(self._on_runtime_ready)
        self.manager.runtime_launched.connect(self._on_runtime_launched)
        self.manager.runtime_stopped.connect(self._on_runtime_stopped)
        self.manager.runtime_failed.connect(self._on_runtime_failed)
        self.manager.app_launch_started.connect(self._on_app_launch_started)
        self.manager.app_launch_finished.connect(self._on_app_launch_finished)
        _icon_loader.loaded.connect(self._on_icon_loaded)

    def _is_compact_catalog(self) -> bool:
        if not self.player_container.isHidden():
            return not self.isVisible() or self.body_widget.width() < 860
        return self.isVisible() and 0 < self.body_widget.width() < 860

    def _sync_header_compact(self) -> None:
        w = self.width()
        compact_hdr = 0 < w < 1280
        if compact_hdr == self._compact_header:
            return
        self._compact_header = compact_hdr
        for btn, label in (
            (self.folder_btn, "Thư mục"),
            (self.settings_btn, "Cài đặt"),
            (self.refresh_btn, "Làm mới"),
        ):
            btn.setText("" if compact_hdr else label)
            btn.setProperty("compact", "true" if compact_hdr else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
            btn.updateGeometry()

    def _sync_catalog_compact(self) -> None:
        compact = self._is_compact_catalog()
        if compact == self._compact_catalog:
            return
        self._compact_catalog = compact
        self.rt_lbl.setVisible(not compact)
        compact_dark = DARK_BTN_STYLE + "\nQPushButton { padding: 0px; }\n"
        for btn, label in (
            (self.player_toggle_btn, "Màn hình Android"),
            (self.install_file_btn, "Cài APK/XAPK"),
        ):
            btn.setText("" if compact else label)
            btn.setStyleSheet(compact_dark if compact else DARK_BTN_STYLE)
            if compact:
                btn.setFixedWidth(36)
            else:
                btn.setMinimumWidth(0)
                btn.setMaximumWidth(16777215)
            btn.updateGeometry()
        self._sync_pagination_bar()

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if obj is getattr(self, "body_widget", None) and event.type() == QEvent.Type.Resize:
            self._sync_catalog_compact()
        return super().eventFilter(obj, event)

    def _sync_split_margins(self) -> None:
        if self.player_container.isHidden():
            self._body_layout.setContentsMargins(*CONTENT_MARGINS)
        else:
            self._player_wrap_layout.setContentsMargins(CONTENT_MARGINS[0], 16, 8, 18)
            self._body_layout.setContentsMargins(10, 16, CONTENT_MARGINS[2], 18)
        self._sync_catalog_compact()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._sync_header_compact()
        self._sync_catalog_compact()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._sync_header_compact()
        self._sync_catalog_compact()

    @safe_slot
    def _on_splitter_moved(self, _pos: int, _index: int) -> None:
        self._sync_catalog_compact()

    def show_player_pane(self, show: bool = True, runtime: RuntimeInfo | None = None) -> None:
        """Show or hide the center Android Player pane with store catalog on the right."""
        if show:
            was_hidden = self.player_container.isHidden()
            self.player_container.show()
            self._sync_split_margins()
            if was_hidden:
                total_w = max(784, self.split_view.width() or self.width() or 1040)
                avail_h = max(560, self.split_view.height() or (self.height() - 64) or 736)
                portrait_w = int((avail_h - 110) * 9 / 16) + 56
                center_player_w = max(396, min(436, portrait_w))
                right_catalog_w = max(380, total_w - center_player_w)
                self.split_view.setSizes([center_player_w, right_catalog_w])
            rt = runtime or self._selected_runtime()
            if rt is not None and rt.running:
                self.player_panel.attach_runtime(rt)
        else:
            self.player_container.hide()
            self._sync_split_margins()

    @safe_slot
    def toggle_player_pane(self) -> None:
        opening = self.player_container.isHidden()
        self._user_collapsed_player = not opening
        self.show_player_pane(opening)
        logger.info(f"{TAG} Toggled split-screen Android player pane -> visible={opening}")

    @safe_slot
    def _on_player_collapse_requested(self) -> None:
        self._user_collapsed_player = True
        self.show_player_pane(False)
        self.status_lbl.setText(
            "Đã thu gọn màn hình Android — game vẫn tiếp tục chạy nền. Bấm 'Màn hình Android' để mở lại."
        )

    @safe_slot
    def _on_stop_runtime_requested(self) -> None:
        self.status_lbl.setText("Đang tắt máy ảo Android...")
        self.player_panel.notify_runtime_stopped()
        self.manager.stop_active_runtime_async()

    @safe_slot
    def _on_runtime_stopped(self) -> None:
        self.status_lbl.setText("Đã tắt máy ảo Android.")
        self.player_panel.notify_runtime_stopped()
        self.refresh_runtimes()

    def shutdown_player(self) -> None:
        self.player_panel.shutdown()

    def refresh_storage_and_hw_summary(self) -> None:
        root = self.manager.get_install_root()
        rt_dir = os.path.join(root, "AndroidRuntime")
        apps_dir = os.path.join(root, "AndroidApps")
        hw = get_emulator_settings()
        ram_gb = hw["ram_mb"] // 1024
        self.root_info_lbl.setText(
            f"Emulator: {rt_dir}  ·  Game: {apps_dir}  ·  {hw['cpu_cores']} CPU / {ram_gb}GB RAM / {hw['resolution']} {hw['fps']}FPS"
        )
        self.root_info_lbl.setToolTip(
            f"Thư mục máy ảo Android: {rt_dir}\n"
            f"Thư mục game APK/XAPK/OBB: {apps_dir}\n"
            f"Cấu hình máy ảo: {hw['cpu_cores']} nhân CPU · {hw['ram_mb']} MB RAM · {hw['resolution']} · {hw['fps']} FPS"
        )

    def _refresh_root_label(self) -> None:
        self.refresh_storage_and_hw_summary()

    def _update_chip_styles(self) -> None:
        for k, btn in self._chip_buttons.items():
            btn.setStyleSheet(_CHIP_ACTIVE if k == self._current_category else _CHIP_IDLE)

    # ------------------------------------------------------------------ Runtime Discovery & Actions

    @safe_slot
    def refresh_runtimes(self) -> None:
        self._refresh_root_label()
        t = Task(self.manager.list_runtimes, "android-runtimes", expected_errors=(AndroidError,))
        t.done.connect(self._on_runtimes_loaded)
        t.start_tracked()

    @safe_slot
    def _on_runtimes_loaded(self, result, error: str) -> None:
        if error or not isinstance(result, list):
            self.runtime_badge.set_state("LỖI RUNTIME", "error")
            return
        self._runtimes = result
        self.runtime_combo.blockSignals(True)
        self.runtime_combo.clear()
        pref = self.manager.get_preferred_runtime_id()
        sel_idx = 0
        for idx, rt in enumerate(self._runtimes):
            if rt.running:
                state_tag = "Đang chạy"
            elif rt.installed:
                state_tag = "Đã cài"
            elif (
                rt.runtime_id == RUNTIME_PORTABLE_SDK
                and rt.root_dir
                and os.path.isdir(os.path.join(rt.root_dir, "emulator"))
            ):
                state_tag = "Cần nâng cấp Android 14"
            else:
                state_tag = "Tự tải khi cần"
            self.runtime_combo.addItem(f"{rt.label} [{state_tag}]", rt.runtime_id)
            if pref and rt.runtime_id == pref:
                sel_idx = idx
        self.runtime_combo.setCurrentIndex(sel_idx)
        self.runtime_combo.setToolTip(self.runtime_combo.currentText())
        self.runtime_combo.blockSignals(False)
        self._sync_runtime_controls()
        sel_rt = self._selected_runtime()
        # The player follows the runtime that is actually running (a 32-bit game may have been routed to
        # Android 11 while Android 14 stays selected for new installs).
        live_rt = next((r for r in self._runtimes if r.running and r.kind == RUNTIME_PORTABLE_SDK), None)
        if sel_rt is not None and sel_rt.running:
            live_rt = sel_rt
        if live_rt is not None:
            if not self._user_collapsed_player:
                self.show_player_pane(True, runtime=live_rt)
            else:
                self.player_panel.attach_runtime(live_rt)
        else:
            self.player_panel.attach_runtime(sel_rt)

    def _selected_runtime(self) -> RuntimeInfo | None:
        idx = self.runtime_combo.currentIndex()
        if 0 <= idx < len(self._runtimes):
            return self._runtimes[idx]
        return self._runtimes[0] if self._runtimes else None

    def _sync_runtime_controls(self) -> None:
        rt = self._selected_runtime()
        if rt is None:
            self.runtime_badge.set_state("CHƯA CÓ ENGINE", "warn")
            self.runtime_action_btn.setEnabled(False)
            return
        if rt.running:
            self.runtime_badge.set_state("RUNTIME ĐANG CHẠY", "ok")
            self.runtime_action_btn.setText("Mở màn hình")
            self.runtime_action_btn.setStyleSheet(GREEN_BTN_STYLE)
            self.runtime_action_btn.setEnabled(True)
        elif self.manager.is_runtime_provisioning():
            self.runtime_badge.set_state("ĐANG KHỞI ĐỘNG", "warn")
            self.runtime_action_btn.setText("Đang khởi chạy...")
            self.runtime_action_btn.setStyleSheet(DARK_BTN_STYLE)
            self.runtime_action_btn.setEnabled(False)
        elif rt.installed:
            virt_hint = check_virtualization_hint() if rt.kind in (RUNTIME_PORTABLE_SDK, RUNTIME_SYSTEM_SDK) else ""
            if virt_hint:
                self.runtime_badge.set_state("CẦN BẬT ẢO HÓA BIOS", "warn")
                self.status_lbl.setText(
                    "CPU đang tắt ảo hóa BIOS (SVM Mode / Intel VT-x) — bấm Khởi động Runtime để xem hướng dẫn bật trong 30 giây."
                )
            else:
                self.runtime_badge.set_state("RUNTIME SẴN SÀNG", "ok")
            self.runtime_action_btn.setText("Khởi động Runtime")
            self.runtime_action_btn.setStyleSheet(DARK_BTN_STYLE)
            self.runtime_action_btn.setEnabled(True)
        else:
            has_partial = bool(rt.root_dir and os.path.isdir(os.path.join(rt.root_dir, "emulator")))
            if has_partial and rt.runtime_id == RUNTIME_PORTABLE_SDK:
                self.runtime_badge.set_state("CẦN NÂNG CẤP ANDROID 14", "warn")
                self.runtime_action_btn.setText("Nâng cấp Android 14")
            else:
                self.runtime_badge.set_state("TỰ TẢI LẦN ĐẦU", "warn")
                self.runtime_action_btn.setText("Tải Android Runtime")
            self.runtime_action_btn.setStyleSheet(PURPLE_BTN_STYLE)
            self.runtime_action_btn.setEnabled(True)

    @safe_slot
    def _on_runtime_combo_changed(self, _index: int) -> None:
        self.runtime_combo.setToolTip(self.runtime_combo.currentText())
        rt = self._selected_runtime()
        if rt:
            self.manager.set_preferred_runtime_id(rt.runtime_id)
        self._sync_runtime_controls()

    @safe_slot
    def _on_runtime_action(self) -> None:
        rt = self._selected_runtime()
        if not rt:
            return
        if rt.running:
            self._user_collapsed_player = False
            self.show_player_pane(True)
            return
        self.progress_widget.show()
        self.cancel_task_btn.show()
        if not rt.installed and rt.kind == RUNTIME_PORTABLE_SDK:
            self._runtime_op_mode = "install"
            self.progress_bar.setValue(2)
            self.progress_lbl.setText("Đang khởi tạo tải Android Runtime...")
            self.status_lbl.setText("Đang tải gói Android Runtime từ Google...")
            self.manager.setup_portable_runtime_async(rt.runtime_id)
            self._sync_runtime_controls()
            return

        self._runtime_op_mode = "boot"
        self._user_collapsed_player = False
        self.show_player_pane(True)
        boot_msg = f"Đang mở {rt.label} ngay trong ứng dụng..."
        self.progress_bar.setValue(10)
        self.progress_lbl.setText(boot_msg)
        self.status_lbl.setText(f"Đang khởi động {rt.label}...")
        self.player_panel.set_booting_state(True, 10, boot_msg, headline="Đang khởi động máy ảo Android...")
        self.manager.boot_runtime_async(rt)
        self._sync_runtime_controls()

    def notify_launching_game(self, package_name: str, app_name: str) -> None:
        """Immediate synchronous UI feedback when the user clicks Play on an Android game."""
        title = (app_name or package_name).strip()
        self._user_collapsed_player = False
        self.show_player_pane(True)
        rt = self._selected_runtime()
        already_live = bool(rt and rt.running)
        msg = (
            f'Đang mở "{title}" trên màn hình Android...'
            if already_live
            else f'Đang khởi động máy ảo Android để mở "{title}"...'
        )
        pct = 90 if already_live else 8
        self.progress_widget.show()
        self.cancel_task_btn.show()
        self.progress_bar.setValue(pct)
        self.progress_lbl.setText(msg)
        self.status_lbl.setText(msg)
        if not already_live:
            self.player_panel.set_booting_state(True, pct, msg, headline=f'Đang khởi động "{title}"...')
            self.runtime_badge.set_state("ĐANG KHỞI ĐỘNG", "warn")
            self.runtime_action_btn.setText("Đang khởi chạy...")
            self.runtime_action_btn.setStyleSheet(DARK_BTN_STYLE)
            self.runtime_action_btn.setEnabled(False)
        card = self._cards_by_pkg.get((package_name or "").strip().lower())
        if card is not None and isValid(card):
            card.refresh_state(card._installed_meta, None, is_launching=True)

    @safe_slot
    def _on_app_launch_started(self, package_name: str, app_name: str) -> None:
        self.notify_launching_game(package_name, app_name)

    @safe_slot
    def _on_app_launch_finished(self, _package_name: str, app_name: str, error: str) -> None:
        self.progress_widget.hide()
        if error:
            self.player_panel.set_booting_state(False)
            first_line = error.splitlines()[0] if error else "Lỗi không xác định"
            self.status_lbl.setText(f'Không thể mở "{app_name}": {first_line}')
            self.player_panel.canvas.clear_frame("Không thể khởi động máy ảo Android", first_line)
        else:
            self.status_lbl.setText(f'Đang chạy "{app_name}" trực tiếp trong Bob Gaming!')
        self._refresh_cards_state()
        self.refresh_runtimes()

    @safe_slot
    def _on_runtime_progress(self, pct: int, message: str) -> None:
        self.progress_widget.show()
        self.cancel_task_btn.show()
        self.progress_bar.setValue(max(0, min(100, pct)))
        self.progress_lbl.setText(message)
        self.status_lbl.setText(message)
        self.player_panel.set_booting_state(True, pct, message)
        self._sync_runtime_controls()

    @safe_slot
    def _on_runtime_ready(self, rt_obj) -> None:
        self.progress_widget.hide()
        mode = getattr(self, "_runtime_op_mode", "boot")
        if mode == "install":
            self.player_panel.set_booting_state(False)
            self.status_lbl.setText("Cài đặt Android Runtime hoàn tất — bấm Khởi động Runtime hoặc tải game ngay!")
        else:
            self.status_lbl.setText("Android Runtime đã khởi động trực tiếp trong Bob Gaming!")
            if isinstance(rt_obj, RuntimeInfo) and rt_obj.running:
                self._user_collapsed_player = False
                self.show_player_pane(True, runtime=rt_obj)
        self.refresh_runtimes()

    @safe_slot
    def _on_runtime_launched(self, rt_obj) -> None:
        if isinstance(rt_obj, RuntimeInfo) and rt_obj.running:
            self._user_collapsed_player = False
            self.show_player_pane(True, runtime=rt_obj)
        self.refresh_runtimes()

    @safe_slot
    def _on_runtime_failed(self, error: str) -> None:
        self.progress_widget.hide()
        self.player_panel.set_booting_state(False)
        if "Đã hủy" in (error or ""):
            self.status_lbl.setText(error)
        else:
            first_line = (error or "").splitlines()[0] if error else "Lỗi không xác định"
            self.status_lbl.setText(f"Không thể khởi chạy Runtime: {first_line}")
            QMessageBox.warning(self, "Lỗi Android Runtime", error)
        self.refresh_runtimes()

    # ------------------------------------------------------------------ Store Catalog, Pool Buffer & Pagination

    def _total_pages(self) -> int:
        return max(1, (len(self._pool_apps) + UI_PAGE_SIZE - 1) // UI_PAGE_SIZE)

    @staticmethod
    def _fetch_source_pages_throttled(fetch_fn, pages: list[int], max_workers: int = 2) -> list[tuple[int, list[AndroidApp]]]:
        if not pages:
            return []
        results: list[tuple[int, list[AndroidApp]]] = []
        with ThreadPoolExecutor(max_workers=max(1, min(max_workers, len(pages))), thread_name_prefix="android-pool") as pool:
            futs = [(p, pool.submit(fetch_fn, p)) for p in pages]
            for p, fut in futs:
                try:
                    items = fut.result()
                    results.append((p, items if isinstance(items, list) else []))
                except Exception as exc:
                    logger.warning(f"{TAG} Background pool page {p} fetch failed: {exc}")
                    results.append((p, []))
        return results

    def _visible_page_numbers(self, current: int, total: int, compact: bool = False) -> list[int | None]:
        """Return page numbers with None representing an ASCII '...' gap."""
        if compact:
            if total <= 4:
                return list(range(1, total + 1))
            if current <= 2:
                return [1, 2, None, total]
            if current >= total - 1:
                return [1, None, total - 1, total]
            return [1, None, current, None, total]

        if total <= 7:
            return list(range(1, total + 1))
        pages: list[int | None] = [1]
        start = max(2, current - 2)
        end = min(total - 1, current + 2)
        if current <= 4:
            start, end = 2, 5
        elif current >= total - 3:
            start, end = total - 4, total - 1
        if start > 2:
            pages.append(None)
        pages.extend(range(start, end + 1))
        if end < total - 1:
            pages.append(None)
        pages.append(total)
        return pages

    def _sync_pagination_bar(self) -> None:
        while self.page_numbers_layout.count():
            item = self.page_numbers_layout.takeAt(0)
            w = item.widget() if item else None
            if w is not None:
                w.deleteLater()
        self._page_num_btns.clear()

        total = self._total_pages()
        cur = max(1, min(self._current_page, total))
        self._current_page = cur

        is_installed_tab = self._current_category == CATEGORY_INSTALLED
        if is_installed_tab and total <= 1:
            self.pagination_bar.hide()
            return
        self.pagination_bar.show()

        compact = self._is_compact_catalog()
        self.prev_page_btn.setText("Trước" if compact else "Trang trước")
        self.next_page_btn.setText("Sau" if compact else "Trang sau")

        for slot in self._visible_page_numbers(cur, total, compact=compact):
            if slot is None:
                gap = QLabel("...")
                gap.setStyleSheet("color: #64748b; font-size: 12px; font-weight: 700; padding: 0 3px;")
                self.page_numbers_layout.addWidget(gap)
                self._page_num_btns.append(gap)
                continue
            btn = QPushButton(str(slot))
            btn.setFixedHeight(32)
            btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(_PAGE_NUM_ACTIVE if slot == cur else _PAGE_NUM_IDLE)
            btn.clicked.connect(lambda _c=False, p=slot: self._go_to_page(p))
            self.page_numbers_layout.addWidget(btn)
            self._page_num_btns.append(btn)

        if compact:
            self.page_info_lbl.setText(f"{cur}/{total}")
        else:
            loading_tag = " · Đang tải sẵn..." if self._pool_loading else ""
            self.page_info_lbl.setText(f"Trang {cur} / {total}{loading_tag}")
        self.prev_page_btn.setEnabled(cur > 1)
        can_next = cur < total or (not is_installed_tab and not self._pool_exhausted)
        self.next_page_btn.setEnabled(can_next)

    def _render_current_page(self, scroll_top: bool = False) -> None:
        total = self._total_pages()
        self._current_page = max(1, min(self._current_page, total))
        start = (self._current_page - 1) * UI_PAGE_SIZE
        end = start + UI_PAGE_SIZE
        page_slice = self._pool_apps[start:end]
        self._render_apps(page_slice)
        if scroll_top:
            self.scroll.verticalScrollBar().setValue(0)
        self._sync_pagination_bar()
        self._refresh_status_summary()

    def _refresh_status_summary(self) -> None:
        total_items = len(self._pool_apps)
        total_pages = self._total_pages()
        if self._current_category == CATEGORY_INSTALLED:
            self.status_lbl.setText(f"Có {total_items} trò chơi / ứng dụng Android đã cài trên máy.")
            return
        if self._current_query:
            if total_items == 0 and self._pool_loading:
                self.status_lbl.setText(f'Đang tìm "{self._current_query}" trên kho Android...')
            else:
                extra = " (đang tải thêm trang nền...)" if self._pool_loading else ""
                self.status_lbl.setText(
                    f'Tìm thấy {total_items} kết quả cho "{self._current_query}" · Trang {self._current_page}/{total_pages}{extra}'
                )
            return
        if total_items == 0 and self._pool_loading:
            self.status_lbl.setText("Đang tải danh sách ứng dụng & trò chơi Android...")
        else:
            extra = " (đang cào thêm trang nền...)" if self._pool_loading else ""
            self.status_lbl.setText(
                f"Đã đệm {total_items} trò chơi & ứng dụng Android · Trang {self._current_page}/{total_pages}{extra}"
            )

    @safe_slot
    def _go_to_page(self, page_num: int) -> None:
        total = self._total_pages()
        target = max(1, min(int(page_num), total))
        if target == self._current_page:
            self._ensure_prefetch_buffer()
            return
        logger.info(f"{TAG} Switched Android store page {self._current_page} -> {target} (total={total})")
        self._current_page = target
        self._render_current_page(scroll_top=True)
        self._ensure_prefetch_buffer()

    @safe_slot
    def _on_prev_page(self) -> None:
        if self._current_page > 1:
            self._go_to_page(self._current_page - 1)

    @safe_slot
    def _on_next_page(self) -> None:
        total = self._total_pages()
        if self._current_page < total:
            self._go_to_page(self._current_page + 1)
            return
        if self._current_category != CATEGORY_INSTALLED and not self._pool_exhausted:
            self._extend_pool_async(wait_for_page=True)

    def _ensure_prefetch_buffer(self) -> None:
        """Auto-scrape the next batch in background whenever <= 2 UI pages remain ahead."""
        if self._current_category == CATEGORY_INSTALLED or self._pool_loading or self._pool_exhausted:
            return
        pages_ahead = self._total_pages() - self._current_page
        if pages_ahead <= PREFETCH_AHEAD_PAGES:
            self._extend_pool_async(wait_for_page=False)

    def _start_wave2_pool(self, req_id: int, category: str, query: str) -> None:
        pages = list(range(2, INITIAL_POOL_PAGES + 1))
        if not pages:
            self._pool_loading = False
            self._sync_pagination_bar()
            self._refresh_status_summary()
            return
        self._pool_loading = True
        self._sync_pagination_bar()
        t0 = time.monotonic()

        def _fetch_page(p: int) -> list[AndroidApp]:
            if query:
                return self.manager.store.search(query, category, limit=SOURCE_PER_PAGE, page=p)
            return self.manager.store.get_catalog_page(category, page=p, per_page=SOURCE_PER_PAGE)

        t = Task(
            lambda: self._fetch_source_pages_throttled(_fetch_page, pages, max_workers=2),
            f"android-wave2-{req_id}",
            expected_errors=(AndroidError,),
        )
        t.done.connect(lambda res, err: self._on_pool_batch_loaded(req_id, category, query, res, err, t0, is_wave2=True))
        t.start_tracked()

    def _extend_pool_async(self, wait_for_page: bool = False) -> None:
        if self._current_category == CATEGORY_INSTALLED or self._pool_exhausted:
            return
        if self._pool_loading:
            if wait_for_page:
                self._wait_extend_page = True
                self._sync_pagination_bar()
            return

        req_id = self._request_id
        category = self._current_category
        query = self._current_query
        pages = list(range(self._next_source_page, self._next_source_page + EXTEND_BATCH_PAGES))
        self._pool_loading = True
        self._wait_extend_page = wait_for_page
        self._sync_pagination_bar()
        self._refresh_status_summary()
        t0 = time.monotonic()
        logger.info(
            f"{TAG} Background prefetching Android store pages {pages[0]}..{pages[-1]} "
            f"(category={category}, query={query!r}, cur_page={self._current_page}/{self._total_pages()})"
        )

        def _fetch_page(p: int) -> list[AndroidApp]:
            if query:
                return self.manager.store.search(query, category, limit=SOURCE_PER_PAGE, page=p)
            return self.manager.store.get_catalog_page(category, page=p, per_page=SOURCE_PER_PAGE)

        t = Task(
            lambda: self._fetch_source_pages_throttled(_fetch_page, pages, max_workers=2),
            f"android-extend-{req_id}-{pages[0]}",
            expected_errors=(AndroidError,),
        )
        t.done.connect(lambda res, err: self._on_pool_batch_loaded(req_id, category, query, res, err, t0, is_wave2=False))
        t.start_tracked()

    @safe_slot
    def _on_pool_batch_loaded(
        self,
        req_id: int,
        category: str,
        query: str,
        result,
        error: str,
        started_at: float,
        is_wave2: bool,
    ) -> None:
        if req_id != self._request_id:
            return
        self._pool_loading = False
        prev_total_pages = self._total_pages()

        if error or not isinstance(result, list):
            self._wait_extend_page = False
            self._sync_pagination_bar()
            self._refresh_status_summary()
            return

        incoming: list[AndroidApp] = []
        non_empty_pages = 0
        for p, p_items in result:
            self._next_source_page = max(self._next_source_page, p + 1)
            if p_items:
                non_empty_pages += 1
                incoming.extend(p_items)

        prev_shown_count = len(self._apps)
        merged, added = _merge_unique_apps(self._pool_apps, incoming)
        self._pool_apps = merged
        if non_empty_pages == 0 or added == 0:
            self._pool_exhausted = True

        if not query and self._pool_apps:
            self.manager.store._save_cache(category, self._pool_apps)

        elapsed = time.monotonic() - started_at
        phase = "Wave-2 initial buffer" if is_wave2 else "Background prefetch"
        logger.info(
            f"{TAG} {phase} ready in {elapsed:.2f}s: +{added} apps -> pool={len(self._pool_apps)} "
            f"({self._total_pages()} pages, next_src_page={self._next_source_page})"
        )

        if self._wait_extend_page:
            self._wait_extend_page = False
            if self._total_pages() > prev_total_pages:
                self._current_page = prev_total_pages + 1
                self._render_current_page(scroll_top=True)
            else:
                self._sync_pagination_bar()
                self._refresh_status_summary()
        elif prev_shown_count < UI_PAGE_SIZE and len(self._pool_apps) > prev_shown_count:
            # Top up current page if Wave 1 had fewer than UI_PAGE_SIZE items
            self._render_current_page(scroll_top=False)
        else:
            self._sync_pagination_bar()
            self._refresh_status_summary()

        self._ensure_prefetch_buffer()

    @safe_slot
    def load_catalog(self) -> None:
        self._request_id += 1
        req_id = self._request_id
        self._current_query = ""
        self._current_page = 1
        self._next_source_page = 2
        self._pool_exhausted = False
        self._wait_extend_page = False

        if self._current_category == CATEGORY_INSTALLED:
            self._pool_loading = False
            self._render_installed_only()
            return

        cat = self._current_category
        cached = self.manager.store.load_cached_featured(cat)
        self._pool_apps = list(cached) if cached else []
        self._pool_loading = True
        if self._pool_apps:
            self._render_current_page(scroll_top=True)
        else:
            self._sync_pagination_bar()
            self.status_lbl.setText("Đang tải danh sách ứng dụng & trò chơi Android...")

        t = Task(
            lambda: self.manager.store.get_catalog_page(cat, page=1, per_page=SOURCE_PER_PAGE),
            f"featured-{cat}-{req_id}",
            expected_errors=(AndroidError,),
        )
        t.done.connect(lambda res, err: self._on_catalog_wave1_loaded(req_id, cat, res, err))
        t.start_tracked()

    @safe_slot
    def _on_catalog_wave1_loaded(self, req_id: int, category: str, result, error: str) -> None:
        if req_id != self._request_id:
            return
        if error:
            self._pool_loading = False
            self._sync_pagination_bar()
            self.status_lbl.setText(f"Không thể làm mới kho online: {error}")
            return
        wave1 = result if isinstance(result, list) else []
        merged, _ = _merge_unique_apps(wave1, self._pool_apps)
        self._pool_apps = merged
        self._render_current_page(scroll_top=False)
        self._start_wave2_pool(req_id, category, query="")

    @safe_slot
    def _on_select_category(self, category: str) -> None:
        if self._current_category == category:
            return
        self._current_category = category
        self._update_chip_styles()
        query = self.search_input.text().strip()
        if query and category != CATEGORY_INSTALLED:
            self._on_search_submitted()
        else:
            self.load_catalog()

    @safe_slot
    def _on_search_submitted(self) -> None:
        q = self.search_input.text().strip()
        if not q:
            self.load_catalog()
            return
        if self._current_category == CATEGORY_INSTALLED:
            self._current_category = CATEGORY_ALL
            self._update_chip_styles()

        self._request_id += 1
        req_id = self._request_id
        cat = self._current_category
        self._current_query = q
        self._current_page = 1
        self._next_source_page = 2
        self._pool_apps = []
        self._pool_loading = True
        self._pool_exhausted = False
        self._wait_extend_page = False
        self._sync_pagination_bar()
        self.status_lbl.setText(f'Đang tìm "{q}" trên kho Android...')

        t = Task(
            lambda: self.manager.store.search(q, cat, limit=SOURCE_PER_PAGE, page=1),
            f"android-search-{req_id}",
            expected_errors=(AndroidError,),
        )
        t.done.connect(lambda res, err: self._on_search_wave1_loaded(req_id, cat, q, res, err))
        t.start_tracked()

    @safe_slot
    def _on_search_wave1_loaded(self, req_id: int, category: str, query: str, result, error: str) -> None:
        if req_id != self._request_id:
            return
        if error:
            self._pool_loading = False
            self._sync_pagination_bar()
            self.status_lbl.setText(f"Lỗi tìm kiếm: {error}")
            return
        wave1 = result if isinstance(result, list) else []
        self._pool_apps = list(wave1)
        self._render_current_page(scroll_top=True)
        if len(wave1) < 8:
            self._pool_loading = False
            self._pool_exhausted = True
            self._sync_pagination_bar()
            self._refresh_status_summary()
            return
        self._start_wave2_pool(req_id, category, query=query)

    def _render_installed_only(self) -> None:
        installed = self.manager.list_installed_apps()
        self._pool_apps = [
            AndroidApp(
                package_name=pkg,
                name=str(meta.get("name") or pkg),
                kind=str(meta.get("kind") or CATEGORY_GAMES),
                version=str(meta.get("version") or ""),
                icon_url=str(meta.get("icon_url") or ""),
                source=str(meta.get("source") or "local"),
                summary=f"Đã cài đặt tại {meta.get('install_dir', '')}",
            )
            for pkg, meta in installed.items()
        ]
        self._current_page = 1
        self._render_current_page(scroll_top=True)

    def _clear_grid(self) -> None:
        self._cards_by_pkg.clear()
        while self.flow_layout.count():
            item = self.flow_layout.takeAt(0)
            w = item.widget() if item else None
            if w is not None:
                w.deleteLater()

    def _render_apps(self, apps: list[AndroidApp]) -> None:
        self._apps = list(apps)
        self._clear_grid()
        installed = self.manager.list_installed_apps()
        active_by_pkg = {
            t.package_name.lower(): t.progress
            for t in self.manager.list_tasks()
            if t.status in ACTIVE_ANDROID_STATUSES
        }

        for app in self._apps:
            pkg_low = app.package_name.lower()
            inst_meta = next((m for p, m in installed.items() if p.lower() == pkg_low), None)
            card = AndroidAppCard(
                app=app,
                installed_meta=inst_meta,
                active_progress=active_by_pkg.get(pkg_low),
                is_launching=self.manager.is_package_launching(pkg_low),
                parent=self.grid_container,
            )
            card.install_clicked.connect(self._on_card_install)
            card.launch_clicked.connect(self._on_card_launch)
            card.uninstall_clicked.connect(self._on_card_uninstall)
            self.flow_layout.addWidget(card)
            self._cards_by_pkg[pkg_low] = card

    @safe_slot
    def _on_icon_loaded(self, url: str, qimg_obj) -> None:
        if not isinstance(qimg_obj, QImage) or qimg_obj.isNull():
            return
        pix = _icon_loader.store_pixmap(url, qimg_obj)
        for card in self._cards_by_pkg.values():
            if isValid(card) and card.app_data.poster_url == url:
                card.icon_lbl.setPixmap(pix)

    # ------------------------------------------------------------------ Install / Launch / Uninstall Slots

    @safe_slot
    def _on_card_install(self, app_obj) -> None:
        if not isinstance(app_obj, AndroidApp):
            return
        try:
            task_id = self.manager.start_store_install(app_obj)
            self._active_task_id = task_id
        except AndroidError as exc:
            QMessageBox.warning(self, "Không thể bắt đầu cài đặt", str(exc))

    @safe_slot
    def _on_pick_local_package(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Chọn tệp cài đặt Android (APK / XAPK / APKS)",
            "",
            "Android Packages (*.apk *.xapk *.apks *.apkm);;All Files (*)",
        )
        if not path:
            return
        try:
            task_id = self.manager.start_local_file_install(path)
            self._active_task_id = task_id
        except AndroidError as exc:
            QMessageBox.warning(self, "Không thể cài tệp Android", str(exc))

    @safe_slot
    def _on_pick_install_root(self) -> None:
        chosen = QFileDialog.getExistingDirectory(
            self,
            "Chọn thư mục ổ đĩa lưu Android Runtime và Game",
            self.manager.get_install_root(),
        )
        if not chosen:
            return
        if not is_valid_android_root(chosen):
            QMessageBox.warning(
                self,
                "Thư mục không hợp lệ",
                "Không được chọn thư mục cấu hình của Bob Gaming hoặc thư mục gốc hệ thống. Hãy chọn một thư mục lưu game riêng.",
            )
            return
        self.manager.set_install_root(chosen)
        self.refresh_runtimes()

    @safe_slot
    def _on_refresh_all(self) -> None:
        self.refresh_runtimes()
        if self.search_input.text().strip():
            self._on_search_submitted()
        else:
            self.load_catalog()

    @safe_slot
    def _on_cancel_active_task(self) -> None:
        if self.manager.is_runtime_provisioning():
            self.manager.cancel_runtime_operation()
            self.progress_widget.hide()
            self.refresh_runtimes()
        if self._active_task_id:
            self.manager.cancel_task(self._active_task_id)
            self.progress_widget.hide()
            self._refresh_cards_state()

    @safe_slot
    def _on_card_launch(self, package_name: str, app_name: str, launcher_path: str) -> None:
        self.launch_game_requested.emit(
            {
                "name": app_name,
                "android_package": package_name,
                "exe_path": launcher_path,
                "source": "manual",
            }
        )

    @safe_slot
    def _on_card_uninstall(self, package_name: str, app_name: str, install_dir: str) -> None:
        ans = QMessageBox.question(
            self,
            "Gỡ cài đặt ứng dụng Android",
            f'Bạn có chắc muốn gỡ "{app_name}" khỏi Android Runtime và Thư viện?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return
        self.status_lbl.setText(f'Đang gỡ cài đặt "{app_name}"...')

        def _do_remove():
            self.manager.uninstall_installed_app(package_name, install_dir)
            return package_name

        t = Task(_do_remove, f"uninstall-{package_name}", expected_errors=(AndroidError,))

        def _done(_res, err: str):
            if err:
                QMessageBox.warning(self, "Lỗi gỡ cài đặt", err)
            else:
                self.uninstall_android_requested.emit(package_name, app_name, install_dir)
                self.status_lbl.setText(f'Đã gỡ cài đặt "{app_name}".')
                if self._current_category == CATEGORY_INSTALLED:
                    self._render_installed_only()
                else:
                    self._refresh_cards_state()

        t.done.connect(_done)
        t.start_tracked()

    def _refresh_cards_state(self) -> None:
        installed = self.manager.list_installed_apps()
        active_by_pkg = {
            t.package_name.lower(): t.progress
            for t in self.manager.list_tasks()
            if t.status in ACTIVE_ANDROID_STATUSES
        }
        for pkg_low, card in self._cards_by_pkg.items():
            if isValid(card):
                inst_meta = next((m for p, m in installed.items() if p.lower() == pkg_low), None)
                card.refresh_state(
                    inst_meta,
                    active_by_pkg.get(pkg_low),
                    is_launching=self.manager.is_package_launching(pkg_low),
                )

    @safe_slot
    def _on_manager_task_updated(self, task_id: str) -> None:
        task = self.manager.get_task(task_id)
        if not task:
            return
        if task.status in ACTIVE_ANDROID_STATUSES:
            self._active_task_id = task_id
            self.progress_widget.show()
            self.cancel_task_btn.show()
            self.progress_bar.setValue(max(0, min(100, task.progress)))
            label = task.status_text or f"Đang cài {task.app_name}..."
            if task.status == AndroidTaskStatus.DOWNLOADING and task.downloaded_bytes > 0:
                dl_txt = format_bytes(task.downloaded_bytes)
                if task.total_bytes > 0:
                    dl_txt = f"{dl_txt} / {format_bytes(task.total_bytes)}"
                if task.speed_bps > 0:
                    dl_txt = f"{dl_txt} - {format_bytes(task.speed_bps)}/s"
                label = f"{label} ({dl_txt})"
            self.progress_lbl.setText(label)
        elif task_id == self._active_task_id and task.status == AndroidTaskStatus.CANCELLED:
            self.progress_widget.hide()
        self._refresh_cards_state()

    @safe_slot
    def _on_manager_task_completed(self, _task_id: str, payload: dict) -> None:
        self.progress_widget.hide()
        app_name = payload.get("name") or "Ứng dụng Android"
        self.status_lbl.setText(f'Đã cài đặt "{app_name}" thành công — bấm "Chơi ngay" để mở!')
        self.refresh_runtimes()
        if self._current_category == CATEGORY_INSTALLED:
            self._render_installed_only()
        else:
            self._refresh_cards_state()

    @safe_slot
    def _on_manager_task_failed(self, _task_id: str, error_msg: str) -> None:
        self.progress_widget.hide()
        self.status_lbl.setText(f"Cài đặt thất bại: {error_msg}")
        self._refresh_cards_state()
