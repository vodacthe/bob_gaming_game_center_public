"""
Add Game Dialog for Bob Gaming Game Center.
Allows users to add a game with its name, executable (.exe), and save folder.
"""

import logging
import os
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QFileDialog, QMessageBox,
    QWidget
)
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QFont

from app.ui.icons import make_svg_icon, make_svg_pixmap

logger = logging.getLogger(__name__)


class AddGameDialog(QDialog):
    """Dialog for adding a custom game with .exe selection and save folder."""

    game_added = Signal(dict)  # Emits game data dict

    def __init__(self, existing_names=None, parent=None):
        super().__init__(parent)
        self.existing_names = set(existing_names or [])
        self._save_path_is_auto = False
        self._detect_closed = False
        self._detect_worker = None
        self.setWindowTitle("Thêm trò chơi mới")
        self.setFixedSize(540, 390)
        self.setStyleSheet("""
            QDialog {
                background-color: #0b0e14;
                border: 1px solid rgba(212, 175, 55, 0.35);
                border-radius: 12px;
            }
            QLabel {
                color: #e6edf3;
                font-size: 13px;
            }
            QLineEdit {
                background-color: #121620;
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 8px;
                padding: 8px 12px;
                color: #ffffff;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #a855f7;
            }
        """)

        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 24, 26, 24)
        layout.setSpacing(14)

        # Header
        header_row = QHBoxLayout()
        icon_lbl = QLabel()
        icon_lbl.setPixmap(make_svg_pixmap("plus", 20, "#a855f7"))
        title = QLabel("Thêm trò chơi mới")
        title.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        title.setStyleSheet("color: #ffffff;")
        header_row.addWidget(icon_lbl)
        header_row.addWidget(title)
        header_row.addStretch()
        layout.addLayout(header_row)

        desc = QLabel("Cấu hình thông tin game, đường dẫn thực thi (.exe) để tự động đồng bộ khi thoát và thư mục lưu game.")
        desc.setStyleSheet("color: #8b949e; font-size: 12px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # 1. Game Name
        name_label = QLabel("Tên trò chơi *")
        name_label.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        layout.addWidget(name_label)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Ví dụ: Black Myth: Wukong")
        layout.addWidget(self.name_input)

        # 2. Executable (.exe) Selection
        exe_label = QLabel("File thực thi game (.exe) — Tự động đồng bộ khi thoát")
        exe_label.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        layout.addWidget(exe_label)

        exe_row = QHBoxLayout()
        exe_row.setSpacing(8)
        self.exe_input = QLineEdit()
        self.exe_input.setPlaceholderText("Tùy chọn: Chọn file .exe của trò chơi")
        exe_row.addWidget(self.exe_input)

        exe_browse_btn = QPushButton(" Duyệt...")
        exe_browse_btn.setIcon(make_svg_icon("folder", 16, "#a855f7"))
        exe_browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        exe_browse_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.06);
                color: #e6edf3;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 8px;
                padding: 8px 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: #a855f7;
            }
        """)
        exe_browse_btn.clicked.connect(self._on_browse_exe)
        exe_row.addWidget(exe_browse_btn)
        layout.addLayout(exe_row)

        # 3. Save Folder Selection
        save_label = QLabel("Đường dẫn thư mục lưu game (Save Folder)")
        save_label.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        layout.addWidget(save_label)

        save_row = QHBoxLayout()
        save_row.setSpacing(8)
        self.save_input = QLineEdit()
        self.save_input.setPlaceholderText("Tùy chọn: Chọn thư mục lưu ngay hoặc cấu hình sau")
        self.save_input.textEdited.connect(lambda _t: setattr(self, "_save_path_is_auto", False))
        save_row.addWidget(self.save_input)

        self.auto_save_btn = QPushButton(" Tự động tìm")
        self.auto_save_btn.setIcon(make_svg_icon("search", 15, "#38bdf8"))
        self.auto_save_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.auto_save_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(56, 189, 248, 0.10);
                color: #38bdf8;
                border: 1px solid rgba(56, 189, 248, 0.35);
                border-radius: 8px;
                padding: 8px 12px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(56, 189, 248, 0.22);
                border-color: #38bdf8;
            }
            QPushButton:disabled {
                color: #64748b;
                border-color: rgba(100, 116, 139, 0.3);
            }
        """)
        self.auto_save_btn.clicked.connect(lambda: self._start_auto_detect_save(interactive=True))
        save_row.addWidget(self.auto_save_btn)

        save_browse_btn = QPushButton(" Duyệt...")
        save_browse_btn.setIcon(make_svg_icon("folder", 16, "#a855f7"))
        save_browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        save_browse_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.06);
                color: #e6edf3;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 8px;
                padding: 8px 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.12);
                border-color: #a855f7;
            }
        """)
        save_browse_btn.clicked.connect(self._on_browse_save)
        save_row.addWidget(save_browse_btn)
        layout.addLayout(save_row)

        layout.addStretch()

        # Action Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)
        btn_row.addStretch()

        cancel_btn = QPushButton("Hủy bỏ")
        cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #8b949e;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 8px;
                padding: 8px 18px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.06);
                color: white;
            }
        """)
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)

        add_btn = QPushButton(" Thêm trò chơi")
        add_btn.setIcon(make_svg_icon("plus", 16, "#000000"))
        add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        add_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f59e0b, stop:1 #d97706);
                color: #0b0e14;
                border: none;
                border-radius: 8px;
                padding: 8px 22px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #fbbf24, stop:1 #f59e0b);
            }
        """)
        add_btn.clicked.connect(self._on_submit)
        btn_row.addWidget(add_btn)

        layout.addLayout(btn_row)

    def closeEvent(self, event):
        self._detect_closed = True
        super().closeEvent(event)

    def _on_browse_exe(self):
        """Pick an executable file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Chọn file thực thi (.exe)",
            "",
            "Tệp thực thi (*.exe);;Tất cả tệp (*.*)"
        )
        if file_path:
            file_path = os.path.abspath(file_path).replace("\\", "/")
            self.exe_input.setText(file_path)

            # Auto-suggest name if name input is blank
            if not self.name_input.text().strip():
                base_name = os.path.splitext(os.path.basename(file_path))[0]
                if base_name.lower() in ("game", "launcher", "start", "shipping", "app") or base_name.endswith("-Win64-Shipping"):
                    parent_dir = os.path.basename(os.path.dirname(file_path))
                    self.name_input.setText(parent_dir)
                else:
                    self.name_input.setText(base_name)

            if not self.save_input.text().strip() and os.environ.get("BOBGAMING_SAVEDETECT_DISABLE") != "1":
                self._start_auto_detect_save(interactive=False)

    def _start_auto_detect_save(self, interactive: bool = True):
        """Detect save folder in background thread from game name / exe path."""
        name = self.name_input.text().strip()
        exe_path = self.exe_input.text().strip()
        if not name and not exe_path:
            if interactive:
                QMessageBox.information(
                    self,
                    "Thiếu thông tin",
                    "Vui lòng nhập Tên trò chơi hoặc chọn File thực thi trước để tự động dò vị trí save.",
                )
            return
        if self._detect_worker is not None:
            return

        from app.ui.sync_dialog import (
            _ACTIVE_SAVE_DETECT_THREADS,
            _ACTIVE_SAVE_DETECT_WORKERS,
            SaveCandidatePickerDialog,
            _ensure_about_to_quit_hook,
        )
        from app.ui.workers import SaveDetectWorker

        _ensure_about_to_quit_hook()
        self.auto_save_btn.setEnabled(False)
        self.auto_save_btn.setText(" Đang dò...")

        thread = QThread()
        thread.setObjectName("add-game-save-detect")
        worker = SaveDetectWorker(
            game_name=name,
            exe_path=exe_path,
            install_location=os.path.dirname(exe_path) if exe_path else "",
            interactive=interactive,
        )
        self._detect_worker = worker
        worker.moveToThread(thread)
        thread.started.connect(worker.run)

        def _on_done(_gname: str, candidates: list, _w=worker):
            try:
                if self._detect_worker is _w:
                    self._detect_worker = None
                if self._detect_closed:
                    return
                self.auto_save_btn.setEnabled(True)
                self.auto_save_btn.setText(" Tự động tìm")
                if not candidates:
                    if _w.interactive:
                        QMessageBox.information(
                            self,
                            "Không tìm thấy",
                            "Chưa tìm thấy vị trí lưu game tự động. Bạn có thể bấm Duyệt để chọn thủ công.",
                        )
                    return
                chosen = candidates[0]
                if _w.interactive and len(candidates) > 1:
                    picker = SaveCandidatePickerDialog(name or "Trò chơi", candidates, parent=self)
                    if not picker.exec() or picker.selected_candidate is None:
                        return
                    chosen = picker.selected_candidate
                self.save_input.setText(os.path.abspath(chosen.path).replace("\\", "/"))
                self._save_path_is_auto = not _w.interactive
            except RuntimeError:
                pass
            except Exception as exc:
                logger.error(f"[CloudSave/Detector] AddGameDialog save detect failed: {exc}", exc_info=True)

        def _on_thread_finished(_w=worker, _t=thread):
            _ACTIVE_SAVE_DETECT_THREADS.discard(_t)
            _ACTIVE_SAVE_DETECT_WORKERS.discard(_w)
            _w.deleteLater()
            _t.deleteLater()

        worker.finished.connect(_on_done)
        worker.finished.connect(thread.quit, Qt.ConnectionType.DirectConnection)
        thread.finished.connect(_on_thread_finished)
        _ACTIVE_SAVE_DETECT_THREADS.add(thread)
        _ACTIVE_SAVE_DETECT_WORKERS.add(worker)
        thread.start()

    def _on_browse_save(self):
        """Pick a save directory."""
        dir_path = QFileDialog.getExistingDirectory(
            self,
            "Chọn thư mục lưu game",
            os.environ.get("APPDATA", os.path.expanduser("~")),
            QFileDialog.Option.ShowDirsOnly
        )
        if dir_path:
            dir_path = os.path.abspath(dir_path).replace("\\", "/")
            self.save_input.setText(dir_path)
            self._save_path_is_auto = False

    def _on_submit(self):
        """Validate and emit game data."""
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Thông báo", "Vui lòng nhập tên trò chơi.")
            return

        if name in self.existing_names:
            QMessageBox.warning(self, "Trùng lặp", f'Trò chơi \"{name}\" đã có trong thư viện.')
            return

        exe_path = self.exe_input.text().strip()
        save_path = self.save_input.text().strip()

        data = {
            "name": name,
            "exe_path": exe_path,
            "save_path": save_path,
            "save_path_auto": bool(save_path and self._save_path_is_auto),
        }
        self.game_added.emit(data)
        self.accept()
