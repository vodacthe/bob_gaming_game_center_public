"""
Modernized Library Screen for Bob Gaming Game Center.
Unified Cyberpunk Titanium Violet & Emerald Design Language.
Matching mockup design 100%.
"""

import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QScrollArea, QFrame, QSizePolicy, QComboBox,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap, QFont

from app.config import (
    get_app_dir,
    SYNC_STATUS_SYNCED, SYNC_STATUS_SYNCING,
)
from app.ui.game_card import GameCard
from app.ui.flow_layout import FlowLayout
from app.ui.icons import make_svg_icon, make_svg_pixmap

try:
    from shiboken6 import isValid as _is_valid_cpp
except ImportError:
    def _is_valid_cpp(x):
        return True


ACTIVE_TAB_STYLE = """
    QPushButton {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #7c3aed, stop:1 #6366f1);
        color: #ffffff;
        font-weight: 700;
        border: 1px solid #8b5cf6;
        border-radius: 8px;
        padding: 6px 14px;
        font-size: 12px;
    }
    QPushButton:hover {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8b5cf6, stop:1 #7c3aed);
    }
"""

INACTIVE_TAB_STYLE = """
    QPushButton {
        background-color: rgba(255, 255, 255, 0.05);
        color: #cbd5e1;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        padding: 6px 14px;
        font-size: 12px;
        font-weight: 500;
    }
    QPushButton:hover {
        background-color: rgba(255, 255, 255, 0.09);
        border-color: rgba(139, 92, 246, 0.4);
        color: #ffffff;
    }
"""

ACTIVE_VIEW_STYLE = """
    QPushButton {
        background-color: #7c3aed;
        border: 1px solid #8b5cf6;
        border-radius: 8px;
    }
"""

INACTIVE_VIEW_STYLE = """
    QPushButton {
        background-color: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 8px;
    }
    QPushButton:hover {
        background-color: rgba(255, 255, 255, 0.09);
        border-color: rgba(139, 92, 246, 0.4);
    }
"""


class LibraryScreen(QWidget):
    """
    Main game library screen with responsive grid, category filtering,
    and liquid glass styling.
    """

    # Signals
    game_selected = Signal(dict)
    logout_requested = Signal()
    login_requested = Signal()
    scan_requested = Signal()
    add_game_requested = Signal()
    remove_game_requested = Signal(dict)
    uninstall_game_requested = Signal(dict)
    settings_requested = Signal()
    utility_requested = Signal()
    sync_now_requested = Signal(dict)
    unsync_requested = Signal(dict)
    exclude_requested = Signal(dict)
    steam_artwork_requested = Signal(dict)
    favorite_toggled = Signal(dict)
    launch_requested = Signal(dict)
    exe_path_changed = Signal(str, str)
    category_filter_changed = Signal(str)
    counts_updated = Signal(int, int, int, int, int, int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._cards: dict[str, GameCard] = {}
        self._current_category = "all"
        self._is_logged_in = False
        self._setup_ui()

    def _setup_ui(self):
        """Set up the luxury library screen UI matching mockup."""
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setStyleSheet("background: transparent;")

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ---- Top Header Bar with Clean Single-Row Layout ----
        header = QWidget()
        header.setObjectName("headerBar")
        header.setFixedHeight(54)
        header.mousePressEvent = self._on_header_mouse_press
        header.mouseMoveEvent = self._on_header_mouse_move
        header.mouseReleaseEvent = self._on_header_mouse_release
        header.mouseDoubleClickEvent = self._on_header_mouse_double_click

        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(20, 6, 20, 6)
        header_layout.setSpacing(10)

        # Backward compatibility dummy handles for window control references
        self.min_btn = None
        self.max_btn = None
        self.close_btn = None

        # Title Label
        self.section_title = QLabel("Thư viện trò chơi")
        self.section_title.setObjectName("titleLabel")
        self.section_title.setFont(QFont("Segoe UI Variable Display", 18, QFont.Weight.Bold))
        header_layout.addWidget(self.section_title)

        # Backward compatibility hidden badge
        self.category_badge = QLabel("TẤT CẢ GAME")
        self.category_badge.hide()

        header_layout.addStretch()

        # Responsive Search Bar with leading SVG icon
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Tìm kiếm trò chơi trong thư viện...")
        self.search_input.setMinimumWidth(140)
        self.search_input.setMaximumWidth(280)
        self.search_input.setMinimumHeight(36)
        self.search_input.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.search_input.addAction(
            make_svg_icon("search", size=15, normal_color="#64748b", active_color="#a855f7"),
            QLineEdit.ActionPosition.LeadingPosition
        )
        self.search_input.textChanged.connect(lambda: self.filter_games(self.search_input.text()))
        header_layout.addWidget(self.search_input)

        # Quick Action Buttons
        self.scan_btn = QPushButton(" Quét thư viện")
        self.scan_btn.setObjectName("secondaryBtn")
        self.scan_btn.setIcon(make_svg_icon("sync", size=16, normal_color="#cbd5e1", active_color="#ffffff"))
        self.scan_btn.setMinimumHeight(36)
        self.scan_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.scan_btn.setToolTip("Quét tìm trò chơi đã cài đặt trên máy")
        self.scan_btn.clicked.connect(self.scan_requested.emit)
        header_layout.addWidget(self.scan_btn)

        self.add_btn = QPushButton(" Thêm trò chơi")
        self.add_btn.setObjectName("primaryBtn")
        self.add_btn.setIcon(make_svg_icon("gamepad", size=16, normal_color="#ffffff", active_color="#ffffff"))
        self.add_btn.setMinimumHeight(36)
        self.add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_btn.setToolTip("Thêm trò chơi thủ công")
        self.add_btn.clicked.connect(self.add_game_requested.emit)
        header_layout.addWidget(self.add_btn)

        main_layout.addWidget(header)

        # Backward-compatible buttons (handled in sidebar)
        self.settings_btn = QPushButton()
        self.settings_btn.hide()
        self.utility_btn = QPushButton()
        self.utility_btn.hide()
        self.auth_btn = QPushButton()
        self.auth_btn.hide()

        # ---- Subtitle / Stat & View Controls Bar ----
        control_bar = QWidget()
        control_bar.setStyleSheet("background: transparent;")
        control_layout = QHBoxLayout(control_bar)
        control_layout.setContentsMargins(20, 4, 20, 4)
        control_layout.setSpacing(6)

        # 6 Horizontal Pill Tabs matching user request:
        # [ Tất cả game (14) ] [ Đã cài đặt (14) ] [ Chưa cài đặt (0) ] [ Đã đồng bộ (1) ] [ Chưa đồng bộ (13) ] [ Yêu thích (0) ]
        self.tab_all = QPushButton("  Tất cả game (0)")
        self.tab_all.setObjectName("filterTabBtn")
        self.tab_all.setIcon(make_svg_icon("gamepad", size=14, normal_color="#ffffff", active_color="#ffffff"))
        self.tab_all.setCursor(Qt.CursorShape.PointingHandCursor)
        self.tab_all.clicked.connect(lambda: self._on_filter_tab_clicked("all"))
        control_layout.addWidget(self.tab_all)

        self.tab_installed = QPushButton("  Đã cài đặt (0)")
        self.tab_installed.setObjectName("filterTabBtn")
        self.tab_installed.setIcon(make_svg_icon("download", size=14, normal_color="#94a3b8", active_color="#ffffff"))
        self.tab_installed.setCursor(Qt.CursorShape.PointingHandCursor)
        self.tab_installed.clicked.connect(lambda: self._on_filter_tab_clicked("installed"))
        control_layout.addWidget(self.tab_installed)

        self.tab_uninstalled = QPushButton("  Chưa cài đặt (0)")
        self.tab_uninstalled.setObjectName("filterTabBtn")
        self.tab_uninstalled.setIcon(make_svg_icon("uninstalled", size=14, normal_color="#94a3b8", active_color="#ffffff"))
        self.tab_uninstalled.setCursor(Qt.CursorShape.PointingHandCursor)
        self.tab_uninstalled.clicked.connect(lambda: self._on_filter_tab_clicked("uninstalled"))
        control_layout.addWidget(self.tab_uninstalled)

        self.tab_synced = QPushButton("  Đã đồng bộ (0)")
        self.tab_synced.setObjectName("filterTabBtn")
        self.tab_synced.setIcon(make_svg_icon("cloud", size=14, normal_color="#94a3b8", active_color="#ffffff"))
        self.tab_synced.setCursor(Qt.CursorShape.PointingHandCursor)
        self.tab_synced.clicked.connect(lambda: self._on_filter_tab_clicked("synced"))
        control_layout.addWidget(self.tab_synced)

        self.tab_unsynced = QPushButton("  Chưa đồng bộ (0)")
        self.tab_unsynced.setObjectName("filterTabBtn")
        self.tab_unsynced.setIcon(make_svg_icon("cloud_off", size=14, normal_color="#94a3b8", active_color="#ffffff"))
        self.tab_unsynced.setCursor(Qt.CursorShape.PointingHandCursor)
        self.tab_unsynced.clicked.connect(lambda: self._on_filter_tab_clicked("unsynced"))
        control_layout.addWidget(self.tab_unsynced)

        self.tab_favorites = QPushButton("  Yêu thích (0)")
        self.tab_favorites.setObjectName("filterTabBtn")
        self.tab_favorites.setIcon(make_svg_icon("star", size=14, normal_color="#94a3b8", active_color="#ffffff"))
        self.tab_favorites.setCursor(Qt.CursorShape.PointingHandCursor)
        self.tab_favorites.clicked.connect(lambda: self._on_filter_tab_clicked("favorites"))
        control_layout.addWidget(self.tab_favorites)

        # Hidden count label for backward test compatibility
        self.count_label = QLabel("0 trò chơi trong danh mục này (Tổng: 0)")
        self.count_label.hide()

        control_layout.addStretch()

        # View Mode Toggle: Grid (4 squares) & List
        self.grid_view_btn = QPushButton()
        self.grid_view_btn.setObjectName("viewToggleBtn")
        self.grid_view_btn.setFixedSize(36, 32)
        self.grid_view_btn.setCheckable(True)
        self.grid_view_btn.setChecked(True)
        self.grid_view_btn.setStyleSheet(ACTIVE_VIEW_STYLE)
        self.grid_view_btn.setIcon(make_svg_icon("grid", size=15, normal_color="#ffffff", active_color="#ffffff"))
        self.grid_view_btn.setToolTip("Xem dạng lưới (Grid view)")
        self.grid_view_btn.clicked.connect(lambda: self._set_view_mode("grid"))
        control_layout.addWidget(self.grid_view_btn)

        self.list_view_btn = QPushButton()
        self.list_view_btn.setObjectName("viewToggleBtn")
        self.list_view_btn.setFixedSize(36, 32)
        self.list_view_btn.setCheckable(True)
        self.list_view_btn.setChecked(False)
        self.list_view_btn.setStyleSheet(INACTIVE_VIEW_STYLE)
        self.list_view_btn.setIcon(make_svg_icon("list", size=15, normal_color="#94a3b8", active_color="#ffffff"))
        self.list_view_btn.setToolTip("Xem dạng danh sách (List view)")
        self.list_view_btn.clicked.connect(lambda: self._set_view_mode("list"))
        control_layout.addWidget(self.list_view_btn)

        # Sort Dropdown with horizontal sliders icon
        self.sort_combo = QComboBox()
        self.sort_combo.setObjectName("sortCombo")
        self.sort_combo.setFixedHeight(32)
        sort_icon = make_svg_icon("sliders", size=14, normal_color="#cbd5e1", active_color="#a855f7")
        self.sort_combo.addItem(sort_icon, "Sắp xếp: Tên (A → Z)")
        self.sort_combo.addItem(sort_icon, "Sắp xếp: Tên (Z → A)")
        self.sort_combo.addItem(sort_icon, "Sắp xếp: Đã cài đặt")
        self.sort_combo.addItem(sort_icon, "Sắp xếp: Đã lưu Cloud")
        self.sort_combo.addItem(sort_icon, "Sắp xếp: Yêu thích")
        self.sort_combo.currentIndexChanged.connect(self._on_sort_changed)
        control_layout.addWidget(self.sort_combo)

        # Initialize tab styling
        self._update_tab_styles()

        # ---- Game Grid Scroll Area ----
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll_area.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        self.grid_container = QWidget()
        self.grid_container.setStyleSheet("background: transparent;")
        self.flow_layout = FlowLayout(self.grid_container, margin=24, spacing=18)
        self.grid_container.setLayout(self.flow_layout)
        self.scroll_area.setWidget(self.grid_container)

        # ---- Loading Overlay ----
        self.loading_overlay = QWidget(self)
        self.loading_overlay.setObjectName("loadingOverlay")
        self.loading_overlay.hide()

        loading_layout = QVBoxLayout(self.loading_overlay)
        loading_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        loading_layout.setSpacing(12)

        loading_icon = QLabel()
        loading_icon.setPixmap(make_svg_pixmap("sync", size=48, color="#a855f7"))
        loading_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        loading_icon.setStyleSheet("background: transparent;")

        loading_text = QLabel("Đang tải dữ liệu và quét thư viện...")
        loading_text.setObjectName("loadingText")
        loading_text.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        loading_text.setAlignment(Qt.AlignmentFlag.AlignCenter)

        loading_layout.addWidget(loading_icon)
        loading_layout.addWidget(loading_text)

        # ---- Assemble ----
        main_layout.addWidget(header)
        main_layout.addWidget(control_bar)
        main_layout.addWidget(self.scroll_area)

    def _on_max_clicked(self):
        win = self.window()
        if not win:
            return
        if hasattr(win, "_toggle_maximize"):
            win._toggle_maximize()
        elif win.isMaximized():
            win.showNormal()
            self.max_btn.setIcon(make_svg_icon("window_maximize", size=10, normal_color="#cbd5e1", active_color="#ffffff"))
        else:
            win.showMaximized()
            self.max_btn.setIcon(make_svg_icon("window_restore", size=10, normal_color="#cbd5e1", active_color="#ffffff"))

    def _on_filter_tab_clicked(self, category: str):
        self.set_category_filter(category)

    def _filter_tabs(self) -> list[tuple[str, QPushButton]]:
        return [
            ("all", self.tab_all), ("installed", self.tab_installed), ("uninstalled", self.tab_uninstalled),
            ("synced", self.tab_synced), ("unsynced", self.tab_unsynced), ("favorites", self.tab_favorites),
        ]

    def cycle_category(self, step: int) -> QPushButton:
        """Select the previous (-1) / next (+1) filter tab, wrapping around. Returns the new tab button."""
        tabs = self._filter_tabs()
        keys = [k for k, _ in tabs]
        cur = keys.index(self._current_category) if self._current_category in keys else 0
        key, btn = tabs[(cur + step) % len(tabs)]
        self.set_category_filter(key)
        return btn

    def _update_tab_styles(self):
        """Update active styling on the 6 pill tabs."""
        tabs = [
            ("all", self.tab_all, "gamepad"),
            ("installed", self.tab_installed, "download"),
            ("uninstalled", self.tab_uninstalled, "uninstalled"),
            ("synced", self.tab_synced, "cloud"),
            ("unsynced", self.tab_unsynced, "cloud_off"),
            ("favorites", self.tab_favorites, "star"),
        ]
        for key, btn, icon_name in tabs:
            is_active = (self._current_category == key)
            btn.setProperty("active", "true" if is_active else "false")
            btn.setStyleSheet(ACTIVE_TAB_STYLE if is_active else INACTIVE_TAB_STYLE)
            normal_col = "#ffffff" if is_active else "#94a3b8"
            btn.setIcon(make_svg_icon(icon_name, size=14, normal_color=normal_col, active_color="#ffffff"))
            btn.update()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.loading_overlay.setGeometry(self.rect())

    def set_category_filter(self, category: str):
        """Update active category filter from sidebar or tabs."""
        self._current_category = category
        cat_titles = {
            "all": "TẤT CẢ GAME",
            "installed": "ĐÃ CÀI ĐẶT TRÊN MÁY",
            "uninstalled": "CHƯA CÀI ĐẶT",
            "synced": "ĐÃ ĐỒNG BỘ ĐÁM MÂY",
            "unsynced": "CHƯA ĐỒNG BỘ ĐÁM MÂY",
            "favorites": "DANH SÁCH YÊU THÍCH",
        }
        self.category_badge.setText(cat_titles.get(category, category.upper()))
        self._update_tab_styles()
        self.filter_games(self.search_input.text())
        self.category_filter_changed.emit(category)

    def set_games(self, games: list[dict]):
        """Populate the grid with game cards."""
        self.clear_games()
        for game_data in games:
            self._add_card(game_data)
        self._update_counts()
        self.filter_games(self.search_input.text())
        self._relayout()

    def _update_counts(self):
        """Recalculate dynamic counts and update pill labels."""
        total = len(self._cards)
        installed = 0
        uninstalled = 0
        synced = 0
        unsynced = 0
        favorites = 0

        for c in self._cards.values():
            if not _is_valid_cpp(c):
                continue
            gd = c.game_data or {}

            # 1. Đã cài đặt: chỉ chứa game có file .exe
            exe = (gd.get("exe_path") or "").strip()
            is_inst = bool(exe and (os.path.isfile(exe) or exe.lower().endswith(".exe")))
            if is_inst:
                installed += 1
            else:
                uninstalled += 1

            # 2. Đã đồng bộ: đã setup cloud sync (có save_path, on_cloud hoặc trạng thái SYNCED/SYNCING)
            save_path = (gd.get("save_path") or "").strip()
            on_cloud = bool(gd.get("on_cloud", False))
            status = getattr(c, "_status", None) or gd.get("status", "")
            is_sync = bool(save_path or on_cloud or status in [SYNC_STATUS_SYNCED, SYNC_STATUS_SYNCING])
            if is_sync:
                synced += 1
            else:
                unsynced += 1

            # 3. Yêu thích
            if bool(gd.get("favorite", False)):
                favorites += 1

        self.tab_all.setText(f"  Tất cả game ({total})")
        self.tab_installed.setText(f"  Đã cài đặt ({installed})")
        self.tab_uninstalled.setText(f"  Chưa cài đặt ({uninstalled})")
        self.tab_synced.setText(f"  Đã đồng bộ ({synced})")
        self.tab_unsynced.setText(f"  Chưa đồng bộ ({unsynced})")
        self.tab_favorites.setText(f"  Yêu thích ({favorites})")

        self.counts_updated.emit(total, installed, uninstalled, synced, unsynced, favorites)

    def get_games(self) -> list[dict]:
        """Copies of the data of every game currently in the Library (name, install_location, exe_path, ...)."""
        return [dict(c.game_data) for c in self._cards.values()]

    def _add_card(self, game_data: dict):
        card = GameCard(game_data)
        card.clicked.connect(self._on_card_clicked)
        card.remove_requested.connect(self._on_remove_requested)
        card.uninstall_requested.connect(self._on_uninstall_requested)
        card.sync_now_requested.connect(self._on_sync_now_requested)
        card.unsync_requested.connect(self._on_unsync_requested)
        card.exclude_requested.connect(self._on_exclude_requested)
        card.steam_artwork_requested.connect(self._on_steam_artwork_requested)
        card.favorite_toggled.connect(self._on_favorite_toggled)
        card.launch_requested.connect(self.launch_requested.emit)
        card.exe_path_changed.connect(self.exe_path_changed.emit)
        self.flow_layout.addWidget(card)
        self._cards[game_data.get("name", "")] = card

    def _on_favorite_toggled(self, game_data: dict):
        self.favorite_toggled.emit(game_data)
        self._update_counts()
        if self._current_category == "favorites":
            self.filter_games(self.search_input.text())

    def _on_sort_changed(self, index: int):
        """Sort cards according to selected criteria."""
        card_items = list(self._cards.items())
        if index == 0:  # Tên A-Z
            card_items.sort(key=lambda item: item[0].lower())
        elif index == 1:  # Tên Z-A
            card_items.sort(key=lambda item: item[0].lower(), reverse=True)
        elif index == 2:  # Đã cài đặt trước
            card_items.sort(key=lambda item: bool(((item[1].game_data or {}).get("exe_path") or "").strip()), reverse=True)
        elif index == 3:  # Đã lưu Cloud trước
            card_items.sort(key=lambda item: bool((item[1].game_data or {}).get("save_path") or (item[1].game_data or {}).get("on_cloud")), reverse=True)
        elif index == 4:  # Yêu thích trước
            card_items.sort(key=lambda item: bool((item[1].game_data or {}).get("favorite")), reverse=True)

        while self.flow_layout.count():
            self.flow_layout.takeAt(0)
        for _, card in card_items:
            self.flow_layout.addWidget(card)
        self._relayout()

    def _set_view_mode(self, mode: str):
        """Toggle between Grid View and List View."""
        if mode == "grid":
            self.grid_view_btn.setChecked(True)
            self.list_view_btn.setChecked(False)
            self.grid_view_btn.setStyleSheet(ACTIVE_VIEW_STYLE)
            self.list_view_btn.setStyleSheet(INACTIVE_VIEW_STYLE)
            self.grid_view_btn.setIcon(make_svg_icon("grid", size=15, normal_color="#ffffff", active_color="#ffffff"))
            self.list_view_btn.setIcon(make_svg_icon("list", size=15, normal_color="#94a3b8", active_color="#ffffff"))
            for card in self._cards.values():
                card.setFixedSize(GameCard.CARD_WIDTH, GameCard.CARD_HEIGHT)
                card.image_label.setVisible(True)
        else:
            self.grid_view_btn.setChecked(False)
            self.list_view_btn.setChecked(True)
            self.grid_view_btn.setStyleSheet(INACTIVE_VIEW_STYLE)
            self.list_view_btn.setStyleSheet(ACTIVE_VIEW_STYLE)
            self.grid_view_btn.setIcon(make_svg_icon("grid", size=15, normal_color="#94a3b8", active_color="#ffffff"))
            self.list_view_btn.setIcon(make_svg_icon("list", size=15, normal_color="#ffffff", active_color="#ffffff"))
            for card in self._cards.values():
                card.setFixedSize(GameCard.CARD_WIDTH, 110)
                card.image_label.setVisible(False)
        self._relayout()

    def add_game(self, game_data: dict):
        self._add_card(game_data)
        self._update_counts()
        self.filter_games(self.search_input.text())
        self._relayout()

    def add_games(self, games: list[dict]):
        """Batch add game cards with a single layout and filter pass."""
        if not games:
            return
        for game_data in games:
            self._add_card(game_data)
        self._update_counts()
        self.filter_games(self.search_input.text())
        self._relayout()

    def get_card(self, game_name: str):
        """Get card widget by game name (exact or case-insensitive)."""
        if not game_name:
            return None
        card = self._cards.get(game_name)
        if card and _is_valid_cpp(card):
            return card
        for name, c in self._cards.items():
            if name.lower() == game_name.lower() and _is_valid_cpp(c):
                return c
        return None

    def remove_game(self, game_name: str) -> bool:
        """Remove a game card from library screen and update layouts/counters."""
        if not game_name:
            return False

        target_key = None
        if game_name in self._cards:
            target_key = game_name
        else:
            for name in self._cards:
                if name.lower() == game_name.lower():
                    target_key = name
                    break

        if not target_key:
            return False

        card = self._cards.pop(target_key, None)
        if card:
            try:
                self.flow_layout.removeWidget(card)
            except Exception:
                pass
            if _is_valid_cpp(card):
                card.deleteLater()
            self._update_counts()
            self.filter_games(self.search_input.text())
            self._relayout()
            return True
        return False

    def _relayout(self):
        viewport_width = self.scroll_area.viewport().width()
        new_height = self.flow_layout.heightForWidth(viewport_width)
        self.grid_container.setMinimumHeight(new_height + 60)
        self.flow_layout.setGeometry(self.flow_layout.geometry())

    def clear_games(self):
        while self.flow_layout.count():
            item = self.flow_layout.takeAt(0)
            if item and item.widget():
                item.widget().deleteLater()
        self._cards.clear()
        self._update_counts()

    def filter_games(self, query: str = ""):
        """Filter cards by search keyword AND current category."""
        query_lower = query.lower().strip()
        visible_count = 0

        for name, card in self._cards.items():
            if not _is_valid_cpp(card):
                continue
            game_data = card.game_data or {}

            # Category filter check
            exe = (game_data.get("exe_path") or "").strip()
            is_installed = bool(exe and (os.path.isfile(exe) or exe.lower().endswith(".exe")))

            save_path = (game_data.get("save_path") or "").strip()
            on_cloud = bool(game_data.get("on_cloud", False))
            status = getattr(card, "_status", None) or game_data.get("status", "")
            is_synced = bool(save_path or on_cloud or status in [SYNC_STATUS_SYNCED, SYNC_STATUS_SYNCING])

            cat_match = True
            if self._current_category == "installed":
                cat_match = is_installed
            elif self._current_category == "uninstalled":
                cat_match = not is_installed
            elif self._current_category == "synced":
                cat_match = is_synced
            elif self._current_category == "unsynced":
                cat_match = not is_synced
            elif self._current_category == "favorites":
                cat_match = bool(game_data.get("favorite", False))

            # Text search check
            text_match = (not query_lower) or (query_lower in name.lower())

            should_show = cat_match and text_match
            card.setVisible(should_show)
            if should_show:
                visible_count += 1

        total = len(self._cards)
        if query_lower:
            self.count_label.setText(f"Tìm thấy {visible_count} / {total} trò chơi phù hợp")
        else:
            self.count_label.setText(f"{visible_count} trò chơi trong danh mục này (Tổng: {total})")

    def update_game_status(self, game_name: str, status: str):
        card = self._cards.get(game_name)
        if card:
            if not _is_valid_cpp(card):
                self._cards.pop(game_name, None)
                return
            card.set_status(status)

    def update_game_data(self, game_name: str, updates: dict):
        card = self._cards.get(game_name)
        if card:
            if not _is_valid_cpp(card):
                self._cards.pop(game_name, None)
                return
            if card.game_data:
                card.game_data.update(updates)
                if "status" in updates:
                    card.set_status(updates["status"])
                if "on_cloud" in updates:
                    card._update_overlay_badges()
                    card._update_status_display()
                card._update_action_button()
                card.update()
            self._update_counts()

    def update_cloud_check(self, game_name: str, check_status: str):
        card = self._cards.get(game_name)
        if card:
            if not _is_valid_cpp(card):
                self._cards.pop(game_name, None)
                return
            card.set_cloud_check_status(check_status)

    def update_game_image(self, game_name: str, image_path: str):
        card = self._cards.get(game_name)
        if card:
            if not _is_valid_cpp(card):
                self._cards.pop(game_name, None)
                return
            card.update_image_from_path(image_path)

    def show_loading(self, show: bool):
        if show:
            self.loading_overlay.setGeometry(self.rect())
            self.loading_overlay.raise_()
            self.loading_overlay.show()
        else:
            self.loading_overlay.hide()

    def _on_card_clicked(self, game_data: dict):
        self.game_selected.emit(game_data)

    def _on_remove_requested(self, game_data: dict):
        self.remove_game_requested.emit(game_data)

    def _on_uninstall_requested(self, game_data: dict):
        self.uninstall_game_requested.emit(game_data)

    def _on_sync_now_requested(self, game_data: dict):
        self.sync_now_requested.emit(game_data)

    def _on_unsync_requested(self, game_data: dict):
        self.unsync_requested.emit(game_data)

    def _on_exclude_requested(self, game_data: dict):
        self.exclude_requested.emit(game_data)

    def _on_steam_artwork_requested(self, game_data: dict):
        self.steam_artwork_requested.emit(game_data)

    def _on_auth_clicked(self):
        if self._is_logged_in:
            self.logout_requested.emit()
        else:
            self.login_requested.emit()

    def set_logged_in(self, logged_in: bool, provider: str = ""):
        self._is_logged_in = logged_in

    def _on_max_clicked(self):
        win = self.window()
        if not win:
            return
        if hasattr(win, "toggle_maximize"):
            win.toggle_maximize()
        elif win.isMaximized():
            win.showNormal()
            self.max_btn.setIcon(make_svg_icon("window_maximize", size=10, normal_color="#cbd5e1", active_color="#ffffff"))
        else:
            win.showMaximized()
            self.max_btn.setIcon(make_svg_icon("window_restore", size=10, normal_color="#cbd5e1", active_color="#ffffff"))

    def _on_header_mouse_press(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            win = self.window()
            if win:
                from app.ui.main_window import start_system_move
                start_system_move(win)
            event.accept()

    def _on_header_mouse_move(self, event):
        win = self.window()
        if win and getattr(win, "_drag_pos", None) is not None and event.buttons() == Qt.MouseButton.LeftButton:
            if not win.isMaximized():
                win.move(event.globalPosition().toPoint() - win._drag_pos)
                event.accept()

    def _on_header_mouse_release(self, event):
        win = self.window()
        if win:
            win._drag_pos = None
        event.accept()

    def _on_header_mouse_double_click(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._on_max_clicked()
            event.accept()
