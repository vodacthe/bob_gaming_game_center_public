"""
Game card and list row widgets for Bob Gaming Game Center.
Unified Cyberpunk Titanium Violet & Emerald Design Language.
Matching mockup design 100%.
"""

import os
import subprocess
import logging
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QGraphicsDropShadowEffect, QMenu,
    QHBoxLayout, QPushButton, QFileDialog,
)
from PySide6.QtCore import Qt, Signal, QRectF, QPropertyAnimation, QEasingCurve, QPoint
from PySide6.QtGui import (
    QPixmap, QPainter, QColor, QFont, QPainterPath, QAction, QLinearGradient, QPen,
)

from app.config import (
    SYNC_STATUS_SYNCED, SYNC_STATUS_SYNCING, SYNC_STATUS_NOT_SYNCED,
    SYNC_STATUS_NOT_CONFIGURED, SYNC_STATUS_ERROR,
)
from app.ui.icons import make_svg_icon

# Cloud check status constants
CLOUD_CHECK_PENDING = "pending"
CLOUD_CHECK_CHECKING = "checking"
CLOUD_CHECK_DONE = "done"

try:
    from shiboken6 import isValid as _is_valid_cpp
except ImportError:
    def _is_valid_cpp(x):
        return True

logger = logging.getLogger(__name__)


PURPLE_BTN_STYLE = """
    QPushButton {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8e45ff, stop:1 #624df8);
        color: #ffffff;
        font-weight: 700;
        font-size: 12px;
        border: none;
        border-radius: 8px;
        padding: 0px 12px;
        margin: 0px;
        height: 32px;
        min-height: 32px;
        max-height: 32px;
    }
    QPushButton:hover {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #9d5cff, stop:1 #7564f9);
    }
    QPushButton:pressed {
        background: #523ee0;
    }
"""

GREEN_BTN_STYLE = """
    QPushButton {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00e676, stop:1 #00c853);
        color: #042612;
        font-weight: 800;
        font-size: 12px;
        border: none;
        border-radius: 8px;
        padding: 0px 12px;
        margin: 0px;
        height: 32px;
        min-height: 32px;
        max-height: 32px;
    }
    QPushButton:hover {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2bf08d, stop:1 #10d866);
        color: #000000;
    }
    QPushButton:pressed {
        background: #00a844;
    }
"""

SETUP_EXE_BTN_STYLE = """
    QPushButton {
        background-color: rgba(56, 189, 248, 0.10);
        color: #38bdf8;
        font-weight: 600;
        font-size: 11px;
        border: 1px solid rgba(56, 189, 248, 0.35);
        border-radius: 8px;
        padding: 0px 4px;
        margin: 0px;
        height: 32px;
        min-height: 32px;
        max-height: 32px;
    }
    QPushButton:hover {
        background-color: rgba(56, 189, 248, 0.22);
        border-color: #38bdf8;
        color: #ffffff;
    }
    QPushButton:pressed {
        background-color: rgba(56, 189, 248, 0.38);
    }
"""

DARK_BTN_STYLE = """
    QPushButton {
        background-color: rgba(255, 255, 255, 0.08);
        color: #f1f5f9;
        font-weight: 600;
        font-size: 12px;
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 8px;
        padding: 0px 12px;
        margin: 0px;
        height: 30px;
        min-height: 30px;
        max-height: 30px;
    }
    QPushButton:hover {
        background-color: rgba(255, 255, 255, 0.14);
        border-color: rgba(139, 92, 246, 0.5);
        color: #ffffff;
    }
    QPushButton:pressed {
        background-color: rgba(255, 255, 255, 0.04);
    }
    QPushButton:disabled {
        background-color: rgba(255, 255, 255, 0.03);
        color: rgba(148, 163, 184, 0.42);
        border-color: rgba(255, 255, 255, 0.06);
    }
"""

MORE_BTN_STYLE = """
    QPushButton {
        background-color: rgba(255, 255, 255, 0.07);
        color: #cbd5e1;
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 8px;
        font-weight: 900;
        font-size: 13px;
        padding: 0px;
        margin: 0px;
        height: 32px;
        min-height: 32px;
        max-height: 32px;
        width: 36px;
        min-width: 36px;
        max-width: 36px;
    }
    QPushButton:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(139, 92, 246, 0.5);
        color: #ffffff;
    }
"""

GOLD_BTN_STYLE = PURPLE_BTN_STYLE  # Backwards compatibility alias

KNOWN_SIZES = {
    "pes 2020": "24.5 GB",
    "dawnwalker": "42.1 GB",
    "crimson desert": "65.0 GB",
    "eastern era": "18.2 GB",
    "mafia": "35.0 GB",
    "rockstar": "1.2 GB",
}


class _CardBorderOverlay(QWidget):
    """Transparent overlay that draws the card border on top of edge-to-edge cover artwork."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self._hovered = False

    def set_hovered(self, hovered: bool):
        if self._hovered != hovered:
            self._hovered = hovered
            self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        pen = QPen()
        if self._hovered:
            pen.setColor(QColor(142, 69, 255, 230))
            pen.setWidthF(1.5)
        else:
            pen.setColor(QColor(255, 255, 255, 20))
            pen.setWidthF(1.0)

        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        w = pen.widthF()
        r = QRectF(w / 2.0, w / 2.0, self.width() - w, self.height() - w)
        painter.drawRoundedRect(r, 14.0, 14.0)


class GameCard(QWidget):
    """Cyberpunk Titanium Game Card matching mockup design 100%."""

    clicked = Signal(dict)
    remove_requested = Signal(dict)
    uninstall_requested = Signal(dict)
    sync_now_requested = Signal(dict)
    unsync_requested = Signal(dict)
    exclude_requested = Signal(dict)
    steam_artwork_requested = Signal(dict)
    favorite_toggled = Signal(dict)
    launch_requested = Signal(dict)
    exe_path_changed = Signal(str, str)

    CARD_WIDTH = 224
    CARD_HEIGHT = 308
    IMAGE_WIDTH = 224
    IMAGE_HEIGHT = 175

    def __init__(self, game_data: dict = None, parent=None):
        super().__init__(parent)
        self.game_data = game_data or {}
        self._status = SYNC_STATUS_NOT_CONFIGURED
        self._cloud_check = CLOUD_CHECK_PENDING
        self._pixmap = None

        self.setObjectName("gameCard")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet("""
            #gameCard {
                background-color: #0d141e;
                border: 1px solid transparent;
                border-radius: 14px;
            }
            #gameCard:hover {
                background-color: #0d141e;
                border: 1px solid transparent;
            }
        """)
        self.setFixedSize(self.CARD_WIDTH, self.CARD_HEIGHT)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)  # controller navigation (gamepad_nav)

        self._setup_ui()
        self._setup_hover_effect()

        if self.game_data:
            self.set_game_data(self.game_data)

    def _setup_ui(self):
        """Build structured card with edge-to-edge blended poster."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 10)
        layout.setSpacing(4)

        # 1. Edge-to-Edge Poster Container
        self.image_label = QLabel(self)
        self.image_label.setFixedSize(self.IMAGE_WIDTH, self.IMAGE_HEIGHT)
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet("background: transparent; border: none;")

        # Favorite Heart Button (Top-Right)
        self._fav_btn = QPushButton(self.image_label)
        self._fav_btn.setGeometry(self.IMAGE_WIDTH - 38, 10, 28, 28)
        self._fav_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._fav_btn.setToolTip("Yêu thích")
        self._fav_btn.clicked.connect(self._on_fav_clicked)
        self._update_fav_icon()

        # Cloud Status Pill (Top-Right of Poster)
        self._cloud_badge = QLabel(self.image_label)
        self._cloud_badge.setGeometry(self.IMAGE_WIDTH - 76, 10, 68, 22)
        self._cloud_badge.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        self._cloud_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._cloud_badge.hide()

        layout.addWidget(self.image_label)

        # 2. Bottom Info Container (Title, Status, Sync Status, Action Buttons)
        info_widget = QWidget(self)
        info_widget.setStyleSheet("background: transparent; border: none;")
        info_layout = QVBoxLayout(info_widget)
        info_layout.setContentsMargins(14, 0, 14, 0)
        info_layout.setSpacing(2)

        self.name_label = QLabel(info_widget)
        self.name_label.setObjectName("cardTitle")
        self.name_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.name_label.setFixedHeight(20)
        self.name_label.setWordWrap(False)
        info_layout.addWidget(self.name_label)

        self._status_label = QLabel(info_widget)
        self._status_label.setObjectName("cardStatus")
        self._status_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self._status_label.setFixedHeight(16)
        info_layout.addWidget(self._status_label)

        self._sync_status_label = QLabel(info_widget)
        self._sync_status_label.setObjectName("cardSyncStatus")
        self._sync_status_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self._sync_status_label.setFixedHeight(16)
        info_layout.addWidget(self._sync_status_label)

        btn_layout = QHBoxLayout()
        btn_layout.setContentsMargins(0, 3, 0, 0)
        btn_layout.setSpacing(6)
        btn_layout.setAlignment(Qt.AlignmentFlag.AlignVCenter)

        self._action_btn = QPushButton(info_widget)
        self._action_btn.setFixedHeight(32)
        self._action_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._action_btn.clicked.connect(self._on_action_clicked)
        btn_layout.addWidget(self._action_btn, 1)

        self._more_btn = QPushButton(info_widget)
        self._more_btn.setObjectName("cardActionMore")
        self._more_btn.setIcon(make_svg_icon("more", size=16, normal_color="#cbd5e1", active_color="#ffffff"))
        self._more_btn.setStyleSheet(MORE_BTN_STYLE)
        self._more_btn.setFixedSize(36, 32)
        self._more_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._more_btn.setToolTip("Tùy chọn khác")
        self._more_btn.clicked.connect(self._show_more_menu)
        btn_layout.addWidget(self._more_btn)

        info_layout.addLayout(btn_layout)
        layout.addWidget(info_widget)

        # 3. Transparent Border Overlay to keep border on top of edge-to-edge artwork
        self._border_overlay = _CardBorderOverlay(self)
        self._border_overlay.setGeometry(0, 0, self.CARD_WIDTH, self.CARD_HEIGHT)
        self._border_overlay.raise_()

        # Backward compatibility aliases
        self._sync_badge = self._sync_status_label
        self._sync_now_btn = self._action_btn

    def _setup_hover_effect(self):
        """Electric Violet ambient rim lighting on hover."""
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(0)
        self.shadow.setOffset(0, 0)
        self.shadow.setColor(QColor(139, 92, 246, 110))
        self.setGraphicsEffect(self.shadow)

        self.glow_anim = QPropertyAnimation(self.shadow, b"blurRadius")
        self.glow_anim.setDuration(200)
        self.glow_anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    def _update_fav_icon(self):
        """Update heart icon based on favorite status matching mockup."""
        is_fav = bool(self.game_data.get("favorite", False))
        if is_fav:
            self._fav_btn.setIcon(make_svg_icon("heart", size=14, normal_color="#ef4444", active_color="#f87171"))
            self._fav_btn.setStyleSheet("""
                QPushButton {
                    background: rgba(15, 17, 26, 0.65);
                    border: 1px solid rgba(239, 68, 68, 0.5);
                    border-radius: 14px;
                    padding: 0;
                }
                QPushButton:hover {
                    background: rgba(20, 22, 34, 0.85);
                    border-color: rgba(239, 68, 68, 0.8);
                }
            """)
        else:
            self._fav_btn.setIcon(make_svg_icon("heart", size=14, normal_color="#cbd5e1", active_color="#ffffff"))
            self._fav_btn.setStyleSheet("""
                QPushButton {
                    background: rgba(15, 17, 26, 0.65);
                    border: 1px solid rgba(255, 255, 255, 0.15);
                    border-radius: 14px;
                    padding: 0;
                }
                QPushButton:hover {
                    background: rgba(20, 22, 34, 0.85);
                    border-color: rgba(255, 255, 255, 0.4);
                }
            """)

    def _on_fav_clicked(self):
        """Toggle favorite state and emit signal."""
        is_fav = not bool(self.game_data.get("favorite", False))
        self.game_data["favorite"] = is_fav
        self._update_fav_icon()
        self._update_overlay_badges()
        self.favorite_toggled.emit(self.game_data)

    def _update_overlay_badges(self):
        """Update top-right badge: Cloud pill vs Heart button matching mockup 100%."""
        try:
            if not _is_valid_cpp(self) or not _is_valid_cpp(self._cloud_badge) or not _is_valid_cpp(self._fav_btn):
                return
            show_cloud = bool(self.game_data and self.game_data.get("on_cloud", False))
            is_fav = bool(self.game_data and self.game_data.get("favorite", False))
            has_exe = bool(self.game_data and self.game_data.get("exe_path"))
            is_checking = (self._cloud_check == CLOUD_CHECK_CHECKING)

            if is_checking:
                self._cloud_badge.setText("Kiểm tra...")
                self._cloud_badge.setStyleSheet("""
                    color: #fbbf24;
                    background: rgba(11, 14, 20, 0.85);
                    border: 1px solid rgba(251, 191, 36, 0.5);
                    border-radius: 6px;
                    padding: 1px 4px;
                    font-size: 10px;
                """)
                self._cloud_badge.setGeometry(self.IMAGE_WIDTH - 76, 8, 68, 22)
                self._cloud_badge.show()
                self._cloud_badge.raise_()
                self._fav_btn.hide()
            elif show_cloud and not has_exe and not is_fav:
                self._cloud_badge.setText("☁ Cloud")
                self._cloud_badge.setStyleSheet("""
                    color: #38bdf8;
                    background: rgba(12, 28, 48, 0.85);
                    border: 1px solid rgba(56, 189, 248, 0.5);
                    border-radius: 6px;
                    padding: 1px 6px;
                    font-size: 10px;
                    font-weight: bold;
                """)
                self._cloud_badge.setGeometry(self.IMAGE_WIDTH - 76, 8, 68, 22)
                self._cloud_badge.show()
                self._cloud_badge.raise_()
                self._fav_btn.hide()
            else:
                self._cloud_badge.hide()
                self._fav_btn.setGeometry(self.IMAGE_WIDTH - 36, 8, 28, 28)
                self._fav_btn.show()
                self._fav_btn.raise_()
        except RuntimeError:
            pass

    def _update_status_display(self):
        """Update the installation status and cloud sync status lines under game title."""
        try:
            if not _is_valid_cpp(self) or not _is_valid_cpp(self._status_label):
                return
            exe_path = (self.game_data.get("exe_path") or "").strip()
            exe_exists = bool(exe_path and os.path.isfile(exe_path))
            is_installed = bool(exe_exists or (exe_path and exe_path.lower().endswith(".exe")))

            # 1. Trạng thái cài đặt (Đã cài đặt / Chưa cài đặt)
            if is_installed:
                name_key = self.game_data.get("name", "").lower()
                size_val = self.game_data.get("size")
                if not size_val:
                    for k, v in KNOWN_SIZES.items():
                        if k in name_key or name_key in k:
                            size_val = v
                            break
                size_html = f"&nbsp;&nbsp;<span style='color: #94a3b8; font-weight: 400;'>{size_val}</span>" if size_val else ""
                self._status_label.setText(f"<span style='color: #10b981; font-weight: 600;'>● Đã cài đặt</span>{size_html}")
            else:
                self._status_label.setText("<span style='color: #94a3b8; font-weight: 500;'>☁ Chưa cài đặt</span>")

            # 2. Trạng thái đồng bộ đám mây (Đã đồng bộ / Chưa đồng bộ / Đang đồng bộ... / Lỗi đồng bộ)
            if hasattr(self, "_sync_status_label") and _is_valid_cpp(self._sync_status_label):
                is_synced = (self._status == SYNC_STATUS_SYNCED) or (
                    bool(self.game_data.get("on_cloud")) and self._status not in [SYNC_STATUS_NOT_SYNCED, SYNC_STATUS_ERROR]
                )
                if self._status == SYNC_STATUS_SYNCING:
                    self._sync_status_label.setText("<span style='color: #fbbf24; font-weight: 500;'>● Đang đồng bộ...</span>")
                elif self._status == SYNC_STATUS_ERROR:
                    self._sync_status_label.setText("<span style='color: #ef4444; font-weight: 500;'>● Lỗi đồng bộ</span>")
                elif is_synced:
                    self._sync_status_label.setText("<span style='color: #10b981; font-weight: 500;'>● Đã đồng bộ</span>")
                else:
                    self._sync_status_label.setText("<span style='color: #94a3b8; font-weight: 500;'>○ Chưa đồng bộ</span>")
        except RuntimeError:
            pass

    def _update_action_button(self):
        """Configure main action button: Cài đặt (Purple) if no save_path, Cài đặt file chạy game if has save_path but no exe, Chơi (Green) if exe is set."""
        try:
            if not _is_valid_cpp(self) or not _is_valid_cpp(self._action_btn):
                return
            has_path = bool(self.game_data.get("save_path"))
            exe_path = self.game_data.get("exe_path", "")
            exe_exists = bool(exe_path and os.path.isfile(exe_path))

            if exe_exists:
                self._action_btn.setObjectName("cardActionGreen")
                self._action_btn.setText("▶  Chơi")
                self._action_btn.setStyleSheet(GREEN_BTN_STYLE)
                self._action_btn.setToolTip("Khởi chạy trò chơi")
            elif not has_path:
                self._action_btn.setObjectName("cardActionPurple")
                self._action_btn.setText("▶  Cài đặt")
                self._action_btn.setStyleSheet(PURPLE_BTN_STYLE)
                self._action_btn.setToolTip("Cấu hình đường dẫn lưu game")
            else:
                self._action_btn.setObjectName("cardActionSetupExe")
                self._action_btn.setText("Cài đặt file chạy game")
                self._action_btn.setStyleSheet(SETUP_EXE_BTN_STYLE)
                self._action_btn.setToolTip("Cài đặt file thực thi (.exe) để khởi chạy trò chơi")

        except RuntimeError:
            pass

    def _update_sync_now_visibility(self):
        """Compatibility alias to update button states."""
        self._update_action_button()

    def _on_action_clicked(self):
        """Handle primary action button click."""
        has_path = bool(self.game_data.get("save_path"))
        exe_path = self.game_data.get("exe_path", "")
        exe_exists = bool(exe_path and os.path.isfile(exe_path))

        if exe_exists:
            # Launch executable directly
            try:
                pass
                # Delegated to MainWindow._on_launch_game via launch_requested (Steam Non-Steam or direct fallback)
                self.launch_requested.emit(self.game_data)
            except Exception as e:
                logger.error(f"Failed to launch {exe_path}: {e}")
                self.clicked.emit(self.game_data)
        elif not has_path:
            # Open setup dialog
            self.clicked.emit(self.game_data)
        else:
            self._on_setup_exe()

    def _on_setup_exe(self):
        """Prompt user to choose executable (.exe) for this game."""
        game_name = self.game_data.get("name", "")
        curr_exe = self.game_data.get("exe_path", "")
        start_dir = ""
        if curr_exe and os.path.isdir(os.path.dirname(curr_exe)):
            start_dir = os.path.dirname(curr_exe)
        elif self.game_data.get("save_path") and os.path.isdir(self.game_data.get("save_path")):
            start_dir = self.game_data.get("save_path")
        else:
            start_dir = os.environ.get("PROGRAMFILES", "C:/")

        file_path, _ = QFileDialog.getOpenFileName(
            self,
            f"Chọn file thực thi (.exe) cho {game_name}",
            start_dir,
            "Tệp thực thi (*.exe);;Tất cả tệp (*.*)"
        )
        if file_path:
            file_path = os.path.abspath(file_path).replace("\\", "/")
            self.game_data["exe_path"] = file_path
            self.exe_path_changed.emit(game_name, file_path)
            self._update_status_display()
            self._update_action_button()

    def set_game_data(self, data: dict):
        """Populate game data and refresh card."""
        self.game_data = data
        name = data.get("name", "Trò chơi")

        self.setToolTip(name)
        metrics = self.name_label.fontMetrics()
        elided = metrics.elidedText(name, Qt.TextElideMode.ElideRight, self.IMAGE_WIDTH - 28)
        self.name_label.setText(elided)

        self._status = data.get("status", SYNC_STATUS_NOT_CONFIGURED)
        self._update_fav_icon()
        self._update_overlay_badges()
        self._update_status_display()
        self._update_action_button()

    def set_image(self, pixmap: QPixmap):
        """Set cover art with top 14px rounded corners and smooth bottom gradient fade."""
        if pixmap and not pixmap.isNull():
            self._pixmap = pixmap
            w = self.IMAGE_WIDTH
            h = self.IMAGE_HEIGHT
            scaled = pixmap.scaled(
                w, h,
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation,
            )
            # Center-crop horizontally, top-align vertically so top title/artwork is always visible
            x = max(0, (scaled.width() - w) // 2) if scaled.width() > w else 0
            y = 0
            scaled = scaled.copy(x, y, w, h)

            rounded = QPixmap(w, h)
            rounded.fill(QColor(0, 0, 0, 0))

            painter = QPainter(rounded)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
            
            # Clip only top corners (14px) so artwork aligns with card curves
            path = QPainterPath()
            path.moveTo(0, h)
            path.lineTo(0, 14)
            path.arcTo(0, 0, 28, 28, 180, -90)
            path.lineTo(w - 14, 0)
            path.arcTo(w - 28, 0, 28, 28, 90, -90)
            path.lineTo(w, h)
            path.closeSubpath()
            painter.setClipPath(path)
            painter.drawPixmap(0, 0, scaled)

            # Apply smooth bottom gradient fade directly blending to card background (#0d141e)
            card_bg = QColor(13, 20, 30)
            start_y = int(h * 0.60)
            fade_h = h - start_y
            grad = QLinearGradient(0, start_y, 0, h)
            grad.setColorAt(0.0, QColor(card_bg.red(), card_bg.green(), card_bg.blue(), 0))
            grad.setColorAt(0.40, QColor(card_bg.red(), card_bg.green(), card_bg.blue(), 90))
            grad.setColorAt(0.75, QColor(card_bg.red(), card_bg.green(), card_bg.blue(), 200))
            grad.setColorAt(1.0, QColor(card_bg.red(), card_bg.green(), card_bg.blue(), 255))
            painter.fillRect(0, start_y, w, fade_h, grad)
            painter.end()

            self.image_label.setPixmap(rounded)
            self._update_overlay_badges()
            if hasattr(self, "_border_overlay") and self._border_overlay:
                self._border_overlay.raise_()

    def set_status(self, status: str):
        try:
            if not _is_valid_cpp(self):
                return
            self._status = status
            if self.game_data:
                self.game_data["status"] = status
            self._update_status_display()
            self._update_action_button()
        except RuntimeError:
            pass

    def set_cloud_check_status(self, status: str):
        try:
            if not _is_valid_cpp(self):
                return
            self._cloud_check = status
            self._update_overlay_badges()
        except RuntimeError:
            pass

    def update_image_from_path(self, path: str):
        try:
            if not _is_valid_cpp(self):
                return
            pixmap = QPixmap(path)
            if not pixmap.isNull():
                self.set_image(pixmap)
        except RuntimeError:
            pass

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "_border_overlay") and self._border_overlay:
            self._border_overlay.setGeometry(self.rect())
            self._border_overlay.raise_()

    def enterEvent(self, event):
        """Animate rim glow on hover."""
        super().enterEvent(event)
        if hasattr(self, "_border_overlay") and self._border_overlay:
            self._border_overlay.set_hovered(True)
        self.glow_anim.stop()
        self.glow_anim.setStartValue(self.shadow.blurRadius())
        self.glow_anim.setEndValue(16)
        self.glow_anim.start()

    def leaveEvent(self, event):
        """Fade out rim glow."""
        super().leaveEvent(event)
        if hasattr(self, "_border_overlay") and self._border_overlay:
            self._border_overlay.set_hovered(False)
        self.glow_anim.stop()
        self.glow_anim.setStartValue(self.shadow.blurRadius())
        self.glow_anim.setEndValue(0)
        self.glow_anim.start()

    def mousePressEvent(self, event):
        """Handle whole card click to open configuration."""
        if event.button() == Qt.MouseButton.LeftButton:
            child = self.childAt(event.position().toPoint())
            if child not in (self._action_btn, self._more_btn, self._fav_btn):
                self.clicked.emit(self.game_data)
        super().mousePressEvent(event)

    # ── Controller navigation (app/ui/gamepad_nav.py) ──

    def gamepad_activate(self):
        self.clicked.emit(self.game_data)

    def gamepad_secondary(self):
        if self._action_btn.isVisible() and self._action_btn.isEnabled():
            self._action_btn.click()

    def gamepad_tertiary(self):
        self._show_more_menu()

    def gamepad_hints(self) -> list[tuple[str, str]]:
        hints = [("A", "Cấu hình")]
        if self._action_btn.isVisible() and self._action_btn.isEnabled():
            hints.append(("X", self._action_btn.text().replace("▶", "").strip()))
        hints.append(("Y", "Tuỳ chọn"))
        return hints

    def _show_more_menu(self):
        """Open popup context menu for game management."""
        menu = self._build_context_menu()
        menu.exec(self._more_btn.mapToGlobal(QPoint(0, self._more_btn.height())))

    def _build_context_menu(self) -> QMenu:
        """Create sleek luxury popup menu."""
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: #121422;
                border: 1px solid rgba(139, 92, 246, 0.35);
                border-radius: 10px;
                padding: 6px;
            }
            QMenu::item {
                padding: 8px 24px 8px 12px;
                color: #e2e8f0;
                border-radius: 6px;
                font-size: 12px;
            }
            QMenu::item:selected {
                background-color: rgba(139, 92, 246, 0.22);
                color: #ffffff;
            }
            QMenu::separator {
                height: 1px;
                background: rgba(255, 255, 255, 0.08);
                margin: 4px 6px;
            }
        """)

        has_path = bool(self.game_data.get("save_path"))

        exe_for_menu = (self.game_data.get("exe_path") or "").strip().strip('"')
        if exe_for_menu and os.path.isfile(exe_for_menu):
            direct_act = menu.addAction(
                make_svg_icon("play", size=14, color="#10b981"),
                "Chạy trực tiếp .exe (không qua Steam)",
            )
            direct_act.triggered.connect(
                lambda: self.launch_requested.emit({**self.game_data, "_force_direct_exe": True})
            )
            menu.addSeparator()

        sync_act = menu.addAction(make_svg_icon("sync", size=14, color="#a855f7"), "Đồng bộ ngay")
        sync_act.setEnabled(has_path)
        sync_act.triggered.connect(lambda: self.sync_now_requested.emit(self.game_data))

        cfg_act = menu.addAction(make_svg_icon("settings", size=14, color="#cbd5e1"), "Cấu hình Đường dẫn lưu...")
        cfg_act.triggered.connect(lambda: self.clicked.emit(self.game_data))

        exe_act = menu.addAction(make_svg_icon("folder", size=14, color="#38bdf8"), "Cài đặt file chạy game (.exe)...")
        exe_act.triggered.connect(self._on_setup_exe)

        art_act = menu.addAction(make_svg_icon("image", size=14, color="#cbd5e1"), "Đổi ảnh bìa Steam...")
        art_act.triggered.connect(lambda: self.steam_artwork_requested.emit(self.game_data))

        excl_act = menu.addAction(make_svg_icon("shield", size=14, color="#cbd5e1"), "Quy tắc loại trừ (.bobignore)...")
        excl_act.triggered.connect(lambda: self.exclude_requested.emit(self.game_data))

        open_act = menu.addAction(make_svg_icon("folder", size=14, color="#cbd5e1"), "Mở thư mục save...")
        open_act.setEnabled(has_path and os.path.exists(self.game_data.get("save_path", "")))
        open_act.triggered.connect(self._open_save_folder)

        fav_is_on = bool(self.game_data.get("favorite"))
        fav_icon = make_svg_icon("star", size=14, color="#f59e0b" if fav_is_on else "#cbd5e1")
        fav_act = menu.addAction(fav_icon, "Bỏ yêu thích" if fav_is_on else "Thêm vào yêu thích")
        fav_act.triggered.connect(self._on_fav_clicked)

        menu.addSeparator()

        unsync_act = menu.addAction(make_svg_icon("close", size=14, color="#ef4444"), "Hủy đồng bộ khỏi Cloud")
        unsync_act.setEnabled(self.game_data.get("on_cloud", False))
        unsync_act.triggered.connect(lambda: self.unsync_requested.emit(self.game_data))

        exe_path = (self.game_data.get("exe_path") or "").strip().strip('"')
        if exe_path and os.path.isfile(exe_path):
            uninst_act = menu.addAction(make_svg_icon("trash", size=14, color="#ef4444"), "Gỡ cài đặt game...")
            uninst_act.triggered.connect(lambda: self.uninstall_requested.emit(self.game_data))

        del_act = menu.addAction(make_svg_icon("close", size=14, color="#cbd5e1"), "Xóa game khỏi thư viện")
        del_act.triggered.connect(lambda: self.remove_requested.emit(self.game_data))

        return menu

    def _open_save_folder(self):
        save_path = self.game_data.get("save_path", "")
        if save_path and os.path.exists(save_path):
            os.startfile(save_path)


class GameListRow(QWidget):
    """Compact row for List View (Chế độ xem danh sách)."""

    clicked = Signal(dict)
    remove_requested = Signal(dict)
    uninstall_requested = Signal(dict)
    sync_now_requested = Signal(dict)
    unsync_requested = Signal(dict)
    exclude_requested = Signal(dict)
    steam_artwork_requested = Signal(dict)
    favorite_toggled = Signal(dict)
    launch_requested = Signal(dict)
    exe_path_changed = Signal(str, str)

    def __init__(self, game_data: dict = None, parent=None):
        super().__init__(parent)
        self.game_data = game_data or {}
        self._status = self.game_data.get("status", SYNC_STATUS_NOT_CONFIGURED)
        self._cloud_check = CLOUD_CHECK_PENDING

        self.setFixedHeight(62)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)  # controller navigation (gamepad_nav)
        self.setStyleSheet("""
            QWidget {
                background-color: #12131e;
                border: 1px solid rgba(255, 255, 255, 0.06);
                border-radius: 8px;
            }
            QWidget:hover {
                background-color: #171828;
                border-color: rgba(139, 92, 246, 0.4);
            }
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 6, 12, 6)
        layout.setSpacing(12)

        # 1. Favorite button
        self._fav_btn = QPushButton(self)
        self._fav_btn.setFixedSize(26, 26)
        self._fav_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._fav_btn.clicked.connect(self._on_fav_clicked)
        layout.addWidget(self._fav_btn)

        # 2. Thumbnail
        self.thumb_label = QLabel(self)
        self.thumb_label.setFixedSize(36, 44)
        self.thumb_label.setStyleSheet("background-color: #1a1b2b; border-radius: 4px;")
        self.thumb_label.setScaledContents(True)
        layout.addWidget(self.thumb_label)

        # 3. Name & Subtitles (Installed status and Sync status)
        name_box = QVBoxLayout()
        name_box.setSpacing(1)
        self.name_label = QLabel(self.game_data.get("name", "Trò chơi"), self)
        self.name_label.setStyleSheet("color: #ffffff; font-weight: 700; font-size: 13px; background: transparent; border: none;")
        self._status_label = QLabel("☁ Chưa cài đặt", self)
        self._status_label.setStyleSheet("color: #94a3b8; font-size: 11px; background: transparent; border: none;")
        self._sync_status_label = QLabel("○ Chưa đồng bộ", self)
        self._sync_status_label.setStyleSheet("color: #94a3b8; font-size: 11px; background: transparent; border: none;")
        name_box.addWidget(self.name_label)
        name_box.addWidget(self._status_label)
        name_box.addWidget(self._sync_status_label)
        layout.addLayout(name_box, 1)

        # 4. Cloud badge
        self._cloud_badge = QLabel("☁ Cloud", self)
        self._cloud_badge.setStyleSheet("""
            color: #38bdf8;
            background: rgba(14, 22, 36, 0.85);
            border: 1px solid rgba(56, 189, 248, 0.4);
            border-radius: 4px;
            padding: 2px 7px;
            font-size: 10px;
        """)
        self._cloud_badge.hide()
        layout.addWidget(self._cloud_badge)

        # 5. Action button
        self._action_btn = QPushButton(self)
        self._action_btn.setFixedHeight(30)
        self._action_btn.setFixedWidth(90)
        self._action_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._action_btn.clicked.connect(self._on_action_clicked)
        layout.addWidget(self._action_btn)

        # 6. More button
        self._more_btn = QPushButton("•••", self)
        self._more_btn.setObjectName("cardActionMore")
        self._more_btn.setFixedSize(34, 30)
        self._more_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._more_btn.clicked.connect(self._show_more_menu)
        layout.addWidget(self._more_btn)

        self._update_all()

    def _update_all(self):
        is_fav = bool(self.game_data.get("favorite", False))
        if is_fav:
            self._fav_btn.setIcon(make_svg_icon("heart_filled", 14, "#f59e0b", "#f59e0b"))
            self._fav_btn.setStyleSheet("background: transparent; border: none;")
        else:
            self._fav_btn.setIcon(make_svg_icon("heart", 14, "#f87171", "#ef4444"))
            self._fav_btn.setStyleSheet("background: transparent; border: none;")

        exe_path = (self.game_data.get("exe_path") or "").strip()
        exe_exists = bool(exe_path and os.path.isfile(exe_path))
        is_installed = bool(exe_exists or (exe_path and exe_path.lower().endswith(".exe")))
        has_path = bool(self.game_data.get("save_path"))

        # 1. Trạng thái cài đặt
        if is_installed:
            name_key = self.game_data.get("name", "").lower()
            size_val = self.game_data.get("size")
            if not size_val:
                for k, v in KNOWN_SIZES.items():
                    if k in name_key or name_key in k:
                        size_val = v
                        break
            size_str = f"  {size_val}" if size_val else ""
            self._status_label.setText(f"● Đã cài đặt{size_str}")
            self._status_label.setStyleSheet("color: #10b981; font-size: 11px; font-weight: 600; background: transparent; border: none;")
            if exe_exists:
                self._action_btn.setFixedWidth(80)
                self._action_btn.setObjectName("cardActionGreen")
                self._action_btn.setText("▶ Chơi")
                self._action_btn.setStyleSheet(GREEN_BTN_STYLE)
                self._action_btn.setToolTip("Khởi chạy trò chơi")
            else:
                self._action_btn.setFixedWidth(145)
                self._action_btn.setObjectName("cardActionSetupExe")
                self._action_btn.setText("Cài đặt file chạy game")
                self._action_btn.setStyleSheet(SETUP_EXE_BTN_STYLE)
                self._action_btn.setToolTip("Cài đặt file thực thi (.exe) để khởi chạy trò chơi")
        elif not has_path:
            self._status_label.setText("☁ Chưa cài đặt")
            self._status_label.setStyleSheet("color: #94a3b8; font-size: 11px; background: transparent; border: none;")
            self._action_btn.setFixedWidth(85)
            self._action_btn.setObjectName("cardActionPurple")
            self._action_btn.setText("▶ Cài đặt")
            self._action_btn.setStyleSheet(PURPLE_BTN_STYLE)
            self._action_btn.setToolTip("Cấu hình đường dẫn lưu game")
        else:
            self._status_label.setText("☁ Chưa cài đặt")
            self._status_label.setStyleSheet("color: #94a3b8; font-size: 11px; background: transparent; border: none;")
            self._action_btn.setFixedWidth(145)
            self._action_btn.setObjectName("cardActionSetupExe")
            self._action_btn.setText("Cài đặt file chạy game")
            self._action_btn.setStyleSheet(SETUP_EXE_BTN_STYLE)
            self._action_btn.setToolTip("Cài đặt file thực thi (.exe) để khởi chạy trò chơi")

        # 2. Trạng thái đồng bộ đám mây
        is_synced = (self._status == SYNC_STATUS_SYNCED) or (
            bool(self.game_data.get("on_cloud")) and self._status not in [SYNC_STATUS_NOT_SYNCED, SYNC_STATUS_ERROR]
        )
        if self._status == SYNC_STATUS_SYNCING:
            self._sync_status_label.setText("● Đang đồng bộ...")
            self._sync_status_label.setStyleSheet("color: #fbbf24; font-size: 11px; font-weight: 500; background: transparent; border: none;")
        elif self._status == SYNC_STATUS_ERROR:
            self._sync_status_label.setText("● Lỗi đồng bộ")
            self._sync_status_label.setStyleSheet("color: #ef4444; font-size: 11px; font-weight: 500; background: transparent; border: none;")
        elif is_synced:
            self._sync_status_label.setText("● Đã đồng bộ")
            self._sync_status_label.setStyleSheet("color: #10b981; font-size: 11px; font-weight: 500; background: transparent; border: none;")
        else:
            self._sync_status_label.setText("○ Chưa đồng bộ")
            self._sync_status_label.setStyleSheet("color: #94a3b8; font-size: 11px; font-weight: 500; background: transparent; border: none;")

        if self.game_data.get("on_cloud", False):
            self._cloud_badge.show()
        else:
            self._cloud_badge.hide()

    def _on_fav_clicked(self):
        is_fav = not bool(self.game_data.get("favorite", False))
        self.game_data["favorite"] = is_fav
        self._update_all()
        self.favorite_toggled.emit(self.game_data)

    def _on_action_clicked(self):
        has_path = bool(self.game_data.get("save_path"))
        exe_path = self.game_data.get("exe_path", "")
        exe_exists = bool(exe_path and os.path.isfile(exe_path))

        if exe_exists:
            try:
                pass
                # Delegated to MainWindow._on_launch_game via launch_requested (Steam Non-Steam or direct fallback)
                self.launch_requested.emit(self.game_data)
            except Exception as e:
                logger.error(f"Failed to launch {exe_path}: {e}")
                self.clicked.emit(self.game_data)
        elif not has_path:
            self.clicked.emit(self.game_data)
        else:
            self._on_setup_exe()

    def _on_setup_exe(self):
        """Prompt user to choose executable (.exe) for this game."""
        game_name = self.game_data.get("name", "")
        curr_exe = self.game_data.get("exe_path", "")
        start_dir = ""
        if curr_exe and os.path.isdir(os.path.dirname(curr_exe)):
            start_dir = os.path.dirname(curr_exe)
        elif self.game_data.get("save_path") and os.path.isdir(self.game_data.get("save_path")):
            start_dir = self.game_data.get("save_path")
        else:
            start_dir = os.environ.get("PROGRAMFILES", "C:/")

        file_path, _ = QFileDialog.getOpenFileName(
            self,
            f"Chọn file thực thi (.exe) cho {game_name}",
            start_dir,
            "Tệp thực thi (*.exe);;Tất cả tệp (*.*)"
        )
        if file_path:
            file_path = os.path.abspath(file_path).replace("\\", "/")
            self.game_data["exe_path"] = file_path
            self.exe_path_changed.emit(game_name, file_path)
            self._update_all()

    def _update_action_button(self):
        self._update_all()

    # ── Controller navigation (app/ui/gamepad_nav.py) ──

    def gamepad_activate(self):
        self.clicked.emit(self.game_data)

    def gamepad_secondary(self):
        if self._action_btn.isVisible() and self._action_btn.isEnabled():
            self._action_btn.click()

    def gamepad_tertiary(self):
        self._show_more_menu()

    def gamepad_hints(self) -> list[tuple[str, str]]:
        hints = [("A", "Cấu hình")]
        if self._action_btn.isVisible() and self._action_btn.isEnabled():
            hints.append(("X", self._action_btn.text().replace("▶", "").strip()))
        hints.append(("Y", "Tuỳ chọn"))
        return hints

    def _show_more_menu(self):
        card_dummy = GameCard(self.game_data, parent=self)
        card_dummy.remove_requested.connect(self.remove_requested.emit)
        card_dummy.uninstall_requested.connect(self.uninstall_requested.emit)
        card_dummy.sync_now_requested.connect(self.sync_now_requested.emit)
        card_dummy.unsync_requested.connect(self.unsync_requested.emit)
        card_dummy.exclude_requested.connect(self.exclude_requested.emit)
        card_dummy.steam_artwork_requested.connect(self.steam_artwork_requested.emit)
        card_dummy.favorite_toggled.connect(self.favorite_toggled.emit)
        card_dummy.launch_requested.connect(self.launch_requested.emit)
        card_dummy.clicked.connect(self.clicked.emit)
        menu = card_dummy._build_context_menu()
        menu.exec(self._more_btn.mapToGlobal(QPoint(0, self._more_btn.height())))

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.game_data)
        super().mousePressEvent(event)

    def set_image(self, pixmap: QPixmap):
        if pixmap and not pixmap.isNull():
            scaled = pixmap.scaled(36, 44, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
            if scaled.width() > 36 or scaled.height() > 44:
                x = max(0, (scaled.width() - 36) // 2) if scaled.width() > 36 else 0
                y = 0
                scaled = scaled.copy(x, y, 36, 44)
            self.thumb_label.setPixmap(scaled)

    def set_status(self, status: str):
        self._status = status
        self._update_all()

    def set_cloud_check_status(self, status: str):
        self._cloud_check = status
        if status == CLOUD_CHECK_CHECKING:
            self._cloud_badge.setText("Kiểm tra...")
            self._cloud_badge.show()
        elif self.game_data.get("on_cloud", False):
            self._cloud_badge.setText("☁ Cloud")
            self._cloud_badge.show()
        else:
            self._cloud_badge.hide()

    def update_image_from_path(self, path: str):
        pix = QPixmap(path)
        if not pix.isNull():
            self.set_image(pix)
