# Bob Gaming Game Center - UI Package
from app.ui.i18n_ui import install_qt_i18n_hooks

install_qt_i18n_hooks()
