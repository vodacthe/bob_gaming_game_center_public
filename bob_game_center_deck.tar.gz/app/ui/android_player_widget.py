"""Embedded split-screen Android Emulator display & input panel with FPS HUD, Pop-Out, and Fullscreen modes."""

from __future__ import annotations

import logging

from PySide6.QtCore import QEvent, QObject, QPoint, QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import (
    QColor,
    QFont,
    QFontMetrics,
    QGuiApplication,
    QImage,
    QKeyEvent,
    QMouseEvent,
    QPainter,
    QPainterPath,
    QPen,
    QWheelEvent,
)
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from app.core.android.gamepad.bridge import (
    STATE_ACTIVE,
    STATE_ERROR,
    STATE_READY,
    AndroidGamepadBridge,
    BridgeStatus,
)
from app.core.android.gamepad.settings import load_gamepad_settings, save_gamepad_settings
from app.core.android.models import (
    RUNTIME_EXTERNAL_ADB,
    RUNTIME_PORTABLE_SDK,
    RUNTIME_SYSTEM_SDK,
    RUNTIME_WAYDROID,
    RuntimeInfo,
)
from app.core.android.native_window import EmulatorWindowEmbedder, GuestDisplayMonitor
from app.core.android.runtime import AndroidRuntimeManager, DEFAULT_AVD_NAME
from app.core.android.scrcpy_client import (
    AKEY_EVENT_ACTION_DOWN,
    AKEY_EVENT_ACTION_UP,
    AMOTION_EVENT_ACTION_DOWN,
    AMOTION_EVENT_ACTION_MOVE,
    AMOTION_EVENT_ACTION_UP,
    EmulatorWindowController,
    ScrcpyStreamClient,
)
from app.ui.game_card import DARK_BTN_STYLE, GREEN_BTN_STYLE
from app.ui.icons import make_svg_icon
from app.ui.online_fix.common import safe_slot

logger = logging.getLogger(__name__)
TAG = "[Android/Player]"

KEYCODE_HOME = 3
KEYCODE_BACK = 4
KEYCODE_VOLUME_UP = 24
KEYCODE_VOLUME_DOWN = 25
KEYCODE_APP_SWITCH = 187

_QT_KEY_MAP: dict[int, int] = {
    int(Qt.Key.Key_Up): 19,
    int(Qt.Key.Key_Down): 20,
    int(Qt.Key.Key_Left): 21,
    int(Qt.Key.Key_Right): 22,
    int(Qt.Key.Key_Return): 66,
    int(Qt.Key.Key_Enter): 66,
    int(Qt.Key.Key_Backspace): 67,
    int(Qt.Key.Key_Delete): 112,
    int(Qt.Key.Key_Tab): 61,
    int(Qt.Key.Key_Space): 62,
    int(Qt.Key.Key_Home): 122,
    int(Qt.Key.Key_End): 123,
    int(Qt.Key.Key_PageUp): 92,
    int(Qt.Key.Key_PageDown): 93,
}
for _idx, _ch in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
    _QT_KEY_MAP[int(getattr(Qt.Key, f"Key_{_ch}"))] = 29 + _idx
for _idx in range(10):
    _QT_KEY_MAP[int(getattr(Qt.Key, f"Key_{_idx}"))] = 7 + _idx

_PLAYER_FRAME_STYLE = """
    QFrame#androidPlayerPanel {
        background-color: #090d16;
        border: 1px solid #1e293b;
        border-radius: 12px;
    }
"""

_TOOLBAR_BTN_STYLE = """
    QPushButton {
        background-color: #151c2c;
        color: #cbd5e1;
        border: 1px solid #263248;
        border-radius: 7px;
        padding: 0 8px;
        font-size: 11px;
        font-weight: 600;
    }
    QPushButton:hover {
        background-color: #1e293b;
        color: #f8fafc;
        border-color: #38bdf8;
    }
    QPushButton:disabled {
        color: #475569;
        border-color: #161e2e;
    }
"""

_DANGER_BTN_STYLE = """
    QPushButton {
        background-color: rgba(239, 68, 68, 0.12);
        color: #fca5a5;
        border: 1px solid rgba(239, 68, 68, 0.32);
        border-radius: 7px;
        padding: 0 8px;
        font-size: 11px;
        font-weight: 600;
    }
    QPushButton:hover {
        background-color: rgba(239, 68, 68, 0.24);
        color: #fecaca;
        border-color: #ef4444;
    }
    QPushButton:disabled {
        color: #475569;
        background-color: transparent;
        border-color: #161e2e;
    }
"""


def _fps_badge_style(color_hex: str, active: bool) -> str:
    bg = "rgba(15, 23, 42, 0.92)" if active else "rgba(15, 23, 42, 0.55)"
    border = color_hex if active else "#263248"
    return f"""
        QPushButton {{
            background-color: {bg};
            color: {color_hex};
            border: 1px solid {border};
            border-radius: 7px;
            padding: 0 8px;
            font-size: 11px;
            font-weight: 700;
        }}
        QPushButton:hover {{
            background-color: #1e293b;
            border-color: #38bdf8;
        }}
        QPushButton:disabled {{
            color: #475569;
            border-color: #161e2e;
        }}
    """


class ElidedTextLabel(QLabel):
    """Single-line QLabel with zero horizontal min-width that elides cleanly with full QSS styling."""

    def __init__(self, text: str = "", parent: QWidget | None = None) -> None:
        super().__init__("", parent)
        self._full_text = ""
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.setMinimumWidth(0)
        if text:
            self.setText(text)

    def setText(self, text: str) -> None:  # type: ignore[override]
        self._full_text = text or ""
        self.setToolTip(self._full_text)
        self._sync_elided()

    def text(self) -> str:  # type: ignore[override]
        return self._full_text

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._sync_elided()

    def _sync_elided(self) -> None:
        avail = self.width()
        if avail <= 4:
            super().setText(self._full_text)
            return
        self.ensurePolished()
        elided = QFontMetrics(self.font()).elidedText(
            self._full_text, Qt.TextElideMode.ElideRight, max(12, avail - 2)
        )
        super().setText(elided)


class _ToolbarButton(QPushButton):
    """Fixed-size-policy toolbar button whose sizeHint accounts for bold QSS font + icon without clipping."""

    def __init__(self, text: str = "", parent: QWidget | None = None, height: int = 28) -> None:
        super().__init__(text, parent)
        self._btn_h = height
        self.setFixedHeight(height)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

    def setText(self, text: str) -> None:  # type: ignore[override]
        super().setText(text)
        self.updateGeometry()

    def sizeHint(self) -> QSize:
        txt = self.text()
        has_icon = not self.icon().isNull()
        if not txt:
            return QSize(30, self._btn_h)
        f = QFont("Segoe UI")
        f.setPixelSize(11)
        f.setBold(True)
        txt_w = QFontMetrics(f).horizontalAdvance(txt.replace("&&", "&"))
        icon_w = (self.iconSize().width() + 5) if has_icon else 0
        return QSize(txt_w + icon_w + 20, self._btn_h)

    def minimumSizeHint(self) -> QSize:
        return self.sizeHint()


class _VideoCanvas(QWidget):
    """Aspect-preserving frame canvas with optional FPS/latency HUD overlay and touch/key translation."""

    escape_pressed = Signal()
    focus_changed = Signal(bool)

    def __init__(self, stream: ScrcpyStreamClient, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._stream = stream
        self._frame: QImage | None = None
        self._target_rect = QRectF()
        self._mouse_down = False
        self._boot_pct: int | None = None
        self._status_headline = "Máy ảo Android chưa khởi động"
        self._status_hint = "Bấm Khởi động hoặc mở một game Android bất kỳ để chơi ngay trong cửa sổ này."
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(False)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(320, 240)

    def set_frame(self, img: QImage | None) -> None:
        self._frame = img
        if img is not None:
            self._boot_pct = None
        if self.isVisible():
            self.update()

    def set_boot_progress(self, pct: int, headline: str, hint: str = "") -> None:
        self._frame = None
        self._boot_pct = max(0, min(100, int(pct)))
        self._status_headline = headline
        self._status_hint = hint
        if self.isVisible():
            self.update()

    def set_placeholder(self, headline: str, hint: str = "") -> None:
        self._status_headline = headline
        self._status_hint = hint
        if self._frame is None and self.isVisible():
            self.update()

    def clear_frame(self, headline: str, hint: str = "") -> None:
        self._frame = None
        self._boot_pct = None
        self._status_headline = headline
        self._status_hint = hint
        if self.isVisible():
            self.update()

    def _compute_target_rect(self, img_w: int, img_h: int) -> QRectF:
        cw = max(1.0, float(self.width()))
        ch = max(1.0, float(self.height()))
        if img_w <= 0 or img_h <= 0:
            return QRectF(0.0, 0.0, cw, ch)
        scale = min(cw / img_w, ch / img_h)
        dw = img_w * scale
        dh = img_h * scale
        return QRectF((cw - dw) * 0.5, (ch - dh) * 0.5, dw, dh)

    def _map_pos(self, pos: QPointF) -> tuple[int, int] | None:
        vw, vh = self._stream.video_size
        if vw <= 0 or vh <= 0:
            if self._frame is not None and not self._frame.isNull():
                vw, vh = self._frame.width(), self._frame.height()
            else:
                return None
        rect = self._compute_target_rect(vw, vh)
        if rect.width() <= 1.0 or rect.height() <= 1.0:
            return None
        nx = (pos.x() - rect.left()) / rect.width()
        ny = (pos.y() - rect.top()) / rect.height()
        nx = max(0.0, min(1.0, nx))
        ny = max(0.0, min(1.0, ny))
        return int(nx * (vw - 1)), int(ny * (vh - 1))

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#05070c"))
        img = self._frame
        if img is not None and not img.isNull():
            painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
            self._target_rect = self._compute_target_rect(img.width(), img.height())
            painter.drawImage(self._target_rect, img)
        else:
            cy = self.height() * 0.5
            painter.setPen(QColor("#f8fafc" if self._boot_pct is not None else "#e2e8f0"))
            font = painter.font()
            font.setPointSize(11)
            font.setBold(True)
            painter.setFont(font)
            head_rc = QRectF(24.0, cy - 54.0, max(60.0, self.width() - 48.0), 34.0)
            painter.drawText(head_rc, Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, self._status_headline)
            if self._status_hint:
                font.setPointSize(9)
                font.setBold(False)
                painter.setFont(font)
                painter.setPen(QColor("#cbd5e1" if self._boot_pct is not None else "#94a3b8"))
                sub_rc = QRectF(24.0, cy - 14.0, max(60.0, self.width() - 48.0), 42.0)
                painter.drawText(sub_rc, Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, self._status_hint)
            if self._boot_pct is not None:
                painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                bar_w = min(260.0, max(120.0, self.width() - 64.0))
                bar_h = 8.0
                bx = (self.width() - bar_w) * 0.5
                by = cy + 36.0
                track_path = QPainterPath()
                track_path.addRoundedRect(QRectF(bx, by, bar_w, bar_h), 4.0, 4.0)
                painter.fillPath(track_path, QColor(30, 41, 59, 220))
                fill_w = max(8.0, bar_w * (self._boot_pct / 100.0))
                fill_path = QPainterPath()
                fill_path.addRoundedRect(QRectF(bx, by, fill_w, bar_h), 4.0, 4.0)
                painter.fillPath(fill_path, QColor("#a855f7" if self._boot_pct < 85 else "#10b981"))
                font.setPointSize(9)
                font.setBold(True)
                painter.setFont(font)
                painter.setPen(QColor("#38bdf8"))
                pct_rc = QRectF(bx, by + 13.0, bar_w, 20.0)
                painter.drawText(pct_rc, Qt.AlignmentFlag.AlignCenter, f"{self._boot_pct}%")
        painter.end()

    def focusInEvent(self, event) -> None:
        super().focusInEvent(event)
        self.focus_changed.emit(True)

    def focusOutEvent(self, event) -> None:
        super().focusOutEvent(event)
        self.focus_changed.emit(False)

    def mousePressEvent(self, event: QMouseEvent) -> None:
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        if event.button() == Qt.MouseButton.LeftButton:
            mapped = self._map_pos(event.position())
            if mapped is not None:
                self._mouse_down = True
                self._stream.send_touch(AMOTION_EVENT_ACTION_DOWN, mapped[0], mapped[1])
        elif event.button() == Qt.MouseButton.RightButton:
            self._stream.send_keycode(KEYCODE_BACK)
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if self._mouse_down and (event.buttons() & Qt.MouseButton.LeftButton):
            mapped = self._map_pos(event.position())
            if mapped is not None:
                self._stream.send_touch(AMOTION_EVENT_ACTION_MOVE, mapped[0], mapped[1])
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton and self._mouse_down:
            self._mouse_down = False
            mapped = self._map_pos(event.position())
            if mapped is not None:
                self._stream.send_touch(AMOTION_EVENT_ACTION_UP, mapped[0], mapped[1])
        super().mouseReleaseEvent(event)

    def wheelEvent(self, event: QWheelEvent) -> None:
        mapped = self._map_pos(event.position())
        if mapped is not None:
            delta = event.angleDelta()
            v_step = max(-1.0, min(1.0, delta.y() / 120.0))
            h_step = max(-1.0, min(1.0, delta.x() / 120.0))
            if v_step != 0.0 or h_step != 0.0:
                self._stream.send_scroll(mapped[0], mapped[1], h_step, v_step)
        event.accept()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key.Key_Escape:
            self.escape_pressed.emit()
            event.accept()
            return
        if event.isAutoRepeat():
            return
        keycode = _QT_KEY_MAP.get(int(event.key()))
        if keycode is not None:
            self._stream.send_key_event(AKEY_EVENT_ACTION_DOWN, keycode)
            event.accept()
            return
        txt = event.text()
        if txt and txt.isprintable():
            self._stream.send_text(txt)
            event.accept()
            return
        super().keyPressEvent(event)

    def keyReleaseEvent(self, event: QKeyEvent) -> None:
        if not event.isAutoRepeat():
            keycode = _QT_KEY_MAP.get(int(event.key()))
            if keycode is not None:
                self._stream.send_key_event(AKEY_EVENT_ACTION_UP, keycode)
                event.accept()
                return
        super().keyReleaseEvent(event)


class _NativeHost(QWidget):
    """Plain placeholder the emulator's own GPU window is laid over (an owned popup of the top-level window).

    Deliberately NOT a native widget: never set `WA_NativeWindow` or call `winId()` on it (see native_window.py).
    """

    resized = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet("background-color: #05070c;")
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(320, 240)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.resized.emit()


class _FullscreenHostWindow(QWidget):
    """Borderless fullscreen container temporarily holding the Android display.

    The scrcpy canvas leaves on Esc. The embedded emulator window owns the keyboard (Esc is Android's Back
    there), so that mode gets a slim exit bar instead.
    """

    closed = Signal()
    exit_clicked = Signal()

    def __init__(self, with_exit_bar: bool = False) -> None:
        super().__init__(None)
        self.setWindowTitle("Bob Gaming - Android Fullscreen")
        self.setStyleSheet("background-color: #05070c;")
        self.body_layout = QVBoxLayout(self)
        self.body_layout.setContentsMargins(0, 0, 0, 0)
        self.body_layout.setSpacing(0)
        if with_exit_bar:
            bar = QHBoxLayout()
            bar.setContentsMargins(8, 6, 8, 6)
            bar.addStretch()
            exit_btn = QPushButton("Thoát toàn màn hình")
            exit_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            exit_btn.setStyleSheet(DARK_BTN_STYLE)
            exit_btn.setIcon(make_svg_icon("fullscreen", size=14, color="#cbd5e1"))
            exit_btn.clicked.connect(self.exit_clicked.emit)
            bar.addWidget(exit_btn)
            self.body_layout.addLayout(bar)

    def closeEvent(self, event) -> None:
        self.closed.emit()
        super().closeEvent(event)


class AndroidPlayerPanel(QFrame):
    """Center split-screen Android Player with live FPS diagnostics, Pop-Out toggle, and background keep-alive."""

    boot_runtime_requested = Signal()
    stop_runtime_requested = Signal()
    collapse_requested = Signal()

    def __init__(self, runtime_mgr: AndroidRuntimeManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("androidPlayerPanel")
        self.setStyleSheet(_PLAYER_FRAME_STYLE)
        self.setMinimumWidth(360)

        self._runtime_mgr = runtime_mgr
        self._win_ctrl = EmulatorWindowController()
        self._stream = ScrcpyStreamClient(runtime_mgr, self)
        self._current_runtime: RuntimeInfo | None = None
        self._popped_out = False
        self._booting = False
        self._boot_headline = ""
        self._compact_toolbar = False
        self._last_fps = 0
        self._fullscreen_win: _FullscreenHostWindow | None = None
        self._fullscreen_native = False

        # Native path: the emulator's own GPU window lives inside `native_host` (no video encode / decode).
        self._native = EmulatorWindowEmbedder()
        self._monitor = GuestDisplayMonitor(runtime_mgr, self)
        self._native_fallback_logged = False
        self._embed_timer = QTimer(self)
        self._embed_timer.setInterval(300)
        self._embed_timer.timeout.connect(self._on_embed_poll)
        self._embed_polls_left = 0
        self._geom_timer = QTimer(self)
        # Short: the emulator moves itself ~1 s after each resize and must be pulled back quickly.
        self._geom_timer.setInterval(200)
        self._geom_timer.timeout.connect(self._on_geometry_tick)
        self._watched_ancestors: list[QObject] = []

        self._hide_poll_timer = QTimer(self)
        self._hide_poll_timer.setInterval(700)
        self._hide_poll_timer.timeout.connect(self._on_dock_window_poll)
        self._hide_polls_left = 0

        self._perf_timer = QTimer(self)
        self._perf_timer.setInterval(500)
        self._perf_timer.timeout.connect(self._on_perf_tick)

        # PC controllers / keyboard + mouse -> virtual gamepad inside Android.
        self._gamepad = AndroidGamepadBridge(runtime_mgr, self)
        self._gamepad_monitor = None
        self._gamepad.set_settings(load_gamepad_settings())

        self._build_ui()
        self._connect_signals()
        self._sync_controls()
        self._on_gamepad_status(self._gamepad.status)

    @property
    def is_popped_out(self) -> bool:
        return self._popped_out

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        # ---- Top Control Bar ----
        top_row = QHBoxLayout()
        top_row.setSpacing(5)

        title_col = QVBoxLayout()
        title_col.setSpacing(1)
        self.title_lbl = ElidedTextLabel("Màn hình Android")
        self.title_lbl.setStyleSheet("color: #f8fafc; font-size: 13px; font-weight: 700; border: none;")
        self.state_lbl = ElidedTextLabel("Chưa kết nối")
        self.state_lbl.setStyleSheet("color: #64748b; font-size: 11px; border: none;")
        title_col.addWidget(self.title_lbl)
        title_col.addWidget(self.state_lbl)
        top_row.addLayout(title_col, 1)

        self.fps_btn = _ToolbarButton("FPS")
        self.fps_btn.setStyleSheet(_fps_badge_style("#94a3b8", True))
        self.fps_btn.setToolTip("Chẩn đoán hiệu năng luồng hình ảnh (FPS · Độ trễ giải mã · Bitrate)")
        top_row.addWidget(self.fps_btn)

        self.gamepad_btn = _ToolbarButton("Tay cầm")
        self.gamepad_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.gamepad_btn.setStyleSheet(_TOOLBAR_BTN_STYLE)
        self.gamepad_btn.setIcon(make_svg_icon("gamepad", size=14, color="#cbd5e1"))
        top_row.addWidget(self.gamepad_btn)

        self.popout_btn = _ToolbarButton("Tách cửa sổ")
        self.popout_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.popout_btn.setStyleSheet(_TOOLBAR_BTN_STYLE)
        self.popout_btn.setIcon(make_svg_icon("pop_out", size=14, color="#cbd5e1"))
        self.popout_btn.setToolTip("Tách máy ảo Android ra cửa sổ riêng hoặc gắn lại vào Bob Gaming")
        top_row.addWidget(self.popout_btn)

        self.rotate_btn = _ToolbarButton("Xoay")
        self.rotate_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.rotate_btn.setStyleSheet(_TOOLBAR_BTN_STYLE)
        self.rotate_btn.setIcon(make_svg_icon("rotate", size=14, color="#cbd5e1"))
        self.rotate_btn.setToolTip("Xoay ngang / dọc màn hình Android")
        top_row.addWidget(self.rotate_btn)

        self.fullscreen_btn = _ToolbarButton("Toàn màn hình")
        self.fullscreen_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.fullscreen_btn.setStyleSheet(_TOOLBAR_BTN_STYLE)
        self.fullscreen_btn.setIcon(make_svg_icon("fullscreen", size=14, color="#cbd5e1"))
        self.fullscreen_btn.setToolTip("Phóng toàn màn hình (bấm Esc để thu nhỏ)")
        top_row.addWidget(self.fullscreen_btn)

        self.power_btn = _ToolbarButton("Tắt")
        self.power_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.power_btn.setStyleSheet(_DANGER_BTN_STYLE)
        self.power_btn.setIcon(make_svg_icon("power", size=14, color="#fca5a5"))
        self.power_btn.setToolTip("Tắt hoàn toàn máy ảo Android")
        top_row.addWidget(self.power_btn)

        self.collapse_btn = _ToolbarButton("")
        self.collapse_btn.setFixedSize(28, 28)
        self.collapse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.collapse_btn.setStyleSheet(_TOOLBAR_BTN_STYLE)
        self.collapse_btn.setIcon(make_svg_icon("close", size=14, color="#94a3b8"))
        self.collapse_btn.setToolTip("Ẩn khung màn hình (game vẫn tiếp tục chạy nền)")
        top_row.addWidget(self.collapse_btn)

        root.addLayout(top_row)

        # ---- Video Canvas Container ----
        self.canvas_host = QWidget()
        self.canvas_host_layout = QVBoxLayout(self.canvas_host)
        self.canvas_host_layout.setContentsMargins(0, 0, 0, 0)
        self.canvas_host_layout.setSpacing(0)

        self.canvas = _VideoCanvas(self._stream, self.canvas_host)
        self.canvas_host_layout.addWidget(self.canvas, 1)
        self.native_host = _NativeHost(self.canvas_host)
        self.canvas_host_layout.addWidget(self.native_host, 1)
        self.native_host.hide()
        root.addWidget(self.canvas_host, 1)

        # ---- Idle Quick-Action Row ----
        self.quick_row_widget = QWidget()
        quick_row = QHBoxLayout(self.quick_row_widget)
        quick_row.setContentsMargins(0, 0, 0, 0)
        quick_row.addStretch()
        self.quick_boot_btn = QPushButton("Khởi động máy ảo Android")
        self.quick_boot_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.quick_boot_btn.setStyleSheet(GREEN_BTN_STYLE)
        self.quick_boot_btn.setIcon(make_svg_icon("play", size=14, color="#042612"))
        quick_row.addWidget(self.quick_boot_btn)
        quick_row.addStretch()
        root.addWidget(self.quick_row_widget)

        # ---- Bottom Android System Bar ----
        nav_row = QHBoxLayout()
        nav_row.setSpacing(6)

        self.back_nav_btn = QPushButton("Quay lại")
        self.home_nav_btn = QPushButton("Trang chủ")
        self.recents_nav_btn = QPushButton("Đa nhiệm")
        self.voldown_nav_btn = QPushButton()
        self.volup_nav_btn = QPushButton()

        for btn, icon_name, tip in (
            (self.back_nav_btn, "chevron_left", "Phím Back Android (Chuột phải)"),
            (self.home_nav_btn, "android_home", "Về màn hình chính Android"),
            (self.recents_nav_btn, "android_recents", "Ứng dụng gần đây"),
            (self.voldown_nav_btn, "volume_down", "Giảm âm lượng"),
            (self.volup_nav_btn, "volume_up", "Tăng âm lượng"),
        ):
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(DARK_BTN_STYLE)
            btn.setIcon(make_svg_icon(icon_name, size=14, color="#cbd5e1"))
            btn.setToolTip(tip)
            nav_row.addWidget(btn)

        self.voldown_nav_btn.setFixedWidth(38)
        self.volup_nav_btn.setFixedWidth(38)
        root.addLayout(nav_row)

    def _connect_signals(self) -> None:
        self.gamepad_btn.clicked.connect(self._on_gamepad_clicked)
        self._gamepad.status_changed.connect(self._on_gamepad_status)
        self.canvas.focus_changed.connect(self._gamepad.set_canvas_focused)
        gui_app = QGuiApplication.instance()
        if gui_app is not None:
            gui_app.applicationStateChanged.connect(self._on_app_state_changed)
        self.popout_btn.clicked.connect(self.toggle_pop_out)
        self.rotate_btn.clicked.connect(self._on_rotate_clicked)
        self.fullscreen_btn.clicked.connect(self.toggle_fullscreen)
        self.power_btn.clicked.connect(self._on_power_clicked)
        self.collapse_btn.clicked.connect(self.collapse_requested.emit)
        self.quick_boot_btn.clicked.connect(self._on_quick_boot_clicked)

        self.back_nav_btn.clicked.connect(lambda: self._send_android_key(KEYCODE_BACK))
        self.home_nav_btn.clicked.connect(lambda: self._send_android_key(KEYCODE_HOME))
        self.recents_nav_btn.clicked.connect(lambda: self._send_android_key(KEYCODE_APP_SWITCH))
        self.voldown_nav_btn.clicked.connect(lambda: self._send_android_key(KEYCODE_VOLUME_DOWN))
        self.volup_nav_btn.clicked.connect(lambda: self._send_android_key(KEYCODE_VOLUME_UP))
        self.native_host.resized.connect(self._on_geometry_tick)
        self._monitor.stats_ready.connect(self._on_native_stats)

        self.canvas.escape_pressed.connect(self._on_canvas_escape)
        self._stream.frame_ready.connect(self._on_frame_ready)
        self._stream.stream_started.connect(self._on_stream_started)
        self._stream.stream_stopped.connect(self._on_stream_stopped)
        self._stream.stream_error.connect(self._on_stream_error)

    def _toolbar_tier(self) -> int:
        w = self.width()
        if w <= 0 or w >= 680:
            return 0
        return 2 if w < 520 else 1

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        tier = self._toolbar_tier()
        if tier != self._compact_toolbar:
            self._compact_toolbar = tier
            self._sync_controls()

    # ------------------------------------------------------------------ Native (embedded GPU window) display

    def _avd_name(self) -> str:
        rt = self._current_runtime
        return (rt.avd_name if rt else "") or DEFAULT_AVD_NAME

    def _native_wanted(self, rt: RuntimeInfo | None = None) -> bool:
        if self._popped_out or not self._native.supported:
            return False
        rt = rt or self._current_runtime
        return rt is None or rt.kind in (RUNTIME_PORTABLE_SDK, RUNTIME_SYSTEM_SDK)

    def _top_level_hwnd(self) -> int:
        # The top-level window is native anyway; calling winId() on any *child* widget would make it native.
        return int(self.native_host.window().winId())

    def _push_native_area(self) -> None:
        """Tell the embedder where the placeholder is (top-level client pixels) and whether it is on screen."""
        host = self.native_host
        top = host.window()
        visible = (
            host.isVisible()
            and not host.visibleRegion().isEmpty()
            and not top.isMinimized()
        )
        dpr = top.devicePixelRatioF() or 1.0
        origin = host.mapTo(top, QPoint(0, 0))
        self._native.set_area(
            round(origin.x() * dpr),
            round(origin.y() * dpr),
            round(host.width() * dpr),
            round(host.height() * dpr),
            visible,
        )

    def _watch_ancestors(self) -> None:
        """Follow moves / resizes / page switches of every ancestor so the overlay never lags behind the layout."""
        for obj in self._watched_ancestors:
            try:
                obj.removeEventFilter(self)
            except RuntimeError:
                pass
        self._watched_ancestors = []
        w: QWidget | None = self.native_host
        while w is not None:
            w.installEventFilter(self)
            self._watched_ancestors.append(w)
            if w.isWindow():
                break
            w = w.parentWidget()

    def eventFilter(self, obj, event) -> bool:  # noqa: N802
        try:
            if self._native.is_embedded and event.type() in (
                QEvent.Type.Move,
                QEvent.Type.Resize,
                QEvent.Type.Show,
                QEvent.Type.Hide,
                QEvent.Type.WindowStateChange,
                QEvent.Type.ParentChange,
            ):
                if event.type() == QEvent.Type.ParentChange:
                    self._watch_ancestors()
                self._on_geometry_tick()
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Native display layout sync failed")
        return False

    def _try_embed(self) -> bool:
        """Pull the emulator's GPU window over the player. False while the emulator has no window (yet)."""
        top_hwnd = self._top_level_hwnd()
        if self._native.is_embedded and self._native.is_alive() and self._native.parent_hwnd == top_hwnd:
            return True
        self.canvas.hide()
        self.native_host.show()
        self._push_native_area()
        if not self._native.embed(top_hwnd, self._avd_name()):
            self.native_host.hide()
            self.canvas.show()
            return False
        self._watch_ancestors()
        self._native.sync_geometry(force=True)
        self._geom_timer.start()
        return True

    def _leave_native(self, show_window: bool = False) -> None:
        """Detach the emulator window (hidden unless `show_window`) and bring the placeholder canvas back."""
        self._embed_timer.stop()
        self._geom_timer.stop()
        for obj in self._watched_ancestors:
            try:
                obj.removeEventFilter(self)
            except RuntimeError:
                pass
        self._watched_ancestors = []
        if self._native.has_window:
            self._native.release(show=show_window)
        self.native_host.hide()
        self.canvas.show()

    def _arm_embed_poll(self) -> None:
        if not self._native_wanted() or self._native.is_embedded:
            return
        self._embed_polls_left = 600
        if not self._embed_timer.isActive():
            self._embed_timer.start()

    @safe_slot
    def _on_embed_poll(self) -> None:
        self._embed_polls_left -= 1
        if self._embed_polls_left <= 0 or not self._native_wanted():
            self._embed_timer.stop()
            return
        if self._try_embed():
            self._embed_timer.stop()

    @safe_slot
    def _on_geometry_tick(self) -> None:
        if not self._native.is_embedded:
            return
        if self._native.parent_hwnd != self._top_level_hwnd():
            # The panel was moved into another top-level window (fullscreen): follow it.
            self._try_embed()
            return
        self._push_native_area()
        self._native.sync_geometry()
        if not self._native.has_window:
            # The emulator process exited underneath us.
            self._geom_timer.stop()
            self.native_host.hide()
            self.canvas.show()

    @safe_slot
    def _on_native_stats(self, fps: int, width: int, height: int) -> None:
        if not self._native.is_embedded:
            return
        self._native.set_display_size(int(width), int(height))
        self._update_fps_badge(int(fps), streaming=True)
        self.fps_btn.setToolTip(f"Hiển thị GPU trực tiếp (không mã hoá video): {fps} FPS · {width}x{height}")
        self.state_lbl.setText(f"Trực tiếp GPU · {width}x{height}")

    def _send_android_key(self, keycode: int) -> None:
        if self._native.is_embedded:
            self._monitor.send_keyevent(keycode)
        else:
            self._stream.send_keycode(keycode)

    # ------------------------------------------------------------------ Gamepad bridge

    def attach_gamepad_monitor(self, monitor) -> None:
        """Let the app's GamepadMonitor hand physical controllers to the Android gamepad bridge."""
        self._gamepad_monitor = monitor
        if monitor is not None:
            monitor.set_pad_tap(self._gamepad)

    def _sync_gamepad_presence(self) -> None:
        """Tell the bridge whether the Android display is what the user is looking at."""
        running = bool(self._current_runtime and self._current_runtime.running)
        top = self.window()
        on_screen = self.isVisible() and top is not None and not top.isMinimized()
        self._gamepad.set_player_active(running and (self._popped_out or self._fullscreen_win is not None or on_screen))

    @safe_slot
    def _on_app_state_changed(self, state) -> None:
        self._gamepad.set_app_active(state == Qt.ApplicationState.ApplicationActive)

    @safe_slot
    def _on_gamepad_status(self, status: BridgeStatus) -> None:
        state = getattr(status, "state", "")
        color = {STATE_ACTIVE: "#4ade80", STATE_READY: "#38bdf8", STATE_ERROR: "#f87171"}.get(state, "#cbd5e1")
        self.gamepad_btn.setIcon(make_svg_icon("gamepad", size=14, color=color))
        self.gamepad_btn.setToolTip(
            f"{getattr(status, 'text', '')}\nBấm để chọn tay cầm hoặc phím + chuột giả tay cầm cho Android."
        )

    @safe_slot
    def _on_gamepad_clicked(self) -> None:
        from app.ui.android_gamepad_dialog import AndroidGamepadDialog

        logger.info(f"{TAG} User opened the Android gamepad settings")
        dlg = AndroidGamepadDialog(self._gamepad, self._gamepad.settings, self.window())
        self._place_beside_player(dlg)
        accepted = dlg.exec() == AndroidGamepadDialog.DialogCode.Accepted
        chosen = dlg.result_settings
        dlg.deleteLater()
        if not accepted or chosen is None:
            return
        self._gamepad.set_settings(chosen)
        if not save_gamepad_settings(chosen):
            self.state_lbl.setText("Không lưu được cấu hình tay cầm")
            self.state_lbl.setStyleSheet("color: #f87171; font-size: 11px; font-weight: 600; border: none;")

    def _place_beside_player(self, dlg: QWidget) -> None:
        """Open the dialog next to the player: the emulator's GPU window is a separate window over the player
        area, so a dialog on top of it would be covered as soon as the game is clicked."""
        top = self.window()
        if top is None:
            return
        frame = top.frameGeometry()
        panel_right = self.mapToGlobal(QPoint(self.width(), 0)).x()
        x = panel_right + 16
        if x + dlg.width() > frame.right() - 8:
            x = max(frame.left() + 8, frame.right() - 8 - dlg.width())
        y = frame.top() + max(24, (frame.height() - dlg.height()) // 2)
        dlg.move(x, y)

    def set_booting_state(self, booting: bool, pct: int = 0, message: str = "", headline: str = "") -> None:
        if not booting:
            self._booting = False
            self._boot_headline = ""
            if not (self._current_runtime and self._current_runtime.running):
                self._embed_timer.stop()
            self._sync_controls()
            return
        if self._stream.is_streaming and self._current_runtime and self._current_runtime.running:
            return
        self._booting = True
        if headline:
            self._boot_headline = headline
        title = self._boot_headline or "Đang khởi động máy ảo Android..."
        clamped = max(1, min(99, int(pct) or 8))
        self.state_lbl.setText(f"Đang khởi động ({clamped}%)...")
        self.state_lbl.setStyleSheet("color: #fbbf24; font-size: 11px; font-weight: 600; border: none;")
        self.canvas.set_boot_progress(
            clamped,
            title,
            message or "Đang khởi tạo nhân Android & GPU tăng tốc phần cứng...",
        )
        self._arm_embed_poll()
        self._sync_controls()

    def _update_fps_badge(self, fps: int, streaming: bool) -> None:
        self._last_fps = fps
        if not streaming:
            self.fps_btn.setText("FPS")
            self.fps_btn.setStyleSheet(_fps_badge_style("#64748b", False))
            return
        if fps >= 45:
            col = "#4ade80"
        elif fps >= 25:
            col = "#fbbf24"
        elif fps > 0:
            col = "#f87171"
        else:
            col = "#94a3b8"
        self.fps_btn.setText(f"{fps} FPS")
        self.fps_btn.setStyleSheet(_fps_badge_style(col, True))

    def _on_perf_tick(self) -> None:
        if not self._stream.is_streaming:
            self._perf_timer.stop()
            self._update_fps_badge(0, streaming=False)
            return
        stats = self._stream.snapshot_stats()
        fps = int(stats.get("fps") or 0)
        self._update_fps_badge(fps, streaming=True)
        dec_ms = float(stats.get("decode_ms") or 0.0)
        mbps = float(stats.get("bitrate_mbps") or 0.0)
        w = int(stats.get("width") or 0)
        h = int(stats.get("height") or 0)
        self.fps_btn.setToolTip(
            f"Hiệu năng trực tiếp: {fps} FPS · Giải mã {dec_ms:.1f} ms · {mbps:.1f} Mbps · {w}x{h}"
        )

    def _can_hide_external_window(self, rt: RuntimeInfo | None) -> bool:
        if rt is None:
            return False
        return rt.kind not in (RUNTIME_EXTERNAL_ADB, RUNTIME_WAYDROID)

    def _show_runtime_external_window(self) -> None:
        rt = self._current_runtime
        avd = (rt.avd_name if rt else "") or DEFAULT_AVD_NAME
        serial = (rt.adb_serial if rt else "") or ""
        self._win_ctrl.show_external_windows(avd, serial)

    def _arm_dock_window_hider(self) -> None:
        rt = self._current_runtime
        if self._native.has_window or self._embed_timer.isActive():
            self._hide_poll_timer.stop()
            return
        if self._popped_out or not self._can_hide_external_window(rt) or rt is None:
            self._hide_poll_timer.stop()
            return
        self._win_ctrl.hide_external_windows(rt.avd_name or DEFAULT_AVD_NAME, rt.adb_serial)
        self._hide_polls_left = 8
        self._hide_poll_timer.start()

    @safe_slot
    def _on_dock_window_poll(self) -> None:
        rt = self._current_runtime
        if self._popped_out or rt is None or not rt.running or self._hide_polls_left <= 0:
            self._hide_poll_timer.stop()
            return
        self._hide_polls_left -= 1
        if self._win_ctrl.hide_external_windows(rt.avd_name or DEFAULT_AVD_NAME, rt.adb_serial) > 0:
            self._hide_poll_timer.stop()

    def attach_runtime(self, runtime: RuntimeInfo | None) -> None:
        """Bind to a booted Android runtime and either stream in-app or show popped-out state."""
        self._current_runtime = runtime
        self._gamepad.set_runtime(runtime)
        if runtime is None or not runtime.running:
            self._hide_poll_timer.stop()
            self._perf_timer.stop()
            self._stream.stop_stream()
            self._monitor.stop()
            self._update_fps_badge(0, streaming=False)
            if not self._booting:
                self._leave_native()
                self.canvas.clear_frame(
                    "Máy ảo Android chưa khởi động",
                    "Bấm Khởi động hoặc mở một game Android bất kỳ để chơi ngay trong ứng dụng.",
                )
            self._sync_controls()
            return

        self._booting = False
        self._boot_headline = ""

        if self._popped_out:
            self._hide_poll_timer.stop()
            self._perf_timer.stop()
            self._stream.stop_stream()
            self._update_fps_badge(0, streaming=False)
            self._show_runtime_external_window()
            self.canvas.clear_frame(
                "Đang chạy ở cửa sổ tách rời",
                "Bấm 'Gắn vào ứng dụng' ở thanh trên để đưa màn hình Android quay lại Bob Gaming.",
            )
            self._sync_controls()
            return

        if self._native_wanted(runtime):
            if self._try_embed():
                self._embed_timer.stop()
                self._hide_poll_timer.stop()
                self._perf_timer.stop()
                self._stream.stop_stream()
                self.state_lbl.setText("Trực tiếp GPU")
                self.state_lbl.setStyleSheet("color: #4ade80; font-size: 11px; font-weight: 600; border: none;")
                if not self._monitor.is_running:
                    logger.info(
                        f"{TAG} Showing {runtime.label} ({runtime.adb_serial}) through its embedded GPU window"
                    )
                    self._monitor.start(runtime)
                self._native_fallback_logged = False
                self._sync_controls()
                return
            if not self._native_fallback_logged:
                self._native_fallback_logged = True
                logger.warning(
                    f"{TAG} {runtime.label} has no display window to embed (started hidden); "
                    "falling back to the scrcpy video stream"
                )

        self._arm_dock_window_hider()
        if not self._stream.is_streaming or self._stream.active_serial != runtime.adb_serial:
            self.state_lbl.setText("Đang kết nối hình ảnh...")
            self.canvas.set_placeholder(
                "Đang kết nối màn hình Android...",
                "Luồng hình ảnh tốc độ cao đang khởi tạo trực tiếp vào Bob Gaming.",
            )
            logger.info(f"{TAG} Attaching in-app Android player to {runtime.label} ({runtime.adb_serial})")
            self._stream.start_stream(runtime)
        if not self._perf_timer.isActive():
            self._perf_timer.start()
        self._sync_controls()

    def notify_runtime_stopped(self) -> None:
        self._gamepad.set_runtime(None)
        self._booting = False
        self._boot_headline = ""
        self._hide_poll_timer.stop()
        self._perf_timer.stop()
        self._exit_fullscreen()
        self._stream.stop_stream()
        self._monitor.stop()
        self._leave_native()
        self._native.forget()
        self._win_ctrl.clear_tracked_windows()
        self._update_fps_badge(0, streaming=False)
        if self._current_runtime is not None:
            self._current_runtime.running = False
        self.canvas.clear_frame(
            "Đã tắt máy ảo Android",
            "Bấm Khởi động máy ảo Android hoặc mở game để chạy lại bất cứ lúc nào.",
        )
        self._sync_controls()

    @safe_slot
    def toggle_pop_out(self) -> None:
        self._popped_out = not self._popped_out
        if self._popped_out:
            self._exit_fullscreen()
            self._hide_poll_timer.stop()
            self._perf_timer.stop()
            self._stream.stop_stream()
            self._update_fps_badge(0, streaming=False)
            if self._native.has_window:
                self._leave_native(show_window=True)
            else:
                self._show_runtime_external_window()
            logger.info(f"{TAG} User popped out Android Emulator window")
            self.canvas.clear_frame(
                "Đang chạy ở cửa sổ tách rời",
                "Game vẫn tiếp tục chạy mượt — bấm 'Gắn vào ứng dụng' để nhúng lại vào chia đôi màn hình.",
            )
        else:
            logger.info(f"{TAG} User docked Android Emulator back into Bob Gaming")
            if self._current_runtime is not None and self._current_runtime.running:
                self.attach_runtime(self._current_runtime)
        self._sync_controls()

    @safe_slot
    def toggle_fullscreen(self) -> None:
        if self._fullscreen_win is not None:
            self._exit_fullscreen()
            return
        if self._popped_out or self._current_runtime is None or not self._current_runtime.running:
            return
        native = self._native.is_embedded
        win = _FullscreenHostWindow(with_exit_bar=native)
        win.closed.connect(self._exit_fullscreen)
        win.exit_clicked.connect(self._exit_fullscreen)
        self._fullscreen_native = native
        if native:
            # Moving `native_host` to another top-level recreates its HWND, which would destroy an embedded
            # child window with it: detach the emulator first and embed it again once the host is back up.
            self._geom_timer.stop()
            self._native.release(show=False)
            self.canvas_host_layout.removeWidget(self.native_host)
            win.body_layout.addWidget(self.native_host, 1)
        else:
            self.canvas_host_layout.removeWidget(self.canvas)
            win.body_layout.addWidget(self.canvas)
        self._fullscreen_win = win
        self._sync_gamepad_presence()
        win.showFullScreen()
        if native:
            self.native_host.show()
            self._try_embed()
        else:
            self.canvas.setFocus()
        logger.info(f"{TAG} Entered fullscreen Android view (native={native})")

    @safe_slot
    def _exit_fullscreen(self) -> None:
        win = self._fullscreen_win
        if win is None:
            return
        self._fullscreen_win = None
        self._sync_gamepad_presence()
        if self._fullscreen_native:
            self._fullscreen_native = False
            was_embedded = self._native.is_embedded
            self._geom_timer.stop()
            if self._native.has_window:
                self._native.release(show=False)
            win.body_layout.removeWidget(self.native_host)
            self.canvas_host_layout.addWidget(self.native_host, 1)
            if was_embedded and self._native_wanted():
                self.native_host.show()
                self._try_embed()
            else:
                self.native_host.hide()
                self.canvas.show()
        else:
            win.body_layout.removeWidget(self.canvas)
            self.canvas_host_layout.addWidget(self.canvas, 1)
            self.canvas.show()
        try:
            win.close()
            win.deleteLater()
        except RuntimeError:
            pass
        logger.info(f"{TAG} Exited fullscreen Android view")

    @safe_slot
    def _on_canvas_escape(self) -> None:
        if self._fullscreen_win is not None:
            self._exit_fullscreen()
        else:
            self._stream.send_keycode(KEYCODE_BACK)

    @safe_slot
    def _on_rotate_clicked(self) -> None:
        if self._native.is_embedded:
            self._monitor.rotate_device()
        else:
            self._stream.rotate_device()

    @safe_slot
    def _on_power_clicked(self) -> None:
        logger.info(f"{TAG} User clicked Stop Android Runtime from player toolbar")
        self.stop_runtime_requested.emit()

    @safe_slot
    def _on_quick_boot_clicked(self) -> None:
        if self._popped_out and self._current_runtime is not None and self._current_runtime.running:
            self.toggle_pop_out()
            return
        self.boot_runtime_requested.emit()

    @safe_slot
    def _on_frame_ready(self, _img_obj) -> None:
        img = self._stream.take_latest_frame()
        if isinstance(img, QImage) and not img.isNull():
            self.canvas.set_frame(img)

    @safe_slot
    def _on_stream_started(self, w: int, h: int) -> None:
        self.state_lbl.setText(f"Trực tiếp · {w}x{h}")
        self.state_lbl.setStyleSheet("color: #4ade80; font-size: 11px; font-weight: 600; border: none;")
        self._arm_dock_window_hider()
        if not self._perf_timer.isActive():
            self._perf_timer.start()
        self._on_perf_tick()
        self._sync_controls()

    @safe_slot
    def _on_stream_stopped(self, _reason: str) -> None:
        self._perf_timer.stop()
        self._update_fps_badge(0, streaming=False)
        if not self._popped_out:
            self.state_lbl.setText("Đã ngắt luồng hình ảnh")
            self.state_lbl.setStyleSheet("color: #94a3b8; font-size: 11px; border: none;")
            self.canvas.clear_frame(
                "Màn hình Android đang tạm nghỉ",
                "Bấm Khởi động hoặc mở game để kết nối lại màn hình.",
            )
            if self._current_runtime is not None:
                self._current_runtime.running = False
                self._gamepad.set_runtime(None)  # the runtime is gone: stop retrying its control channel
        self._sync_controls()

    @safe_slot
    def _on_stream_error(self, message: str) -> None:
        self._perf_timer.stop()
        self._update_fps_badge(0, streaming=False)
        self.state_lbl.setText("Cửa sổ rời dự phòng")
        self.state_lbl.setStyleSheet("color: #fbbf24; font-size: 11px; border: none;")
        self._show_runtime_external_window()
        self.canvas.clear_frame("Đã chuyển sang cửa sổ máy ảo rời", message)
        self._sync_controls()

    def _sync_controls(self) -> None:
        running = bool(self._current_runtime and self._current_runtime.running)
        in_app_active = running and not self._popped_out
        tier = int(self._compact_toolbar)
        compact = tier >= 1
        ultra = tier >= 2

        if self._popped_out:
            self.popout_btn.setText("" if ultra else ("Gắn lại" if compact else "Gắn vào ứng dụng"))
            self.popout_btn.setToolTip("Gắn màn hình Android trở lại trong Bob Gaming")
            self.popout_btn.setIcon(make_svg_icon("dock_in", size=14, color="#38bdf8"))
            if running:
                self.state_lbl.setText("Đang tách cửa sổ rời")
                self.state_lbl.setStyleSheet("color: #38bdf8; font-size: 11px; font-weight: 600; border: none;")
        else:
            self.popout_btn.setText("" if ultra else ("Tách rời" if compact else "Tách cửa sổ"))
            self.popout_btn.setToolTip("Tách màn hình Android ra cửa sổ riêng (hoặc gắn lại vào ứng dụng)")
            self.popout_btn.setIcon(make_svg_icon("pop_out", size=14, color="#cbd5e1"))
            if not running and not self._booting:
                self.state_lbl.setText("Chưa khởi động")
                self.state_lbl.setStyleSheet("color: #64748b; font-size: 11px; border: none;")

        self.gamepad_btn.setText("" if compact else "Tay cầm")
        self.rotate_btn.setText("" if compact else "Xoay")
        self.fullscreen_btn.setText("" if compact else "Toàn màn hình")
        self.power_btn.setText("" if compact else "Tắt")

        self.back_nav_btn.setText("" if ultra else "Quay lại")
        self.home_nav_btn.setText("" if ultra else "Trang chủ")
        self.recents_nav_btn.setText("" if ultra else "Đa nhiệm")

        self.fps_btn.setEnabled(in_app_active)
        self.popout_btn.setEnabled(running or self._popped_out)
        self.rotate_btn.setEnabled(in_app_active)
        self.fullscreen_btn.setEnabled(in_app_active)
        self.power_btn.setEnabled(running)
        for btn in (
            self.back_nav_btn,
            self.home_nav_btn,
            self.recents_nav_btn,
            self.voldown_nav_btn,
            self.volup_nav_btn,
        ):
            btn.setEnabled(in_app_active)

        if self._booting and not running:
            self.quick_row_widget.hide()
        elif not running:
            self.quick_boot_btn.setText("Khởi động máy ảo Android")
            self.quick_boot_btn.setIcon(make_svg_icon("play", size=14, color="#042612"))
            self.quick_row_widget.show()
        elif self._popped_out:
            self.quick_boot_btn.setText("Gắn lại vào ứng dụng")
            self.quick_boot_btn.setIcon(make_svg_icon("dock_in", size=14, color="#042612"))
            self.quick_row_widget.show()
        else:
            self.quick_row_widget.hide()
        self._sync_gamepad_presence()

    def hideEvent(self, event) -> None:
        super().hideEvent(event)
        self._sync_gamepad_presence()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._sync_gamepad_presence()
        latest = self._stream.take_latest_frame()
        if latest is not None and not latest.isNull():
            self.canvas.set_frame(latest)
        if self._native.is_embedded:
            self._on_geometry_tick()
        elif not self._popped_out and self._current_runtime is not None and self._current_runtime.running:
            self._arm_dock_window_hider()

    def shutdown(self) -> None:
        """Stop client stream cleanly on app exit without unhiding dying QEMU windows."""
        if self._gamepad_monitor is not None:
            try:
                self._gamepad_monitor.set_pad_tap(None)
            except Exception:  # noqa: BLE001
                logger.exception(f"{TAG} Detaching the gamepad tap failed")
            self._gamepad_monitor = None
        self._gamepad.shutdown()
        self._hide_poll_timer.stop()
        self._perf_timer.stop()
        self._exit_fullscreen()
        self._stream.stop_stream()
        self._monitor.stop()
        # Detach before `native_host` is destroyed so its HWND never takes the emulator window down with it.
        self._leave_native()
        self._native.forget()
        self._win_ctrl.clear_tracked_windows()
