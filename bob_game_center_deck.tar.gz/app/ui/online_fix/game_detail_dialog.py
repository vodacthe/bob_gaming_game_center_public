"""
Game detail dialog: poster + update note, optional multi-store provider switcher, the game's download sources,
and install options. Torrent / Direct CDN sources are downloaded by Bob (aria2c); browser-only sources open in browser.
"""

import logging
import os
import webbrowser

from PySide6.QtCore import QSize, Qt, QTimer, Signal
from PySide6.QtWidgets import (

    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.core.online_fix.client import OnlineFixError
from app.core.online_fix.store_cache import (
    candidate_steam_urls_for_game,
    peek_cached_steam_store_url,
    resolve_steam_store_url,
)
from app.core.online_fix.manager import _ordered_variants, _sanitize_folder_name, get_online_fix_manager
from app.core.online_fix.models import (
    LINK_TORRENT,
    LINK_WEB,
    PROVIDER_PRIORITY,
    SOURCE_ANKERGAMES, SOURCE_FITGIRL,
    SOURCE_ONLINE_FIX,
    SOURCE_STEAMRIP,
    OnlineFixGame,
)
from app.ui.flow_layout import FlowLayout
from app.ui.game_card import DARK_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.online_fix.common import (
    CHECKBOX_STYLE,
    COMBO_STYLE,
    INPUT_STYLE,
    STATUS_COLORS,
    FitButton,
    PosterLoader,
    SourceBadge,
    Task,
    make_button,
    copy_to_clipboard,
    rounded_cover,
    safe_slot,
    source_display_name,
    source_theme,
)

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/Detail]"

POSTER_W, POSTER_H = 150, 200

_SHARE_COPIED_STYLE = (
    DARK_BTN_STYLE
    + "QPushButton { color: #34d399; border-color: rgba(52, 211, 153, 0.55); "
    "background-color: rgba(16, 185, 129, 0.14); }"
)


def _button(text: str, style: str, icon: str) -> QPushButton:
    return make_button(text, style, icon)


def _provider_button_label(source: str) -> str:
    if source == SOURCE_ONLINE_FIX:
        return "Online-Fix (Co-op)"
    if source == SOURCE_FITGIRL:
        return "FitGirl Repacks"
    if source == SOURCE_STEAMRIP:
        return "SteamRIP"
    if source == SOURCE_ANKERGAMES: return "AnkerGames"
    return source_display_name(source)


def _provider_tab_style(source: str, active: bool) -> str:
    bg, border, fg, _icon, _full, _short = source_theme(source)
    if active:
        return (
            f"QPushButton {{ background-color: {bg}; border: 1.5px solid {fg}; border-radius: 8px; "
            f"color: #ffffff; font-size: 12px; font-weight: 700; padding: 0 12px; min-height: 32px; }}"
            f"QPushButton:hover {{ border-color: {fg}; }}"
        )
    return (
        "QPushButton { background-color: rgba(18, 24, 38, 0.82); border: 1px solid rgba(255, 255, 255, 0.10); "
        "border-radius: 8px; color: #94a3b8; font-size: 12px; font-weight: 600; padding: 0 12px; min-height: 32px; }"
        f"QPushButton:hover {{ background-color: rgba(30, 41, 59, 0.92); border-color: {border}; color: #e2e8f0; }}"
    )


class GameDetailDialog(QDialog):
    download_requested = Signal(dict)
    install_root_changed = Signal(str)   # user picked / typed another install folder: the screen saves it

    def __init__(
        self,
        game: OnlineFixGame,
        client,
        default_install_dir: str,
        posters: PosterLoader,
        parent=None,
        *,
        providers: list[OnlineFixGame] | None = None,
        clients_by_source: dict[str, object] | None = None,
        initial_source: str | None = None,
    ):
        super().__init__(parent)
        self.posters = posters
        self.default_install_dir = default_install_dir
        self._last_root = os.path.normcase(os.path.normpath(default_install_dir))

        raw_providers = (
            list(providers)
            if providers
            else (list(game.providers) if getattr(game, "providers", None) else [game])
        )
        by_src: dict[str, OnlineFixGame] = {}
        for item in raw_providers:
            src = item.source or SOURCE_ONLINE_FIX
            if src not in by_src:
                by_src[src] = item
        g_src = game.source or SOURCE_ONLINE_FIX
        by_src.setdefault(g_src, game)

        ordered: list[OnlineFixGame] = _ordered_variants(by_src)
        if SOURCE_ONLINE_FIX in by_src and ordered and (ordered[0].source or SOURCE_ONLINE_FIX) != SOURCE_ONLINE_FIX:
            ordered = [by_src[SOURCE_ONLINE_FIX]] + [
                p for p in ordered if (p.source or SOURCE_ONLINE_FIX) != SOURCE_ONLINE_FIX
            ]
        for s, item in by_src.items():
            if False and s not in PROVIDER_PRIORITY:
                ordered.append(item)

        self.providers: list[OnlineFixGame] = ordered
        self._provider_map: dict[str, OnlineFixGame] = {p.source or SOURCE_ONLINE_FIX: p for p in ordered}
        self._clients_by_source: dict[str, object] = dict(clients_by_source or {})
        if client is not None:
            self._clients_by_source.setdefault(g_src, client)

        if initial_source and initial_source in self._provider_map:
            start_src = initial_source
        elif SOURCE_ONLINE_FIX in self._provider_map:
            start_src = SOURCE_ONLINE_FIX
        elif g_src in self._provider_map:
            start_src = g_src
        else:
            start_src = ordered[0].source or SOURCE_ONLINE_FIX

        self.game: OnlineFixGame = self._provider_map[start_src]
        self.client = self._resolve_client(start_src)
        self._details: OnlineFixGame | None = None
        self._details_by_source: dict[str, OnlineFixGame] = {}
        self._detail_req_id = 0
        self._has_poster = False
        self._task: Task | None = None
        self._web_task: Task | None = None
        self._share_task: Task | None = None
        self._share_reset_timer = QTimer(self)
        self._share_reset_timer.setSingleShot(True)
        self._share_reset_timer.timeout.connect(self._reset_share_btn)
        self._pending_web_url: str = ""
        self._logged_hv_sources: set[str] = set()
        self.provider_buttons: dict[str, QPushButton] = {}

        self.setWindowTitle(self.game.title)
        self.setFixedWidth(680)
        self.setStyleSheet("""
            QDialog { background-color: #0b0e14; }
            QLabel { background: transparent; color: #cbd5e1; }
            QLabel#ofSection { color: #8b949e; font-size: 11px; font-weight: 700; }
            QFrame#ofSep { background-color: rgba(255, 255, 255, 0.06); max-height: 1px; border: none; }
        """)
        self._setup_ui()
        posters.loaded.connect(self._on_poster_loaded)
        self._refresh_poster_for_current_game()
        self._load_details()

    def _resolve_client(self, source: str):
        cli = self._clients_by_source.get(source)
        if cli is not None:
            return cli
        mgr = get_online_fix_manager()
        if source == SOURCE_FITGIRL:
            cli = mgr.fitgirl_client
        elif source == SOURCE_ANKERGAMES: cli = mgr.ankergames_client
        elif source == SOURCE_STEAMRIP:
            cli = mgr.steamrip_client
        else:
            cli = mgr.client
        self._clients_by_source[source] = cli
        return cli

    # ------------------------------------------------------------ layout

    def _setup_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 22, 24, 20)
        lay.setSpacing(14)

        # Optional multi-store provider switcher bar (visible only when >= 2 stores have this game)
        self.provider_bar_box = QWidget()
        prov_outer = QVBoxLayout(self.provider_bar_box)
        prov_outer.setContentsMargins(0, 0, 0, 2)
        prov_outer.setSpacing(6)
        prov_hdr = self._section(f"CHỌN KHO TẢI GAME ({len(self.providers)} NGUỒN KHẢ DỤNG)")
        prov_outer.addWidget(prov_hdr)
        prov_row = QHBoxLayout()
        prov_row.setContentsMargins(0, 0, 0, 0)
        prov_row.setSpacing(8)
        for p_game in self.providers:
            src = p_game.source or SOURCE_ONLINE_FIX
            _bg, _border, fg, icon_name, _full, _short = source_theme(src)
            tab_lbl = _provider_button_label(src) + (" · HV" if p_game.is_hypervisor else "")
            btn = FitButton(tab_lbl, font_px=12, height=32)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setIcon(make_svg_icon(icon_name, size=14, normal_color=fg))
            btn.setIconSize(QSize(14, 14))
            btn.clicked.connect(lambda _=False, s=src: self.select_provider(s))
            prov_row.addWidget(btn)
            self.provider_buttons[src] = btn
        prov_row.addStretch()
        prov_outer.addLayout(prov_row)
        prov_sep = QFrame()
        prov_sep.setObjectName("ofSep")
        prov_sep.setFrameShape(QFrame.Shape.HLine)
        prov_outer.addWidget(prov_sep)
        self.provider_bar_box.setVisible(len(self.providers) > 1)
        lay.addWidget(self.provider_bar_box)

        self.top_box = QWidget()
        self.top_box.setMinimumHeight(POSTER_H)
        top = QHBoxLayout(self.top_box)
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(18)
        self.poster_label = QLabel()
        self.poster_label.setFixedSize(POSTER_W, POSTER_H)
        self.poster_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.poster_label.setStyleSheet("background-color: #111827; border-radius: 10px;")
        self.poster_label.setPixmap(make_svg_pixmap("image", size=32, color="#334155"))
        self.poster_hv_badge = QLabel("HV", self.poster_label)
        self.poster_hv_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.poster_hv_badge.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.poster_hv_badge.setFixedSize(30, 24)
        self.poster_hv_badge.setStyleSheet(
            "background-color: #ee0000; color: #ffffff; border: none; font-size: 11px; font-weight: 800; "
            "letter-spacing: 0.4px; border-top-left-radius: 3px; border-top-right-radius: 10px; "
            "border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;"
        )
        self.poster_hv_badge.move(POSTER_W - 30, POSTER_H - 24)
        self.poster_hv_badge.hide()
        poster_col = QVBoxLayout()
        poster_col.setContentsMargins(0, 0, 0, 0)
        poster_col.setSpacing(0)
        poster_col.addWidget(self.poster_label)
        poster_col.addStretch(1)
        top.addLayout(poster_col)

        info = QVBoxLayout()
        info.setSpacing(6)

        badge_row = QHBoxLayout()
        badge_row.setContentsMargins(0, 0, 0, 0)
        badge_row.setSpacing(8)
        self.source_badge = SourceBadge(self.game.source)
        badge_row.addWidget(self.source_badge)
        self.hv_pill = QLabel("HV · HYPERVISOR")
        self.hv_pill.setStyleSheet(
            "background-color: #ee0000; color: #ffffff; border: 1px solid #f87171; "
            "border-radius: 6px; padding: 2px 8px; font-size: 10px; font-weight: 800; letter-spacing: 0.4px;"
        )
        self.hv_pill.hide()
        badge_row.addWidget(self.hv_pill)
        self.date_label = QLabel("")
        self.date_label.setStyleSheet("color: #8b949e; font-size: 12px;")
        badge_row.addWidget(self.date_label)
        badge_row.addStretch()
        info.addLayout(badge_row)

        self.title_label = QLabel(self.game.title)
        self.title_label.setWordWrap(True)
        self.title_label.setStyleSheet("color: #ffffff; font-size: 18px; font-weight: 700;")
        info.addWidget(self.title_label)

        self.hv_notice_label = QLabel(
            "Bản Hypervisor (HV): dùng cơ chế Hypervisor Bypass cho game Denuvo — "
            "cần bật/cấu hình Hypervisor theo hướng dẫn đi kèm bộ cài."
        )
        self.hv_notice_label.setWordWrap(True)
        self.hv_notice_label.setStyleSheet(
            "background-color: rgba(127, 29, 29, 0.36); color: #fecaca; "
            "border: 1px solid rgba(248, 113, 113, 0.45); border-radius: 8px; "
            "padding: 6px 10px; font-size: 11px; font-weight: 600;"
        )
        self.hv_notice_label.hide()
        info.addWidget(self.hv_notice_label)

        self.update_label = QLabel("")
        self.update_label.setWordWrap(True)
        info.addWidget(self.update_label)
        self.modes_label = QLabel("")
        self.modes_label.setWordWrap(True)
        self.modes_label.setStyleSheet("color: #94a3b8; font-size: 12px;")
        self.modes_label.hide()
        info.addWidget(self.modes_label)
        info.addStretch()
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        info.addWidget(self.status_label)
        self.page_btn = _button("Mở trang game", DARK_BTN_STYLE, "globe")
        self.page_btn.clicked.connect(lambda: self._open_url(self.game.url))
        action_row = QHBoxLayout()
        action_row.setContentsMargins(0, 0, 0, 0)
        action_row.setSpacing(8)
        action_row.addWidget(self.page_btn)
        self.share_btn = _button("Chia sẻ", DARK_BTN_STYLE, "share")
        self.share_btn.setToolTip("Sao chép liên kết Steam của trò chơi để gửi cho bạn bè")
        self.share_btn.clicked.connect(self._on_share_clicked)
        action_row.addWidget(self.share_btn)
        action_row.addStretch()
        info.addLayout(action_row)
        top.addLayout(info, 1)
        lay.addWidget(self.top_box)

        sep = QFrame()
        sep.setObjectName("ofSep")
        sep.setFrameShape(QFrame.Shape.HLine)
        lay.addWidget(sep)

        lay.addWidget(self._section("NGUỒN TẢI TRỰC TIẾP (BOB TỰ TẢI & CÀI ĐẶT)"))
        self.source_combo = QComboBox()
        self.source_combo.setFixedHeight(36)
        self.source_combo.setStyleSheet(COMBO_STYLE)
        self.source_combo.setEnabled(False)
        lay.addWidget(self.source_combo)

        self.web_section = self._section("NGUỒN KHÁC (MỞ TRÊN TRÌNH DUYỆT)")
        self.web_section.hide()
        lay.addWidget(self.web_section)
        self.web_box = QWidget()                      # wraps onto several lines instead of overflowing
        self.web_row = FlowLayout(self.web_box, margin=0, spacing=8)
        self.web_box.hide()
        lay.addWidget(self.web_box)

        lay.addWidget(self._section("THƯ MỤC CÀI ĐẶT"))
        dir_row = QHBoxLayout()
        dir_row.setSpacing(8)
        self.dir_input = QLineEdit(self.default_install_dir)
        self.dir_input.setFixedHeight(36)
        self.dir_input.setStyleSheet(INPUT_STYLE)
        dir_row.addWidget(self.dir_input, 1)
        browse_btn = _button("Chọn…", DARK_BTN_STYLE, "folder")
        browse_btn.clicked.connect(self._on_browse_dir)
        dir_row.addWidget(browse_btn)
        lay.addLayout(dir_row)
        self.target_hint = QLabel("")
        self.target_hint.setWordWrap(True)
        self.target_hint.setStyleSheet("color: #64748b; font-size: 11px;")
        lay.addWidget(self.target_hint)
        self.dir_input.textChanged.connect(self._update_target_hint)
        self.dir_input.editingFinished.connect(self._on_dir_edited)

        self.auto_extract_cb = QCheckBox("")
        self.auto_extract_cb.setChecked(True)
        self.auto_extract_cb.setStyleSheet(CHECKBOX_STYLE)
        lay.addWidget(self.auto_extract_cb)
        self.delete_archive_cb = QCheckBox("")
        self.delete_archive_cb.setChecked(True)
        self.delete_archive_cb.setStyleSheet(CHECKBOX_STYLE)
        lay.addWidget(self.delete_archive_cb)
        self.auto_extract_cb.toggled.connect(self.delete_archive_cb.setEnabled)

        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        buttons.addStretch()
        cancel_btn = _button("Đóng", DARK_BTN_STYLE, "close")
        cancel_btn.clicked.connect(self.reject)
        buttons.addWidget(cancel_btn)
        self.download_btn = _button("Bắt đầu tải", PURPLE_BTN_STYLE, "download")
        self.download_btn.setEnabled(False)
        self.download_btn.clicked.connect(self._on_start_download)
        buttons.addWidget(self.download_btn)
        lay.addLayout(buttons)

        self._reset_share_btn()
        self._sync_header_and_options_for_source()
        self._sync_dialog_height()

    @staticmethod
    def _section(text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("ofSection")
        return label

    def _sync_header_and_options_for_source(self):
        active_src = self.game.source or SOURCE_ONLINE_FIX
        is_fitgirl = (active_src == SOURCE_FITGIRL)
        is_steamrip = (active_src == SOURCE_STEAMRIP)

        for src, btn in self.provider_buttons.items():
            is_act = (src == active_src)
            _bg, _border, fg, icon_name, _full, _short = source_theme(src)
            btn.setStyleSheet(_provider_tab_style(src, active=is_act))
            btn.setIcon(make_svg_icon(icon_name, size=14, normal_color=fg if is_act else "#94a3b8"))

        self.setWindowTitle(self.game.title)
        self.source_badge.set_source(active_src, compact=False)
        if self.game.date:
            self.date_label.setText(f"Cập nhật: {self.game.date}")
            self.date_label.show()
        else:
            self.date_label.clear()
            self.date_label.hide()

        self.title_label.setText(self.game.title)
        upd_color = "#34d399" if (is_fitgirl or active_src == SOURCE_ANKERGAMES) else ("#fbbf24" if is_steamrip else "#38bdf8")
        self.update_label.setStyleSheet(f"color: {upd_color}; font-size: 12px;")
        self.update_label.setText(self.game.update_info or "")
        self.update_label.setVisible(bool(self.game.update_info))
        self.modes_label.clear()
        self.modes_label.hide()
        self._sync_hv_state()

        self.auto_extract_cb.setText(
            "Tự động cài đặt ngầm (Silent Install) sau khi tải xong"
            if is_fitgirl else "Tự giải nén sau khi tải xong"
        )
        self.delete_archive_cb.setText(
            "Xóa bộ cài tạm (setup.exe / .bin) sau khi cài đặt thành công"
            if is_fitgirl else "Xóa file nén đã tải sau khi giải nén thành công"
        )
        self._update_target_hint()

    def _sync_hv_state(self):
        is_hv = bool(self.game.is_hypervisor or (self._details is not None and self._details.is_hypervisor))
        src_key = self.game.source or SOURCE_ONLINE_FIX
        if is_hv and not self.game.is_hypervisor:
            self.game.is_hypervisor = True
            btn = self.provider_buttons.get(src_key)
            if btn is not None:
                btn.setText(_provider_button_label(src_key) + " · HV")
        if is_hv and src_key not in self._logged_hv_sources:
            self._logged_hv_sources.add(src_key)
            logger.info(f"{TAG} Displaying Hypervisor (HV) badge/notice for {self.game.title!r} (source={src_key})")
        self.poster_hv_badge.setVisible(is_hv)
        if is_hv:
            self.poster_hv_badge.raise_()
        self.hv_pill.setVisible(is_hv)
        self.hv_notice_label.setVisible(is_hv)

    def _sync_dialog_height(self):
        lay = self.layout()
        if lay is None:
            return
        w = self.width() or 680
        if not self.web_box.isHidden() and self.web_row.count() > 0:
            web_w = max(200, w - 48)
            self.web_box.setFixedHeight(max(32, self.web_row.heightForWidth(web_w)))
        lay.activate()
        target_h = lay.heightForWidth(w) if lay.hasHeightForWidth() else lay.sizeHint().height()
        min_h = max(lay.minimumSize().height(), lay.minimumHeightForWidth(w) if lay.hasHeightForWidth() else 0)
        target_h = max(target_h, min_h)
        self.setFixedSize(w, target_h)
        self.resize(w, target_h)
        lay.setGeometry(self.rect())

    def _clear_web_buttons(self):
        while self.web_row.count():
            item = self.web_row.takeAt(0)
            w = item.widget() if item else None
            if w is not None:
                w.hide()
                w.deleteLater()
        self.web_box.setMinimumHeight(0)
        self.web_box.setMaximumHeight(16777215)
        self.web_section.hide()
        self.web_box.hide()

    def _candidate_poster_urls(self) -> list[str]:
        urls: list[str] = []
        for u in (self.game.poster_url, self.game.provider_poster_url):
            if u and u not in urls and not self.posters.has_failed(u):
                urls.append(u)
        for p in self.providers:
            for u in (p.poster_url, p.provider_poster_url):
                if u and u not in urls and not self.posters.has_failed(u):
                    urls.append(u)
        return urls

    def _refresh_poster_for_current_game(self):
        candidates = self._candidate_poster_urls()
        for url in candidates:
            cached = self.posters.cached(url)
            if cached is not None and self._set_poster(cached):
                return
        if candidates:
            self.posters.request(candidates[0])

    @safe_slot
    def select_provider(self, source: str):
        target = self._provider_map.get(source)
        if target is None:
            return
        cur_src = self.game.source or SOURCE_ONLINE_FIX
        if source == cur_src and (self._details is not None or (self._task is not None and self._task.isRunning())):
            return

        logger.info(f"{TAG} User switched store provider to {source!r} for {target.title!r} ({target.url})")
        self.game = target
        self.client = self._resolve_client(source)
        self._details = None
        self.source_combo.clear()
        self.source_combo.setEnabled(False)
        self.download_btn.setEnabled(False)
        self._clear_web_buttons()

        self._reset_share_btn()
        self._sync_header_and_options_for_source()
        self._refresh_poster_for_current_game()

        cached_details = self._details_by_source.get(source)
        if cached_details is not None:
            self._detail_req_id += 1
            self._apply_details(cached_details)
            return
        self._load_details()
        self._sync_dialog_height()

    def _set_status(self, text: str, kind: str):
        self.status_label.setText(text)
        self.status_label.setStyleSheet(f"color: {STATUS_COLORS[kind]}; font-size: 12px;")

    def _set_poster(self, data: bytes) -> bool:
        pix = rounded_cover(data, POSTER_W, POSTER_H, 10)
        if pix is not None:
            self.poster_label.setPixmap(pix)
            self._has_poster = True
            return True
        return False

    @safe_slot
    def _on_poster_loaded(self, url: str, data: bytes):
        detail_url = getattr(self._details, "poster_url", "")
        known_urls = set(self._candidate_poster_urls())
        if detail_url:
            known_urls.add(detail_url)
        if url in known_urls:
            if not self._set_poster(data):
                for fb in self._candidate_poster_urls():
                    if fb != url:
                        cached = self.posters.cached(fb)
                        if cached is not None and self._set_poster(cached):
                            break
                        self.posters.request(fb)
                        break

    @safe_slot
    def _update_target_hint(self):
        root = self.dir_input.text().strip() or self.default_install_dir
        verb = "cài đặt" if self.game.source == SOURCE_FITGIRL else "giải nén"
        self.target_hint.setText(f"Game sẽ được {verb} vào: {os.path.join(root, _sanitize_folder_name(self.game.title))}")

    # ------------------------------------------------------------ details

    def _load_details(self):
        self._detail_req_id += 1
        req_id = self._detail_req_id
        fetched_source = self.game.source or SOURCE_ONLINE_FIX
        src_label = source_display_name(fetched_source)
        self._set_status(f"Đang lấy các nguồn tải từ {src_label}…", "busy")
        client, url = self.client, self.game.url
        self._task = Task(
            lambda: client.get_game_details(url),
            f"details-{fetched_source}-{self.game.id}",
            expected_errors=(OnlineFixError,),
        )
        self._task.done.connect(
            lambda details, err, r=req_id, s=fetched_source: self._on_details_loaded(r, s, details, err)
        )
        self._task.start_tracked()

    @safe_slot
    def _on_details_loaded(self, req_id: int, fetched_source: str, details, error: str):
        if not error and details is not None:
            self._details_by_source[fetched_source] = details
        if req_id != self._detail_req_id or fetched_source != (self.game.source or SOURCE_ONLINE_FIX):
            return
        if error:
            self._set_status(error, "error")
            return
        self._apply_details(details)

    def _apply_details(self, details: OnlineFixGame):
        self._details = details
        self._sync_hv_state()
        if (
            details.poster_url
            and not self._has_poster
            and (not self.game.poster_url or self.posters.has_failed(self.game.poster_url))
        ):
            cached = self.posters.cached(details.poster_url)
            if cached is not None:
                self._set_poster(cached)
            elif not self.posters.has_failed(details.poster_url):
                self.posters.request(details.poster_url)
        if details.game_modes:
            self.modes_label.setText(details.game_modes[:300])
            self.modes_label.show()
        if details.update_info and not self.game.update_info:
            self.update_label.setText(details.update_info)
            self.update_label.show()

        torrents = [d for d in details.download_links if d["kind"] == LINK_TORRENT]
        webs = [d for d in details.download_links if d["kind"] == LINK_WEB]
        self.source_combo.clear()
        self._clear_web_buttons()

        icon_color = (
            "#34d399" if self.game.source in (SOURCE_FITGIRL, SOURCE_ANKERGAMES)
            else "#fbbf24" if self.game.source == SOURCE_STEAMRIP
            else "#38bdf8"
        )
        for d in torrents:
            self.source_combo.addItem(make_svg_icon("download", size=14, normal_color=icon_color), d["title"], d["url"])
        for d in webs[:8]:
            btn = _button(d["title"], DARK_BTN_STYLE, "globe")
            btn.setToolTip(d["url"])
            btn.clicked.connect(lambda _=False, u=d["url"]: self._open_url(u))
            self.web_row.addWidget(btn)
        self.web_section.setVisible(bool(webs))
        self.web_box.setVisible(bool(webs))

        if torrents:
            self.source_combo.setEnabled(True)
            self.download_btn.setEnabled(True)
            pwd = details.archive_password
            if self.game.source in (SOURCE_FITGIRL, SOURCE_ANKERGAMES) or not pwd:
                self._set_status(f"Có {len(torrents)} nguồn tải trực tiếp (Torrent / Direct CDN). Sẵn sàng tải.", "ok")
            elif self.game.source == SOURCE_STEAMRIP:
                self._set_status(
                    f"Có {len(torrents)} nguồn tải trực tiếp (Direct CDN / Torrent). Tự giải nén (mật khẩu: {pwd}).",
                    "ok",
                )
            else:
                self._set_status(f"Có {len(torrents)} nguồn torrent. Mật khẩu giải nén: {pwd}", "ok")
        elif webs:
            self.source_combo.addItem("Game này chỉ có liên kết tải trình duyệt")
            self._set_status("Chọn một máy chủ bên dưới để tải qua trình duyệt.", "warn")
        else:
            self.source_combo.addItem("Không tìm thấy nguồn tải")
            self._set_status("Không tìm thấy liên kết tải trên trang game.", "warn")
        self._sync_dialog_height()

    # ------------------------------------------------------------ actions

    @safe_slot
    def _open_url(self, url: str):
        low = (url or "").lower()
        if (
            self.game.source == SOURCE_STEAMRIP
            and ("bzzhr.to/" in low or "buzzheavier.com/" in low)
            and hasattr(self.client, "resolve_browser_download_url")
        ):
            if self._web_task is not None and self._web_task.isRunning():
                return
            logger.info(f"{TAG} Resolving Buzzheavier browser link for {url} (referer={self.game.url})")
            self._set_status("Đang lấy liên kết tải trực tiếp Buzzheavier (tránh bị chuyển hướng về SteamRIP)…", "busy")
            client, ref = self.client, self.game.url
            self._pending_web_url = url
            self._web_task = Task(
                lambda: client.resolve_browser_download_url(url, referer=ref),
                f"web-bzzhr-{self.game.id}",
            )
            self._web_task.done.connect(self._on_web_url_resolved)
            self._web_task.start_tracked()
            return
        logger.info(f"{TAG} User opened {url} in the browser")
        webbrowser.open(url)

    @safe_slot
    def _on_web_url_resolved(self, resolved_url, error: str):
        orig_url = self._pending_web_url
        target = str(resolved_url or "").strip() if not error else ""
        if not target:
            target = self.game.url or orig_url
        logger.info(f"{TAG} Opening resolved Buzzheavier browser target {target} (from {orig_url})")
        webbrowser.open(target)
        if "steamrip.com" in target.lower():
            self._set_status(
                "Đã mở trang bài viết SteamRIP — hãy bấm nút DOWNLOAD HERE của Buzzheavier ngay trên trang đó.",
                "warn",
            )
        else:
            self._set_status("Đã mở liên kết tải tệp Buzzheavier trực tiếp trên trình duyệt.", "ok")

    def _collect_share_candidate_urls(self) -> tuple[str, ...]:
        urls: list[str] = list(candidate_steam_urls_for_game(self.game))
        if self._details and self._details.poster_url and self._details.poster_url not in urls:
            urls.append(self._details.poster_url)
        for p in self.providers:
            for u in candidate_steam_urls_for_game(p):
                if u not in urls:
                    urls.append(u)
        return tuple(urls)

    @safe_slot
    def _on_share_clicked(self):
        if self._share_task is not None and self._share_task.isRunning():
            return
        title = self.game.title
        cands = self._collect_share_candidate_urls()
        logger.info(f"{TAG} User clicked Share for {title!r} (source={self.game.source})")
        cached_url = peek_cached_steam_store_url(title, *cands)
        if cached_url:
            self._apply_shared_url(title, cached_url, cached=True)
            return
        self._share_reset_timer.stop()
        self.share_btn.setEnabled(False)
        self.share_btn.setText("Đang lấy link…")
        self._share_task = Task(
            lambda: resolve_steam_store_url(title, *cands),
            f"share-steam-{self.game.id}",
        )
        self._share_task.done.connect(lambda url, err, t=title: self._on_share_resolved(t, url, err))
        self._share_task.start_tracked()

    @safe_slot
    def _on_share_resolved(self, title: str, url, error: str):
        self.share_btn.setEnabled(True)
        if error or not url:
    
            self._reset_share_btn()
            self._set_status(error or "Không lấy được liên kết Steam.", "error")
            return
        self._apply_shared_url(title, str(url), cached=False)

    def _apply_shared_url(self, title: str, url: str, *, cached: bool):
        copy_to_clipboard(url)
        logger.info(f"{TAG} Copied Steam link for {title!r} to clipboard: {url} (cached={cached})")
        self.share_btn.setEnabled(True)
        self.share_btn.setText("Đã sao chép")
        self.share_btn.setStyleSheet(_SHARE_COPIED_STYLE)
        self.share_btn.setIcon(make_svg_icon("check", size=14, normal_color="#34d399"))
        self._share_reset_timer.start(2000)

    @safe_slot
    def _reset_share_btn(self):
        self._share_reset_timer.stop()
        if self._share_task is not None and self._share_task.isRunning():
            return
        self.share_btn.setEnabled(True)
        self.share_btn.setText("Chia sẻ")
        self.share_btn.setStyleSheet(DARK_BTN_STYLE)
        self.share_btn.setIcon(make_svg_icon("share", size=14, normal_color="#ffffff"))

    @safe_slot
    def _on_browse_dir(self):
        chosen = QFileDialog.getExistingDirectory(self, "Chọn thư mục cài đặt game", self.dir_input.text())
        if chosen:
            self.dir_input.setText(os.path.normpath(chosen))
            self._on_dir_edited()

    @safe_slot
    def _on_dir_edited(self):
        root = self.dir_input.text().strip()
        if root and os.path.isabs(root) and os.path.normcase(os.path.normpath(root)) != self._last_root:
            self._last_root = os.path.normcase(os.path.normpath(root))
            self.install_root_changed.emit(os.path.normpath(root))

    @safe_slot
    def _on_start_download(self):
        selected_url = self.source_combo.currentData()
        if not selected_url:
            return
        target_dir = self.dir_input.text().strip() or self.default_install_dir
        try:
            os.makedirs(target_dir, exist_ok=True)
        except OSError as e:
            logger.warning(f"{TAG} Install folder {target_dir} is not usable: {e}")
            self._set_status(f"Không tạo được thư mục cài đặt: {e}", "error")
            return

        details = self._details
        enriched_poster = (
            self.game.poster_url
            if self.game.poster_url and self.game.poster_url != self.game.provider_poster_url
            else ""
        )
        poster_url = enriched_poster or (details.poster_url if details and details.poster_url else self.game.poster_url)
        self.download_requested.emit({
            "game_title": self.game.title,
            "source_url": selected_url,
            "install_target_root": target_dir,
            "auto_extract": self.auto_extract_cb.isChecked(),
            "delete_archive": self.delete_archive_cb.isChecked(),
            "archive_password": details.archive_password if details else "",
            "referer": self.game.url,
            "poster_url": poster_url,
            "source": self.game.source,
        })
        self.accept()
