"""
OnlineFixScreen ("KHO GAME"): unified Game Store screen for Online-Fix.me, AnkerGames, FitGirl Repacks, and SteamRIP.
Organizes games into horizontal Category Shelves (powered by SteamGridDB 2:3 covers + Steam Store genres)
and a full Grid view with persistent disk caching in Documents\\Bob Gaming\\GameCenter\\cache.

All network and disk work runs off the UI thread (common.Task, PosterLoader, StoreMetadataEnricher);
results arrive strictly via queued Qt signals guarded by @safe_slot.
"""

from concurrent.futures import ThreadPoolExecutor
import logging
import os
import threading
import time

from PySide6.QtCore import QSize, Qt, QTimer, Signal
from PySide6.QtGui import QFontMetrics, QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMenu,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from app.core.online_fix.ankergames_client import (
    ANKERGAMES_CATEGORY_PATHS,
    ANKERGAMES_PAGE_SIZE,
    AnkerGamesClient,
)
from app.core.online_fix.client import SEARCH_PAGE_SIZE, OnlineFixError, _is_test_env
from app.core.online_fix.fitgirl_client import (
    FITGIRL_BATCH_SIZE,
    FITGIRL_CATEGORY_SEARCH_TERMS,
    FITGIRL_PAGE_SIZE,
    FitGirlClient,
)
from app.core.online_fix.manager import (
    attach_store_providers,
    find_installed_game_updates,
    get_online_fix_manager,
    interleave_games,
    is_game_update_available,
    resolve_game_providers,
)
from app.core.online_fix.models import (
    ALL_STORE_SOURCES,
    SOURCE_ANKERGAMES,
    SOURCE_FITGIRL,
    SOURCE_ONLINE_FIX,
    SOURCE_STEAMRIP,
    OnlineFixGame,
    matches_search_query,
    normalize_enabled_stores,
    sort_games_for_search,
)
from app.core.online_fix.steamrip_client import (
    STEAMRIP_BATCH_SIZE,
    STEAMRIP_CATEGORY_WP_IDS,
    STEAMRIP_PAGE_SIZE,
    SteamRipClient,
)
from app.core.online_fix.store_cache import (
    CATEGORY_LABELS,
    STORE_CATEGORIES,
    classify_game_categories,
    get_catalog_cache_path,
    get_store_metadata_enricher,
    load_catalog_cache,
    normalize_game_cache_key,
    save_catalog_source_cache,
    candidate_steam_urls_for_game,
    peek_cached_steam_store_url,
    resolve_steam_store_url,
)
from app.ui.flow_layout import FlowLayout
from app.ui.game_card import DARK_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.online_fix.common import (
    STATUS_COLORS,
    SourceBadge,
    SpinningLoader,
    Task,
    make_button,
    copy_to_clipboard,
    poster_loader,
    rounded_cover,
    safe_slot,
    source_display_name,
)
from app.ui.online_fix.download_drawer import DownloadDrawer
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader

logger = logging.getLogger(__name__)
TAG = "[OnlineFix/Screen]"

UI_PAGE_SIZE = 24
INITIAL_POOL_PAGES = 5
EXTEND_BATCH_PAGES = 3
PREFETCH_AHEAD_PAGES = 2
SEARCH_PREFETCH_PAGES = 2
SR_CATEGORY_BATCH_SIZE = 48
FG_CATEGORY_BATCH_SIZE = 30
MAX_AUTO_PREFETCH_HOPS = 3
SHELF_INITIAL_LIMIT = 18
SHELF_STEP_LIMIT = 18
INSTALLED_UPDATES_SLUG = "installed_updates"

_ORIG_AG_GET_LATEST = AnkerGamesClient.get_latest_games
_ORIG_AG_GET_CAT = AnkerGamesClient.get_category_games
_ORIG_AG_SEARCH = AnkerGamesClient.search_games
_ORIG_AG_HTTP_GET = AnkerGamesClient._get

_ORIG_FG_GET_LATEST = FitGirlClient.get_latest_games
_ORIG_FG_GET_BATCH = FitGirlClient.get_latest_games_batch
_ORIG_FG_GET_CAT = FitGirlClient.get_category_games
_ORIG_FG_SEARCH = FitGirlClient.search_games
_ORIG_FG_HTTP_GET = FitGirlClient._get

_ORIG_SR_GET_LATEST = SteamRipClient.get_latest_games
_ORIG_SR_GET_CAT = SteamRipClient.get_category_games
_ORIG_SR_SEARCH = SteamRipClient.search_games
_ORIG_SR_HTTP_GET = SteamRipClient._get

_ACTIVE_CHIP_STYLE = """
    QPushButton {
        background-color: rgba(14, 165, 233, 0.22);
        border: 1px solid rgba(56, 189, 248, 0.75);
        border-radius: 8px;
        color: #ffffff;
        font-weight: 700;
        padding: 0 12px;
    }
    QPushButton:hover {
        background-color: rgba(14, 165, 233, 0.32);
    }
"""

_IDLE_CHIP_STYLE = """
    QPushButton {
        background-color: rgba(18, 24, 38, 0.78);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 8px;
        color: #cbd5e1;
        font-weight: 600;
        padding: 0 12px;
    }
    QPushButton:hover {
        background-color: rgba(30, 41, 59, 0.9);
        border-color: rgba(56, 189, 248, 0.4);
        color: #ffffff;
    }
"""

_SHELF_NAV_BTN_STYLE = """
    QPushButton {
        background-color: rgba(255, 255, 255, 0.06);
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 7px;
        padding: 0px;
        min-width: 26px; max-width: 26px;
        min-height: 26px; max-height: 26px;
    }
    QPushButton:hover {
        background-color: rgba(56, 189, 248, 0.20);
        border-color: rgba(56, 189, 248, 0.55);
    }
"""

_SEARCH_INPUT_STYLE = """
    QLineEdit {
        background-color: rgba(18, 24, 38, 0.92);
        border: 1px solid rgba(139, 92, 246, 0.45);
        border-radius: 8px;
        padding: 0 12px;
        color: #ffffff;
        font-size: 13px;
    }
    QLineEdit:hover {
        border-color: rgba(139, 92, 246, 0.72);
        background-color: rgba(22, 29, 46, 0.96);
    }
    QLineEdit:focus {
        border: 1px solid #8b5cf6;
        background-color: rgba(24, 32, 52, 1.0);
    }
"""

_VIEW_STACK_STYLE = """
    QStackedWidget { background: transparent; }
    #ofCard { background-color: #0d141e; border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 14px; }
    #ofCard:hover, #ofCard:focus { border: 1px solid rgba(56, 189, 248, 0.68); background-color: #111b29; }
    #ofCard QLabel { background: transparent; border: none; }
    #ofCard QLabel#ofCardTitle { color: #ffffff; font-size: 13px; font-weight: 700; }
    #ofCard QLabel#ofCardInfo { color: #8b949e; font-size: 11px; }
    #ofCard QLabel#ofPoster { background-color: #111827; border-top-left-radius: 14px; border-top-right-radius: 14px; }
    #ofCategoryShelf {
        background-color: rgba(13, 18, 28, 0.48);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 14px;
    }
    #ofCategoryShelf QLabel { background: transparent; border: none; }
"""

_CARD_PLACEHOLDER_PIXMAP: QPixmap | None = None
_CACHED_ICONS: dict[tuple[str, int, str], QIcon] = {}
_CACHED_PIXMAPS: dict[tuple[str, int, str], QPixmap] = {}


def _placeholder_pixmap() -> QPixmap:
    global _CARD_PLACEHOLDER_PIXMAP
    if _CARD_PLACEHOLDER_PIXMAP is None or _CARD_PLACEHOLDER_PIXMAP.isNull():
        _CARD_PLACEHOLDER_PIXMAP = make_svg_pixmap("image", size=32, color="#334155")
    return _CARD_PLACEHOLDER_PIXMAP


def _cached_svg_icon(name: str, size: int, color: str) -> QIcon:
    key = (name, size, color)
    ico = _CACHED_ICONS.get(key)
    if ico is None or ico.isNull():
        ico = make_svg_icon(name, size=size, normal_color=color)
        _CACHED_ICONS[key] = ico
    return ico


def _cached_svg_pixmap(name: str, size: int, color: str) -> QPixmap:
    key = (name, size, color)
    pix = _CACHED_PIXMAPS.get(key)
    if pix is None or pix.isNull():
        pix = make_svg_pixmap(name, size=size, color=color)
        _CACHED_PIXMAPS[key] = pix
    return pix


def _game_uid(game: OnlineFixGame) -> str:
    return f"{game.source}:{game.url or game.id or game.title}"


def _dedupe_key(game: OnlineFixGame) -> str:
    return (game.url or game.id or game.title).rstrip("/").lower()


def _merge_unique_games(
    existing: list[OnlineFixGame],
    incoming: list[OnlineFixGame],
) -> tuple[list[OnlineFixGame], int]:
    """Append non-duplicate games from `incoming` after `existing`. Returns (merged_list, added_count)."""
    if not incoming:
        return list(existing), 0
    out = list(existing)
    by_key = {_dedupe_key(g): g for g in out}
    added = 0
    for g in incoming:
        k = _dedupe_key(g)
        if not k:
            continue
        prev = by_key.get(k)
        if prev is None:
            by_key[k] = g
            out.append(g)
            added += 1
        elif g.is_hypervisor and not prev.is_hypervisor:
            prev.is_hypervisor = True
    return out, added


def _merge_fresh_head(fresh: list[OnlineFixGame], cached_tail: list[OnlineFixGame]) -> list[OnlineFixGame]:
    """Put `fresh` items first while retaining non-duplicate deeper items from `cached_tail`."""
    merged, _ = _merge_unique_games(fresh, cached_tail)
    return merged


def _in_pytest() -> bool:
    return bool(_is_test_env() or "PYTEST_CURRENT_TEST" in os.environ)


def _should_query_ankergames_in_all_mode(ag_client: AnkerGamesClient) -> bool:
    """In production always query AnkerGames; in pytest only query AnkerGames in 'all' mode when mocked."""
    if not _in_pytest():
        return True
    if any(k in ag_client.__dict__ for k in ("get_latest_games", "get_category_games", "search_games", "_get")):
        return True
    return (
        AnkerGamesClient.get_latest_games is not _ORIG_AG_GET_LATEST
        or AnkerGamesClient.get_category_games is not _ORIG_AG_GET_CAT
        or AnkerGamesClient.search_games is not _ORIG_AG_SEARCH
        or AnkerGamesClient._get is not _ORIG_AG_HTTP_GET
    )


def _can_use_ag_category(ag_client: AnkerGamesClient) -> bool:
    if not _in_pytest():
        return True
    return (
        "get_category_games" in ag_client.__dict__
        or "_get" in ag_client.__dict__
        or AnkerGamesClient.get_category_games is not _ORIG_AG_GET_CAT
        or AnkerGamesClient._get is not _ORIG_AG_HTTP_GET
    )


def _should_query_fitgirl_in_all_mode(fg_client: FitGirlClient) -> bool:
    """In production always query FitGirl; in pytest only query FitGirl in 'all' mode when mocked."""
    if not _in_pytest():
        return True
    if any(
        k in fg_client.__dict__
        for k in ("get_latest_games", "get_latest_games_batch", "get_category_games", "search_games", "_get")
    ):
        return True
    return (
        FitGirlClient.get_latest_games is not _ORIG_FG_GET_LATEST
        or FitGirlClient.get_latest_games_batch is not _ORIG_FG_GET_BATCH
        or FitGirlClient.get_category_games is not _ORIG_FG_GET_CAT
        or FitGirlClient.search_games is not _ORIG_FG_SEARCH
        or FitGirlClient._get is not _ORIG_FG_HTTP_GET
    )


def _should_query_steamrip_in_all_mode(sr_client: SteamRipClient) -> bool:
    """In production always query SteamRIP; in pytest only query SteamRIP in 'all' mode when mocked."""
    if not _in_pytest():
        return True
    if any(k in sr_client.__dict__ for k in ("get_latest_games", "get_category_games", "search_games", "_get")):
        return True
    return (
        SteamRipClient.get_latest_games is not _ORIG_SR_GET_LATEST
        or SteamRipClient.get_category_games is not _ORIG_SR_GET_CAT
        or SteamRipClient.search_games is not _ORIG_SR_SEARCH
        or SteamRipClient._get is not _ORIG_SR_HTTP_GET
    )


def _can_use_fg_batch(fg_client: FitGirlClient) -> bool:
    if not _in_pytest():
        return FitGirlClient.get_latest_games is _ORIG_FG_GET_LATEST and "get_latest_games" not in fg_client.__dict__
    return (
        "get_latest_games_batch" in fg_client.__dict__
        or "_get" in fg_client.__dict__
        or FitGirlClient.get_latest_games_batch is not _ORIG_FG_GET_BATCH
        or FitGirlClient._get is not _ORIG_FG_HTTP_GET
    )


def _can_use_sr_batch(sr_client: SteamRipClient) -> bool:
    if not _in_pytest():
        return SteamRipClient.get_latest_games is _ORIG_SR_GET_LATEST and "get_latest_games" not in sr_client.__dict__
    return "_get" in sr_client.__dict__ or SteamRipClient._get is not _ORIG_SR_HTTP_GET


def _can_use_fg_category(fg_client: FitGirlClient) -> bool:
    if not _in_pytest():
        return True
    return (
        "get_category_games" in fg_client.__dict__
        or "_get" in fg_client.__dict__
        or FitGirlClient.get_category_games is not _ORIG_FG_GET_CAT
        or FitGirlClient._get is not _ORIG_FG_HTTP_GET
    )


def _can_use_sr_category(sr_client: SteamRipClient) -> bool:
    if not _in_pytest():
        return True
    return (
        "get_category_games" in sr_client.__dict__
        or "_get" in sr_client.__dict__
        or SteamRipClient.get_category_games is not _ORIG_SR_GET_CAT
        or SteamRipClient._get is not _ORIG_SR_HTTP_GET
    )


_CARD_SHARE_BTN_STYLE = (
    "QPushButton { background-color: rgba(11, 16, 26, 0.86); "
    "border: 1px solid rgba(255, 255, 255, 0.16); border-radius: 7px; padding: 0px; }"
    "QPushButton:hover { background-color: rgba(14, 165, 233, 0.30); "
    "border-color: rgba(56, 189, 248, 0.80); }"
    "QPushButton:pressed { background-color: rgba(14, 165, 233, 0.45); }"
)

_CARD_SHARE_COPIED_STYLE = (
    "QPushButton { background-color: rgba(6, 78, 59, 0.92); "
    "border: 1px solid rgba(16, 185, 129, 0.80); border-radius: 7px; padding: 0px; }"
)

_CARD_MENU_STYLE = (
    "QMenu { background-color: #111827; color: #e2e8f0; "
    "border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 8px; padding: 4px; }"
    "QMenu::item { padding: 6px 14px; border-radius: 5px; font-size: 12px; font-weight: 600; }"
    "QMenu::item:selected { background-color: rgba(56, 189, 248, 0.22); color: #ffffff; }"
)

_HV_POSTER_BADGE_STYLE = (
    "background-color: #ee0000; "
    "color: #ffffff; "
    "border: none; "
    "font-size: 12px; "
    "font-weight: 800; "
    "letter-spacing: 0.4px; "
    "border-top-left-radius: 3px; "
    "border-top-right-radius: 10px; "
    "border-bottom-left-radius: 10px; "
    "border-bottom-right-radius: 10px;"
)


class _OnlineFixGameCard(QFrame):
    """Uniform 2:3 vertical cover + horizontal store badge(s) + title + category/date subtitle."""

    clicked = Signal(object)    # OnlineFixGame
    share_requested = Signal(object)    # OnlineFixGame

    WIDTH = 188
    POSTER_H = 248
    HEIGHT = 312

    def __init__(self, game: OnlineFixGame, parent=None):
        super().__init__(parent)
        self.game = game
        self._rendered_title = ""
        self._rendered_sources: tuple[str, ...] = ()
        self._applied_poster_url = ""
        self._has_update = False
        self._is_hv = False
        self._hv_styled = False
        self.setObjectName("ofCard")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)     # controller navigation (gamepad_nav)
        self.setFixedSize(self.WIDTH, self.HEIGHT)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 10)
        lay.setSpacing(4)

        self.poster = QLabel()
        self.poster.setObjectName("ofPoster")
        self.poster.setFixedSize(self.WIDTH, self.POSTER_H)
        self.poster.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.poster.setPixmap(_placeholder_pixmap())

        self.badge_bar = QWidget(self.poster)
        self.badge_bar.setStyleSheet("background: transparent; border: none;")
        self.badge_bar.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.badge_layout = QHBoxLayout(self.badge_bar)
        self.badge_layout.setContentsMargins(0, 0, 0, 0)
        self.badge_layout.setSpacing(4)
        self.source_badges: list[SourceBadge] = []
        self.source_badge = SourceBadge(game.source, self.badge_bar)
        self.badge_layout.addWidget(self.source_badge)
        self.source_badges.append(self.source_badge)
        self.badge_bar.move(8, 8)

        self.update_pill = QLabel("CÓ CẬP NHẬT", self.poster)
        self.update_pill.setObjectName("ofUpdatePill")
        self.update_pill.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.update_pill.setStyleSheet(
            "background-color: rgba(6, 78, 59, 0.94); "
            "color: #ecfdf5; "
            "border: 1px solid #10b981; "
            "border-radius: 6px; "
            "padding: 2px 7px; "
            "font-size: 10px; "
            "font-weight: 800; "
            "letter-spacing: 0.4px;"
        )
        self.update_pill.adjustSize()
        self.update_pill.move(8, self.POSTER_H - self.update_pill.height() - 8)
        self.update_pill.hide()

        self.hv_badge = QLabel("HV", self.poster)
        self.hv_badge.setObjectName("ofHvBadge")
        self.hv_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hv_badge.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.hv_badge.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.hv_badge.setFixedSize(34, 26)
        self.hv_badge.move(self.WIDTH - 34, self.POSTER_H - 26)
        self._share_copied = False
        self._share_reset_timer = QTimer(self)
        self._share_reset_timer.setSingleShot(True)
        self._share_reset_timer.timeout.connect(self.reset_share_feedback)
        self.share_btn = QPushButton(self.poster)
        self.share_btn.setObjectName("ofShareBtn")
        self.share_btn.setFixedSize(28, 28)
        self.share_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.share_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.share_btn.setToolTip("Chia sẻ liên kết Steam")
        self.share_btn.setIcon(_cached_svg_icon("share", 13, "#e2e8f0"))
        self.share_btn.setIconSize(QSize(13, 13))
        self.share_btn.setStyleSheet(_CARD_SHARE_BTN_STYLE)
        self.share_btn.clicked.connect(self._on_share_btn_clicked)
        self._position_share_btn()
        self.hv_badge.hide()
        lay.addWidget(self.poster)

        text = QVBoxLayout()
        text.setContentsMargins(12, 5, 12, 0)
        text.setSpacing(2)
        self.title_lbl = QLabel()
        self.title_lbl.setObjectName("ofCardTitle")
        self.title_lbl.setFixedHeight(20)
        text.addWidget(self.title_lbl)

        self.info_lbl = QLabel()
        self.info_lbl.setObjectName("ofCardInfo")
        lay.addLayout(text)
        text.addWidget(self.info_lbl)
        lay.addStretch()
        self.sync_game(game)

    def _sync_badges(self):
        sources = tuple(self.game.available_sources())
        if sources == self._rendered_sources:
            return
        self._rendered_sources = sources
        compact = len(sources) > 1
        while len(self.source_badges) > len(sources):
            extra = self.source_badges.pop()
            self.badge_layout.removeWidget(extra)
            extra.hide()
            extra.deleteLater()
        for idx, src in enumerate(sources):
            if idx < len(self.source_badges):
                badge = self.source_badges[idx]
                badge.set_source(src, compact=compact)
                badge.show()
            else:
                badge = SourceBadge(src, self.badge_bar, compact=compact)
                self.badge_layout.addWidget(badge)
                badge.show()
                self.source_badges.append(badge)
        self.source_badge = self.source_badges[0]
        self.badge_bar.adjustSize()

    def sync_game(self, game: OnlineFixGame):
        self.game = game
        self._sync_badges()
        hv = bool(game.is_hypervisor)
        if hv != self._is_hv:
            self._is_hv = hv
            if hv:
                if not self._hv_styled:
                    self._hv_styled = True
                    self.hv_badge.setStyleSheet(_HV_POSTER_BADGE_STYLE)
                self.hv_badge.show()
                self.hv_badge.raise_()
            else:
                self.hv_badge.hide()
            self._position_share_btn()
        if game.title != self._rendered_title:
            self.reset_share_feedback()
            self._rendered_title = game.title
            font = self.title_lbl.font()
            font.setPixelSize(13)
            font.setBold(True)
            self.title_lbl.setText(
                QFontMetrics(font).elidedText(game.title, Qt.TextElideMode.ElideRight, self.WIDTH - 24)
            )
        self.refresh_meta_labels()

    def refresh_meta_labels(self):
        sources = self.game.available_sources()
        src_summary = " · ".join(source_display_name(s) for s in sources)
        cats = [CATEGORY_LABELS.get(c, "") for c in (self.game.categories or []) if c != "other"]
        cat_label = cats[0] if cats else ""
        if cat_label:
            info_text = f"{cat_label}  ·  {self.game.date}" if self.game.date else f"{cat_label}  ·  {src_summary}"
        else:
            info_text = f"{src_summary}  |  {self.game.date}" if self.game.date else src_summary

        info_font = self.info_lbl.font()
        info_font.setPixelSize(11)
        elided = QFontMetrics(info_font).elidedText(info_text, Qt.TextElideMode.ElideRight, self.WIDTH - 24)
        if self.info_lbl.text() != elided:
            self.info_lbl.setText(elided)

        tip = f"{self.game.title}\n[{src_summary}]"
        if cats:
            tip += " · " + ", ".join(cats[:3])
        if self.game.is_hypervisor:
            tip += "\nBản Hypervisor (HV) — dùng cơ chế Hypervisor Bypass"
        if self.game.update_info:
            tip += f"\n{self.game.update_info}"
        if self._has_update:
            tip += "\nĐã cài đặt trên máy — có bản cập nhật mới hơn trên cửa hàng"
        if self.toolTip() != tip:
            self.setToolTip(tip)

    def set_update_available(self, available: bool):
        flag = bool(available)
        if self._has_update == flag:
            return
        self._has_update = flag
        if flag:
            self.update_pill.adjustSize()
            self.update_pill.move(8, self.POSTER_H - self.update_pill.height() - 8)
            self.update_pill.show()
            self.update_pill.raise_()
        else:
            self.update_pill.hide()
        self.refresh_meta_labels()

    def set_poster_pixmap(self, pix: QPixmap | None, url: str = ""):
        if pix is not None and not pix.isNull():
            if url and self._applied_poster_url == url:
                return
            self._applied_poster_url = url
            self.poster.setPixmap(pix)

    def set_poster(self, data: bytes):
        pix = rounded_cover(data, self.WIDTH, self.POSTER_H, 14, top_only=True)
        self.set_poster_pixmap(pix)

    def mouseReleaseEvent(self, event):
        pt = event.position().toPoint()
        if (
            event.button() == Qt.MouseButton.LeftButton
            and self.rect().contains(pt)
            and not self.share_btn.rect().contains(self.share_btn.mapFrom(self, pt))
        ):
            self.clicked.emit(self.game)
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Space):
            self.clicked.emit(self.game)
            return
        super().keyPressEvent(event)

    def _position_share_btn(self):
        if self._is_hv:
            self.share_btn.move(self.WIDTH - 34 - 28 - 6, self.POSTER_H - 28 - 6)
        else:
            self.share_btn.move(self.WIDTH - 28 - 8, self.POSTER_H - 28 - 8)
        self.share_btn.raise_()

    @safe_slot
    def _on_share_btn_clicked(self):
        self.share_requested.emit(self.game)

    def show_share_copied(self):
        self._share_copied = True
        self.share_btn.setStyleSheet(_CARD_SHARE_COPIED_STYLE)
        self.share_btn.setIcon(_cached_svg_icon("check", 13, "#34d399"))
        self.share_btn.setToolTip("Đã sao chép liên kết Steam")
        self._share_reset_timer.start(1800)

    @safe_slot
    def reset_share_feedback(self):
        self._share_reset_timer.stop()
        if not self._share_copied:
            return
        self._share_copied = False
        self.share_btn.setStyleSheet(_CARD_SHARE_BTN_STYLE)
        self.share_btn.setIcon(_cached_svg_icon("share", 13, "#e2e8f0"))
        self.share_btn.setToolTip("Chia sẻ liên kết Steam")

    def _build_context_menu(self) -> QMenu:
        menu = QMenu(self)
        menu.setStyleSheet(_CARD_MENU_STYLE)
        act = menu.addAction(_cached_svg_icon("share", 14, "#e2e8f0"), "Chia sẻ liên kết Steam")
        act.triggered.connect(self._on_share_btn_clicked)
        return menu

    def contextMenuEvent(self, event):
        menu = self._build_context_menu()
        try:
            menu.exec(event.globalPos())
        finally:
            menu.deleteLater()


class _CategoryShelfWidget(QFrame):
    """Horizontal scrollable category shelf with icon, title, count pill, left/right scroll, and 'Xem tất cả'."""

    view_all_requested = Signal(str)    # category_slug
    near_end_reached = Signal(str)      # category_slug

    def __init__(
        self,
        category_slug: str,
        title: str,
        icon_name: str,
        total_count: int,
        show_view_all: bool = True,
        parent=None,
    ):
        super().__init__(parent)
        self.category_slug = category_slug
        self._cards_by_uid: dict[str, _OnlineFixGameCard] = {}
        self._current_uids: list[str] = []
        self._last_near_end_count = 0
        self.setObjectName("ofCategoryShelf")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(10)

        hdr = QHBoxLayout()
        hdr.setSpacing(8)
        icon_lbl = QLabel()
        icon_lbl.setFixedSize(18, 18)
        icon_lbl.setPixmap(_cached_svg_pixmap(icon_name, 18, "#38bdf8"))
        hdr.addWidget(icon_lbl)

        title_lbl = QLabel(title)
        title_lbl.setStyleSheet("color: #f8fafc; font-size: 15px; font-weight: 700;")
        hdr.addWidget(title_lbl)

        self.count_lbl = QLabel(f"{total_count} game")
        self.count_lbl.setStyleSheet(
            "color: #38bdf8; background-color: rgba(14, 165, 233, 0.14); "
            "border: 1px solid rgba(56, 189, 248, 0.28); border-radius: 9px; "
            "padding: 2px 8px; font-size: 11px; font-weight: 700;"
        )
        hdr.addWidget(self.count_lbl)
        hdr.addStretch()

        prev_btn = QPushButton()
        prev_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        prev_btn.setStyleSheet(_SHELF_NAV_BTN_STYLE)
        prev_btn.setIcon(_cached_svg_icon("chevron_left", 14, "#cbd5e1"))
        prev_btn.setIconSize(QSize(14, 14))
        prev_btn.setToolTip("Cuộn sang trái")
        prev_btn.clicked.connect(lambda: self._scroll_by(-420))
        hdr.addWidget(prev_btn)

        next_btn = QPushButton()
        next_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        next_btn.setStyleSheet(_SHELF_NAV_BTN_STYLE)
        next_btn.setIcon(_cached_svg_icon("chevron_right", 14, "#cbd5e1"))
        next_btn.setIconSize(QSize(14, 14))
        next_btn.setToolTip("Cuộn sang phải")
        next_btn.clicked.connect(lambda: self._scroll_by(420))
        hdr.addWidget(next_btn)

        if show_view_all:
            all_btn = make_button("Xem tất cả", DARK_BTN_STYLE, "grid", small=True)
            all_btn.clicked.connect(lambda: self.view_all_requested.emit(self.category_slug))
            hdr.addWidget(all_btn)

        lay.addLayout(hdr)

        self.row_scroll = QScrollArea()
        self.row_scroll.setWidgetResizable(True)
        self.row_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.row_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.row_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.row_scroll.setFixedHeight(_OnlineFixGameCard.HEIGHT + 18)
        self.row_scroll.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:horizontal { background: transparent; height: 6px; margin: 2px 0 0 0; }
            QScrollBar::handle:horizontal { background: rgba(148, 163, 184, 0.25); border-radius: 3px; min-width: 36px; }
            QScrollBar::handle:horizontal:hover { background: rgba(56, 189, 248, 0.60); }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; }
            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background: transparent; }
        """)
        self.row_container = QWidget()
        self.row_container.setStyleSheet("background: transparent;")
        self.row_layout = QHBoxLayout(self.row_container)
        self.row_layout.setContentsMargins(0, 0, 0, 4)
        self.row_layout.setSpacing(14)
        self.row_scroll.setWidget(self.row_container)
        self.row_scroll.horizontalScrollBar().valueChanged.connect(self._on_hscroll_changed)
        lay.addWidget(self.row_scroll)

    def _on_hscroll_changed(self, value: int):
        bar = self.row_scroll.horizontalScrollBar()
        if bar.maximum() > 0 and value >= bar.maximum() - 260:
            cur_len = len(self._current_uids)
            if cur_len and cur_len != self._last_near_end_count:
                self._last_near_end_count = cur_len
                self.near_end_reached.emit(self.category_slug)

    def _scroll_by(self, delta: int):
        bar = self.row_scroll.horizontalScrollBar()
        target = bar.value() + delta
        bar.setValue(target)
        if delta > 0 and target >= max(0, bar.maximum() - 260):
            cur_len = len(self._current_uids)
            if cur_len and cur_len != self._last_near_end_count:
                self._last_near_end_count = cur_len
                self.near_end_reached.emit(self.category_slug)

    def sync_games(
        self,
        games: list[OnlineFixGame],
        total_count: int,
        card_builder,
        card_syncer,
    ):
        cnt_txt = f"{total_count} game"
        if self.count_lbl.text() != cnt_txt:
            self.count_lbl.setText(cnt_txt)

        desired_uids = [_game_uid(g) for g in games]
        if desired_uids == self._current_uids:
            for uid, g in zip(desired_uids, games):
                card = self._cards_by_uid.get(uid)
                if card is not None and isValid(card):
                    card_syncer(card, g)
            return

        h_val = self.row_scroll.horizontalScrollBar().value()
        self.row_container.setUpdatesEnabled(False)
        try:
            while self.row_layout.count():
                self.row_layout.takeAt(0)
            next_cards: dict[str, _OnlineFixGameCard] = {}
            for uid, g in zip(desired_uids, games):
                existing = self._cards_by_uid.pop(uid, None)
                if existing is not None and isValid(existing):
                    card_syncer(existing, g)
                    card = existing
                else:
                    card = card_builder(g, self.row_container)
                next_cards[uid] = card
                self.row_layout.addWidget(card)
                card.show()
            self.row_layout.addStretch(1)
            for old in self._cards_by_uid.values():
                if isValid(old):
                    old.hide()
                    old.deleteLater()
            self._cards_by_uid = next_cards
            self._current_uids = desired_uids
        finally:
            self.row_container.setUpdatesEnabled(True)
            self.row_scroll.horizontalScrollBar().setValue(h_val)


class OnlineFixScreen(QWidget):
    """Full-screen unified Game Store ("KHO GAME": Online-Fix.me + AnkerGames + FitGirl Repacks + SteamRIP)."""

    back_requested = Signal()
    game_installed = Signal(dict)          # {"name", "exe_path", "install_location", "poster_url", "source"}
    source_filter_changed = Signal(str)    # "all" | SOURCE_ONLINE_FIX | SOURCE_ANKERGAMES | SOURCE_FITGIRL | SOURCE_STEAMRIP
    launch_game_requested = Signal(dict)   # {"name", "exe_path", "install_location", "online_fix"}

    def __init__(self, parent=None, initial_source: str = "all"):
        super().__init__(parent)
        self.setObjectName("onlineFixScreen")
        self.manager = get_online_fix_manager()
        self.client = self.manager.client
        self.ankergames_client = self.manager.ankergames_client
        self.fitgirl_client = self.manager.fitgirl_client
        self.steamrip_client = self.manager.steamrip_client
        self._posters = poster_loader(self.manager.fetch_poster_bytes)
        self._enricher = get_store_metadata_enricher()

        self._current_page = 1
        self._current_query = ""
        self._enabled_stores: list[str] = self.manager.get_enabled_stores()
        valid_initial = initial_source if initial_source in ("all", *ALL_STORE_SOURCES) else "all"
        if valid_initial != "all" and valid_initial not in self._enabled_stores:
            logger.warning(f"{TAG} Initial source {valid_initial!r} is disabled; falling back to 'all'")
            valid_initial = "all"
        self._source_filter = valid_initial
        self._category_filter = "discovery"     # "discovery" (shelves) | "all" (grid) | category slug
        self._request_id = 0                    # only the newest page request may fill the view
        self._task_of: Task | None = None
        self._task_ag: Task | None = None
        self._task_fg: Task | None = None
        self._task_sr: Task | None = None
        self._task_pool: Task | None = None
        self._cat_tasks: dict[str, Task] = {}

        self._of_games: list[OnlineFixGame] = []
        self._ag_games: list[OnlineFixGame] = []
        self._fg_games: list[OnlineFixGame] = []
        self._sr_games: list[OnlineFixGame] = []
        self._of_loading = False
        self._ag_loading = False
        self._fg_loading = False
        self._sr_loading = False
        self._of_done = False
        self._ag_done = False
        self._fg_done = False
        self._sr_done = False
        self._of_error = ""
        self._ag_error = ""
        self._fg_error = ""
        self._sr_error = ""
        self._queried_sources_count = 1
        self._completed_sources_count = 0

        # Multi-page catalog pool cursors & exhaustion flags
        self._of_next_page = 2
        self._ag_next_page = 2
        self._fg_next_page = 2
        self._fg_next_batch = 1
        self._sr_next_page = 2
        self._sr_next_batch = 1
        self._of_exhausted = False
        self._ag_exhausted = False
        self._fg_exhausted = False
        self._sr_exhausted = False
        self._pool_loading = False
        self._wait_extend_page = False
        self._backfilling_slugs: set[str] = set()
        self._cat_ag_next_page: dict[str, int] = {}
        self._cat_sr_next_page: dict[str, int] = {}
        self._cat_fg_next_page: dict[str, int] = {}
        self._cat_ag_exhausted: set[str] = set()
        self._cat_sr_exhausted: set[str] = set()
        self._cat_fg_exhausted: set[str] = set()
        self._auto_prefetch_hops = 0
        self._shelf_limits: dict[str, int] = {}
        self._installed_ts_map: dict[str, float] = {}

        self._cards: dict[str, list[_OnlineFixGameCard]] = {}          # poster url -> cards waiting for it
        self._cards_by_key: dict[str, list[_OnlineFixGameCard]] = {}   # norm game key -> live card instances
        self._grid_card_pool: dict[str, _OnlineFixGameCard] = {}       # game uid -> reusable grid card
        self._grid_uids: list[str] = []
        self._shelf_widgets: dict[str, _CategoryShelfWidget] = {}      # category slug -> reusable shelf widget
        self._shelf_order: list[str] = []
        self._catalog_version = 0
        self._interleave_cache: tuple[tuple[str, int], list[OnlineFixGame]] | None = None
        self._source_cache: tuple[int, dict[str, list[OnlineFixGame]]] | None = None
        self._pending_poster_urls: set[str] = set()
        self._chip_buttons: dict[str, QPushButton] = {}
        self._dialog_open = False
        self._catalog_cache_path = get_catalog_cache_path()
        self._inflight_share_keys: set[str] = set()

        self._poster_flush_timer = QTimer(self)
        self._poster_flush_timer.setSingleShot(True)
        self._poster_flush_timer.setInterval(16)
        self._poster_flush_timer.timeout.connect(self._flush_pending_posters)

        self._rebucket_timer = QTimer(self)
        self._rebucket_timer.setSingleShot(True)
        self._rebucket_timer.setInterval(650)
        self._rebucket_timer.timeout.connect(self._on_rebucket_timeout)

        self._setup_ui()
        self._posters.loaded.connect(self._on_poster_loaded)
        self._enricher.game_enriched.connect(self._on_game_enriched)
        self.manager.task_added.connect(self._update_queue_button)
        self.manager.task_paused.connect(self._update_queue_button)
        self.manager.task_resumed.connect(self._update_queue_button)
        self.manager.task_completed.connect(self._on_task_completed)
        self.manager.task_failed.connect(self._update_queue_button)
        self.manager.task_cancelled.connect(self._update_queue_button)
        self.manager.tasks_removed.connect(self._update_queue_button)
        self._update_queue_button()
        self._refresh_store_copy()
        self._update_filter_buttons()
        logger.info(
            f"{TAG} Screen opened (source={self._source_filter}, enabled_stores={self._enabled_stores}, "
            f"tasks: {len(self.manager.list_tasks())})"
        )
        QTimer.singleShot(0, self._initial_load)

    def deleteLater(self):
        self._rebucket_timer.stop()
        self._poster_flush_timer.stop()
        self._request_id += 1
        super().deleteLater()

    def showEvent(self, event):
        super().showEvent(event)
        if self._of_done or self._ag_done or self._fg_done or self._sr_done or self._of_games:
            self.refresh_installed_games_state(render=True)

    @safe_slot
    def refresh_installed_games_state(self, render: bool = True):
        try:
            new_map = self.manager.get_installed_games_timestamps()
        except Exception as e:  # noqa: BLE001
            logger.warning(f"{TAG} Could not read installed games timestamps: {e}")
            new_map = {}
        if new_map == self._installed_ts_map:
            return
        self._installed_ts_map = new_map
        for cards in self._cards_by_key.values():
            for c in cards:
                if isValid(c):
                    c.set_update_available(is_game_update_available(c.game, self._installed_ts_map))
        if render:
            self._render_from_memory()

    @safe_slot
    def _initial_load(self):
        self._load_games("", 1)

    # ------------------------------------------------------------ layout

    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.header = ScreenHeader("Kho Game", "store")
        self.header.back_requested.connect(self.back_requested.emit)

        self.search_input = QLineEdit()
        self.search_input.setMinimumWidth(180)
        self.search_input.setFixedHeight(36)
        self.search_input.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.search_input.setClearButtonEnabled(True)
        self.search_input.setPlaceholderText(
            "Tìm kiếm game trên Online-Fix.me, FitGirl Repacks & SteamRIP (vd: Elden Ring, Palworld)…"
        )
        self.search_input.addAction(
            make_svg_icon("search", size=16, normal_color="#a78bfa"),
            QLineEdit.ActionPosition.LeadingPosition,
        )
        self.search_input.setStyleSheet(_SEARCH_INPUT_STYLE)
        self.search_input.returnPressed.connect(self._on_search)
        self.header.add_widget(self.search_input, stretch=1)

        self.search_btn = self.header.add_button(
            "Tìm kiếm",
            "primary",
            icon="search",
            tooltip="Tìm kiếm game theo từ khóa",
        )
        self.search_btn.clicked.connect(self._on_search)

        self.latest_btn = self.header.add_button(
            "Làm mới",
            "secondary",
            icon="refresh",
            tooltip="Xóa từ khóa tìm kiếm và tải lại danh sách mới nhất",
        )
        self.latest_btn.clicked.connect(self._on_show_latest)

        self.queue_btn = self.header.add_button("Danh sách tải", "primary", icon="download")
        self.queue_btn.clicked.connect(self._toggle_drawer)
        root.addWidget(self.header)

        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(*CONTENT_MARGINS)
        lay.setSpacing(8)

        # Row 1: Store Source Filters (enabled stores first, disabled stores at the end)
        source_row = QHBoxLayout()
        source_row.setSpacing(8)
        self.source_row_label = QLabel("Nguồn cửa hàng:")
        self.source_row_label.setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 700; padding-right: 4px;")
        source_row.addWidget(self.source_row_label)

        self.filter_all_btn = make_button("Tất cả", PURPLE_BTN_STYLE, "store", small=True)
        self.filter_all_btn.setToolTip("Hiển thị kết hợp từ Online-Fix, AnkerGames, FitGirl và SteamRIP")
        self.filter_all_btn.clicked.connect(lambda: self._on_set_source_filter("all"))
        source_row.addWidget(self.filter_all_btn)

        self.store_filters_layout = QHBoxLayout()
        self.store_filters_layout.setContentsMargins(0, 0, 0, 0)
        self.store_filters_layout.setSpacing(8)

        self.filter_of_btn = make_button("Online-Fix", DARK_BTN_STYLE, "users", small=True)
        self.filter_of_btn.setToolTip("Lọc cửa hàng Online-Fix.me (Co-op / Multiplayer)")
        self.filter_of_btn.clicked.connect(lambda: self._on_set_source_filter(SOURCE_ONLINE_FIX))

        self.filter_ag_btn = make_button("AnkerGames", DARK_BTN_STYLE, "bolt", small=True)
        self.filter_ag_btn.setToolTip("Lọc cửa hàng AnkerGames (Pre-installed Direct Download)")
        self.filter_ag_btn.clicked.connect(lambda: self._on_set_source_filter(SOURCE_ANKERGAMES))

        self.filter_fg_btn = make_button("FitGirl", DARK_BTN_STYLE, "package", small=True)
        self.filter_fg_btn.setToolTip("Lọc cửa hàng FitGirl Repacks")
        self.filter_fg_btn.clicked.connect(lambda: self._on_set_source_filter(SOURCE_FITGIRL))

        self.filter_sr_btn = make_button("SteamRIP", DARK_BTN_STYLE, "steam", small=True)
        self.filter_sr_btn.setToolTip("Lọc cửa hàng SteamRIP (Pre-installed Games)")
        self.filter_sr_btn.clicked.connect(lambda: self._on_set_source_filter(SOURCE_STEAMRIP))

        self._store_filter_buttons: dict[str, QPushButton] = {
            SOURCE_ONLINE_FIX: self.filter_of_btn,
            SOURCE_ANKERGAMES: self.filter_ag_btn,
            SOURCE_FITGIRL: self.filter_fg_btn,
            SOURCE_STEAMRIP: self.filter_sr_btn,
        }
        self._store_button_order: list[str] = []
        for src in (SOURCE_ONLINE_FIX, SOURCE_FITGIRL, SOURCE_STEAMRIP, SOURCE_ANKERGAMES):
            self.store_filters_layout.addWidget(self._store_filter_buttons[src])
            self._store_button_order.append(src)
        for b in (self.filter_all_btn, *self._store_filter_buttons.values()):
            b.setFixedHeight(28)

        source_row.addLayout(self.store_filters_layout)
        source_row.addStretch(1)

        lay.addLayout(source_row)

        # Row 3: Horizontal Category Chip Bar
        self.category_scroll = QScrollArea()
        self.category_scroll.setWidgetResizable(True)
        self.category_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.category_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.category_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.category_scroll.setFixedHeight(34)
        self.category_scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        cat_container = QWidget()
        cat_container.setStyleSheet("background: transparent;")
        cat_lay = QHBoxLayout(cat_container)
        cat_lay.setContentsMargins(0, 0, 0, 0)
        cat_lay.setSpacing(6)

        chip_specs = [
            ("discovery", "Kệ Khám Phá", "store"),
            ("all", "Tất cả (Lưới)", "grid"),
            (INSTALLED_UPDATES_SLUG, "Có cập nhật", "refresh"),
            *STORE_CATEGORIES,
        ]
        for slug, label, icon_name in chip_specs:
            btn = make_button(label.replace("&", "&&"), _IDLE_CHIP_STYLE, icon_name, small=True, icon_color="#cbd5e1")
            btn.setFixedHeight(28)
            btn.clicked.connect(lambda _=False, s=slug: self._on_set_category_filter(s))
            cat_lay.addWidget(btn)
            self._chip_buttons[slug] = btn
        cat_lay.addStretch(1)
        self.category_scroll.setWidget(cat_container)
        lay.addWidget(self.category_scroll)
        self._update_category_chips([])

        # Row 4: Status bar
        status_row = QHBoxLayout()
        status_row.setSpacing(8)
        self.inline_spinner = SpinningLoader(size=16, line_width=2, color="#38bdf8", parent=body)
        self.inline_spinner.hide()
        status_row.addWidget(self.inline_spinner)
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        status_row.addWidget(self.status_label, 1)
        self.retry_btn = self._button("Thử lại", DARK_BTN_STYLE, "refresh")
        self.retry_btn.clicked.connect(lambda: self._load_games(self._current_query, self._current_page, force_network=True))
        self.retry_btn.hide()
        status_row.addWidget(self.retry_btn)
        lay.addLayout(status_row)

        # Centered spinning loading box shown only when no cached/loaded games exist yet
        self.loading_box = QWidget()
        self.loading_box.setStyleSheet("background: transparent;")
        loading_lay = QVBoxLayout(self.loading_box)
        loading_lay.setContentsMargins(0, 48, 0, 48)
        loading_lay.setSpacing(12)
        loading_lay.addStretch()
        self.center_spinner = SpinningLoader(size=44, line_width=4, color="#38bdf8", parent=self.loading_box)
        loading_lay.addWidget(self.center_spinner, 0, Qt.AlignmentFlag.AlignCenter)
        self.loading_title_lbl = QLabel("Đang tải dữ liệu Kho Game…")
        self.loading_title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.loading_title_lbl.setStyleSheet("color: #e2e8f0; font-size: 14px; font-weight: 700; background: transparent;")
        loading_lay.addWidget(self.loading_title_lbl)
        self.loading_sub_lbl = QLabel("Đang kết nối đa luồng tới Online-Fix.me, AnkerGames, FitGirl Repacks & SteamRIP")
        self.loading_sub_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.loading_sub_lbl.setStyleSheet("color: #64748b; font-size: 12px; background: transparent;")
        loading_lay.addWidget(self.loading_sub_lbl)
        loading_lay.addStretch()
        self.loading_box.hide()
        lay.addWidget(self.loading_box, 1)

        # Dual-mode view stack: Page 0 = Horizontal Category Shelves, Page 1 = Full Grid
        self.view_stack = QStackedWidget()
        self.view_stack.setStyleSheet(_VIEW_STACK_STYLE)

        self.shelves_scroll = QScrollArea()
        self.shelves_scroll.setWidgetResizable(True)
        self.shelves_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.shelves_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.shelves_scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        self.shelves_container = QWidget()
        self.shelves_container.setStyleSheet("background: transparent;")
        self.shelves_layout = QVBoxLayout(self.shelves_container)
        self.shelves_layout.setContentsMargins(0, 0, 4, 8)
        self.shelves_layout.setSpacing(16)
        self.shelves_scroll.setWidget(self.shelves_container)
        self.view_stack.addWidget(self.shelves_scroll)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll_area.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        self.grid_container = QWidget()
        self.grid_container.setStyleSheet("background: transparent;")
        self.grid_layout = FlowLayout(self.grid_container, margin=0, spacing=16)
        self.scroll_area.setWidget(self.grid_container)
        self.view_stack.addWidget(self.scroll_area)

        lay.addWidget(self.view_stack, 1)

        # Pagination bar
        page_row = QHBoxLayout()
        page_row.setSpacing(10)
        page_row.addStretch()
        self.prev_page_btn = self._button("Trang trước", DARK_BTN_STYLE, "chevron_left")
        self.prev_page_btn.clicked.connect(self._on_prev_page)
        page_row.addWidget(self.prev_page_btn)
        self.page_info_label = QLabel("Trang 1")
        self.page_info_label.setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 700; padding: 0 8px;")
        page_row.addWidget(self.page_info_label)
        self.next_page_btn = self._button("Trang sau", DARK_BTN_STYLE, "chevron_right")
        self.next_page_btn.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.next_page_btn.clicked.connect(self._on_next_page)
        page_row.addWidget(self.next_page_btn)
        page_row.addStretch()
        lay.addLayout(page_row)

        self.download_drawer = DownloadDrawer(self.manager, self)
        self.download_drawer.setFixedHeight(240)
        self.download_drawer.collapse_requested.connect(self._toggle_drawer)
        self.download_drawer.launch_requested.connect(self._on_drawer_launch_requested)
        lay.addWidget(self.download_drawer)
        self.download_drawer.setVisible(bool(self.manager.list_tasks()))

        root.addWidget(body, 1)

    @staticmethod
    def _button(text: str, style: str, icon: str) -> QPushButton:
        return make_button(text, style, icon)

    def _set_status(self, text: str, kind: str = "info"):
        self.status_label.setText(text)
        self.status_label.setStyleSheet(f"color: {STATUS_COLORS[kind]}; font-size: 12px;")

    @safe_slot
    def _on_drawer_launch_requested(self, game_data: dict):
        win = self.window()
        if win is not None and win is not self and hasattr(win, "_on_launch_game"):
            self.launch_game_requested.emit(game_data)
            return
        from app.core.game_launcher import launch_game
        name = str(game_data.get("name") or "")
        exe = str(game_data.get("exe_path") or "")
        loc = str(game_data.get("install_location") or "")
        t = Task(
            lambda: launch_game(name, exe, install_location=loc, ensure_shortcut_if_pending=True),
            f"launch-{name}",
        )
        t.start_tracked()

    # ------------------------------------------------------------ header & sidebar sync

    @safe_slot
    def _update_queue_button(self):
        total = len(self.manager.list_tasks())
        active = self.manager.active_count()
        self.queue_btn.setText(
            f"Danh sách tải ({active})" if active else (f"Danh sách tải ({total})" if total else "Danh sách tải")
        )
        self.queue_btn.updateGeometry()

    @safe_slot
    def _toggle_drawer(self):
        visible = not self.download_drawer.isVisible()
        self.download_drawer.setVisible(visible)
        logger.debug(f"{TAG} Download list {'shown' if visible else 'hidden'}")

    @property
    def current_source_filter(self) -> str:
        return self._source_filter

    def _enabled_store_names_text(self) -> str:
        names = [source_display_name(s) for s in self._enabled_stores]
        if not names:
            return "Online-Fix.me"
        if len(names) == 1:
            return names[0]
        return f"{', '.join(names[:-1])} & {names[-1]}"

    def _refresh_store_copy(self):
        names_text = self._enabled_store_names_text()
        self.header.setToolTip(
            f"Khám phá & tải game từ {names_text} — "
            "sắp xếp theo ngày phát hành & báo cập nhật cho game đã cài đặt"
        )
        self.search_input.setPlaceholderText(
            f"Tìm kiếm game trên {names_text} (vd: Elden Ring, Palworld)…"
        )
        self.search_input.setToolTip(
            f"Nhập tên game cần tìm kiếm trên {names_text} rồi nhấn Enter hoặc bấm Tìm kiếm"
        )
        self.filter_all_btn.setToolTip(f"Hiển thị kết hợp từ {names_text}")
        self.loading_sub_lbl.setText(f"Đang kết nối đa luồng tới {names_text}")

    def set_enabled_stores(self, stores: list[str] | tuple[str, ...]):
        """Live-update enabled game stores when changed from System Settings."""
        new_stores = normalize_enabled_stores(stores)
        if new_stores == self._enabled_stores:
            return
        old_stores = list(self._enabled_stores)
        newly_enabled = [s for s in new_stores if s not in old_stores]
        newly_disabled = [s for s in old_stores if s not in new_stores]
        self._enabled_stores = new_stores
        logger.info(f"{TAG} Updated enabled stores: {old_stores} -> {new_stores}")

        self._refresh_store_copy()

        if self._source_filter != "all" and self._source_filter not in self._enabled_stores:
            logger.info(
                f"{TAG} Active source filter {self._source_filter!r} was disabled; falling back to 'all'"
            )
            self._source_filter = "all"
            self._current_page = 1
            self.source_filter_changed.emit("all")

        for src in newly_disabled:
            if src == SOURCE_ONLINE_FIX:
                self._of_games = []
                self._of_loading = False
                self._of_done = True
                self._of_exhausted = True
                self._of_error = ""
            elif src == SOURCE_ANKERGAMES:
                self._ag_games = []
                self._ag_loading = False
                self._ag_done = True
                self._ag_exhausted = True
                self._ag_error = ""
            elif src == SOURCE_FITGIRL:
                self._fg_games = []
                self._fg_loading = False
                self._fg_done = True
                self._fg_exhausted = True
                self._fg_error = ""
            elif src == SOURCE_STEAMRIP:
                self._sr_games = []
                self._sr_loading = False
                self._sr_done = True
                self._sr_exhausted = True
                self._sr_error = ""
        if newly_disabled:
            self._catalog_version += 1

        if newly_enabled:
            self._load_games(self._current_query, 1)
        else:
            self._update_filter_buttons()
            self._render_from_memory()

    def set_source_filter(self, source_filter: str, emit_signal: bool = False):
        """Programmatically select a store source."""
        if source_filter not in ("all", *ALL_STORE_SOURCES):
            source_filter = "all"
        if source_filter != "all" and source_filter not in self._enabled_stores:
            logger.warning(f"{TAG} Refused switching source filter to disabled store {source_filter!r}")
            return
        self._apply_source_filter(source_filter, emit_signal=emit_signal)

    # ------------------------------------------------------------ search / paging / source & category filters

    @safe_slot
    def _on_set_source_filter(self, source_filter: str):
        self._apply_source_filter(source_filter, emit_signal=True)

    @property
    def _category_backfilling(self) -> bool:
        return bool(self._backfilling_slugs)

    def _apply_source_filter(self, source_filter: str, emit_signal: bool = True):
        if source_filter != "all" and source_filter not in self._enabled_stores:
            logger.warning(f"{TAG} Refused switching source filter to disabled store {source_filter!r}")
            return
        if self._source_filter == source_filter:
            return
        self._source_filter = source_filter
        self._current_page = 1
        self._wait_extend_page = False
        self._auto_prefetch_hops = 0
        self.scroll_area.verticalScrollBar().setValue(0)
        logger.info(
            f"{TAG} Switched source filter to {source_filter!r} "
            f"(OF={len(self._of_games)}, AG={len(self._ag_games)}, FG={len(self._fg_games)}, SR={len(self._sr_games)}, page={self._current_page})"
        )
        self._update_filter_buttons()
        if emit_signal:
            self.source_filter_changed.emit(self._source_filter)

        if source_filter == SOURCE_ONLINE_FIX and not self._of_loading and not self._of_done:
            self._queried_sources_count += 1
            self._launch_online_fix_task(self._request_id, self._current_query, 1)
            return
        if source_filter == SOURCE_ANKERGAMES and not self._ag_loading and not self._ag_done:
            self._queried_sources_count += 1
            self._launch_ankergames_task(self._request_id, self._current_query, 1)
            return
        if source_filter == SOURCE_FITGIRL and not self._fg_loading and not self._fg_done:
            self._queried_sources_count += 1
            self._launch_fitgirl_task(self._request_id, self._current_query, 1)
            return
        if source_filter == SOURCE_STEAMRIP and not self._sr_loading and not self._sr_done:
            self._queried_sources_count += 1
            self._launch_steamrip_task(self._request_id, self._current_query, 1)
            return

        self._render_from_memory()
        self._ensure_prefetch_buffer()

    @safe_slot
    def _on_set_category_filter(self, category_slug: str):
        if self._category_filter == category_slug and self._current_page == 1:
            return
        self._category_filter = category_slug
        self._current_page = 1
        self._wait_extend_page = False
        self._auto_prefetch_hops = 0
        self.scroll_area.verticalScrollBar().setValue(0)
        logger.info(f"{TAG} User selected category view {category_slug!r}")
        self._render_from_memory()
        self._ensure_prefetch_buffer()

    def _update_filter_buttons(self):
        enabled = set(self._enabled_stores)
        of_cnt = len(self._of_games) if SOURCE_ONLINE_FIX in enabled else 0
        ag_cnt = len(self._ag_games) if SOURCE_ANKERGAMES in enabled else 0
        fg_cnt = len(self._fg_games) if SOURCE_FITGIRL in enabled else 0
        sr_cnt = len(self._sr_games) if SOURCE_STEAMRIP in enabled else 0
        total_cnt = len(self._get_cached_source_games("all")) if (of_cnt or ag_cnt or fg_cnt or sr_cnt) else 0
        any_done = any(
            flag
            for src, flag in (
                (SOURCE_ONLINE_FIX, self._of_done),
                (SOURCE_ANKERGAMES, self._ag_done),
                (SOURCE_FITGIRL, self._fg_done),
                (SOURCE_STEAMRIP, self._sr_done),
            )
            if src in enabled
        )
        texts = (
            (self.filter_all_btn, f"Tất cả ({total_cnt})" if any_done and total_cnt else "Tất cả"),
            (
                self.filter_of_btn,
                f"Online-Fix ({of_cnt})" if (SOURCE_ONLINE_FIX in enabled and (self._of_done or of_cnt)) else "Online-Fix",
            ),
            (
                self.filter_ag_btn,
                f"AnkerGames ({ag_cnt})" if (SOURCE_ANKERGAMES in enabled and (self._ag_done or ag_cnt)) else "AnkerGames",
            ),
            (
                self.filter_fg_btn,
                f"FitGirl ({fg_cnt})" if (SOURCE_FITGIRL in enabled and (self._fg_done or fg_cnt)) else "FitGirl",
            ),
            (
                self.filter_sr_btn,
                f"SteamRIP ({sr_cnt})" if (SOURCE_STEAMRIP in enabled and (self._sr_done or sr_cnt)) else "SteamRIP",
            ),
        )
        for btn, txt in texts:
            if btn.text() != txt:
                btn.setText(txt)
        base_tooltips = {
            SOURCE_ONLINE_FIX: "Lọc cửa hàng Online-Fix.me (Co-op / Multiplayer)",
            SOURCE_ANKERGAMES: "Lọc cửa hàng AnkerGames (Pre-installed Direct Download)",
            SOURCE_FITGIRL: "Lọc cửa hàng FitGirl Repacks",
            SOURCE_STEAMRIP: "Lọc cửa hàng SteamRIP (Pre-installed Games)",
        }
        base_order = (
            SOURCE_ONLINE_FIX,
            SOURCE_ANKERGAMES,
            SOURCE_FITGIRL,
            SOURCE_STEAMRIP,
        )
        desired_order = [s for s in base_order if s in enabled] + [s for s in base_order if s not in enabled]
        if desired_order != self._store_button_order:
            while self.store_filters_layout.count():
                self.store_filters_layout.takeAt(0)
            for src in desired_order:
                self.store_filters_layout.addWidget(self._store_filter_buttons[src])
            self._store_button_order = desired_order

        mapping = [
            ("all", self.filter_all_btn, "store"),
            (SOURCE_ONLINE_FIX, self.filter_of_btn, "users"),
            (SOURCE_ANKERGAMES, self.filter_ag_btn, "bolt"),
            (SOURCE_FITGIRL, self.filter_fg_btn, "package"),
            (SOURCE_STEAMRIP, self.filter_sr_btn, "steam"),
        ]
        for key, btn, icon_name in mapping:
            is_enabled = (key == "all") or (key in enabled)
            if btn.isEnabled() != is_enabled:
                btn.setEnabled(is_enabled)
                btn.setCursor(
                    Qt.CursorShape.PointingHandCursor if is_enabled else Qt.CursorShape.ForbiddenCursor
                )
            if key != "all":
                tip = (
                    base_tooltips[key]
                    if is_enabled
                    else f"{source_display_name(key)} đang tắt — bật lại trong Cài đặt hệ thống"
                )
                if btn.toolTip() != tip:
                    btn.setToolTip(tip)
            active = is_enabled and (self._source_filter == key)
            state_tag = "active" if active else ("idle" if is_enabled else "disabled")
            if btn.property("srcState") != state_tag:
                btn.setProperty("srcState", state_tag)
                btn.setProperty("srcActive", active)
                btn.setStyleSheet(
                    (PURPLE_BTN_STYLE if active else DARK_BTN_STYLE)
                    + "QPushButton { height: 28px; min-height: 28px; max-height: 28px; font-size: 11px; }"
                )
                icon_color = "#ffffff" if active else ("#cbd5e1" if is_enabled else "#475569")
                btn.setIcon(_cached_svg_icon(icon_name, 14, icon_color))

    def _update_category_chips(self, base_games: list[OnlineFixGame]):
        counts: dict[str, int] = {slug: 0 for slug, _, _ in STORE_CATEGORIES}
        for g in base_games:
            cats = g.categories or classify_game_categories(g)
            for c in cats:
                if c in counts:
                    counts[c] += 1

        upd_cnt = len(find_installed_game_updates(base_games, self._installed_ts_map)) if self._installed_ts_map else 0
        use_shelves = self._is_shelf_mode_active()
        active_chip = "discovery" if use_shelves else (
            "all" if self._category_filter == "discovery" else self._category_filter
        )

        specs = [
            ("discovery", "Kệ Khám Phá", "store", None),
            ("all", f"Tất cả ({len(base_games)})" if base_games else "Tất cả (Lưới)", "grid", None),
            (INSTALLED_UPDATES_SLUG, "Có cập nhật", "refresh", upd_cnt),
            *[(slug, label, icon, counts.get(slug, 0)) for slug, label, icon in STORE_CATEGORIES],
        ]
        for slug, label, icon_name, cnt in specs:
            btn = self._chip_buttons.get(slug)
            if not btn:
                continue
            if slug in ("other", INSTALLED_UPDATES_SLUG) and not cnt and active_chip != slug:
                if not btn.isHidden():
                    btn.hide()
                continue
            if btn.isHidden():
                btn.show()
            txt = (f"{label} ({cnt})" if cnt else label).replace("&", "&&")
            if btn.text() != txt:
                btn.setText(txt)
            is_act = (slug == active_chip)
            if btn.property("chipActive") is not is_act:
                btn.setProperty("chipActive", is_act)
                btn.setStyleSheet(_ACTIVE_CHIP_STYLE if is_act else _IDLE_CHIP_STYLE)
                btn.setIcon(_cached_svg_icon(icon_name, 13, "#38bdf8" if is_act else "#94a3b8"))

    def _is_shelf_mode_active(self) -> bool:
        return (
            self._category_filter == "discovery"
            and not self._current_query
            and self._current_page == 1
        )

    @safe_slot
    def _on_search(self):
        q = self.search_input.text().strip()
        logger.info(f"{TAG} User searched {q!r}" if q else f"{TAG} User searched with an empty query (latest)")
        if q:
            self._category_filter = "all"
        elif self._category_filter == "all":
            self._category_filter = "discovery"
        self._load_games(q, 1)

    @safe_slot
    def _on_show_latest(self):
        self.search_input.clear()
        self._category_filter = "discovery"
        logger.info(f"{TAG} User refreshed Kho Game latest catalog")
        self._load_games("", 1, force_network=True)

    @safe_slot
    def _on_prev_page(self):
        if self._current_page > 1:
            self._current_page -= 1
            self._wait_extend_page = False
            self._auto_prefetch_hops = 0
            logger.info(f"{TAG} User navigated to previous page {self._current_page}")
            if self._current_page == 1 and not self._current_query and self._category_filter == "all":
                self._category_filter = "discovery"
            self.scroll_area.verticalScrollBar().setValue(0)
            self._render_from_memory()
            self._ensure_prefetch_buffer()

    @safe_slot
    def _on_next_page(self):
        if self._category_filter == "discovery":
            self._category_filter = "all"
        self._current_page += 1
        self._auto_prefetch_hops = 0
        logger.info(f"{TAG} User navigated to next page {self._current_page}")
        self.scroll_area.verticalScrollBar().setValue(0)

        all_filtered = self._current_filtered_games()
        start = (self._current_page - 1) * UI_PAGE_SIZE

        if start < len(all_filtered):
            self._wait_extend_page = False
            self._render_from_memory()
            self._ensure_prefetch_buffer()
        elif not self._current_query and self._can_extend_category(self._category_filter):
            self._prefetch_category_async(self._category_filter, wait_for_page=True)
        else:
            self._extend_pool_async(wait_for_page=True, force_attempt=True)

    # ------------------------------------------------------------ async multi-page pool + disk cache hydration

    def _can_extend_active_sources(self) -> bool:
        enabled = set(self._enabled_stores)
        want_of = (
            SOURCE_ONLINE_FIX in enabled
            and self._source_filter in ("all", SOURCE_ONLINE_FIX)
            and not self._of_exhausted
        )
        want_ag = (
            SOURCE_ANKERGAMES in enabled
            and self._source_filter in ("all", SOURCE_ANKERGAMES)
            and not self._ag_exhausted
            and (_should_query_ankergames_in_all_mode(self.ankergames_client) or self._source_filter == SOURCE_ANKERGAMES)
        )
        want_fg = (
            SOURCE_FITGIRL in enabled
            and self._source_filter in ("all", SOURCE_FITGIRL)
            and not self._fg_exhausted
            and (_should_query_fitgirl_in_all_mode(self.fitgirl_client) or self._source_filter == SOURCE_FITGIRL)
        )
        want_sr = (
            SOURCE_STEAMRIP in enabled
            and self._source_filter in ("all", SOURCE_STEAMRIP)
            and not self._sr_exhausted
            and (_should_query_steamrip_in_all_mode(self.steamrip_client) or self._source_filter == SOURCE_STEAMRIP)
        )
        return bool(want_of or want_ag or want_fg or want_sr)

    def _can_extend_category(self, category_slug: str) -> bool:
        if category_slug in ("discovery", "all", "other", INSTALLED_UPDATES_SLUG) or self._current_query:
            return False
        enabled = set(self._enabled_stores)
        can_ag = (
            SOURCE_ANKERGAMES in enabled
            and category_slug in ANKERGAMES_CATEGORY_PATHS
            and category_slug not in self._cat_ag_exhausted
            and self._source_filter in ("all", SOURCE_ANKERGAMES)
            and (_should_query_ankergames_in_all_mode(self.ankergames_client) or self._source_filter == SOURCE_ANKERGAMES)
            and _can_use_ag_category(self.ankergames_client)
        )
        can_sr = (
            SOURCE_STEAMRIP in enabled
            and category_slug in STEAMRIP_CATEGORY_WP_IDS
            and category_slug not in self._cat_sr_exhausted
            and self._source_filter in ("all", SOURCE_STEAMRIP)
            and (_should_query_steamrip_in_all_mode(self.steamrip_client) or self._source_filter == SOURCE_STEAMRIP)
            and _can_use_sr_category(self.steamrip_client)
        )
        can_fg = (
            SOURCE_FITGIRL in enabled
            and category_slug in FITGIRL_CATEGORY_SEARCH_TERMS
            and category_slug not in self._cat_fg_exhausted
            and self._source_filter in ("all", SOURCE_FITGIRL)
            and (_should_query_fitgirl_in_all_mode(self.fitgirl_client) or self._source_filter == SOURCE_FITGIRL)
            and _can_use_fg_category(self.fitgirl_client)
        )
        can_of = (
            SOURCE_ONLINE_FIX in enabled
            and category_slug == "coop"
            and self._source_filter in ("all", SOURCE_ONLINE_FIX)
            and not self._of_exhausted
        )
        return bool(can_ag or can_sr or can_fg or can_of)

    def _persist_catalog_snapshots(self):
        if self._current_query:
            return
        snapshots = [
            (src, list(lst))
            for src, lst in (
                (SOURCE_ONLINE_FIX, self._of_games),
                (SOURCE_ANKERGAMES, self._ag_games),
                (SOURCE_FITGIRL, self._fg_games),
                (SOURCE_STEAMRIP, self._sr_games),
            )
            if lst
        ]
        if not snapshots:
            return
        cat_path = self._catalog_cache_path

        def _save_all():
            for src, snap in snapshots:
                save_catalog_source_cache(src, snap, target_path=cat_path)

        threading.Thread(target=_save_all, daemon=True, name="save-catalog-pool").start()

    def _load_games(self, query: str, page: int = 1, force_network: bool = False):
        self._current_query, self._current_page = query, max(1, page)
        self._catalog_cache_path = get_catalog_cache_path()
        self._inflight_share_keys: set[str] = set()
        self.refresh_installed_games_state(render=False)
        self._request_id += 1
        request_id = self._request_id

        self._of_error = ""
        self._ag_error = ""
        self._fg_error = ""
        self._sr_error = ""
        self._queried_sources_count = 1
        self._completed_sources_count = 0
        self._of_done = False
        self._ag_done = False
        self._fg_done = False
        self._sr_done = False

        self._of_next_page = 2
        self._ag_next_page = 2
        self._fg_next_page = 2
        self._fg_next_batch = 1
        self._sr_next_page = 2
        self._sr_next_batch = 1
        self._of_exhausted = False
        self._ag_exhausted = False
        self._fg_exhausted = False
        self._sr_exhausted = False
        self._pool_loading = False
        self._wait_extend_page = False
        self._backfilling_slugs.clear()
        self._cat_tasks.clear()
        self._auto_prefetch_hops = 0
        self._shelf_limits.clear()
        if force_network or query:
            self._cat_ag_next_page.clear()
            self._cat_sr_next_page.clear()
            self._cat_fg_next_page.clear()
            self._cat_ag_exhausted.clear()
            self._cat_sr_exhausted.clear()
            self._cat_fg_exhausted.clear()

        enabled = set(self._enabled_stores)
        query_of = SOURCE_ONLINE_FIX in enabled
        query_ag = (
            SOURCE_ANKERGAMES in enabled
            and (_should_query_ankergames_in_all_mode(self.ankergames_client) or self._source_filter == SOURCE_ANKERGAMES)
        )
        query_fg = (
            SOURCE_FITGIRL in enabled
            and (_should_query_fitgirl_in_all_mode(self.fitgirl_client) or self._source_filter == SOURCE_FITGIRL)
        )
        query_sr = (
            SOURCE_STEAMRIP in enabled
            and (_should_query_steamrip_in_all_mode(self.steamrip_client) or self._source_filter == SOURCE_STEAMRIP)
        )
        self._queried_sources_count = (
            (1 if query_of else 0)
            + (1 if query_ag else 0)
            + (1 if query_fg else 0)
            + (1 if query_sr else 0)
        )
        self._completed_sources_count = 0

        # Hydrate full pooled catalog immediately from Documents\Bob Gaming\GameCenter\cache\store_catalog_cache.json
        hydrated = False
        if not query and self._current_page == 1 and not force_network:
            cached_sources = load_catalog_cache()
            if cached_sources:
                self._of_games = cached_sources.get(SOURCE_ONLINE_FIX, []) if query_of else []
                self._ag_games = cached_sources.get(SOURCE_ANKERGAMES, []) if query_ag else []
                self._fg_games = cached_sources.get(SOURCE_FITGIRL, []) if query_fg else []
                self._sr_games = cached_sources.get(SOURCE_STEAMRIP, []) if query_sr else []
                self._catalog_version += 1
                for g_list in (self._of_games, self._ag_games, self._fg_games, self._sr_games):
                    self._enricher.enqueue_games(g_list)
                hydrated = bool(self._of_games or self._ag_games or self._fg_games or self._sr_games)
                if hydrated:
                    logger.info(
                        f"{TAG} Instant disk-cache hydration: "
                        f"OF={len(self._of_games)}, AG={len(self._ag_games)}, FG={len(self._fg_games)}, SR={len(self._sr_games)}"
                    )

        if not hydrated:
            self._clear_views()
            self.scroll_area.verticalScrollBar().setValue(0)
            self.shelves_scroll.verticalScrollBar().setValue(0)
            self._of_games = []
            self._ag_games = []
            self._fg_games = []
            self._sr_games = []
            self._catalog_version += 1
            self._update_filter_buttons()

            what = f"từ khóa '{query}'" if query else "game mới phát hành"
            names_text = self._enabled_store_names_text()
            self.loading_title_lbl.setText(f"Đang tải trang {self._current_page} ({what})…")
            self.loading_sub_lbl.setText(
                f"Đang tải đa luồng từ {names_text} — cửa hàng nào xong trước hiện trước"
            )
            self.view_stack.hide()
            self.loading_box.show()
            self.center_spinner.start()
            self._set_status(f"Đang tải bất đồng bộ trang {self._current_page} ({what})…", "busy")

        self.inline_spinner.start()
        self.retry_btn.hide()
        self.page_info_label.setText(f"Trang {self._current_page}")
        self.prev_page_btn.setEnabled(False)
        self.next_page_btn.setEnabled(False)

        logger.info(
            f"{TAG} Starting async load page={self._current_page} query={query!r} "
            f"(Online-Fix={query_of}, AnkerGames={query_ag}, FitGirl={query_fg}, SteamRIP={query_sr}, hydrated={hydrated})"
        )

        if query_of:
            self._launch_online_fix_task(request_id, query, 1)
        else:
            self._of_loading = False
            self._of_done = True
            self._of_exhausted = True

        if query_ag:
            self._launch_ankergames_task(request_id, query, 1)
        else:
            self._ag_loading = False
            self._ag_done = True
            self._ag_exhausted = True

        if query_fg:
            self._launch_fitgirl_task(request_id, query, 1)
        else:
            self._fg_loading = False
            self._fg_done = True
            self._fg_exhausted = True

        if query_sr:
            self._launch_steamrip_task(request_id, query, 1)
        else:
            self._sr_loading = False
            self._sr_done = True
            self._sr_exhausted = True

        if hydrated or self._queried_sources_count == 0:
            self._update_filter_buttons()
            self._render_from_memory()

    def _launch_online_fix_task(self, request_id: int, query: str, page: int):
        self._of_loading = True
        self._of_done = False
        client = self.client
        started_at = time.monotonic()
        task = Task(
            lambda: client.search_games(query, page) if query else client.get_latest_games(page),
            f"list-of-{'search' if query else 'latest'}-p{page}",
            expected_errors=(OnlineFixError,),
        )
        task.done.connect(
            lambda games, err: self._on_source_loaded(
                request_id, SOURCE_ONLINE_FIX, query, page, started_at, games, err
            )
        )
        self._task_of = task
        task.start_tracked()

    def _launch_ankergames_task(self, request_id: int, query: str, page: int):
        self._ag_loading = True
        self._ag_done = False
        ag_client = self.ankergames_client
        started_at = time.monotonic()
        task = Task(
            lambda: ag_client.search_games(query, page) if query else ag_client.get_latest_games(page),
            f"list-ag-{'search' if query else 'latest'}-p{page}",
            expected_errors=(OnlineFixError,),
        )
        task.done.connect(
            lambda games, err: self._on_source_loaded(
                request_id, SOURCE_ANKERGAMES, query, page, started_at, games, err
            )
        )
        self._task_ag = task
        task.start_tracked()

    def _launch_fitgirl_task(self, request_id: int, query: str, page: int):
        self._fg_loading = True
        self._fg_done = False
        fg_client = self.fitgirl_client
        started_at = time.monotonic()
        task = Task(
            lambda: fg_client.search_games(query, page) if query else fg_client.get_latest_games(page),
            f"list-fg-{'search' if query else 'latest'}-p{page}",
            expected_errors=(OnlineFixError,),
        )
        task.done.connect(
            lambda games, err: self._on_source_loaded(
                request_id, SOURCE_FITGIRL, query, page, started_at, games, err
            )
        )
        self._task_fg = task
        task.start_tracked()

    def _launch_steamrip_task(self, request_id: int, query: str, page: int):
        self._sr_loading = True
        self._sr_done = False
        sr_client = self.steamrip_client
        started_at = time.monotonic()
        task = Task(
            lambda: sr_client.search_games(query, page) if query else sr_client.get_latest_games(page),
            f"list-sr-{'search' if query else 'latest'}-p{page}",
            expected_errors=(OnlineFixError,),
        )
        task.done.connect(
            lambda games, err: self._on_source_loaded(
                request_id, SOURCE_STEAMRIP, query, page, started_at, games, err
            )
        )
        self._task_sr = task
        task.start_tracked()

    @safe_slot
    def _on_source_loaded(
        self,
        request_id: int,
        source: str,
        query: str,
        page: int,
        started_at: float,
        games,
        error: str,
    ):
        if request_id != self._request_id:
            logger.debug(f"{TAG} Dropped stale {source} result for {query!r} page {page}")
            return
        if source not in self._enabled_stores:
            logger.debug(f"{TAG} Ignored result from disabled store {source} for {query!r} page {page}")
            return

        elapsed = time.monotonic() - started_at
        src_name = source_display_name(source)
        items = list(games or [])

        # Apply cached SteamGridDB/Steam metadata immediately & queue uncached titles on background worker pool
        if items:
            self._enricher.enqueue_games(items)

        if source == SOURCE_ONLINE_FIX:
            self._of_loading = False
            self._of_done = True
            self._of_error = error or ""
            self._of_exhausted = bool(error) or len(items) < 12
            self._of_next_page = page + 1
            if items:
                self._of_games = _merge_fresh_head(items, self._of_games) if (not query and page == 1) else items
                self._catalog_version += 1
            elif not error:
                self._of_games = []
                self._catalog_version += 1
        elif source == SOURCE_ANKERGAMES:
            self._ag_loading = False
            self._ag_done = True
            self._ag_error = error or ""
            self._ag_exhausted = bool(error) or len(items) < 12
            self._ag_next_page = page + 1
            if items:
                self._ag_games = _merge_fresh_head(items, self._ag_games) if (not query and page == 1) else items
                self._catalog_version += 1
            elif not error:
                self._ag_games = []
                self._catalog_version += 1
        elif source == SOURCE_FITGIRL:
            self._fg_loading = False
            self._fg_done = True
            self._fg_error = error or ""
            use_batch = not query and _can_use_fg_batch(self.fitgirl_client)
            self._fg_exhausted = bool(error) or (not use_batch and len(items) < FITGIRL_PAGE_SIZE)
            self._fg_next_page = page + 1
            if items:
                self._fg_games = _merge_fresh_head(items, self._fg_games) if (not query and page == 1) else items
                self._catalog_version += 1
            elif not error:
                self._fg_games = []
                self._catalog_version += 1
        else:
            self._sr_loading = False
            self._sr_done = True
            self._sr_error = error or ""
            use_batch = not query and _can_use_sr_batch(self.steamrip_client)
            self._sr_exhausted = bool(error) or (not use_batch and len(items) < STEAMRIP_PAGE_SIZE)
            self._sr_next_page = page + 1
            if items:
                self._sr_games = _merge_fresh_head(items, self._sr_games) if (not query and page == 1) else items
                self._catalog_version += 1
            elif not error:
                self._sr_games = []
                self._catalog_version += 1

        if not query and page == 1 and items and not error:
            cat_path = self._catalog_cache_path
            snapshot = list(
                self._of_games if source == SOURCE_ONLINE_FIX
                else self._ag_games if source == SOURCE_ANKERGAMES
                else self._fg_games if source == SOURCE_FITGIRL
                else self._sr_games
            )
            threading.Thread(
                target=save_catalog_source_cache,
                args=(source, snapshot, cat_path),
                daemon=True,
                name=f"save-catalog-{source}",
            ).start()

        self._completed_sources_count += 1
        done_idx = self._completed_sources_count
        total_q = max(self._queried_sources_count, done_idx)

        still_loading = [
            source_display_name(s)
            for s, flag in (
                (SOURCE_ONLINE_FIX, self._of_loading),
                (SOURCE_ANKERGAMES, self._ag_loading),
                (SOURCE_FITGIRL, self._fg_loading),
                (SOURCE_STEAMRIP, self._sr_loading),
            )
            if flag
        ]
        if error:
            logger.warning(
                f"{TAG} [Async {done_idx}/{total_q}] {src_name} failed on page {page} "
                f"(query={query!r}) in {elapsed:.2f}s: {error}"
            )
        elif still_loading:
            first_word = "finished first" if done_idx == 1 else "finished"
            logger.info(
                f"{TAG} [Async {done_idx}/{total_q}] {src_name} {first_word} for page {page} (query={query!r}): "
                f"{len(items)} game(s) in {elapsed:.2f}s — rendering immediately while waiting for {', '.join(still_loading)}"
            )
        else:
            logger.info(
                f"{TAG} [Async {done_idx}/{total_q}] {src_name} finished for page {page} (query={query!r}): "
                f"{len(items)} game(s) in {elapsed:.2f}s — all sources ready "
                f"(Online-Fix={len(self._of_games)}, AnkerGames={len(self._ag_games)}, FitGirl={len(self._fg_games)}, SteamRIP={len(self._sr_games)})"
            )
            if not query:
                self._maybe_start_wave2_pool(request_id)

        self._update_filter_buttons()
        self._render_from_memory()
        if not still_loading and not self._pool_loading:
            self._ensure_prefetch_buffer()

    # ------------------------------------------------------------ multi-page background pool & category backfill

    @staticmethod
    def _fetch_pages_throttled(fetch_fn, pages: list[int], max_workers: int = 2) -> list[tuple[int, list[OnlineFixGame]]]:
        if not pages:
            return []
        if len(pages) == 1:
            p = pages[0]
            try:
                return [(p, list(fetch_fn(p) or []))]
            except Exception:   # noqa: BLE001
                return [(p, [])]

        results: dict[int, list[OnlineFixGame]] = {}
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="store-pool") as pool:
            futs = {pool.submit(fetch_fn, p): p for p in pages}
            for fut, p in futs.items():
                try:
                    results[p] = list(fut.result() or [])
                except Exception:   # noqa: BLE001
                    results[p] = []
        return [(p, results.get(p, [])) for p in pages]

    def _maybe_start_wave2_pool(self, request_id: int):
        """Wave 2: after page 1 paints, quietly pool ~350-450 games across pages 1..5 in background."""
        if self._pool_loading or self._current_query:
            return
        enabled = set(self._enabled_stores)
        query_ag = (
            SOURCE_ANKERGAMES in enabled
            and (_should_query_ankergames_in_all_mode(self.ankergames_client) or self._source_filter == SOURCE_ANKERGAMES)
        )
        query_fg = (
            SOURCE_FITGIRL in enabled
            and (_should_query_fitgirl_in_all_mode(self.fitgirl_client) or self._source_filter == SOURCE_FITGIRL)
        )
        query_sr = (
            SOURCE_STEAMRIP in enabled
            and (_should_query_steamrip_in_all_mode(self.steamrip_client) or self._source_filter == SOURCE_STEAMRIP)
        )

        want_of = SOURCE_ONLINE_FIX in enabled and not self._of_exhausted
        want_ag = query_ag and not self._ag_exhausted
        want_fg = query_fg and not self._fg_exhausted
        want_sr = query_sr and not self._sr_exhausted
        if not (want_of or want_ag or want_fg or want_sr):
            return

        of_client = self.client
        ag_client = self.ankergames_client
        fg_client = self.fitgirl_client
        sr_client = self.steamrip_client
        fg_batch_mode = _can_use_fg_batch(fg_client)
        sr_batch_mode = _can_use_sr_batch(sr_client)
        of_pages = list(range(2, INITIAL_POOL_PAGES + 1)) if want_of else []
        ag_pages = list(range(2, INITIAL_POOL_PAGES + 1)) if want_ag else []
        fg_pages = list(range(2, INITIAL_POOL_PAGES + 1)) if (want_fg and not fg_batch_mode) else []
        sr_pages = list(range(2, INITIAL_POOL_PAGES + 1)) if (want_sr and not sr_batch_mode) else []

        self._pool_loading = True
        started = time.monotonic()

        def _work():
            out: dict = {}
            with ThreadPoolExecutor(max_workers=4, thread_name_prefix="wave2-src") as src_pool:
                f_of = (
                    src_pool.submit(self._fetch_pages_throttled, of_client.get_latest_games, of_pages, 2)
                    if of_pages else None
                )
                f_ag = (
                    src_pool.submit(self._fetch_pages_throttled, ag_client.get_latest_games, ag_pages, 2)
                    if ag_pages else None
                )
                if want_fg:
                    if fg_batch_mode:
                        f_fg = src_pool.submit(fg_client.get_latest_games_batch, 1, FITGIRL_BATCH_SIZE)
                    else:
                        f_fg = src_pool.submit(self._fetch_pages_throttled, fg_client.get_latest_games, fg_pages, 2)
                else:
                    f_fg = None

                if want_sr:
                    if sr_batch_mode:
                        f_sr = src_pool.submit(
                            self._fetch_pages_throttled,
                            lambda b: sr_client.get_latest_games(b, per_page=STEAMRIP_BATCH_SIZE),
                            [1, 2],
                            2,
                        )
                    else:
                        f_sr = src_pool.submit(self._fetch_pages_throttled, sr_client.get_latest_games, sr_pages, 2)
                else:
                    f_sr = None

                if f_of is not None:
                    out["of_pages"] = f_of.result()
                if f_ag is not None:
                    out["ag_pages"] = f_ag.result()
                if f_fg is not None:
                    try:
                        out["fg"] = f_fg.result()
                    except Exception:   # noqa: BLE001
                        out["fg"] = []
                if f_sr is not None:
                    out["sr"] = f_sr.result()
            out["fg_batch_mode"] = fg_batch_mode
            out["sr_batch_mode"] = sr_batch_mode
            out["elapsed"] = time.monotonic() - started
            return out

        task = Task(_work, "pool-wave2", expected_errors=(OnlineFixError,))
        task.done.connect(lambda res, err: self._on_wave2_pool_done(request_id, res, err))
        self._task_pool = task
        task.start_tracked()

    @safe_slot
    def _on_wave2_pool_done(self, request_id: int, res, error: str):
        if request_id != self._request_id:
            return
        self._pool_loading = False
        if error or not isinstance(res, dict):
            self._render_from_memory()
            return

        new_for_enrich: list[OnlineFixGame] = []
        changed = False

        if "of_pages" in res:
            of_batch: list[OnlineFixGame] = []
            exh = False
            for p, p_items in res["of_pages"]:
                self._of_next_page = max(self._of_next_page, p + 1)
                if len(p_items) < 12:
                    exh = True
                of_batch.extend(p_items)
            self._of_exhausted = exh
            if of_batch:
                self._of_games, added = _merge_unique_games(self._of_games, of_batch)
                if added:
                    new_for_enrich.extend(of_batch)
                    changed = True

        if "ag_pages" in res:
            ag_batch: list[OnlineFixGame] = []
            exh = False
            for p, p_items in res["ag_pages"]:
                self._ag_next_page = max(self._ag_next_page, p + 1)
                if len(p_items) < 12:
                    exh = True
                ag_batch.extend(p_items)
            self._ag_exhausted = exh
            if ag_batch:
                self._ag_games, added = _merge_unique_games(self._ag_games, ag_batch)
                if added:
                    new_for_enrich.extend(ag_batch)
                    changed = True

        if "fg" in res:
            if res.get("fg_batch_mode"):
                fg_items = list(res["fg"] or [])
                self._fg_next_batch = 2
                self._fg_next_page = INITIAL_POOL_PAGES + 1
                self._fg_exhausted = len(fg_items) < (FITGIRL_BATCH_SIZE // 2)
            else:
                fg_items = []
                exh = False
                for p, p_items in (res["fg"] or []):
                    self._fg_next_page = max(self._fg_next_page, p + 1)
                    if len(p_items) < FITGIRL_PAGE_SIZE:
                        exh = True
                    fg_items.extend(p_items)
                self._fg_exhausted = exh
            if fg_items:
                self._fg_games, added = _merge_unique_games(self._fg_games, fg_items)
                if added:
                    new_for_enrich.extend(fg_items)
                    changed = True

        if "sr" in res:
            sr_items: list[OnlineFixGame] = []
            if res.get("sr_batch_mode"):
                exh = False
                for b, b_items in (res["sr"] or []):
                    self._sr_next_batch = max(self._sr_next_batch, b + 1)
                    if len(b_items) < (STEAMRIP_BATCH_SIZE // 2):
                        exh = True
                    sr_items.extend(b_items)
                self._sr_next_page = (self._sr_next_batch - 1) * 8 + 1
                self._sr_exhausted = exh
            else:
                exh = False
                for p, p_items in (res["sr"] or []):
                    self._sr_next_page = max(self._sr_next_page, p + 1)
                    if len(p_items) < STEAMRIP_PAGE_SIZE:
                        exh = True
                    sr_items.extend(p_items)
                self._sr_exhausted = exh
            if sr_items:
                self._sr_games, added = _merge_unique_games(self._sr_games, sr_items)
                if added:
                    new_for_enrich.extend(sr_items)
                    changed = True

        if changed:
            self._catalog_version += 1
            self._enricher.enqueue_games(new_for_enrich)
            self._persist_catalog_snapshots()
            logger.info(
                f"{TAG} Multi-page pool ready in {res.get('elapsed', 0.0):.2f}s: "
                f"Online-Fix={len(self._of_games)}, AnkerGames={len(self._ag_games)}, FitGirl={len(self._fg_games)}, SteamRIP={len(self._sr_games)}"
            )

        self._update_filter_buttons()
        self._render_from_memory()
        self._ensure_prefetch_buffer()

    def _extend_pool_async(self, wait_for_page: bool = False, force_attempt: bool = False):
        """Fetch the next +3 pages (or +2 search pages) per active source before items run out."""
        if self._pool_loading:
            if wait_for_page:
                self._wait_extend_page = True
                self._render_from_memory()
            return

        request_id = self._request_id
        query = self._current_query
        enabled = set(self._enabled_stores)
        query_ag = (
            SOURCE_ANKERGAMES in enabled
            and (_should_query_ankergames_in_all_mode(self.ankergames_client) or self._source_filter == SOURCE_ANKERGAMES)
        )
        query_fg = (
            SOURCE_FITGIRL in enabled
            and (_should_query_fitgirl_in_all_mode(self.fitgirl_client) or self._source_filter == SOURCE_FITGIRL)
        )
        query_sr = (
            SOURCE_STEAMRIP in enabled
            and (_should_query_steamrip_in_all_mode(self.steamrip_client) or self._source_filter == SOURCE_STEAMRIP)
        )

        do_of = (
            SOURCE_ONLINE_FIX in enabled
            and self._source_filter in ("all", SOURCE_ONLINE_FIX)
            and (not self._of_exhausted or force_attempt)
        )
        do_ag = (
            self._source_filter in ("all", SOURCE_ANKERGAMES)
            and query_ag
            and (not self._ag_exhausted or force_attempt)
        )
        do_fg = (
            self._source_filter in ("all", SOURCE_FITGIRL)
            and query_fg
            and (not self._fg_exhausted or force_attempt)
        )
        do_sr = (
            self._source_filter in ("all", SOURCE_STEAMRIP)
            and query_sr
            and (not self._sr_exhausted or force_attempt)
        )
        if not (do_of or do_ag or do_fg or do_sr):
            self._wait_extend_page = False
            self._render_from_memory()
            return

        of_client = self.client
        ag_client = self.ankergames_client
        fg_client = self.fitgirl_client
        sr_client = self.steamrip_client
        fg_batch_mode = not query and _can_use_fg_batch(fg_client)
        sr_batch_mode = not query and _can_use_sr_batch(sr_client)

        of_n = 1 if (force_attempt and self._of_exhausted) else (SEARCH_PREFETCH_PAGES if query else EXTEND_BATCH_PAGES)
        of_pages = list(range(self._of_next_page, self._of_next_page + of_n)) if do_of else []
        ag_n = 1 if (force_attempt and self._ag_exhausted) else (SEARCH_PREFETCH_PAGES if query else EXTEND_BATCH_PAGES)
        ag_pages = list(range(self._ag_next_page, self._ag_next_page + ag_n)) if do_ag else []
        fg_batch_idx = self._fg_next_batch
        fg_n = 1 if (force_attempt and self._fg_exhausted) else (SEARCH_PREFETCH_PAGES if query else EXTEND_BATCH_PAGES)
        fg_pages = list(range(self._fg_next_page, self._fg_next_page + fg_n)) if (do_fg and not fg_batch_mode) else []
        sr_batch_idx = self._sr_next_batch
        sr_n = 1 if (force_attempt and self._sr_exhausted) else (SEARCH_PREFETCH_PAGES if query else EXTEND_BATCH_PAGES)
        sr_pages = list(range(self._sr_next_page, self._sr_next_page + sr_n)) if (do_sr and not sr_batch_mode) else []

        self._pool_loading = True
        self._wait_extend_page = wait_for_page
        self._render_from_memory()
        started = time.monotonic()

        def _work():
            out: dict = {"fg_batch_mode": fg_batch_mode, "sr_batch_mode": sr_batch_mode}
            with ThreadPoolExecutor(max_workers=4, thread_name_prefix="extend-src") as src_pool:
                f_of = (
                    src_pool.submit(
                        self._fetch_pages_throttled,
                        (lambda p: of_client.search_games(query, p)) if query else of_client.get_latest_games,
                        of_pages,
                        2,
                    )
                    if of_pages else None
                )
                f_ag = (
                    src_pool.submit(
                        self._fetch_pages_throttled,
                        (lambda p: ag_client.search_games(query, p)) if query else ag_client.get_latest_games,
                        ag_pages,
                        2,
                    )
                    if ag_pages else None
                )
                if do_fg:
                    if fg_batch_mode:
                        f_fg = src_pool.submit(fg_client.get_latest_games_batch, fg_batch_idx, FITGIRL_BATCH_SIZE)
                    else:
                        f_fg = src_pool.submit(
                            self._fetch_pages_throttled,
                            (lambda p: fg_client.search_games(query, p)) if query else fg_client.get_latest_games,
                            fg_pages,
                            2,
                        )
                else:
                    f_fg = None

                if do_sr:
                    if sr_batch_mode:
                        f_sr = src_pool.submit(
                            self._fetch_pages_throttled,
                            lambda b: sr_client.get_latest_games(b, per_page=STEAMRIP_BATCH_SIZE),
                            [sr_batch_idx],
                            1,
                        )
                    else:
                        f_sr = src_pool.submit(
                            self._fetch_pages_throttled,
                            (lambda p: sr_client.search_games(query, p)) if query else sr_client.get_latest_games,
                            sr_pages,
                            2,
                        )
                else:
                    f_sr = None

                if f_of is not None:
                    out["of_pages"] = f_of.result()
                if f_ag is not None:
                    out["ag_pages"] = f_ag.result()
                if f_fg is not None:
                    try:
                        out["fg"] = f_fg.result()
                    except Exception:   # noqa: BLE001
                        out["fg"] = []
                if f_sr is not None:
                    out["sr"] = f_sr.result()
            out["elapsed"] = time.monotonic() - started
            return out

        task = Task(_work, f"pool-extend-p{self._current_page}", expected_errors=(OnlineFixError,))
        task.done.connect(lambda res, err: self._on_extend_pool_done(request_id, res, err))
        self._task_pool = task
        task.start_tracked()

    @safe_slot
    def _on_extend_pool_done(self, request_id: int, res, error: str):
        if request_id != self._request_id:
            return
        self._pool_loading = False
        self._wait_extend_page = False

        if not error and isinstance(res, dict):
            new_for_enrich: list[OnlineFixGame] = []
            total_added = 0

            if "of_pages" in res:
                of_batch: list[OnlineFixGame] = []
                exh = False
                for p, p_items in res["of_pages"]:
                    self._of_next_page = max(self._of_next_page, p + 1)
                    if len(p_items) < 12:
                        exh = True
                    of_batch.extend(p_items)
                self._of_games, added = _merge_unique_games(self._of_games, of_batch)
                self._of_exhausted = exh or added == 0
                if added:
                    new_for_enrich.extend(of_batch)
                    total_added += added

            if "ag_pages" in res:
                ag_batch: list[OnlineFixGame] = []
                exh = False
                for p, p_items in res["ag_pages"]:
                    self._ag_next_page = max(self._ag_next_page, p + 1)
                    if len(p_items) < 12:
                        exh = True
                    ag_batch.extend(p_items)
                self._ag_games, added = _merge_unique_games(self._ag_games, ag_batch)
                self._ag_exhausted = exh or added == 0
                if added:
                    new_for_enrich.extend(ag_batch)
                    total_added += added

            if "fg" in res:
                if res.get("fg_batch_mode"):
                    fg_items = list(res["fg"] or [])
                    self._fg_next_batch += 1
                    self._fg_next_page += 5
                    exh = len(fg_items) < (FITGIRL_BATCH_SIZE // 2)
                else:
                    fg_items = []
                    exh = False
                    for p, p_items in (res["fg"] or []):
                        self._fg_next_page = max(self._fg_next_page, p + 1)
                        if len(p_items) < FITGIRL_PAGE_SIZE:
                            exh = True
                        fg_items.extend(p_items)
                self._fg_games, added = _merge_unique_games(self._fg_games, fg_items)
                self._fg_exhausted = exh or added == 0
                if added:
                    new_for_enrich.extend(fg_items)
                    total_added += added

            if "sr" in res:
                sr_items: list[OnlineFixGame] = []
                if res.get("sr_batch_mode"):
                    exh = False
                    for b, b_items in (res["sr"] or []):
                        self._sr_next_batch = max(self._sr_next_batch, b + 1)
                        if len(b_items) < (STEAMRIP_BATCH_SIZE // 2):
                            exh = True
                        sr_items.extend(b_items)
                else:
                    exh = False
                    for p, p_items in (res["sr"] or []):
                        self._sr_next_page = max(self._sr_next_page, p + 1)
                        if len(p_items) < STEAMRIP_PAGE_SIZE:
                            exh = True
                        sr_items.extend(p_items)
                self._sr_games, added = _merge_unique_games(self._sr_games, sr_items)
                self._sr_exhausted = exh or added == 0
                if added:
                    new_for_enrich.extend(sr_items)
                    total_added += added

            if total_added:
                self._catalog_version += 1
                self._enricher.enqueue_games(new_for_enrich)
                self._persist_catalog_snapshots()
                logger.info(
                    f"{TAG} Extended catalog pool (+{total_added} new games) in {res.get('elapsed', 0.0):.2f}s"
                )

        self._update_filter_buttons()
        self._render_from_memory()
        self._ensure_prefetch_buffer()

    def _prefetch_category_async(self, category_slug: str, wait_for_page: bool = False) -> bool:
        """Fetch the next page of category-specific archives for `category_slug` in background."""
        if category_slug in ("discovery", "all", "other", INSTALLED_UPDATES_SLUG) or self._current_query:
            return False
        if category_slug in self._backfilling_slugs:
            if wait_for_page:
                self._wait_extend_page = True
                self._render_from_memory()
            return True

        enabled = set(self._enabled_stores)
        do_ag = (
            SOURCE_ANKERGAMES in enabled
            and category_slug in ANKERGAMES_CATEGORY_PATHS
            and category_slug not in self._cat_ag_exhausted
            and self._source_filter in ("all", SOURCE_ANKERGAMES)
            and (_should_query_ankergames_in_all_mode(self.ankergames_client) or self._source_filter == SOURCE_ANKERGAMES)
            and _can_use_ag_category(self.ankergames_client)
        )
        do_sr = (
            SOURCE_STEAMRIP in enabled
            and category_slug in STEAMRIP_CATEGORY_WP_IDS
            and category_slug not in self._cat_sr_exhausted
            and self._source_filter in ("all", SOURCE_STEAMRIP)
            and (_should_query_steamrip_in_all_mode(self.steamrip_client) or self._source_filter == SOURCE_STEAMRIP)
            and _can_use_sr_category(self.steamrip_client)
        )
        do_fg = (
            SOURCE_FITGIRL in enabled
            and category_slug in FITGIRL_CATEGORY_SEARCH_TERMS
            and category_slug not in self._cat_fg_exhausted
            and self._source_filter in ("all", SOURCE_FITGIRL)
            and (_should_query_fitgirl_in_all_mode(self.fitgirl_client) or self._source_filter == SOURCE_FITGIRL)
            and _can_use_fg_category(self.fitgirl_client)
        )
        do_of = (
            SOURCE_ONLINE_FIX in enabled
            and category_slug == "coop"
            and self._source_filter in ("all", SOURCE_ONLINE_FIX)
            and not self._of_exhausted
            and not self._of_loading
            and not self._pool_loading
        )
        if not (do_ag or do_sr or do_fg or do_of):
            return False

        ag_page = self._cat_ag_next_page.get(category_slug, 1)
        sr_page = self._cat_sr_next_page.get(category_slug, 1)
        fg_page = self._cat_fg_next_page.get(category_slug, 1)
        self._backfilling_slugs.add(category_slug)
        if wait_for_page:
            self._wait_extend_page = True
        request_id = self._request_id
        ag_client = self.ankergames_client
        sr_client = self.steamrip_client
        fg_client = self.fitgirl_client
        of_client = self.client
        of_pages = [self._of_next_page, self._of_next_page + 1] if do_of else []
        self._render_from_memory()
        started = time.monotonic()

        def _work():
            out: dict = {"ag_page": ag_page, "sr_page": sr_page, "fg_page": fg_page}
            with ThreadPoolExecutor(max_workers=4, thread_name_prefix="cat-backfill") as pool:
                f_ag = (
                    pool.submit(ag_client.get_category_games, category_slug, ag_page)
                    if do_ag else None
                )
                f_sr = (
                    pool.submit(sr_client.get_category_games, category_slug, sr_page, SR_CATEGORY_BATCH_SIZE)
                    if do_sr else None
                )
                f_fg = (
                    pool.submit(fg_client.get_category_games, category_slug, fg_page, FG_CATEGORY_BATCH_SIZE)
                    if do_fg else None
                )
                f_of = (
                    pool.submit(self._fetch_pages_throttled, of_client.get_latest_games, of_pages, 2)
                    if of_pages else None
                )
                if f_ag is not None:
                    try:
                        out["ag"] = list(f_ag.result() or [])
                    except Exception:   # noqa: BLE001
                        out["ag"] = []
                if f_sr is not None:
                    try:
                        out["sr"] = list(f_sr.result() or [])
                    except Exception:   # noqa: BLE001
                        out["sr"] = []
                if f_fg is not None:
                    try:
                        out["fg"] = list(f_fg.result() or [])
                    except Exception:   # noqa: BLE001
                        out["fg"] = []
                if f_of is not None:
                    out["of_pages"] = f_of.result()
            out["elapsed"] = time.monotonic() - started
            return out

        task = Task(_work, f"backfill-cat-{category_slug}-p{max(ag_page, sr_page, fg_page)}", expected_errors=(OnlineFixError,))
        task.done.connect(lambda res, err: self._on_category_backfilled(request_id, category_slug, res, err))
        self._cat_tasks[category_slug] = task
        task.start_tracked()
        return True

    @safe_slot
    def _on_category_backfilled(self, request_id: int, category_slug: str, res, error: str):
        self._backfilling_slugs.discard(category_slug)
        self._cat_tasks.pop(category_slug, None)
        if request_id != self._request_id:
            return
        if self._category_filter == category_slug and not self._pool_loading:
            self._wait_extend_page = False

        if error or not isinstance(res, dict):
            self._cat_ag_exhausted.add(category_slug)
            self._cat_sr_exhausted.add(category_slug)
            self._cat_fg_exhausted.add(category_slug)
        else:
            new_for_enrich: list[OnlineFixGame] = []
            added_total = 0

            if "ag" in res:
                ag_items = list(res["ag"] or [])
                ag_page = int(res.get("ag_page") or 1)
                self._cat_ag_next_page[category_slug] = ag_page + 1
                ag_added = 0
                if ag_items:
                    self._ag_games, ag_added = _merge_unique_games(self._ag_games, ag_items)
                    if ag_added:
                        new_for_enrich.extend(ag_items)
                        added_total += ag_added
                if len(ag_items) < ANKERGAMES_PAGE_SIZE or (ag_added == 0 and ag_page >= 3):
                    self._cat_ag_exhausted.add(category_slug)

            if "sr" in res:
                sr_items = list(res["sr"] or [])
                sr_page = int(res.get("sr_page") or 1)
                self._cat_sr_next_page[category_slug] = sr_page + 1
                sr_added = 0
                if sr_items:
                    self._sr_games, sr_added = _merge_unique_games(self._sr_games, sr_items)
                    if sr_added:
                        new_for_enrich.extend(sr_items)
                        added_total += sr_added
                if len(sr_items) < SR_CATEGORY_BATCH_SIZE or (sr_added == 0 and sr_page >= 3):
                    self._cat_sr_exhausted.add(category_slug)

            if "fg" in res:
                fg_items = list(res["fg"] or [])
                fg_page = int(res.get("fg_page") or 1)
                self._cat_fg_next_page[category_slug] = fg_page + 1
                fg_added = 0
                if fg_items:
                    self._fg_games, fg_added = _merge_unique_games(self._fg_games, fg_items)
                    if fg_added:
                        new_for_enrich.extend(fg_items)
                        added_total += fg_added
                if len(fg_items) < FG_CATEGORY_BATCH_SIZE or (fg_added == 0 and fg_page >= 3):
                    self._cat_fg_exhausted.add(category_slug)

            if "of_pages" in res:
                of_items: list[OnlineFixGame] = []
                for p, p_items in res["of_pages"]:
                    self._of_next_page = max(self._of_next_page, p + 1)
                    if len(p_items) < 12:
                        self._of_exhausted = True
                    of_items.extend(p_items)
                of_added = 0
                if of_items:
                    self._of_games, of_added = _merge_unique_games(self._of_games, of_items)
                    if of_added:
                        new_for_enrich.extend(of_items)
                        added_total += of_added
                if of_added == 0:
                    self._of_exhausted = True

            if added_total:
                self._catalog_version += 1
                self._enricher.enqueue_games(new_for_enrich)
                self._persist_catalog_snapshots()
                logger.info(
                    f"{TAG} Category {category_slug!r} backfill added +{added_total} games "
                    f"in {res.get('elapsed', 0.0):.2f}s"
                )

        self._update_filter_buttons()
        self._render_from_memory()
        self._ensure_prefetch_buffer()

    def _ensure_prefetch_buffer(self):
        """Proactively prefetch in background whenever <= PREFETCH_AHEAD_PAGES (<=48 items) remain ahead."""
        if self._of_loading or self._ag_loading or self._fg_loading or self._sr_loading:
            return
        if self._auto_prefetch_hops >= MAX_AUTO_PREFETCH_HOPS:
            return

        low_watermark = PREFETCH_AHEAD_PAGES * UI_PAGE_SIZE

        if self._is_shelf_mode_active():
            if len(self._source_filtered_games()) < (low_watermark + UI_PAGE_SIZE):
                if not self._pool_loading and self._can_extend_active_sources():
                    self._auto_prefetch_hops += 1
                    logger.info(f"{TAG} Low-watermark prefetch in shelf mode (source={self._source_filter!r})")
                    self._extend_pool_async(wait_for_page=False)
            return

        all_filtered = self._current_filtered_games()
        remaining_ahead = len(all_filtered) - (self._current_page * UI_PAGE_SIZE)
        if remaining_ahead > low_watermark:
            return

        cat = self._category_filter
        if not self._current_query and cat not in ("discovery", "all", "other", INSTALLED_UPDATES_SLUG):
            if cat in self._backfilling_slugs:
                return
            if self._can_extend_category(cat):
                self._auto_prefetch_hops += 1
                logger.info(
                    f"{TAG} Low-watermark prefetch for category {cat!r} "
                    f"(page={self._current_page}, remaining_ahead={max(0, remaining_ahead)})"
                )
                self._prefetch_category_async(cat, wait_for_page=False)
                return

        if not self._pool_loading and self._can_extend_active_sources():
            self._auto_prefetch_hops += 1
            logger.info(
                f"{TAG} Low-watermark pool prefetch (source={self._source_filter!r}, "
                f"cat={cat!r}, query={self._current_query!r}, page={self._current_page}, "
                f"remaining_ahead={max(0, remaining_ahead)})"
            )
            self._extend_pool_async(wait_for_page=False)

    @safe_slot
    def _on_shelf_near_end(self, category_slug: str):
        base_games = self._source_filtered_games()
        if category_slug == "all":
            avail = base_games
            default_lim = 16
        elif category_slug == INSTALLED_UPDATES_SLUG:
            avail = find_installed_game_updates(base_games, self._installed_ts_map)
            default_lim = SHELF_INITIAL_LIMIT
        else:
            avail = [g for g in base_games if category_slug in (g.categories or classify_game_categories(g))]
            default_lim = SHELF_INITIAL_LIMIT

        cur_lim = self._shelf_limits.get(category_slug, default_lim)
        new_lim = cur_lim
        if len(avail) > cur_lim:
            new_lim = cur_lim + SHELF_STEP_LIMIT
            self._shelf_limits[category_slug] = new_lim
            self._sync_shelves(base_games)

        if len(avail) - new_lim <= SHELF_STEP_LIMIT and not self._current_query:
            self._auto_prefetch_hops = 0
            if category_slug not in ("all", "discovery", "other", INSTALLED_UPDATES_SLUG) and self._can_extend_category(category_slug):
                logger.info(f"{TAG} Shelf {category_slug!r} scrolled near end — prefetching next category batch")
                self._prefetch_category_async(category_slug, wait_for_page=False)
            elif not self._pool_loading and self._can_extend_active_sources():
                logger.info(f"{TAG} Shelf {category_slug!r} scrolled near end — extending catalog pool")
                self._extend_pool_async(wait_for_page=False)

    # ------------------------------------------------------------ live enrichment callbacks

    @safe_slot
    def _on_game_enriched(self, norm_key: str, meta: dict):
        poster_2x3 = str(meta.get("poster_2x3_url") or "").strip()
        if poster_2x3 and self._posters.has_failed(poster_2x3):
            poster_2x3 = ""
        genres = meta.get("genres") or ()
        steam_cats = meta.get("steam_categories") or ()

        changed_cat = False
        changed_any = False
        for g_list in (self._of_games, self._ag_games, self._fg_games, self._sr_games):
            for g in g_list:
                if normalize_game_cache_key(g.title) != norm_key:
                    continue
                if not g.provider_poster_url and g.poster_url:
                    g.provider_poster_url = g.poster_url
                target_poster = poster_2x3 or g.provider_poster_url or g.poster_url
                if target_poster and g.poster_url != target_poster:
                    g.poster_url = target_poster
                    changed_any = True
                new_cats = classify_game_categories(g, extra_genres=genres, extra_categories=steam_cats)
                if new_cats != g.categories:
                    g.categories = new_cats
                    changed_cat = True
                    changed_any = True

        if changed_any:
            self._catalog_version += 1

        # Update existing card widgets in-place immediately (zero layout tear-down)
        live_cards = [c for c in self._cards_by_key.get(norm_key, []) if isValid(c)]
        if norm_key in self._cards_by_key:
            self._cards_by_key[norm_key] = live_cards
        for card in live_cards:
            if poster_2x3:
                card.game.poster_url = poster_2x3
            extra_card_cats = classify_game_categories(card.game, extra_genres=genres, extra_categories=steam_cats)
            for c in extra_card_cats:
                if c not in card.game.categories:
                    card.game.categories.append(c)
            if len(card.game.categories) > 1 and "other" in card.game.categories:
                card.game.categories = [c for c in card.game.categories if c != "other"]
            card.refresh_meta_labels()
            card_url = poster_2x3 or card.game.provider_poster_url or card.game.poster_url
            if card_url and card._applied_poster_url != card_url:
                pix = self._posters.card_pixmap(card_url)
                if pix is not None:
                    card.set_poster_pixmap(pix, card_url)
                elif not self._posters.has_failed(card_url):
                    waiters = self._cards.setdefault(card_url, [])
                    if card not in waiters:
                        waiters.append(card)
                    self._posters.request(card_url)

        if changed_cat and not self._dialog_open:
            self._rebucket_timer.start()

    @safe_slot
    def _on_rebucket_timeout(self):
        self._rebucket_timer.stop()
        if self._dialog_open or QApplication.mouseButtons() != Qt.MouseButton.NoButton:
            self._rebucket_timer.start()
            return
        self._render_from_memory()
        self._persist_catalog_snapshots()

    # ------------------------------------------------------------ rendering (Shelves + Client-Side 24/page Grid)

    def _get_cached_source_games(self, source_filter: str) -> list[OnlineFixGame]:
        if self._source_cache is None or self._source_cache[0] != self._catalog_version:
            self._source_cache = (self._catalog_version, {})
        bucket = self._source_cache[1]
        cached = bucket.get(source_filter)
        if cached is not None:
            return cached
        enabled = set(self._enabled_stores)
        of_pool = self._of_games if SOURCE_ONLINE_FIX in enabled else []
        fg_pool = self._fg_games if SOURCE_FITGIRL in enabled else []
        sr_pool = self._sr_games if SOURCE_STEAMRIP in enabled else []
        ag_pool = self._ag_games if SOURCE_ANKERGAMES in enabled else []
        if source_filter == SOURCE_ONLINE_FIX:
            res = attach_store_providers(of_pool, of_pool, fg_pool, sr_pool, ag_pool)
        elif source_filter == SOURCE_ANKERGAMES:
            res = attach_store_providers(ag_pool, of_pool, fg_pool, sr_pool, ag_pool)
        elif source_filter == SOURCE_FITGIRL:
            res = attach_store_providers(fg_pool, of_pool, fg_pool, sr_pool, ag_pool)
        elif source_filter == SOURCE_STEAMRIP:
            res = attach_store_providers(sr_pool, of_pool, fg_pool, sr_pool, ag_pool)
        else:
            res = interleave_games(of_pool, fg_pool, sr_pool, ag_pool)
        if self._current_query:
            res = [g for g in res if matches_search_query(self._current_query, g.title, g.url)]
            res = sort_games_for_search(self._current_query, res)
        bucket[source_filter] = res
        return res

    def _source_filtered_games(self) -> list[OnlineFixGame]:
        return list(self._get_cached_source_games(self._source_filter))

    def _current_filtered_games(self) -> list[OnlineFixGame]:
        base = self._source_filtered_games()
        if self._category_filter in ("discovery", "all"):
            return base
        if self._category_filter == INSTALLED_UPDATES_SLUG:
            return find_installed_game_updates(base, self._installed_ts_map)
        return [
            g for g in base
            if self._category_filter in (g.categories or classify_game_categories(g))
        ]

    def _render_from_memory(self):
        query = self._current_query
        wave1_loading = self._of_loading or self._ag_loading or self._fg_loading or self._sr_loading
        any_loading = wave1_loading or self._pool_loading or self._category_backfilling

        if self._source_filter == SOURCE_ONLINE_FIX:
            filter_loading = self._of_loading
            filter_err = self._of_error
        elif self._source_filter == SOURCE_ANKERGAMES:
            filter_loading = self._ag_loading
            filter_err = self._ag_error
        elif self._source_filter == SOURCE_FITGIRL:
            filter_loading = self._fg_loading
            filter_err = self._fg_error
        elif self._source_filter == SOURCE_STEAMRIP:
            filter_loading = self._sr_loading
            filter_err = self._sr_error
        else:
            enabled = set(self._enabled_stores)
            active_loading = [
                flag
                for src, flag in (
                    (SOURCE_ONLINE_FIX, self._of_loading),
                    (SOURCE_ANKERGAMES, self._ag_loading),
                    (SOURCE_FITGIRL, self._fg_loading),
                    (SOURCE_STEAMRIP, self._sr_loading),
                )
                if src in enabled
            ]
            filter_loading = bool(active_loading) and all(active_loading)
            errors = [
                err
                for src, err in (
                    (SOURCE_ONLINE_FIX, self._of_error),
                    (SOURCE_ANKERGAMES, self._ag_error),
                    (SOURCE_FITGIRL, self._fg_error),
                    (SOURCE_STEAMRIP, self._sr_error),
                )
                if src in enabled and err
            ]
            has_any_games = bool(
                (SOURCE_ONLINE_FIX in enabled and self._of_games)
                or (SOURCE_ANKERGAMES in enabled and self._ag_games)
                or (SOURCE_FITGIRL in enabled and self._fg_games)
                or (SOURCE_STEAMRIP in enabled and self._sr_games)
            )
            filter_err = errors[0] if (errors and not has_any_games and not any_loading) else ""

        base_games = self._source_filtered_games()
        self._update_category_chips(base_games)
        all_filtered = self._current_filtered_games()
        total_matching = len(all_filtered)
        total_ui_pages = max(1, (total_matching + UI_PAGE_SIZE - 1) // UI_PAGE_SIZE)

        if self._wait_extend_page and (self._pool_loading or self._category_backfilling):
            self._sync_grid([])
            self.loading_title_lbl.setText(f"Đang tải nối thêm trang {self._current_page}…")
            self.view_stack.hide()
            self.loading_box.show()
            self.center_spinner.start()
            self.inline_spinner.start()
            self.prev_page_btn.setEnabled(False)
            self.next_page_btn.setEnabled(False)
            return

        if total_matching and self._current_page > total_ui_pages:
            self._current_page = total_ui_pages
        page = self._current_page
        start = (page - 1) * UI_PAGE_SIZE
        page_games = all_filtered[start : start + UI_PAGE_SIZE]

        if not base_games and (filter_loading or (any_loading and not filter_err)):
            self.view_stack.hide()
            self.loading_box.show()
            self.center_spinner.start()
            self.inline_spinner.start()
            return

        self.center_spinner.stop()
        self.loading_box.hide()
        self.view_stack.show()

        if any_loading:
            self.inline_spinner.start()
        else:
            self.inline_spinner.stop()

        self.page_info_label.setText(
            f"Trang {page} / {total_ui_pages}" if total_ui_pages > 1 else f"Trang {page}"
        )
        self.prev_page_btn.setEnabled(page > 1 and not filter_loading)

        if not base_games and filter_err and not any_loading:
            self._clear_views()
            self._set_status(filter_err, "error")
            self.retry_btn.show()
            self.next_page_btn.setEnabled(False)
            return

        if not page_games and not any_loading:
            self._sync_grid([])
            if self._is_shelf_mode_active():
                self._sync_shelves(base_games)
                self.view_stack.setCurrentWidget(self.shelves_scroll)
            else:
                self.view_stack.setCurrentWidget(self.scroll_area)
            self.retry_btn.hide()
            if base_games and self._category_filter not in ("discovery", "all"):
                cat_name = (
                    "Đã cài đặt · Có bản cập nhật"
                    if self._category_filter == INSTALLED_UPDATES_SLUG
                    else CATEGORY_LABELS.get(self._category_filter, self._category_filter)
                )
                self._set_status(
                    f"Chưa tìm thấy game thuộc danh mục '{cat_name}' trong kho hiện tại. Chọn 'Kệ Khám Phá' hoặc 'Làm mới'.",
                    "warn",
                )
            else:
                self._set_status(
                    f"Không có kết quả cho '{query}'. Thử từ khóa tiếng Anh khác hoặc bấm 'Làm mới'."
                    if query else "Không còn game nào ở trang này.",
                    "warn",
                )
            self.next_page_btn.setEnabled(False)
            return

        self.retry_btn.hide()
        what = f"cho '{query}'" if query else "mới cập nhật"
        if wave1_loading:
            waiting = [
                source_display_name(s)
                for s, flag in (
                    (SOURCE_ONLINE_FIX, self._of_loading),
                    (SOURCE_ANKERGAMES, self._ag_loading),
                    (SOURCE_FITGIRL, self._fg_loading),
                    (SOURCE_STEAMRIP, self._sr_loading),
                )
                if flag
            ]
            self._set_status(
                f"Đã hiển thị {total_matching} game — đang đồng bộ thêm từ {', '.join(waiting)}…",
                "busy",
            )
        elif self._category_backfilling:
            cat_name = CATEGORY_LABELS.get(self._category_filter, self._category_filter)
            self._set_status(
                f"Đã có {total_matching} game '{cat_name}' — đang tải thêm chuyên mục từ các nguồn…",
                "busy",
            )
        elif self._pool_loading:
            self._set_status(
                f"Đã gom {total_matching} game {what} — đang tải nối thêm các trang tiếp theo ở nền…",
                "busy",
            )
        elif total_matching > len(page_games) and not self._is_shelf_mode_active():
            self._set_status(
                f"Hiển thị {start + 1}–{start + len(page_games)} / {total_matching} game {what}. Bấm vào thẻ game để chọn nguồn tải.",
                "info",
            )
        else:
            self._set_status(f"{total_matching} game {what}. Bấm vào thẻ game để chọn nguồn tải.", "info")

        has_more_in_pool = (page * UI_PAGE_SIZE) < total_matching
        can_extend = self._can_extend_active_sources() or self._can_extend_category(self._category_filter)
        self.next_page_btn.setEnabled(has_more_in_pool or can_extend)

        # Sync grid_layout in-place (at most 24 reusable card widgets per UI page)
        self._sync_grid(page_games)

        if self._is_shelf_mode_active():
            self._sync_shelves(base_games)
            self.view_stack.setCurrentWidget(self.shelves_scroll)
        else:
            self.view_stack.setCurrentWidget(self.scroll_area)

    def _bind_card_poster(self, card: _OnlineFixGameCard, game: OnlineFixGame):
        norm_key = normalize_game_cache_key(game.title)
        if norm_key:
            key_cards = self._cards_by_key.setdefault(norm_key, [])
            if card not in key_cards:
                key_cards.append(card)
        url = game.poster_url
        if url and self._posters.has_failed(url) and game.provider_poster_url and game.provider_poster_url != url:
            for prov in (game.providers or ()):
                if prov.poster_url == game.poster_url and prov.provider_poster_url:
                    prov.poster_url = prov.provider_poster_url
            game.poster_url = game.provider_poster_url
            url = game.poster_url
        if not url or card._applied_poster_url == url:
            return
        pix = self._posters.card_pixmap(url)
        if pix is not None:
            card.set_poster_pixmap(pix, url)
        elif not self._posters.has_failed(url):
            waiters = self._cards.setdefault(url, [])
            if card not in waiters:
                waiters.append(card)
            self._posters.request(url)

    def _sync_existing_card(self, card: _OnlineFixGameCard, game: OnlineFixGame):
        if not game.categories:
            game.categories = classify_game_categories(game)
        card.sync_game(game)
        card.set_update_available(is_game_update_available(game, self._installed_ts_map))
        self._bind_card_poster(card, game)

    def _build_bound_card(self, game: OnlineFixGame, parent: QWidget) -> _OnlineFixGameCard:
        if not game.categories:
            game.categories = classify_game_categories(game)
        card = _OnlineFixGameCard(game, parent)
        card.set_update_available(is_game_update_available(game, self._installed_ts_map))
        card.clicked.connect(self._on_card_clicked)
        card.share_requested.connect(self._on_share_game)
        self._bind_card_poster(card, game)
        return card

    def _sync_grid(self, games: list[OnlineFixGame]):
        desired_uids = [_game_uid(g) for g in games]
        if desired_uids == self._grid_uids:
            for uid, g in zip(desired_uids, games):
                card = self._grid_card_pool.get(uid)
                if card is not None and isValid(card):
                    self._sync_existing_card(card, g)
            return

        v_pos = self.scroll_area.verticalScrollBar().value()
        self.grid_container.setUpdatesEnabled(False)
        try:
            while self.grid_layout.count():
                self.grid_layout.takeAt(0)
            desired_set = set(desired_uids)
            for uid, card in list(self._grid_card_pool.items()):
                if not isValid(card):
                    self._grid_card_pool.pop(uid, None)
                elif uid not in desired_set and not card.isHidden():
                    card.hide()

            for uid, g in zip(desired_uids, games):
                card = self._grid_card_pool.get(uid)
                if card is not None and isValid(card):
                    self._sync_existing_card(card, g)
                else:
                    card = self._build_bound_card(g, self.grid_container)
                    self._grid_card_pool[uid] = card
                self.grid_layout.addWidget(card)
                card.show()
            self._grid_uids = desired_uids
        finally:
            self.grid_container.setUpdatesEnabled(True)
            self.scroll_area.verticalScrollBar().setValue(v_pos)

    def _sync_shelves(self, base_games: list[OnlineFixGame]):
        if not base_games:
            self._clear_shelves_only()
            return

        desired_specs: list[tuple[str, str, str, list[OnlineFixGame], int]] = []
        upd_games = find_installed_game_updates(base_games, self._installed_ts_map) if self._installed_ts_map else []
        if upd_games:
            upd_lim = self._shelf_limits.get(INSTALLED_UPDATES_SLUG, SHELF_INITIAL_LIMIT)
            desired_specs.append(
                (
                    INSTALLED_UPDATES_SLUG,
                    "Đã cài đặt · Có bản cập nhật",
                    "refresh",
                    upd_games[:upd_lim],
                    len(upd_games),
                )
            )
        all_lim = self._shelf_limits.get("all", 16)
        desired_specs.append(
            ("all", "Mới phát hành & đăng tải", "store", base_games[:all_lim], len(base_games))
        )
        for slug, label, icon_name in STORE_CATEGORIES:
            cat_games = [
                g for g in base_games
                if slug in (g.categories or classify_game_categories(g))
            ]
            if cat_games:
                lim = self._shelf_limits.get(slug, SHELF_INITIAL_LIMIT)
                desired_specs.append((slug, label, icon_name, cat_games[:lim], len(cat_games)))

        desired_order = [spec[0] for spec in desired_specs]
        if desired_order == self._shelf_order and all(
            s in self._shelf_widgets and isValid(self._shelf_widgets[s]) for s in desired_order
        ):
            for slug, _label, _icon, row_games, total_cnt in desired_specs:
                self._shelf_widgets[slug].sync_games(
                    row_games, total_cnt, self._build_bound_card, self._sync_existing_card
                )
            return

        v_pos = self.shelves_scroll.verticalScrollBar().value()
        self.shelves_container.setUpdatesEnabled(False)
        try:
            while self.shelves_layout.count():
                self.shelves_layout.takeAt(0)
            next_shelves: dict[str, _CategoryShelfWidget] = {}
            for slug, label, icon_name, row_games, total_cnt in desired_specs:
                shelf = self._shelf_widgets.pop(slug, None)
                if shelf is None or not isValid(shelf):
                    shelf = _CategoryShelfWidget(
                        slug,
                        label,
                        icon_name,
                        total_cnt,
                        show_view_all=True,
                        parent=self.shelves_container,
                    )
                    shelf.view_all_requested.connect(self._on_set_category_filter)
                    shelf.near_end_reached.connect(self._on_shelf_near_end)
                shelf.sync_games(row_games, total_cnt, self._build_bound_card, self._sync_existing_card)
                next_shelves[slug] = shelf
                self.shelves_layout.addWidget(shelf)
                shelf.show()
            self.shelves_layout.addStretch(1)
            for old_shelf in self._shelf_widgets.values():
                if isValid(old_shelf):
                    old_shelf.hide()
                    old_shelf.deleteLater()
            self._shelf_widgets = next_shelves
            self._shelf_order = desired_order
        finally:
            self.shelves_container.setUpdatesEnabled(True)
            self.shelves_scroll.verticalScrollBar().setValue(v_pos)

    def _clear_shelves_only(self):
        while self.shelves_layout.count():
            item = self.shelves_layout.takeAt(0)
            w = item.widget() if item else None
            if w and w not in self._shelf_widgets.values():
                w.deleteLater()
        for shelf in self._shelf_widgets.values():
            if isValid(shelf):
                shelf.hide()
                shelf.deleteLater()
        self._shelf_widgets.clear()
        self._shelf_order.clear()

    def _clear_grid(self):
        while self.grid_layout.count():
            self.grid_layout.takeAt(0)
        for card in self._grid_card_pool.values():
            if isValid(card):
                card.hide()
                card.deleteLater()
        self._grid_card_pool.clear()
        self._grid_uids.clear()

    def _clear_views(self):
        self._cards.clear()
        self._cards_by_key.clear()
        self._pending_poster_urls.clear()
        self._clear_grid()
        self._clear_shelves_only()

    @safe_slot
    def _on_poster_loaded(self, url: str, _data: bytes):
        if not url:
            return
        self._pending_poster_urls.add(url)
        if not self._poster_flush_timer.isActive():
            self._poster_flush_timer.start()

    @safe_slot
    def _flush_pending_posters(self):
        if not self._pending_poster_urls:
            return
        urls = list(self._pending_poster_urls)
        self._pending_poster_urls.clear()
        for url in urls:
            waiters = self._cards.pop(url, [])
            if not waiters:
                continue
            pix = self._posters.card_pixmap(url)
            if pix is None:
                for card in waiters:
                    try:
                        if not isValid(card):
                            continue
                        fb = card.game.provider_poster_url
                        if fb and fb != url and not self._posters.has_failed(fb):
                            card.game.poster_url = fb
                            for prov in (card.game.providers or ()):
                                if prov.poster_url == url and prov.provider_poster_url:
                                    prov.poster_url = prov.provider_poster_url
                            self._catalog_version += 1
                            fb_pix = self._posters.card_pixmap(fb)
                            if fb_pix is not None:
                                card.set_poster_pixmap(fb_pix, fb)
                            else:
                                fb_waiters = self._cards.setdefault(fb, [])
                                if card not in fb_waiters:
                                    fb_waiters.append(card)
                                self._posters.request(fb)
                    except RuntimeError:
                        pass
                continue
            for card in waiters:
                try:
                    if isValid(card):
                        card.set_poster_pixmap(pix, url)
                except RuntimeError:
                    pass

    # ------------------------------------------------------------ detail & download

    def _default_install_dir(self) -> str:
        return self.manager.get_install_root()

    @safe_slot
    def _on_card_clicked(self, game: OnlineFixGame):
        from app.ui.online_fix.game_detail_dialog import GameDetailDialog

        enabled = set(self._enabled_stores)
        of_pool = self._of_games if SOURCE_ONLINE_FIX in enabled else []
        fg_pool = self._fg_games if SOURCE_FITGIRL in enabled else []
        sr_pool = self._sr_games if SOURCE_STEAMRIP in enabled else []
        ag_pool = self._ag_games if SOURCE_ANKERGAMES in enabled else []
        variants = [
            v for v in resolve_game_providers(game, of_pool, fg_pool, sr_pool, ag_pool)
            if v.source in enabled
        ] or [game]
        initial_src = (
            self._source_filter
            if (self._source_filter != "all" and self._source_filter in enabled)
            else None
        )
        clients_map = {
            SOURCE_ONLINE_FIX: self.client,
            SOURCE_ANKERGAMES: self.ankergames_client,
            SOURCE_FITGIRL: self.fitgirl_client,
            SOURCE_STEAMRIP: self.steamrip_client,
        }
        client = clients_map.get(game.source, self.client)
        logger.info(
            f"{TAG} User opened game {game.title!r} "
            f"[selected={initial_src or variants[0].source}, providers={[v.source for v in variants]}] ({game.url})"
        )

        self._dialog_open = True
        dialog = GameDetailDialog(
            game,
            client,
            self._default_install_dir(),
            self._posters,
            self,
            providers=variants,
            clients_by_source=clients_map,
            initial_source=initial_src,
        )
        try:
            dialog.download_requested.connect(self._start_download_task)
            dialog.install_root_changed.connect(self._on_install_root_changed)
            dialog.exec()
        finally:
            self._dialog_open = False
            dialog.deleteLater()

    @safe_slot
    def _on_share_game(self, game: OnlineFixGame):
        title = game.title
        norm_key = normalize_game_cache_key(title) or _dedupe_key(game)
        cands = self._candidate_share_urls(game)
        logger.info(f"{TAG} User clicked share for {title!r} ({game.url})")
        cached_url = peek_cached_steam_store_url(title, *cands)
        if cached_url:
            self._finish_share_game(title, norm_key, cached_url, cached=True)
            return
        if norm_key in self._inflight_share_keys:
            return
        self._inflight_share_keys.add(norm_key)
        self._set_status(f"Đang lấy liên kết Steam cho '{title}'…", "busy")
        task = Task(
            lambda: resolve_steam_store_url(title, *cands),
            f"share-card-{game.id}",
        )
        task.done.connect(lambda url, err, t=title, k=norm_key: self._on_share_game_resolved(t, k, url, err))
        task.start_tracked()

    def _candidate_share_urls(self, game: OnlineFixGame) -> tuple[str, ...]:
        enabled = set(self._enabled_stores)
        variants = resolve_game_providers(
            game,
            self._of_games if SOURCE_ONLINE_FIX in enabled else [],
            self._fg_games if SOURCE_FITGIRL in enabled else [],
            self._sr_games if SOURCE_STEAMRIP in enabled else [],
            self._ag_games if SOURCE_ANKERGAMES in enabled else [],
        ) or [game]
        urls: list[str] = []
        for v in (game, *variants):
            for u in candidate_steam_urls_for_game(v):
                if u and u not in urls:
                    urls.append(u)
        return tuple(urls)

    @safe_slot
    def _on_share_game_resolved(self, title: str, norm_key: str, url, error: str):
        self._inflight_share_keys.discard(norm_key)
        if error or not url:
            self._set_status(error or f"Không lấy được liên kết Steam cho '{title}'.", "error")
            return
        self._finish_share_game(title, norm_key, str(url), cached=False)

    def _finish_share_game(self, title: str, norm_key: str, url: str, *, cached: bool):
        copy_to_clipboard(url)
        logger.info(f"{TAG} Copied Steam link for {title!r} to clipboard: {url} (cached={cached})")
        cache_key = normalize_game_cache_key(title) or norm_key
        for card in self._cards_by_key.get(cache_key, ()):
            if isValid(card):
                card.show_share_copied()
        self._set_status(f"Đã sao chép liên kết Steam của '{title}': {url}", "ok")

    @safe_slot
    def _on_install_root_changed(self, root: str):
        logger.info(f"{TAG} User changed the install folder to {root}")
        self.manager.save_install_root(root)

    @safe_slot
    def _start_download_task(self, data: dict):
        logger.info(f"{TAG} User started download of {data['game_title']!r} into {data['install_target_root']}")
        self.manager.save_install_root(data["install_target_root"])
        self.manager.create_and_start_task(
            game_title=data["game_title"],
            source_url=data["source_url"],
            install_target_root=data["install_target_root"],
            delete_archive=data.get("delete_archive", True),
            auto_extract=data.get("auto_extract", True),
            archive_password=data.get("archive_password", ""),
            referer=data.get("referer", ""),
            poster_url=data.get("poster_url", ""),
            source=data.get("source", SOURCE_ONLINE_FIX),
        )
        self.download_drawer.show()
        self._update_queue_button()

    @safe_slot
    def _on_task_completed(self, task_id: str, exe_path: str):
        self._update_queue_button()
        task = self.manager.get_task(task_id)
        if not task:
            return
        if not exe_path or not os.path.isfile(exe_path):
            logger.warning(f"{TAG} {task.game_title!r} finished without a game exe: checking fallback")
            from app.core.online_fix.extractor import find_game_executable
            exe_path = find_game_executable(task.target_install_dir, task.game_title) or ""
        self.game_installed.emit({
            "name": task.game_title,
            "exe_path": exe_path,
            "install_location": task.target_install_dir,
            "poster_url": getattr(task, "poster_url", ""),
            "source": getattr(task, "source", SOURCE_ONLINE_FIX),
        })
        QTimer.singleShot(50, self.refresh_installed_games_state)
