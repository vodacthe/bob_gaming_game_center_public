"""Gamepad monitoring using SDL2 — adapted from controller_mapping project.

Opens ALL joystick devices and merges input. Supports multiple combos,
each mapping to a different keyboard shortcut.
"""

import os
import collections
import ctypes
import time
import logging
import threading

# Ensure SDL background events are enabled and RawInput is disabled (forces XInput for background)
os.environ["SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS"] = "1"
os.environ["SDL_JOYSTICK_RAWINPUT"] = "0"

from PySide6.QtCore import QThread, Signal

from app.core.android.gamepad.hid import pad_state_from_sdl
from app.core.gamepad_tester import GC_AXES, GC_BUTTONS

logger = logging.getLogger(__name__)

# Try to import SDL2 — optional dependency
try:
    import sdl2
    SDL2_AVAILABLE = True
except ImportError:
    SDL2_AVAILABLE = False
    logger.warning("sdl2 not available — gamepad monitoring disabled")

# SDL Hat constants
SDL_HAT_CENTERED = 0
SDL_HAT_UP = 1
SDL_HAT_RIGHT = 2
SDL_HAT_DOWN = 4
SDL_HAT_LEFT = 8

HAT_NAMES = {
    SDL_HAT_UP: "D-Pad Up", SDL_HAT_RIGHT: "D-Pad Right",
    SDL_HAT_DOWN: "D-Pad Down", SDL_HAT_LEFT: "D-Pad Left",
    SDL_HAT_UP | SDL_HAT_RIGHT: "D-Pad Up-Right",
    SDL_HAT_UP | SDL_HAT_LEFT: "D-Pad Up-Left",
    SDL_HAT_DOWN | SDL_HAT_RIGHT: "D-Pad Down-Right",
    SDL_HAT_DOWN | SDL_HAT_LEFT: "D-Pad Down-Left",
}

AXIS_TRIGGER_THRESHOLD = 16000
AXIS_REST_MIN = -32000
AXIS_REST_MAX = 32000
SNAPSHOT_INTERVAL = 1 / 30     # tester refresh rate
BATTERY_POLL_SECONDS = 30.0   # SDL reports coarse levels; they change slowly
COMBO_COOLDOWN_MS = 500

# ── UI navigation (app/ui/gamepad_nav.py) ──
NAV_DIRECTIONS = ("up", "down", "left", "right")
NAV_SCROLLS = ("scroll_up", "scroll_down")
NAV_STICK_THRESHOLD = 20000
NAV_REPEAT_DELAY = 0.40       # s before a held direction starts repeating
NAV_REPEAT_INTERVAL = 0.11    # s between repeats of a held direction
NAV_SCROLL_INTERVAL = 0.05    # s between right-stick scroll ticks
POLL_INTERVAL = 0.016         # s between polls (combos, UI navigation)
TAP_POLL_INTERVAL = 0.004     # s between polls while a pad tap forwards the controllers (game input)
LIVE_STATE_INTERVAL = 0.1     # s between live_state emissions


class NavInputTracker:
    """Turns the per-frame set of held nav inputs into discrete UI actions.

    Directions fire on press and auto-repeat while held. Buttons fire on *release*, and only when
    pressed alone with nothing else in between — so pressing a Controller Mapper combo (e.g. LB+RB+A)
    never also clicks the focused UI element.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self._next_fire: dict[str, float] = {}
        self._buttons_down: set[str] = set()
        self._gesture: str | None = None
        self._gesture_valid = False
        self._suppressed: set[str] = set()      # directions held since prime(): ignored until released

    def combo_fired(self):
        self._gesture_valid = False

    def prime(self, pressed: set[str], now: float) -> None:
        """Start from what is held right now without acting on it: a button already down (e.g. the B held to leave
        the controller tester) is not a press, and a held direction waits until it is released."""
        self.reset()
        self._buttons_down = {p for p in pressed if p not in NAV_DIRECTIONS and p not in NAV_SCROLLS}
        self._suppressed = {p for p in pressed if p in NAV_DIRECTIONS or p in NAV_SCROLLS}

    def update(self, pressed: set[str], now: float) -> list[str]:
        actions: list[str] = []
        buttons = {p for p in pressed if p not in NAV_DIRECTIONS and p not in NAV_SCROLLS}

        new_buttons = buttons - self._buttons_down
        if new_buttons:
            if not self._buttons_down and self._gesture is None and len(new_buttons) == 1:
                self._gesture = next(iter(new_buttons))
                self._gesture_valid = True
            else:
                self._gesture_valid = False
        if self._buttons_down and not buttons:
            if self._gesture and self._gesture_valid:
                actions.append(self._gesture)
            self._gesture = None
            self._gesture_valid = False
        self._buttons_down = buttons

        self._suppressed &= pressed                     # a direction released since prime() counts again
        # Directions are suppressed while a button is held: that is a chord, not navigation.
        moves = set() if buttons else {p for p in pressed if p in NAV_DIRECTIONS or p in NAV_SCROLLS}
        moves -= self._suppressed
        if buttons and any(p in NAV_DIRECTIONS for p in pressed):
            self._gesture_valid = False
        for name in list(self._next_fire):
            if name not in moves:
                del self._next_fire[name]
        for name in sorted(moves):
            due = self._next_fire.get(name)
            if due is None:
                actions.append(name)
                self._next_fire[name] = now + (NAV_SCROLL_INTERVAL if name in NAV_SCROLLS else NAV_REPEAT_DELAY)
            elif now >= due:
                actions.append(name)
                self._next_fire[name] = now + (NAV_SCROLL_INTERVAL if name in NAV_SCROLLS else NAV_REPEAT_INTERVAL)
        return actions

BUTTON_NAMES = {
    0: "A / Cross", 1: "B / Circle", 2: "X / Square", 3: "Y / Triangle",
    4: "LB / L1", 5: "RB / R1", 6: "Back / Select", 7: "Start / Options",
    8: "L3", 9: "R3", 10: "Guide / Home", 11: "Share", 12: "Touchpad",
}

AXIS_NAMES = {
    "axis:0+": "L-Stick Right", "axis:0-": "L-Stick Left",
    "axis:1+": "L-Stick Down", "axis:1-": "L-Stick Up",
    "axis:2+": "R-Stick Right", "axis:2-": "R-Stick Left",
    "axis:3+": "R-Stick Down", "axis:3-": "R-Stick Up",
    "axis:4+": "LT / L2", "axis:4-": "LT / L2 (neg)",
    "axis:5+": "RT / R2", "axis:5-": "RT / R2 (neg)",
}


class GamepadMonitor(QThread):
    """Monitors ALL joystick devices and fires combos."""

    combo_triggered = Signal(str)  # combo_id
    gamepad_connected = Signal(str)
    gamepad_disconnected = Signal()
    buttons_changed = Signal(set)  # during recording
    live_state = Signal(set, str)
    debug_message = Signal(str)
    device_snapshots = Signal(object)  # list of per-controller dicts (~30 Hz) while the tester is open
    battery_changed = Signal(object)  # {device name: raw SDL power level}, when it changes (also on (un)plug)
    nav_action = Signal(str)  # "up"/"down"/"left"/"right"/"a"/"b"/"x"/"y"/"lb"/"rb"/"start"/"back"/"scroll_*"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.battery_levels: dict[str, int] = {}   # latest {device: SDL power level}
        self._detail = False                          # the controller tester wants full snapshots
        self._rumble_queue: collections.deque = collections.deque(maxlen=32)
        self.setPriority(QThread.Priority.HighestPriority)
        self._running = True
        self._paused = threading.Event()
        self._paused_ack = threading.Event()
        self._combo_groups: dict[str, dict[str, set]] = {}  # owner -> combo_id -> input keys
        self._combos: dict[str, set] = {}  # merged view read by the polling thread
        self._recording = False
        self._recorded_inputs = set()
        self.connected_device_names = ""
        self._controllers: dict[int, object] = {}  # joystick index -> SDL_GameController
        self._nav_enabled = False
        self._nav = NavInputTracker()
        self._pad_tap = None              # consumer of full controller states (Android gamepad bridge)
        self._pad_tap_failed = False

    def set_pad_tap(self, tap) -> None:
        """Hand every controller's full state to `tap` while it asks for it.

        `tap.wants_pads()` is checked on each poll; while it is true the monitor polls faster and calls
        `tap.feed_pads([(instance_id, name, PadState), ...])` on this thread. When that returns True the input
        belongs to the tap (a game is being played with it) and UI navigation is not fed from it.
        """
        self._pad_tap = tap
        self._pad_tap_failed = False
        logger.info(f"[GamepadMonitor] Pad tap {'attached' if tap is not None else 'detached'}")

    def _feed_tap(self, joysticks: list) -> tuple[bool, bool]:
        """Returns (tap is reading the pads, tap consumed the input). Never raises."""
        tap = self._pad_tap
        if tap is None:
            return False, False
        try:
            if not tap.wants_pads():
                return False, False
            return True, bool(tap.feed_pads(self._read_pad_states(joysticks)))
        except Exception:   # noqa: BLE001 - a broken consumer must not stop the input thread
            if not self._pad_tap_failed:   # once: this runs on every poll
                self._pad_tap_failed = True
                logger.exception("[GamepadMonitor] Pad tap failed; controller forwarding is unavailable")
            return False, False

    def _read_pad_states(self, joysticks: list) -> list:
        """`(instance_id, name, PadState)` of every attached controller, in the standard Xbox layout."""
        out = []
        for idx, js, name in joysticks:
            if not sdl2.SDL_JoystickGetAttached(js):
                continue
            gc = self._controllers.get(idx)
            if gc:
                buttons = [sdl2.SDL_GameControllerGetButton(gc, b) for b in range(15)]
                axes = [sdl2.SDL_GameControllerGetAxis(gc, a) for a in range(6)]
            else:
                # Unknown device: assume the common XInput-style raw layout (same guess as UI navigation)
                n_btn = sdl2.SDL_JoystickNumButtons(js)
                raw = [bool(sdl2.SDL_JoystickGetButton(js, b)) for b in range(min(n_btn, 10))] + [False] * 10
                hat = sdl2.SDL_JoystickGetHat(js, 0) if sdl2.SDL_JoystickNumHats(js) > 0 else 0
                # raw: A B X Y LB RB Back Start LS RS -> SDL order: A B X Y Back Guide Start LS RS LB RB + D-pad
                buttons = [raw[0], raw[1], raw[2], raw[3], raw[6], False, raw[7], raw[8], raw[9], raw[4], raw[5],
                           bool(hat & SDL_HAT_UP), bool(hat & SDL_HAT_DOWN),
                           bool(hat & SDL_HAT_LEFT), bool(hat & SDL_HAT_RIGHT)]
                n_axes = sdl2.SDL_JoystickNumAxes(js)
                axes = [sdl2.SDL_JoystickGetAxis(js, a) if a < n_axes else 0 for a in range(4)] + [0, 0]
            out.append((int(sdl2.SDL_JoystickInstanceID(js)), name, pad_state_from_sdl(buttons, axes)))
        return out

    def acts_on_input(self) -> bool:
        """Combos and UI navigation react to the pad, except while a combo is being recorded or the tester is open."""
        return not self._recording and not self._detail

    def set_detail_enabled(self, enabled: bool) -> None:
        """Turn the per-controller snapshots (device_snapshots, ~30 Hz) on while the tester is visible."""
        self._detail = bool(enabled)
        logger.info(f"[GamepadMonitor] Tester snapshots {'on' if enabled else 'off'}")

    def rumble(self, instance_id: int, low: int, high: int, duration_ms: int) -> None:
        """Vibrate a controller (0..65535 per motor). Runs on the gamepad thread; 0, 0 stops it."""
        self._rumble_queue.append(("main", int(instance_id), int(low), int(high), int(duration_ms)))

    def rumble_triggers(self, instance_id: int, left: int, right: int, duration_ms: int) -> None:
        """Impulse triggers (Xbox One / Series pads); ignored by controllers without them."""
        self._rumble_queue.append(("triggers", int(instance_id), int(left), int(right), int(duration_ms)))

    def _run_rumbles(self, joysticks: list) -> None:
        while self._rumble_queue:
            kind, instance_id, a, b, ms = self._rumble_queue.popleft()
            try:
                for idx, js, name in joysticks:
                    if sdl2.SDL_JoystickInstanceID(js) != instance_id:
                        continue
                    gc = self._controllers.get(idx)
                    if kind == "triggers":
                        fn = sdl2.SDL_GameControllerRumbleTriggers if gc else sdl2.SDL_JoystickRumbleTriggers
                    else:
                        fn = sdl2.SDL_GameControllerRumble if gc else sdl2.SDL_JoystickRumble
                    rc = fn(gc or js, a, b, ms)
                    logger.info(f"[GamepadMonitor] Rumble {kind} on {name}: {a}/{b} for {ms} ms (rc={rc})")
            except Exception as e:   # noqa: BLE001 - an unsupported pad must not stop the input thread
                logger.warning(f"[GamepadMonitor] Rumble failed: {e!r}")

    def _snapshot(self, joysticks: list) -> list[dict]:
        """Everything the tester shows about each controller. Never raises (a broken field is left out)."""
        out = []
        for idx, js, name in joysticks:
            d = {"index": idx, "name": name}
            try:
                if not sdl2.SDL_JoystickGetAttached(js):
                    continue
                d["instance_id"] = int(sdl2.SDL_JoystickInstanceID(js))
                buf = ctypes.create_string_buffer(64)
                sdl2.SDL_JoystickGetGUIDString(sdl2.SDL_JoystickGetGUID(js), buf, 64)
                d["guid"] = buf.value.decode("ascii", "replace")
                d["vendor"] = int(sdl2.SDL_JoystickGetVendor(js))
                d["product"] = int(sdl2.SDL_JoystickGetProduct(js))
                d["product_version"] = int(sdl2.SDL_JoystickGetProductVersion(js))
                serial = sdl2.SDL_JoystickGetSerial(js) if hasattr(sdl2, "SDL_JoystickGetSerial") else None
                d["serial"] = serial.decode("utf-8", "replace") if serial else ""
                d["player_index"] = int(sdl2.SDL_JoystickGetPlayerIndex(js))
                d["power"] = int(sdl2.SDL_JoystickCurrentPowerLevel(js))
                d["rumble"] = bool(sdl2.SDL_JoystickHasRumble(js))
                d["trigger_rumble"] = bool(sdl2.SDL_JoystickHasRumbleTriggers(js))
                d["led"] = bool(sdl2.SDL_JoystickHasLED(js))
                d["buttons"] = [int(sdl2.SDL_JoystickGetButton(js, b)) for b in range(sdl2.SDL_JoystickNumButtons(js))]
                d["axes"] = [int(sdl2.SDL_JoystickGetAxis(js, a)) for a in range(sdl2.SDL_JoystickNumAxes(js))]
                d["hats"] = [int(sdl2.SDL_JoystickGetHat(js, h)) for h in range(sdl2.SDL_JoystickNumHats(js))]
                gc = self._controllers.get(idx)
                d["is_controller"] = bool(gc)
                if gc:
                    d["type_id"] = int(sdl2.SDL_GameControllerGetType(gc))
                    mapping = sdl2.SDL_GameControllerMapping(gc)
                    d["mapping"] = mapping.decode("utf-8", "replace") if mapping else ""
                    d["gc_buttons"] = {n: bool(sdl2.SDL_GameControllerGetButton(gc, i))
                                       for i, n in enumerate(GC_BUTTONS)}
                    d["gc_axes"] = {n: int(sdl2.SDL_GameControllerGetAxis(gc, i)) for i, n in enumerate(GC_AXES)}
            except Exception as e:   # noqa: BLE001
                logger.debug(f"[GamepadMonitor] snapshot of {name} incomplete: {e!r}")
            out.append(d)
        return out

    def set_nav_enabled(self, enabled: bool):
        """Emit `nav_action` for UI navigation (off by default; turned on by GamepadNavigator)."""
        self._nav_enabled = enabled

    def pause(self, *args, timeout: float = 0.250, **kwargs):
        """Pause gamepad polling, ensuring no SDL calls are made during a remote stream."""
        self._paused.set()
        self._paused_ack.wait(timeout)

    def resume(self, *args, **kwargs):
        """Resume gamepad polling."""
        self._paused_ack.clear()
        self._paused.clear()

    def set_combos(self, combos: dict[str, set], group: str = "mapper"):
        """Replace the combos owned by `group` (Controller Mapper = "mapper"); other groups are kept.
        Combo ids must be unique across groups."""
        groups = dict(self._combo_groups)
        groups[group] = {cid: set(inputs) for cid, inputs in combos.items()}
        self._combo_groups = groups
        merged: dict[str, set] = {}
        for owned in groups.values():
            merged.update(owned)
        self._combos = merged   # single reference swap: the polling thread never sees a half-built dict
        logger.info(f"[GamepadMonitor] Combos updated ({group}): {groups[group]}")

    def start_recording(self):
        self._recording = True
        self._recorded_inputs = set()

    def stop_recording(self) -> set:
        self._recording = False
        result = self._recorded_inputs.copy()
        self._recorded_inputs = set()
        return result

    @property
    def is_recording(self) -> bool:
        return self._recording

    def stop(self):
        self._running = False

    def _open_all_joysticks(self) -> list:
        joysticks = []
        num = sdl2.SDL_NumJoysticks()
        for i in range(num):
            js = sdl2.SDL_JoystickOpen(i)
            if js:
                name_bytes = sdl2.SDL_JoystickName(js)
                name = name_bytes.decode("utf-8", errors="replace") if name_bytes else f"Device {i}"
                logger.info(
                    f"[GamepadMonitor] Opened device [{i}] {name} | Btn:{sdl2.SDL_JoystickNumButtons(js)} "
                    f"Ax:{sdl2.SDL_JoystickNumAxes(js)} Hat:{sdl2.SDL_JoystickNumHats(js)}"
                )
                joysticks.append((i, js, name))
                # Standardised layout (A/B/X/Y, D-pad, sticks) for UI navigation, same on Xbox/PS/Switch pads
                if sdl2.SDL_IsGameController(i):
                    gc = sdl2.SDL_GameControllerOpen(i)
                    if gc:
                        self._controllers[i] = gc
        return joysticks

    @staticmethod
    def _read_battery(joysticks: list) -> dict[str, int]:
        """Raw SDL power level of each attached controller (-1 = unknown). Never raises: battery is a nicety."""
        levels: dict[str, int] = {}
        for _idx, js, name in joysticks:
            try:
                if sdl2.SDL_JoystickGetAttached(js):
                    levels[name] = int(sdl2.SDL_JoystickCurrentPowerLevel(js))
            except Exception as e:   # noqa: BLE001 - a driver that cannot report must not stop the input thread
                logger.debug(f"[GamepadMonitor] battery of {name} unavailable: {e}")
        return levels

    def _close_all_joysticks(self, joysticks: list):
        for gc in self._controllers.values():
            sdl2.SDL_GameControllerClose(gc)
        self._controllers = {}
        for _, js, _ in joysticks:
            sdl2.SDL_JoystickClose(js)

    def _read_nav_state(self, joysticks: list) -> set[str]:
        """Held navigation inputs across all pads, as NavInputTracker names."""
        state = set()
        t = NAV_STICK_THRESHOLD
        for idx, js, _ in joysticks:
            if not sdl2.SDL_JoystickGetAttached(js):
                continue
            gc = self._controllers.get(idx)
            if gc:
                for name, btn in (
                    ("a", sdl2.SDL_CONTROLLER_BUTTON_A), ("b", sdl2.SDL_CONTROLLER_BUTTON_B),
                    ("x", sdl2.SDL_CONTROLLER_BUTTON_X), ("y", sdl2.SDL_CONTROLLER_BUTTON_Y),
                    ("lb", sdl2.SDL_CONTROLLER_BUTTON_LEFTSHOULDER),
                    ("rb", sdl2.SDL_CONTROLLER_BUTTON_RIGHTSHOULDER),
                    ("back", sdl2.SDL_CONTROLLER_BUTTON_BACK), ("start", sdl2.SDL_CONTROLLER_BUTTON_START),
                    ("guide", sdl2.SDL_CONTROLLER_BUTTON_GUIDE),
                    ("l3", sdl2.SDL_CONTROLLER_BUTTON_LEFTSTICK), ("r3", sdl2.SDL_CONTROLLER_BUTTON_RIGHTSTICK),
                    ("up", sdl2.SDL_CONTROLLER_BUTTON_DPAD_UP), ("down", sdl2.SDL_CONTROLLER_BUTTON_DPAD_DOWN),
                    ("left", sdl2.SDL_CONTROLLER_BUTTON_DPAD_LEFT), ("right", sdl2.SDL_CONTROLLER_BUTTON_DPAD_RIGHT),
                ):
                    if sdl2.SDL_GameControllerGetButton(gc, btn):
                        state.add(name)
                lx = sdl2.SDL_GameControllerGetAxis(gc, sdl2.SDL_CONTROLLER_AXIS_LEFTX)
                ly = sdl2.SDL_GameControllerGetAxis(gc, sdl2.SDL_CONTROLLER_AXIS_LEFTY)
                ry = sdl2.SDL_GameControllerGetAxis(gc, sdl2.SDL_CONTROLLER_AXIS_RIGHTY)
                if sdl2.SDL_GameControllerGetAxis(gc, sdl2.SDL_CONTROLLER_AXIS_TRIGGERLEFT) > t:
                    state.add("lt")
                if sdl2.SDL_GameControllerGetAxis(gc, sdl2.SDL_CONTROLLER_AXIS_TRIGGERRIGHT) > t:
                    state.add("rt")
            else:
                # Unknown device: assume the common XInput-style raw layout
                for b, name in enumerate(("a", "b", "x", "y", "lb", "rb", "back", "start")):
                    if b < sdl2.SDL_JoystickNumButtons(js) and sdl2.SDL_JoystickGetButton(js, b):
                        state.add(name)
                if sdl2.SDL_JoystickNumHats(js) > 0:
                    hat = sdl2.SDL_JoystickGetHat(js, 0)
                    for bit, name in ((SDL_HAT_UP, "up"), (SDL_HAT_DOWN, "down"),
                                      (SDL_HAT_LEFT, "left"), (SDL_HAT_RIGHT, "right")):
                        if hat & bit:
                            state.add(name)
                has_axes = sdl2.SDL_JoystickNumAxes(js) >= 2
                lx = sdl2.SDL_JoystickGetAxis(js, 0) if has_axes else 0
                ly = sdl2.SDL_JoystickGetAxis(js, 1) if has_axes else 0
                ry = 0
            if lx < -t:
                state.add("left")
            elif lx > t:
                state.add("right")
            if ly < -t:
                state.add("up")
            elif ly > t:
                state.add("down")
            if ry < -t:
                state.add("scroll_up")
            elif ry > t:
                state.add("scroll_down")
        return state

    def run(self):
        if not SDL2_AVAILABLE:
            logger.error("[GamepadMonitor] SDL2 not available")
            return

        # Crucial for Windows:
        # 1. ALLOW_BACKGROUND_EVENTS: enables receiving joystick inputs even when app lacks focus
        # 2. RAWINPUT = 0: Disables RawInput backend. On Windows, RawInput drops input when unfocused.
        #    Setting RAWINPUT=0 forces SDL2 to use XInput (for Xbox) and DirectInput, which query
        #    the driver directly (XInputGetState) globally without needing window focus.
        # 3. HIDAPI = 1: Enables direct background USB/Bluetooth driver for DualShock/DualSense
        # 4. THREAD = 1: Dedicated background input thread in SDL2
        override = getattr(sdl2, "SDL_HINT_OVERRIDE", 2)
        sdl2.SDL_SetHintWithPriority(b"SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", b"1", override)
        sdl2.SDL_SetHintWithPriority(b"SDL_JOYSTICK_RAWINPUT", b"0", override)
        sdl2.SDL_SetHintWithPriority(b"SDL_JOYSTICK_HIDAPI", b"1", override)
        sdl2.SDL_SetHintWithPriority(b"SDL_JOYSTICK_THREAD", b"1", override)

        ret = sdl2.SDL_Init(sdl2.SDL_INIT_JOYSTICK | sdl2.SDL_INIT_GAMECONTROLLER)
        if ret != 0:
            logger.error(f"[GamepadMonitor] SDL2 init failed")
            return

        logger.info("[GamepadMonitor] SDL2 initialized successfully")
        joysticks = self._open_all_joysticks()
        if joysticks:
            self.connected_device_names = " + ".join(n for _, _, n in joysticks)
            self.gamepad_connected.emit(self.connected_device_names)
        else:
            self.connected_device_names = ""

        prev_pressed = set()
        last_battery_check = 0.0
        last_snapshot = 0.0
        nav_was_active = False
        last_battery: dict[str, int] | None = None
        combo_was_active: dict[str, bool] = {}
        last_combo_time: dict[str, float] = {}
        last_live_state = 0.0
        last_rescan = time.time()

        while self._running:
            if self._paused.is_set():
                self._paused_ack.set()
                prev_pressed.clear()
                combo_was_active.clear()
                self._nav.reset()
                time.sleep(0.05)
                continue  # NO sdl2.* call of any kind while paused

            now = time.time()
            event = sdl2.SDL_Event()
            while sdl2.SDL_PollEvent(ctypes.byref(event)):
                if event.type in (sdl2.SDL_JOYDEVICEADDED, sdl2.SDL_JOYDEVICEREMOVED):
                    self._close_all_joysticks(joysticks)
                    joysticks = self._open_all_joysticks()
                    if joysticks:
                        self.connected_device_names = " + ".join(n for _, _, n in joysticks)
                        self.gamepad_connected.emit(self.connected_device_names)
                    else:
                        self.connected_device_names = ""
                        self.gamepad_disconnected.emit()
                        prev_pressed.clear()

            if not joysticks and now - last_rescan > 3.0:
                last_rescan = now
                sdl2.SDL_JoystickUpdate()
                joysticks = self._open_all_joysticks()
                if joysticks:
                    self.connected_device_names = " + ".join(n for _, _, n in joysticks)
                    self.gamepad_connected.emit(self.connected_device_names)
                else:
                    self.connected_device_names = ""

            if now - last_battery_check >= BATTERY_POLL_SECONDS or (last_battery or {}).keys() !=                     {n for _, _, n in joysticks}:
                last_battery_check = now
                levels = self._read_battery(joysticks)
                if levels != last_battery:
                    last_battery = levels
                    self.battery_levels = dict(levels)
                    self.battery_changed.emit(dict(levels))

            if self._detail and now - last_snapshot >= (SNAPSHOT_INTERVAL if joysticks else 0.5):
                last_snapshot = now
                self.device_snapshots.emit(self._snapshot(joysticks))
            if self._rumble_queue:
                self._run_rumbles(joysticks)

            if not joysticks:
                self._nav.reset()
                self._feed_tap(joysticks)   # tells the tap that no controller is left
                time.sleep(0.1)
                continue

            sdl2.SDL_JoystickUpdate()
            tap_reading, tap_consumed = self._feed_tap(joysticks)
            current_pressed = set()
            debug_parts = []

            for idx, js, name in joysticks:
                if not sdl2.SDL_JoystickGetAttached(js):
                    continue
                # Buttons
                for b in range(sdl2.SDL_JoystickNumButtons(js)):
                    if sdl2.SDL_JoystickGetButton(js, b):
                        current_pressed.add(f"btn:{b}")
                # Hats
                for h in range(sdl2.SDL_JoystickNumHats(js)):
                    hat = sdl2.SDL_JoystickGetHat(js, h)
                    if hat != SDL_HAT_CENTERED:
                        current_pressed.add(f"hat:{hat}")
                # Axes
                for a in range(sdl2.SDL_JoystickNumAxes(js)):
                    val = sdl2.SDL_JoystickGetAxis(js, a)
                    if AXIS_REST_MIN < val < AXIS_REST_MAX:
                        if val > AXIS_TRIGGER_THRESHOLD:
                            current_pressed.add(f"axis:{a}+")
                        elif val < -AXIS_TRIGGER_THRESHOLD:
                            current_pressed.add(f"axis:{a}-")

            # Live state (~10Hz)
            if now - last_live_state >= LIVE_STATE_INTERVAL:
                last_live_state = now
                self.live_state.emit(current_pressed, str(len(current_pressed)))

            # Recording
            if self._recording:
                new_presses = current_pressed - prev_pressed
                if new_presses:
                    for press in new_presses:
                        if press.startswith("hat:"):
                            # A D-pad/hat can only point to one state at a time. Remove other hat inputs.
                            self._recorded_inputs = {x for x in self._recorded_inputs if not x.startswith("hat:")}
                        elif press.startswith("axis:"):
                            # An axis can only be pushed in one direction at a time. Remove opposite direction.
                            axis_id = press.split(":")[1][:-1]
                            opposite = f"axis:{axis_id}-" if press.endswith("+") else f"axis:{axis_id}+"
                            if opposite in self._recorded_inputs:
                                self._recorded_inputs.remove(opposite)
                        self._recorded_inputs.add(press)
                    self.buttons_changed.emit(self._recorded_inputs.copy())

            # Combo detection
            combo_fired = False
            # the tester shows inputs: pressing a mapped combo there must not also run its action. The held state is
            # still followed, so a combo held while leaving the tester does not fire the moment it closes.
            acting = self.acts_on_input()
            if self._combos and not self._recording:
                for combo_id, combo_inputs in self._combos.items():
                    if not combo_inputs:
                        continue
                    active = combo_inputs.issubset(current_pressed)
                    was_active = combo_was_active.get(combo_id, False)
                    if acting and active and not was_active:
                        elapsed = (now - last_combo_time.get(combo_id, 0)) * 1000
                        if elapsed >= COMBO_COOLDOWN_MS:
                            logger.info(f"[GamepadMonitor] Combo triggered: {combo_id} (inputs: {combo_inputs})")
                            self.combo_triggered.emit(combo_id)
                            last_combo_time[combo_id] = now
                            combo_fired = True
                    combo_was_active[combo_id] = active

            # UI navigation (never while recording a combo, nor while the controller tester is open: every stick
            # movement and button press there is a test, not "move the focus / scroll"; nor while a pad tap is
            # sending the controller to a game)
            if self._nav_enabled and acting and not tap_consumed:
                nav_state = self._read_nav_state(joysticks)
                if not nav_was_active:
                    self._nav.prime(nav_state, now)
                else:
                    if combo_fired:
                        self._nav.combo_fired()
                    for action in self._nav.update(nav_state, now):
                        self.nav_action.emit(action)
                nav_was_active = True
            else:
                self._nav.reset()
                nav_was_active = False

            prev_pressed = current_pressed
            time.sleep(TAP_POLL_INTERVAL if tap_reading else POLL_INTERVAL)

        self._close_all_joysticks(joysticks)
        sdl2.SDL_QuitSubSystem(sdl2.SDL_INIT_GAMECONTROLLER | sdl2.SDL_INIT_JOYSTICK)

    @staticmethod
    def get_input_display_name(input_key: str) -> str:
        if input_key.startswith("btn:"):
            btn_id = int(input_key.split(":")[1])
            return BUTTON_NAMES.get(btn_id, f"Button {btn_id + 1}")
        elif input_key.startswith("hat:"):
            hat_val = int(input_key.split(":")[1])
            return HAT_NAMES.get(hat_val, f"Hat {hat_val}")
        elif input_key in AXIS_NAMES:
            return AXIS_NAMES[input_key]
        elif input_key.startswith("axis:"):
            return f"Axis {input_key.split(':')[1]}"
        return input_key
