"""Shared header bar for every full-screen view (Settings, Cloud Sync, Network Unblock, ...).

One place defines the look so screens stay consistent:

    [← Quay lại]  (icon) Title                          [badge] [Button] [Button]
                         optional subtitle

    header = ScreenHeader("Cài đặt hệ thống", "settings", subtitle="...")
    header.back_requested.connect(self._on_back)
    self.save_btn = header.add_button("Lưu cài đặt", "primary", icon="save")
    self.badge = header.add_badge("CHƯA KẾT NỐI", "error")
    layout.addWidget(header)

Button kinds: secondary | primary | danger | success.   Badge kinds: ok | warn | error | info | off.
The stylesheet lives on the header itself, so a screen's own stylesheet cannot make its header drift.

Body spacing is shared too: lay screen content out with CONTENT_MARGINS / CONTENT_SPACING.
"""

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QFont, QFontMetrics, QPainter
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QSizePolicy, QVBoxLayout, QWidget

from app.ui.icons import make_svg_icon, make_svg_pixmap

HEADER_HEIGHT = 64
CONTENT_MARGINS = (28, 20, 28, 24)   # left, top, right, bottom of a screen's body
CONTENT_SPACING = 16

BUTTON_KINDS = ("secondary", "primary", "danger", "success")
BADGE_KINDS = ("ok", "warn", "error", "info", "off")

_STYLE = """
#screenHeader {
    background-color: rgba(13, 16, 26, 0.40);
    border: none;
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);
}
#screenHeader QLabel { background: transparent; border: none; }
#screenHeader QLabel#headerTitle { color: #ffffff; font-size: 16px; font-weight: 700; }
#screenHeader QLabel#headerSubtitle { color: #8b949e; font-size: 12px; font-weight: 400; }
#screenHeader QLabel#headerHint { color: #8b949e; font-size: 11px; }

#screenHeader QPushButton {
    min-height: 0px; padding: 0 16px; border-radius: 8px;
    font-family: 'Segoe UI', Arial, sans-serif; font-size: 12px; font-weight: 700;
}
#screenHeader QPushButton[compact="true"] { padding: 0px; }
#screenHeader QPushButton:disabled { color: rgba(255, 255, 255, 0.35); }
#screenHeader QPushButton[kind="secondary"] {
    background-color: rgba(30, 36, 56, 0.7); border: 1px solid rgba(255, 255, 255, 0.12); color: #cbd5e1;
}
#screenHeader QPushButton[kind="secondary"]:hover {
    background-color: rgba(45, 54, 82, 0.85); border-color: rgba(139, 92, 246, 0.45); color: #ffffff;
}
#screenHeader QPushButton[kind="secondary"]:pressed { background-color: rgba(25, 30, 48, 0.85); }
#screenHeader QPushButton[kind="primary"] {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8b5cf6, stop:1 #6d28d9);
    border: 1px solid rgba(168, 85, 247, 0.5); color: #ffffff;
}
#screenHeader QPushButton[kind="primary"]:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #a855f7, stop:1 #7c3aed);
}
#screenHeader QPushButton[kind="danger"] {
    background-color: rgba(239, 68, 68, 0.18); border: 1px solid rgba(239, 68, 68, 0.7); color: #f87171;
}
#screenHeader QPushButton[kind="danger"]:hover { background-color: #ef4444; color: #ffffff; }
#screenHeader QPushButton[kind="success"] {
    background-color: rgba(16, 185, 129, 0.18); border: 1px solid rgba(16, 185, 129, 0.7); color: #34d399;
}
#screenHeader QPushButton[kind="success"]:hover { background-color: #10b981; color: #ffffff; }
#screenHeader QPushButton:disabled[kind="secondary"],
#screenHeader QPushButton:disabled[kind="primary"],
#screenHeader QPushButton:disabled[kind="danger"],
#screenHeader QPushButton:disabled[kind="success"] {
    background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255, 255, 255, 0.08); color: rgba(255, 255, 255, 0.35);
}

#screenHeader QLabel#headerBadge {
    border-radius: 8px; padding: 0 12px; font-size: 11px; font-weight: 700;
}
#screenHeader QLabel#headerBadge[kind="ok"] {
    background-color: rgba(46, 213, 115, 0.15); color: #2ed573; border: 1px solid rgba(46, 213, 115, 0.55);
}
#screenHeader QLabel#headerBadge[kind="warn"] {
    background-color: rgba(210, 153, 34, 0.18); color: #e3b341; border: 1px solid rgba(210, 153, 34, 0.6);
}
#screenHeader QLabel#headerBadge[kind="error"] {
    background-color: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.5);
}
#screenHeader QLabel#headerBadge[kind="info"] {
    background-color: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.5);
}
#screenHeader QLabel#headerBadge[kind="off"] {
    background-color: rgba(148, 163, 184, 0.12); color: #94a3b8; border: 1px solid rgba(148, 163, 184, 0.35);
}
"""


def _repolish(w: QWidget):
    w.style().unpolish(w)
    w.style().polish(w)


class _ElidedLabel(QLabel):
    """Single-line label that gives way (…) instead of pushing the header's buttons out of view."""

    def __init__(self, text: str = "", min_width: int = 0, parent=None):
        super().__init__(parent)
        self._full = ""
        self._min_width = min_width
        self.setSizePolicy(
            QSizePolicy.Policy.Preferred if min_width > 0 else QSizePolicy.Policy.Ignored,
            QSizePolicy.Policy.Preferred,
        )
        if text:
            self.setText(text)

    def setText(self, text: str):
        self._full = text
        self.setToolTip(text)
        super().setText("")
        self.updateGeometry()
        self.update()

    def text(self) -> str:
        return self._full

    def paintEvent(self, event):
        p = QPainter(self)
        p.setFont(self.font())
        p.setPen(self.palette().color(self.foregroundRole()))
        fm = QFontMetrics(self.font())
        p.drawText(self.rect(), int(self.alignment()) | int(Qt.AlignmentFlag.AlignVCenter),
                   fm.elidedText(self._full, Qt.TextElideMode.ElideRight, self.width()))
        p.end()

    def sizeHint(self):
        fm = QFontMetrics(self.font())
        if self._min_width > 0:
            return QSize(fm.horizontalAdvance(self._full) + 4, fm.height() + 2)
        sh = super().sizeHint()
        sh.setHeight(fm.height() + 2)
        return sh

    def minimumSizeHint(self):
        fm = QFontMetrics(self.font())
        if self._min_width > 0:
            return QSize(min(self._min_width, fm.horizontalAdvance(self._full) + 4), fm.height() + 2)
        return QSize(0, fm.height() + 2)


def _bold_metrics(px: int) -> QFontMetrics:
    font = QFont("Segoe UI")
    font.setPixelSize(px)
    font.setBold(True)
    return QFontMetrics(font)


class _HeaderButton(QPushButton):
    """sizeHint measured with the bold stylesheet font + padding, so a Fixed-width button never clips its text."""

    def sizeHint(self):
        if not self.text():
            return QSize(38, 36)
        icon_w = (self.iconSize().width() + 6) if not self.icon().isNull() else 0
        return QSize(_bold_metrics(12).horizontalAdvance(self.text()) + icon_w + 34, 36)

    def minimumSizeHint(self):
        return self.sizeHint()


class HeaderBadge(QLabel):
    """Small status pill; change its look with set_kind() / set_state() instead of writing a stylesheet."""

    def __init__(self, text: str = "", kind: str = "off", parent=None):
        super().__init__(text, parent)
        self.setObjectName("headerBadge")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedHeight(28)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.set_kind(kind)

    def sizeHint(self):
        return QSize(_bold_metrics(11).horizontalAdvance(self.text()) + 28, 28)

    def minimumSizeHint(self):
        return self.sizeHint()

    def setText(self, text: str):
        super().setText(text)
        self.updateGeometry()

    def set_kind(self, kind: str):
        if kind not in BADGE_KINDS:
            raise ValueError(f"unknown badge kind {kind!r}")
        self.setProperty("kind", kind)
        _repolish(self)

    def set_state(self, text: str, kind: str):
        self.setText(text)
        self.set_kind(kind)


class ScreenHeader(QWidget):
    """Back button + icon + title (+ subtitle) on the left, badges and action buttons on the right."""

    back_requested = Signal()

    def __init__(self, title: str, icon: str = "", subtitle: str = "", show_back: bool = True, parent=None):
        super().__init__(parent)
        self.setObjectName("screenHeader")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setFixedHeight(HEADER_HEIGHT)
        self.setStyleSheet(_STYLE)
        self._has_stretch_action = False

        row = QHBoxLayout(self)
        self._row = row
        row.setContentsMargins(CONTENT_MARGINS[0], 0, CONTENT_MARGINS[2], 0)
        row.setSpacing(12)

        self.back_btn = self.make_button("← Quay lại", "secondary", tooltip="Quay lại thư viện")
        self.back_btn.clicked.connect(self.back_requested.emit)
        row.addWidget(self.back_btn)
        self.back_btn.setVisible(show_back)     # after addWidget: shown while parentless it flashes as a window

        self._icon = QLabel()
        self._icon.setFixedSize(24, 24)
        row.addWidget(self._icon)
        self.set_icon(icon)

        titles = QVBoxLayout()
        self._titles = titles
        titles.setSpacing(1)
        titles.setContentsMargins(0, 0, 0, 0)
        self._title = _ElidedLabel(title, min_width=96)
        self._title.setObjectName("headerTitle")
        title_font = QFont("Segoe UI")
        title_font.setPixelSize(16)
        title_font.setBold(True)
        self._title.setFont(title_font)
        self._subtitle = _ElidedLabel()
        self._subtitle.setObjectName("headerSubtitle")
        titles.addStretch()
        titles.addWidget(self._title)
        titles.addWidget(self._subtitle)
        titles.addStretch()
        row.addLayout(titles, 1)   # takes the spare width; its subtitle elides first
        self.set_subtitle(subtitle)

        self._actions = QHBoxLayout()
        self._actions.setSpacing(10)
        row.addLayout(self._actions)

    # ── content ──

    def set_title(self, text: str):
        self._title.setText(text)

    def set_subtitle(self, text: str):
        self._subtitle.setText(text)
        self._subtitle.setVisible(bool(text))
        if self._has_stretch_action:
            self._row.setStretchFactor(self._titles, 1 if text else 0)

    def set_icon(self, name: str):
        self._icon.setVisible(bool(name))
        if name:
            self._icon.setPixmap(make_svg_pixmap(name, size=22, color="#a855f7"))

    # ── right-hand side ──

    @staticmethod
    def make_button(text: str, kind: str = "secondary", icon: str = "", tooltip: str = "") -> QPushButton:
        if kind not in BUTTON_KINDS:
            raise ValueError(f"unknown button kind {kind!r}")
        btn = _HeaderButton(text)
        btn.setProperty("kind", kind)
        btn.setFixedHeight(36)
        btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)   # never squeezed: text stays whole
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        if icon:
            btn.setIcon(make_svg_icon(icon, size=14, normal_color="#ffffff"))
        if tooltip:
            btn.setToolTip(tooltip)
        return btn

    @staticmethod
    def set_button_kind(btn: QPushButton, kind: str):
        """Switch an existing header button between kinds (e.g. a start/stop toggle)."""
        if kind not in BUTTON_KINDS:
            raise ValueError(f"unknown button kind {kind!r}")
        btn.setProperty("kind", kind)
        _repolish(btn)

    def add_button(self, text: str, kind: str = "secondary", icon: str = "", tooltip: str = "") -> QPushButton:
        btn = self.make_button(text, kind, icon, tooltip)
        self._actions.addWidget(btn)
        return btn

    def add_badge(self, text: str = "", kind: str = "off") -> HeaderBadge:
        badge = HeaderBadge(text, kind)
        self._actions.addWidget(badge)
        return badge

    def add_hint(self, text: str = "") -> QLabel:
        """Small muted text on the right (e.g. 'Last refresh: ...')."""
        label = QLabel(text)
        label.setObjectName("headerHint")
        label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self._actions.addWidget(label)
        return label

    def add_widget(self, widget: QWidget, stretch: int = 0):
        if stretch > 0:
            self._has_stretch_action = True
            self._row.setStretchFactor(self._titles, 1 if self._subtitle.text() else 0)
            self._row.setStretchFactor(self._actions, stretch)
        self._actions.addWidget(widget, stretch)
