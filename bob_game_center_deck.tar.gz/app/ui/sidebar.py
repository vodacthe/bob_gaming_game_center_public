"""
Luxury Collapsible Sidebar for Bob Gaming Game Center.
Featuring the authentic Bob Gaming logo and razor-sharp vector SVG icons.
Unified Cyberpunk Titanium Violet & Emerald Design Language.
"""

import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QFrame, QSizePolicy
)
from PySide6.QtCore import Qt, Signal, QRectF, QSize
from PySide6.QtGui import QFont, QPixmap, QPainter, QColor, QLinearGradient

from app.config import get_app_dir
from app.ui.icons import make_svg_pixmap
from app.version import APP_VERSION


class _ClickableLabel(QLabel):
    clicked = Signal()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)


class _SidebarNavButton(QPushButton):
    """A sleek navigation item with razor-sharp vector icon and luxury styling."""

    def __init__(self, key: str, icon_name: str, text: str, badge_text: str = "", parent=None):
        super().__init__(parent)
        self.key = key
        self.icon_name = icon_name
        self.label_text = text
        self.badge_text = badge_text
        self.is_collapsed = False
        self._is_active = False
        self._hovered = False

        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(36)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        self._update_text()

    def minimumSizeHint(self) -> QSize:
        return QSize(40, 36)

    def sizeHint(self) -> QSize:
        return QSize(120, 36)

    def set_active(self, active: bool):
        self._is_active = active
        self.setProperty("active", "true" if active else "false")
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def set_badge(self, text: str, is_highlight: bool = False):
        self.badge_text = text
        self._badge_highlight = is_highlight
        self._update_text()
        self.update()

    def set_collapsed(self, collapsed: bool):
        self.is_collapsed = collapsed
        self._update_text()
        self.update()

    def _update_text(self):
        """Update QPushButton text for backwards compatibility and test assertions."""
        badge_str = f"  [{self.badge_text}]" if self.badge_text else ""
        if self.is_collapsed:
            self.setText("")
            tooltip = self.label_text
            if self.badge_text:
                tooltip += f" [{self.badge_text}]"
            self.setToolTip(tooltip)
        else:
            self.setText(f"  {self.label_text}{badge_str}")
            self.setToolTip(self.label_text if ("@" in self.label_text or len(self.label_text) > 20) else "")

    def enterEvent(self, event):
        self._hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hovered = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        """Pixel-perfect custom painting matching mockup without text overlap."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        rect = self.rect()

        # 1. Background (Rounded pill)
        if self._is_active:
            grad = QLinearGradient(0, 0, rect.width(), 0)
            grad.setColorAt(0, QColor("#6d28d9"))
            grad.setColorAt(1, QColor("#5b21b6"))
            painter.setBrush(grad)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(rect.adjusted(2, 2, -2, -2), 8, 8)
        elif self._hovered:
            painter.setBrush(QColor(255, 255, 255, 14))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(rect.adjusted(2, 2, -2, -2), 8, 8)

        # 2. Icon
        icon_size = 18
        if self.is_collapsed:
            icon_x = (rect.width() - icon_size) // 2
        else:
            icon_x = 12
        icon_y = (rect.height() - icon_size) // 2

        icon_color = "#ffffff" if self._is_active else ("#ffffff" if self._hovered else "#8c96a8")
        pix = make_svg_pixmap(self.icon_name, size=icon_size, color=icon_color)
        if not pix.isNull():
            painter.drawPixmap(icon_x, icon_y, pix)

        # In collapsed mode, do not draw text or badges
        if self.is_collapsed:
            painter.end()
            return

        # 3. Badge geometry & pre-measurement
        badge_w = 0
        badge_draw_fn = None

        if self.badge_text:
            badge_font = QFont("Segoe UI", 9, QFont.Weight.Bold)
            painter.setFont(badge_font)
            metrics = painter.fontMetrics()

            if self.badge_text in ["ON", "ONLINE"]:
                txt = f"[{self.badge_text}]"
                txt_w = metrics.horizontalAdvance(txt)
                badge_w = txt_w + 4
                badge_x = rect.width() - badge_w - 10
                badge_rect = QRectF(badge_x, 0, badge_w, rect.height())

                def _draw_status():
                    painter.setFont(badge_font)
                    painter.setPen(QColor("#10b981"))
                    painter.drawText(badge_rect, Qt.AlignmentFlag.AlignCenter, txt)

                badge_draw_fn = _draw_status
            else:
                txt_w = metrics.horizontalAdvance(self.badge_text)
                pill_w = max(22, txt_w + 12)
                pill_h = 18
                badge_w = pill_w
                pill_x = rect.width() - pill_w - 10
                pill_y = (rect.height() - pill_h) // 2
                pill_rect = QRectF(pill_x, pill_y, pill_w, pill_h)

                def _draw_pill():
                    painter.setFont(badge_font)
                    if self.badge_text == "HOT":            # red pill, active or not
                        painter.setBrush(QColor("#ef4444"))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawRoundedRect(pill_rect, 6, 6)
                        painter.setPen(QColor("#ffffff"))
                    elif self.badge_text == "NEW":          # emerald pill for newly added features
                        painter.setBrush(QColor("#10b981"))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawRoundedRect(pill_rect, 6, 6)
                        painter.setPen(QColor("#052e16"))
                    elif self._is_active:
                        painter.setBrush(QColor(255, 255, 255, 45))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawRoundedRect(pill_rect, 6, 6)
                        painter.setPen(QColor("#ffffff"))
                    else:
                        painter.setBrush(QColor(255, 255, 255, 20))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawRoundedRect(pill_rect, 6, 6)
                        painter.setPen(QColor("#94a3b8"))
                    painter.drawText(pill_rect, Qt.AlignmentFlag.AlignCenter, self.badge_text)

                badge_draw_fn = _draw_pill

        # 4. Text Label (strictly elided so it NEVER collides with badge)
        text_color = QColor("#ffffff") if self._is_active else (QColor("#ffffff") if self._hovered else QColor("#94a3b8"))
        font = QFont("Segoe UI", 10)
        font.setWeight(QFont.Weight.DemiBold if self._is_active else QFont.Weight.Medium)
        painter.setFont(font)
        painter.setPen(text_color)

        text_x = 38
        right_reserve = (badge_w + 14) if badge_w > 0 else 8
        available_text_w = max(10, rect.width() - text_x - right_reserve)
        elide_mode = Qt.TextElideMode.ElideMiddle if "@" in self.label_text else Qt.TextElideMode.ElideRight
        elided_text = painter.fontMetrics().elidedText(self.label_text, elide_mode, int(available_text_w))

        text_rect = QRectF(text_x, 0, available_text_w, rect.height())
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, elided_text)

        # Draw badge after text
        if badge_draw_fn:
            badge_draw_fn()

        painter.end()


class SidebarWidget(QWidget):
    """
    Main Navigation Sidebar featuring authentic Bob Gaming branding,
    vector navigation icons, and collapsible luxury design.
    """

    # Signals
    category_selected = Signal(str)  # 'all', 'installed', 'favorites', 'synced'
    tool_triggered = Signal(str)      # 'net_unblock', 'steam_chat', 'cloud_sync', 'steam_artwork', 'upscaler'
    device_triggered = Signal(str)    # 'controller'
    system_triggered = Signal(str)    # 'settings', 'logs', 'account'
    collapse_toggled = Signal(bool)
    version_clicked = Signal()        # check for updates now

    EXPANDED_WIDTH = 256
    COLLAPSED_WIDTH = 68

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("sidebar")
        self._collapsed = False
        self._nav_buttons: dict[str, _SidebarNavButton] = {}
        self._group_labels: list[QLabel] = []

        self.setFixedWidth(self.EXPANDED_WIDTH)
        self._setup_ui()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(8, 10, 8, 10)
        main_layout.setSpacing(4)

        # ---- Official Bob Gaming Brand Header ----
        self.header_widget = QWidget()
        self.header_widget.setCursor(Qt.CursorShape.PointingHandCursor)
        header_layout = QVBoxLayout(self.header_widget)
        header_layout.setContentsMargins(0, 0, 0, 4)
        header_layout.setSpacing(2)
        header_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        app_dir = get_app_dir()
        logo_path = os.path.join(app_dir, "assets", "logo.png")
        icon_path = os.path.join(app_dir, "assets", "icon.png")

        # Outer logo container
        self.logo_card = QFrame()
        self.logo_card.setObjectName("logoCard")
        self.logo_card.setStyleSheet("""
            #logoCard {
                border: none;
                background-color: transparent;
            }
        """)
        logo_card_layout = QVBoxLayout(self.logo_card)
        logo_card_layout.setContentsMargins(2, 2, 2, 2)
        logo_card_layout.setSpacing(2)
        logo_card_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Full logo for expanded mode
        self.logo_full_label = QLabel()
        self.logo_full_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo_full_label.setStyleSheet("background: transparent; border: none;")
        if os.path.exists(logo_path):
            pix_full = QPixmap(logo_path)
            scaled_full = pix_full.scaledToWidth(160, Qt.TransformationMode.SmoothTransformation)
            self.logo_full_label.setPixmap(scaled_full)
        else:
            self.logo_full_label.setText("BOB GAMING")
            self.logo_full_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #ffffff;")

        self.logo_subtitle = QLabel("Game Center")
        self.logo_subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo_subtitle.setStyleSheet("color: #94a3b8; font-size: 11px; font-weight: 600; letter-spacing: 0.5px; background: transparent; border: none;")

        logo_card_layout.addWidget(self.logo_full_label)
        logo_card_layout.addWidget(self.logo_subtitle)

        # Icon logo for collapsed mode
        self.logo_icon_label = QLabel()
        self.logo_icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo_icon_label.setStyleSheet("background: transparent; border: none;")
        if os.path.exists(icon_path):
            pix_icon = QPixmap(icon_path)
            scaled_icon = pix_icon.scaledToHeight(38, Qt.TransformationMode.SmoothTransformation)
            self.logo_icon_label.setPixmap(scaled_icon)
        else:
            self.logo_icon_label.setText("BG")
            self.logo_icon_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #a855f7;")
        self.logo_icon_label.hide()

        header_layout.addWidget(self.logo_card)
        header_layout.addWidget(self.logo_icon_label)
        main_layout.addWidget(self.header_widget)

        # Subtle divider below logo
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("background-color: rgba(255, 255, 255, 0.07); max-height: 1px;")
        main_layout.addWidget(sep)

        # ---- Scrollable Navigation Body ----
        scroll = QScrollArea()
        scroll.setObjectName("sidebarScroll")
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 4px;
                margin: 0;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 2px;
                min-height: 24px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(139, 92, 246, 0.6);
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0;
                background: transparent;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: transparent;
            }
        """)

        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(0, 4, 4, 0)
        body_layout.setSpacing(2)

        # 1. GROUP: KHO GAME (GAME STORE — TOP SECTION ABOVE LIBRARY)
        self._add_group_label(body_layout, "KHO GAME")
        self._add_nav_item(body_layout, "online_fix", "store", "Cửa hàng miễn phí", group="tool", badge="HOT")
        self._add_nav_item(body_layout, "store_steam_free", "gift", "Steam Miễn Phí", group="tool")

        # 2. GROUP: THƯ VIỆN (LIBRARY)
        self._add_group_label(body_layout, "THƯ VIỆN")
        self._add_nav_item(body_layout, "all", "gamepad", "Tất cả trò chơi", group="lib", active=True, badge="0")
        self._add_nav_item(body_layout, "installed", "download", "Đã cài đặt", group="lib", badge="0")
        self._add_nav_item(body_layout, "synced", "cloud", "Đã đồng bộ", group="lib", badge="0")
        self._add_nav_item(body_layout, "favorites", "star", "Yêu thích", group="lib", badge="0")

        # 3. GROUP: CÔNG CỤ NÂNG CAO (PRO TOOLS)
        self._add_group_label(body_layout, "CÔNG CỤ NÂNG CAO")
        self._add_nav_item(body_layout, "remote_gaming", "cast", "Remote Gaming", group="tool", badge="")
        self._add_nav_item(body_layout, "trainer", "bolt", "Game Trainer", group="tool", badge="NEW")
        self._add_nav_item(body_layout, "net_unblock", "globe", "Mở chặn mạng", group="tool", badge="")
        self._add_nav_item(body_layout, "steam_chat", "chat", "Steam Chat Overlay", group="tool", badge="")
        self._add_nav_item(body_layout, "cloud_sync", "sync", "Đồng bộ đám mây", group="tool")
        self._add_nav_item(body_layout, "steam_artwork", "image", "Ảnh bìa Steam", group="tool")
        self._add_nav_item(body_layout, "upscaler", "sliders", "Upscaler", group="tool")

        # 3. GROUP: THIẾT BỊ (DEVICES)
        self._add_group_label(body_layout, "THIẾT BỊ")
        self._add_nav_item(body_layout, "controller", "controller", "Quản lý tay cầm", group="device")

        # 4. GROUP: HỆ THỐNG (SYSTEM)
        self._add_group_label(body_layout, "HỆ THỐNG")
        self._add_nav_item(body_layout, "logs", "terminal", "Nhật ký Logs", group="system")
        self._add_nav_item(body_layout, "settings", "settings", "Cài đặt", group="system")
        self._add_nav_item(body_layout, "account", "user", "Tài khoản Cloud", group="system", badge="")

        body_layout.addStretch()
        scroll.setWidget(body)
        main_layout.addWidget(scroll)

        # ---- Bottom Bar (Collapse Button) ----
        bottom_widget = QWidget()
        bottom_layout = QVBoxLayout(bottom_widget)
        bottom_layout.setContentsMargins(2, 6, 2, 2)
        bottom_layout.setSpacing(6)

        self.version_label = _ClickableLabel(f"v{APP_VERSION}")
        self.version_label.setObjectName("sidebarVersion")
        self.version_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.version_label.setToolTip(f"Bob Gaming Game Center v{APP_VERSION} · Bấm để kiểm tra cập nhật")
        self.version_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self.version_label.clicked.connect(self.version_clicked)
        self.version_label.setStyleSheet(
            "color: #64748b; font-size: 11px; font-weight: 600; background: transparent; border: none;")
        bottom_layout.addWidget(self.version_label)

        self.collapse_btn = QPushButton("◀ Thu gọn")
        self.collapse_btn.setObjectName("secondaryBtn")
        self.collapse_btn.setFixedHeight(34)
        self.collapse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.collapse_btn.clicked.connect(self.toggle_collapse)

        bottom_layout.addWidget(self.collapse_btn)
        main_layout.addWidget(bottom_widget)

    def _add_group_label(self, layout: QVBoxLayout, text: str):
        lbl = QLabel(text)
        lbl.setObjectName("sidebarGroupLabel")
        layout.addWidget(lbl)
        self._group_labels.append(lbl)

    def _add_nav_item(self, layout: QVBoxLayout, key: str, icon_name: str,
                      text: str, group: str, active: bool = False, badge: str = ""):
        btn = _SidebarNavButton(key, icon_name, text, badge_text=badge, parent=self)
        btn.setObjectName("sidebarItem")
        if active:
            btn.set_active(True)

        btn.clicked.connect(lambda: self._on_item_clicked(key, group))
        layout.addWidget(btn)
        self._nav_buttons[key] = btn

    def _on_item_clicked(self, key: str, group: str):
        self.set_active_item(key)
        if group == "lib":
            self.category_selected.emit(key)
        elif group == "tool":
            self.tool_triggered.emit(key)
        elif group == "device":
            self.device_triggered.emit(key)
        elif group == "system":
            self.system_triggered.emit(key)

    def set_active_item(self, key: str):
        """Set active navigation item across all groups with pixel-perfect highlight."""
        for k, btn in self._nav_buttons.items():
            btn.set_active(k == key)

    def set_active_category(self, key: str):
        """Set active category / nav item across all sidebar items."""
        self.set_active_item(key)

    def active_button(self):
        """The highlighted nav button (first one if none), used as controller focus anchor."""
        for btn in self._nav_buttons.values():
            if btn._is_active:
                return btn
        return next(iter(self._nav_buttons.values()), None)

    def update_counts(self, total: int = 0, installed: int = 0, uninstalled: int = 0,
                      synced: int = 0, unsynced: int = 0, favorites: int = 0, *args, **kwargs):
        """Update category count badges in sidebar."""
        badges = {
            "all": str(total),
            "installed": str(installed),
            "uninstalled": str(uninstalled),
            "synced": str(synced),
            "unsynced": str(unsynced),
            "favorites": str(favorites),
        }
        for key, val in badges.items():
            if key in self._nav_buttons:
                self._nav_buttons[key].set_badge(val)

    def set_net_unblock_status(self, is_active: bool):
        """Update live status indicator on Net Unblock nav button."""
        btn = self._nav_buttons.get("net_unblock")
        if btn:
            btn.set_badge("ON" if is_active else "", is_highlight=is_active)

    def set_steam_chat_status(self, is_active: bool):
        """Update live status indicator on the Steam Chat Overlay nav button."""
        btn = self._nav_buttons.get("steam_chat")
        if btn:
            btn.set_badge("ON" if is_active else "", is_highlight=is_active)

    def set_account_status(self, logged_in: bool, display_name: str = ""):
        """Update the account button text based on login state (no redundant ONLINE badge)."""
        btn = self._nav_buttons.get("account")
        if btn:
            if logged_in:
                btn.label_text = display_name if display_name else "Đã kết nối Cloud"
            else:
                btn.label_text = "Tài khoản Cloud"
            btn.set_badge("")
            btn._update_text()
            btn.update()

    def toggle_collapse(self):
        """Toggle collapsed / expanded sidebar mode."""
        self._collapsed = not self._collapsed
        target_width = self.COLLAPSED_WIDTH if self._collapsed else self.EXPANDED_WIDTH
        self.setFixedWidth(target_width)

        # Toggle logo visibility
        self.logo_card.setVisible(not self._collapsed)
        self.logo_icon_label.setVisible(self._collapsed)

        for lbl in self._group_labels:
            lbl.setVisible(not self._collapsed)

        for btn in self._nav_buttons.values():
            btn.set_collapsed(self._collapsed)

        if self._collapsed:
            self.collapse_btn.setText("▶")
            self.collapse_btn.setToolTip("Mở rộng menu")
        else:
            self.collapse_btn.setText("◀ Thu gọn")
            self.collapse_btn.setToolTip("")

        self.collapse_toggled.emit(self._collapsed)
