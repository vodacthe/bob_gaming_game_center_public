"""
Controller Mapper screen for Bob Gaming Game Center.
Maps controller button combos to keyboard shortcuts.
Layout mirrors the library screen structure.
"""

import json
import logging
import os
import uuid

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QScrollArea, QLabel,
    QPushButton, QFrame, QGraphicsDropShadowEffect, QMessageBox,
    QComboBox, QTabWidget,
)
from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtGui import QColor, QFont, QKeyEvent

from app.config import CONFIG_DIR
from app.core.system_actions import SYSTEM_ACTIONS
from app.ui.gamepad_monitor import GamepadMonitor, SDL2_AVAILABLE
from app.ui.keyboard_sim import send_key_combo, qt_key_to_name
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS, ScreenHeader
from app.ui.styles import CHEVRON_DOWN_ICON_PATH

logger = logging.getLogger(__name__)

MAPPER_CONFIG_FILE = os.path.join(CONFIG_DIR, "controller_mapper.json")


def _load_mappings() -> list[dict]:
    if os.path.exists(MAPPER_CONFIG_FILE):
        try:
            with open(MAPPER_CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return []


def _save_mappings(mappings: list[dict]):
    try:
        os.makedirs(os.path.dirname(MAPPER_CONFIG_FILE), exist_ok=True)
        with open(MAPPER_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(mappings, f, indent=2, ensure_ascii=False)
    except OSError as e:
        logger.error(f"Failed to save mappings: {e}")


class MappingCard(QFrame):
    """Card representing a single controller mapping (to action or keyboard)."""

    remove_requested = Signal(str)  # mapping_id
    record_controller_requested = Signal(str)  # mapping_id
    record_keyboard_requested = Signal(str)  # mapping_id
    target_mode_changed = Signal(str, str)  # (mapping_id, mode)
    mapping_changed = Signal()

    def __init__(self, mapping: dict, parent=None):
        super().__init__(parent)
        self.mapping = mapping
        self._id = mapping.get("id", str(uuid.uuid4()))
        self.mapping.setdefault("id", self._id)

        # Default target_type
        if "target_type" not in self.mapping:
            if self.mapping.get("action_id"):
                self.mapping["target_type"] = "action"
            elif self.mapping.get("keyboard_keys"):
                self.mapping["target_type"] = "keyboard"
            else:
                self.mapping["target_type"] = "action"

        if self.mapping["target_type"] == "action" and not self.mapping.get("action_id"):
            self.mapping["action_id"] = "volume_up"

        self.setObjectName("mappingCard")
        self.setStyleSheet("""
            #mappingCard {
                background-color: #1a1f2e;
                border: 1px solid #2a3040;
                border-radius: 12px;
            }
            #mappingCard:hover {
                border-color: rgba(108, 99, 255, 0.4);
            }
        """)
        self.setMinimumHeight(145)

        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(12)
        shadow.setOffset(0, 2)
        shadow.setColor(QColor(0, 0, 0, 40))
        self.setGraphicsEffect(shadow)

        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)

        # Top row: title + remove
        top = QHBoxLayout()
        title = QLabel(f"Tổ hợp #{self.mapping.get('index', 1)}")
        title.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        title.setStyleSheet("color: #ffffff; background: transparent;")
        top.addWidget(title)
        top.addStretch()

        remove_btn = QPushButton()
        remove_btn.setIcon(make_svg_icon("close", size=12, color="#ff4757"))
        remove_btn.setFixedSize(28, 28)
        remove_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        remove_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 71, 87, 0.1);
                border: none; border-radius: 6px;
                color: #ff4757; font-size: 12px; font-weight: bold;
            }
            QPushButton:hover { background: rgba(255, 71, 87, 0.25); }
        """)
        remove_btn.clicked.connect(lambda: self.remove_requested.emit(self._id))
        top.addWidget(remove_btn)
        layout.addLayout(top)

        # Content: controller combo → target output
        content = QHBoxLayout()
        content.setSpacing(16)

        # Left: Controller combo
        ctrl_col = QVBoxLayout()
        ctrl_col.setSpacing(6)
        
        ctrl_head = QHBoxLayout()
        ctrl_head.setSpacing(6)
        c_icon = QLabel()
        c_icon.setPixmap(make_svg_pixmap("controller", size=14, color="#a855f7"))
        c_icon.setStyleSheet("background: transparent;")
        ctrl_label = QLabel("Tổ hợp phím tay cầm")
        ctrl_label.setFont(QFont("Segoe UI", 10))
        ctrl_label.setStyleSheet("color: #8b949e; background: transparent;")
        ctrl_head.addWidget(c_icon)
        ctrl_head.addWidget(ctrl_label)
        ctrl_head.addStretch()
        ctrl_col.addLayout(ctrl_head)

        self.combo_display = QLabel(self._get_combo_text())
        self.combo_display.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        self.combo_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.combo_display.setWordWrap(True)
        self.combo_display.setMinimumHeight(36)
        self._apply_combo_idle_style()
        ctrl_col.addWidget(self.combo_display)

        self.record_ctrl_btn = QPushButton("● Ghi phím")
        self.record_ctrl_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.record_ctrl_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 #e5c05b, stop:1 #b8860b);
                color: #0b0e14; border: none; border-radius: 6px;
                padding: 6px 12px; font-weight: bold; font-size: 11px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 #f0d275, stop:1 #c9971c);
            }
        """)
        self.record_ctrl_btn.clicked.connect(
            lambda: self.record_controller_requested.emit(self._id)
        )
        ctrl_col.addWidget(self.record_ctrl_btn)
        content.addLayout(ctrl_col, 1)

        # Arrow
        arrow = QLabel("→")
        arrow.setFont(QFont("Segoe UI", 20, QFont.Weight.Bold))
        arrow.setStyleSheet("color: #4ade80; background: transparent;")
        arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
        arrow.setFixedWidth(30)
        content.addWidget(arrow)

        # Right: Output (Action or Keyboard)
        out_col = QVBoxLayout()
        out_col.setSpacing(6)

        # Header with Mode Switcher
        out_header = QHBoxLayout()
        out_header.setSpacing(6)
        out_label = QLabel("Hành động kích hoạt")
        out_label.setFont(QFont("Segoe UI", 10))
        out_label.setStyleSheet("color: #8b949e; background: transparent;")
        out_header.addWidget(out_label)
        out_header.addStretch()

        self.btn_mode_action = QPushButton("Lệnh hệ thống")
        self.btn_mode_action.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_mode_action.clicked.connect(lambda: self._set_target_mode("action"))

        self.btn_mode_kb = QPushButton("Phím tắt")
        self.btn_mode_kb.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_mode_kb.clicked.connect(lambda: self._set_target_mode("keyboard"))

        out_header.addWidget(self.btn_mode_action)
        out_header.addWidget(self.btn_mode_kb)
        out_col.addLayout(out_header)

        # Action Widget container
        self.action_widget = QWidget()
        self.action_widget.setStyleSheet("background: transparent;")
        action_layout = QVBoxLayout(self.action_widget)
        action_layout.setContentsMargins(0, 0, 0, 0)
        action_layout.setSpacing(4)

        self.action_combo = QComboBox()
        self.action_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.action_combo.setStyleSheet("""
            QComboBox {
                background-color: #0f172a;
                color: #ffffff;
                border: 1px solid #2a3040;
                border-radius: 8px;
                padding: 6px 12px;
                font-size: 12px;
                font-weight: bold;
                min-height: 22px;
            }
            QComboBox:hover {
                border-color: #a855f7;
            }
            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 26px;
                border-left: 1px solid #2a3040;
                border-top-right-radius: 8px;
                border-bottom-right-radius: 8px;
                background-color: rgba(255, 255, 255, 0.04);
            }
            QComboBox::down-arrow {
                image: url("__CHEVRON_DOWN_ICON_PATH__");
                width: 12px;
                height: 12px;
                margin-right: 4px;
                border: none;
            }
            QComboBox QAbstractItemView {
                background-color: #1a1f2e;
                color: #ffffff;
                border: 1px solid #2a3040;
                border-radius: 8px;
                selection-background-color: rgba(212, 175, 55, 0.25);
                selection-color: #ffffff;
                padding: 4px;
                outline: none;
            }
        """.replace("__CHEVRON_DOWN_ICON_PATH__", CHEVRON_DOWN_ICON_PATH))

        categories = [
            ("audio", "── Audio ──"),
            ("display", "── Display ──"),
            ("media", "── Media Controls ──"),
            ("system", "── System Utilities ──"),
        ]
        for cat_id, cat_header in categories:
            self.action_combo.addItem(cat_header)
            header_idx = self.action_combo.count() - 1
            item = self.action_combo.model().item(header_idx)
            if item:
                item.setEnabled(False)
            for aid, info in SYSTEM_ACTIONS.items():
                if info.get("category") == cat_id:
                    self.action_combo.addItem(f"{info['icon']}  {info['name']}", aid)

        cur_aid = self.mapping.get("action_id", "volume_up")
        idx = self.action_combo.findData(cur_aid)
        if idx >= 0:
            self.action_combo.setCurrentIndex(idx)
        self.action_combo.currentIndexChanged.connect(self._on_action_changed)
        action_layout.addWidget(self.action_combo)

        self.action_desc_label = QLabel(self._get_action_desc())
        self.action_desc_label.setFont(QFont("Segoe UI", 9))
        self.action_desc_label.setStyleSheet("color: #8b949e; background: transparent; padding-left: 2px;")
        action_layout.addWidget(self.action_desc_label)

        out_col.addWidget(self.action_widget)

        # Keyboard Widget container
        self.kb_widget = QWidget()
        self.kb_widget.setStyleSheet("background: transparent;")
        kb_layout = QVBoxLayout(self.kb_widget)
        kb_layout.setContentsMargins(0, 0, 0, 0)
        kb_layout.setSpacing(4)

        self.kb_display = QLabel(self._get_keyboard_text())
        self.kb_display.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        self.kb_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.kb_display.setWordWrap(True)
        self.kb_display.setMinimumHeight(36)
        self._apply_kb_idle_style()
        kb_layout.addWidget(self.kb_display)

        self.record_kb_btn = QPushButton("● Ghi phím")
        self.record_kb_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.record_kb_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 #e17055, stop:1 #d63031);
                color: white; border: none; border-radius: 6px;
                padding: 6px 12px; font-weight: bold; font-size: 11px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 #f08060, stop:1 #e64040);
            }
        """)
        self.record_kb_btn.clicked.connect(
            lambda: self.record_keyboard_requested.emit(self._id)
        )
        kb_layout.addWidget(self.record_kb_btn)

        out_col.addWidget(self.kb_widget)
        content.addLayout(out_col, 1)

        layout.addLayout(content)
        self._update_target_mode_ui()

    # ── Display helpers ──

    def _get_combo_text(self) -> str:
        inputs = self.mapping.get("controller_inputs", [])
        if not inputs:
            return "No combo set"
        names = [GamepadMonitor.get_input_display_name(i) for i in sorted(inputs)]
        return " + ".join(names)

    def _get_keyboard_text(self) -> str:
        keys = self.mapping.get("keyboard_keys", [])
        if not keys:
            return "No keys set"
        return " + ".join(k.upper() for k in keys)

    def _apply_combo_idle_style(self):
        self.combo_display.setStyleSheet("""
            color: #38bdf8; padding: 6px 10px;
            background-color: #0f172a; border: 1px solid #1e3a5f;
            border-radius: 8px;
        """)

    def _apply_kb_idle_style(self):
        self.kb_display.setStyleSheet("""
            color: #fbbf24; padding: 6px 10px;
            background-color: #0f172a; border: 1px solid #5f3a1e;
            border-radius: 8px;
        """)

    # ── Target Mode Switching ──

    def _set_target_mode(self, mode: str):
        if self.mapping.get("target_type") == mode:
            return
        self.mapping["target_type"] = mode
        if mode == "action" and not self.mapping.get("action_id"):
            self.mapping["action_id"] = "volume_up"
        self._update_target_mode_ui()
        self.target_mode_changed.emit(self._id, mode)
        self.mapping_changed.emit()

    def _update_target_mode_ui(self):
        mode = self.mapping.get("target_type", "action")
        is_action = (mode == "action")

        self.action_widget.setVisible(is_action)
        self.kb_widget.setVisible(not is_action)

        active_btn_style = """
            QPushButton {
                background-color: #7c3aed;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: bold;
            }
        """
        inactive_btn_style = """
            QPushButton {
                background-color: rgba(255, 255, 255, 0.05);
                color: #8b949e;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 6px;
                padding: 4px 10px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.12);
                color: #e0e0e0;
            }
        """
        self.btn_mode_action.setStyleSheet(active_btn_style if is_action else inactive_btn_style)
        self.btn_mode_kb.setStyleSheet(inactive_btn_style if is_action else active_btn_style)

    def _on_action_changed(self, index: int):
        aid = self.action_combo.currentData()
        if aid:
            self.mapping["action_id"] = aid
            self.action_desc_label.setText(self._get_action_desc())
            self.mapping_changed.emit()

    def _get_action_desc(self) -> str:
        aid = self.mapping.get("action_id", "volume_up")
        info = SYSTEM_ACTIONS.get(aid)
        if info:
            return info.get("description", "")
        return ""

    # ── State updates called by parent ──

    def update_combo_display(self, inputs: set | None = None):
        if inputs is not None:
            self.mapping["controller_inputs"] = list(inputs)
        self.combo_display.setText(self._get_combo_text())
        self._apply_combo_idle_style()

    def update_kb_display(self, keys: list[str] | None = None):
        if keys is not None:
            self.mapping["keyboard_keys"] = keys
        self.kb_display.setText(self._get_keyboard_text())
        self._apply_kb_idle_style()

    def set_controller_recording(self, recording: bool):
        if recording:
            self.record_ctrl_btn.setText("Dừng ghi")
            self.combo_display.setStyleSheet("""
                color: #fbbf24; padding: 6px 10px; font-weight: bold;
                background-color: #1c1917; border: 1px dashed #854d0e;
                border-radius: 8px;
            """)
            self.combo_display.setText("Nhấn tổ hợp phím trên tay cầm...")
        else:
            self.record_ctrl_btn.setText("● Ghi phím")
            self._apply_combo_idle_style()

    def set_keyboard_recording(self, recording: bool):
        if recording:
            self.record_kb_btn.setText("Dừng ghi")
            self.kb_display.setStyleSheet("""
                color: #fbbf24; padding: 6px 10px; font-weight: bold;
                background-color: #1c1917; border: 1px dashed #854d0e;
                border-radius: 8px;
            """)
            self.kb_display.setText("Nhấn phím trên bàn phím...")
        else:
            self.record_kb_btn.setText("● Ghi phím")
            self._apply_kb_idle_style()


class ControllerMapperScreen(QWidget):
    """Controller Mapper screen — similar layout to LibraryScreen."""

    back_requested = Signal()

    def __init__(self, gamepad, parent=None, *, steam_controller_service=None):
        super().__init__(parent)
        self._cards: dict[str, MappingCard] = {}
        self._recording_ctrl_id: str | None = None  # controller recording
        self._recording_kb_id: str | None = None    # keyboard recording
        self._kb_recorded_keys: list[str] = []       # keys captured so far
        self._gamepad = gamepad
        self._steam_controller_service = steam_controller_service
        self._mappings: list[dict] = []

        self._setup_ui()
        self._load_and_display()
        self._init_gamepad()

        # Allow this widget to capture key events for keyboard recording
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Header
        header = ScreenHeader("Quản lý tay cầm", "controller", subtitle="Kiểm tra tay cầm & tổ hợp phím")
        header.back_requested.connect(self._on_back)
        self._gp_status = header.add_badge("● Chưa kết nối tay cầm", "off")
        add_btn = header.add_button("Thêm tổ hợp phím", "primary", icon="plus")
        add_btn.clicked.connect(self._add_mapping)
        self._add_btn = add_btn

        # Subtitle
        subtitle_bar = QWidget()
        subtitle_bar.setStyleSheet("background-color: #0a0e17;")
        subtitle_layout = QHBoxLayout(subtitle_bar)
        subtitle_layout.setContentsMargins(CONTENT_MARGINS[0], 8, CONTENT_MARGINS[2], 8)

        self.count_label = QLabel("0 tổ hợp phím đã cấu hình")
        self.count_label.setObjectName("countLabel")
        subtitle_layout.addWidget(self.count_label)
        subtitle_layout.addStretch()

        if not SDL2_AVAILABLE:
            warn = QLabel("Chưa cài đặt thư viện SDL2 — Chức năng ghi phím tay cầm bị tắt")
            warn.setStyleSheet("color: #ffa502; font-size: 11px; background: transparent;")
            subtitle_layout.addWidget(warn)

        # Scroll area
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.scroll_area.setStyleSheet(
            "QScrollArea { border: none; background-color: #0a0e17; }"
        )

        self.list_container = QWidget()
        self.list_container.setStyleSheet("background-color: transparent;")
        self.list_layout = QVBoxLayout(self.list_container)
        self.list_layout.setContentsMargins(CONTENT_MARGINS[0], 16, CONTENT_MARGINS[2], 16)
        self.list_layout.setSpacing(12)
        self.list_layout.addStretch()
        self.scroll_area.setWidget(self.list_container)

        main_layout.addWidget(header)

        # Two tabs: the controller tester first, then the button mapper
        from app.ui.controller_tester import ControllerTesterPanel
        from app.ui.steam_controller_panel import SteamControllerPanel
        self.tester = ControllerTesterPanel(self._gamepad)
        self.steam_panel = SteamControllerPanel(self._steam_controller_service)
        mapper_page = QWidget()
        self._mapper_page = mapper_page
        mapper_layout = QVBoxLayout(mapper_page)
        mapper_layout.setContentsMargins(0, 0, 0, 0)
        mapper_layout.setSpacing(0)
        mapper_layout.addWidget(subtitle_bar)
        mapper_layout.addWidget(self.scroll_area)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.tabBar().setDrawBase(False)
        self.tabs.setAutoFillBackground(True)
        # the tab bar sits below the header's divider (a selected tab used to paint over it) and is aligned with
        # the page content; tabs are pills, not raised folders
        self.tabs.setStyleSheet(
            "QTabWidget { background-color: #0a0e17; }"
            "QTabWidget::pane { border: none; border-top: 1px solid rgba(255,255,255,0.08); background-color: #0a0e17; }"
            "QTabWidget::tab-bar { left: %dpx; }"
            "QTabBar { background: transparent; }"
            "QTabBar::tab { background: rgba(255,255,255,0.05); color: #cbd5e1; padding: 7px 20px; margin: 10px 6px 10px 0;"
            " border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; font-weight: bold; }"
            "QTabBar::tab:hover { background: rgba(139,92,246,0.18); }"
            "QTabBar::tab:selected { background: #8b5cf6; color: #ffffff; border-color: #8b5cf6; }" % CONTENT_MARGINS[0])
        self.tabs.addTab(self.tester, "Kiểm tra tay cầm")
        self.tabs.addTab(mapper_page, "Tổ hợp phím")
        self.tabs.addTab(self.steam_panel, "Steam Controller (XInput)")
        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.tester.exit_requested.connect(self._leave_tester)
        main_layout.addWidget(self.tabs)
        self._on_tab_changed(self.tabs.currentIndex())

    def _leave_tester(self):
        """B held on the pad: go to the mapper tab (the tester stops, the pad drives the UI again)."""
        try:
            self.tabs.setCurrentIndex(self.tabs.indexOf(self.tester) + 1)
            self.tabs.tabBar().setFocus()
        except Exception:   # noqa: BLE001
            logger.exception("[ControllerMapper] could not leave the tester")

    def _on_tab_changed(self, index: int):
        """"Thêm tổ hợp phím" only makes sense on the mapper tab."""
        try:
            self._add_btn.setVisible(self.tabs.widget(index) is self._mapper_page)
        except Exception:   # noqa: BLE001
            logger.exception("[ControllerMapper] tab switch failed")

    # ── Gamepad ──

    def _init_gamepad(self):
        if not self._gamepad:
            self._gp_status.set_state("● Đã ngắt kết nối (Chưa có SDL2)", "error")
            return
        self._gamepad.gamepad_connected.connect(self._on_gp_connected)
        self._gamepad.gamepad_disconnected.connect(self._on_gp_disconnected)
        self._gamepad.buttons_changed.connect(self._on_recording_buttons)
        self._gamepad.battery_changed.connect(self._on_battery)
        self._battery = dict(getattr(self._gamepad, "battery_levels", {}) or {})
        
        if self._gamepad.connected_device_names:
            self._on_gp_connected(self._gamepad.connected_device_names)
        else:
            self._gp_status.set_state("● Đã ngắt kết nối", "error")

    def _on_gp_connected(self, name: str):
        self._gp_name = name
        self._gp_status.set_state(f"● Đã kết nối: {name}{self._battery_text()}", "ok")
        self._sync_combos_to_monitor()

    def _battery_text(self) -> str:
        """" · Pin: yếu" for the status badge ("" when the controller does not report it)."""
        from app.core import gamepad_battery as battery
        levels = [battery.from_sdl(v) for v in (getattr(self, "_battery", None) or {}).values()]
        known = [lv for lv in levels if lv != battery.UNKNOWN]
        if not known:
            return ""
        worst = min(known, key=[battery.EMPTY, battery.LOW, battery.MEDIUM, battery.FULL, battery.WIRED].index)
        return f" · {battery.ICONS[worst]} Pin: {battery.LABELS[worst]}"

    def _on_battery(self, raw):
        try:
            self._battery = dict(raw or {})
            if getattr(self, "_gp_name", ""):
                from app.core import gamepad_battery as battery
                worst_low = any(battery.is_warning(battery.from_sdl(v)) for v in self._battery.values())
                self._gp_status.set_state(f"● Đã kết nối: {self._gp_name}{self._battery_text()}",
                                          "warn" if worst_low else "ok")
        except Exception:   # noqa: BLE001 - a status badge must never take the screen down
            logger.exception("[ControllerMapper] could not show the battery level")

    def _on_gp_disconnected(self):
        self._gp_name = ""
        self._gp_status.set_state("● Đã ngắt kết nối", "error")



    def _on_recording_buttons(self, inputs: set):
        if self._recording_ctrl_id and self._recording_ctrl_id in self._cards:
            card = self._cards[self._recording_ctrl_id]
            names = [GamepadMonitor.get_input_display_name(i) for i in sorted(inputs)]
            card.combo_display.setText(" + ".join(names))

    # ── Keyboard recording via keyPressEvent ──

    def keyPressEvent(self, event: QKeyEvent):
        """Capture keyboard input when recording keyboard output."""
        if self._recording_kb_id:
            key_name = qt_key_to_name(event.key())
            if key_name and key_name not in self._kb_recorded_keys:
                self._kb_recorded_keys.append(key_name)
                # Update display live
                card = self._cards.get(self._recording_kb_id)
                if card:
                    card.kb_display.setText(
                        " + ".join(k.upper() for k in self._kb_recorded_keys)
                    )
            event.accept()
            return
        super().keyPressEvent(event)

    # ── Data management ──

    def _load_and_display(self):
        self._mappings = _load_mappings()
        for i, m in enumerate(self._mappings):
            m.setdefault("id", str(uuid.uuid4()))
            m["index"] = i + 1
            if "target_type" not in m:
                if m.get("action_id"):
                    m["target_type"] = "action"
                elif m.get("keyboard_keys"):
                    m["target_type"] = "keyboard"
                else:
                    m["target_type"] = "action"
            self._add_card(m)
        self._update_count()

    def _add_card(self, mapping: dict):
        card = MappingCard(mapping)
        card.remove_requested.connect(self._remove_mapping)
        card.record_controller_requested.connect(self._toggle_controller_recording)
        card.record_keyboard_requested.connect(self._toggle_keyboard_recording)
        card.target_mode_changed.connect(self._on_card_mode_changed)
        card.mapping_changed.connect(self._save_all)
        self._cards[mapping["id"]] = card
        self.list_layout.insertWidget(self.list_layout.count() - 1, card)

    def _on_card_mode_changed(self, mapping_id: str, mode: str):
        if mode == "action" and self._recording_kb_id == mapping_id:
            self._stop_keyboard_recording()

    def _add_mapping(self):
        new_id = str(uuid.uuid4())
        mapping = {
            "id": new_id,
            "index": len(self._mappings) + 1,
            "controller_inputs": [],
            "target_type": "action",
            "action_id": "volume_up",
            "keyboard_keys": [],
        }
        self._mappings.append(mapping)
        self._add_card(mapping)
        self._update_count()
        self._save_all()

    def _remove_mapping(self, mapping_id: str):
        card = self._cards.pop(mapping_id, None)
        if card:
            self.list_layout.removeWidget(card)
            card.deleteLater()
        self._mappings = [m for m in self._mappings if m.get("id") != mapping_id]
        for i, m in enumerate(self._mappings):
            m["index"] = i + 1
        self._update_count()
        self._save_all()
        self._sync_combos_to_monitor()

    # ── Controller recording ──

    def _toggle_controller_recording(self, mapping_id: str):
        if not self._gamepad:
            QMessageBox.warning(
                self, "SDL2 Required",
                "SDL2 (pysdl2) is required for controller recording.\n"
                "Install with: pip install pysdl2 pysdl2-dll"
            )
            return

        # Stop keyboard recording if active
        self._stop_keyboard_recording()

        if self._recording_ctrl_id == mapping_id:
            # Stop controller recording
            recorded = self._gamepad.stop_recording()
            card = self._cards.get(mapping_id)
            if card:
                card.set_controller_recording(False)
                if recorded:
                    card.update_combo_display(recorded)
                    for m in self._mappings:
                        if m["id"] == mapping_id:
                            m["controller_inputs"] = list(recorded)
                            break
                    self._save_all()
                    self._sync_combos_to_monitor()
                else:
                    card.update_combo_display()
            self._recording_ctrl_id = None
            return

        # Stop previous controller recording
        if self._recording_ctrl_id:
            self._gamepad.stop_recording()
            old = self._cards.get(self._recording_ctrl_id)
            if old:
                old.set_controller_recording(False)
                old.update_combo_display()

        # Start
        self._recording_ctrl_id = mapping_id
        self._gamepad.start_recording()
        card = self._cards.get(mapping_id)
        if card:
            card.set_controller_recording(True)

    # ── Keyboard recording ──

    def _toggle_keyboard_recording(self, mapping_id: str):
        # Stop controller recording if active
        self._stop_controller_recording()

        if self._recording_kb_id == mapping_id:
            # Stop keyboard recording
            self._finish_keyboard_recording()
            return

        # Stop previous kb recording
        if self._recording_kb_id:
            self._finish_keyboard_recording()

        # Start
        self._recording_kb_id = mapping_id
        self._kb_recorded_keys = []
        card = self._cards.get(mapping_id)
        if card:
            card.set_keyboard_recording(True)
        self.setFocus()  # Grab focus to receive keyPressEvent

    def _finish_keyboard_recording(self):
        if not self._recording_kb_id:
            return
        card = self._cards.get(self._recording_kb_id)
        if card:
            card.set_keyboard_recording(False)
            if self._kb_recorded_keys:
                card.update_kb_display(list(self._kb_recorded_keys))
                for m in self._mappings:
                    if m["id"] == self._recording_kb_id:
                        m["keyboard_keys"] = list(self._kb_recorded_keys)
                        break
                self._save_all()
            else:
                card.update_kb_display()
        self._recording_kb_id = None
        self._kb_recorded_keys = []

    def _stop_keyboard_recording(self):
        if self._recording_kb_id:
            self._finish_keyboard_recording()

    def _stop_controller_recording(self):
        if self._recording_ctrl_id and self._gamepad:
            self._gamepad.stop_recording()
            old = self._cards.get(self._recording_ctrl_id)
            if old:
                old.set_controller_recording(False)
                old.update_combo_display()
            self._recording_ctrl_id = None

    # ── Misc ──

    def _sync_combos_to_monitor(self):
        if not self._gamepad:
            return
        combos = {}
        for m in self._mappings:
            inputs = m.get("controller_inputs", [])
            if inputs:
                combos[m["id"]] = set(inputs)
        self._gamepad.set_combos(combos)

    def _save_all(self):
        _save_mappings(self._mappings)

    def _update_count(self):
        n = len(self._mappings)
        self.count_label.setText(f"{n} mapping{'s' if n != 1 else ''} configured")

    def _on_back(self):
        self._stop_controller_recording()
        self._stop_keyboard_recording()
        self.back_requested.emit()

    def cleanup(self):
        """Disconnect signals from the global gamepad monitor."""
        try:
            self.tester.cleanup()
        except Exception:   # noqa: BLE001
            logger.exception("[ControllerMapper] tester cleanup failed")
        try:
            self.steam_panel.cleanup()
        except Exception:   # noqa: BLE001
            logger.exception("[ControllerMapper] steam_panel cleanup failed")
        if self._gamepad:
            try:
                self._gamepad.gamepad_connected.disconnect(self._on_gp_connected)
            except (RuntimeError, TypeError):
                pass
            try:
                self._gamepad.gamepad_disconnected.disconnect(self._on_gp_disconnected)
            except (RuntimeError, TypeError):
                pass
            try:
                self._gamepad.buttons_changed.disconnect(self._on_recording_buttons)
            except (RuntimeError, TypeError):
                pass
            try:
                self._gamepad.battery_changed.disconnect(self._on_battery)
            except (RuntimeError, TypeError):
                pass
            self._gamepad = None
