"""Settings dialog of the Android gamepad bridge: input mode, mouse look and keyboard / mouse bindings."""

from __future__ import annotations

import logging

from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from app.core.android.gamepad.bridge import (
    STATE_ACTIVE,
    STATE_ERROR,
    STATE_READY,
    AndroidGamepadBridge,
    BridgeStatus,
)
from app.core.android.gamepad.kbm import kbm_supported
from app.core.android.gamepad.settings import (
    ACTIONS,
    DEFAULT_BINDINGS,
    MAX_SENSITIVITY,
    MIN_SENSITIVITY,
    MODE_CONTROLLER,
    MODE_KBM,
    MODE_LABELS,
    MODE_OFF,
    MODES,
    VK_BACK,
    VK_DELETE,
    VK_ESCAPE,
    VK_F1,
    GamepadSettings,
    key_token,
    mouse_token,
    normalize_vk,
    token_label,
    vk_name,
)
from app.ui.game_card import DARK_BTN_STYLE, PURPLE_BTN_STYLE
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.online_fix.common import safe_slot
from app.ui.styles import CHECK_ICON_PATH

logger = logging.getLogger(__name__)
TAG = "[Android/GamepadUI]"

_TOGGLE_ACTION = "__toggle__"
_DIALOG_WIDTH = 580
_KBM_HEIGHT = 660

_MODE_HINTS = {
    MODE_OFF: "Không gửi tay cầm vào Android. Bàn phím và chuột vẫn dùng trực tiếp trong màn hình Android như cũ.",
    MODE_CONTROLLER: (
        "Mọi tay cầm cắm vào máy tính (Xbox, PlayStation, Switch, Steam Controller...) xuất hiện trong Android "
        "như một tay cầm Xbox thật, tối đa 4 chiếc. Tay cầm chỉ điều khiển game khi màn hình Android đang mở; "
        "giữ Back + Start 1 giây để trả tay cầm về giao diện Bob Gaming, giữ lần nữa để quay lại game."
    ),
    MODE_KBM: (
        "Bàn phím và chuột đóng vai một tay cầm Xbox trong Android. Bấm vào màn hình Android rồi bấm phím "
        "bật / tắt chế độ chơi: khi bật, các phím bên dưới thành nút tay cầm và chuột xoay camera (cần phải); "
        "khi tắt, bàn phím và chuột trở lại gõ chữ và chạm màn hình bình thường."
    ),
}

_MOUSE_BUTTON_NAMES = {
    Qt.MouseButton.LeftButton: "left",
    Qt.MouseButton.RightButton: "right",
    Qt.MouseButton.MiddleButton: "middle",
    Qt.MouseButton.XButton1: "x1",
    Qt.MouseButton.XButton2: "x2",
}

_DIALOG_STYLE = """
    QDialog { background-color: #0f1320; }
    QLabel { color: #cbd5e1; font-size: 12px; background: transparent; }
    QLabel#gpTitle { color: #f8fafc; font-size: 15px; font-weight: 700; }
    QLabel#gpSection { color: #a78bfa; font-size: 12px; font-weight: 700; }
    QLabel#gpHint { color: #94a3b8; font-size: 12px; }
    QFrame#gpCard { background-color: #151b2b; border: 1px solid #232c42; border-radius: 10px; }
    QScrollArea { background: transparent; border: none; }
    QScrollArea > QWidget > QWidget { background: transparent; }
    QCheckBox { color: #cbd5e1; font-size: 12px; spacing: 8px; background: transparent; }
    QCheckBox::indicator {
        width: 16px; height: 16px; border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.2); background: #1a2135;
    }
    QCheckBox::indicator:unchecked { image: none; }
    QCheckBox::indicator:checked { background: #8b5cf6; border-color: #a78bfa; image: url("__CHECK_ICON_PATH__"); }
    QSlider::groove:horizontal { height: 6px; background: #232c42; border-radius: 3px; }
    QSlider::sub-page:horizontal { background: #8b5cf6; border-radius: 3px; }
    QSlider::handle:horizontal {
        width: 14px; margin: -5px 0; border-radius: 7px; background: #f8fafc; border: 1px solid #8b5cf6;
    }
    QSlider::groove:horizontal:disabled { background: #1a2135; }
    QSlider::sub-page:horizontal:disabled { background: #3b3660; }
""".replace("__CHECK_ICON_PATH__", CHECK_ICON_PATH)

_MODE_BTN_STYLE = """
    QPushButton {
        background-color: #151b2b; color: #cbd5e1; border: 1px solid #263248; border-radius: 8px;
        padding: 0 14px; min-height: 34px; max-height: 34px; font-size: 12px; font-weight: 600;
    }
    QPushButton:hover { border-color: #8b5cf6; color: #f8fafc; }
    QPushButton:checked { background-color: rgba(139, 92, 246, 0.22); border-color: #8b5cf6; color: #ffffff; }
    QPushButton:disabled { color: #475569; border-color: #1b2233; }
"""

_BIND_BTN_STYLE = """
    QPushButton {
        background-color: #1a2135; color: #f1f5f9; border: 1px solid #2b3550; border-radius: 6px;
        padding: 0 10px; min-height: 26px; max-height: 26px; font-size: 12px; font-weight: 600;
    }
    QPushButton:hover { border-color: #8b5cf6; }
    QPushButton:disabled { color: #475569; border-color: #1b2233; background-color: #131827; }
"""
_BIND_BTN_RECORDING_STYLE = """
    QPushButton {
        background-color: rgba(139, 92, 246, 0.25); color: #ffffff; border: 1px solid #a78bfa; border-radius: 6px;
        padding: 0 10px; min-height: 26px; max-height: 26px; font-size: 12px; font-weight: 700;
    }
"""

_STATUS_COLORS = {STATE_ACTIVE: "#4ade80", STATE_READY: "#38bdf8", STATE_ERROR: "#f87171"}


class AndroidGamepadDialog(QDialog):
    """Edits a copy of the bridge settings; `result_settings` holds it after the dialog is accepted."""

    def __init__(self, bridge: AndroidGamepadBridge, settings: GamepadSettings, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._bridge = bridge
        self._settings = settings.copy()
        self.result_settings: GamepadSettings | None = None
        self._kbm_ok = kbm_supported()
        self._recording: str | None = None
        self._filter_installed = False
        self._mode_btns: dict[str, QPushButton] = {}
        self._bind_btns: dict[str, QPushButton] = {}

        self.setWindowTitle("Điều khiển Android bằng tay cầm")
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)
        self.setStyleSheet(_DIALOG_STYLE)
        self.setMinimumWidth(520)
        self.resize(_DIALOG_WIDTH, _KBM_HEIGHT)
        self._build_ui()
        self._load_into_ui()
        self._on_status(bridge.status)
        bridge.status_changed.connect(self._on_status)

    # ------------------------------------------------------------------ UI

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 18, 20, 16)
        root.setSpacing(12)

        head = QHBoxLayout()
        head.setSpacing(10)
        icon = QLabel()
        icon.setPixmap(make_svg_pixmap("gamepad", size=22, color="#a78bfa"))
        head.addWidget(icon)
        title = QLabel("Điều khiển Android bằng tay cầm")
        title.setObjectName("gpTitle")
        head.addWidget(title)
        head.addStretch()
        root.addLayout(head)

        self.status_lbl = QLabel("")
        self.status_lbl.setWordWrap(True)
        root.addWidget(self.status_lbl)

        mode_row = QHBoxLayout()
        mode_row.setSpacing(8)
        for mode, icon_name in ((MODE_OFF, "close"), (MODE_CONTROLLER, "gamepad"), (MODE_KBM, "keyboard")):
            btn = QPushButton(MODE_LABELS[mode])
            btn.setCheckable(True)
            btn.setAutoDefault(False)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(_MODE_BTN_STYLE)
            btn.setIcon(make_svg_icon(icon_name, size=15, color="#cbd5e1"))
            btn.clicked.connect(lambda _checked=False, m=mode: self._on_mode_clicked(m))
            self._mode_btns[mode] = btn
            mode_row.addWidget(btn, 1)
        if not self._kbm_ok:
            self._mode_btns[MODE_KBM].setEnabled(False)
            self._mode_btns[MODE_KBM].setToolTip("Phím + chuột giả tay cầm chỉ dùng được trên Windows")
        root.addLayout(mode_row)

        self.mode_hint_lbl = QLabel("")
        self.mode_hint_lbl.setObjectName("gpHint")
        self.mode_hint_lbl.setWordWrap(True)
        root.addWidget(self.mode_hint_lbl)

        # ---- Keyboard + mouse card
        self.kbm_card = QFrame()
        self.kbm_card.setObjectName("gpCard")
        card = QVBoxLayout(self.kbm_card)
        card.setContentsMargins(14, 12, 14, 12)
        card.setSpacing(10)

        section = QLabel("Phím + Chuột")
        section.setObjectName("gpSection")
        card.addWidget(section)

        toggle_row = QHBoxLayout()
        toggle_row.setSpacing(10)
        toggle_row.addWidget(QLabel("Phím bật / tắt chế độ chơi"))
        toggle_row.addStretch()
        self._bind_btns[_TOGGLE_ACTION] = self._make_bind_button(_TOGGLE_ACTION)
        toggle_row.addWidget(self._bind_btns[_TOGGLE_ACTION])
        card.addLayout(toggle_row)

        self.mouse_look_chk = QCheckBox("Chuột điều khiển cần phải (xoay camera) khi đang ở chế độ chơi")
        card.addWidget(self.mouse_look_chk)

        sens_row = QHBoxLayout()
        sens_row.setSpacing(10)
        sens_row.addWidget(QLabel("Độ nhạy chuột"))
        self.sens_slider = QSlider(Qt.Orientation.Horizontal)
        self.sens_slider.setRange(int(MIN_SENSITIVITY * 10), int(MAX_SENSITIVITY * 10))
        self.sens_slider.setSingleStep(1)
        self.sens_slider.setPageStep(5)
        sens_row.addWidget(self.sens_slider, 1)
        self.sens_value_lbl = QLabel("1.0x")
        self.sens_value_lbl.setFixedWidth(40)
        self.sens_value_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        sens_row.addWidget(self.sens_value_lbl)
        card.addLayout(sens_row)
        self.sens_slider.valueChanged.connect(self._on_sens_changed)
        self.mouse_look_chk.toggled.connect(self._sync_enabled)

        bind_hint = QLabel(
            "Bấm vào một ô rồi bấm phím hoặc nút chuột muốn gán. Esc để huỷ, Delete để bỏ gán. "
            "Nút chuột chỉ có tác dụng khi bật chuột điều khiển cần phải."
        )
        bind_hint.setObjectName("gpHint")
        bind_hint.setWordWrap(True)
        card.addWidget(bind_hint)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        holder = QWidget()
        grid = QGridLayout(holder)
        grid.setContentsMargins(0, 0, 6, 0)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(6)
        half = (len(ACTIONS) + 1) // 2
        for idx, (action, label) in enumerate(ACTIONS):
            col = 0 if idx < half else 2
            row = idx if idx < half else idx - half
            grid.addWidget(QLabel(label), row, col)
            btn = self._make_bind_button(action)
            self._bind_btns[action] = btn
            grid.addWidget(btn, row, col + 1)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(2, 1)
        grid.setColumnMinimumWidth(1, 112)
        grid.setColumnMinimumWidth(3, 112)
        scroll.setWidget(holder)
        card.addWidget(scroll, 1)
        root.addWidget(self.kbm_card, 1)
        self._spacer_index = root.count()
        root.addStretch(0)

        # ---- Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        self.reset_btn = QPushButton("Khôi phục mặc định")
        self.reset_btn.setAutoDefault(False)
        self.reset_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.reset_btn.setStyleSheet(DARK_BTN_STYLE)
        self.reset_btn.clicked.connect(self._on_reset)
        btn_row.addWidget(self.reset_btn)
        btn_row.addStretch()
        self.cancel_btn = QPushButton("Huỷ")
        self.cancel_btn.setAutoDefault(False)
        self.cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cancel_btn.setStyleSheet(DARK_BTN_STYLE)
        self.cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(self.cancel_btn)
        self.save_btn = QPushButton("Lưu")
        self.save_btn.setAutoDefault(False)
        self.save_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.save_btn.setStyleSheet(PURPLE_BTN_STYLE)
        self.save_btn.setIcon(make_svg_icon("save", size=14, color="#ffffff"))
        self.save_btn.clicked.connect(self._on_save)
        btn_row.addWidget(self.save_btn)
        root.addLayout(btn_row)

    def _make_bind_button(self, action: str) -> QPushButton:
        btn = QPushButton("")
        btn.setAutoDefault(False)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setStyleSheet(_BIND_BTN_STYLE)
        btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        btn.setMinimumWidth(112)
        btn.clicked.connect(lambda _checked=False, a=action: self._on_bind_clicked(a))
        return btn

    def _load_into_ui(self) -> None:
        if self._settings.mode == MODE_KBM and not self._kbm_ok:
            self._settings.mode = MODE_CONTROLLER
        self.mouse_look_chk.setChecked(self._settings.mouse_look)
        self.sens_slider.setValue(int(round(self._settings.mouse_sensitivity * 10)))
        self._on_sens_changed(self.sens_slider.value())
        self._refresh_bind_labels()
        self._select_mode(self._settings.mode)

    def _refresh_bind_labels(self) -> None:
        for action, btn in self._bind_btns.items():
            if action == self._recording:
                continue
            if action == _TOGGLE_ACTION:
                btn.setText(vk_name(self._settings.toggle_vk))
            else:
                btn.setText(token_label(self._settings.bindings.get(action, "")))

    def _select_mode(self, mode: str) -> None:
        self._settings.mode = mode
        for m, btn in self._mode_btns.items():
            btn.setChecked(m == mode)
        self.mode_hint_lbl.setText(_MODE_HINTS[mode])
        self._sync_enabled()

    def _sync_enabled(self) -> None:
        """The keyboard + mouse card only exists in that mode; the dialog shrinks to fit without it."""
        kbm = self._settings.mode == MODE_KBM and self._kbm_ok
        self.kbm_card.setVisible(kbm)
        self.reset_btn.setVisible(kbm)
        self.sens_slider.setEnabled(kbm and self.mouse_look_chk.isChecked())
        layout = self.layout()
        layout.setStretch(self._spacer_index, 0 if kbm else 1)
        layout.activate()
        if kbm:
            height = _KBM_HEIGHT
        elif layout.hasHeightForWidth():  # the word-wrapped hint decides how tall the compact dialog is
            height = layout.totalHeightForWidth(self.width())
        else:
            height = self.sizeHint().height()
        self.resize(self.width(), height)

    # ------------------------------------------------------------------ Slots

    @safe_slot
    def _on_status(self, status: BridgeStatus) -> None:
        color = _STATUS_COLORS.get(getattr(status, "state", ""), "#94a3b8")
        self.status_lbl.setStyleSheet(f"color: {color}; font-size: 12px; font-weight: 600;")
        self.status_lbl.setText(f"Trạng thái: {getattr(status, 'text', '')}")

    @safe_slot
    def _on_mode_clicked(self, mode: str) -> None:
        self._stop_recording()
        if mode in MODES:
            self._select_mode(mode)

    @safe_slot
    def _on_sens_changed(self, value: int) -> None:
        self.sens_value_lbl.setText(f"{value / 10.0:.1f}x")

    @safe_slot
    def _on_reset(self) -> None:
        self._stop_recording()
        self._settings.bindings = dict(DEFAULT_BINDINGS)
        self._settings.toggle_vk = VK_F1
        self._settings.mouse_look = True
        self._settings.mouse_sensitivity = 1.0
        self.mouse_look_chk.setChecked(True)
        self.sens_slider.setValue(10)
        self._refresh_bind_labels()
        logger.info(f"{TAG} Keyboard + mouse bindings reset to defaults (not saved yet)")

    @safe_slot
    def _on_save(self) -> None:
        self._stop_recording()
        self._settings.mouse_look = self.mouse_look_chk.isChecked()
        self._settings.mouse_sensitivity = self.sens_slider.value() / 10.0
        self.result_settings = self._settings.copy()
        self.accept()

    # ------------------------------------------------------------------ Binding capture

    @safe_slot
    def _on_bind_clicked(self, action: str) -> None:
        if self._recording == action:
            self._stop_recording()
            return
        self._stop_recording()
        self._recording = action
        btn = self._bind_btns[action]
        btn.setStyleSheet(_BIND_BTN_RECORDING_STYLE)
        btn.setText("Bấm phím..." if action == _TOGGLE_ACTION else "Bấm phím / chuột...")
        self.grabKeyboard()
        app = QApplication.instance()
        if app is not None and not self._filter_installed:
            app.installEventFilter(self)
            self._filter_installed = True

    def _stop_recording(self) -> None:
        if self._filter_installed:
            app = QApplication.instance()
            if app is not None:
                app.removeEventFilter(self)
            self._filter_installed = False
        if self._recording is None:
            return
        action, self._recording = self._recording, None
        self.releaseKeyboard()
        btn = self._bind_btns.get(action)
        if btn is not None:
            btn.setStyleSheet(_BIND_BTN_STYLE)
        self._refresh_bind_labels()

    def _assign(self, token: str) -> None:
        action = self._recording
        if action is None:
            return
        if action == _TOGGLE_ACTION:
            parts = token.split(":")
            if len(parts) == 2 and parts[0] == "K":
                self._settings.toggle_vk = int(parts[1])
                # The toggle key cannot also be a gamepad button.
                for other, current in self._settings.bindings.items():
                    if current == token:
                        self._settings.bindings[other] = ""
        else:
            if token == key_token(self._settings.toggle_vk):
                return  # reserved for switching game mode: keep recording
            self._settings.bind(action, token)
        self._stop_recording()

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802
        try:
            if self._recording is not None:
                event.accept()
                if event.isAutoRepeat():
                    return
                vk = normalize_vk(int(event.nativeVirtualKey() or 0))
                if vk == VK_ESCAPE:
                    self._stop_recording()
                elif vk in (VK_DELETE, VK_BACK) and self._recording != _TOGGLE_ACTION:
                    self._settings.bind(self._recording, "")
                    self._stop_recording()
                elif 0 < vk < 256:
                    self._assign(key_token(vk))
                return
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Recording a key binding failed")
            self._stop_recording()
            return
        super().keyPressEvent(event)

    def eventFilter(self, obj, event) -> bool:  # noqa: N802
        try:
            if self._recording is not None and event.type() in (
                QEvent.Type.MouseButtonPress,
                QEvent.Type.MouseButtonDblClick,
            ):
                if isinstance(obj, QWidget) and (obj is self or self.isAncestorOf(obj)):
                    name = _MOUSE_BUTTON_NAMES.get(event.button())
                    if self._recording == _TOGGLE_ACTION or name is None:
                        self._stop_recording()
                    else:
                        self._assign(mouse_token(name))
                    return True
        except Exception:  # noqa: BLE001
            logger.exception(f"{TAG} Recording a mouse binding failed")
            self._stop_recording()
        return False

    def done(self, result: int) -> None:
        self._stop_recording()
        super().done(result)

    def closeEvent(self, event) -> None:  # noqa: N802
        self._stop_recording()
        super().closeEvent(event)

