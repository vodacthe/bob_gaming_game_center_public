"""
Dark theme QSS stylesheet for Bob Gaming Game Center.
Unified Cyberpunk Titanium Violet & Emerald Design Language.
"""

import os
from app.config import get_app_dir

CHECK_ICON_PATH = os.path.join(get_app_dir(), "assets", "checkbox_check.svg").replace("\\", "/")

DARK_THEME = """
/* ======================== GLOBAL ======================== */
QWidget {
    color: #e2e8f0;
    font-family: "Segoe UI", "Segoe UI Symbol", -apple-system, Arial, sans-serif;
    font-size: 13px;
}

QMainWindow {
    background-color: transparent;
}

QDialog, QMessageBox, QMenu {
    background-color: #0d141e;
    color: #e2e8f0;
}

/* ======================== SCROLL AREA ======================== */
QScrollArea {
    border: none;
    background-color: transparent;
}

QScrollArea > QWidget > QWidget {
    background-color: transparent;
}

QScrollBar:vertical {
    background-color: rgba(255, 255, 255, 0.02);
    width: 6px;
    margin: 0;
    border-radius: 3px;
}

QScrollBar::handle:vertical {
    background-color: rgba(255, 255, 255, 0.14);
    border-radius: 3px;
    min-height: 32px;
}

QScrollBar::handle:vertical:hover {
    background-color: rgba(139, 92, 246, 0.5);
}

QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical {
    height: 0;
    border: none;
}

QScrollBar::add-page:vertical,
QScrollBar::sub-page:vertical {
    background: none;
}

QScrollBar:horizontal {
    background-color: rgba(255, 255, 255, 0.02);
    height: 6px;
    margin: 0;
    border-radius: 3px;
}

QScrollBar::handle:horizontal {
    background-color: rgba(255, 255, 255, 0.14);
    border-radius: 3px;
    min-width: 32px;
}

QScrollBar::handle:horizontal:hover {
    background-color: rgba(139, 92, 246, 0.5);
}

QScrollBar::add-line:horizontal,
QScrollBar::sub-line:horizontal {
    width: 0;
    border: none;
}

/* ======================== BUTTONS ======================== */
QPushButton {
    background-color: rgba(255, 255, 255, 0.06);
    color: #f1f5f9;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 8px;
    padding: 8px 18px;
    font-weight: 600;
    font-size: 13px;
    min-height: 20px;
    letter-spacing: 0.3px;
}

QPushButton:hover {
    background-color: rgba(255, 255, 255, 0.10);
    border: 1px solid rgba(139, 92, 246, 0.5);
    color: #ffffff;
}

QPushButton:pressed {
    background-color: rgba(255, 255, 255, 0.04);
    border-color: rgba(139, 92, 246, 0.3);
}

QPushButton:disabled {
    background-color: rgba(255, 255, 255, 0.02);
    border: 1px solid rgba(255, 255, 255, 0.05);
    color: #4b5563;
}

/* Primary Action Button (Electric Violet Gradient) */
QPushButton#primaryBtn, QPushButton.primaryBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #9333ea, stop:0.5 #7c3aed, stop:1 #4f46e5);
    color: #ffffff;
    border: none;
    border-radius: 8px;
    font-weight: 700;
}

QPushButton#primaryBtn:hover, QPushButton.primaryBtn:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #a855f7, stop:0.5 #8b5cf6, stop:1 #6366f1);
    color: #ffffff;
}

QPushButton#primaryBtn:pressed, QPushButton.primaryBtn:pressed {
    background: #4338ca;
    color: #ffffff;
}

QPushButton#secondaryBtn {
    background-color: rgba(30, 36, 56, 0.7);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 8px;
    color: #cbd5e1;
    font-weight: 600;
}

QPushButton#secondaryBtn:hover {
    background-color: rgba(45, 54, 82, 0.85);
    border: 1px solid rgba(139, 92, 246, 0.45);
    color: #ffffff;
}

QPushButton#secondaryBtn:pressed {
    background-color: rgba(25, 30, 48, 0.85);
}

/* Window Control Buttons (—, □, ✕) */
QPushButton#winMinBtn, QPushButton#winMaxBtn, QPushButton#winCloseBtn {
    background-color: transparent;
    border: none;
    border-radius: 4px;
    padding: 0;
    min-height: 0px;
}

QPushButton#winMinBtn:hover, QPushButton#winMaxBtn:hover {
    background-color: rgba(255, 255, 255, 0.12);
}

QPushButton#winMinBtn:pressed, QPushButton#winMaxBtn:pressed {
    background-color: rgba(255, 255, 255, 0.07);
}

QPushButton#winCloseBtn:hover {
    background-color: #e11d48;
}

QPushButton#winCloseBtn:pressed {
    background-color: #be123c;
}

QPushButton#dangerBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #dc2626, stop:1 #991b1b);
    border: 1px solid rgba(248, 113, 113, 0.4);
    color: #ffffff;
}

QPushButton#dangerBtn:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #ef4444, stop:1 #b91c1c);
    border-color: rgba(252, 165, 165, 0.6);
}

QPushButton#dangerBtn:disabled {
    background: rgba(220, 38, 38, 0.15);
    border: 1px solid rgba(248, 113, 113, 0.2);
    color: rgba(255, 255, 255, 0.35);
}

QPushButton#successBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #10b981, stop:1 #047857);
    border: 1px solid rgba(52, 211, 153, 0.4);
    color: #ffffff;
}

QPushButton#successBtn:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #34d399, stop:1 #059669);
    border-color: rgba(110, 231, 183, 0.6);
}

QPushButton#successBtn:disabled {
    background: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(52, 211, 153, 0.2);
    color: rgba(255, 255, 255, 0.35);
}

/* ======================== INPUT FIELDS ======================== */
QLineEdit, QTextEdit, QPlainTextEdit {
    background-color: rgba(14, 19, 29, 0.85);
    color: #f1f5f9;
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    padding: 8px 14px;
    font-size: 13px;
    selection-background-color: #7c3aed;
    selection-color: #ffffff;
}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {
    border: 1px solid rgba(139, 92, 246, 0.7);
    background-color: rgba(18, 22, 36, 0.95);
}

QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled {
    background-color: rgba(255, 255, 255, 0.02);
    color: #4b5563;
    border-color: rgba(255, 255, 255, 0.05);
}

QLineEdit[readOnly="true"] {
    background-color: rgba(14, 19, 29, 0.5);
    color: #94a3b8;
}

/* ======================== LABELS ======================== */
QLabel, QFrame QLabel, QFrame > QLabel {
    background-color: transparent;
    color: #e2e8f0;
    border: none;
}

QLabel#titleLabel {
    font-size: 22px;
    font-weight: 700;
    color: #ffffff;
    letter-spacing: -0.3px;
}

QLabel#subtitleLabel {
    font-size: 13px;
    color: #94a3b8;
}

QLabel#appTitle {
    font-size: 17px;
    font-weight: 800;
    color: #ffffff;
    letter-spacing: 0.5px;
    padding-left: 2px;
}

QLabel#errorLabel {
    color: #f87171;
    font-size: 12px;
}

QLabel#successLabel {
    color: #34d399;
    font-size: 12px;
}

QLabel#countLabel {
    color: #8c9bb0;
    font-size: 12px;
    padding: 4px 0;
}

/* ======================== CHECKBOX ======================== */
QCheckBox {
    color: #94a3b8;
    font-size: 12px;
    spacing: 8px;
    background: transparent;
}

QCheckBox::indicator {
    width: 17px;
    height: 17px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 4px;
    background-color: rgba(12, 16, 24, 0.8);
}

QCheckBox::indicator:hover {
    border-color: rgba(139, 92, 246, 0.6);
}

QCheckBox::indicator:unchecked {
    image: none;
}

QCheckBox::indicator:checked {
    background-color: #8b5cf6;
    border: 1px solid #a78bfa;
    image: url("__CHECK_ICON_PATH__");
}

QCheckBox::indicator:checked:hover {
    background-color: #7c3aed;
    border-color: #c084fc;
}

/* ======================== COMBOBOX ======================== */
QComboBox {
    background-color: rgba(16, 22, 33, 0.8);
    color: #f1f5f9;
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    padding: 7px 12px;
    min-height: 22px;
}

QComboBox:hover {
    border-color: rgba(139, 92, 246, 0.45);
}

QComboBox:focus {
    border: 1px solid rgba(139, 92, 246, 0.75);
}

QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 24px;
    border-left: none;
}

QComboBox QAbstractItemView {
    background-color: #111622;
    color: #f1f5f9;
    border: 1px solid rgba(139, 92, 246, 0.3);
    border-radius: 8px;
    selection-background-color: rgba(139, 92, 246, 0.25);
    selection-color: #ffffff;
    padding: 4px;
}

/* ======================== PROGRESS BAR ======================== */
QProgressBar {
    background-color: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.06);
    border-radius: 6px;
    text-align: center;
    color: #ffffff;
    font-size: 11px;
    min-height: 10px;
    max-height: 10px;
}

QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #8b5cf6, stop:1 #6d28d9);
    border-radius: 5px;
}

/* ======================== DIALOGS ======================== */
QDialog {
    background-color: #0d1118;
    border: 1px solid rgba(139, 92, 246, 0.25);
    border-radius: 14px;
}

QMessageBox {
    background-color: #0d1118;
    min-width: 440px;
    border: 1px solid rgba(139, 92, 246, 0.25);
    border-radius: 12px;
}

QMessageBox QLabel {
    color: #e2e8f0;
    font-size: 13px;
}

QMessageBox QPushButton {
    min-width: 100px;
    padding: 7px 16px;
    font-size: 12px;
}

/* ======================== TOOLTIP ======================== */
QToolTip {
    background-color: #121722;
    color: #f8fafc;
    border: 1px solid rgba(139, 92, 246, 0.35);
    border-radius: 6px;
    padding: 6px 11px;
    font-size: 12px;
}

/* ======================== GAME CARD ======================== */
#gameCard {
    background-color: #0d141e;
    border: 1px solid transparent;
    border-radius: 14px;
}

#gameCard:hover {
    border: 1px solid transparent;
    background-color: #0d141e;
}

#cardTitle {
    color: #ffffff;
    font-size: 13px;
    font-weight: 700;
    background-color: transparent;
    padding: 0;
}

#cardStatus,
#cardSyncStatus {
    font-size: 11px;
    font-weight: 500;
    color: #94a3b8;
    background-color: transparent;
}

/* Button styles for Game Card */
#cardActionPurple {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8e45ff, stop:1 #624df8);
    color: #ffffff;
    border: none;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 700;
    padding: 0px 12px;
    margin: 0px;
    height: 32px;
    min-height: 32px;
    max-height: 32px;
}

#cardActionPurple:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #9d5cff, stop:1 #7564f9);
}

#cardActionPurple:pressed {
    background: #523ee0;
}

#cardActionGreen {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00e676, stop:1 #00c853);
    color: #042612;
    border: none;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 800;
    padding: 0px 12px;
    margin: 0px;
    height: 32px;
    min-height: 32px;
    max-height: 32px;
}

#cardActionGreen:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2bf08d, stop:1 #10d866);
    color: #000000;
}

#cardActionGreen:pressed {
    background: #00a844;
}

#cardActionGold {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8e45ff, stop:1 #624df8);
    color: #ffffff;
    border: none;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 700;
    padding: 0px 12px;
    margin: 0px;
    height: 32px;
    min-height: 32px;
    max-height: 32px;
}

#cardActionDark {
    background-color: rgba(255, 255, 255, 0.08);
    color: #f1f5f9;
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    padding: 0px 12px;
    margin: 0px;
    height: 30px;
    min-height: 30px;
    max-height: 30px;
}

#cardActionDark:hover {
    background-color: rgba(255, 255, 255, 0.14);
    border-color: rgba(139, 92, 246, 0.5);
    color: #ffffff;
}

#cardActionDark:pressed {
    background-color: rgba(255, 255, 255, 0.04);
}

#cardActionMore {
    background-color: rgba(255, 255, 255, 0.07);
    color: #cbd5e1;
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 8px;
    font-weight: 900;
    font-size: 13px;
    padding: 0px;
    margin: 0px;
    height: 32px;
    min-height: 32px;
    max-height: 32px;
    width: 36px;
    min-width: 36px;
    max-width: 36px;
}

#cardActionMore:hover {
    background-color: rgba(255, 255, 255, 0.15);
    border-color: rgba(139, 92, 246, 0.5);
    color: #ffffff;
}

QPushButton#viewToggleBtn {
    background-color: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 8px;
    padding: 0;
}

QPushButton#viewToggleBtn:hover {
    background-color: rgba(255, 255, 255, 0.09);
    border-color: rgba(139, 92, 246, 0.4);
}

QPushButton#viewToggleBtn:checked {
    background: #7c3aed;
    border: 1px solid #8b5cf6;
}

#sortCombo, QComboBox#sortCombo {
    background-color: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 8px;
    color: #f1f5f9;
    padding: 5px 12px;
    font-size: 12px;
    font-weight: 500;
}

#sortCombo:hover, QComboBox#sortCombo:hover {
    border-color: rgba(139, 92, 246, 0.4);
}

QComboBox#sortCombo::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 22px;
    border-left: none;
}

QComboBox#sortCombo::down-arrow {
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid #94a3b8;
    width: 0;
    height: 0;
    margin-right: 8px;
}

QComboBox#sortCombo::down-arrow:hover {
    border-top: 5px solid #ffffff;
}

/* ======================== FILTER PILL TABS ======================== */
QPushButton#filterTabBtn {
    background-color: rgba(255, 255, 255, 0.05);
    color: #cbd5e1;
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    padding: 5px 10px;
    font-size: 11px;
    font-weight: 500;
}

QPushButton#filterTabBtn:hover {
    background-color: rgba(255, 255, 255, 0.09);
    border-color: rgba(139, 92, 246, 0.4);
    color: #ffffff;
}

QPushButton#filterTabBtn[active="true"] {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #7c3aed, stop:1 #6366f1);
    color: #ffffff;
    font-weight: 700;
    border: 1px solid #8b5cf6;
    border-radius: 8px;
}

/* ======================== STATUS BADGE ======================== */
#statusBadge {
    font-size: 10px;
    font-weight: 700;
    border-radius: 5px;
    padding: 2px 8px;
    color: white;
    background-color: transparent;
    letter-spacing: 0.3px;
}

/* ======================== LOGIN / GLASS CARD ======================== */
#loginCard, .glassCard {
    background-color: rgba(18, 23, 34, 0.85);
    border: 1px solid rgba(255, 255, 255, 0.09);
    border-radius: 16px;
}

#loginTitle {
    font-size: 26px;
    font-weight: 800;
    color: #ffffff;
    background: transparent;
    letter-spacing: -0.5px;
}

#loginSubtitle {
    font-size: 13px;
    color: #94a3b8;
    background: transparent;
}

/* ======================== LOADING OVERLAY ======================== */
#loadingOverlay {
    background-color: rgba(11, 14, 20, 0.92);
    border-radius: 12px;
}

#loadingText {
    color: #a855f7;
    font-size: 14px;
    font-weight: 600;
    background: transparent;
}

/* ======================== SEPARATOR ======================== */
#separator {
    background-color: rgba(255, 255, 255, 0.07);
    max-height: 1px;
    min-height: 1px;
}

/* ======================== HEADER BAR ======================== */
#headerBar {
    background-color: rgba(13, 16, 26, 0.40);
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    padding: 6px 20px;
}

/* ======================== SIDEBAR ======================== */
#sidebar {
    background-color: rgba(11, 13, 22, 0.82);
    border-right: 1px solid rgba(255, 255, 255, 0.06);
}

#sidebarHeader {
    padding: 16px 14px 12px 14px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.07);
}

#sidebarGroupLabel {
    color: #555a73;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 10px 10px 4px 10px;
}

#sidebarScroll QScrollBar:vertical {
    width: 4px;
    background: transparent;
    margin: 0;
    border-radius: 2px;
}

#sidebarScroll QScrollBar::handle:vertical {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 2px;
    min-height: 24px;
}

#sidebarScroll QScrollBar::handle:vertical:hover {
    background: rgba(139, 92, 246, 0.6);
}

#sidebarItem {
    background-color: transparent;
    color: #94a3b8;
    border: 1px solid transparent;
    border-radius: 8px;
    padding: 6px 10px;
    text-align: left;
    font-size: 13px;
    font-weight: 500;
}

#sidebarItem:hover {
    background-color: rgba(255, 255, 255, 0.05);
    color: #ffffff;
}

#sidebarItem[active="true"] {
    background: #581c87;
    border: 1px solid rgba(139, 92, 246, 0.4);
    border-radius: 8px;
    color: #ffffff;
    font-weight: 600;
}
""".replace("__CHECK_ICON_PATH__", CHECK_ICON_PATH)
