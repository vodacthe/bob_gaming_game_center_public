"""Steam Controller (2015) -> Xbox 360 (XInput) configuration and live preview panel.

Runs inside `ControllerMapperScreen` as the 3rd tab ("Steam Controller (XInput)"). All hardware I/O and driver
installation happen off the UI thread inside `SteamControllerService`.
"""

from __future__ import annotations

import functools
import inspect
import logging
from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSlider,
    QVBoxLayout,
    QWidget,
)
from shiboken6 import isValid

from app.core import gamepad_tester as gt
from app.core.steam_controller.protocol import (
    GRIP_TARGETS,
    GYRO_AXIS_MODES,
    LEFT_PAD_MODES,
    RIGHT_PAD_MODES,
    XUSB_A,
    XUSB_B,
    XUSB_BACK,
    XUSB_DPAD_DOWN,
    XUSB_DPAD_LEFT,
    XUSB_DPAD_RIGHT,
    XUSB_DPAD_UP,
    XUSB_GUIDE,
    XUSB_LEFT_SHOULDER,
    XUSB_LEFT_THUMB,
    XUSB_RIGHT_SHOULDER,
    XUSB_RIGHT_THUMB,
    XUSB_START,
    XUSB_X,
    XUSB_Y,
)
from app.core.steam_controller.service import DEFAULT_SERVICE_SETTINGS, SteamControllerService
from app.ui.controller_tester import GamepadDiagram
from app.ui.icons import make_svg_icon, make_svg_pixmap
from app.ui.screen_header import CONTENT_MARGINS
from app.ui.styles import CHEVRON_DOWN_ICON_PATH

logger = logging.getLogger(__name__)
TAG = "[UI/SteamController]"

_CARD_STYLE = (
    "QFrame#scCard { background-color: rgba(18, 24, 38, 0.86); border: 1px solid rgba(255, 255, 255, 0.08);"
    " border-radius: 12px; }"
    " QLabel { background: transparent; border: none; color: #cbd5e1; }"
)
_COMBO_STYLE = (
    "QComboBox { background-color: #0f172a; color: #f8fafc; border: 1px solid #2a3448; border-radius: 8px;"
    " padding: 6px 12px; font-size: 12px; min-height: 20px; }"
    " QComboBox:hover { border-color: #38bdf8; }"
    " QComboBox::drop-down { subcontrol-origin: padding; subcontrol-position: top right; width: 26px;"
    " border-left: 1px solid #2a3448; border-top-right-radius: 8px; border-bottom-right-radius: 8px;"
    " background-color: rgba(255, 255, 255, 0.04); }"
    ' QComboBox::down-arrow { image: url("__CHEVRON__"); width: 12px; height: 12px; margin-right: 4px; border: none; }'
    " QComboBox QAbstractItemView { background-color: #161e2e; color: #f8fafc; border: 1px solid #2a3448;"
    " border-radius: 8px; selection-background-color: rgba(16, 185, 129, 0.25); selection-color: #ffffff;"
    " padding: 4px; outline: none; }"
).replace("__CHEVRON__", CHEVRON_DOWN_ICON_PATH)

_CHECKBOX_STYLE = (
    "QCheckBox { color: #cbd5e1; font-size: 12px; spacing: 8px; background: transparent; }"
    " QCheckBox::indicator { width: 16px; height: 16px; border-radius: 4px; border: 1px solid #475569;"
    " background-color: #0f172a; }"
    " QCheckBox::indicator:checked { background-color: #10b981; border-color: #10b981; }"
)

_SLIDER_STYLE = (
    "QSlider::groove:horizontal { height: 6px; background: #1e293b; border-radius: 3px; }"
    " QSlider::sub-page:horizontal { background: #10b981; border-radius: 3px; }"
    " QSlider::handle:horizontal { background: #f8fafc; border: 2px solid #10b981; width: 14px; height: 14px;"
    " margin: -5px 0; border-radius: 8px; }"
)

_BTN_START_STYLE = (
    "QPushButton { background-color: #10b981; color: #052e16; border: none; border-radius: 8px;"
    " padding: 8px 18px; font-size: 12px; font-weight: bold; }"
    " QPushButton:hover { background-color: #34d399; }"
    " QPushButton:disabled { background-color: #1e293b; color: #64748b; }"
)
_BTN_STOP_STYLE = (
    "QPushButton { background-color: rgba(239, 68, 68, 0.18); color: #fca5a5;"
    " border: 1px solid rgba(239, 68, 68, 0.45); border-radius: 8px; padding: 8px 18px;"
    " font-size: 12px; font-weight: bold; }"
    " QPushButton:hover { background-color: rgba(239, 68, 68, 0.30); }"
)
_BTN_SECONDARY_STYLE = (
    "QPushButton { background-color: rgba(255, 255, 255, 0.06); color: #e2e8f0;"
    " border: 1px solid rgba(255, 255, 255, 0.14); border-radius: 8px; padding: 7px 14px; font-size: 12px; }"
    " QPushButton:hover { background-color: rgba(255, 255, 255, 0.12); }"
    " QPushButton:disabled { color: #64748b; background-color: transparent; }"
)
_BTN_INSTALL_STYLE = (
    "QPushButton { background-color: #eab308; color: #1c1917; border: none; border-radius: 8px;"
    " padding: 7px 16px; font-size: 12px; font-weight: bold; }"
    " QPushButton:hover { background-color: #facc15; }"
    " QPushButton:disabled { background-color: #334155; color: #94a3b8; }"
)

_LPAD_LABELS = {
    "dpad_click": "Nhấn xuống mới nhận D-Pad (Khuyên dùng)",
    "dpad_touch": "Chạm nhẹ là nhận D-Pad (Cảm ứng 8 hướng)",
    "off": "Tắt bàn rê trái",
}
_RPAD_LABELS = {
    "joystick": "Cần gạt tuyệt đối (Giữ tay ở đâu cần ở đó - Khuyên dùng)",
    "trackball": "Trackball vuốt chuột có quán tính",
    "off": "Tắt bàn rê phải",
}
_GYRO_AXIS_LABELS = {
    "yaw": "Yaw + Pitch (Lia cổ tay trái/phải - Khuyên dùng)",
    "roll": "Roll + Pitch (Nghiêng tay cầm như vô-lăng)",
    "yaw_roll": "Kết hợp cả Yaw và Roll",
}


def _safe(func):
    params = list(inspect.signature(func).parameters.values())[1:]
    accepts_varargs = any(p.kind is inspect.Parameter.VAR_POSITIONAL for p in params)
    max_args = len([p for p in params if p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)])

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if not accepts_varargs:
            args = args[:max_args]
        try:
            return func(self, *args, **kwargs)
        except Exception:  # noqa: BLE001
            logger.exception("%s %s failed", TAG, func.__name__)
            if isValid(self) and hasattr(self, "detail_label"):
                self.detail_label.setText("Đã xảy ra lỗi không mong muốn — xem Nhật ký hệ thống để biết chi tiết.")
            return None

    return wrapper


def xbox_dict_to_device_state(xbox: dict[str, Any], label: str = "Virtual Xbox 360") -> gt.DeviceState:
    """Convert `XboxState` dict (+Y = Up) into `gt.DeviceState` (+Y = Down in `gc_axes`) for `GamepadDiagram`."""
    xb = int(xbox.get("buttons", 0))
    lx = int(xbox.get("lx", 0))
    ly = int(xbox.get("ly", 0))
    rx = int(xbox.get("rx", 0))
    ry = int(xbox.get("ry", 0))
    lt = int(xbox.get("left_trigger", 0))
    rt = int(xbox.get("right_trigger", 0))

    gc_buttons = {
        "A": bool(xb & XUSB_A),
        "B": bool(xb & XUSB_B),
        "X": bool(xb & XUSB_X),
        "Y": bool(xb & XUSB_Y),
        "LB": bool(xb & XUSB_LEFT_SHOULDER),
        "RB": bool(xb & XUSB_RIGHT_SHOULDER),
        "Back": bool(xb & XUSB_BACK),
        "Guide": bool(xb & XUSB_GUIDE),
        "Start": bool(xb & XUSB_START),
        "LS": bool(xb & XUSB_LEFT_THUMB),
        "RS": bool(xb & XUSB_RIGHT_THUMB),
        "DPadUp": bool(xb & XUSB_DPAD_UP),
        "DPadDown": bool(xb & XUSB_DPAD_DOWN),
        "DPadLeft": bool(xb & XUSB_DPAD_LEFT),
        "DPadRight": bool(xb & XUSB_DPAD_RIGHT),
    }
    gc_axes = {
        "LeftX": lx,
        "LeftY": max(-32768, min(32767, -ly)),
        "RightX": rx,
        "RightY": max(-32768, min(32767, -ry)),
        "TriggerLeft": int(round((lt / 255.0) * 32767)),
        "TriggerRight": int(round((rt / 255.0) * 32767)),
    }
    return gt.DeviceState(
        name=label,
        type_id=1,
        is_controller=True,
        gc_buttons=gc_buttons,
        gc_axes=gc_axes,
    )


class SteamControllerPanel(QWidget):
    """Tab widget for configuring and monitoring Steam Controller (2015) -> Xbox 360 translation."""

    def __init__(self, service: SteamControllerService | None = None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._service = service
        self._loading_controls = False
        self._signals_connected = False

        self._build_ui()
        self._load_settings_into_controls()

        if self._service is not None:
            self._service.status_changed.connect(self._on_status_changed)
            self._service.live_preview.connect(self._on_live_preview)
            self._service.driver_install_progress.connect(self._on_install_progress)
            self._service.driver_install_finished.connect(self._on_install_finished)
            self._signals_connected = True
            self._apply_status(self._service.refresh_environment_status() if not self._service.is_running() else self._service.get_status())
        else:
            self._apply_status({
                "running": False,
                "state": "stopped",
                "driver_ok": False,
                "driver_message": "Dịch vụ chưa được khởi tạo",
                "steam_running": False,
                "connected_count": 0,
                "devices": [],
                "error": "",
            })

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { border: none; background-color: #0a0e17; }")
        outer.addWidget(scroll)

        content = QWidget()
        content.setStyleSheet("background-color: #0a0e17;")
        scroll.setWidget(content)

        root = QVBoxLayout(content)
        root.setContentsMargins(CONTENT_MARGINS[0], 16, CONTENT_MARGINS[2], 20)
        root.setSpacing(14)

        # 1. Hero Status & Toggle Card
        hero = QFrame()
        hero.setObjectName("scCard")
        hero.setStyleSheet(_CARD_STYLE)
        root.addWidget(hero)
        hero_lay = QVBoxLayout(hero)
        hero_lay.setContentsMargins(18, 16, 18, 16)
        hero_lay.setSpacing(12)

        top_row = QHBoxLayout()
        top_row.setSpacing(12)
        hero_lay.addLayout(top_row)

        icon_lbl = QLabel()
        icon_lbl.setPixmap(make_svg_pixmap("controller", size=26, color="#10b981"))
        icon_lbl.setFixedSize(32, 32)
        top_row.addWidget(icon_lbl)

        title_col = QVBoxLayout()
        title_col.setSpacing(4)
        top_row.addLayout(title_col, 1)

        title_line = QHBoxLayout()
        title_line.setSpacing(10)
        title_col.addLayout(title_line)

        title_lbl = QLabel("Steam Controller (2015) sang Xbox 360 (XInput)")
        title_lbl.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        title_lbl.setStyleSheet("color: #f8fafc;")
        title_line.addWidget(title_lbl)

        self.status_badge = QLabel("Đã tắt")
        self.status_badge.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        title_line.addWidget(self.status_badge)
        title_line.addStretch()

        self.detail_label = QLabel(
            "Dùng trực tiếp qua cáp USB, đầu thu không dây 2.4GHz hoặc Bluetooth LE mà không cần chạy Steam."
        )
        self.detail_label.setWordWrap(True)
        self.detail_label.setStyleSheet("color: #94a3b8; font-size: 12px;")
        title_col.addWidget(self.detail_label)

        self.refresh_btn = QPushButton("Kiểm tra lại")
        self.refresh_btn.setIcon(make_svg_icon("refresh", size=14, color="#e2e8f0"))
        self.refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.refresh_btn.setStyleSheet(_BTN_SECONDARY_STYLE)
        self.refresh_btn.clicked.connect(self._on_refresh_clicked)
        top_row.addWidget(self.refresh_btn)

        self.toggle_btn = QPushButton("Bật giả lập XInput")
        self.toggle_btn.setIcon(make_svg_icon("play", size=14, color="#052e16"))
        self.toggle_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.toggle_btn.setStyleSheet(_BTN_START_STYLE)
        self.toggle_btn.clicked.connect(self._on_toggle_clicked)
        top_row.addWidget(self.toggle_btn)

        # Driver install sub-banner (hidden when ViGEmBus is installed)
        self.driver_banner = QFrame()
        self.driver_banner.setStyleSheet(
            "QFrame { background-color: rgba(234, 179, 8, 0.10); border: 1px solid rgba(234, 179, 8, 0.35);"
            " border-radius: 8px; }"
        )
        hero_lay.addWidget(self.driver_banner)
        drv_lay = QVBoxLayout(self.driver_banner)
        drv_lay.setContentsMargins(14, 10, 14, 10)
        drv_lay.setSpacing(8)

        drv_row = QHBoxLayout()
        drv_row.setSpacing(10)
        drv_lay.addLayout(drv_row)

        drv_icon = QLabel()
        drv_icon.setPixmap(make_svg_pixmap("alert", size=18, color="#facc15"))
        drv_row.addWidget(drv_icon)

        self.driver_msg_lbl = QLabel(
            "Chưa cài đặt driver ảo ViGEmBus v1.22.0 (~6.3 MB, ký số Microsoft WHQL). Cần cài một lần duy nhất để tạo tay cầm Xbox 360."
        )
        self.driver_msg_lbl.setWordWrap(True)
        self.driver_msg_lbl.setStyleSheet("color: #fef08a; font-size: 12px; border: none; background: transparent;")
        drv_row.addWidget(self.driver_msg_lbl, 1)

        self.install_drv_btn = QPushButton("Tải và cài đặt ViGEmBus")
        self.install_drv_btn.setIcon(make_svg_icon("download", size=14, color="#1c1917"))
        self.install_drv_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.install_drv_btn.setStyleSheet(_BTN_INSTALL_STYLE)
        self.install_drv_btn.clicked.connect(self._on_install_driver_clicked)
        drv_row.addWidget(self.install_drv_btn)

        self.install_progress = QProgressBar()
        self.install_progress.setRange(0, 100)
        self.install_progress.setFixedHeight(10)
        self.install_progress.setTextVisible(False)
        self.install_progress.setStyleSheet(
            "QProgressBar { background-color: #1e293b; border: none; border-radius: 5px; }"
            " QProgressBar::chunk { background-color: #eab308; border-radius: 5px; }"
        )
        drv_lay.addWidget(self.install_progress)
        self.install_progress.hide()
        self.driver_banner.hide()

        # Steam conflict sub-banner (hidden unless steam.exe is detected)
        self.steam_banner = QFrame()
        self.steam_banner.setStyleSheet(
            "QFrame { background-color: rgba(56, 189, 248, 0.10); border: 1px solid rgba(56, 189, 248, 0.35);"
            " border-radius: 8px; }"
        )
        hero_lay.addWidget(self.steam_banner)
        st_row = QHBoxLayout(self.steam_banner)
        st_row.setContentsMargins(14, 9, 14, 9)
        st_row.setSpacing(10)
        st_icon = QLabel()
        st_icon.setPixmap(make_svg_pixmap("steam", size=18, color="#38bdf8"))
        st_row.addWidget(st_icon)
        self.steam_msg_lbl = QLabel(
            "Phát hiện tiến trình steam.exe đang chạy — bộ chuyển đổi tự tạm dừng để tránh nhận đúp nút với Steam Input."
        )
        self.steam_msg_lbl.setWordWrap(True)
        self.steam_msg_lbl.setStyleSheet("color: #bae6fd; font-size: 12px; border: none; background: transparent;")
        st_row.addWidget(self.steam_msg_lbl, 1)
        self.steam_banner.hide()

        # 2. Body Columns: Left = Settings, Right = Live Xbox 360 Preview
        body = QHBoxLayout()
        body.setSpacing(14)
        root.addLayout(body)

        # Left column: Configuration
        cfg_card = QFrame()
        cfg_card.setObjectName("scCard")
        cfg_card.setStyleSheet(_CARD_STYLE)
        body.addWidget(cfg_card, 3)
        cfg_lay = QVBoxLayout(cfg_card)
        cfg_lay.setContentsMargins(18, 16, 18, 16)
        cfg_lay.setSpacing(12)

        cfg_head = QHBoxLayout()
        cfg_head.setSpacing(8)
        cfg_lay.addLayout(cfg_head)
        cfg_icon = QLabel()
        cfg_icon.setPixmap(make_svg_pixmap("sliders", size=16, color="#38bdf8"))
        cfg_head.addWidget(cfg_icon)
        cfg_title = QLabel("CẤU HÌNH ÁNH XẠ VÀ BÀN RÊ CẢM ỨNG")
        cfg_title.setStyleSheet("color: #38bdf8; font-weight: bold; font-size: 11px; letter-spacing: 1px;")
        cfg_head.addWidget(cfg_title)
        cfg_head.addStretch()

        self.reset_btn = QPushButton("Khôi phục mặc định")
        self.reset_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.reset_btn.setStyleSheet(_BTN_SECONDARY_STYLE)
        self.reset_btn.clicked.connect(self._on_reset_defaults)
        cfg_head.addWidget(self.reset_btn)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(10)
        cfg_lay.addLayout(form)

        self.lpad_combo = QComboBox()
        self.lpad_combo.setStyleSheet(_COMBO_STYLE)
        for mode in LEFT_PAD_MODES:
            self.lpad_combo.addItem(_LPAD_LABELS[mode], mode)
        self.lpad_combo.currentIndexChanged.connect(self._on_setting_changed)
        form.addRow(QLabel("Bàn rê trái (D-Pad):"), self.lpad_combo)

        self.rpad_combo = QComboBox()
        self.rpad_combo.setStyleSheet(_COMBO_STYLE)
        for mode in RIGHT_PAD_MODES:
            self.rpad_combo.addItem(_RPAD_LABELS[mode], mode)
        self.rpad_combo.currentIndexChanged.connect(self._on_setting_changed)
        form.addRow(QLabel("Bàn rê phải (Cần phải RS):"), self.rpad_combo)

        sens_row = QHBoxLayout()
        sens_row.setSpacing(10)
        self.sens_slider = QSlider(Qt.Orientation.Horizontal)
        self.sens_slider.setRange(25, 300)
        self.sens_slider.setSingleStep(5)
        self.sens_slider.setStyleSheet(_SLIDER_STYLE)
        self.sens_val_lbl = QLabel("1.00x")
        self.sens_val_lbl.setFixedWidth(48)
        self.sens_val_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.sens_val_lbl.setStyleSheet("color: #f8fafc; font-weight: bold;")
        self.sens_slider.valueChanged.connect(self._on_slider_changed)
        self.sens_slider.sliderReleased.connect(self._on_setting_changed)
        sens_row.addWidget(self.sens_slider, 1)
        sens_row.addWidget(self.sens_val_lbl)
        form.addRow(QLabel("Độ nhạy bàn rê phải:"), sens_row)

        msens_row = QHBoxLayout()
        msens_row.setSpacing(10)
        self.mouse_sens_slider = QSlider(Qt.Orientation.Horizontal)
        self.mouse_sens_slider.setRange(20, 300)
        self.mouse_sens_slider.setSingleStep(5)
        self.mouse_sens_slider.setStyleSheet(_SLIDER_STYLE)
        self.mouse_sens_val_lbl = QLabel("1.00x")
        self.mouse_sens_val_lbl.setFixedWidth(48)
        self.mouse_sens_val_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.mouse_sens_val_lbl.setStyleSheet("color: #f8fafc; font-weight: bold;")
        self.mouse_sens_slider.valueChanged.connect(self._on_slider_changed)
        self.mouse_sens_slider.sliderReleased.connect(self._on_setting_changed)
        msens_row.addWidget(self.mouse_sens_slider, 1)
        msens_row.addWidget(self.mouse_sens_val_lbl)
        form.addRow(QLabel("Độ nhạy con trỏ chuột:"), msens_row)

        dz_row = QHBoxLayout()
        dz_row.setSpacing(10)
        self.dz_slider = QSlider(Qt.Orientation.Horizontal)
        self.dz_slider.setRange(0, 40)
        self.dz_slider.setSingleStep(1)
        self.dz_slider.setStyleSheet(_SLIDER_STYLE)
        self.dz_val_lbl = QLabel("12%")
        self.dz_val_lbl.setFixedWidth(48)
        self.dz_val_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.dz_val_lbl.setStyleSheet("color: #f8fafc; font-weight: bold;")
        self.dz_slider.valueChanged.connect(self._on_slider_changed)
        self.dz_slider.sliderReleased.connect(self._on_setting_changed)
        dz_row.addWidget(self.dz_slider, 1)
        dz_row.addWidget(self.dz_val_lbl)
        form.addRow(QLabel("Vùng chết tâm (Deadzone):"), dz_row)

        outer_row = QHBoxLayout()
        outer_row.setSpacing(10)
        self.outer_slider = QSlider(Qt.Orientation.Horizontal)
        self.outer_slider.setRange(60, 100)
        self.outer_slider.setSingleStep(1)
        self.outer_slider.setStyleSheet(_SLIDER_STYLE)
        self.outer_val_lbl = QLabel("90%")
        self.outer_val_lbl.setFixedWidth(48)
        self.outer_val_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.outer_val_lbl.setStyleSheet("color: #f8fafc; font-weight: bold;")
        self.outer_slider.valueChanged.connect(self._on_slider_changed)
        self.outer_slider.sliderReleased.connect(self._on_setting_changed)
        outer_row.addWidget(self.outer_slider, 1)
        outer_row.addWidget(self.outer_val_lbl)
        form.addRow(QLabel("Ngưỡng đạt 100% biên ngoài:"), outer_row)

        self.lg_combo = QComboBox()
        self.lg_combo.setStyleSheet(_COMBO_STYLE)
        self.rg_combo = QComboBox()
        self.rg_combo.setStyleSheet(_COMBO_STYLE)
        for key, (label, _mask) in GRIP_TARGETS.items():
            self.lg_combo.addItem(label, key)
            self.rg_combo.addItem(label, key)
        self.lg_combo.currentIndexChanged.connect(self._on_setting_changed)
        self.rg_combo.currentIndexChanged.connect(self._on_setting_changed)
        form.addRow(QLabel("Nút mặt lưng trái (LG):"), self.lg_combo)
        form.addRow(QLabel("Nút mặt lưng phải (RG):"), self.rg_combo)

        self.gyro_axis_combo = QComboBox()
        self.gyro_axis_combo.setStyleSheet(_COMBO_STYLE)
        for gmode in GYRO_AXIS_MODES:
            self.gyro_axis_combo.addItem(_GYRO_AXIS_LABELS[gmode], gmode)
        self.gyro_axis_combo.currentIndexChanged.connect(self._on_setting_changed)
        form.addRow(QLabel("Trục ngang ngắm Gyro:"), self.gyro_axis_combo)

        for combo in (self.lpad_combo, self.rpad_combo, self.lg_combo, self.rg_combo, self.gyro_axis_combo):
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            combo.setMinimumContentsLength(16)

        gsens_row = QHBoxLayout()
        gsens_row.setSpacing(10)
        self.gyro_sens_slider = QSlider(Qt.Orientation.Horizontal)
        self.gyro_sens_slider.setRange(25, 400)
        self.gyro_sens_slider.setSingleStep(5)
        self.gyro_sens_slider.setStyleSheet(_SLIDER_STYLE)
        self.gyro_sens_val_lbl = QLabel("1.00x")
        self.gyro_sens_val_lbl.setFixedWidth(48)
        self.gyro_sens_val_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.gyro_sens_val_lbl.setStyleSheet("color: #f8fafc; font-weight: bold;")
        self.gyro_sens_slider.valueChanged.connect(self._on_slider_changed)
        self.gyro_sens_slider.sliderReleased.connect(self._on_setting_changed)
        gsens_row.addWidget(self.gyro_sens_slider, 1)
        gsens_row.addWidget(self.gyro_sens_val_lbl)
        form.addRow(QLabel("Độ nhạy ngắm Gyro:"), gsens_row)

        self.invert_y_chk = QCheckBox("Đảo ngược trục dọc (Y) của bàn rê phải")
        self.invert_y_chk.setStyleSheet(_CHECKBOX_STYLE)
        self.invert_y_chk.toggled.connect(self._on_setting_changed)
        cfg_lay.addWidget(self.invert_y_chk)

        self.invert_gyro_x_chk = QCheckBox("Đảo ngược trục ngang (X) khi ngắm Gyro")
        self.invert_gyro_x_chk.setStyleSheet(_CHECKBOX_STYLE)
        self.invert_gyro_x_chk.toggled.connect(self._on_setting_changed)
        cfg_lay.addWidget(self.invert_gyro_x_chk)

        self.invert_gyro_y_chk = QCheckBox("Đảo ngược trục dọc (Y) khi ngắm Gyro")
        self.invert_gyro_y_chk.setStyleSheet(_CHECKBOX_STYLE)
        self.invert_gyro_y_chk.toggled.connect(self._on_setting_changed)
        cfg_lay.addWidget(self.invert_gyro_y_chk)

        self.lizard_chk = QCheckBox(
            "Tự tắt Lizard Mode (chuột và phím mặc định của firmware) khi bật, khôi phục khi dừng"
        )
        self.lizard_chk.setStyleSheet(_CHECKBOX_STYLE)
        self.lizard_chk.toggled.connect(self._on_setting_changed)
        cfg_lay.addWidget(self.lizard_chk)

        self.haptics_chk = QCheckBox("Bật phản hồi Haptics (rung bàn rê cảm ứng và rung game XInput)")
        self.haptics_chk.setStyleSheet(_CHECKBOX_STYLE)
        self.haptics_chk.toggled.connect(self._on_setting_changed)
        cfg_lay.addWidget(self.haptics_chk)

        self.pause_steam_chk = QCheckBox("Tự tạm dừng giả lập khi phát hiện Steam đang chạy")
        self.pause_steam_chk.setStyleSheet(_CHECKBOX_STYLE)
        self.pause_steam_chk.toggled.connect(self._on_setting_changed)
        cfg_lay.addWidget(self.pause_steam_chk)
        cfg_lay.addStretch()

        # Right column: Live Xbox 360 Preview
        prev_card = QFrame()
        prev_card.setObjectName("scCard")
        prev_card.setStyleSheet(_CARD_STYLE)
        body.addWidget(prev_card, 2)
        prev_lay = QVBoxLayout(prev_card)
        prev_lay.setContentsMargins(18, 16, 18, 16)
        prev_lay.setSpacing(10)

        prev_head = QHBoxLayout()
        prev_head.setSpacing(8)
        prev_lay.addLayout(prev_head)
        prev_icon = QLabel()
        prev_icon.setPixmap(make_svg_pixmap("gamepad", size=16, color="#10b981"))
        prev_head.addWidget(prev_icon)
        prev_title = QLabel("TÍN HIỆU XBOX 360 ĐẦU RA")
        prev_title.setStyleSheet("color: #10b981; font-weight: bold; font-size: 11px; letter-spacing: 1px;")
        prev_head.addWidget(prev_title)
        prev_head.addStretch()

        self.diagram = GamepadDiagram()
        self.diagram.setFixedHeight(225)
        self.diagram.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        prev_lay.addWidget(self.diagram)

        self.telemetry_label = QLabel("LS: (+0, +0)  |  RS: (+0, +0)\nLT: 0  RT: 0  |  Gyro: (+0, +0, +0)")
        self.telemetry_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.telemetry_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.telemetry_label.setStyleSheet(
            "color: #94a3b8; font-family: Consolas, monospace; font-size: 11px;"
            " background-color: rgba(15, 23, 42, 0.75); border-radius: 6px; padding: 6px 8px;"
        )
        prev_lay.addWidget(self.telemetry_label)
        prev_lay.addStretch(1)

        root.addStretch()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if self._service is not None:
            self._service.set_preview_enabled(True)
            if not self._service.is_running():
                self._apply_status(self._service.refresh_environment_status())

    def hideEvent(self, event) -> None:
        super().hideEvent(event)
        if self._service is not None:
            self._service.set_preview_enabled(False)

    def cleanup(self) -> None:
        if self._service is not None:
            self._service.set_preview_enabled(False)
            if self._signals_connected:
                self._signals_connected = False
                for sig, slot in (
                    (self._service.status_changed, self._on_status_changed),
                    (self._service.live_preview, self._on_live_preview),
                    (self._service.driver_install_progress, self._on_install_progress),
                    (self._service.driver_install_finished, self._on_install_finished),
                ):
                    try:
                        sig.disconnect(slot)
                    except (RuntimeError, TypeError):
                        pass

    def _load_settings_into_controls(self) -> None:
        settings = self._service.get_settings() if self._service is not None else dict(DEFAULT_SERVICE_SETTINGS)
        self._loading_controls = True
        try:
            self._select_combo_data(self.lpad_combo, settings["left_pad_mode"])
            self._select_combo_data(self.rpad_combo, settings["right_pad_mode"])
            sens_int = int(round(float(settings["right_pad_sensitivity"]) * 100))
            self.sens_slider.setValue(max(25, min(300, sens_int)))
            self.sens_val_lbl.setText(f"{self.sens_slider.value() / 100.0:.2f}x")
            msens_int = int(round(float(settings.get("mouse_sensitivity", 1.0)) * 100))
            self.mouse_sens_slider.setValue(max(20, min(300, msens_int)))
            self.mouse_sens_val_lbl.setText(f"{self.mouse_sens_slider.value() / 100.0:.2f}x")
            dz_int = int(settings["deadzone_percent"])
            self.dz_slider.setValue(max(0, min(40, dz_int)))
            self.dz_val_lbl.setText(f"{self.dz_slider.value()}%")
            outer_int = int(settings.get("stick_outer_percent", 90))
            self.outer_slider.setValue(max(60, min(100, outer_int)))
            self.outer_val_lbl.setText(f"{self.outer_slider.value()}%")
            self._select_combo_data(self.lg_combo, settings["left_grip_button"])
            self._select_combo_data(self.rg_combo, settings["right_grip_button"])
            self._select_combo_data(self.gyro_axis_combo, settings["gyro_axis_mode"])
            gsens_int = int(round(float(settings["gyro_sensitivity"]) * 100))
            self.gyro_sens_slider.setValue(max(25, min(400, gsens_int)))
            self.gyro_sens_val_lbl.setText(f"{self.gyro_sens_slider.value() / 100.0:.2f}x")
            self.invert_y_chk.setChecked(bool(settings["invert_right_y"]))
            self.invert_gyro_x_chk.setChecked(bool(settings["invert_gyro_x"]))
            self.invert_gyro_y_chk.setChecked(bool(settings["invert_gyro_y"]))
            self.lizard_chk.setChecked(bool(settings["manage_lizard_mode"]))
            self.haptics_chk.setChecked(bool(settings["haptics_enabled"]))
            self.pause_steam_chk.setChecked(bool(settings["pause_when_steam_running"]))
        finally:
            self._loading_controls = False

    @staticmethod
    def _select_combo_data(combo: QComboBox, value: Any) -> None:
        idx = combo.findData(value)
        if idx >= 0:
            combo.setCurrentIndex(idx)

    def _collect_settings_from_controls(self) -> dict[str, Any]:
        return {
            "left_pad_mode": self.lpad_combo.currentData(),
            "right_pad_mode": self.rpad_combo.currentData(),
            "right_pad_sensitivity": round(self.sens_slider.value() / 100.0, 2),
            "mouse_sensitivity": round(self.mouse_sens_slider.value() / 100.0, 2),
            "deadzone_percent": int(self.dz_slider.value()),
            "stick_outer_percent": int(self.outer_slider.value()),
            "left_grip_button": self.lg_combo.currentData(),
            "right_grip_button": self.rg_combo.currentData(),
            "gyro_axis_mode": self.gyro_axis_combo.currentData(),
            "gyro_sensitivity": round(self.gyro_sens_slider.value() / 100.0, 2),
            "invert_right_y": self.invert_y_chk.isChecked(),
            "invert_gyro_x": self.invert_gyro_x_chk.isChecked(),
            "invert_gyro_y": self.invert_gyro_y_chk.isChecked(),
            "manage_lizard_mode": self.lizard_chk.isChecked(),
            "haptics_enabled": self.haptics_chk.isChecked(),
            "pause_when_steam_running": self.pause_steam_chk.isChecked(),
        }

    @_safe
    def _on_slider_changed(self) -> None:
        self.sens_val_lbl.setText(f"{self.sens_slider.value() / 100.0:.2f}x")
        self.mouse_sens_val_lbl.setText(f"{self.mouse_sens_slider.value() / 100.0:.2f}x")
        self.dz_val_lbl.setText(f"{self.dz_slider.value()}%")
        self.outer_val_lbl.setText(f"{self.outer_slider.value()}%")
        self.gyro_sens_val_lbl.setText(f"{self.gyro_sens_slider.value() / 100.0:.2f}x")
        if not self._loading_controls and self._service is not None:
            dragging = any(
                s.isSliderDown()
                for s in (
                    self.sens_slider,
                    self.mouse_sens_slider,
                    self.dz_slider,
                    self.outer_slider,
                    self.gyro_sens_slider,
                )
            )
            self._service.update_settings(
                self._collect_settings_from_controls(),
                persist=not dragging,
                log_change=not dragging,
            )

    @_safe
    def _on_setting_changed(self) -> None:
        if not self._loading_controls and self._service is not None:
            self._service.update_settings(self._collect_settings_from_controls())

    @_safe
    def _on_reset_defaults(self) -> None:
        if self._service is not None:
            keep_enabled = self._service.get_settings().get("enabled", False)
            defaults = dict(DEFAULT_SERVICE_SETTINGS)
            defaults["enabled"] = keep_enabled
            self._service.update_settings(defaults)
        self._load_settings_into_controls()

    @_safe
    def _on_refresh_clicked(self) -> None:
        if self._service is not None:
            if not self._service.is_running():
                self._apply_status(self._service.refresh_environment_status())
            else:
                self._apply_status(self._service.get_status())

    @_safe
    def _on_toggle_clicked(self) -> None:
        if self._service is None:
            return
        if self._service.is_running():
            self._service.stop(persist=True)
        else:
            self._service.start(persist=True)

    @_safe
    def _on_install_driver_clicked(self) -> None:
        if self._service is None:
            return
        if self._service.install_driver():
            self.install_drv_btn.setEnabled(False)
            self.install_progress.setValue(2)
            self.install_progress.setVisible(True)
            self.driver_msg_lbl.setText("Đang khởi tạo tải gói cài đặt ViGEmBus v1.22.0...")

    @_safe
    def _on_install_progress(self, pct: int, msg: str) -> None:
        self.install_progress.setVisible(True)
        self.install_progress.setValue(max(0, min(100, int(pct))))
        self.driver_msg_lbl.setText(msg)

    @_safe
    def _on_install_finished(self, ok: bool, msg: str) -> None:
        self.install_drv_btn.setEnabled(True)
        self.install_progress.hide()
        if ok:
            self.detail_label.setText("Đã cài đặt ViGEmBus thành công — bạn có thể bật giả lập XInput ngay.")
        else:
            self.driver_msg_lbl.setText(msg)

    @_safe
    def _on_status_changed(self, st: dict) -> None:
        self._apply_status(st)

    def _apply_status(self, st: dict[str, Any]) -> None:
        running = bool(st.get("running", False))
        state = str(st.get("state", "stopped"))
        drv_ok = bool(st.get("driver_ok", False))
        steam_on = bool(st.get("steam_running", False))
        devices = st.get("devices") or []
        err = str(st.get("error") or "")

        if running:
            self.toggle_btn.setText("Tắt giả lập XInput")
            self.toggle_btn.setIcon(make_svg_icon("pause", size=14, color="#fca5a5"))
            self.toggle_btn.setStyleSheet(_BTN_STOP_STYLE)
            self.toggle_btn.setEnabled(True)
        else:
            self.toggle_btn.setText("Bật giả lập XInput")
            self.toggle_btn.setIcon(make_svg_icon("play", size=14, color="#052e16"))
            self.toggle_btn.setStyleSheet(_BTN_START_STYLE)
            self.toggle_btn.setEnabled(drv_ok)

        self.driver_banner.setVisible(not drv_ok)
        self.steam_banner.setVisible(steam_on and bool(self.pause_steam_chk.isChecked()))

        if state == "active" and devices:
            dev = devices[0]
            slot_num = int(dev.get("player_slot", -1))
            slot_txt = f"Xbox 360 Player {slot_num + 1}" if slot_num >= 0 else "Xbox 360 đã cắm"
            raw_bat = dev.get("battery_percent")
            bat = int(raw_bat) if raw_bat is not None else -1
            bat_txt = f"  |  Pin: {bat}%" if bat >= 0 else ""
            self._set_badge(f"ĐANG HOẠT ĐỘNG ({len(devices)})", "#052e16", "#10b981")
            self.detail_label.setText(f"Đã kết nối qua {dev.get('label', 'HID')}  ->  {slot_txt}{bat_txt}")
        elif state == "waiting_device":
            self._set_badge("CHỜ TAY CẦM", "#082f49", "#38bdf8")
            self.detail_label.setText(
                "Đang chờ bật nguồn hoặc cắm Steam Controller (cáp USB, đầu thu 2.4GHz hoặc Bluetooth LE)..."
            )
            self.diagram.set_state(None)
        elif state == "paused_steam":
            self._set_badge("TẠM DỪNG (STEAM)", "#422006", "#facc15")
            self.detail_label.setText("Đang tạm dừng vì Steam đang mở — sẽ tự kích hoạt lại ngay khi thoát Steam.")
            self.diagram.set_state(None)
        elif state == "driver_missing":
            self._set_badge("THIẾU DRIVER", "#450a0a", "#f87171")
            self.detail_label.setText(err or str(st.get("driver_message") or "Chưa cài đặt driver ViGEmBus."))
            self.diagram.set_state(None)
        else:
            self._set_badge("ĐÃ TẮT", "#1e293b", "#94a3b8")
            self.detail_label.setText(
                err or "Nhấn 'Bật giả lập XInput' để biến Steam Controller (2015) thành tay cầm Xbox 360 chuẩn."
            )
            self.diagram.set_state(None)

    def _set_badge(self, text: str, fg: str, bg: str) -> None:
        self.status_badge.setText(text)
        self.status_badge.setStyleSheet(
            f"color: {fg}; background-color: {bg}; border-radius: 6px; padding: 2px 8px; font-weight: bold;"
        )

    @_safe
    def _on_live_preview(self, payload: dict) -> None:
        xbox = payload.get("xbox") or {}
        raw = payload.get("raw") or {}
        label = str(payload.get("device_label") or "Steam Controller")
        self.diagram.set_state(xbox_dict_to_device_state(xbox, label=label))
        self.telemetry_label.setText(
            f"LS: ({xbox.get('lx', 0):+d}, {xbox.get('ly', 0):+d})  |  "
            f"RS: ({xbox.get('rx', 0):+d}, {xbox.get('ry', 0):+d})\n"
            f"LT: {xbox.get('left_trigger', 0)}  RT: {xbox.get('right_trigger', 0)}  |  "
            f"Gyro: ({raw.get('gyro_x', 0):+d}, {raw.get('gyro_y', 0):+d}, {raw.get('gyro_z', 0):+d})"
        )
