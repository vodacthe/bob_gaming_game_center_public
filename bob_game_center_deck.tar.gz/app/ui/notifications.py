"""Điểm vào tập trung cho toàn bộ thông báo hệ thống (tray balloon & toast nội bộ).

Chặn thông báo khi cửa sổ chính đang hiển thị ở tiền cảnh (active foreground),
xử lý cả đặc thù Steam Deck Game Mode (nơi ``isActiveWindow()`` có thể luôn trả ``True``).
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
import logging
from typing import Any
import weakref

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QSystemTrayIcon, QWidget

logger = logging.getLogger(__name__)
TAG = "[Notify]"

_QT_APP_ACTIVE_VALUE = int(Qt.ApplicationState.ApplicationActive.value)
_main_window_ref: weakref.ReferenceType[QWidget] | None = None


@dataclass(frozen=True)
class WindowNotificationState:
    """Ảnh chụp trạng thái cửa sổ và ứng dụng để hàm quyết định chạy thuần không cần GUI."""

    is_visible: bool = False
    is_minimized: bool = False
    is_hidden: bool = True
    application_state: Any = Qt.ApplicationState.ApplicationInactive
    is_active_window: bool = False


def _is_qt_app_active(application_state: Any) -> bool:
    """Kiểm tra ``application_state == Qt.ApplicationActive`` an toàn cho cả enum Qt và số nguyên."""
    if application_state is None:
        return False
    if isinstance(application_state, bool):
        return application_state
    try:
        if application_state == Qt.ApplicationState.ApplicationActive:
            return True
    except Exception:
        pass
    raw_val = getattr(application_state, "value", application_state)
    if isinstance(raw_val, int) and not isinstance(raw_val, bool):
        return raw_val == _QT_APP_ACTIVE_VALUE
    return False


def register_main_window(window: QWidget | None) -> None:
    """Đăng ký cửa sổ chính để các thành phần phát thông báo tra cứu trạng thái hiển thị."""
    global _main_window_ref
    if window is None:
        _main_window_ref = None
        return
    try:
        ref = weakref.ref(window)
    except TypeError:
        return
    _main_window_ref = ref
    try:
        def _on_destroyed(*_args: object, tracked_ref: weakref.ReferenceType[QWidget] = ref) -> None:
            global _main_window_ref
            if _main_window_ref is tracked_ref:
                _main_window_ref = None

        window.destroyed.connect(_on_destroyed)
    except Exception:
        pass


def unregister_main_window(window: QWidget | None = None) -> None:
    """Gỡ đăng ký cửa sổ chính khi đóng hẳn ứng dụng."""
    global _main_window_ref
    if _main_window_ref is None:
        return
    if window is None or _main_window_ref() is window or _main_window_ref() is None:
        _main_window_ref = None


def get_main_window() -> QWidget | None:
    """Trả về cửa sổ chính đang sống (hoặc ``None`` nếu chưa khởi tạo / đã đóng)."""
    if _main_window_ref is None:
        return None
    win = _main_window_ref()
    if win is None:
        return None
    try:
        _ = win.isVisible()
    except RuntimeError:
        return None
    return win


def capture_window_state(window: QWidget | None = None) -> WindowNotificationState:
    """Đọc trạng thái thực tế của cửa sổ và ``QGuiApplication`` một cách an toàn."""
    app_state: Any = Qt.ApplicationState.ApplicationInactive
    try:
        if QGuiApplication.instance() is not None:
            app_state = QGuiApplication.applicationState()
    except Exception:
        app_state = Qt.ApplicationState.ApplicationInactive

    target = window if window is not None else get_main_window()
    if target is None:
        return WindowNotificationState(
            is_visible=False,
            is_minimized=False,
            is_hidden=True,
            application_state=app_state,
            is_active_window=False,
        )

    try:
        vis = target.isVisible()
        mini = target.isMinimized()
        hid = target.isHidden()
        if not (isinstance(vis, bool) and isinstance(mini, bool) and isinstance(hid, bool)):
            return WindowNotificationState(
                is_visible=False,
                is_minimized=False,
                is_hidden=True,
                application_state=app_state,
                is_active_window=False,
            )
        try:
            win_state = target.windowState()
            if isinstance(win_state, Qt.WindowState) and bool(win_state & Qt.WindowState.WindowMinimized):
                mini = True
        except Exception:
            pass
        act_raw = target.isActiveWindow()
        is_act_win = act_raw if isinstance(act_raw, bool) else False
        return WindowNotificationState(
            is_visible=vis,
            is_minimized=mini,
            is_hidden=hid,
            application_state=app_state,
            is_active_window=is_act_win,
        )
    except RuntimeError:
        # Cửa sổ tạo bằng __new__ trong unit test hoặc đối tượng C++ đã huỷ
        return WindowNotificationState(
            is_visible=False,
            is_minimized=False,
            is_hidden=True,
            application_state=app_state,
            is_active_window=False,
        )


def app_is_foreground(
    state: WindowNotificationState | Mapping[str, Any] | None = None,
    *,
    window: QWidget | None = None,
) -> bool:
    """Hàm thuần quyết định app có đang hiển thị active trên màn hình hay không.

    Khi truyền ``state`` (``WindowNotificationState`` hoặc ``dict``), hàm hoàn toàn thuần
    và không truy cập bất kỳ đối tượng Qt GUI nào. Khi ``state is None``, hàm tự chụp
    trạng thái hiện hành từ ``window`` (hoặc ``MainWindow`` đã đăng ký).

    Trên Steam Deck Game Mode, ``isActiveWindow()`` có thể luôn trả ``True``, nên điều kiện
    bắt buộc kết hợp đầy đủ:
    ``isVisible() and not isMinimized() and not isHidden()`` và
    ``QGuiApplication.applicationState() == Qt.ApplicationActive``.
    """
    if state is None:
        state = capture_window_state(window)

    if isinstance(state, WindowNotificationState):
        is_visible = bool(state.is_visible)
        is_minimized = bool(state.is_minimized)
        is_hidden = bool(state.is_hidden)
        app_state = state.application_state
    elif isinstance(state, Mapping):
        is_visible = bool(state.get("is_visible", False))
        is_minimized = bool(state.get("is_minimized", False))
        is_hidden = bool(state["is_hidden"]) if "is_hidden" in state else (not is_visible)
        app_state = state.get("application_state", Qt.ApplicationState.ApplicationInactive)
    else:
        raise TypeError(f"Unsupported notification state type: {type(state)!r}")

    return bool(is_visible and (not is_minimized) and (not is_hidden) and _is_qt_app_active(app_state))


def should_notify(
    state: WindowNotificationState | Mapping[str, Any] | None = None,
    *,
    window: QWidget | None = None,
    force: bool = False,
    kind: str = "general",
    log_suppressed: bool = False,
) -> bool:
    """Trả về ``True`` nếu được phép hiện thông báo, ``False`` nếu cần chặn do app đang active."""
    if force:
        return True
    if app_is_foreground(state, window=window):
        if log_suppressed:
            logger.info(f"{TAG} bỏ qua (app đang active) [loại={kind}]")
        return False
    return True


def notify_user(
    title: str,
    message: str,
    *,
    kind: str = "tray",
    icon: QSystemTrayIcon.MessageIcon = QSystemTrayIcon.MessageIcon.Information,
    duration_ms: int = 5000,
    tray_icon: QSystemTrayIcon | None = None,
    window: QWidget | None = None,
    force: bool = False,
    state: WindowNotificationState | Mapping[str, Any] | None = None,
) -> bool:
    """Phát thông báo khay hệ thống qua cổng kiểm soát tập trung.

    Trả về ``True`` nếu thông báo đã được gửi tới ``QSystemTrayIcon``, ``False`` nếu bị chặn
    hoặc khay hệ thống không khả dụng.
    """
    active = app_is_foreground(state, window=window)
    if active and not force:
        logger.info(f"{TAG} bỏ qua (app đang active) [loại={kind}] title={title!r}")
        return False

    resolved_tray = tray_icon
    if resolved_tray is None and window is not None:
        resolved_tray = getattr(window, "tray_icon", None)
    if resolved_tray is None:
        main_win = get_main_window()
        if main_win is not None:
            resolved_tray = getattr(main_win, "tray_icon", None)

    if resolved_tray is None:
        logger.warning(f"{TAG} không thể hiện thông báo do thiếu tray_icon [loại={kind}] title={title!r}")
        return False

    try:
        resolved_tray.showMessage(title, message, icon, int(duration_ms))
        if force and active:
            logger.info(f"{TAG} đã hiện thông báo (ép hiện khi app đang active) [loại={kind}] title={title!r}")
        else:
            logger.info(f"{TAG} đã hiện thông báo [loại={kind}] title={title!r}")
        return True
    except Exception:
        logger.exception(f"{TAG} lỗi khi phát thông báo [loại={kind}] title={title!r}")
        return False


def notify_toast(
    show_fn: Callable[[], None],
    *,
    kind: str = "toast",
    summary: str = "",
    window: QWidget | None = None,
    force: bool = False,
    state: WindowNotificationState | Mapping[str, Any] | None = None,
) -> bool:
    """Phát toast nội bộ (ví dụ cảnh báo pin tay cầm) qua cùng cổng chặn tập trung."""
    active = app_is_foreground(state, window=window)
    if active and not force:
        detail = f" summary={summary!r}" if summary else ""
        logger.info(f"{TAG} bỏ qua (app đang active) [loại={kind}]{detail}")
        return False

    try:
        show_fn()
        if force and active:
            logger.info(f"{TAG} đã hiện toast (ép hiện khi app đang active) [loại={kind}]")
        else:
            logger.info(f"{TAG} đã hiện toast [loại={kind}]")
        return True
    except Exception:
        logger.exception(f"{TAG} lỗi khi hiển thị toast [loại={kind}]")
        return False
