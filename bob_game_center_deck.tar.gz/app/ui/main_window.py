"""
Main window for Bob Gaming Game Center.
Manages screen transitions, background operations, and app lifecycle.
"""

import logging
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import time
import traceback

from PySide6.QtWidgets import (
    QMainWindow, QMessageBox, QInputDialog, QSystemTrayIcon, QMenu,
    QApplication, QSplitter, QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QStackedWidget,
)
from PySide6.QtCore import Qt, QThread, QObject, QTimer, Signal, Slot, QEvent, QPoint
from PySide6.QtGui import QPixmap, QIcon, QAction, QPainter, QColor, QLinearGradient, QCursor

if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32

    WM_NCCALCSIZE = 0x0083
    WM_NCHITTEST  = 0x0084

    HTNOWHERE    = 0
    HTCLIENT     = 1
    HTCAPTION    = 2
    HTLEFT       = 10
    HTRIGHT      = 11
    HTTOP        = 12
    HTTOPLEFT    = 13
    HTTOPRIGHT   = 14
    HTBOTTOM     = 15
    HTBOTTOMLEFT = 16
    HTBOTTOMRIGHT= 17

from app.config import (
    load_config, save_config, decode_password,
    SYNC_STATUS_NOT_CONFIGURED, SYNC_STATUS_SYNCED,
    SYNC_STATUS_NOT_SYNCED, SYNC_STATUS_SYNCING, STEAMGRIDB_API_KEY,
    PROVIDER_NEXTCLOUD, PROVIDER_GOOGLE_DRIVE,
    get_app_dir, reset_to_default_config, remove_log_files, CONFIG_DIR
)
from app.utils.helpers import restart_application
from app.core.cloud_provider import CloudProvider
from app.core.nextcloud_client import NextcloudClient
from app.core.sync_manager import SyncManager
from app.core.auto_sync import AutoSyncManager
from app.core.image_cache import ImageCache
from app.core.process_monitor import ProcessMonitor
from app.ui.login_screen import LoginDialog
from app.ui.library_screen import LibraryScreen
from app.ui.sync_dialog import SyncDialog
from app.ui.add_game_dialog import AddGameDialog
from app.ui.settings_dialog import SettingsDialog, is_auto_start_enabled, set_auto_start

from app.ui.sidebar import SidebarWidget
from app.ui.mica import apply_mica_or_acrylic
from app.ui.conflict_dialog import ConflictDialog
from app.ui.utility_dialog import UtilityDialog
from app.ui.log_console_panel import LogConsolePanel
from app.ui.update_dialog import UpdateCheckWorker, UpdateDialog
from app.core import updater
from app.ui.gamepad_monitor import GamepadMonitor, SDL2_AVAILABLE
from app.ui.icons import make_svg_icon
from app.ui.workers import (
    CloudCheckBatchWorker, CloudGameDiscoveryWorker,
    ImageLoadWorker, AsyncImageLoader, SyncWorker, LocalScanWorker,
    SyncNowCheckWorker, SteamScanWorker, NonSteamShortcutsScanWorker,
)

logger = logging.getLogger(__name__)

NET_UNBLOCK_TICK_MS = 5 * 60 * 1000  # proxy health check; IP refresh itself is gated by refresh_due()


def is_official_steam_game(game_or_source) -> bool:
    """
    Check if a game is an official Steam store game (with Steam Cloud).
    Non-Steam games (source="steam_shortcut", "manual", "registry", "epic", "gog", "cloud")
    return False.
    """
    if isinstance(game_or_source, dict):
        if game_or_source.get("is_non_steam"):
            return False
        src = game_or_source.get("source", "")
        if src == "steam_shortcut":
            return False
        return src == "steam"
    src = str(game_or_source or "")
    if src == "steam_shortcut":
        return False
    return src == "steam"


def _sanitize_game_status(status: str, game_name: str, config_games: dict | None = None) -> str:
    """Reset stale 'syncing' status — no sync is in progress at startup or scan."""
    if status == SYNC_STATUS_SYNCING:
        logger.info(f"Reset stale 'syncing' status for {game_name} -> synced")
        if config_games and game_name in config_games:
            config_games[game_name]["status"] = SYNC_STATUS_SYNCED
        return SYNC_STATUS_SYNCED
    return status


def start_system_move(widget_or_window):
    """Trigger native OS window drag with Windows Aero Snap & Snap Layouts support."""
    win = widget_or_window.window() if hasattr(widget_or_window, "window") else widget_or_window
    if not win:
        return
    wh = win.windowHandle()
    if wh and hasattr(wh, "startSystemMove"):
        if wh.startSystemMove():
            return
    if sys.platform == "win32":
        try:
            import ctypes
            user32 = ctypes.windll.user32
            user32.ReleaseCapture()
            hwnd = int(win.winId())
            user32.SendMessageW(hwnd, 0x0112, 0xF012, 0)
        except Exception:
            pass



class _PollCloudWorker(QObject):
    """Worker that runs cloud polling in a background QThread.

    Defined at module level so PySide6 properly registers the Signal
    (inner-class Signals can silently fail in PySide6).
    """
    finished = Signal()

    def __init__(self, auto_sync_mgr):
        super().__init__()
        self._auto_sync = auto_sync_mgr

    def run(self):
        try:
            logger.info("[PollCloud] Starting cloud timestamp comparison...")
            self._auto_sync._poll_cloud()
            logger.info("[PollCloud] Cloud timestamp comparison finished")
        except Exception as e:
            logger.error(f"[PollCloud] poll_cloud error: {e}", exc_info=True)
        finally:
            self.finished.emit()


# ===================== MAIN WINDOW =====================


class MainWindow(QMainWindow):
    """Main application window - goes directly to library, login on demand."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Bob Gaming Game Center")
        self.RESIZE_BORDER = 8
        self.setMinimumSize(1024, 680)
        self.resize(1280, 800)

        # Frameless window with custom application control buttons
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        # Background wallpaper asset
        bg_path = os.path.join(get_app_dir(), "assets", "bg.png")
        self._bg_pixmap = QPixmap(bg_path) if os.path.exists(bg_path) else None
        self._drag_pos = None

        # State
        self.config = load_config()
        self.cloud_client: CloudProvider | None = None
        self.sync_manager: SyncManager | None = None
        self.auto_sync: AutoSyncManager | None = None
        self.image_cache: ImageCache | None = None
        self._active_dialog: SyncDialog | None = None
        self._conflict_dialog: ConflictDialog | None = None  # Track active conflict dialog
        self._pending_conflicts: list[dict] = []  # Conflicts queued while window hidden
        self._force_quit = False  # True when quitting from tray

        # Worker threads (keep references to prevent GC)
        self._scan_thread: QThread | None = None
        self._image_thread: QThread | None = None
        self.image_loader: AsyncImageLoader | None = None
        self._sync_thread: QThread | None = None
        self._active_sync_threads: dict[str, QThread] = {}  # Per-game active sync threads
        self._active_sync_workers: dict[str, QObject] = {}  # Keep references of sync workers to prevent GC
        self._cloud_check_threads: list[QThread] = []  # Per-game cloud check threads
        self._cloud_check_workers: list[QObject] = []  # Keep references of cloud check workers to prevent GC
        self._cloud_check_pending: int = 0  # Count of pending cloud checks
        self._discovery_thread: QThread | None = None  # Cloud game discovery
        self._steam_thread: QThread | None = None  # Steam games scan
        self._shortcut_thread: QThread | None = None  # Non-Steam shortcuts scan
        self._steam_add_threads: dict[str, QThread] = {}  # Background steam shortcut+artwork addition threads
        self._steam_add_workers: dict[str, QObject] = {}  # Workers kept alive while steam add threads run
        self._orphaned_threads: list[QThread] = []  # Threads still running when replaced
        self._orphaned_workers: list[QObject] = []  # Workers kept alive while orphaned threads run

        # Global Gamepad Monitor for Controller Mapper
        self._gamepad = None
        self._gamepad_nav = None
        self._init_gamepad()

        # Apply Windows 11 Mica / Acrylic backdrop blur & dark titlebar
        try:
            apply_mica_or_acrylic(self, prefer_acrylic=True)
        except Exception as e:
            logger.debug(f"[Mica] setup: {e}")

        self._setup_ui()
        self._setup_tray_icon()
        self._init_image_cache()
        self._try_auto_login()
        self._load_saved_games()

        # Periodic cloud sync check every 30 seconds
        self._periodic_timer = QTimer(self)
        self._periodic_timer.timeout.connect(self._periodic_cloud_check)
        self._periodic_timer.start(30000)  # 30 seconds
        logger.info("[Periodic] Started periodic cloud check timer (30s interval)")

        # Process Monitor for instant post-game save upload
        self.process_monitor = ProcessMonitor(lambda: self.config, self)
        self.process_monitor.game_exited.connect(self._on_game_process_exited)
        self.process_monitor.start()

        # Ensure auto-start task exists if enabled in config or existing task/registry
        try:
            if self.config.get("auto_start", False) or is_auto_start_enabled():
                set_auto_start(True)
        except Exception as e:
            logger.debug(f"Auto-start setup check: {e}")

        # Network Unblock: inert unless the user enabled it before
        self.net_unblock = None
        self._init_net_unblock()

        # Steam Chat Overlay: starts only if the user enabled it before
        self.steam_chat = None
        self._init_steam_chat()

        # Self-update: check shortly after start-up, then every 15 minutes
        self._init_updater()

        # Online-Fix auto-registration: listens to downloads finishing even if store screen is closed
        self._init_online_fix()
        self._init_steam_free_keep()

    def paintEvent(self, event):
        """Paint atmospheric cyberpunk background wallpaper and subtle window border."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

        # 1. Base solid dark background so there are no transparent holes
        painter.fillRect(self.rect(), QColor(10, 12, 19))

        # 2. Draw background wallpaper (bg.png) anchored to top-right with soft ambient opacity
        if hasattr(self, "_bg_pixmap") and self._bg_pixmap and not self._bg_pixmap.isNull():
            scaled = self._bg_pixmap.scaled(
                self.size(),
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation,
            )
            # Anchor to top right corner
            x = self.width() - scaled.width()
            y = 0

            # Render at 42% opacity so it sinks gracefully into the dark void without glaring
            painter.setOpacity(0.42)
            painter.drawPixmap(x, y, scaled)
            painter.setOpacity(1.0)

            # Left dark gradient overlay so sidebar and content remain clean & readable
            left_grad = QLinearGradient(0, 0, self.width(), 0)
            left_grad.setColorAt(0.0, QColor(10, 12, 19, 235))
            left_grad.setColorAt(0.24, QColor(10, 12, 19, 195))
            left_grad.setColorAt(0.55, QColor(10, 12, 19, 110))
            left_grad.setColorAt(1.0, QColor(10, 12, 19, 50))
            painter.fillRect(self.rect(), left_grad)

            # Bottom ambient vignette
            bot_grad = QLinearGradient(0, self.height(), 0, 0)
            bot_grad.setColorAt(0.0, QColor(10, 12, 19, 140))
            bot_grad.setColorAt(0.45, QColor(10, 12, 19, 0))
            painter.fillRect(self.rect(), bot_grad)

        # 3. Subtle 1px border for frameless window
        painter.setPen(QColor(255, 255, 255, 22))
        painter.drawRect(0, 0, self.width() - 1, self.height() - 1)
        painter.end()

    def showEvent(self, event):
        """Enable native Windows sizing frame (WS_THICKFRAME) so edges and corners can be resized."""
        super().showEvent(event)
        if sys.platform == "win32":
            try:
                hwnd = int(self.winId())
                if hwnd:
                    style = user32.GetWindowLongW(hwnd, -16)
                    # Add WS_THICKFRAME (0x00040000), WS_MINIMIZEBOX (0x00020000), WS_MAXIMIZEBOX (0x00010000), WS_CAPTION (0x00C00000)
                    user32.SetWindowLongW(hwnd, -16, style | 0x00040000 | 0x00020000 | 0x00010000 | 0x00C00000)
                    user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0020 | 0x0002 | 0x0001 | 0x0004)
            except Exception as e:
                logger.debug(f"[NativeWindow] Setup failed: {e}")
        if not event.spontaneous():
            stack = "".join(traceback.format_stack()[-5:-1])
            logger.info(f"[ShowEvent] Window shown programmatically:\n{stack}")

    def nativeEvent(self, event_type, message):
        """Native Win32 message handling for seamless border resizing and Aero snap."""
        if sys.platform == "win32":
            try:
                msg = wintypes.MSG.from_address(int(message))
                if msg.message == WM_NCCALCSIZE:
                    if msg.wParam:
                        return True, 0
                elif msg.message == WM_NCHITTEST:
                    if self.isMaximized():
                        return False, 0
                    p = self.mapFromGlobal(QCursor.pos())
                    w, h = self.width(), self.height()
                    b = getattr(self, "RESIZE_BORDER", 8)

                    if p.x() < 0 or p.x() > w or p.y() < 0 or p.y() > h:
                        return False, 0

                    left = p.x() <= b
                    right = p.x() >= w - b
                    top = p.y() <= b
                    bottom = p.y() >= h - b

                    if top and left:
                        return True, HTTOPLEFT
                    if top and right:
                        return True, HTTOPRIGHT
                    if bottom and left:
                        return True, HTBOTTOMLEFT
                    if bottom and right:
                        return True, HTBOTTOMRIGHT
                    if left:
                        return True, HTLEFT
                    if right:
                        return True, HTRIGHT
                    if top:
                        return True, HTTOP
                    if bottom:
                        return True, HTBOTTOM
            except Exception:
                pass
        return super().nativeEvent(event_type, message)

    def mousePressEvent(self, event):
        """Enable dragging the frameless window from top bar with native Aero Snap."""
        if event.button() == Qt.MouseButton.LeftButton and event.position().y() <= 70:
            start_system_move(self)
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        """Move frameless window while dragging (fallback when system move not active)."""
        if hasattr(self, "_drag_pos") and self._drag_pos is not None and event.buttons() == Qt.MouseButton.LeftButton:
            if not self.isMaximized():
                self.move(event.globalPosition().toPoint() - self._drag_pos)
                event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        """End frameless window drag."""
        self._drag_pos = None
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        """Toggle maximize when double clicking top bar."""
        if event.button() == Qt.MouseButton.LeftButton and event.position().y() <= 70:
            self.toggle_maximize()
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)

    def _on_top_bar_mouse_press(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            start_system_move(self)
            event.accept()

    def _on_top_bar_mouse_move(self, event):
        if hasattr(self, "_drag_pos") and self._drag_pos is not None and event.buttons() == Qt.MouseButton.LeftButton:
            if not self.isMaximized():
                self.move(event.globalPosition().toPoint() - self._drag_pos)
                event.accept()

    def _on_top_bar_mouse_release(self, event):
        self._drag_pos = None
        event.accept()

    def _on_top_bar_double_click(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.toggle_maximize()
            event.accept()

    def toggle_maximize(self):
        """Toggle between normal and maximized window state."""
        if self.isMaximized():
            self.showNormal()
            self._update_window_controls(is_max=False)
        else:
            self.showMaximized()
            self._update_window_controls(is_max=True)

    def changeEvent(self, event):
        """Detect window maximize/restore to update control button icon."""
        if event.type() == QEvent.Type.WindowStateChange:
            self._update_window_controls(is_max=self.isMaximized())
        super().changeEvent(event)

    def _update_window_controls(self, is_max: bool):
        """Update maximize/restore button icon in Top Bar and LibraryScreen."""
        icon_name = "window_restore" if is_max else "window_maximize"
        if hasattr(self, "max_btn") and self.max_btn:
            self.max_btn.setIcon(make_svg_icon(icon_name, size=10, normal_color="#cbd5e1", active_color="#ffffff"))
        if hasattr(self, "library_screen") and getattr(self.library_screen, "max_btn", None):
            self.library_screen.max_btn.setIcon(make_svg_icon(icon_name, size=10, normal_color="#cbd5e1", active_color="#ffffff"))

    def _setup_ui(self):
        """Set up the main window UI with luxury Sidebar, persistent Top Bar, and Splitter."""
        # Collapsible Glass Sidebar on the left
        self.sidebar = SidebarWidget(self)
        self.sidebar.category_selected.connect(self._on_sidebar_category_selected)
        self.sidebar.tool_triggered.connect(self._on_sidebar_tool_triggered)
        self.sidebar.device_triggered.connect(self._on_sidebar_device_triggered)
        self.sidebar.system_triggered.connect(self._on_sidebar_system_triggered)
        self.sidebar.version_clicked.connect(self._check_for_update_manual)

        # Content container holding the active screen (LibraryScreen, MapperScreen, etc.)
        self._content_container = QStackedWidget(self)
        self._content_container.setObjectName("contentContainer")
        self._content_container.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._content_container.setStyleSheet("background: transparent;")
        self._content_container.setMinimumWidth(560)

        # Library screen (always shown as main view initially)
        self.library_screen = LibraryScreen()
        self._connect_library_signals()
        self._content_container.addWidget(self.library_screen)

        self._mapper_screen = None  # Lazy-init
        self._remote_screen = None
        self._net_unblock_screen = None
        self._settings_screen = None
        self._account_screen = None
        self._cloud_sync_screen = None
        self._steam_artwork_screen = None
        self._upscaler_screen = None
        self._online_fix_screen = None

        # Live Log Console panel (collapsible right dock)
        self._log_panel = LogConsolePanel(self)
        self._log_panel.closed.connect(lambda: self._toggle_log_console(show=False))
        self._log_panel.hide()

        # Root horizontal splitter hosting content on the left and log stream on the right
        self._root_splitter = QSplitter(Qt.Orientation.Horizontal, self)
        self._root_splitter.setObjectName("rootSplitter")
        self._root_splitter.setStyleSheet("background: transparent;")
        self._root_splitter.setChildrenCollapsible(False)
        self._root_splitter.addWidget(self._content_container)
        self._root_splitter.addWidget(self._log_panel)

        self._root_splitter.setStyleSheet("""
            #rootSplitter {
                background: transparent;
            }
            #rootSplitter::handle:horizontal {
                background-color: rgba(255, 255, 255, 0.05);
                width: 2px;
            }
            #rootSplitter::handle:horizontal:hover {
                background-color: #7c3aed;
            }
        """)

        # Persistent Top Bar with window controls (—, □, ✕) anchored at top right of the whole window
        self._top_bar = QWidget(self)
        self._top_bar.setObjectName("appTopBar")
        self._top_bar.setFixedHeight(28)
        self._top_bar.setStyleSheet("background: transparent;")
        self._top_bar.mousePressEvent = self._on_top_bar_mouse_press
        self._top_bar.mouseMoveEvent = self._on_top_bar_mouse_move
        self._top_bar.mouseReleaseEvent = self._on_top_bar_mouse_release
        self._top_bar.mouseDoubleClickEvent = self._on_top_bar_double_click

        top_bar_layout = QHBoxLayout(self._top_bar)
        top_bar_layout.setContentsMargins(12, 4, 12, 2)
        top_bar_layout.setSpacing(4)
        top_bar_layout.addStretch()

        self.min_btn = QPushButton()
        self.min_btn.setObjectName("winMinBtn")
        self.min_btn.setFixedSize(30, 20)
        self.min_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.min_btn.setIcon(make_svg_icon("window_minimize", size=10, normal_color="#cbd5e1", active_color="#ffffff"))
        self.min_btn.setToolTip("Thu nhỏ")
        self.min_btn.clicked.connect(self.showMinimized)
        top_bar_layout.addWidget(self.min_btn)

        self.max_btn = QPushButton()
        self.max_btn.setObjectName("winMaxBtn")
        self.max_btn.setFixedSize(30, 20)
        self.max_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.max_btn.setIcon(make_svg_icon("window_maximize", size=10, normal_color="#cbd5e1", active_color="#ffffff"))
        self.max_btn.setToolTip("Phóng to / Khôi phục")
        self.max_btn.clicked.connect(self.toggle_maximize)
        top_bar_layout.addWidget(self.max_btn)

        self.close_btn = QPushButton()
        self.close_btn.setObjectName("winCloseBtn")
        self.close_btn.setFixedSize(30, 20)
        self.close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_btn.setIcon(make_svg_icon("window_close", size=10, normal_color="#cbd5e1", active_color="#ffffff"))
        self.close_btn.setToolTip("Đóng ứng dụng")
        self.close_btn.clicked.connect(self.close)
        top_bar_layout.addWidget(self.close_btn)

        # Right container combining Top Bar and Root Splitter
        self._right_container = QWidget(self)
        self._right_container.setObjectName("rightContainer")
        self._right_container.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._right_container.setStyleSheet("background: transparent;")
        right_layout = QVBoxLayout(self._right_container)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)
        right_layout.addWidget(self._top_bar)
        right_layout.addWidget(self._root_splitter, stretch=1)

        # Main horizontal container combining sidebar and right container
        self._main_container = QWidget(self)
        self._main_container.setObjectName("mainContainer")
        self._main_container.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._main_container.setStyleSheet("background: transparent;")
        self._main_layout = QHBoxLayout(self._main_container)
        self._main_layout.setContentsMargins(0, 0, 0, 0)
        self._main_layout.setSpacing(0)
        self._main_layout.addWidget(self.sidebar)
        self._main_layout.addWidget(self._right_container, stretch=1)

        self.setCentralWidget(self._main_container)

    def _set_active_screen(self, widget: QWidget):
        """Set active screen inside content container stack."""
        if self._content_container.indexOf(widget) == -1:
            self._content_container.addWidget(widget)
        self._content_container.setCurrentWidget(widget)

    def _connect_library_signals(self):
        """Connect all LibraryScreen signals to MainWindow handlers."""
        self.library_screen.game_selected.connect(self._on_game_selected)
        self.library_screen.logout_requested.connect(self._show_account_screen)
        self.library_screen.login_requested.connect(self._show_account_screen)
        self.library_screen.scan_requested.connect(self._scan_games)
        self.library_screen.add_game_requested.connect(self._on_add_game)
        self.library_screen.remove_game_requested.connect(self._on_remove_game)
        self.library_screen.uninstall_game_requested.connect(self._on_uninstall_game)
        self.library_screen.settings_requested.connect(self._show_settings_screen)
        self.library_screen.utility_requested.connect(self._show_utility_dialog)
        self.library_screen.sync_now_requested.connect(self._on_sync_now_from_card)
        self.library_screen.unsync_requested.connect(self._on_unsync_from_card)
        self.library_screen.exclude_requested.connect(self._on_exclude_requested_from_card)
        self.library_screen.steam_artwork_requested.connect(self._show_steam_artwork_screen)
        self.library_screen.favorite_toggled.connect(self._on_favorite_toggled)
        self.library_screen.launch_requested.connect(self._on_launch_game)
        self.library_screen.exe_path_changed.connect(self._on_game_exe_changed)
        self.library_screen.category_filter_changed.connect(self.sidebar.set_active_category)
        self.library_screen.counts_updated.connect(self.sidebar.update_counts)

    def _on_favorite_toggled(self, game_data: dict):
        """Save favorite state to config."""
        name = game_data.get("name", "")
        if name:
            if "games" not in self.config:
                self.config["games"] = {}
            if name not in self.config["games"]:
                self.config["games"][name] = {}
            self.config["games"][name]["favorite"] = bool(game_data.get("favorite", False))
            self.save_config()

    def _on_sidebar_category_selected(self, cat: str):
        """Handle category filter selection from sidebar."""
        is_in_library = (
            hasattr(self, "_content_container")
            and self._content_container.currentWidget() == self.library_screen
        )
        if not is_in_library:
            self._back_to_library(target_category=cat)
        else:
            self.library_screen.set_category_filter(cat)
            if hasattr(self, "sidebar"):
                self.sidebar.set_active_category(cat)

    def _on_sidebar_tool_triggered(self, tool_id: str):
        """Handle tool action triggered from sidebar."""
        if tool_id == "remote_gaming":
            self._show_remote_screen()
        elif tool_id == "net_unblock":
            self._show_net_unblock_screen()
        elif tool_id == "steam_chat":
            self._show_steam_chat_screen()
        elif tool_id == "cloud_sync":
            self._show_cloud_sync_screen()
        elif tool_id == "steam_artwork":
            self._show_steam_artwork_screen()
        elif tool_id == "upscaler":
            self._show_upscaler_screen()
        elif tool_id == "online_fix":
            self._show_online_fix_screen("all")
        elif tool_id == "store_steam_free":
            self._show_steam_free_screen()
        elif tool_id == "trainer":
            self._show_trainer_screen()

    def _on_sidebar_device_triggered(self, device_id: str):
        """Handle device section action from sidebar."""
        if device_id == "controller":
            self._show_controller_mapper()

    def _on_sidebar_system_triggered(self, sys_id: str):
        """Handle system action from sidebar."""
        if sys_id == "settings":
            self._show_settings_screen()
        elif sys_id == "logs":
            self._toggle_log_console()
        elif sys_id == "account":
            self._show_account_screen()


    # ---- Reusable Helper Methods ----

    def _is_cpp_alive(self, obj: QObject) -> bool:
        """Check if a Qt/C++ object is still alive (not yet destroyed by deleteLater)."""
        try:
            obj.objectName()  # Accessing any property triggers RuntimeError if deleted
            return True
        except RuntimeError:
            return False

    def _has_active_sync(self) -> bool:
        """Check if any sync operation thread is currently active."""
        if not hasattr(self, "_active_sync_threads"):
            return False
        return any(self._is_cpp_alive(t) and t.isRunning() for t in self._active_sync_threads.values())

    def _cleanup_orphaned_thread(self, thread: QThread):
        """Remove a finished thread from the orphaned list."""
        try:
            self._orphaned_threads.remove(thread)
            logger.info("[Thread] Orphaned thread finished and cleaned up")
        except ValueError:
            pass  # Already removed by pruning

    def _run_in_thread(self, worker: QObject, thread_attr: str,
                       connections: dict, done_attr: str = "finished") -> QThread:
        """
        Run a QObject worker in a background QThread with standard lifecycle.
        
        Handles: creating thread, moveToThread, connecting signals, cleanup of
        previous thread on the same slot, and preventing GC.
        
        Args:
            worker: The QObject worker (must have a `run` method).
            thread_attr: Attribute name on self to store the QThread (e.g. '_scan_thread').
            connections: Dict of {signal: slot} to connect before starting.
            done_attr: Name of the worker's 'done' signal for lifecycle cleanup.
        """
        # Clean up previous thread on this slot
        old_thread = getattr(self, thread_attr, None)
        worker_attr = thread_attr.replace("_thread", "_worker")
        old_worker = getattr(self, worker_attr, None)
        if old_thread and isinstance(old_thread, QThread) and self._is_cpp_alive(old_thread):
            try:
                if old_thread.isRunning():
                    if old_worker and hasattr(old_worker, "cancel"):
                        try:
                            old_worker.cancel()
                        except Exception:
                            pass
                    old_thread.quit()
                    if not old_thread.wait(100):
                        logger.warning(f"[Thread] {thread_attr} still running after 100ms, parking reference")
                        self._orphaned_threads.append(old_thread)
                        if old_worker:
                            if not hasattr(self, "_orphaned_workers"):
                                self._orphaned_workers = []
                            self._orphaned_workers.append(old_worker)
                        old_thread.finished.connect(lambda t=old_thread: self._cleanup_orphaned_thread(t))
            except RuntimeError:
                pass

        # Prune finished orphaned threads safely
        still_running = []
        for t in getattr(self, "_orphaned_threads", []):
            try:
                if self._is_cpp_alive(t) and t.isRunning():
                    still_running.append(t)
                else:
                    t.wait(50)
            except RuntimeError:
                pass
        self._orphaned_threads = still_running

        thread = QThread()
        worker.moveToThread(thread)
        thread.started.connect(worker.run)

        # Connect caller-specified signals
        for signal, slot in connections.items():
            signal.connect(slot)

        # Standard lifecycle: done → quit thread → cleanup
        done_signal = getattr(worker, done_attr)
        done_signal.connect(thread.quit)
        done_signal.connect(worker.deleteLater)

        # Store references to prevent GC
        setattr(self, thread_attr, thread)
        setattr(self, worker_attr, worker)

        thread.start()
        return thread

    def _require_login(self) -> bool:
        """Ensure user is logged in. Shows login dialog if not. Returns True if logged in."""
        if self._is_logged_in():
            return True
        QMessageBox.information(
            self, "Yêu cầu kết nối Cloud",
            "Bạn cần kết nối dịch vụ lưu trữ đám mây để đồng bộ lưu game.\n"
            "Vui lòng kết nối tài khoản trước.",
        )
        self._show_login_dialog()
        return self._is_logged_in()

    def _save_game_to_config(self, game_name: str, updates: dict):
        """Update a game's config entry and persist to disk."""
        config_games = self.config.setdefault("games", {})
        config_games.setdefault(game_name, {}).update(updates)
        save_config(self.config)

    def _setup_tray_icon(self):
        """Set up system tray icon with context menu."""
        self.tray_icon = QSystemTrayIcon(self)

        # Use app icon if available, otherwise use default
        app_dir = get_app_dir()
        icon_path = os.path.join(app_dir, "assets", "icon.png")
        if os.path.exists(icon_path):
            self.tray_icon.setIcon(QIcon(icon_path))
        else:
            self.tray_icon.setIcon(self.style().standardIcon(
                self.style().StandardPixmap.SP_ComputerIcon
            ))

        self.tray_icon.setToolTip("Bob Gaming Game Center")

        # Tray context menu
        tray_menu = QMenu(self)
        show_action = QAction(make_svg_icon("gamepad", size=16, color="#a855f7"), "Hiển thị ứng dụng", self)
        show_action.triggered.connect(self._tray_show)
        quit_action = QAction(make_svg_icon("close", size=16, color="#ef4444"), "Thoát ứng dụng", self)
        quit_action.triggered.connect(self._tray_quit)

        tray_menu.addAction(show_action)
        tray_menu.addSeparator()
        tray_menu.addAction(quit_action)

        self._last_tray_notification_target = ""
        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.activated.connect(self._on_tray_activated)
        self.tray_icon.messageClicked.connect(self._on_tray_message_clicked)
        self.tray_icon.show()

    def _init_image_cache(self):
        """Initialize image cache with hardcoded SteamGridDB API key."""
        self.image_cache = ImageCache(STEAMGRIDB_API_KEY)
        self.image_loader = AsyncImageLoader(self.image_cache, max_workers=6, parent=self)
        self.image_loader.image_ready.connect(self._on_image_loaded)

    def _create_cloud_client(self, config: dict) -> CloudProvider | None:
        """Factory method to create the appropriate cloud client from config."""
        provider = config.get("cloud_provider", "")

        if provider == PROVIDER_GOOGLE_DRIVE:
            try:
                from app.core.google_drive_client import GoogleDriveClient
                client = GoogleDriveClient()
                if client.authenticate():
                    return client
            except Exception as e:
                logger.error(f"Failed to create Google Drive client: {e}")
            return None

        if provider == PROVIDER_NEXTCLOUD:
            try:
                password = decode_password(config.get("password", ""))
                return NextcloudClient(
                    config["cloud_url"],
                    config["username"],
                    password,
                )
            except Exception as e:
                logger.error(f"Failed to create Nextcloud client: {e}")
            return None

        return None

    def _try_auto_login(self):
        """Try to auto-login with saved credentials (silently)."""
        provider = self.config.get("cloud_provider", "")

        # Backward compatibility: if no provider set but Nextcloud credentials exist
        if not provider and self.config.get("cloud_url") and self.config.get("username"):
            provider = PROVIDER_NEXTCLOUD
            self.config["cloud_provider"] = provider
            save_config(self.config)
            logger.info("[AutoLogin] Migrated legacy config to explicit Nextcloud provider")

        can_auto = False

        if provider == PROVIDER_NEXTCLOUD:
            can_auto = (
                self.config.get("cloud_url")
                and self.config.get("username")
                and self.config.get("password")
                and self.config.get("remember_me", True)
            )
        elif provider == PROVIDER_GOOGLE_DRIVE:
            from app.core.google_drive_client import GoogleDriveClient
            can_auto = GoogleDriveClient.is_token_saved()

        if can_auto:
            try:
                self.cloud_client = self._create_cloud_client(self.config)
                if not self.cloud_client:
                    raise RuntimeError("Cloud client creation failed")

                self.sync_manager = SyncManager(self.cloud_client, self.config)
                self.sync_manager.sync_progress.connect(self._on_sync_progress)

                # Create auto sync manager (file watcher + cloud polling)
                self.auto_sync = AutoSyncManager(self.sync_manager, self)
                self.auto_sync.upload_needed.connect(self._on_auto_upload_needed)
                self.auto_sync.download_needed.connect(self._on_auto_download_needed)
                self.auto_sync.conflict_detected.connect(self._on_conflict_detected)
                self.auto_sync.refresh_watched_games()

                self.library_screen.set_logged_in(True, provider)
                if hasattr(self, "sidebar"):
                    self.sidebar.set_account_status(True, self.config.get("username", "") or provider)
                logger.info(f"Auto-login successful with {provider} (auto-sync enabled)")
            except Exception as e:
                logger.error(f"Auto-login failed: {e}")
                self.cloud_client = None
                self.sync_manager = None
                self.library_screen.set_logged_in(False)
                if hasattr(self, "sidebar"):
                    self.sidebar.set_account_status(False)
        else:
            self.library_screen.set_logged_in(False)
            if hasattr(self, "sidebar"):
                self.sidebar.set_account_status(False)

    def _load_saved_games(self):
        """Load saved games from config on startup, then start per-game cloud checks."""
        manual_games = self.config.get("manual_games", [])
        config_games = self.config.get("games", {})

        if not manual_games and not config_games:
            # First launch - auto-scan for local games, then do cloud checks
            self._scan_games()
            return

        # Migrate any legacy Online-Fix entries that have trailing "Online" in title/config/folder
        stale_fixed = False
        try:
            from app.core.online_fix.translate import title_to_vietnamese
            from app.config import IMAGE_CACHE_DIR
            import shutil

            games_to_migrate = []
            for g_name, saved in list(config_games.items()):
                if saved.get("online_fix") or g_name.lower().endswith(" online"):
                    clean_title = title_to_vietnamese(g_name)
                    if clean_title != g_name:
                        games_to_migrate.append((g_name, clean_title))

            for old_name, new_name in games_to_migrate:
                logger.info(f"[Migration] Migrating online-fix game: {old_name!r} -> {new_name!r}")
                saved = config_games.pop(old_name)
                saved["name"] = new_name

                # Check if install folder on disk needs rename
                old_loc = saved.get("install_location", "")
                if old_loc and os.path.basename(os.path.normpath(old_loc)).lower().endswith(" online"):
                    parent_dir = os.path.dirname(os.path.normpath(old_loc))
                    new_loc = os.path.join(parent_dir, title_to_vietnamese(os.path.basename(os.path.normpath(old_loc))))
                    if os.path.isdir(old_loc) and not os.path.exists(new_loc):
                        try:
                            try:
                                os.rename(old_loc, new_loc)
                            except OSError:
                                os.makedirs(new_loc, exist_ok=True)
                                for item in os.listdir(old_loc):
                                    shutil.move(os.path.join(old_loc, item), os.path.join(new_loc, item))
                                try:
                                    os.rmdir(old_loc)
                                except OSError:
                                    pass
                            logger.info(f"[Migration] Renamed folder {old_loc} -> {new_loc}")
                            saved["install_location"] = new_loc
                            old_exe = saved.get("exe_path", "")
                            if old_exe and old_exe.startswith(old_loc):
                                saved["exe_path"] = new_loc + old_exe[len(old_loc):]
                        except Exception as e:
                            logger.warning(f"[Migration] Could not rename folder {old_loc}: {e}")

                config_games[new_name] = saved
                manual_games = [new_name if g == old_name else g for g in manual_games]
                self.config["manual_games"] = manual_games
                stale_fixed = True

                # Migrate image cache poster if present
                for ext in (".jpg", ".png", ".webp"):
                    old_poster = os.path.join(IMAGE_CACHE_DIR, f"{old_name}{ext}")
                    new_poster = os.path.join(IMAGE_CACHE_DIR, f"{new_name}{ext}")
                    if os.path.isfile(old_poster) and not os.path.isfile(new_poster):
                        try:
                            shutil.copy2(old_poster, new_poster)
                        except Exception:
                            pass
        except Exception as e:
            logger.warning(f"[Migration] Online-fix legacy cleanup failed: {e}")

        # Flatten any existing duplicate nested folders (e.g. Games\Name\Name -> Games\Name)
        try:
            from app.core.online_fix.extractor import flatten_nested_directory, find_game_executable
            for g_name, saved in list(config_games.items()):
                install_loc = saved.get("install_location", "")
                if install_loc and os.path.isdir(install_loc):
                    if flatten_nested_directory(install_loc):
                        new_exe = find_game_executable(install_loc, g_name) or ""
                        if new_exe:
                            saved["exe_path"] = new_exe
                            stale_fixed = True
                            logger.info(f"[Migration] Auto-flattened {g_name} directory, updated exe: {new_exe}")
        except Exception as e:
            logger.warning(f"[Migration] Auto-flattening check failed: {e}")


        # Build game list from saved data (instant - from local config)
        games = []
        all_names = set()

        hide_steam = self.config.get("hide_steam_games", True)

        def _sanitize_status(status: str, game_name: str) -> str:
            """Reset stale 'syncing' status — no sync is in progress at startup."""
            nonlocal stale_fixed
            if status == SYNC_STATUS_SYNCING:
                logger.info(f"[LoadSaved] Reset stale 'syncing' status for {game_name} → synced")
                if game_name in config_games:
                    config_games[game_name]["status"] = SYNC_STATUS_SYNCED
                    stale_fixed = True
                return SYNC_STATUS_SYNCED
            return status

        removed_games = [g.lower() for g in self.config.get("removed_games", [])]
        for name in manual_games:
            name_lower = name.lower()
            if name_lower in removed_games:
                continue
            saved = config_games.get(name, {})
            source = saved.get("source", "manual")

            # Skip official Steam games if hidden (Non-Steam games stay visible!)
            if hide_steam and is_official_steam_game(source):
                continue

            if name_lower not in all_names:
                all_names.add(name_lower)

                install_loc = saved.get("install_location", "")
                exe = saved.get("exe_path", "")
                if not exe and install_loc and os.path.isdir(install_loc):
                    from app.core.steam_manager import find_game_executable
                    exe = find_game_executable(install_loc, name) or ""
                    if exe:
                        saved["exe_path"] = exe
                        stale_fixed = True

                games.append({
                    "name": name,
                    "install_location": install_loc,
                    "publisher": saved.get("publisher", "Manual"),
                    "source": source,
                    "status": _sanitize_status(saved.get("status", SYNC_STATUS_NOT_CONFIGURED), name),
                    "save_path": saved.get("save_path", ""),
                    "on_cloud": saved.get("on_cloud", False),
                    "favorite": saved.get("favorite", False),
                    "exe_path": exe,
                })

        # Also add games from config_games that aren't in manual list
        for name, data in config_games.items():
            if name.lower() not in all_names and name.lower() not in removed_games:
                source = data.get("source", "")
                if hide_steam and is_official_steam_game(source):
                    continue
                all_names.add(name.lower())
                install_loc = data.get("install_location", "")
                exe = data.get("exe_path", "")
                if not exe and install_loc and os.path.isdir(install_loc):
                    from app.core.steam_manager import find_game_executable
                    exe = find_game_executable(install_loc, name) or ""
                    if exe:
                        data["exe_path"] = exe
                        stale_fixed = True

                games.append({
                    "name": name,
                    "install_location": install_loc,
                    "publisher": data.get("publisher", ""),
                    "source": source or "manual",
                    "status": _sanitize_status(data.get("status", SYNC_STATUS_NOT_CONFIGURED), name),
                    "save_path": data.get("save_path", ""),
                    "on_cloud": data.get("on_cloud", False),
                    "favorite": data.get("favorite", False),
                    "exe_path": exe,
                })

        # Persist any stale status resets
        if stale_fixed:
            save_config(self.config)

        games.sort(key=lambda g: g["name"].lower())
        logger.info(f"[LoadSaved] Loaded {len(games)} games from config, displaying immediately")
        self.library_screen.set_games(games)

        # Load images (seed store poster fallback URLs from config first)
        image_cache = getattr(self, "image_cache", None)
        if image_cache:
            for g_name, g_cfg in config_games.items():
                if isinstance(g_cfg, dict) and g_cfg.get("poster_url"):
                    image_cache.set_fallback_url(g_name, str(g_cfg["poster_url"]))
        self._load_game_images([g["name"] for g in games])

        # Always scan Non-Steam shortcuts async (they are never hidden by Steam filter)
        self._start_non_steam_shortcuts_scan()

        # Add Steam games async if not hidden
        if not self.config.get("hide_steam_games", True):
            self._start_steam_scan()

        # Start per-game cloud checks if logged in
        if self._is_logged_in():
            non_steam = [g["name"] for g in games if not is_official_steam_game(g.get("source"))]
            self._start_cloud_checks(non_steam)
            # Also discover cloud-only games not in local list
            self._start_cloud_discovery()

    def _start_non_steam_shortcuts_scan(self):
        """Scan for Non-Steam shortcuts from Steam in background thread."""
        worker = NonSteamShortcutsScanWorker()
        self._run_in_thread(worker, '_shortcut_thread', {
            worker.finished: self._on_shortcuts_scan_done,
        })

    def _on_shortcuts_scan_done(self, shortcuts: list[dict]):
        """Handle async Non-Steam shortcut scan results - add to library."""
        existing_names = {name.lower() for name in self.library_screen._cards.keys()}
        config_games = self.config.get("games", {})
        manual_games = self.config.get("manual_games", [])
        removed_games = [g.lower() for g in self.config.get("removed_games", [])]

        games_to_add = []
        added_names = []
        config_modified = False

        for sc in shortcuts:
            name = sc["name"]
            name_lower = name.lower()
            if name_lower in removed_games:
                continue

            # Update existing config entry if needed
            if name in config_games:
                cfg = config_games[name]
                if cfg.get("source") == "steam":
                    # Fix: Non-Steam shortcut was misclassified as steam
                    cfg["source"] = "steam_shortcut"
                    config_modified = True
                if sc.get("exe_path") and (not cfg.get("exe_path") or "unins" in cfg.get("exe_path", "").lower()):
                    cfg["exe_path"] = sc["exe_path"]
                    config_modified = True
                if sc.get("install_location") and not cfg.get("install_location"):
                    cfg["install_location"] = sc["install_location"]
                    config_modified = True

            if name_lower not in existing_names:
                existing_names.add(name_lower)
                sc_copy = dict(sc)
                saved = config_games.get(name, {})
                sc_copy["status"] = saved.get("status", SYNC_STATUS_NOT_CONFIGURED)
                sc_copy["save_path"] = saved.get("save_path", "")
                sc_copy["on_cloud"] = saved.get("on_cloud", False)
                sc_copy["favorite"] = saved.get("favorite", False)
                if saved.get("exe_path"):
                    sc_copy["exe_path"] = saved["exe_path"]
                if saved.get("install_location"):
                    sc_copy["install_location"] = saved["install_location"]

                games_to_add.append(sc_copy)
                added_names.append(name)

                if name not in config_games:
                    config_games[name] = {
                        "source": "steam_shortcut",
                        "exe_path": sc_copy.get("exe_path", ""),
                        "install_location": sc_copy.get("install_location", ""),
                        "publisher": "Non-Steam",
                    }
                    config_modified = True
                if name not in manual_games:
                    manual_games.append(name)
                    config_modified = True

        if games_to_add:
            self.library_screen.add_games(games_to_add)

        if config_modified:
            self.config["games"] = config_games
            self.config["manual_games"] = manual_games
            save_config(self.config)

        if added_names:
            logger.info(f"[ShortcutScan] Added {len(added_names)} Non-Steam shortcuts to library")
            self._load_game_images(added_names)
            if self._is_logged_in():
                self._start_cloud_checks(added_names)

    def _start_steam_scan(self):
        """Scan for Steam games in background thread."""
        worker = SteamScanWorker()
        self._run_in_thread(worker, '_steam_thread', {
            worker.finished: self._on_steam_scan_done,
        })

    def _on_steam_scan_done(self, steam_games: list[dict]):
        """Handle async Steam scan results - add to library."""
        existing_names = {name.lower() for name in self.library_screen._cards.keys()}
        added = []
        config_games = self.config.get("games", {})
        manual_games = self.config.get("manual_games", [])

        removed_games = [g.lower() for g in self.config.get("removed_games", [])]
        games_to_add = []
        for sg in steam_games:
            if sg["name"].lower() in removed_games:
                continue
            if sg["name"].lower() not in existing_names:
                sg["on_cloud"] = True
                sg["status"] = SYNC_STATUS_SYNCED
                sg["save_path"] = "Steam Cloud"
                sg["source"] = "steam"
                games_to_add.append(sg)
                added.append(sg["name"])
                existing_names.add(sg["name"].lower())

                # Persist source=steam in config so next startup knows
                if sg["name"] not in config_games:
                    config_games[sg["name"]] = {}
                config_games[sg["name"]]["source"] = "steam"
                config_games[sg["name"]]["on_cloud"] = True
                config_games[sg["name"]]["status"] = SYNC_STATUS_SYNCED
                if sg["name"] not in manual_games:
                    manual_games.append(sg["name"])

        if games_to_add:
            self.library_screen.add_games(games_to_add)

        if added:
            self.config["games"] = config_games
            self.config["manual_games"] = manual_games
            save_config(self.config)
            logger.info(f"[SteamScan] Added {len(added)} Steam games to library")
            self._load_game_images(added)

    def _is_logged_in(self) -> bool:
        """Check if the user is connected to a cloud provider."""
        return self.cloud_client is not None and self.sync_manager is not None

    def _show_login_dialog(self):
        """Show the login popup dialog."""
        dialog = LoginDialog(self)
        dialog.login_successful.connect(self._on_login_success)
        dialog.exec()

    def _on_login_success(self, config: dict):
        """Handle successful login from dialog."""
        old_provider = self.config.get("cloud_provider", "")
        new_provider = config.get("cloud_provider", "")

        # Merge only cloud-related fields — preserve existing settings
        cloud_fields = ["cloud_provider", "cloud_url", "username", "password", "remember_me"]
        for field in cloud_fields:
            if field in config:
                self.config[field] = config[field]
        save_config(self.config)

        try:
            # Create cloud client via factory
            self.cloud_client = self._create_cloud_client(config)
            if not self.cloud_client:
                raise RuntimeError("Failed to create cloud client")

            # Create sync manager
            self.sync_manager = SyncManager(self.cloud_client, self.config)
            self.sync_manager.sync_progress.connect(self._on_sync_progress)

            # Create auto sync manager
            if self.auto_sync:
                self.auto_sync.deleteLater()
            self.auto_sync = AutoSyncManager(self.sync_manager, self)
            self.auto_sync.upload_needed.connect(self._on_auto_upload_needed)
            self.auto_sync.download_needed.connect(self._on_auto_download_needed)
            self.auto_sync.conflict_detected.connect(self._on_conflict_detected)
            
            # Start watching
            self.auto_sync.refresh_watched_games()

            # Update header state
            self.library_screen.set_logged_in(True, new_provider)
            if hasattr(self, "sidebar"):
                self.sidebar.set_account_status(True, self.config.get("username", "") or new_provider)

            # If switching providers, trigger immediate re-sync
            if old_provider and old_provider != new_provider:
                logger.info(f"Provider switched: {old_provider} -> {new_provider}. Triggering re-sync...")
                self._trigger_provider_switch_sync()
            else:
                # Normal login — re-scan games to include cloud games
                self._scan_games()

        except Exception as e:
            logger.error(f"Login setup failed: {e}")
            QMessageBox.critical(self, "Lỗi", f"Khởi tạo dịch vụ đám mây thất bại: {str(e)}")

    def _trigger_provider_switch_sync(self):
        """Upload all configured games to the new provider after a switch."""
        games = self.config.get("games", {})
        configured = [
            (name, data.get("save_path"))
            for name, data in games.items()
            if data.get("save_path") and os.path.isdir(data.get("save_path", ""))
        ]

        if not configured:
            logger.info("[ProviderSwitch] No configured games to sync to new provider")
            self._scan_games()
            return

        logger.info(f"[ProviderSwitch] Syncing {len(configured)} games to new provider")

        # Run sync concurrently in a background thread pool
        class _SwitchSyncWorker(QObject):
            progress = Signal(str, int, int)  # game_name, current_game, total_games
            finished = Signal(int, int)       # success_count, total

            def __init__(self, sync_mgr, game_list):
                super().__init__()
                self.sync_mgr = sync_mgr
                self.game_list = game_list
                self._lock = threading.Lock()
                self._completed = 0
                self._success = 0

            def _sync_single(self, name: str, save_path: str, total: int):
                ok = False
                try:
                    ok = self.sync_mgr.setup_game_sync(name, save_path)
                except Exception as e:
                    logger.error(f"[ProviderSwitch] Failed to sync {name}: {e}")
                with self._lock:
                    self._completed += 1
                    if ok:
                        self._success += 1
                    current = self._completed
                self.progress.emit(name, current, total)
                return ok

            def run(self):
                total = len(self.game_list)
                max_w = min(3, max(1, total))
                with ThreadPoolExecutor(max_workers=max_w) as pool:
                    futures = [
                        pool.submit(self._sync_single, name, save_path, total)
                        for name, save_path in self.game_list
                    ]
                    for f in as_completed(futures):
                        try:
                            f.result()
                        except Exception as e:
                            logger.error(f"[ProviderSwitch] Future error: {e}")
                self.finished.emit(self._success, total)

        self._switch_thread = QThread()
        worker = _SwitchSyncWorker(self.sync_manager, configured)
        worker.moveToThread(self._switch_thread)

        self._switch_thread.started.connect(worker.run)
        worker.finished.connect(self._on_provider_switch_done)
        worker.finished.connect(self._switch_thread.quit)
        worker.finished.connect(worker.deleteLater)
        self._switch_thread.finished.connect(self._switch_thread.deleteLater)

        self._switch_worker = worker
        self._switch_thread.start()

        # Show a notification
        provider = self.config.get("cloud_provider", "")
        provider_name = "Google Drive" if provider == PROVIDER_GOOGLE_DRIVE else "Nextcloud"
        self.tray_icon.showMessage(
            "Đang chuyển dịch vụ đám mây",
            f"Đang đồng bộ {len(configured)} trò chơi lên {provider_name}...",
            QSystemTrayIcon.MessageIcon.Information,
            3000,
        )

    def _on_provider_switch_done(self, success_count: int, total: int):
        """Handle provider switch sync completion."""
        provider = self.config.get("cloud_provider", "")
        provider_name = "Google Drive" if provider == PROVIDER_GOOGLE_DRIVE else "Nextcloud"

        logger.info(f"[ProviderSwitch] Done: {success_count}/{total} games synced to {provider_name}")
        self.tray_icon.showMessage(
            "Chuyển dịch vụ hoàn tất",
            f"Đã đồng bộ thành công {success_count}/{total} trò chơi lên {provider_name}.",
            QSystemTrayIcon.MessageIcon.Information,
            3000,
        )

        # Refresh UI
        self._scan_games()

    def _scan_games(self):
        """Scan for installed games, display them, then start cloud checks."""
        self.library_screen.show_loading(True)

        worker = LocalScanWorker()
        self._run_in_thread(worker, '_scan_thread', {
            worker.finished: self._on_local_scan_done,
        })

    def _on_local_scan_done(self, local_games: list[dict], steam_games: list[dict]):
        """Handle local game scan results, merge with config, display, then cloud-check."""
        config_games = self.config.get("games", {})
        manual_games = self.config.get("manual_games", [])

        all_names = set()
        games = []

        removed_games = [g.lower() for g in self.config.get("removed_games", [])]

        # Merge local scan results with config
        for game in local_games:
            name = game["name"]
            name_lower = name.lower()
            if name_lower in removed_games:
                continue
            if name_lower not in all_names:
                all_names.add(name_lower)
                saved = config_games.get(name, {})
                game["save_path"] = saved.get("save_path", game.get("save_path", ""))
                game["status"] = _sanitize_game_status(saved.get("status", SYNC_STATUS_NOT_CONFIGURED), name, config_games)
                game["on_cloud"] = saved.get("on_cloud", False)
                game["favorite"] = saved.get("favorite", False)

                # Prioritize saved exe_path, then scanned exe_path, then auto-detect
                exe = saved.get("exe_path") or game.get("exe_path", "")
                if not exe and game.get("install_location") and os.path.isdir(game["install_location"]):
                    from app.core.steam_manager import find_game_executable
                    exe = find_game_executable(game["install_location"], name) or ""
                game["exe_path"] = exe

                # Update config_games record
                if name not in config_games:
                    config_games[name] = {}
                config_games[name]["source"] = game.get("source", "registry")
                if exe and not config_games[name].get("exe_path"):
                    config_games[name]["exe_path"] = exe
                if game.get("install_location") and not config_games[name].get("install_location"):
                    config_games[name]["install_location"] = game.get("install_location")

                games.append(game)

        # Add manual games not found by scanner
        for manual_name in manual_games:
            if manual_name.lower() in removed_games:
                continue
            if manual_name.lower() not in all_names:
                game_cfg = config_games.get(manual_name, {})
                source = game_cfg.get("source", "manual")

                # Skip official Steam games if they are marked to be hidden
                if self.config.get("hide_steam_games", True) and is_official_steam_game(source):
                    continue

                all_names.add(manual_name.lower())
                install_loc = game_cfg.get("install_location", "")
                exe = game_cfg.get("exe_path", "")
                if not exe and install_loc and os.path.isdir(install_loc):
                    from app.core.steam_manager import find_game_executable
                    exe = find_game_executable(install_loc, manual_name) or ""
                    if exe:
                        game_cfg["exe_path"] = exe

                games.append({
                    "name": manual_name,
                    "install_location": install_loc,
                    "publisher": game_cfg.get("publisher", "Manual"),
                    "source": source,
                    "status": _sanitize_game_status(game_cfg.get("status", SYNC_STATUS_NOT_CONFIGURED), manual_name, config_games),
                    "save_path": game_cfg.get("save_path", ""),
                    "on_cloud": game_cfg.get("on_cloud", False),
                    "favorite": game_cfg.get("favorite", False),
                    "exe_path": exe,
                })

        # Also add any games from config_games that aren't in manual list or local scan
        hide_steam = self.config.get("hide_steam_games", True)
        for name, data in config_games.items():
            if name.lower() in removed_games:
                continue
            if name.lower() not in all_names:
                source = data.get("source", "")
                if hide_steam and is_official_steam_game(source):
                    continue
                all_names.add(name.lower())
                install_loc = data.get("install_location", "")
                exe = data.get("exe_path", "")
                if not exe and install_loc and os.path.isdir(install_loc):
                    from app.core.steam_manager import find_game_executable
                    exe = find_game_executable(install_loc, name) or ""
                    if exe:
                        data["exe_path"] = exe

                games.append({
                    "name": name,
                    "install_location": install_loc,
                    "publisher": data.get("publisher", "Manual"),
                    "source": source or "manual",
                    "status": _sanitize_game_status(data.get("status", SYNC_STATUS_NOT_CONFIGURED), name, config_games),
                    "save_path": data.get("save_path", ""),
                    "on_cloud": data.get("on_cloud", False),
                    "favorite": data.get("favorite", False),
                    "exe_path": exe,
                })

        # Add Steam games if setting allows
        if not self.config.get("hide_steam_games", True):
            for sg in steam_games:
                if sg["name"].lower() not in all_names:
                    all_names.add(sg["name"].lower())
                    sg["on_cloud"] = True
                    sg["status"] = SYNC_STATUS_SYNCED
                    sg["save_path"] = "Steam Cloud"
                    sg["source"] = "steam"
                    games.append(sg)

        games.sort(key=lambda g: g["name"].lower())
        logger.info(f"[LocalScan] Displaying {len(games)} games from local scan + config")

        self.library_screen.set_games(games)
        self.library_screen.show_loading(False)

        # Save game names for persistence (exclude Steam games from persistence)
        non_steam_names = [g["name"] for g in games if not is_official_steam_game(g.get("source"))]
        self.config["manual_games"] = non_steam_names
        self.config["games"] = config_games
        save_config(self.config)

        # Load images
        all_game_names = [g["name"] for g in games]
        self._load_game_images(all_game_names)

        # Start per-game cloud checks if logged in (skip Steam games)
        if self._is_logged_in():
            non_steam = [g["name"] for g in games if not is_official_steam_game(g.get("source"))]
            self._start_cloud_checks(non_steam)
            self._start_cloud_discovery()

    def _periodic_cloud_check(self):
        """Periodic check (every 30s) - re-check cloud status and auto-sync for synced games."""
        if not self._is_logged_in():
            return

        # Don't run if an active sync operation is currently running
        if self._has_active_sync():
            logger.info("[Periodic] Skipped - active sync operation in progress")
            return

        # Don't run if there are still pending checks from a previous run
        if self._cloud_check_pending > 0:
            logger.info("[Periodic] Skipped - previous cloud check still in progress")
            return

        # Find synced games from config (safe — no UI access needed)
        synced_games = []
        config_games = self.config.get("games", {})
        for name, data in config_games.items():
            if (data.get("status") == SYNC_STATUS_SYNCED
                    and not is_official_steam_game(data.get("source"))):
                synced_games.append(name)

        if not synced_games:
            return

        logger.info(f"[Periodic] Running cloud check for {len(synced_games)} synced games: {synced_games}")
        self._start_cloud_checks(synced_games)

        # Run auto-sync timestamp comparison in background QThread
        # to avoid blocking the UI with synchronous network calls
        self._run_poll_cloud_async()

    def _run_poll_cloud_async(self):
        """Run cloud polling in a background QThread to avoid emitting signals from non-Qt thread."""
        if not self.auto_sync:
            logger.debug("[PollCloud] Skipped — auto_sync not initialized")
            return

        # Skip if active sync operation is currently running
        if self._has_active_sync():
            logger.debug("[PollCloud] Skipped - active sync operation in progress")
            return

        # Skip if previous poll thread is still running
        poll_thread = getattr(self, '_poll_thread', None)

        if poll_thread and self._is_cpp_alive(poll_thread) and poll_thread.isRunning():
            logger.debug("[PollCloud] Skipped — previous poll still running")
            return

        worker = _PollCloudWorker(self.auto_sync)
        self._run_in_thread(worker, '_poll_thread', {}, done_attr='finished')

    def _start_cloud_checks(self, game_names: list[str]):
        """Start a single background thread to check all games' cloud status sequentially."""
        if not self.cloud_client:
            return

        # Clean up old check threads and workers that are already done.
        # For those still running, disconnect callbacks so they don't impact UI or crash,
        # but keep references to them so they are not GC'ed.
        active_threads = []
        active_workers = []
        for t, w in zip(self._cloud_check_threads, self._cloud_check_workers):
            try:
                if not self._is_cpp_alive(t) or not self._is_cpp_alive(w):
                    continue  # C++ object already deleted
                if t.isRunning():
                    try:
                        w.game_checked.disconnect(self._on_cloud_check_done)
                    except (TypeError, RuntimeError):
                        pass
                    active_threads.append(t)
                    active_workers.append(w)
            except RuntimeError:
                # Internal C++ object already deleted by deleteLater()
                continue
        self._cloud_check_threads = active_threads
        self._cloud_check_workers = active_workers

        self._cloud_check_pending = len(game_names)
        logger.info(f"[CloudCheck] Starting sequential cloud check for {len(game_names)} games")

        # Mark all cards as "checking" (only if window is visible)
        if not self.isHidden():
            for game_name in game_names:
                self.library_screen.update_cloud_check(game_name, "checking")

        thread = QThread()
        worker = CloudCheckBatchWorker(self.cloud_client, game_names)
        worker.moveToThread(thread)

        thread.started.connect(worker.run)
        worker.game_checked.connect(self._on_cloud_check_done)
        worker.all_done.connect(thread.quit)
        worker.all_done.connect(worker.deleteLater)

        self._cloud_check_threads.append(thread)
        self._cloud_check_workers.append(worker)
        thread.start()

    def _on_cloud_check_done(self, game_name: str, on_cloud: bool, cloud_save_path: str):
        """Handle result of a single game's cloud check."""
        logger.info(f"[CloudCheck] Result: {game_name} on_cloud={on_cloud}, path={cloud_save_path}")

        # Build the update dict with the cloud check result
        updates = {"on_cloud": on_cloud}
        config_changed = False
        path_auto_configured = False

        config_games = self.config.get("games", {})
        if on_cloud:
            # Save on_cloud=True to config permanently if not already set
            if game_name not in config_games:
                config_games[game_name] = {}
                config_changed = True
            if not config_games[game_name].get("on_cloud"):
                config_games[game_name]["on_cloud"] = True
                config_changed = True

            # Auto-setup if cloud save path exists locally and game not yet configured
            current_save_path = config_games.get(game_name, {}).get("save_path", "")
            current_status = config_games.get(game_name, {}).get("status", "")
            is_unsynced = config_games.get(game_name, {}).get("unsynced", False) or (current_status == SYNC_STATUS_NOT_SYNCED)
            if not is_unsynced and cloud_save_path and not current_save_path:
                if os.path.isdir(cloud_save_path):
                    config_games[game_name]["save_path"] = cloud_save_path
                    config_games[game_name]["status"] = SYNC_STATUS_SYNCED
                    updates["save_path"] = cloud_save_path
                    updates["status"] = SYNC_STATUS_SYNCED
                    config_changed = True
                    path_auto_configured = True
                    logger.info(f"[CloudCheck] Auto-configured {game_name} with cloud path {cloud_save_path}")
                else:
                    updates["save_path"] = cloud_save_path  # Pre-fill for SyncDialog
            elif not is_unsynced and current_save_path and current_status == SYNC_STATUS_SYNCING:
                # Reset stale 'syncing' status — no sync is actually running
                config_games[game_name]["status"] = SYNC_STATUS_SYNCED
                updates["status"] = SYNC_STATUS_SYNCED
                config_changed = True
                logger.info(f"[CloudCheck] Reset stale 'syncing' status for {game_name} → synced")

            if config_changed:
                self.config["games"] = config_games
                save_config(self.config)
        else:
            # If config says on_cloud but cloud says not, update config
            if config_games.get(game_name, {}).get("on_cloud"):
                config_games[game_name]["on_cloud"] = False
                self.config["games"] = config_games
                save_config(self.config)

        # Update game_data FIRST so badge reads the correct on_cloud value
        self.library_screen.update_game_data(game_name, updates)

        # THEN mark cloud check as "done" — badge will now show the correct state
        self.library_screen.update_cloud_check(game_name, "done")

        # Update active dialog if open
        if self._active_dialog and self._active_dialog.game_name == game_name:
            self._active_dialog.on_cloud = on_cloud
            if hasattr(self._active_dialog, 'cloud_indicator'):
                if on_cloud:
                    self._active_dialog.cloud_indicator.setText("● Có trên Cloud")
                    self._active_dialog.cloud_indicator.setStyleSheet("color: #22c55e; font-size: 13px; font-weight: bold;")
                else:
                    self._active_dialog.cloud_indicator.setText("○ Chưa có trên Cloud")
                    self._active_dialog.cloud_indicator.setStyleSheet("color: #94a3b8; font-size: 13px;")

        # Track completion
        self._cloud_check_pending -= 1
        if self._cloud_check_pending <= 0:
            logger.info("[CloudCheck] All cloud checks completed")
            # Only refresh auto-sync watcher if a game was newly auto-configured with a save path
            if path_auto_configured and self.auto_sync:
                self.auto_sync.refresh_watched_games()

    def _start_cloud_discovery(self):
        """Discover games on the cloud that aren't in the local list."""
        if not self.cloud_client:
            return

        worker = CloudGameDiscoveryWorker(self.cloud_client)
        # error signal also needs to quit the thread
        worker.error.connect(lambda e: logger.error(f"[CloudDiscovery] Error: {e}"))
        self._run_in_thread(worker, '_discovery_thread', {
            worker.finished: self._on_cloud_discovery_done,
        })

    def _on_cloud_discovery_done(self, cloud_game_names: list[str]):
        """Handle discovery of cloud-only games - add them to the library."""
        existing_names = {name.lower() for name in self.library_screen._cards.keys()}
        new_games = []

        config_games = self.config.get("games", {})
        manual_games = self.config.get("manual_games", [])

        removed_games = [g.lower() for g in self.config.get("removed_games", [])]
        for cloud_name in cloud_game_names:
            if cloud_name.lower() in removed_games:
                continue
            if cloud_name.lower() not in existing_names:
                logger.info(f"[CloudDiscovery] Found cloud-only game: {cloud_name}")
                game_data = {
                    "name": cloud_name,
                    "install_location": "",
                    "publisher": "Cloud",
                    "source": "cloud",
                    "status": SYNC_STATUS_NOT_SYNCED,
                    "save_path": "",
                    "on_cloud": True,
                }
                self.library_screen.add_game(game_data)
                new_games.append(cloud_name)

                # Save to config
                if cloud_name not in config_games:
                    config_games[cloud_name] = {}
                config_games[cloud_name]["on_cloud"] = True
                if cloud_name not in manual_games:
                    manual_games.append(cloud_name)

        if new_games:
            self.config["games"] = config_games
            self.config["manual_games"] = manual_games
            save_config(self.config)
            logger.info(f"[CloudDiscovery] Added {len(new_games)} new cloud games")

            # Load images and start cloud checks for new games
            self._load_game_images(new_games)
            self._start_cloud_checks(new_games)

    def _load_game_images(self, game_names: list[str]):
        """Load game images asynchronously via queue without blocking or thread churn."""
        if not self.image_cache or not game_names:
            return

        if not hasattr(self, "image_loader") or self.image_loader is None:
            self.image_loader = AsyncImageLoader(self.image_cache, max_workers=6, parent=self)
            self.image_loader.image_ready.connect(self._on_image_loaded)

        self.image_loader.enqueue(game_names)

    def _on_image_loaded(self, game_name: str, image_path: str):
        """Handle image loaded from background."""
        self.library_screen.update_game_image(game_name, image_path)

    def _on_game_selected(self, game_data: dict):
        """Handle game card click - check login before opening sync dialog."""
        # Block sync for official Steam games (they use Steam Cloud)
        if is_official_steam_game(game_data):
            QMessageBox.information(
                self,
                "Steam Cloud Save",
                f"Trò chơi \"{game_data.get('name', 'Này')}\" sử dụng tính năng Steam Cloud Save.\n\n"
                "Dữ liệu lưu game do Steam tự động quản lý.\n"
                "Không cần cấu hình đồng bộ thêm.",
            )
            return

        if not self._require_login():
            return

        # Ensure config fields are populated into game_data
        config_game = self.config.get("games", {}).get(game_data.get("name", ""), {})
        if "exe_path" in config_game and "exe_path" not in game_data:
            game_data["exe_path"] = config_game["exe_path"]
        if "status" in config_game:
            game_data["status"] = config_game["status"]
        if "on_cloud" in config_game:
            game_data["on_cloud"] = config_game["on_cloud"]
        if "exclude_patterns" in config_game:
            game_data["exclude_patterns"] = config_game["exclude_patterns"]

        dialog = SyncDialog(game_data, self)
        dialog.sync_requested.connect(self._on_sync_requested)
        dialog.download_requested.connect(self._on_download_requested)
        dialog.sync_now_requested.connect(self._on_sync_now_from_dialog)
        dialog.unsync_requested.connect(self._on_unsync_requested)
        dialog.exe_path_changed.connect(self._on_game_exe_changed)
        dialog.exclude_patterns_changed.connect(self._on_game_exclude_patterns_changed)

        self._active_dialog = dialog
        existing_thread = getattr(self, "_active_sync_threads", {}).get(game_data.get("name", ""))
        if existing_thread and self._is_cpp_alive(existing_thread) and existing_thread.isRunning():
            existing_worker = getattr(self, "_active_sync_workers", {}).get(game_data.get("name", ""))
            if existing_worker:
                dialog._current_operation = existing_worker.operation
            dialog.show_progress(True)
            if getattr(dialog, "_current_operation", "sync") == "upload":
                dialog.show_message("Đang tải lên dữ liệu lưu game...", "info")
            elif getattr(dialog, "_current_operation", "sync") == "download":
                dialog.show_message("Đang tải về dữ liệu lưu game...", "info")
            else:
                dialog.show_message("Đang đồng bộ trong tiến trình ngầm...", "info")

        dialog.exec()
        self._active_dialog = None


    def _on_sync_requested(self, game_name: str, save_path: str):
        """Handle sync request from dialog."""
        self._run_sync_operation("upload", game_name, save_path)

    def _on_sync_now_from_card(self, game_data: dict):
        """Handle Sync Now button click on a game card — smart sync with version check."""
        game_name = game_data.get("name", "")
        save_path = game_data.get("save_path", "")

        if not game_name or not save_path:
            return

        if not self._require_login():
            return

        logger.info(f"[SyncNow] Smart sync triggered for {game_name}")
        self._run_sync_now_check(game_name, game_data)

    def _on_sync_now_from_dialog(self, game_name: str, save_path: str):
        """Handle Sync Now button click from sync dialog — smart sync with version check."""
        if not self._is_logged_in() or not self.sync_manager:
            return

        game_data = self.config.get("games", {}).get(game_name, {})
        game_data["name"] = game_name
        game_data["save_path"] = save_path

        logger.info(f"[SyncNow] Smart sync triggered from dialog for {game_name}")
        self._run_sync_now_check(game_name, game_data)

    def _run_sync_now_check(self, game_name: str, game_data: dict = None):
        """Run a background timestamp check, then decide upload/download/conflict."""
        if not self.sync_manager:
            return

        # Update card status to show we're checking
        self.library_screen.update_game_status(game_name, "syncing")

        worker = SyncNowCheckWorker(self.sync_manager, game_name)
        self._run_in_thread(worker, '_sync_now_thread', {
            worker.result_ready: self._on_sync_now_check_done,
        }, done_attr='result_ready')

    @Slot(str, str, float, float, float)
    def _on_sync_now_check_done(self, game_name: str, decision: str,
                                 local_time: float, remote_time: float, last_sync: float):
        """Handle result of the sync now timestamp check on the main GUI thread."""
        game_data = self.config.get("games", {}).get(game_name, {})
        save_path = game_data.get("save_path", "")
        logger.info(f"[SyncNow] Decision for {game_name}: {decision}")

        if decision == "upload":
            if self._active_dialog and self._active_dialog.game_name == game_name:
                self._active_dialog._current_operation = "upload"
                self._active_dialog.show_message("⬆ Uploading — local saves are newer", "info")
            self._run_sync_operation("sync", game_name, save_path)

        elif decision == "download":
            if self._active_dialog and self._active_dialog.game_name == game_name:
                self._active_dialog._current_operation = "download"
                self._active_dialog.show_message("⬇ Downloading — cloud saves are newer", "info")
            self._run_sync_operation("download", game_name, save_path)

        elif decision == "conflict":
            # Reset syncing status before showing dialog
            self.library_screen.update_game_status(game_name, game_data.get("status", "synced"))
            if self._active_dialog and self._active_dialog.game_name == game_name:
                self._active_dialog.show_progress(False)
                self._active_dialog.show_message("Phát hiện xung đột — cả máy và đám mây đều có thay đổi mới!", "warning")
            self._on_conflict_detected(game_name, game_data, local_time, remote_time)

        elif decision in ("up_to_date", "none"):
            # Nothing to do — already in sync
            self.library_screen.update_game_status(game_name, "synced")
            if self._active_dialog and self._active_dialog.game_name == game_name:
                self._active_dialog.show_progress(False)
                self._active_dialog.show_message("Dữ liệu đã mới nhất — không phát hiện thay đổi", "success")

        elif decision == "error":
            self.library_screen.update_game_status(game_name, "error")
            if self._active_dialog and self._active_dialog.game_name == game_name:
                self._active_dialog.show_progress(False)
                self._active_dialog.show_message("Không thể kiểm tra trạng thái đồng bộ", "error")

        else:
            self.library_screen.update_game_status(game_name, "synced")
            if self._active_dialog and self._active_dialog.game_name == game_name:
                self._active_dialog.show_progress(False)
                self._active_dialog.show_message(f"Status: {decision}", "info")

    def _on_download_requested(self, game_name: str):
        """Handle download request from dialog."""
        # Get save path from config or cloud
        save_path = ""
        config_games = self.config.get("games", {})
        if game_name in config_games:
            save_path = config_games[game_name].get("save_path", "")

        self._run_sync_operation("download", game_name, save_path)

    def _on_auto_upload_needed(self, game_name: str, save_path: str):
        """Handle background auto-upload request."""
        logger.info(f"Auto-upload triggered for {game_name}")
        self._run_sync_operation("sync", game_name, save_path)

    def _on_auto_download_needed(self, game_name: str, save_path: str):
        """Handle background auto-download request."""
        logger.info(f"Auto-download triggered for {game_name}")
        self._run_sync_operation("download", game_name, save_path)

    def _on_conflict_detected(self, game_name: str, game_data: dict, local_time: float, remote_time: float):
        """Handle save file conflict by prompting user."""
        # Guard: skip if a conflict dialog is already showing (prevents re-entrant dialogs
        # from periodic timers firing during the dialog's lifetime)
        if self._conflict_dialog is not None:
            logger.warning(f"Conflict dialog already showing, ignoring conflict for {game_name}")
            return

        # If window is hidden (minimized to tray) or minimized, queue the conflict
        # instead of popping up a dialog that forces the app to re-appear
        is_minimized = bool(self.windowState() & Qt.WindowState.WindowMinimized)
        if self.isHidden() or is_minimized:
            logger.info(f"[Conflict] Window hidden, queuing conflict for {game_name}")
            self._pending_conflicts.append({
                "game_name": game_name,
                "game_data": dict(game_data),  # snapshot
                "local_time": local_time,
                "remote_time": remote_time,
            })
            self.tray_icon.showMessage(
                "Phát hiện xung đột lưu game",
                f"{game_name}: Dữ liệu lưu trên máy và đám mây không khớp.\n"
                "Mở ứng dụng để giải quyết xung đột.",
                QSystemTrayIcon.MessageIcon.Warning,
                5000,
            )
            return

        logger.warning(f"Showing conflict dialog for {game_name}")

        # Snapshot save_path now so the closure doesn't depend on a mutable dict reference
        save_path = game_data.get("save_path", "")

        # Parent to active SyncDialog if visible, so ConflictDialog renders directly on top
        parent_widget = self
        if self._active_dialog and self._is_cpp_alive(self._active_dialog) and self._active_dialog.isVisible():
            parent_widget = self._active_dialog

        dialog = ConflictDialog(game_name, local_time, remote_time, parent_widget)
        self._conflict_dialog = dialog

        def on_resolved(name: str, resolution: str):
            if resolution == "local":
                logger.info(f"Conflict resolved: User chose to upload local save for {name}")
                if self._active_dialog and self._is_cpp_alive(self._active_dialog) and self._active_dialog.game_name == name:
                    self._active_dialog.show_progress(True)
                    self._active_dialog.show_message("Đang tải dữ liệu lưu game lên Cloud...", "info")
                self._run_sync_operation("upload", name, save_path)
            elif resolution == "cloud":
                logger.info(f"Conflict resolved: User chose to download cloud save for {name}")
                if self._active_dialog and self._is_cpp_alive(self._active_dialog) and self._active_dialog.game_name == name:
                    self._active_dialog.show_progress(True)
                    self._active_dialog.show_message("Đang tải dữ liệu lưu game từ Cloud về...", "info")
                self._run_sync_operation("download", name, save_path)

        def on_dialog_finished():
            self._conflict_dialog = None
            # Chain: show next pending conflict if any
            if self._pending_conflicts:
                QTimer.singleShot(200, self._show_pending_conflicts)

        dialog.resolved.connect(on_resolved)
        dialog.finished.connect(on_dialog_finished)
        dialog.show()
        dialog.raise_()
        dialog.activateWindow()

    def _run_sync_operation(self, operation: str, game_name: str, save_path: str):
        """Run a sync operation in background asynchronously."""
        if not self.sync_manager:
            return

        if not hasattr(self, "_active_sync_threads"):
            self._active_sync_threads = {}
        if not hasattr(self, "_active_sync_workers"):
            self._active_sync_workers = {}

        # Guard: If this game is already actively syncing, skip redundant trigger
        existing_thread = self._active_sync_threads.get(game_name)
        if existing_thread and self._is_cpp_alive(existing_thread) and existing_thread.isRunning():
            logger.info(f"[Sync] Operation already running for {game_name}, skipping.")
            if self._active_dialog and self._active_dialog.game_name == game_name:
                self._active_dialog.show_progress(True)
                self._active_dialog.show_message("Đang đồng bộ trong tiến trình ngầm...", "info")
            return

        # Update card status
        self.library_screen.update_game_status(game_name, "syncing")

        worker = SyncWorker(self.sync_manager, operation, game_name, save_path)
        thread = QThread()
        worker.moveToThread(thread)
        thread.started.connect(worker.run)

        worker.progress.connect(self._on_sync_progress)

        def _cleanup(g=game_name, success=False, message=""):
            try:
                self._on_sync_finished(g, success, message)
            finally:
                if hasattr(self, "_active_sync_threads"):
                    self._active_sync_threads.pop(g, None)
                if hasattr(self, "_active_sync_workers"):
                    self._active_sync_workers.pop(g, None)

        worker.finished.connect(_cleanup)
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)

        self._active_sync_threads[game_name] = thread
        self._active_sync_workers[game_name] = worker
        self._sync_thread = thread

        thread.start()

    @Slot(str, int, int)
    @Slot(str, int, int, float, int, int)
    def _on_sync_progress(self, game_name: str, current: int, total: int, speed: float = 0.0, bytes_done: int = 0, total_bytes: int = 0):
        """Handle sync progress update."""
        if self._active_dialog and self._is_cpp_alive(self._active_dialog) and self._active_dialog.game_name == game_name:
            self._active_dialog.update_progress(current, total, speed, bytes_done, total_bytes)

    def _on_sync_finished(self, game_name: str, success: bool, message: str):
        """Handle sync completion."""
        # Reload config first to get the latest save path
        self.config = load_config()
        if self.sync_manager:
            self.sync_manager.config = self.config

        new_status = SYNC_STATUS_SYNCED if success else "error"
        
        if success:
            game_config = self.config.get("games", {}).get(game_name, {})
            self.library_screen.update_game_data(game_name, {
                "status": new_status,
                "save_path": game_config.get("save_path", ""),
                "on_cloud": True,
            })
        else:
            self.library_screen.update_game_status(game_name, new_status)

        # Update dialog if still open
        if self._active_dialog and self._active_dialog.game_name == game_name:
            self._active_dialog.on_sync_complete(success, message)

    def _on_add_game(self):
        """Handle add game manually using AddGameDialog with .exe and save path."""
        existing_names = list(self.library_screen._cards.keys())
        dialog = AddGameDialog(existing_names=existing_names, parent=self)

        def _add(data):
            name = data.get("name", "").strip()
            exe_path = data.get("exe_path", "").strip()
            save_path = data.get("save_path", "").strip()
            if not name:
                return

            game_data = {
                "name": name,
                "install_location": "",
                "publisher": "Manual",
                "source": "manual",
                "status": SYNC_STATUS_NOT_CONFIGURED,
                "save_path": save_path,
                "exe_path": exe_path,
                "on_cloud": False,
            }

            # Check if it exists on cloud
            if self.cloud_client:
                try:
                    game_data["on_cloud"] = self.cloud_client.check_game_exists(name)
                    if game_data["on_cloud"]:
                        game_data["status"] = SYNC_STATUS_NOT_SYNCED
                except Exception:
                    pass

            self.library_screen.add_game(game_data)

            # Save to config so it persists across restarts
            manual_games = self.config.get("manual_games", [])
            if name not in manual_games:
                manual_games.append(name)
                self.config["manual_games"] = manual_games

            # Un-blacklist from removed_games if re-added
            removed_games = self.config.get("removed_games", [])
            self.config["removed_games"] = [g for g in removed_games if g.lower() != name.lower()]

            if "games" not in self.config:
                self.config["games"] = {}
            if name not in self.config["games"]:
                self.config["games"][name] = {}

            self.config["games"][name]["name"] = name
            if exe_path:
                self.config["games"][name]["exe_path"] = exe_path
            if save_path:
                self.config["games"][name]["save_path"] = save_path
                self.config["games"][name]["status"] = game_data["status"]
            self.config["games"][name]["source"] = "manual"
            self.config["games"][name]["on_cloud"] = game_data["on_cloud"]
            save_config(self.config)

            # Load image for the new game
            if self.image_cache:
                self._load_game_images([name])

        dialog.game_added.connect(_add)
        dialog.exec()

    def _on_game_exe_changed(self, game_name: str, exe_path: str):
        """Save updated executable path for game."""
        if "games" not in self.config:
            self.config["games"] = {}
        if game_name not in self.config["games"]:
            self.config["games"][game_name] = {}
        self.config["games"][game_name]["exe_path"] = exe_path
        save_config(self.config)
        self.library_screen.update_game_data(game_name, {"exe_path": exe_path})
        logger.info(f"Updated exe_path for {game_name}: {exe_path}")

        # If this is an online-fix game without steam shortcut yet, auto-add to Steam
        game_cfg = self.config.get("games", {}).get(game_name, {})
        if game_cfg.get("online_fix") and not game_cfg.get("steam_shortcut") and exe_path and os.path.isfile(exe_path):
            self._start_auto_steam_add(game_name, exe_path, game_cfg.get("install_location"))

    def _on_game_exclude_patterns_changed(self, game_name: str, patterns: list[str]):
        """Save updated exclude patterns for game."""
        if "games" not in self.config:
            self.config["games"] = {}
        if game_name not in self.config["games"]:
            self.config["games"][game_name] = {}
        self.config["games"][game_name]["exclude_patterns"] = patterns
        save_config(self.config)
        self.library_screen.update_game_data(game_name, {"exclude_patterns": patterns})
        logger.info(f"Updated exclude_patterns for {game_name}: {patterns}")
        if hasattr(self, "auto_sync") and self.auto_sync:
            self.auto_sync.refresh_watched_games()
        if hasattr(self, "sync_manager") and self.sync_manager and self.config["games"][game_name].get("on_cloud"):
            import threading
            threading.Thread(
                target=self.sync_manager.upload_bobignore,
                args=(game_name, self.config["games"][game_name].get("save_path")),
                daemon=True,
                name=f"UploadBobignore-{game_name}",
            ).start()

    def _on_exclude_requested_from_card(self, game_data: dict):
        """Handle right-click 'Exclude files...' from game card context menu."""
        game_name = game_data.get("name", "")
        save_path = game_data.get("save_path", "")

        config_game = self.config.get("games", {}).get(game_name, {})
        if not save_path:
            save_path = config_game.get("save_path", "")

        if not save_path or not os.path.isdir(save_path):
            QMessageBox.information(
                self,
                "Yêu cầu thư mục lưu game",
                f"Vui lòng thiết lập thư mục lưu game cho \"{game_name}\" trước khi cấu hình quy tắc loại trừ."
            )
            return

        patterns = config_game.get("exclude_patterns", game_data.get("exclude_patterns", []))

        try:
            from app.ui.exclude_dialog import ExcludeDialog
            dialog = ExcludeDialog(game_name, save_path, patterns, parent=self)
            if dialog.exec():
                updated_patterns = dialog.get_patterns()
                self._on_game_exclude_patterns_changed(game_name, updated_patterns)
                game_data["exclude_patterns"] = updated_patterns
        except Exception as e:
            logger.error(f"Error opening ExcludeDialog from card: {e}", exc_info=True)
            QMessageBox.critical(self, "Lỗi", f"Không thể mở hộp thoại loại trừ file:\n{e}")

    def _on_unsync_requested(self, game_name: str, delete_remote: bool):
        """Handle un-sync request for a game."""
        logger.info(f"Un-sync requested for {game_name} (delete_remote={delete_remote})")
        if self.auto_sync:
            self.auto_sync.stop_watching(game_name)

        if self.sync_manager:
            self.sync_manager.unsync_game(game_name, delete_from_cloud=delete_remote)

        new_on_cloud = False if delete_remote else True
        self.library_screen.update_game_data(game_name, {
            "status": SYNC_STATUS_NOT_SYNCED,
            "on_cloud": new_on_cloud
        })

        if self._active_dialog and self._active_dialog.game_name == game_name:
            self._active_dialog.status = SYNC_STATUS_NOT_SYNCED
            self._active_dialog.on_cloud = new_on_cloud
            self._active_dialog._update_status_label()
            self._active_dialog._update_ui_state()
            self._active_dialog.show_message(
                f"Đã hủy đồng bộ trò chơi thành công. Bản lưu {'đã xóa khỏi' if delete_remote else 'vẫn giữ trên'} đám mây.",
                "info"
            )

        self.tray_icon.showMessage(
            "Bob Gaming Game Center",
            f"Đã hủy đồng bộ {game_name}" + (" và xóa khỏi đám mây." if delete_remote else "."),
            QSystemTrayIcon.MessageIcon.Information,
            2500
        )

    def _on_unsync_from_card(self, game_data: dict):
        """Handle un-sync triggered from game card context menu."""
        game_name = game_data.get("name", "")
        if not game_name:
            return

        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Hủy đồng bộ trò chơi")
        msg_box.setText(f"Bạn có chắc chắn muốn hủy đồng bộ \"{game_name}\"?")
        msg_box.setInformativeText("Chọn cách xử lý dữ liệu lưu game trên đám mây (Cloud):")

        btn_keep_cloud = msg_box.addButton("Giữ lại bản sao Cloud", QMessageBox.ButtonRole.ActionRole)
        btn_delete_cloud = msg_box.addButton("Xóa bản sao Cloud", QMessageBox.ButtonRole.DestructiveRole)
        btn_cancel = msg_box.addButton("Hủy bỏ", QMessageBox.ButtonRole.RejectRole)

        btn_delete_cloud.setObjectName("dangerBtn")
        btn_cancel.setObjectName("secondaryBtn")

        msg_box.setDefaultButton(btn_keep_cloud)
        msg_box.exec()

        clicked = msg_box.clickedButton()
        if clicked == btn_cancel or clicked is None:
            return

        delete_remote = (clicked == btn_delete_cloud)
        self._on_unsync_requested(game_name, delete_remote)

    def _on_game_process_exited(self, game_name: str, exe_path: str):
        """Handle game process exit detected by ProcessMonitor."""
        logger.info(f"[AutoPostSync] Game process closed for {game_name} ({exe_path})")
        if self._update_pending is not None and not self._is_game_active():
            QTimer.singleShot(800, self._flush_pending_update_dialog)
        game_data = self.config.get("games", {}).get(game_name, {})
        save_path = game_data.get("save_path", "")

        if not save_path or not os.path.exists(save_path):
            logger.warning(f"[AutoPostSync] No valid save path configured for {game_name}, skipping post-game sync")
            return

        if not self._is_logged_in() or not self.sync_manager:
            logger.warning(f"[AutoPostSync] Not logged in to cloud provider, skipping post-game sync")
            return

        self.tray_icon.showMessage(
            "Bob Gaming Game Center",
            f"'{game_name}' đã đóng. Đang đồng bộ lưu game lên đám mây...",
            QSystemTrayIcon.MessageIcon.Information,
            3500
        )
        # Immediate sync operation
        self._run_sync_operation("sync", game_name, save_path)


    def _on_remove_game(self, game_data: dict):
        """Handle remove game from list."""
        game_name = game_data.get("name", "")
        if not game_name:
            return

        reply = QMessageBox.question(
            self,
            "Xóa trò chơi",
            f"Bạn có chắc chắn muốn xóa \"{game_name}\" khỏi danh sách thư viện?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )

        if reply == QMessageBox.StandardButton.Yes:
            # 1. Remove card from UI
            removed = self.library_screen.remove_game(game_name)
            logger.info(f"[RemoveGame] Removed '{game_name}' from library screen: {removed}")

            # 2. Remove from config["games"]
            config_games = self.config.get("games", {})
            keys_to_del = [k for k in config_games.keys() if k.lower() == game_name.lower()]
            for k in keys_to_del:
                del config_games[k]
            self.config["games"] = config_games

            # 3. Remove from config["manual_games"]
            manual_games = self.config.get("manual_games", [])
            self.config["manual_games"] = [m for m in manual_games if m.lower() != game_name.lower()]

            # 4. Add to removed_games list so auto-scanners don't resurrect it
            removed_games = self.config.get("removed_games", [])
            if not any(r.lower() == game_name.lower() for r in removed_games):
                removed_games.append(game_name)
            self.config["removed_games"] = removed_games

            save_config(self.config)
            logger.info(f"[RemoveGame] Successfully removed '{game_name}' from library and config")

            self.tray_icon.showMessage(
                "Bob Gaming Game Center",
                f"Đã xóa \"{game_name}\" khỏi thư viện trò chơi.",
                QSystemTrayIcon.MessageIcon.Information,
                2000,
            )

    def _on_launch_game(self, game_data: dict):
        """Launch a game via Steam Non-Steam shortcut (or direct .exe fallback) on a background QThread."""
        try:
            game_name = (game_data.get("name") or "").strip()
            cfg_games = self.config.setdefault("games", {})
            cfg_entry = cfg_games.get(game_name) or {}
            merged = {**cfg_entry, **(game_data or {})}

            exe_path = str(merged.get("exe_path") or "").strip().strip('"')
            install_loc = str(merged.get("install_location") or "").strip().strip('"')
            force_direct = bool(game_data.get("_force_direct_exe", False))
            if not game_name and exe_path:
                game_name = os.path.splitext(os.path.basename(exe_path))[0]
            if not game_name:
                return

            if not hasattr(self, "_launch_threads"):
                self._launch_threads = {}
            if not hasattr(self, "_launch_workers"):
                self._launch_workers = {}

            existing_thread = self._launch_threads.get(game_name)
            if existing_thread and self._is_cpp_alive(existing_thread) and existing_thread.isRunning():
                logger.info(f"[Library/Launch] Launch already in progress for {game_name!r}")
                return

            # Ensure ProcessMonitor sees exe_path in config["games"] for post-exit Auto-Sync Save
            if exe_path and os.path.isfile(exe_path):
                entry = cfg_games.setdefault(game_name, {})
                if entry.get("exe_path") != exe_path:
                    entry["exe_path"] = exe_path
                    save_config(self.config)

            from app.core.game_launcher import GameLaunchWorker
            from app.core.steam_manager import needs_steam_reload_for_shortcut

            pending_ts = cfg_entry.get("steam_pending_reload_ts")
            ensure_pending = bool(pending_ts is not None or merged.get("online_fix"))

            if not force_direct and needs_steam_reload_for_shortcut(
                game_name, exe_path, persisted_pending_ts=pending_ts
            ):
                self.tray_icon.showMessage(
                    "Bob Gaming Game Center",
                    f"Đang khởi động lại Steam để nạp phím tắt và mở \"{game_name}\"...",
                    QSystemTrayIcon.MessageIcon.Information,
                    3000,
                )

            worker = GameLaunchWorker(
                game_name=game_name,
                exe_path=exe_path,
                install_location=install_loc,
                force_direct_exe=force_direct,
                persisted_pending_ts=pending_ts,
                ensure_shortcut_if_pending=ensure_pending,
            )
            thread = QThread(self)
            worker.moveToThread(thread)

            thread.started.connect(worker.run)
            worker.finished.connect(self._on_launch_game_finished)
            worker.finished.connect(thread.quit)
            worker.finished.connect(worker.deleteLater)
            thread.finished.connect(thread.deleteLater)

            def _cleanup(g=game_name):
                self._launch_threads.pop(g, None)
                self._launch_workers.pop(g, None)

            thread.finished.connect(_cleanup)

            self._launch_threads[game_name] = thread
            self._launch_workers[game_name] = worker
            thread.start()
        except Exception:
            logger.exception("[Library/Launch] Failed to start game launch worker")
            QMessageBox.warning(self, "Không thể khởi chạy", "Đã xảy ra lỗi khi khởi chạy trò chơi.")

    @Slot(dict)
    def _on_launch_game_finished(self, result: dict):
        """Handle completion of GameLaunchWorker on the UI thread."""
        try:
            game_name = (result.get("game_name") or "").strip()
            if not result.get("success"):
                err_msg = str(result.get("error") or "Không thể khởi chạy trò chơi.")
                QMessageBox.warning(self, "Không thể khởi chạy trò chơi", err_msg)
                return

            if game_name and result.get("mode") == "steam":
                cfg_entry = (self.config.get("games") or {}).get(game_name)
                if isinstance(cfg_entry, dict) and "steam_pending_reload_ts" in cfg_entry:
                    cfg_entry.pop("steam_pending_reload_ts", None)
                    save_config(self.config)
        except Exception:
            logger.exception("[Library/Launch] Error in _on_launch_game_finished slot")

    def _purge_game_from_library_and_config(self, game_name: str) -> bool:
        """Remove a game card from LibraryScreen and persist removal in config.json."""
        removed = self.library_screen.remove_game(game_name)
        config_games = self.config.get("games", {})
        for k in [k for k in list(config_games.keys()) if k.lower() == game_name.lower()]:
            del config_games[k]
        self.config["games"] = config_games
        self.config["manual_games"] = [
            m for m in self.config.get("manual_games", []) if m.lower() != game_name.lower()
        ]
        removed_games = self.config.get("removed_games", [])
        if not any(r.lower() == game_name.lower() for r in removed_games):
            removed_games.append(game_name)
        self.config["removed_games"] = removed_games
        save_config(self.config)
        return removed

    def _on_uninstall_game(self, game_data: dict):
        """Confirm and run background game uninstallation (files + Library + Non-Steam shortcut)."""
        try:
            game_name = (game_data.get("name") or "").strip()
            if not game_name:
                return

            if not hasattr(self, "_uninstall_threads"):
                self._uninstall_threads = {}
            if not hasattr(self, "_uninstall_workers"):
                self._uninstall_workers = {}

            existing_thread = self._uninstall_threads.get(game_name)
            if existing_thread and self._is_cpp_alive(existing_thread) and existing_thread.isRunning():
                logger.info(f"[Library/Uninstall] Uninstall already running for {game_name!r}")
                return

            from app.core.game_uninstaller import (
                GameUninstallWorker,
                is_safe_delete_dir,
                resolve_game_install_dir,
            )
            from app.core.steam_manager import (
                find_steam_path,
                has_non_steam_shortcut,
                is_steam_running,
            )
            from app.ui.uninstall_game_dialog import UninstallGameDialog

            cfg_entry = (self.config.get("games") or {}).get(game_name) or {}
            merged = {**cfg_entry, **(game_data or {})}
            exe_path = str(merged.get("exe_path") or "").strip().strip('"')
            save_path = str(merged.get("save_path") or "").strip().strip('"')

            other_exes: list[str] = []
            for gd in self.library_screen.get_games():
                if (gd.get("name") or "").strip().lower() != game_name.lower() and gd.get("exe_path"):
                    other_exes.append(str(gd["exe_path"]))
            for gname, gd in (self.config.get("games") or {}).items():
                if gname.strip().lower() != game_name.lower() and isinstance(gd, dict) and gd.get("exe_path"):
                    other_exes.append(str(gd["exe_path"]))

            steam_path = find_steam_path()
            online_fix_root = str(self.config.get("online_fix_install_root") or "").strip()
            extra_protected = [p for p in (online_fix_root, steam_path) if p]

            resolved_dir, refusal_reason = resolve_game_install_dir(
                merged,
                other_game_exes=other_exes,
                extra_protected_dirs=extra_protected,
            )

            save_deletable = False
            if save_path and os.path.exists(save_path):
                if os.path.isdir(save_path):
                    save_deletable, _ = is_safe_delete_dir(
                        save_path,
                        other_game_exes=other_exes,
                        extra_protected_dirs=extra_protected,
                    )
                elif os.path.isfile(save_path):
                    save_deletable = True

            has_shortcut = bool(steam_path and has_non_steam_shortcut(game_name, exe_path, steam_path=steam_path))
            steam_running = bool(has_shortcut and is_steam_running())

            dlg = UninstallGameDialog(
                game_name=game_name,
                resolved_dir=resolved_dir,
                refusal_reason=refusal_reason,
                has_shortcut=has_shortcut,
                steam_running=steam_running,
                save_path=save_path,
                save_deletable=save_deletable,
                parent=self,
            )
            if not dlg.exec():
                logger.info(f"[Library/Uninstall] User cancelled uninstall dialog for {game_name!r}")
                return

            if getattr(self, "auto_sync", None):
                try:
                    self.auto_sync.stop_watching(game_name)
                except Exception:
                    pass

            card = self.library_screen.get_card(game_name)
            if card is not None:
                card.setEnabled(False)

            worker = GameUninstallWorker(
                game_name=game_name,
                exe_path=exe_path,
                install_dir=resolved_dir,
                delete_save=dlg.should_delete_save,
                save_path=save_path,
                remove_steam_shortcut=True,
                restart_steam=False,
                steam_path=steam_path,
                other_game_exes=other_exes,
                extra_protected_dirs=extra_protected,
            )
            thread = QThread(self)
            worker.moveToThread(thread)

            thread.started.connect(worker.run)
            worker.finished.connect(self._on_uninstall_game_finished)
            worker.finished.connect(thread.quit)
            worker.finished.connect(worker.deleteLater)
            thread.finished.connect(thread.deleteLater)

            def _cleanup(g=game_name):
                self._uninstall_threads.pop(g, None)
                self._uninstall_workers.pop(g, None)

            thread.finished.connect(_cleanup)

            self._uninstall_threads[game_name] = thread
            self._uninstall_workers[game_name] = worker
            logger.info(f"[Library/Uninstall] Dispatched background uninstall thread for {game_name!r}")
            thread.start()
        except Exception:
            logger.exception("[Library/Uninstall] Failed to start game uninstall")
            QMessageBox.critical(self, "Lỗi gỡ cài đặt", "Không thể khởi chạy tiến trình gỡ cài đặt trò chơi.")

    @Slot(dict)
    def _on_uninstall_game_finished(self, result: dict):
        """Handle completion of background GameUninstallWorker on the UI thread."""
        try:
            game_name = (result.get("game_name") or "").strip()
            if not game_name:
                return

            if not result.get("success"):
                card = self.library_screen.get_card(game_name)
                if card is not None:
                    card.setEnabled(True)
                if getattr(self, "auto_sync", None):
                    try:
                        self.auto_sync.refresh_watched_games()
                    except Exception:
                        pass
                err_msg = str(result.get("error") or "Gỡ cài đặt trò chơi thất bại.")
                QMessageBox.warning(self, "Không thể gỡ cài đặt", err_msg)
                return

            removed = self._purge_game_from_library_and_config(game_name)
            if getattr(self, "auto_sync", None):
                try:
                    self.auto_sync.refresh_watched_games()
                except Exception:
                    pass
            logger.info(f"[Library/Uninstall] Purged {game_name!r} from Library UI ({removed}) and config")

            msg = f"Đã gỡ cài đặt \"{game_name}\" khỏi máy tính và thư viện."
            if (
                result.get("steam_removed_count", 0) > 0
                and result.get("steam_was_running")
                and not result.get("steam_restarted")
            ):
                msg += " Khởi động lại Steam để cập nhật Non-Steam Library."

            self.tray_icon.showMessage(
                "Bob Gaming Game Center",
                msg,
                QSystemTrayIcon.MessageIcon.Information,
                3500,
            )

            warnings = result.get("warnings") or []
            if warnings:
                QMessageBox.information(self, "Hoàn tất kèm lưu ý", "\n".join(str(w) for w in warnings))
        except Exception:
            logger.exception("[Library/Uninstall] Error in _on_uninstall_game_finished slot")

    def _on_logout(self):
        """Handle logout."""
        reply = QMessageBox.question(
            self,
            "Đăng xuất",
            "Bạn có chắc chắn muốn đăng xuất tài khoản đám mây?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )

        if reply == QMessageBox.StandardButton.Yes:
            provider = self.config.get("cloud_provider", "")

            # Clear credentials but keep games config
            self.config["cloud_provider"] = ""
            self.config["cloud_url"] = ""
            self.config["username"] = ""
            self.config["password"] = ""
            save_config(self.config)

            # Clear Google token if applicable
            if provider == PROVIDER_GOOGLE_DRIVE:
                from app.core.google_drive_client import GoogleDriveClient
                GoogleDriveClient.clear_token()

            # Reset cloud state
            self.cloud_client = None
            self.sync_manager = None

            # Update header
            self.library_screen.set_logged_in(False)
            if hasattr(self, "sidebar"):
                self.sidebar.set_account_status(False)

            # Re-scan to remove cloud-only games
            self._scan_games()

    def _show_settings(self):
        """Show the settings dialog."""
        dialog = SettingsDialog(self.config, self)
        dialog.settings_changed.connect(self._on_settings_changed)
        dialog.reset_requested.connect(self.perform_factory_reset)
        dialog.exec()

    def _on_settings_changed(self, new_config: dict):
        """Handle settings changes."""
        from app.core.online_fix.models import normalize_enabled_stores

        old_hide_steam = self.config.get("hide_steam_games", True)
        new_hide_steam = new_config.get("hide_steam_games", True)
        old_stores = normalize_enabled_stores(self.config.get("enabled_game_stores"))
        new_stores = (
            normalize_enabled_stores(new_config.get("enabled_game_stores"))
            if "enabled_game_stores" in new_config
            else old_stores
        )

        self.config["auto_start"] = new_config.get("auto_start", False)
        self.config["minimize_to_tray"] = new_config.get("minimize_to_tray", True)
        old_auto_claim = self.config.get("auto_claim_steam_free_games", True)
        new_auto_claim = new_config.get("auto_claim_steam_free_games", True)
        self.config["hide_steam_games"] = new_hide_steam
        self.config["auto_claim_steam_free_games"] = new_auto_claim
        self.config["enabled_game_stores"] = new_stores
        if new_config.get("online_fix_install_root"):
            self.config["online_fix_install_root"] = new_config["online_fix_install_root"]

        if old_auto_claim != new_auto_claim:
            logger.info(f"[Settings] auto_claim_steam_free_games changed: {old_auto_claim} -> {new_auto_claim}")
            self._apply_steam_free_keep_setting(new_auto_claim)
        if old_stores != new_stores:
            logger.info(f"[Settings] enabled_game_stores changed: {old_stores} -> {new_stores}")
            try:
                from app.core.online_fix.manager import get_online_fix_manager
                get_online_fix_manager().save_enabled_stores(new_stores)
            except Exception as e:
                logger.warning(f"[Settings] Could not sync enabled_game_stores to OnlineFixManager: {e}")

        save_config(self.config)

        if old_stores != new_stores and getattr(self, "_online_fix_screen", None) is not None:
            self._online_fix_screen.set_enabled_stores(new_stores)

        # Reload library if Steam visibility changed
        if old_hide_steam != new_hide_steam:
            logger.info(f"[Settings] hide_steam_games changed: {old_hide_steam} -> {new_hide_steam}")
            self._load_saved_games()

    def perform_factory_reset(self):
        """Perform full factory reset: abort tasks, remove config, clear accounts & logs, restart app."""
        logger.info("[Reset] Initiating factory reset...")
        self._force_quit = True
        self._periodic_timer.stop()
        if hasattr(self, "tray_icon") and self.tray_icon:
            self.tray_icon.hide()

        # 1. Stop background monitors
        if hasattr(self, "process_monitor") and self.process_monitor:
            try:
                self.process_monitor.stop()
            except Exception as e:
                logger.warning(f"[Reset] Error stopping process_monitor: {e}")

        if hasattr(self, "_gamepad") and self._gamepad:
            try:
                self._gamepad.stop()
                self._gamepad.wait(1000)
            except Exception as e:
                logger.warning(f"[Reset] Error stopping gamepad: {e}")

        # 2. Stop all running threads
        all_threads = [
            getattr(self, '_scan_thread', None),
            getattr(self, '_image_thread', None),
            getattr(self, '_sync_thread', None),
            getattr(self, '_discovery_thread', None),
            getattr(self, '_poll_thread', None),
            getattr(self, '_steam_thread', None),
            getattr(self, '_shortcut_thread', None),
        ]
        if hasattr(self, '_active_sync_threads'):
            all_threads.extend(self._active_sync_threads.values())
        for thread in all_threads:
            try:
                if thread and self._is_cpp_alive(thread) and thread.isRunning():
                    thread.quit()
                    thread.wait(1000)
            except Exception:
                pass
        if hasattr(self, '_active_sync_threads'):
            self._active_sync_threads.clear()
        if hasattr(self, '_active_sync_workers'):
            self._active_sync_workers.clear()

        for thread in getattr(self, '_cloud_check_threads', []):
            try:
                if self._is_cpp_alive(thread) and thread.isRunning():
                    thread.quit()
                    thread.wait(500)
            except Exception:
                pass
        if hasattr(self, '_cloud_check_threads'):
            self._cloud_check_threads.clear()

        # 2b. Network Unblock: remove hosts block / proxy script setting and forget its state
        try:
            self._reset_net_unblock()
        except Exception as e:
            logger.error(f"[Reset] Failed to reset Network Unblock: {e}")

        # 2c. Steam Chat Overlay: unhook, remove the Steam debug flag if we created it, forget settings
        try:
            if getattr(self, "steam_chat", None) is not None:
                self.steam_chat.factory_reset()
            elif os.environ.get("BOBGAMING_STEAMCHAT_DISABLE") != "1":
                from app.core.steam_chat import steam_debug
                from app.core.steam_chat.settings import SettingsStore
                store = SettingsStore()
                if store.data.created_debug_marker:
                    steam_debug.set_debug_marker(False)
                store.delete()
        except Exception as e:
            logger.error(f"[Reset] Failed to reset Steam Chat Overlay: {e}")

        # 2d. Steam Free-to-Keep scanner: stop timers/worker and remove debug marker if we created it
        try:
            self._shutdown_steam_free_keep()
            if self.config.get("steam_free_created_debug_marker") and os.environ.get("BOBGAMING_FREEKEEP_DISABLE") != "1":
                from app.core.steam_chat import steam_debug
                steam_debug.set_debug_marker(False)
        except Exception as e:
            logger.error(f"[Reset] Failed to reset Steam Free-to-Keep scanner: {e}")

        # 3. Disable auto-start (Windows Task Scheduler / Registry)
        try:
            set_auto_start(False)
        except Exception as e:
            logger.error(f"[Reset] Failed to disable auto start: {e}")

        # 4. Clear Google Drive token
        try:
            from app.core.google_drive_client import GoogleDriveClient
            GoogleDriveClient.clear_token()
        except Exception as e:
            logger.error(f"[Reset] Failed to clear gdrive token: {e}")

        # 5. Reset config to default
        try:
            reset_to_default_config()
        except Exception as e:
            logger.error(f"[Reset] Failed to reset config: {e}")

        # 6. Delete lock file so new process can start immediately
        try:
            lock_path = os.path.join(CONFIG_DIR, "app.lock")
            if os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception:
            pass

        # 7. Delete logs and close handlers
        try:
            remove_log_files()
        except Exception:
            pass

        # 8. Restart process
        restart_application()


    # ===================== GLOBAL GAMEPAD MONITOR =====================

    def _init_gamepad(self):
        """Initialize the global GamepadMonitor thread."""
        if not SDL2_AVAILABLE:
            logger.info("[Gamepad] SDL2 not available, controller mapping disabled.")
            return

        self._gamepad = GamepadMonitor(self)
        self._gamepad.combo_triggered.connect(self._on_mapper_combo_triggered)

        from app.core.remote.manager import RemoteGamingManager
        remote_mgr = RemoteGamingManager.get()
        remote_mgr.set_gamepad_monitor(self._gamepad)
        remote_mgr.stream_stopped.connect(self._gamepad.resume)

        self._sync_combos_to_monitor()

        # Low controller battery: notice at the bottom centre of the game's screen
        from app.ui.battery_toast import BatteryNotifier
        self._battery = BatteryNotifier(self)
        self._gamepad.battery_changed.connect(self._battery.on_levels)

        # Controller drives the whole UI (focus ring, A/B/X/Y) while the app is the active window
        from app.ui.gamepad_nav import GamepadNavigator
        self._gamepad_nav = GamepadNavigator(self._gamepad, self)

        self._gamepad.start()
        logger.info("[Gamepad] Global GamepadMonitor started successfully.")

    # ── Controller navigation hooks (app/ui/gamepad_nav.py) ──

    def gamepad_button(self, action: str) -> bool:
        """LB/RB on the library: previous/next filter tab. B: sub-screen -> library; library -> sidebar."""
        if not self._gamepad_nav:
            return False
        if action in ("lb", "rb"):
            # LB / RB switch the library filter tabs (Tất cả / Đã cài đặt / ...)
            if self._content_container.currentWidget() is not self.library_screen:
                return False
            tab = self.library_screen.cycle_category(-1 if action == "lb" else 1)
            self._gamepad_nav.focus(tab)
            return True
        if action != "b":
            return False
        if self._content_container.currentWidget() is not self.library_screen:
            self._back_to_library()
        btn = self.sidebar.active_button()
        if btn is not None:
            self._gamepad_nav.focus(btn)
        return True

    def gamepad_default_focus(self):
        return self.sidebar.active_button()

    def _sync_combos_to_monitor(self):
        """Load configured controller mappings and set them on the gamepad thread."""
        if not self._gamepad:
            return
        from app.ui.controller_mapper_screen import _load_mappings
        combos = {}
        for m in _load_mappings():
            inputs = m.get("controller_inputs", [])
            if inputs:
                combos[m["id"]] = set(inputs)
        self._gamepad.set_combos(combos)

    def _on_mapper_combo_triggered(self, combo_id: str):
        """Global handler when a gamepad mapping combo is triggered."""
        if combo_id.startswith("steamchat:"):
            return  # handled by SteamChatController (own combo group in the shared monitor)
        from app.core.remote.manager import RemoteGamingManager
        if RemoteGamingManager.get().stream_runner.is_streaming:
            return

        # Only simulate keys/actions if the mapper screen isn't recording
        if self._mapper_screen and (
            self._mapper_screen._recording_ctrl_id or self._mapper_screen._recording_kb_id
        ):
            return

        from app.ui.controller_mapper_screen import _load_mappings
        from app.ui.keyboard_sim import send_key_combo
        from app.core.system_actions import execute_action
        import threading

        for m in _load_mappings():
            if m.get("id") == combo_id:
                target_type = m.get("target_type")
                if not target_type:
                    target_type = "action" if m.get("action_id") else "keyboard"

                if target_type == "action":
                    action_id = m.get("action_id")
                    if action_id:
                        threading.Thread(
                            target=execute_action,
                            args=(action_id,),
                            daemon=True,
                            name=f"ActionSim-{combo_id[:8]}",
                        ).start()
                        logger.info(f"[Global Mapper] Combo '{combo_id}' → dispatched action '{action_id}'")
                else:
                    keys = m.get("keyboard_keys", [])
                    if keys:
                        threading.Thread(
                            target=send_key_combo,
                            args=(keys,),
                            daemon=True,
                            name=f"KeySim-{combo_id[:8]}",
                        ).start()
                        logger.info(f"[Global Mapper] Combo '{combo_id}' → dispatched keys {keys}")
                break

    # ===================== UTILITY =====================

    def _show_utility_dialog(self):
        """Show the utility selector modal."""
        dialog = UtilityDialog(self)
        dialog.utility_selected.connect(self._on_utility_selected)
        dialog.exec()

    def _on_utility_selected(self, utility_id: str):
        """Handle utility selection from dialog."""
        if utility_id == "remote_gaming":
            self._show_remote_screen()
        elif utility_id == "controller_mapper":
            self._show_controller_mapper()
        elif utility_id == "log_console":
            self._toggle_log_console(show=True)
        elif utility_id == "steam_artwork":
            self._show_steam_artwork_dialog()
        elif utility_id == "net_unblock":
            self._show_net_unblock_dialog()
        elif utility_id == "steam_chat":
            self._show_steam_chat_screen()

    def _show_remote_screen(self):
        """Display Remote Gaming screen in content area."""
        if not hasattr(self, "_remote_screen") or self._remote_screen is None:
            from app.ui.remote import RemoteScreen
            self._remote_screen = RemoteScreen(self)
            self._remote_screen.back_requested.connect(self._back_to_library)
            from app.core.remote.manager import RemoteGamingManager
            RemoteGamingManager.get().stream_stopped.connect(
                self._flush_pending_update_dialog, Qt.ConnectionType.UniqueConnection
            )
        self._set_active_screen(self._remote_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("remote_gaming")

    # ===================== NETWORK UNBLOCK =====================

    def _init_net_unblock(self):
        """Start the housekeeping timer; build the manager only if the feature was enabled before."""
        self._net_unblock_busy = False
        self._net_unblock_timer = QTimer(self)
        self._net_unblock_timer.timeout.connect(self._net_unblock_tick)
        self._net_unblock_timer.start(NET_UNBLOCK_TICK_MS)
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self._shutdown_net_unblock)
        if os.environ.get("BOBGAMING_NETUNBLOCK_DISABLE") == "1":
            return
        try:
            from app.core.net_unblock.manager import NetUnblockManager
            manager = NetUnblockManager()
            if not manager.settings.enabled:
                if hasattr(self, "sidebar"):
                    self.sidebar.set_net_unblock_status(False)
                return
            self.net_unblock = manager
            if hasattr(self, "sidebar"):
                self.sidebar.set_net_unblock_status(bool(manager.settings.enabled))
            if manager.settings.auto_apply:
                threading.Thread(target=manager.startup, daemon=True, name="NetUnblock-Startup").start()
        except Exception:
            logger.exception("[NetUnblock] Could not initialise")

    def _get_net_unblock(self):
        """The shared manager (created on first use so a started proxy outlives the dialog)."""
        if self.net_unblock is None:
            from app.core.net_unblock.manager import NetUnblockManager
            self.net_unblock = NetUnblockManager()
        return self.net_unblock

    def _show_net_unblock_dialog(self):
        """Open the Network Unblock dialog (redirects to screen)."""
        self._show_net_unblock_screen()

    def _show_net_unblock_screen(self):
        """Display Network Unblock as an in-app screen."""
        if not hasattr(self, "_net_unblock_screen") or self._net_unblock_screen is None:
            from app.ui.net_unblock_dialog import NetUnblockDialog
            self._net_unblock_screen = NetUnblockDialog(self, manager=self._get_net_unblock())
            self._net_unblock_screen.back_requested.connect(self._back_to_library)
            if hasattr(self, "sidebar"):
                self._net_unblock_screen.status_changed.connect(self.sidebar.set_net_unblock_status)
        self._set_active_screen(self._net_unblock_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("net_unblock")

    def _show_settings_screen(self):
        """Display Settings as an in-app screen."""
        if not hasattr(self, "_settings_screen") or self._settings_screen is None:
            from app.ui.settings_screen import SettingsScreen
            self._settings_screen = SettingsScreen(self.config, self)
            self._settings_screen.back_requested.connect(self._back_to_library)
            self._settings_screen.settings_changed.connect(self._on_settings_changed)
            self._settings_screen.reset_requested.connect(self.perform_factory_reset)
        else:
            self._settings_screen.sync_config(self.config)
        self._set_active_screen(self._settings_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("settings")

    def _show_account_screen(self):
        """Display Account & Cloud Services as an in-app screen."""
        if not hasattr(self, "_account_screen") or self._account_screen is None:
            from app.ui.account_screen import AccountScreen
            self._account_screen = AccountScreen(self.config, is_logged_in=self._is_logged_in(), parent=self)
            self._account_screen.back_requested.connect(self._back_to_library)
            self._account_screen.login_successful.connect(self._on_login_success)
            self._account_screen.logout_requested.connect(self._on_logout)
        else:
            self._account_screen.set_account_state(self._is_logged_in(), self.config)
        self._set_active_screen(self._account_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("account")

    def _show_cloud_sync_screen(self):
        """Display Cloud Sync Dashboard as an in-app screen."""
        cards = list(getattr(self.library_screen, "_cards", {}).values())
        games_data = [c.game_data for c in cards if getattr(c, "game_data", None)]
        if not hasattr(self, "_cloud_sync_screen") or self._cloud_sync_screen is None:
            from app.ui.cloud_sync_screen import CloudSyncScreen
            self._cloud_sync_screen = CloudSyncScreen(
                self.config,
                games=games_data,
                is_logged_in=self._is_logged_in(),
                parent=self,
            )
            self._cloud_sync_screen.back_requested.connect(self._back_to_library)
            self._cloud_sync_screen.sync_all_requested.connect(self._sync_all_configured_games)
            self._cloud_sync_screen.sync_game_requested.connect(self._on_sync_game_from_screen)
        else:
            self._cloud_sync_screen.update_data(self.config, games_data, self._is_logged_in())
        self._set_active_screen(self._cloud_sync_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("cloud_sync")

    def _show_steam_artwork_screen(self, initial_game: dict = None):
        """Display Steam Artwork Manager as an in-app screen."""
        from app.ui.steam_artwork_screen import SteamArtworkScreen
        self._steam_artwork_screen = SteamArtworkScreen(self.config, initial_game=initial_game, parent=self)
        self._steam_artwork_screen.back_requested.connect(self._back_to_library)
        self._set_active_screen(self._steam_artwork_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("steam_artwork")

    def _show_upscaler_screen(self):
        """Display the Upscaler manager (OptiScaler / FSR / HelixSR) as an in-app screen."""
        from app.ui.upscaler_screen import UpscalerScreen
        self._upscaler_screen = UpscalerScreen(self.config, self.library_screen.get_games, parent=self)
        self._upscaler_screen.back_requested.connect(self._back_to_library)
        self._set_active_screen(self._upscaler_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("upscaler")

    @staticmethod
    def _store_sidebar_key(_source_filter: str = "all") -> str:
        return "online_fix"

    def _on_store_source_filter_changed(self, source_filter: str):
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category(self._store_sidebar_key(source_filter))

    def _show_online_fix_screen(self, source_filter: str = "all"):
        """Display the unified KHO GAME Store & Downloader as an in-app screen."""
        if not hasattr(self, "_online_fix_screen") or self._online_fix_screen is None:
            from app.ui.online_fix.online_fix_screen import OnlineFixScreen
            self._online_fix_screen = OnlineFixScreen(parent=self, initial_source=source_filter)
            self._online_fix_screen.back_requested.connect(self._back_to_library)
            self._online_fix_screen.source_filter_changed.connect(self._on_store_source_filter_changed)
            self._online_fix_screen.launch_game_requested.connect(self._on_launch_game)
        else:
            self._online_fix_screen.set_source_filter(source_filter, emit_signal=False)
        self._set_active_screen(self._online_fix_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category(self._store_sidebar_key(self._online_fix_screen.current_source_filter))

    def _init_online_fix(self):
        """Connect to OnlineFixManager background task completion & failure signals."""
        try:
            from app.core.online_fix.manager import get_online_fix_manager
            manager = get_online_fix_manager()
            self._notified_completed_tasks = set()
            manager.task_completed.connect(self._on_online_fix_task_completed)
            manager.task_failed.connect(self._on_online_fix_task_failed)
            manager.task_resumed.connect(lambda tid: getattr(self, "_notified_completed_tasks", set()).discard(tid))
            logger.info("[OnlineFix] Connected task_completed and task_failed signals to MainWindow")
        except Exception:
            logger.exception("[OnlineFix] Could not initialise online fix manager connection")

    def _show_store_tray_notification(self, title: str, message: str, *, warning: bool = False, target: str = ""):
        """Emit a Windows system tray notification for store game install events."""
        self._last_tray_notification_target = target
        tray = getattr(self, "tray_icon", None)
        if tray is None:
            logger.debug(f"[OnlineFix/Notify] Tray icon unavailable; skipped notification: {title!r}")
            return
        try:
            icon = QSystemTrayIcon.MessageIcon.Warning if warning else QSystemTrayIcon.MessageIcon.Information
            tray.showMessage(title, message, icon, 7000 if warning else 6000)
        except Exception:
            logger.exception(f"[OnlineFix/Notify] Failed to show Windows notification for {title!r}")

    def _on_online_fix_task_completed(self, task_id: str, exe_path: str):
        """Triggered directly when OnlineFixManager finishes extracting and applying fix."""
        try:
            from app.core.online_fix.manager import get_online_fix_manager
            from app.core.online_fix.translate import title_to_vietnamese
            from app.ui.online_fix.common import source_display_name

            manager = get_online_fix_manager()
            task = manager.get_task(task_id)
            if not task:
                return

            final_exe = exe_path or getattr(task, "extracted_exe_path", "")
            if not final_exe or not os.path.isfile(final_exe):
                from app.core.online_fix.extractor import find_game_executable
                final_exe = find_game_executable(task.target_install_dir, task.game_title) or ""

            source = str(getattr(task, "source", "online_fix") or "online_fix")
            self._on_online_fix_game_installed({
                "name": task.game_title,
                "exe_path": final_exe,
                "install_location": task.target_install_dir,
                "poster_url": getattr(task, "poster_url", ""),
                "source": source,
            })

            notified = getattr(self, "_notified_completed_tasks", None)
            if notified is None:
                notified = set()
                self._notified_completed_tasks = notified
            if task_id not in notified:
                notified.add(task_id)
                clean_title = title_to_vietnamese(task.game_title) if task.game_title else "Game"
                store_label = source_display_name(source)
                if final_exe and os.path.isfile(final_exe):
                    msg = f'"{clean_title}" ({store_label}) đã tải và cài đặt xong, sẵn sàng chơi trong Thư viện!'
                else:
                    msg = f'"{clean_title}" ({store_label}) đã giải nén xong tại {task.target_install_dir}.'
                self._show_store_tray_notification(
                    f"Cài đặt hoàn tất — {clean_title}",
                    msg,
                    warning=False,
                    target="library",
                )
                logger.info(f"[OnlineFix/Notify] Notified install completion for {clean_title!r} (task={task_id})")
        except Exception:
            logger.exception(f"[OnlineFix] Error handling task completion for {task_id}")

    def _on_online_fix_task_failed(self, task_id: str, error_message: str):
        """Notify the user via Windows System Tray when a background game download or extraction fails."""
        try:
            from app.core.online_fix.manager import get_online_fix_manager
            from app.core.online_fix.translate import title_to_vietnamese
            from app.ui.online_fix.common import source_display_name

            manager = get_online_fix_manager()
            task = manager.get_task(task_id)
            raw_title = task.game_title if task else ""
            clean_title = title_to_vietnamese(raw_title) if raw_title else "Game"
            source = str(getattr(task, "source", "online_fix") or "online_fix") if task else "online_fix"
            store_label = source_display_name(source)
            detail = (error_message or "Quá trình tải hoặc giải nén bị gián đoạn.").strip()
            if len(detail) > 160:
                detail = detail[:157].rstrip() + "..."
            self._show_store_tray_notification(
                f"Cài đặt gặp lỗi — {clean_title}",
                f'"{clean_title}" ({store_label}): {detail}',
                warning=True,
                target="store_downloads",
            )
            logger.warning(
                f"[OnlineFix/Notify] Notified install failure for {clean_title!r} (task={task_id}): {detail}"
            )
        except Exception:
            logger.exception(f"[OnlineFix/Notify] Error handling task failure notification for {task_id}")

    def _on_online_fix_game_installed(self, game_data: dict):
        """A game was downloaded and extracted from Online-Fix: add it to the Library like a manually added game."""
        try:
            from app.core.online_fix.translate import title_to_vietnamese
            raw_name = (game_data.get("name") or "").strip()
            name = title_to_vietnamese(raw_name) if raw_name else ""
            exe_path = game_data.get("exe_path", "")
            install_location = game_data.get("install_location", "") or (os.path.dirname(exe_path) if exe_path else "")
            if not name:
                return

            if not exe_path and install_location and os.path.isdir(install_location):
                from app.core.online_fix.extractor import find_game_executable
                exe_path = find_game_executable(install_location, name) or ""

            manual_games = self.config.setdefault("manual_games", [])
            # Remove any legacy name variant (e.g. 'Game Online')
            manual_games = [m for m in manual_games if m.lower() != name.lower() and m.lower() != f"{name.lower()} online"]
            manual_games.append(name)
            self.config["manual_games"] = manual_games

            # Clean up old key in config['games'] if present
            old_online_key = f"{name} Online"
            if old_online_key in self.config.get("games", {}):
                self.config["games"].pop(old_online_key, None)

            self.config["removed_games"] = [g for g in self.config.get("removed_games", [])
                                            if g.lower() != name.lower()]
            poster_url = str(game_data.get("poster_url") or "").strip()
            entry = self.config.setdefault("games", {}).setdefault(name, {})
            entry.update({"name": name, "exe_path": exe_path, "install_location": install_location,
                          "source": "manual", "online_fix": True, "installed_at": time.time()})
            if poster_url:
                entry["poster_url"] = poster_url
            save_config(self.config)

            if self.image_cache and poster_url:
                self.image_cache.set_fallback_url(name, poster_url)

            if name.lower() in {n.lower() for n in self.library_screen._cards.keys()}:
                self.library_screen.update_game_data(name, {"exe_path": exe_path,
                                                            "install_location": install_location})
            else:
                from app.ui.online_fix.common import source_display_name
                pub_name = source_display_name(str(game_data.get("source") or "online_fix"))
                self.library_screen.add_game({
                    "name": name, "install_location": install_location, "publisher": pub_name,
                    "source": "manual", "status": SYNC_STATUS_NOT_CONFIGURED, "save_path": "",
                    "exe_path": exe_path, "on_cloud": False,
                })
            if self.image_cache:
                self._load_game_images([name])
            logger.info(f"[OnlineFix] Added {name!r} to the Library (exe: {exe_path or '(not configured)'})")
            if getattr(self, "_online_fix_screen", None) is not None:
                self._online_fix_screen.refresh_installed_games_state()

            # Auto add to Non-Steam games & download artwork (silent tray: install toast was just shown)
            if exe_path and os.path.isfile(exe_path):
                self._start_auto_steam_add(name, exe_path, install_location, show_tray_toast=False)
        except Exception:   # noqa: BLE001 - slot boundary
            logger.exception("[OnlineFix] Could not add the installed game to the Library")

    def _start_auto_steam_add(
        self,
        game_name: str,
        exe_path: str,
        install_location: str | None = None,
        show_tray_toast: bool = True,
    ):
        """Launch background worker to add non-Steam game shortcut and download artwork."""
        try:
            if not hasattr(self, "_steam_add_threads"):
                self._steam_add_threads = {}
            if not hasattr(self, "_steam_add_workers"):
                self._steam_add_workers = {}
            if not hasattr(self, "_steam_add_silent_toast"):
                self._steam_add_silent_toast = set()
            if show_tray_toast:
                self._steam_add_silent_toast.discard(game_name)
            else:
                self._steam_add_silent_toast.add(game_name)

            # If already processing this game, skip
            existing_thread = self._steam_add_threads.get(game_name)
            if existing_thread and self._is_cpp_alive(existing_thread) and existing_thread.isRunning():
                logger.info(f"[Steam/AutoAdd] Task already running for {game_name!r}")
                return

            from app.core.steam_auto_add import SteamAutoAddWorker

            worker = SteamAutoAddWorker(
                game_name=game_name,
                exe_path=exe_path,
                install_location=install_location,
            )
            thread = QThread(self)
            worker.moveToThread(thread)

            thread.started.connect(worker.run)
            worker.finished.connect(self._on_steam_auto_add_finished)
            worker.finished.connect(thread.quit)
            worker.finished.connect(worker.deleteLater)
            thread.finished.connect(thread.deleteLater)

            def _cleanup(g=game_name):
                self._steam_add_threads.pop(g, None)
                self._steam_add_workers.pop(g, None)

            thread.finished.connect(_cleanup)

            self._steam_add_threads[game_name] = thread
            self._steam_add_workers[game_name] = worker

            logger.info(f"[Steam/AutoAdd] Dispatched background thread for {game_name!r}")
            thread.start()
        except Exception:
            logger.exception(f"[Steam/AutoAdd] Failed to start auto Steam add for {game_name!r}")

    @Slot(dict)
    def _on_steam_auto_add_finished(self, result: dict):
        """Handle background auto Steam add and artwork download completion."""
        try:
            game_name = result.get("game_name", "")
            success = result.get("success", False)
            if not game_name:
                return

            if success:
                appid = result.get("appid")
                poster_path = result.get("poster_path")
                steam_running = result.get("steam_running", False)

                # Persist steam metadata in config
                config_games = self.config.get("games", {})
                if game_name in config_games:
                    if appid:
                        config_games[game_name]["steam_appid"] = appid
                    config_games[game_name]["steam_shortcut"] = True
                    steam_ts = result.get("steam_start_ts")
                    if steam_ts is not None:
                        config_games[game_name]["steam_pending_reload_ts"] = steam_ts
                    else:
                        config_games[game_name].pop("steam_pending_reload_ts", None)
                    save_config(self.config)

                # Update library card image if poster is available
                if poster_path and os.path.isfile(poster_path):
                    self.library_screen.update_game_image(game_name, poster_path)

                silent_set = getattr(self, "_steam_add_silent_toast", set())
                suppress_toast = game_name in silent_set
                silent_set.discard(game_name)
                if not suppress_toast and hasattr(self, "tray_icon") and self.tray_icon:
                    msg = f"Đã thêm \"{game_name}\" vào Steam và tải đầy đủ ảnh bìa."
                    if steam_running:
                        msg += " Khởi động lại Steam để hiển thị game."
                    self.tray_icon.showMessage(
                        "Bob Gaming Game Center",
                        msg,
                        QSystemTrayIcon.MessageIcon.Information,
                        4000,
                    )
                logger.info(f"[Steam/AutoAdd] Finished for {game_name!r} (AppID: {appid})")
            else:
                msg = result.get("message", "Không thể thêm game vào Steam.")
                logger.warning(f"[Steam/AutoAdd] Auto-add failed for {game_name!r}: {msg}")
        except Exception:
            logger.exception("[Steam/AutoAdd] Error in _on_steam_auto_add_finished slot")

    def _on_sync_game_from_screen(self, game_name: str, save_path: str):
        """Trigger sync for a single game from Cloud Sync screen."""
        self._on_sync_now_from_dialog(game_name, save_path)

    def _sync_all_configured_games(self):
        """Trigger sync for all configured games with a valid save path."""
        if not self._is_logged_in():
            self._show_account_screen()
            return
        cards = list(getattr(self.library_screen, "_cards", {}).values())
        count = 0
        for c in cards:
            gd = getattr(c, "game_data", None) or {}
            name = gd.get("name")
            save_path = gd.get("save_path")
            if name and save_path and os.path.exists(save_path):
                self._on_sync_now_from_dialog(name, save_path)
                count += 1
        logger.info(f"[CloudSync] Triggered sync for {count} configured games.")

    def _net_unblock_tick(self):
        """Periodic housekeeping: keep the proxy alive and refresh stale IPs (never on the GUI thread)."""
        manager = self.net_unblock
        if manager is None or self._net_unblock_busy or not manager.settings.enabled:
            return
        self._net_unblock_busy = True

        def work():
            try:
                manager.health_check()
                if manager.refresh_due():
                    manager.refresh()
            except Exception:
                logger.exception("[NetUnblock] Periodic check failed")
            finally:
                self._net_unblock_busy = False

        threading.Thread(target=work, daemon=True, name="NetUnblock-Tick").start()

    def _shutdown_net_unblock(self):
        """Stop the proxy and undo the proxy script setting (idempotent; the hosts block stays)."""
        timer = getattr(self, "_net_unblock_timer", None)
        if timer is not None:
            timer.stop()
        manager = getattr(self, "net_unblock", None)
        if manager is not None:
            manager.shutdown("app exit")

    def _reset_net_unblock(self):
        """Factory reset: undo every change and delete the feature's settings."""
        timer = getattr(self, "_net_unblock_timer", None)
        if timer is not None:
            timer.stop()
        if os.environ.get("BOBGAMING_NETUNBLOCK_DISABLE") == "1":
            return
        manager = self._get_net_unblock()
        messages = manager.restore_all()
        for message in messages:
            logger.info(f"[Reset] Network Unblock: {message}")
        if any(m.startswith("Could not edit") for m in messages):
            return                                   # keep the state so a later run (as admin) can still undo it
        manager.delete_settings()

    # ===================== STEAM CHAT OVERLAY =====================

    def _init_steam_chat(self):
        """Create the controller (cheap, no threads) and start the overlay if it was enabled before."""
        if os.environ.get("BOBGAMING_STEAMCHAT_DISABLE") == "1":
            return
        try:
            from app.ui.steam_chat.controller import SteamChatController
            self.steam_chat = SteamChatController(self)
            self.steam_chat.enabled_changed.connect(self._on_steam_chat_enabled_changed)
            if self._gamepad:
                self.steam_chat.attach_gamepad(self._gamepad)   # controller combos share the global monitor
            app = QApplication.instance()
            if app is not None:
                app.aboutToQuit.connect(self._shutdown_steam_chat)
            self.steam_chat.start()
            if hasattr(self, "sidebar"):
                self.sidebar.set_steam_chat_status(self.steam_chat.active)
        except Exception:
            logger.exception("[SteamChat] Could not initialise")
            self.steam_chat = None

    def _on_steam_chat_enabled_changed(self, enabled: bool):
        if hasattr(self, "sidebar"):
            self.sidebar.set_steam_chat_status(enabled)

    def _show_steam_chat_screen(self):
        """Display the Steam Chat Overlay settings as an in-app screen."""
        if self.steam_chat is None:
            QMessageBox.warning(self, "Steam Chat Overlay", "Tính năng này không khởi tạo được. Xem app.log để biết chi tiết.")
            return
        if getattr(self, "_steam_chat_screen", None) is None:
            from app.ui.steam_chat.screen import SteamChatScreen
            self._steam_chat_screen = SteamChatScreen(self.steam_chat, self)
            self._steam_chat_screen.back_requested.connect(self._back_to_library)
        self._set_active_screen(self._steam_chat_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("steam_chat")

    def _shutdown_steam_chat(self):
        """Unhook from Steam, release hotkeys and close the overlay windows (idempotent)."""
        controller = getattr(self, "steam_chat", None)
        if controller is not None:
            try:
                controller.shutdown()
            except Exception:
                logger.exception("[SteamChat] Shutdown failed")

    # ===================== STEAM FREE-TO-KEEP AUTO CLAIM =====================

    def _init_steam_free_keep(self):
        """Arm hourly background scanner for 100%-off Steam paid games & DLCs."""
        from app.core import steam_free_keep

        self._free_keep_thread: QThread | None = None
        self._free_keep_worker: QObject | None = None
        self._free_keep_timer = QTimer(self)
        self._free_keep_timer.setInterval(steam_free_keep.SCAN_INTERVAL_MS)
        self._free_keep_timer.timeout.connect(self._run_steam_free_keep_scan)

        self._free_keep_startup_timer = QTimer(self)
        self._free_keep_startup_timer.setSingleShot(True)
        self._free_keep_startup_timer.setInterval(steam_free_keep.STARTUP_SCAN_DELAY_MS)
        self._free_keep_startup_timer.timeout.connect(self._run_steam_free_keep_scan)

        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self._shutdown_steam_free_keep)

        if os.environ.get("BOBGAMING_FREEKEEP_DISABLE") == "1":
            return
        if self.config.get("auto_claim_steam_free_games", True):
            self._free_keep_timer.start()
            self._free_keep_startup_timer.start()
            logger.info("[Steam/FreeKeep] Armed background scanner (1h interval)")

    def _apply_steam_free_keep_setting(self, enabled: bool):
        """Start or stop the background Steam promo scanner when toggled in Settings."""
        try:
            if not hasattr(self, "_free_keep_timer"):
                return
            self._free_keep_startup_timer.stop()
            if getattr(self, "_steam_free_screen", None) is not None:
                self._steam_free_screen.sync_config(self.config)
            if not enabled:
                self._free_keep_timer.stop()
                logger.info("[Steam/FreeKeep] Disabled background scanner")
                return
            if os.environ.get("BOBGAMING_FREEKEEP_DISABLE") == "1":
                return
            self._free_keep_timer.start()
            logger.info("[Steam/FreeKeep] Enabled background scanner (1h interval)")
            self._run_steam_free_keep_scan()
        except Exception:
            logger.exception("[Steam/FreeKeep] Failed to apply setting change")

    @Slot()
    def _run_steam_free_keep_scan(self):
        """Dispatch a single background free-to-keep scan off the GUI thread."""
        try:
            if not self.config.get("auto_claim_steam_free_games", True):
                return
            if (
                self._free_keep_thread is not None
                and self._is_cpp_alive(self._free_keep_thread)
                and self._free_keep_thread.isRunning()
            ):
                return

            from app.core.steam_free_keep import SteamFreeKeepWorker

            thread = QThread()
            worker = SteamFreeKeepWorker()
            worker.moveToThread(thread)
            thread.started.connect(worker.run)
            worker.finished.connect(self._on_steam_free_keep_finished)
            worker.finished.connect(thread.quit)
            worker.finished.connect(worker.deleteLater)

            self._free_keep_thread = thread
            self._free_keep_worker = worker
            thread.start()
        except Exception:
            logger.exception("[Steam/FreeKeep] Failed to start background scan thread")

    @Slot(dict)
    def _on_steam_free_keep_finished(self, result: dict):
        """Handle completion of a background Steam free-to-keep scan."""
        try:
            if result.get("created_marker") and not self.config.get("steam_free_created_debug_marker"):
                self.config["steam_free_created_debug_marker"] = True
                save_config(self.config)

            claimed = result.get("claimed") or []
            if claimed and hasattr(self, "tray_icon") and self.tray_icon:
                titles = [str(item.get("title") or "").strip() for item in claimed if item.get("title")]
                if len(titles) == 1:
                    msg = f'Đã tự động nhận miễn phí vĩnh viễn "{titles[0]}" vào tài khoản Steam.'
                elif titles:
                    msg = f"Đã tự động nhận miễn phí vĩnh viễn {len(titles)} game/DLC trên Steam: {', '.join(titles[:3])}."
                else:
                    msg = ""
                if msg:
                    self.tray_icon.showMessage(
                        "Bob Gaming Game Center",
                        msg,
                        QSystemTrayIcon.MessageIcon.Information,
                        5000,
                    )
        except Exception:
            logger.exception("[Steam/FreeKeep] Error in _on_steam_free_keep_finished slot")

    def _show_steam_free_screen(self):
        """Display the Steam 100%-Off Free-to-Keep monitor screen under KHO GAME."""
        if getattr(self, "_steam_free_screen", None) is None:
            from app.ui.steam_free_screen import SteamFreeScreen
            self._steam_free_screen = SteamFreeScreen(self.config, parent=self)
            self._steam_free_screen.back_requested.connect(self._back_to_library)
            self._steam_free_screen.promos_updated.connect(self._on_steam_free_keep_finished)
        else:
            self._steam_free_screen.sync_config(self.config)
        self._set_active_screen(self._steam_free_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("store_steam_free")

    def _show_trainer_screen(self):
        """Display the Game Trainer (FLiNG) screen. Kept alive so downloads and the Downloads watcher survive
        navigating away."""
        if getattr(self, "_trainer_screen", None) is None:
            from app.ui.trainer_screen import TrainerScreen
            self._trainer_screen = TrainerScreen(self.config, parent=self)
            self._trainer_screen.back_requested.connect(self._back_to_library)
        self._set_active_screen(self._trainer_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("trainer")

    def _shutdown_steam_free_keep(self):
        """Stop timers and join any active free-to-keep worker thread (idempotent)."""
        for timer_name in ("_free_keep_timer", "_free_keep_startup_timer"):
            timer = getattr(self, timer_name, None)
            if timer is not None:
                try:
                    timer.stop()
                except RuntimeError:
                    pass
        thread = getattr(self, "_free_keep_thread", None)
        if thread is not None:
            try:
                if self._is_cpp_alive(thread) and thread.isRunning():
                    thread.quit()
                    thread.wait(1500)
            except RuntimeError:
                pass

    def _show_steam_artwork_dialog(self, initial_game: dict = None):
        """Open the Steam Non-Steam Game & Artwork Manager (redirects to screen)."""
        self._show_steam_artwork_screen(initial_game=initial_game)

    def _on_steam_artwork_requested_from_card(self, game_data: dict):
        """Handle Steam artwork request from a game card context menu."""
        self._show_steam_artwork_screen(initial_game=game_data)

    def _toggle_log_console(self, show: bool | None = None):
        """Toggle or set the visibility of the Log Console side panel."""
        if show is None:
            show = self._log_panel.isHidden()

        if show:
            self._log_panel.show()
            # If normal window is narrow, expand width so library layout stays clean
            if not self.isMaximized() and self.width() < 1440:
                new_w = min(1600, self.width() + 260)
                self.resize(new_w, self.height())

            # Allocate width for side panel
            splitter_w = self._root_splitter.width()
            if splitter_w <= 0:
                splitter_w = self.width() - self.sidebar.width()
            log_w = max(320, min(420, int(splitter_w * 0.30)))
            content_w = max(560, splitter_w - log_w)
            self._root_splitter.setSizes([content_w, log_w])
        else:
            self._log_panel.hide()
            logger.info("Live Log Console closed")
            self._restore_active_sidebar_item()

    def _show_controller_mapper(self):
        """Switch to the Controller Mapper screen."""
        from app.ui.controller_mapper_screen import ControllerMapperScreen

        # Clean up old mapper screen if exists
        if self._mapper_screen:
            self._mapper_screen.cleanup()
            self._mapper_screen.deleteLater()

        self._mapper_screen = ControllerMapperScreen(self._gamepad)
        self._mapper_screen.back_requested.connect(self._back_to_library)
        self._set_active_screen(self._mapper_screen)
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category("controller")

    def _restore_active_sidebar_item(self):
        """Restore sidebar active button according to current active content screen."""
        if not hasattr(self, "sidebar") or not hasattr(self, "_content_container"):
            return
        current_widget = self._content_container.currentWidget()
        if current_widget == self.library_screen:
            cat = getattr(self.library_screen, "_current_category", "all")
            self.sidebar.set_active_category(cat)
        elif hasattr(self, "_remote_screen") and current_widget == self._remote_screen:
            self.sidebar.set_active_category("remote_gaming")
        elif hasattr(self, "_net_unblock_screen") and current_widget == self._net_unblock_screen:
            self.sidebar.set_active_category("net_unblock")
        elif getattr(self, "_steam_chat_screen", None) is not None and current_widget == self._steam_chat_screen:
            self.sidebar.set_active_category("steam_chat")
        elif hasattr(self, "_cloud_sync_screen") and current_widget == self._cloud_sync_screen:
            self.sidebar.set_active_category("cloud_sync")
        elif hasattr(self, "_steam_artwork_screen") and current_widget == self._steam_artwork_screen:
            self.sidebar.set_active_category("steam_artwork")
        elif getattr(self, "_upscaler_screen", None) is not None and current_widget == self._upscaler_screen:
            self.sidebar.set_active_category("upscaler")
        elif getattr(self, "_trainer_screen", None) is not None and current_widget == self._trainer_screen:
            self.sidebar.set_active_category("trainer")
        elif getattr(self, "_online_fix_screen", None) is not None and current_widget == self._online_fix_screen:
            self.sidebar.set_active_category(
                self._store_sidebar_key(getattr(self._online_fix_screen, "current_source_filter", "all"))
            )
        elif hasattr(self, "_mapper_screen") and current_widget == self._mapper_screen:
            self.sidebar.set_active_category("controller")
        elif hasattr(self, "_settings_screen") and current_widget == self._settings_screen:
            self.sidebar.set_active_category("settings")
        elif hasattr(self, "_account_screen") and current_widget == self._account_screen:
            self.sidebar.set_active_category("account")
        else:
            self.sidebar.set_active_category("all")

    def _back_to_library(self, target_category: str = None):
        """Switch back to the library screen from any sub-screen."""
        if hasattr(self, "_mapper_screen") and self._mapper_screen:
            self._mapper_screen.cleanup()
            self._sync_combos_to_monitor()

        self._set_active_screen(self.library_screen)

        # Restore state
        if self._is_logged_in():
            provider = self.config.get("cloud_provider", "")
            self.library_screen.set_logged_in(True, provider)
        else:
            self.library_screen.set_logged_in(False)

        cat = target_category if target_category is not None else getattr(self.library_screen, "_current_category", "all")
        if hasattr(self, "sidebar"):
            self.sidebar.set_active_category(cat)

        self._load_saved_games()
        if target_category is not None:
            self.library_screen.set_category_filter(target_category)

    # ---- Auto update (app/core/updater.py) ----------------------------------------------------------

    def _init_updater(self):
        self._update_thread: QThread | None = None
        self._update_worker: UpdateCheckWorker | None = None
        self._update_dialog: UpdateDialog | None = None
        self._update_pending = None       # UpdateInfo found while the window was hidden in the tray
        self._update_declined: str = ""   # version the user postponed this session: no re-nagging until restart
        self._update_manual = False       # the running check was asked for by clicking the version label
        self._update_timer = QTimer(self)
        self._update_timer.setInterval(updater.CHECK_INTERVAL_MS)
        self._update_timer.timeout.connect(self._check_for_update)
        if os.environ.get("BOBGAMING_UPDATE_DISABLE") == "1":
            return
        self._update_timer.start()
        QTimer.singleShot(updater.STARTUP_CHECK_DELAY_MS, self._check_for_update)

    def _check_for_update_manual(self):
        """Version label clicked: check now and always report the result."""
        if self._update_dialog is not None:
            return
        self._update_manual = True
        self.sidebar.version_label.setText("Đang kiểm tra…")
        self._check_for_update()

    def _check_for_update(self):
        if self._update_dialog is not None or (self._update_thread is not None and self._update_thread.isRunning()):
            return
        self._update_thread = QThread(self)
        self._update_worker = UpdateCheckWorker()
        self._update_worker.moveToThread(self._update_thread)
        self._update_thread.started.connect(self._update_worker.run)
        self._update_worker.finished.connect(self._on_update_info)
        self._update_worker.finished.connect(self._update_thread.quit)
        self._update_thread.start()

    def _is_game_active(self) -> bool:
        if getattr(self, "process_monitor", None) and self.process_monitor.has_running_game():
            return True
        from app.core.remote.manager import RemoteGamingManager
        rm = RemoteGamingManager._instance
        return bool(rm is not None and rm.stream_runner.is_streaming)

    def _flush_pending_update_dialog(self):
        if self._update_pending is None or self._update_dialog is not None or self._is_game_active():
            return
        info = self._update_pending
        self._update_pending = None
        self._show_update_dialog(info)

    def _on_update_info(self, info):
        if self._update_manual:
            self._update_manual = False
            self.sidebar.version_label.setText(f"v{updater.APP_VERSION}")
            if info is None:
                QMessageBox.warning(self, "Cập nhật", "Không kiểm tra được bản mới. Hãy kiểm tra kết nối mạng.")
            elif not updater.is_newer(info.version):
                QMessageBox.information(self, "Cập nhật", f"Bạn đang dùng bản mới nhất (v{updater.APP_VERSION}).")
            else:
                self._show_update_dialog(info)    # asked for: ignore "skip" / "later"
            return
        skipped = self.config.get("skipped_version", "")
        if not updater.should_offer(info, skipped) or info.version == self._update_declined:
            return
        if self._is_game_active():
            logger.info(f"[Update] Deferring update popup v{info.version} while a game is running")
            self._update_pending = info
            return
        self._show_update_dialog(info)

    def _show_update_dialog(self, info):
        if self._update_dialog is not None:
            return
        minimized_or_hidden = (not self.isVisible()) or self.isMinimized()
        parent = None if minimized_or_hidden else self
        logger.info(
            f"[Update] New version available: {info.version} (current {updater.APP_VERSION}, "
            f"standalone={minimized_or_hidden})"
        )
        self._update_pending = None
        dialog = UpdateDialog(info, parent)
        self._update_dialog = dialog
        try:
            dialog.exec()
        finally:
            self._update_dialog = None
        if dialog.downloaded_path:
            self._install_update(dialog.downloaded_path)
        else:
            self._update_declined = info.version
            if dialog.skip_requested:
                self.config["skipped_version"] = info.version
                save_config(self.config)
                logger.info(f"[Update] User skipped version {info.version}")

    def _install_update(self, new_exe: str):
        if not updater.launch_swap_and_restart(new_exe):
            QMessageBox.information(
                self, "Cập nhật",
                f"Đã tải bản mới về:\n{new_exe}\n\nBản đang chạy ở chế độ mã nguồn dev nên không tự ghi đè trực tiếp.")
            return
        logger.info("[Update] Quitting to apply the update")
        self._force_quit = True
        self.close()
        QApplication.quit()

    def _tray_show(self):
        """Show window from tray."""
        logger.info("[Tray] Restoring window from tray")
        if self.isMinimized():
            self.setWindowState((self.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
            self.showNormal()
        else:
            self.show()
        self.raise_()
        self.activateWindow()
        if self._update_pending is not None:
            QTimer.singleShot(400, self._flush_pending_update_dialog)
        if self._update_dialog is not None:
            self._update_dialog.raise_()
            self._update_dialog.activateWindow()
        # Show any conflicts that were queued while hidden
        if self._pending_conflicts:
            # Defer to let the window paint first
            QTimer.singleShot(300, self._show_pending_conflicts)

    def _show_pending_conflicts(self):
        """Show the first pending conflict dialog (chain through on_dialog_finished)."""
        if not self._pending_conflicts or self._conflict_dialog is not None:
            return
        conflict = self._pending_conflicts.pop(0)
        self._on_conflict_detected(
            conflict["game_name"],
            conflict["game_data"],
            conflict["local_time"],
            conflict["remote_time"],
        )

    def _tray_quit(self):
        """Actually quit the application from tray."""
        logger.info("[Tray] User requested application exit")
        self._force_quit = True
        self.close()
        QApplication.quit()

    def _on_tray_activated(self, reason):
        """Handle tray icon activation (single-click or double-click to show)."""
        logger.info(f"[Tray] Tray icon activated (reason={reason})")
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,
            QSystemTrayIcon.ActivationReason.DoubleClick,
        ):
            self._tray_show()

    def _on_tray_message_clicked(self):
        """Restore app window and jump to relevant view when user clicks a Windows tray notification."""
        target = getattr(self, "_last_tray_notification_target", "")
        self._last_tray_notification_target = ""
        logger.info(f"[OnlineFix/Notify] User clicked Windows tray notification (target={target or 'default'})")
        self._tray_show()
        if target == "library":
            self._back_to_library()
        elif target == "store_downloads":
            self._show_online_fix_screen("all")
            if getattr(self, "_online_fix_screen", None) is not None:
                self._online_fix_screen.download_drawer.show()


    def closeEvent(self, event):
        """Handle window close — minimize to tray or quit."""
        if self.config.get("minimize_to_tray", True) and not self._force_quit:
            # Minimize to tray instead of closing
            event.ignore()
            self.hide()
            self.tray_icon.showMessage(
                "Bob Gaming Game Center",
                "Ứng dụng đang chạy thu nhỏ trong khay hệ thống.",
                QSystemTrayIcon.MessageIcon.Information,
                2000,
            )
            return

        # Actually close — stop periodic timer first
        self._periodic_timer.stop()
        self._update_timer.stop()
        if self._update_thread is not None and self._update_thread.isRunning():
            self._update_thread.quit()
            self._update_thread.wait(1500)
        if hasattr(self, "image_loader") and self.image_loader:
            try:
                self.image_loader.stop()
            except Exception:
                pass
        if hasattr(self, "process_monitor") and self.process_monitor:
            try:
                self.process_monitor.stop()
            except Exception:
                pass
        self._shutdown_net_unblock()
        self._shutdown_steam_chat()
        self._shutdown_steam_free_keep()
        self.tray_icon.hide()
        if hasattr(self, "_gamepad") and self._gamepad:
            try:
                self._gamepad.stop()
                self._gamepad.wait(2000)
            except RuntimeError:
                pass

        all_threads = [
            self._scan_thread, self._image_thread, self._sync_thread, self._discovery_thread,
            getattr(self, '_steam_thread', None), getattr(self, '_shortcut_thread', None),
        ]
        # Include poll thread if it exists
        poll_thread = getattr(self, '_poll_thread', None)
        if poll_thread:
            all_threads.append(poll_thread)
        if hasattr(self, '_active_sync_threads'):
            all_threads.extend(self._active_sync_threads.values())
        if hasattr(self, '_steam_add_threads'):
            all_threads.extend(self._steam_add_threads.values())
        if hasattr(self, '_uninstall_threads'):
            all_threads.extend(self._uninstall_threads.values())
        if hasattr(self, '_launch_threads'):
            all_threads.extend(self._launch_threads.values())

        for thread in all_threads:
            try:
                if thread and self._is_cpp_alive(thread) and thread.isRunning():
                    thread.quit()
                    thread.wait(2000)
            except RuntimeError:
                pass  # Thread's C++ object already deleted
        if hasattr(self, '_active_sync_threads'):
            self._active_sync_threads.clear()
        if hasattr(self, '_active_sync_workers'):
            self._active_sync_workers.clear()
        if hasattr(self, '_steam_add_threads'):
            self._steam_add_threads.clear()
        if hasattr(self, '_steam_add_workers'):
            self._steam_add_workers.clear()
        if hasattr(self, '_uninstall_threads'):
            self._uninstall_threads.clear()
        if hasattr(self, '_uninstall_workers'):
            self._uninstall_workers.clear()
        if hasattr(self, '_launch_threads'):
            self._launch_threads.clear()
        if hasattr(self, '_launch_workers'):
            self._launch_workers.clear()
        # Clean up cloud check threads
        for thread in self._cloud_check_threads:
            try:
                if self._is_cpp_alive(thread) and thread.isRunning():
                    thread.quit()
                    thread.wait(500)
            except RuntimeError:
                pass
        self._cloud_check_threads.clear()

        if hasattr(self, "_log_panel") and self._log_panel:
            self._log_panel.cleanup()

        event.accept()
        QApplication.quit()
