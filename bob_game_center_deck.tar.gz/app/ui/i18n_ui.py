"""Qt UI internationalization bridge: automatic widget text hooks and live retranslation."""

from __future__ import annotations

import logging
import time
import weakref

from PySide6.QtCore import QThread
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QAbstractSpinBox,
    QApplication,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QGroupBox,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QRadioButton,
    QSpinBox,
    QSystemTrayIcon,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QToolButton,
    QTreeWidget,
    QWidget,
)

from app.core.i18n import on_language_changed, tr

try:
    from shiboken6 import isValid as _is_valid_cpp
except ImportError:

    def _is_valid_cpp(_obj) -> bool:
        return True


logger = logging.getLogger(__name__)
TAG = "[UI/I18n]"

SKIP_OBJECT_NAMES = frozenset({"gameTitleLabel", "peerNameLabel"})

_hooks_installed = False
_originals: dict[tuple[type, str], object] = {}
_tray_icons: weakref.WeakSet[QSystemTrayIcon] = weakref.WeakSet()
_unsubscribe_cb = None


def _should_skip(obj) -> bool:
    try:
        if not _is_valid_cpp(obj):
            return True
        if getattr(obj, "_i18n_skip", False):
            return True
        prop_fn = getattr(obj, "property", None)
        if prop_fn is not None and prop_fn("_i18n_skip"):
            return True
        name_fn = getattr(obj, "objectName", None)
        if name_fn is not None and name_fn() in SKIP_OBJECT_NAMES:
            return True
    except RuntimeError:
        return True
    return False


def _is_elided_label(obj) -> bool:
    return type(obj).__name__ in ("_ElidedLabel", "ElidedTextLabel")


def _save_orig(cls: type, name: str):
    key = (cls, name)
    if key not in _originals:
        _originals[key] = getattr(cls, name)
    return _originals[key]


def _get_orig(cls: type, name: str):
    return _originals.get((cls, name)) or getattr(cls, name)


def _translate_str_arg(args: tuple, kwargs: dict, kw_name: str = "text", skip: bool = False):
    """Find first str positional arg or kwarg, return (src_str_or_None, new_args, new_kwargs)."""
    if kw_name in kwargs and isinstance(kwargs[kw_name], str):
        src = kwargs[kw_name]
        if skip:
            return None, args, kwargs
        new_kw = dict(kwargs)
        new_kw[kw_name] = tr(src)
        return src, args, new_kw
    for idx, val in enumerate(args):
        if isinstance(val, str):
            if skip:
                return None, args, kwargs
            new_args = list(args)
            new_args[idx] = tr(val)
            return val, tuple(new_args), kwargs
    return None, args, kwargs


def _wrap_text_widget(cls: type) -> None:
    orig_init = _save_orig(cls, "__init__")
    orig_set = _save_orig(cls, "setText")

    def _init(self, *args, **kwargs):
        skip_pre = (cls is QLabel and _is_elided_label(self)) or bool(getattr(self, "_i18n_skip", False))
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "text", skip=skip_pre)
        orig_init(self, *new_args, **new_kwargs)
        if src is not None and not _should_skip(self) and not (cls is QLabel and _is_elided_label(self)):
            self._i18n_src_text = src

    def _set_text(self, text, *args, **kwargs):
        if (cls is QLabel and _is_elided_label(self)) or not isinstance(text, str) or _should_skip(self):
            return orig_set(self, text, *args, **kwargs)
        self._i18n_src_text = text
        return orig_set(self, tr(text), *args, **kwargs)

    cls.__init__ = _init
    cls.setText = _set_text


def _wrap_groupbox() -> None:
    orig_init = _save_orig(QGroupBox, "__init__")
    orig_set = _save_orig(QGroupBox, "setTitle")

    def _init(self, *args, **kwargs):
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "title", skip=bool(getattr(self, "_i18n_skip", False)))
        orig_init(self, *new_args, **new_kwargs)
        if src is not None and not _should_skip(self):
            self._i18n_src_title = src

    def _set_title(self, title, *args, **kwargs):
        if not isinstance(title, str) or _should_skip(self):
            return orig_set(self, title, *args, **kwargs)
        self._i18n_src_title = title
        return orig_set(self, tr(title), *args, **kwargs)

    QGroupBox.__init__ = _init
    QGroupBox.setTitle = _set_title


def _wrap_placeholders() -> None:
    for cls in (QLineEdit, QTextEdit, QPlainTextEdit):
        orig_set = _save_orig(cls, "setPlaceholderText")

        def _make(orig_fn):
            def _set_placeholder(self, text, *args, **kwargs):
                if not isinstance(text, str) or _should_skip(self):
                    return orig_fn(self, text, *args, **kwargs)
                self._i18n_src_placeholder = text
                return orig_fn(self, tr(text), *args, **kwargs)

            return _set_placeholder

        cls.setPlaceholderText = _make(orig_set)


def _wrap_widget_meta() -> None:
    orig_tip = _save_orig(QWidget, "setToolTip")
    orig_title = _save_orig(QWidget, "setWindowTitle")

    def _set_tooltip(self, text, *args, **kwargs):
        if not isinstance(text, str) or _should_skip(self):
            return orig_tip(self, text, *args, **kwargs)
        self._i18n_src_tooltip = text
        return orig_tip(self, tr(text), *args, **kwargs)

    def _set_window_title(self, title, *args, **kwargs):
        if not isinstance(title, str) or _should_skip(self):
            return orig_title(self, title, *args, **kwargs)
        self._i18n_src_win_title = title
        return orig_title(self, tr(title), *args, **kwargs)

    QWidget.setToolTip = _set_tooltip
    QWidget.setWindowTitle = _set_window_title


def _wrap_combobox() -> None:
    orig_add_item = _save_orig(QComboBox, "addItem")
    orig_add_items = _save_orig(QComboBox, "addItems")
    orig_insert_item = _save_orig(QComboBox, "insertItem")
    orig_set_item_text = _save_orig(QComboBox, "setItemText")
    orig_remove_item = _save_orig(QComboBox, "removeItem")
    orig_clear = _save_orig(QComboBox, "clear")

    def _add_item(self, *args, **kwargs):
        skip = _should_skip(self)
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "text", skip=skip)
        res = orig_add_item(self, *new_args, **new_kwargs)
        if src is not None and not skip:
            srcs = getattr(self, "_i18n_item_srcs", None)
            if srcs is None:
                srcs = {}
                self._i18n_item_srcs = srcs
            srcs[self.count() - 1] = src
        return res

    def _add_items(self, texts, *args, **kwargs):
        skip = _should_skip(self)
        text_list = list(texts)
        base = self.count()
        if not skip:
            translated = [tr(t) if isinstance(t, str) else t for t in text_list]
            res = orig_add_items(self, translated, *args, **kwargs)
            srcs = getattr(self, "_i18n_item_srcs", None)
            if srcs is None:
                srcs = {}
                self._i18n_item_srcs = srcs
            for offset, val in enumerate(text_list):
                if isinstance(val, str):
                    srcs[base + offset] = val
            return res
        return orig_add_items(self, text_list, *args, **kwargs)

    def _insert_item(self, index, *args, **kwargs):
        skip = _should_skip(self)
        clamped = max(0, min(int(index), self.count()))
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "text", skip=skip)
        res = orig_insert_item(self, index, *new_args, **new_kwargs)
        if not skip:
            srcs = getattr(self, "_i18n_item_srcs", None)
            if srcs is None:
                srcs = {}
                self._i18n_item_srcs = srcs
            shifted = {(k + 1 if k >= clamped else k): v for k, v in srcs.items()}
            if src is not None:
                shifted[clamped] = src
            self._i18n_item_srcs = shifted
        return res

    def _set_item_text(self, index, text, *args, **kwargs):
        skip = _should_skip(self)
        if not isinstance(text, str) or skip:
            return orig_set_item_text(self, index, text, *args, **kwargs)
        srcs = getattr(self, "_i18n_item_srcs", None)
        if srcs is None:
            srcs = {}
            self._i18n_item_srcs = srcs
        srcs[int(index)] = text
        return orig_set_item_text(self, index, tr(text), *args, **kwargs)

    def _remove_item(self, index, *args, **kwargs):
        idx = int(index)
        res = orig_remove_item(self, index, *args, **kwargs)
        srcs = getattr(self, "_i18n_item_srcs", None)
        if isinstance(srcs, dict) and srcs:
            self._i18n_item_srcs = {(k - 1 if k > idx else k): v for k, v in srcs.items() if k != idx}
        return res

    def _clear(self, *args, **kwargs):
        self._i18n_item_srcs = {}
        return orig_clear(self, *args, **kwargs)

    QComboBox.addItem = _add_item
    QComboBox.addItems = _add_items
    QComboBox.insertItem = _insert_item
    QComboBox.setItemText = _set_item_text
    QComboBox.removeItem = _remove_item
    QComboBox.clear = _clear


def _wrap_tabwidget() -> None:
    orig_add_tab = _save_orig(QTabWidget, "addTab")
    orig_insert_tab = _save_orig(QTabWidget, "insertTab")
    orig_set_tab_text = _save_orig(QTabWidget, "setTabText")
    orig_set_tab_tip = _save_orig(QTabWidget, "setTabToolTip")
    orig_remove_tab = _save_orig(QTabWidget, "removeTab")
    orig_clear = _save_orig(QTabWidget, "clear")

    def _add_tab(self, widget, *args, **kwargs):
        skip = _should_skip(self)
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "label", skip=skip)
        idx = orig_add_tab(self, widget, *new_args, **new_kwargs)
        if src is not None and not skip and idx >= 0:
            srcs = getattr(self, "_i18n_tab_srcs", None)
            if srcs is None:
                srcs = {}
                self._i18n_tab_srcs = srcs
            srcs[idx] = src
        return idx

    def _insert_tab(self, index, widget, *args, **kwargs):
        skip = _should_skip(self)
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "label", skip=skip)
        idx = orig_insert_tab(self, index, widget, *new_args, **new_kwargs)
        if not skip and idx >= 0:
            srcs = getattr(self, "_i18n_tab_srcs", None) or {}
            shifted = {(k + 1 if k >= idx else k): v for k, v in srcs.items()}
            if src is not None:
                shifted[idx] = src
            self._i18n_tab_srcs = shifted
            tips = getattr(self, "_i18n_tab_tips", None) or {}
            self._i18n_tab_tips = {(k + 1 if k >= idx else k): v for k, v in tips.items()}
        return idx

    def _set_tab_text(self, index, label, *args, **kwargs):
        skip = _should_skip(self)
        if not isinstance(label, str) or skip:
            return orig_set_tab_text(self, index, label, *args, **kwargs)
        srcs = getattr(self, "_i18n_tab_srcs", None)
        if srcs is None:
            srcs = {}
            self._i18n_tab_srcs = srcs
        srcs[int(index)] = label
        return orig_set_tab_text(self, index, tr(label), *args, **kwargs)

    def _set_tab_tip(self, index, tip, *args, **kwargs):
        skip = _should_skip(self)
        if not isinstance(tip, str) or skip:
            return orig_set_tab_tip(self, index, tip, *args, **kwargs)
        tips = getattr(self, "_i18n_tab_tips", None)
        if tips is None:
            tips = {}
            self._i18n_tab_tips = tips
        tips[int(index)] = tip
        return orig_set_tab_tip(self, index, tr(tip), *args, **kwargs)

    def _remove_tab(self, index, *args, **kwargs):
        idx = int(index)
        res = orig_remove_tab(self, index, *args, **kwargs)
        srcs = getattr(self, "_i18n_tab_srcs", None)
        if isinstance(srcs, dict):
            self._i18n_tab_srcs = {(k - 1 if k > idx else k): v for k, v in srcs.items() if k != idx}
        tips = getattr(self, "_i18n_tab_tips", None)
        if isinstance(tips, dict):
            self._i18n_tab_tips = {(k - 1 if k > idx else k): v for k, v in tips.items() if k != idx}
        return res

    def _clear(self, *args, **kwargs):
        self._i18n_tab_srcs = {}
        self._i18n_tab_tips = {}
        return orig_clear(self, *args, **kwargs)

    QTabWidget.addTab = _add_tab
    QTabWidget.insertTab = _insert_tab
    QTabWidget.setTabText = _set_tab_text
    QTabWidget.setTabToolTip = _set_tab_tip
    QTabWidget.removeTab = _remove_tab
    QTabWidget.clear = _clear


def _wrap_tables_and_lists() -> None:
    orig_hheaders = _save_orig(QTableWidget, "setHorizontalHeaderLabels")

    def _set_hheaders(self, labels, *args, **kwargs):
        lbl_list = list(labels)
        if _should_skip(self):
            return orig_hheaders(self, lbl_list, *args, **kwargs)
        self._i18n_hheaders = lbl_list
        return orig_hheaders(self, [tr(l) if isinstance(l, str) else l for l in lbl_list], *args, **kwargs)

    QTableWidget.setHorizontalHeaderLabels = _set_hheaders


def _wrap_spinbox() -> None:
    for cls in (QSpinBox, QDoubleSpinBox):
        for method_name, attr_name in (("setSuffix", "_i18n_src_suffix"), ("setPrefix", "_i18n_src_prefix")):
            orig_fn = _save_orig(cls, method_name)

            def _make_affix(orig_callable, attr):
                def _wrapped(self, text, *args, **kwargs):
                    if not isinstance(text, str) or _should_skip(self):
                        return orig_callable(self, text, *args, **kwargs)
                    setattr(self, attr, text)
                    return orig_callable(self, tr(text), *args, **kwargs)

                return _wrapped

            setattr(cls, method_name, _make_affix(orig_fn, attr_name))

    orig_special = _save_orig(QAbstractSpinBox, "setSpecialValueText")

    def _set_special(self, text, *args, **kwargs):
        if not isinstance(text, str) or _should_skip(self):
            return orig_special(self, text, *args, **kwargs)
        self._i18n_src_special = text
        return orig_special(self, tr(text), *args, **kwargs)

    QAbstractSpinBox.setSpecialValueText = _set_special


def _wrap_treewidget() -> None:
    orig_set_headers = _save_orig(QTreeWidget, "setHeaderLabels")

    def _set_header_labels(self, labels, *args, **kwargs):
        lbl_list = list(labels)
        if _should_skip(self):
            return orig_set_headers(self, lbl_list, *args, **kwargs)
        self._i18n_src_headers = lbl_list
        return orig_set_headers(self, [tr(l) if isinstance(l, str) else l for l in lbl_list], *args, **kwargs)

    QTreeWidget.setHeaderLabels = _set_header_labels

    for item_cls in (QTableWidgetItem, QListWidgetItem):
        orig_init = _save_orig(item_cls, "__init__")
        orig_set_text = _save_orig(item_cls, "setText")
        orig_set_tip = _save_orig(item_cls, "setToolTip")

        def _make_item_wrappers(cls_ref, oi, ost, ostip):
            def _init(self, *args, **kwargs):
                skip = bool(getattr(self, "_i18n_skip", False))
                src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "text", skip=skip)
                oi(self, *new_args, **new_kwargs)
                if src is not None and not skip:
                    self._i18n_src_text = src

            def _set_text(self, text, *args, **kwargs):
                if not isinstance(text, str) or getattr(self, "_i18n_skip", False):
                    return ost(self, text, *args, **kwargs)
                self._i18n_src_text = text
                return ost(self, tr(text), *args, **kwargs)

            def _set_tip(self, tip, *args, **kwargs):
                if not isinstance(tip, str) or getattr(self, "_i18n_skip", False):
                    return ostip(self, tip, *args, **kwargs)
                self._i18n_src_tooltip = tip
                return ostip(self, tr(tip), *args, **kwargs)

            cls_ref.__init__ = _init
            cls_ref.setText = _set_text
            cls_ref.setToolTip = _set_tip

        _make_item_wrappers(item_cls, orig_init, orig_set_text, orig_set_tip)


def _wrap_actions_and_menus() -> None:
    orig_act_init = _save_orig(QAction, "__init__")
    orig_act_text = _save_orig(QAction, "setText")
    orig_act_tip = _save_orig(QAction, "setToolTip")

    def _act_init(self, *args, **kwargs):
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "text", skip=bool(getattr(self, "_i18n_skip", False)))
        orig_act_init(self, *new_args, **new_kwargs)
        if src is not None and not _should_skip(self):
            self._i18n_src_text = src

    def _act_set_text(self, text, *args, **kwargs):
        if not isinstance(text, str) or _should_skip(self):
            return orig_act_text(self, text, *args, **kwargs)
        self._i18n_src_text = text
        return orig_act_text(self, tr(text), *args, **kwargs)

    def _act_set_tip(self, tip, *args, **kwargs):
        if not isinstance(tip, str) or _should_skip(self):
            return orig_act_tip(self, tip, *args, **kwargs)
        self._i18n_src_tooltip = tip
        return orig_act_tip(self, tr(tip), *args, **kwargs)

    QAction.__init__ = _act_init
    QAction.setText = _act_set_text
    QAction.setToolTip = _act_set_tip

    orig_menu_init = _save_orig(QMenu, "__init__")
    orig_menu_title = _save_orig(QMenu, "setTitle")
    orig_menu_add_menu = _save_orig(QMenu, "addMenu")
    orig_menu_add_act = _save_orig(QMenu, "addAction")

    def _menu_init(self, *args, **kwargs):
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "title", skip=bool(getattr(self, "_i18n_skip", False)))
        orig_menu_init(self, *new_args, **new_kwargs)
        if src is not None and not _should_skip(self):
            self._i18n_src_title = src

    def _menu_set_title(self, title, *args, **kwargs):
        if not isinstance(title, str) or _should_skip(self):
            return orig_menu_title(self, title, *args, **kwargs)
        self._i18n_src_title = title
        return orig_menu_title(self, tr(title), *args, **kwargs)

    def _menu_add_menu(self, *args, **kwargs):
        skip = _should_skip(self)
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "title", skip=skip)
        submenu = orig_menu_add_menu(self, *new_args, **new_kwargs)
        if src is not None and submenu is not None and not skip:
            try:
                submenu._i18n_src_title = src
                m_act = submenu.menuAction()
                if m_act is not None:
                    m_act._i18n_src_text = src
            except RuntimeError:
                pass
        return submenu

    def _menu_add_action(self, *args, **kwargs):
        skip = _should_skip(self)
        src, new_args, new_kwargs = _translate_str_arg(args, kwargs, "text", skip=skip)
        action = orig_menu_add_act(self, *new_args, **new_kwargs)
        if src is not None and action is not None and not skip:
            try:
                action._i18n_src_text = src
            except RuntimeError:
                pass
        return action

    QMenu.__init__ = _menu_init
    QMenu.setTitle = _menu_set_title
    QMenu.addMenu = _menu_add_menu
    QMenu.addAction = _menu_add_action


def _wrap_dialogs_and_tray() -> None:
    orig_mb_text = _save_orig(QMessageBox, "setText")
    orig_mb_info_text = _save_orig(QMessageBox, "setInformativeText")

    def _mb_set_text(self, text, *args, **kwargs):
        if not isinstance(text, str) or _should_skip(self):
            return orig_mb_text(self, text, *args, **kwargs)
        self._i18n_src_text = text
        return orig_mb_text(self, tr(text), *args, **kwargs)

    def _mb_set_info_text(self, text, *args, **kwargs):
        if not isinstance(text, str) or _should_skip(self):
            return orig_mb_info_text(self, text, *args, **kwargs)
        self._i18n_src_info_text = text
        return orig_mb_info_text(self, tr(text), *args, **kwargs)

    QMessageBox.setText = _mb_set_text
    QMessageBox.setInformativeText = _mb_set_info_text

    for fn_name in ("information", "warning", "critical", "question"):
        orig_fn = _save_orig(QMessageBox, fn_name)

        def _make_mb_static(orig_callable):
            def _wrapped(parent, title, text, *args, **kwargs):
                t_title = tr(title) if isinstance(title, str) else title
                t_text = tr(text) if isinstance(text, str) else text
                return orig_callable(parent, t_title, t_text, *args, **kwargs)

            return staticmethod(_wrapped)

        setattr(QMessageBox, fn_name, _make_mb_static(orig_fn))

    for fn_name in ("getExistingDirectory", "getOpenFileName", "getOpenFileNames", "getSaveFileName"):
        orig_fn = _save_orig(QFileDialog, fn_name)

        def _make_fd_static(orig_callable, is_dir: bool):
            def _wrapped(*args, **kwargs):
                new_args = list(args)
                new_kw = dict(kwargs)
                if len(new_args) >= 2 and isinstance(new_args[1], str):
                    new_args[1] = tr(new_args[1])
                elif "caption" in new_kw and isinstance(new_kw["caption"], str):
                    new_kw["caption"] = tr(new_kw["caption"])
                if not is_dir:
                    if len(new_args) >= 4 and isinstance(new_args[3], str):
                        new_args[3] = tr(new_args[3])
                    elif "filter" in new_kw and isinstance(new_kw["filter"], str):
                        new_kw["filter"] = tr(new_kw["filter"])
                return orig_callable(*new_args, **new_kw)

            return staticmethod(_wrapped)

        setattr(QFileDialog, fn_name, _make_fd_static(orig_fn, fn_name == "getExistingDirectory"))

    for fn_name in ("getText", "getInt", "getItem"):
        orig_fn = _save_orig(QInputDialog, fn_name)

        def _make_id_static(orig_callable):
            def _wrapped(*args, **kwargs):
                new_args = list(args)
                new_kw = dict(kwargs)
                if len(new_args) >= 2 and isinstance(new_args[1], str):
                    new_args[1] = tr(new_args[1])
                elif "title" in new_kw and isinstance(new_kw["title"], str):
                    new_kw["title"] = tr(new_kw["title"])
                if len(new_args) >= 3 and isinstance(new_args[2], str):
                    new_args[2] = tr(new_args[2])
                elif "label" in new_kw and isinstance(new_kw["label"], str):
                    new_kw["label"] = tr(new_kw["label"])
                return orig_callable(*new_args, **new_kw)

            return staticmethod(_wrapped)

        setattr(QInputDialog, fn_name, _make_id_static(orig_fn))

    orig_tray_init = _save_orig(QSystemTrayIcon, "__init__")
    orig_tray_tip = _save_orig(QSystemTrayIcon, "setToolTip")
    orig_tray_msg = _save_orig(QSystemTrayIcon, "showMessage")

    def _tray_init(self, *args, **kwargs):
        orig_tray_init(self, *args, **kwargs)
        _tray_icons.add(self)

    def _tray_set_tip(self, tip, *args, **kwargs):
        _tray_icons.add(self)
        if isinstance(tip, str) and not _should_skip(self):
            self._i18n_src_tooltip = tip
            return orig_tray_tip(self, tr(tip), *args, **kwargs)
        return orig_tray_tip(self, tip, *args, **kwargs)

    def _tray_show_msg(self, title, msg, *args, **kwargs):
        t_title = tr(title) if isinstance(title, str) else title
        t_msg = tr(msg) if isinstance(msg, str) else msg
        return orig_tray_msg(self, t_title, t_msg, *args, **kwargs)

    QSystemTrayIcon.__init__ = _tray_init
    QSystemTrayIcon.setToolTip = _tray_set_tip
    QSystemTrayIcon.showMessage = _tray_show_msg


def _refresh_actions(actions: list[QAction]) -> int:
    orig_act_text = _get_orig(QAction, "setText")
    orig_act_tip = _get_orig(QAction, "setToolTip")
    orig_menu_title = _get_orig(QMenu, "setTitle")
    count = 0
    for act in actions:
        if not _is_valid_cpp(act) or _should_skip(act):
            continue
        src_text = getattr(act, "_i18n_src_text", None)
        if isinstance(src_text, str):
            new_t = tr(src_text)
            if act.text() != new_t:
                orig_act_text(act, new_t)
                count += 1
        src_tip = getattr(act, "_i18n_src_tooltip", None)
        if isinstance(src_tip, str):
            new_tip = tr(src_tip)
            if act.toolTip() != new_tip:
                orig_act_tip(act, new_tip)
                count += 1
        submenu = act.menu()
        if submenu is not None and _is_valid_cpp(submenu) and not _should_skip(submenu):
            sm_title = getattr(submenu, "_i18n_src_title", None)
            if isinstance(sm_title, str):
                new_sm = tr(sm_title)
                if submenu.title() != new_sm:
                    orig_menu_title(submenu, new_sm)
                    count += 1
            count += _refresh_actions(list(submenu.actions()))
    return count


def _refresh_single_widget(w: QWidget) -> int:
    changed = 0
    if not _is_valid_cpp(w):
        return 0
    if _should_skip(w):
        retranslate = getattr(w, "retranslate_ui", None)
        if callable(retranslate):
            retranslate()
            w.updateGeometry()
            w.update()
            return 1
        return 0

    # Standard text controls
    for cls in (QLabel, QPushButton, QCheckBox, QRadioButton, QToolButton):
        if isinstance(w, cls):
            if cls is QLabel and _is_elided_label(w):
                break
            src = getattr(w, "_i18n_src_text", None)
            if isinstance(src, str):
                orig_set = _get_orig(cls, "setText")
                new_txt = tr(src)
                if w.text() != new_txt:
                    orig_set(w, new_txt)
                    changed += 1
            break

    if isinstance(w, QGroupBox):
        src_title = getattr(w, "_i18n_src_title", None)
        if isinstance(src_title, str):
            new_title = tr(src_title)
            if w.title() != new_title:
                _get_orig(QGroupBox, "setTitle")(w, new_title)
                changed += 1

    if isinstance(w, QMessageBox):
        src_mb = getattr(w, "_i18n_src_text", None)
        if isinstance(src_mb, str):
            new_mb = tr(src_mb)
            if w.text() != new_mb:
                _get_orig(QMessageBox, "setText")(w, new_mb)
                changed += 1
        src_info = getattr(w, "_i18n_src_info_text", None)
        if isinstance(src_info, str):
            new_info = tr(src_info)
            if w.informativeText() != new_info:
                _get_orig(QMessageBox, "setInformativeText")(w, new_info)
                changed += 1

    if isinstance(w, (QLineEdit, QTextEdit, QPlainTextEdit)):
        src_ph = getattr(w, "_i18n_src_placeholder", None)
        if isinstance(src_ph, str):
            new_ph = tr(src_ph)
            if w.placeholderText() != new_ph:
                _get_orig(type(w) if type(w) in (QLineEdit, QTextEdit, QPlainTextEdit) else QLineEdit, "setPlaceholderText")(w, new_ph)
                changed += 1

    if isinstance(w, QComboBox):
        srcs = getattr(w, "_i18n_item_srcs", None)
        if isinstance(srcs, dict) and srcs:
            orig_set_item = _get_orig(QComboBox, "setItemText")
            was_blocked = w.signalsBlocked()
            w.blockSignals(True)
            try:
                total = w.count()
                for idx, src_item in srcs.items():
                    if 0 <= idx < total and isinstance(src_item, str):
                        new_item = tr(src_item)
                        if w.itemText(idx) != new_item:
                            orig_set_item(w, idx, new_item)
                            changed += 1
            finally:
                w.blockSignals(was_blocked)

    if isinstance(w, (QSpinBox, QDoubleSpinBox)):
        spin_cls = QDoubleSpinBox if isinstance(w, QDoubleSpinBox) else QSpinBox
        src_suf = getattr(w, "_i18n_src_suffix", None)
        if isinstance(src_suf, str):
            new_suf = tr(src_suf)
            if w.suffix() != new_suf:
                _get_orig(spin_cls, "setSuffix")(w, new_suf)
                changed += 1
        src_pre = getattr(w, "_i18n_src_prefix", None)
        if isinstance(src_pre, str):
            new_pre = tr(src_pre)
            if w.prefix() != new_pre:
                _get_orig(spin_cls, "setPrefix")(w, new_pre)
                changed += 1

    if isinstance(w, QAbstractSpinBox):
        src_spec = getattr(w, "_i18n_src_special", None)
        if isinstance(src_spec, str):
            new_spec = tr(src_spec)
            if w.specialValueText() != new_spec:
                _get_orig(QAbstractSpinBox, "setSpecialValueText")(w, new_spec)
                changed += 1

    if isinstance(w, QTreeWidget):
        src_hdrs = getattr(w, "_i18n_src_headers", None)
        if isinstance(src_hdrs, list) and src_hdrs:
            _get_orig(QTreeWidget, "setHeaderLabels")(
                w, [tr(h) if isinstance(h, str) else h for h in src_hdrs]
            )
            changed += 1

    if isinstance(w, QTabWidget):
        tab_srcs = getattr(w, "_i18n_tab_srcs", None)
        if isinstance(tab_srcs, dict) and tab_srcs:
            orig_set_tab = _get_orig(QTabWidget, "setTabText")
            total = w.count()
            for idx, src_tab in tab_srcs.items():
                if 0 <= idx < total and isinstance(src_tab, str):
                    new_tab = tr(src_tab)
                    if w.tabText(idx) != new_tab:
                        orig_set_tab(w, idx, new_tab)
                        changed += 1
        tab_tips = getattr(w, "_i18n_tab_tips", None)
        if isinstance(tab_tips, dict) and tab_tips:
            orig_tab_tip = _get_orig(QTabWidget, "setTabToolTip")
            total = w.count()
            for idx, src_tip in tab_tips.items():
                if 0 <= idx < total and isinstance(src_tip, str):
                    new_tip = tr(src_tip)
                    if w.tabToolTip(idx) != new_tip:
                        orig_tab_tip(w, idx, new_tip)
                        changed += 1

    if isinstance(w, QTableWidget):
        headers = getattr(w, "_i18n_hheaders", None)
        if isinstance(headers, list) and headers:
            _get_orig(QTableWidget, "setHorizontalHeaderLabels")(
                w, [tr(h) if isinstance(h, str) else h for h in headers]
            )
            changed += 1
        orig_twi_text = _get_orig(QTableWidgetItem, "setText")
        orig_twi_tip = _get_orig(QTableWidgetItem, "setToolTip")
        for r in range(w.rowCount()):
            for c in range(w.columnCount()):
                item = w.item(r, c)
                if item is not None and not getattr(item, "_i18n_skip", False):
                    st = getattr(item, "_i18n_src_text", None)
                    if isinstance(st, str):
                        nt = tr(st)
                        if item.text() != nt:
                            orig_twi_text(item, nt)
                            changed += 1
                    stip = getattr(item, "_i18n_src_tooltip", None)
                    if isinstance(stip, str):
                        ntip = tr(stip)
                        if item.toolTip() != ntip:
                            orig_twi_tip(item, ntip)
                            changed += 1

    if isinstance(w, QListWidget):
        orig_lwi_text = _get_orig(QListWidgetItem, "setText")
        orig_lwi_tip = _get_orig(QListWidgetItem, "setToolTip")
        for i in range(w.count()):
            item = w.item(i)
            if item is not None and not getattr(item, "_i18n_skip", False):
                st = getattr(item, "_i18n_src_text", None)
                if isinstance(st, str):
                    nt = tr(st)
                    if item.text() != nt:
                        orig_lwi_text(item, nt)
                        changed += 1
                stip = getattr(item, "_i18n_src_tooltip", None)
                if isinstance(stip, str):
                    ntip = tr(stip)
                    if item.toolTip() != ntip:
                        orig_lwi_tip(item, ntip)
                        changed += 1

    if isinstance(w, QMenu):
        m_title = getattr(w, "_i18n_src_title", None)
        if isinstance(m_title, str):
            new_mt = tr(m_title)
            if w.title() != new_mt:
                _get_orig(QMenu, "setTitle")(w, new_mt)
                changed += 1

    # Widget tooltip & window title
    src_tip = getattr(w, "_i18n_src_tooltip", None)
    if isinstance(src_tip, str):
        new_tip = tr(src_tip)
        if w.toolTip() != new_tip:
            _get_orig(QWidget, "setToolTip")(w, new_tip)
            changed += 1

    src_wt = getattr(w, "_i18n_src_win_title", None)
    if isinstance(src_wt, str):
        new_wt = tr(src_wt)
        if w.windowTitle() != new_wt:
            _get_orig(QWidget, "setWindowTitle")(w, new_wt)
            changed += 1

    acts = list(w.actions())
    if acts:
        changed += _refresh_actions(acts)

    retranslate = getattr(w, "retranslate_ui", None)
    if callable(retranslate):
        retranslate()
        changed += 1

    w.updateGeometry()
    w.update()
    return changed


def refresh_all_widgets() -> int:
    """Retranslate every live Qt widget, menu, and tray icon to the active language."""
    app = QApplication.instance()
    if app is None:
        return 0

    started = time.perf_counter()
    updated_widgets = 0
    for w in list(app.allWidgets()):
        try:
            if not _is_valid_cpp(w):
                continue
            updated_widgets += 1
            _refresh_single_widget(w)
        except RuntimeError:
            continue
        except Exception as exc:
            logger.error(f"{TAG} Error refreshing widget {type(w).__name__}: {exc}", exc_info=True)

    orig_tray_tip = _get_orig(QSystemTrayIcon, "setToolTip")
    for tray in list(_tray_icons):
        try:
            if not _is_valid_cpp(tray) or _should_skip(tray):
                continue
            src_tip = getattr(tray, "_i18n_src_tooltip", None)
            if isinstance(src_tip, str):
                new_tip = tr(src_tip)
                if tray.toolTip() != new_tip:
                    orig_tray_tip(tray, new_tip)
            ctx_menu = tray.contextMenu()
            if ctx_menu is not None and _is_valid_cpp(ctx_menu):
                _refresh_actions(list(ctx_menu.actions()))
        except RuntimeError:
            continue
        except Exception as exc:
            logger.error(f"{TAG} Error refreshing tray icon: {exc}", exc_info=True)

    elapsed = time.perf_counter() - started
    logger.info(f"{TAG} Refreshed {updated_widgets} widgets for active language in {elapsed:.3f}s")
    return updated_widgets


def _on_lang_changed_bridge(_lang: str) -> None:
    app = QApplication.instance()
    if app is None:
        return
    if QThread.currentThread() != app.thread():
        return
    refresh_all_widgets()


def install_qt_i18n_hooks() -> None:
    """Install idempotent PySide6 i18n hooks and subscribe live widget refresh."""
    global _hooks_installed, _unsubscribe_cb
    if _hooks_installed:
        return
    _hooks_installed = True

    for cls in (QLabel, QPushButton, QCheckBox, QRadioButton, QToolButton):
        _wrap_text_widget(cls)
    _wrap_groupbox()
    _wrap_placeholders()
    _wrap_widget_meta()
    _wrap_combobox()
    _wrap_spinbox()
    _wrap_tabwidget()
    _wrap_tables_and_lists()
    _wrap_treewidget()
    _wrap_actions_and_menus()
    _wrap_dialogs_and_tray()

    _unsubscribe_cb = on_language_changed(_on_lang_changed_bridge)
    logger.debug(f"{TAG} Qt i18n hooks installed")
