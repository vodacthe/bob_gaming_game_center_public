# Third-party notices

## WinDivert 2.2.2 (packet capture driver) - `assets/windivert/`

* Files: `WinDivert.dll`, `WinDivert64.sys` (signed driver), `LICENSE`. Unmodified binaries from the official
  release https://github.com/basil00/WinDivert/releases/tag/v2.2.2 (`WinDivert-2.2.2-A.zip`, `x64/`).
* License: GNU Lesser General Public License v3.0 (see `assets/windivert/LICENSE`). The DLL is loaded dynamically
  through `app/core/net_unblock/windivert.py`; you may replace it with another build of the same ABI.
* SHA-256 (pinned in `windivert.py`, checked before every load):
  * `WinDivert.dll`   `c1e060ee19444a259b2162f8af0f3fe8c4428a1c6f694dce20de194ac8d7d9a2`
  * `WinDivert64.sys` `8da085332782708d8767bcace5327a6ec7283c17cfb85e40b03cd2323a90ddc2`
* Used only by the optional "Packet engine" of Network Unblock, off by default.

## GoodbyeDPI (algorithms) - https://github.com/ValdikSS/GoodbyeDPI

* License: Apache License 2.0. No GoodbyeDPI source or binary is shipped. `app/core/net_unblock/dpi_engine.py` is an
  independent Python implementation of the techniques behind its options `-e`, `--reverse-frag`, `--auto-ttl`,
  `--wrong-chksum`, `--wrong-seq`, `-p` and `-q`.

## moonlight-common-c - `native/bin/x64/moonlight-common-c.dll`

* Core streaming protocol client library for Moonlight / Sunshine / Apollo.
* Source: https://github.com/ClassicOldSong/moonlight-common-c (fork of Moonlight, commit `ad329b2`).
* License: GNU General Public License v3.0 (GPL-3.0).
* Embedded subcomponents:
  * **ENet** (UDP reliable networking): MIT License, Copyright (c) 2002-2020 Lee Salzman.
  * **Reed-Solomon FEC Codec**: BSD 2-Clause License, Copyright (c) 2002 Phil Karn, KA9Q.
* The DLL is loaded dynamically via `ctypes` in `app/core/remote/limelight/`.

## OpenSSL 3.3.2 - `native/bin/x64/libcrypto-3-x64.dll`

* Cryptographic algorithms (AES-128-CBC, RSA, SHA-256) used by streaming session and pairing.
* Source: OpenSSL Project (https://www.openssl.org/).
* License: Apache License 2.0.

## FFmpeg 7.1 - `native/bin/x64/avcodec-61.dll`, `avutil-59.dll`, `swscale-8.dll`

* Video decoding (H.264, HEVC, AV1) and hardware acceleration interfaces (D3D11VA, DXVA2).
* Built under GNU Lesser General Public License v2.1+ (LGPL-2.1+), without `--enable-gpl`.
* Source: https://ffmpeg.org/.
* Loaded dynamically via `ctypes` in `app/core/remote/stream/video/ffmpeg_api.py`.

## dav1d 1.4.3 - `native/bin/x64/dav1d.dll`

* High-performance AV1 decoder library (used by FFmpeg for software AV1 decoding).
* Source: VideoLAN (https://code.videolan.org/videolan/dav1d).
* License: BSD 2-Clause License, Copyright (c) 2018-2024 VideoLAN and contributors.

## ModeSeven Font - `assets/fonts/ModeSeven.ttf`

* Monospaced bitmap-style display font used for the in-stream performance stats HUD overlay.
* Author: Andrew Bulhak (1998).
* License: Freeware / Public Domain font.


## Nefarius ViGEmClient - `native/bin/x64/ViGEmClient.dll`

* User-mode C client library for the Virtual Gamepad Emulation Framework (`ViGEmBus`), used to create a virtual Xbox
  360 (`XInput`) controller when Steam Controller (2015) translation is enabled.
* Source: https://github.com/nefarius/ViGEmClient (official x64 release binary distributed via `vgamepad` / Nefarius).
* License: MIT License, Copyright (c) 2017-2023 Benjamin Höglinger-Stelzer (Nefarius Software Solutions e.U.).
* SHA-256 (pinned in `app/core/steam_controller/vigem.py`, verified before every load):
  * `ViGEmClient.dll` `2bf0cb1d809039573c922737d298a1653d4dbc61408060ff45a9bcfde82e97d2`
* The optional `ViGEmBus v1.22.0` kernel bus driver installer (`ViGEmBus_1.22.0_x64_x86_arm64.exe`, MIT / BSD-3-Clause,
  Microsoft WHQL-signed) is not bundled inside the `.exe`; if missing on a PC, it can be downloaded on demand from the
  official release https://github.com/nefarius/ViGEmBus/releases/tag/v1.22.0 and verified against pinned SHA-256
  `89220a7865076b342892f98865f3499fb7c4cfd673159e89d352c360fd014c6a` before silent installation.
